define(["require", "exports"], function (require, exports) {
    "use strict";
    var AppConfig = (function () {
        //static BT_BASE_URL:string = "http://dmedap3002.jmlfdc.mil:8080/";
        function AppConfig() {
        }
        //"http://dmetpx4007.jmlfdc.mil:8080/"  -- Test
        //"http://dmedpx3005.jmlfdc.mil:8080/"  -- Dev
        //"http://dmedap3002.jmlfdc.mil:8080/"  -- Dev Direct
        //"http://localhost:8080/" -- Local
        AppConfig.BT_BASE_URL = "http://localhost:8080/";
        return AppConfig;
    }());
    exports.AppConfig = AppConfig;
});
//# sourceMappingURL=appconfig.js.map