/// <reference path="../typings/index.d.ts" />

import {App} from "./module";

// modules
import commonModule from './_common/module';
import constantsModule from './_constants/module';
import modelsModule from './_models/module';
import directivesModule from './_directives/module';
import servicesModule from './_services/module';
import homeModule from './home/module';
import loginModule from './login/module';
import securityModule from './security/module';


import "/src/content/css/angular.rangeSlider.css!";
import "/src/content/css/animations.css!";
import "/src/content/css/daterangepicker.css!";
import "/src/content/css/font-awesome.css!";
import "/src/content/css/growl.css!";
import "/src/content/css/isteven-multi-select.css!";
import "/src/content/css/ng-table.css!";
import "/src/content/css/sidebar.css!";
import "/src/content/css/bootstrap-amz-theme.css!";
import "/src/content/css/app-style.css!";
import "/src/content/css/isteven-extension.css!";
import "/src/content/css/bootstrap-extension.css!";


App.element(document).ready(() => {
    App.bootstrap(document, [
        'DmlesModule',
        constantsModule.name,
        servicesModule.name,
        commonModule.name,
        modelsModule.name,
        directivesModule.name,
        homeModule.name,
        loginModule.name,
        securityModule.name
    ]);


});