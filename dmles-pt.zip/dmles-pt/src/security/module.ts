'use strict';

import router from './router';
import viewsModule from './_views/module';

var module = angular.module('Dmles.Security.Module', [
    viewsModule.name
]);

module.config(router.factory);

export default module;