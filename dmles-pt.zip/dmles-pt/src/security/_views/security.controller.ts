'use strict';

export class SecurityController {
    private controllerName: string = "Security Controller";
    public isNavShown = true;
    private navOpened = '20%';
    private navClosed = 0;
    public navWidth:any = {};
    public navMargin:any = {};

    // @ngInject
    constructor(private $log, private $state, private StateConstants) {
        this.$log.debug("%s - Start", this.controllerName);
        this.navWidth = { "width" : this.navClosed };
        this.navMargin = { "margin-right" : this.navClosed };
    }

    public goToLogin() {
        console.log("%s - Go to Login", this.controllerName);
        this.$state.go(this.StateConstants.LOGIN);
    }

    public toggleClass(){
        this.isNavShown = !this.isNavShown;
        if(this.isNavShown){
            this.navWidth = { "width" : this.navClosed };
            this.navMargin = { "margin-right" : this.navClosed };
        }else{
            this.navWidth = { "width" : this.navOpened };
            this.navMargin = { "margin-right" : this.navOpened };
        }
    }
}