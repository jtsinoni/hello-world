'use strict';

import {SecurityController} from './security.controller';

var controllersModule = angular.module('Dmles.Security.Views.Module', []);
controllersModule.controller('Dmles.Security.Views.SecurityController', SecurityController);

export default controllersModule;