'use strict';

class Router {
    static instance:any;

    // @ngInject
    constructor($stateProvider, $urlRouterProvider, StateConstants) {

        $stateProvider
        .state(StateConstants.SECURITY, {
            url: '/security',
            templateUrl: '/src/security/_views/security.html',
            controller: 'Dmles.Security.Views.SecurityController',
            controllerAs: 'vm'
        })
        ;

    }

    static factory($stateProvider, $urlRouterProvider, StateConstants) {
        Router.instance = new Router($stateProvider, $urlRouterProvider, StateConstants);
        return Router.instance;
    }
}

Router.factory.$inject = ['$stateProvider', '$urlRouterProvider', 'StateConstants'];

export default Router;