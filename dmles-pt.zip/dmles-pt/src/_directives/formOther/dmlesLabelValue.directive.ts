import {DmlesLabelValueController} from "./dmlesLabelValue.controller";

export class DmlesLabelValue implements ng.IDirective {
    public restrict:string = "EA";
    public controller = DmlesLabelValueController;
    public controllerAs: string = 'ctrl';
    public templateUrl:string = "./src/_directives/formOther/dmlesLabelValue.template.html";

    public bindToController:any = {
        label: '@',
        value: '@',
        labelColsClass: '@',
        valueColsClass: '@',
        labelCustomClass: '@',
        valueCustomClass: '@',
        popover: '@'
    };

    public scope: any = {};

    // @ngInject
    constructor(private $log) {}

    public static Factory() {
        const directive = ($log) => new DmlesLabelValue($log);
        directive.$inject = ['$log'];
        return directive;
    }
}