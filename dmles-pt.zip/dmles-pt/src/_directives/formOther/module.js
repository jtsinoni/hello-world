define(["require", "exports", "./dmlesLabelValue.controller", "./dmlesLabelValue.directive"], function (require, exports, dmlesLabelValue_controller_1, dmlesLabelValue_directive_1) {
    "use strict";
    var dmlesFormOtherModule = angular.module('DmlesFormOtherModule', []);
    dmlesFormOtherModule.controller('DmlesLabelValueController', dmlesLabelValue_controller_1.DmlesLabelValueController);
    dmlesFormOtherModule.directive('dmlesLabelValue', dmlesLabelValue_directive_1.DmlesLabelValue.Factory());
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = dmlesFormOtherModule;
});
//# sourceMappingURL=module.js.map