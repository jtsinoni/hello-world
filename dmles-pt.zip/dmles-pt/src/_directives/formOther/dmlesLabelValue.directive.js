define(["require", "exports", "./dmlesLabelValue.controller"], function (require, exports, dmlesLabelValue_controller_1) {
    "use strict";
    var DmlesLabelValue = (function () {
        // @ngInject
        function DmlesLabelValue($log) {
            this.$log = $log;
            this.restrict = "EA";
            this.controller = dmlesLabelValue_controller_1.DmlesLabelValueController;
            this.controllerAs = 'ctrl';
            this.templateUrl = "./src/_directives/formOther/dmlesLabelValue.template.html";
            this.bindToController = {
                label: '@',
                value: '@',
                labelColsClass: '@',
                valueColsClass: '@',
                labelCustomClass: '@',
                valueCustomClass: '@',
                popover: '@'
            };
            this.scope = {};
        }
        DmlesLabelValue.Factory = function () {
            var directive = function ($log) { return new DmlesLabelValue($log); };
            directive.$inject = ['$log'];
            return directive;
        };
        return DmlesLabelValue;
    }());
    exports.DmlesLabelValue = DmlesLabelValue;
});
//# sourceMappingURL=dmlesLabelValue.directive.js.map