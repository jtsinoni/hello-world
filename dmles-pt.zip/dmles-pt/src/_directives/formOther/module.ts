import {DmlesLabelValueController} from "./dmlesLabelValue.controller";
import {DmlesLabelValue} from "./dmlesLabelValue.directive";

var dmlesFormOtherModule = angular.module('DmlesFormOtherModule', []);

dmlesFormOtherModule.controller('DmlesLabelValueController', DmlesLabelValueController);
dmlesFormOtherModule.directive('dmlesLabelValue', DmlesLabelValue.Factory());

export default dmlesFormOtherModule;