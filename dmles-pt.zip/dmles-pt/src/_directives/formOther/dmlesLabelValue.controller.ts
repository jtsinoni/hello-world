export class DmlesLabelValueController {
    private controllerName:string = "DmlesLabelValueController Directive";

    public label:string;
    public value:string;
    public labelColsClass:string;
    public valueColsClass:string;
    public labelCustomClass:string;
    public valueCustomClass:string;
    public popover:string;

    constructor(public $scope, private $log) {
        this.$log.debug('%s - Start', this.controllerName);
        this.init();
    }

    private init():void {

        if(!this.labelColsClass){
            this.labelColsClass = "col-sm-3";
        }

        if(!this.valueColsClass){
            this.valueColsClass = "col-sm-9";
        }
    }

}