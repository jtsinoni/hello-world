define(["require", "exports"], function (require, exports) {
    "use strict";
    var DmlesLabelValueController = (function () {
        function DmlesLabelValueController($scope, $log) {
            this.$scope = $scope;
            this.$log = $log;
            this.controllerName = "DmlesLabelValueController Directive";
            this.$log.debug('%s - Start', this.controllerName);
            this.init();
        }
        DmlesLabelValueController.prototype.init = function () {
            if (!this.labelColsClass) {
                this.labelColsClass = "col-sm-3";
            }
            if (!this.valueColsClass) {
                this.valueColsClass = "col-sm-9";
            }
        };
        return DmlesLabelValueController;
    }());
    exports.DmlesLabelValueController = DmlesLabelValueController;
});
//# sourceMappingURL=dmlesLabelValue.controller.js.map