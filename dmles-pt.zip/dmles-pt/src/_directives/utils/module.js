define(["require", "exports", "./dmlesHideAttr.directive", "./dmlesLoadingIcon.directive", "./dmlesLoadingIcon.controller"], function (require, exports, dmlesHideAttr_directive_1, dmlesLoadingIcon_directive_1, dmlesLoadingIcon_controller_1) {
    "use strict";
    var dmlesDirectiveUtilsModule = angular.module('dmlesDirectiveUtilsModule', []);
    dmlesDirectiveUtilsModule.controller('DmlesLoadingIconController', dmlesLoadingIcon_controller_1.DmlesLoadingIconController);
    dmlesDirectiveUtilsModule.directive('dmlesHideAttr', dmlesHideAttr_directive_1.DmlesHideAttr.Factory());
    dmlesDirectiveUtilsModule.directive('dmlesLoadingIcon', dmlesLoadingIcon_directive_1.DmlesLoadingIcon.Factory());
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = dmlesDirectiveUtilsModule;
});
//# sourceMappingURL=module.js.map