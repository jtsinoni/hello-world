define(["require", "exports", "./dmlesLoadingIcon.controller"], function (require, exports, dmlesLoadingIcon_controller_1) {
    "use strict";
    var DmlesLoadingIcon = (function () {
        // @ngInject
        function DmlesLoadingIcon($log) {
            this.$log = $log;
            this.restrict = "E";
            this.controller = dmlesLoadingIcon_controller_1.DmlesLoadingIconController;
            this.controllerAs = 'ctrl';
            this.templateUrl = "./src/_directives/utils/dmlesLoadingIcon.template.html";
            this.scope = {};
            this.bindToController = {
                loadingMsg: '@'
            };
        }
        DmlesLoadingIcon.Factory = function () {
            var directive = function ($log) { return new DmlesLoadingIcon($log); };
            directive.$inject = ['$log'];
            return directive;
        };
        return DmlesLoadingIcon;
    }());
    exports.DmlesLoadingIcon = DmlesLoadingIcon;
});
//# sourceMappingURL=dmlesLoadingIcon.directive.js.map