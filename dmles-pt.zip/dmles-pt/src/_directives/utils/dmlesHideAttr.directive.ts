/*
 <input  ng-model="target"/>
 <input placeholder="hello" dmles-attr-to-hide="placeholder" dmles-hide-attr="target=='hello'"/>

 dmles-hide-attr: expression to determine to hide attr or not
 dmles-attr-to-hide: attr to hide if dmles-hide-attr: is true
 */

export class DmlesHideAttr implements ng.IDirective {
    public restrict:string = "A";

    public scope:any = {
        dmlesHideAttr: '='
    };

    public link = ($scope, $element, $attr, ...args) => {
        var targetAttr = $attr.dmlesAttrToHide;
        var saveAttr = $attr[targetAttr] || '';
        $scope.$watch('dmlesHideAttr', function(newVal){
            if (newVal){
                $element.removeAttr(targetAttr);
            } else {
                $element.attr(targetAttr,saveAttr);
            }
        })
    };

    // @ngInject
    constructor(private $log) {
        DmlesHideAttr.prototype.link = (scope, element, attr) => {
        };
    }

    public static Factory() {
        const directive = ($log) => new DmlesHideAttr($log);
        directive.$inject = ['$log'];
        return directive;
    }
}