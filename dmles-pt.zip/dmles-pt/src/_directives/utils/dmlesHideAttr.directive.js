/*
 <input  ng-model="target"/>
 <input placeholder="hello" dmles-attr-to-hide="placeholder" dmles-hide-attr="target=='hello'"/>

 dmles-hide-attr: expression to determine to hide attr or not
 dmles-attr-to-hide: attr to hide if dmles-hide-attr: is true
 */
define(["require", "exports"], function (require, exports) {
    "use strict";
    var DmlesHideAttr = (function () {
        // @ngInject
        function DmlesHideAttr($log) {
            this.$log = $log;
            this.restrict = "A";
            this.scope = {
                dmlesHideAttr: '='
            };
            this.link = function ($scope, $element, $attr) {
                var args = [];
                for (var _i = 3; _i < arguments.length; _i++) {
                    args[_i - 3] = arguments[_i];
                }
                var targetAttr = $attr.dmlesAttrToHide;
                var saveAttr = $attr[targetAttr] || '';
                $scope.$watch('dmlesHideAttr', function (newVal) {
                    if (newVal) {
                        $element.removeAttr(targetAttr);
                    }
                    else {
                        $element.attr(targetAttr, saveAttr);
                    }
                });
            };
            DmlesHideAttr.prototype.link = function (scope, element, attr) {
            };
        }
        DmlesHideAttr.Factory = function () {
            var directive = function ($log) { return new DmlesHideAttr($log); };
            directive.$inject = ['$log'];
            return directive;
        };
        return DmlesHideAttr;
    }());
    exports.DmlesHideAttr = DmlesHideAttr;
});
//# sourceMappingURL=dmlesHideAttr.directive.js.map