import {DmlesLoadingIconController} from "./dmlesLoadingIcon.controller";

export class DmlesLoadingIcon implements ng.IDirective {
    public restrict:string = "E";
    public controller = DmlesLoadingIconController;
    public controllerAs: string = 'ctrl';
    public templateUrl:string = "./src/_directives/utils/dmlesLoadingIcon.template.html";

    public scope: any = {};

    public bindToController:any = {
        loadingMsg: '@'
    };

    // @ngInject
    constructor(private $log) {}

    public static Factory() {
        const directive = ($log) => new DmlesLoadingIcon($log);
        directive.$inject = ['$log'];
        return directive;
    }
}