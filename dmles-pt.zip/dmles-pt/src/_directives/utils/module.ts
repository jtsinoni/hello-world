import {DmlesHideAttr} from "./dmlesHideAttr.directive";
import {DmlesLoadingIcon} from "./dmlesLoadingIcon.directive";
import {DmlesLoadingIconController} from "./dmlesLoadingIcon.controller";

var dmlesDirectiveUtilsModule = angular.module('dmlesDirectiveUtilsModule', []);

dmlesDirectiveUtilsModule.controller('DmlesLoadingIconController', DmlesLoadingIconController);

dmlesDirectiveUtilsModule.directive('dmlesHideAttr', DmlesHideAttr.Factory());
dmlesDirectiveUtilsModule.directive('dmlesLoadingIcon', DmlesLoadingIcon.Factory());

export default dmlesDirectiveUtilsModule;