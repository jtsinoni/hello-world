define(["require", "exports"], function (require, exports) {
    "use strict";
    var DmlesLoadingIconController = (function () {
        function DmlesLoadingIconController($scope, $log) {
            this.$scope = $scope;
            this.$log = $log;
            this.controllerName = "DmlesLoadingIconController Directive";
            this.$log.debug('%s - Start', this.controllerName);
            this.init();
        }
        DmlesLoadingIconController.prototype.init = function () {
            if (!this.loadingMsg) {
                this.loadingMsg = "Loading...";
            }
        };
        return DmlesLoadingIconController;
    }());
    exports.DmlesLoadingIconController = DmlesLoadingIconController;
});
//# sourceMappingURL=dmlesLoadingIcon.controller.js.map