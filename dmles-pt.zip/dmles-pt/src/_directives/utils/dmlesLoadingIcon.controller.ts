export class DmlesLoadingIconController {
    private controllerName:string = "DmlesLoadingIconController Directive";

    public loadingMsg:string;

    constructor(public $scope, private $log) {
        this.$log.debug('%s - Start', this.controllerName);
        this.init();
    }

    private init():void {

        if(!this.loadingMsg){
            this.loadingMsg = "Loading...";
        }

    }

}