define(["require", "exports"], function (require, exports) {
    "use strict";
    var SearchInputController = (function () {
        //@inject
        function SearchInputController($log, $scope) {
            this.$log = $log;
            this.$scope = $scope;
            this.controllerName = "SearchInputController Directive";
            this.$log.debug('%s - Start', this.controllerName);
        }
        SearchInputController.prototype.executeSearch = function () {
            this.$log.debug("%s - Search criteria: %s", this.controllerName, this.searchInputData);
            this.$scope.executeSearch({ searchCriteria: this.searchInputData }); // Calls parent controller search
        };
        return SearchInputController;
    }());
    exports.SearchInputController = SearchInputController;
});
//# sourceMappingURL=searchInput.controller.js.map