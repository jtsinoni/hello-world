define(["require", "exports"], function (require, exports) {
    'use strict';
    var SelectedFacetOptionsBreadbox = (function () {
        // @ngInject
        function SelectedFacetOptionsBreadbox() {
            this.templateUrl = "src/_directives/searchComponents/selectedFacetOptionsBreadbox/selectedFacetOptionsBreadbox.html";
            this.restrict = 'E'; // E = element, A = attribute, C = class, M = comment    
            this.scope = {
                breadboxSrv: '=',
                breadcrumbsSrv: '='
            };
            SelectedFacetOptionsBreadbox.prototype.link = function (scope, element, attr) {
            };
        }
        SelectedFacetOptionsBreadbox.Factory = function () {
            var directive = function () {
                return new SelectedFacetOptionsBreadbox();
            };
            return directive;
        };
        return SelectedFacetOptionsBreadbox;
    }());
    exports.SelectedFacetOptionsBreadbox = SelectedFacetOptionsBreadbox;
});
//# sourceMappingURL=selectedFacetOptionsBreadbox.directive.js.map