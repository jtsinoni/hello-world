'use strict';

import {FacetOption} from "../../../_models/facetOption.model";
import {SearchConstants} from "../../../_constants/search.constants";

export class BaseSelectedFacetOptionsService {

    public selectedFacetOptions: Array<FacetOption> = [];

    // this module (for event purposes)
    public eventModule: string = SearchConstants.EVENT_MODULE_BASE;

    // @ngInject
    constructor(private $log, private $state, private $rootScope,
                private CategoryBreadcrumbsService, private FacetsService,
                private SearchUtilService, private StateConstants) {
    }

    public getSelectedFacetOptions(): Array<FacetOption> {
        this.SearchUtilService.sortByCriteria(this.selectedFacetOptions, ["type", "value"]);
        return this.selectedFacetOptions;
    }

    public clearAllClicked() {
        this.clearAllSelectedFacetOptions();
        this.CategoryBreadcrumbsService.clearAllBreadcrumbs();
        this.executeSearch()
    }

    public clearAllSelectedFacetOptions() {
        this.clearFilteringMatchTextFromAllFacets();
        this.clearAllSelectedOptionsFromFacetOptions();

        this.clearSelectedFacetOptions();
        this.goToSearchSummaryResults();
    }

    private clearAllSelectedOptionsFromFacetOptions() {
        let selectedFacetOptions: Array<FacetOption> = this.getSelectedFacetOptions();

        // for each selected facet option
        for (let i: number = 0; i < selectedFacetOptions.length; i++) {

            let eventId = this.SearchUtilService.buildEventId(
                this.eventModule,
                selectedFacetOptions[i].type + SearchConstants.EVENT_TARGET_COMPONENT_FACET,
                SearchConstants.EVENT_TARGET_METHOD_CLEAR_SELECTED_FACET_OPTION);

            this.$log.debug("emit " + eventId + " event");
            this.$rootScope.$emit(eventId, selectedFacetOptions[i]);
        }
    }

    private clearFilteringMatchTextFromAllFacets() {
        angular.forEach(this.FacetsService.getFacets(), (facet) => {
            let eventId = this.SearchUtilService.buildEventId(
                this.eventModule,
                facet.facetConfiguration.displayLabel + SearchConstants.EVENT_TARGET_COMPONENT_FACET,
                SearchConstants.EVENT_TARGET_METHOD_CLEAR_FILTERING_MATCH_STRING);

            this.$log.debug("emit " + eventId + " event");
            this.$rootScope.$emit(eventId);
        });
    }

    public clearSelectedFacetOptions() {
        this.selectedFacetOptions = [];
    }


    private clearSelectedFacetOption(selectedOption) {
        this.clearSelectedOptionFromFacetOptions(selectedOption);
        this.removeSelectedFacetOption(selectedOption);
    }

    private clearSelectedOptionFromFacetOptions(selectedOption) {
        let eventId = this.SearchUtilService.buildEventId(
            this.eventModule,
            selectedOption.type + SearchConstants.EVENT_TARGET_COMPONENT_FACET,
            SearchConstants.EVENT_TARGET_METHOD_CLEAR_SELECTED_FACET_OPTION);

        this.$log.debug("emit " + eventId + " event");
        this.$rootScope.$emit(eventId, selectedOption);
    }

    public init() {
        let removeSelectedFacetOptionEventId = this.SearchUtilService.buildEventId(
            this.eventModule,
            SearchConstants.EVENT_TARGET_COMPONENT_SELECTED_FACET_OPTIONS_BREADBOX,
            SearchConstants.EVENT_TARGET_METHOD_REMOVE_SELECTED_FACET_OPTION);

        let removeSelectedFacetOptionEventHandler = this.$rootScope.$on(removeSelectedFacetOptionEventId, (event: ng.IAngularEvent, data: FacetOption) => {
            // this.$log.debug("caught " + removeSelectedFacetOptionEventId + " event");
            this.removeSelectedFacetOption(data);
        });
        this.$rootScope.$on('$destroy', function () {
            removeSelectedFacetOptionEventHandler();
        });

        let updateSelectedFacetOptionsEventId = this.SearchUtilService.buildEventId(
            this.eventModule,
            SearchConstants.EVENT_TARGET_COMPONENT_SELECTED_FACET_OPTIONS_BREADBOX,
            SearchConstants.EVENT_TARGET_METHOD_UPDATE_SELECTED_FACET_OPTIONS);

        let updateSelectedFacetOptionsEventHandler = this.$rootScope.$on(updateSelectedFacetOptionsEventId, (event: ng.IAngularEvent, data: FacetOption) => {
            // this.$log.debug("caught " + updateSelectedFacetOptionsEventId + " event");
            this.updateSelectedFacetOptions(data);
        });
        this.$rootScope.$on('$destroy', function () {
            updateSelectedFacetOptionsEventHandler();
        });

        let clearAllSelectedFacetOptionsEventId = this.SearchUtilService.buildEventId(
            this.eventModule,
            SearchConstants.EVENT_TARGET_COMPONENT_SELECTED_FACET_OPTIONS_BREADBOX,
            SearchConstants.EVENT_TARGET_METHOD_CLEAR_ALL_SELECTED_FACET_OPTIONS);

        let clearAllSelectedFacetOptionsEventHandler = this.$rootScope.$on(clearAllSelectedFacetOptionsEventId, (event: ng.IAngularEvent) => {
            // this.$log.debug("caught " + clearAllSelectedFacetOptionsEventId + " event");
            this.clearSelectedFacetOptions();
        });
        this.$rootScope.$on('$destroy', function () {
            clearAllSelectedFacetOptionsEventHandler();
        });
    }

    public executeSearch() {
        this.SearchUtilService.executeSearch(this.eventModule, null);
    }

    public removeSelectedFacetOption(facetOption: FacetOption) {
        this.$log.debug("removeSelectedFacetOption - facetOption: %s", JSON.stringify(facetOption));
        for (let i: number = 0; i < this.getSelectedFacetOptions().length; i++) {
            if (this.selectedFacetOptions[i].type === facetOption.type
                && this.selectedFacetOptions[i].value === facetOption.value) {
                this.selectedFacetOptions.splice(i, 1);
            }
        }
    }

    public updateSelectedFacetOptions(facetOption: FacetOption) {
        this.$log.debug("updateSelectedFacetOptions - facetOption: %s", JSON.stringify(facetOption));
        if (facetOption.selected) {
            // add facet value to selectedFacetOptions array
            this.selectedFacetOptions.push({
                type: facetOption.type,
                value: facetOption.value,
                count: facetOption.count,
                selected: facetOption.selected
            });
        } else { // FacetOption.selected === false
            this.removeSelectedFacetOption(facetOption);
        }
    }

    public goToSearchSummaryResults() {
        this.$state.go(this.StateConstants.ABI_SEARCH);
    }
}