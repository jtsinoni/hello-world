define(["require", "exports", "../../../_constants/search.constants"], function (require, exports, search_constants_1) {
    'use strict';
    var BaseSelectedFacetOptionsService = (function () {
        // @ngInject
        function BaseSelectedFacetOptionsService($log, $state, $rootScope, CategoryBreadcrumbsService, FacetsService, SearchUtilService, StateConstants) {
            this.$log = $log;
            this.$state = $state;
            this.$rootScope = $rootScope;
            this.CategoryBreadcrumbsService = CategoryBreadcrumbsService;
            this.FacetsService = FacetsService;
            this.SearchUtilService = SearchUtilService;
            this.StateConstants = StateConstants;
            this.selectedFacetOptions = [];
            // this module (for event purposes)
            this.eventModule = search_constants_1.SearchConstants.EVENT_MODULE_BASE;
        }
        BaseSelectedFacetOptionsService.prototype.getSelectedFacetOptions = function () {
            this.SearchUtilService.sortByCriteria(this.selectedFacetOptions, ["type", "value"]);
            return this.selectedFacetOptions;
        };
        BaseSelectedFacetOptionsService.prototype.clearAllClicked = function () {
            this.clearAllSelectedFacetOptions();
            this.CategoryBreadcrumbsService.clearAllBreadcrumbs();
            this.executeSearch();
        };
        BaseSelectedFacetOptionsService.prototype.clearAllSelectedFacetOptions = function () {
            this.clearFilteringMatchTextFromAllFacets();
            this.clearAllSelectedOptionsFromFacetOptions();
            this.clearSelectedFacetOptions();
            this.goToSearchSummaryResults();
        };
        BaseSelectedFacetOptionsService.prototype.clearAllSelectedOptionsFromFacetOptions = function () {
            var selectedFacetOptions = this.getSelectedFacetOptions();
            // for each selected facet option
            for (var i = 0; i < selectedFacetOptions.length; i++) {
                var eventId = this.SearchUtilService.buildEventId(this.eventModule, selectedFacetOptions[i].type + search_constants_1.SearchConstants.EVENT_TARGET_COMPONENT_FACET, search_constants_1.SearchConstants.EVENT_TARGET_METHOD_CLEAR_SELECTED_FACET_OPTION);
                this.$log.debug("emit " + eventId + " event");
                this.$rootScope.$emit(eventId, selectedFacetOptions[i]);
            }
        };
        BaseSelectedFacetOptionsService.prototype.clearFilteringMatchTextFromAllFacets = function () {
            var _this = this;
            angular.forEach(this.FacetsService.getFacets(), function (facet) {
                var eventId = _this.SearchUtilService.buildEventId(_this.eventModule, facet.facetConfiguration.displayLabel + search_constants_1.SearchConstants.EVENT_TARGET_COMPONENT_FACET, search_constants_1.SearchConstants.EVENT_TARGET_METHOD_CLEAR_FILTERING_MATCH_STRING);
                _this.$log.debug("emit " + eventId + " event");
                _this.$rootScope.$emit(eventId);
            });
        };
        BaseSelectedFacetOptionsService.prototype.clearSelectedFacetOptions = function () {
            this.selectedFacetOptions = [];
        };
        BaseSelectedFacetOptionsService.prototype.clearSelectedFacetOption = function (selectedOption) {
            this.clearSelectedOptionFromFacetOptions(selectedOption);
            this.removeSelectedFacetOption(selectedOption);
        };
        BaseSelectedFacetOptionsService.prototype.clearSelectedOptionFromFacetOptions = function (selectedOption) {
            var eventId = this.SearchUtilService.buildEventId(this.eventModule, selectedOption.type + search_constants_1.SearchConstants.EVENT_TARGET_COMPONENT_FACET, search_constants_1.SearchConstants.EVENT_TARGET_METHOD_CLEAR_SELECTED_FACET_OPTION);
            this.$log.debug("emit " + eventId + " event");
            this.$rootScope.$emit(eventId, selectedOption);
        };
        BaseSelectedFacetOptionsService.prototype.init = function () {
            var _this = this;
            var removeSelectedFacetOptionEventId = this.SearchUtilService.buildEventId(this.eventModule, search_constants_1.SearchConstants.EVENT_TARGET_COMPONENT_SELECTED_FACET_OPTIONS_BREADBOX, search_constants_1.SearchConstants.EVENT_TARGET_METHOD_REMOVE_SELECTED_FACET_OPTION);
            var removeSelectedFacetOptionEventHandler = this.$rootScope.$on(removeSelectedFacetOptionEventId, function (event, data) {
                // this.$log.debug("caught " + removeSelectedFacetOptionEventId + " event");
                _this.removeSelectedFacetOption(data);
            });
            this.$rootScope.$on('$destroy', function () {
                removeSelectedFacetOptionEventHandler();
            });
            var updateSelectedFacetOptionsEventId = this.SearchUtilService.buildEventId(this.eventModule, search_constants_1.SearchConstants.EVENT_TARGET_COMPONENT_SELECTED_FACET_OPTIONS_BREADBOX, search_constants_1.SearchConstants.EVENT_TARGET_METHOD_UPDATE_SELECTED_FACET_OPTIONS);
            var updateSelectedFacetOptionsEventHandler = this.$rootScope.$on(updateSelectedFacetOptionsEventId, function (event, data) {
                // this.$log.debug("caught " + updateSelectedFacetOptionsEventId + " event");
                _this.updateSelectedFacetOptions(data);
            });
            this.$rootScope.$on('$destroy', function () {
                updateSelectedFacetOptionsEventHandler();
            });
            var clearAllSelectedFacetOptionsEventId = this.SearchUtilService.buildEventId(this.eventModule, search_constants_1.SearchConstants.EVENT_TARGET_COMPONENT_SELECTED_FACET_OPTIONS_BREADBOX, search_constants_1.SearchConstants.EVENT_TARGET_METHOD_CLEAR_ALL_SELECTED_FACET_OPTIONS);
            var clearAllSelectedFacetOptionsEventHandler = this.$rootScope.$on(clearAllSelectedFacetOptionsEventId, function (event) {
                // this.$log.debug("caught " + clearAllSelectedFacetOptionsEventId + " event");
                _this.clearSelectedFacetOptions();
            });
            this.$rootScope.$on('$destroy', function () {
                clearAllSelectedFacetOptionsEventHandler();
            });
        };
        BaseSelectedFacetOptionsService.prototype.executeSearch = function () {
            this.SearchUtilService.executeSearch(this.eventModule, null);
        };
        BaseSelectedFacetOptionsService.prototype.removeSelectedFacetOption = function (facetOption) {
            this.$log.debug("removeSelectedFacetOption - facetOption: %s", JSON.stringify(facetOption));
            for (var i = 0; i < this.getSelectedFacetOptions().length; i++) {
                if (this.selectedFacetOptions[i].type === facetOption.type
                    && this.selectedFacetOptions[i].value === facetOption.value) {
                    this.selectedFacetOptions.splice(i, 1);
                }
            }
        };
        BaseSelectedFacetOptionsService.prototype.updateSelectedFacetOptions = function (facetOption) {
            this.$log.debug("updateSelectedFacetOptions - facetOption: %s", JSON.stringify(facetOption));
            if (facetOption.selected) {
                // add facet value to selectedFacetOptions array
                this.selectedFacetOptions.push({
                    type: facetOption.type,
                    value: facetOption.value,
                    count: facetOption.count,
                    selected: facetOption.selected
                });
            }
            else {
                this.removeSelectedFacetOption(facetOption);
            }
        };
        BaseSelectedFacetOptionsService.prototype.goToSearchSummaryResults = function () {
            this.$state.go(this.StateConstants.ABI_SEARCH);
        };
        return BaseSelectedFacetOptionsService;
    }());
    exports.BaseSelectedFacetOptionsService = BaseSelectedFacetOptionsService;
});
//# sourceMappingURL=baseSelectedFacetOptions.service.js.map