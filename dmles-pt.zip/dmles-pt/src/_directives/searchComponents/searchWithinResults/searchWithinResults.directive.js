define(["require", "exports"], function (require, exports) {
    'use strict';
    var SearchWithinResults = (function () {
        // @ngInject
        function SearchWithinResults() {
            this.templateUrl = "src/_directives/searchComponents/searchWithinResults/searchWithinResults.html";
            this.restrict = 'E'; // E = element, A = attribute, C = class, M = comment    
            this.scope = {
                config: '='
            };
            SearchWithinResults.prototype.link = function (scope, element, attr) {
            };
        }
        SearchWithinResults.Factory = function () {
            var directive = function () {
                return new SearchWithinResults();
            };
            return directive;
        };
        return SearchWithinResults;
    }());
    exports.SearchWithinResults = SearchWithinResults;
});
//# sourceMappingURL=searchWithinResults.directive.js.map