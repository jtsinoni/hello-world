'use strict';

import {FacetOption} from "../../../_models/facetOption.model";
import {SearchConstants} from "../../../_constants/search.constants";

export class BaseSearchWithinResultsService {

    private keywordFacetOption: FacetOption = null;

    public searchWithinResultsInput: string = "";
    public searchWithinResultsKeywords: string[] = [];

    // this module (for event purposes)
    public eventModule: string = SearchConstants.EVENT_MODULE_BASE;

    // @ngInject
    constructor(private $log, private $rootScope, private SearchUtilService, private SelectedFacetOptionsBreadboxService) {
    }

    public addKeywordToSearchWithinResults(keyword: string) {
        if (keyword !== "") {
            if (keyword.length > 2) {
                keyword = '*' + keyword + '*';
            }
            this.searchWithinResultsKeywords.push(keyword);
            this.$log.debug("addKeywordToSearchWithinResults - this.searchWithinResultsKeywords: %s", JSON.stringify(this.searchWithinResultsKeywords));

            this.keywordFacetOption = {
                type: "Keyword", value: this.searchWithinResultsInput, count: 0, selected: true
            };

            // emit event telling Breadbox component to add this facet option to its displayed set
            this.updateSelectedFacetOptions(this.keywordFacetOption);

            this.SearchUtilService.executeSearch(this.eventModule, this.keywordFacetOption);
        }

        // reset input to blank
        this.searchWithinResultsInput = "";
    }

    public clearSelectedFacetOption(selectedOption) {
        this.$log.debug("clearSelectedFacetOption - selectedOption: %s", JSON.stringify(selectedOption));
        this.$log.debug("before - this.searchWithinResultsKeywords: %s", JSON.stringify(this.searchWithinResultsKeywords));

        for (let i: number = 0; i < this.searchWithinResultsKeywords.length; i++) {
            if (this.searchWithinResultsKeywords[i] === selectedOption.value || this.searchWithinResultsKeywords[i] === '*' + selectedOption.value + '*') {
                this.searchWithinResultsKeywords.splice(i, 1);
                break;
            }
        }

        this.$log.debug("after - this.searchWithinResultsKeywords: %s", JSON.stringify(this.searchWithinResultsKeywords));
    }

    public init() {
        // listening here for an event targeted specifically to this Keyword "Facet" instance
        let clearSelectedFacetOptionEventId: string = this.SearchUtilService.buildEventId(
            this.eventModule,
            "Keyword" + SearchConstants.EVENT_TARGET_COMPONENT_FACET,
            SearchConstants.EVENT_TARGET_METHOD_CLEAR_SELECTED_FACET_OPTION);

        let clearSelectedFacetOptionEventHandler = this.$rootScope.$on(clearSelectedFacetOptionEventId, (event: ng.IAngularEvent, data: FacetOption) => {
            // this.$log.debug("caught " + clearSelectedFacetOptionEventId + " event");
            this.clearSelectedFacetOption(data);
        });
        this.$rootScope.$on('$destroy', function () {
            clearSelectedFacetOptionEventHandler();
        });
    }

    public getSearchWithinResultsKeywords(): string[] {
        return this.searchWithinResultsKeywords;
    }

    public updateSelectedFacetOptions(facetOption: FacetOption) {
        this.SelectedFacetOptionsBreadboxService.updateSelectedFacetOptions(facetOption);
    }
}