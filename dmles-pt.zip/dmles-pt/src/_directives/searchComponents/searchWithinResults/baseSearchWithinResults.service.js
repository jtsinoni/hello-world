define(["require", "exports", "../../../_constants/search.constants"], function (require, exports, search_constants_1) {
    'use strict';
    var BaseSearchWithinResultsService = (function () {
        // @ngInject
        function BaseSearchWithinResultsService($log, $rootScope, SearchUtilService, SelectedFacetOptionsBreadboxService) {
            this.$log = $log;
            this.$rootScope = $rootScope;
            this.SearchUtilService = SearchUtilService;
            this.SelectedFacetOptionsBreadboxService = SelectedFacetOptionsBreadboxService;
            this.keywordFacetOption = null;
            this.searchWithinResultsInput = "";
            this.searchWithinResultsKeywords = [];
            // this module (for event purposes)
            this.eventModule = search_constants_1.SearchConstants.EVENT_MODULE_BASE;
        }
        BaseSearchWithinResultsService.prototype.addKeywordToSearchWithinResults = function (keyword) {
            if (keyword !== "") {
                if (keyword.length > 2) {
                    keyword = '*' + keyword + '*';
                }
                this.searchWithinResultsKeywords.push(keyword);
                this.$log.debug("addKeywordToSearchWithinResults - this.searchWithinResultsKeywords: %s", JSON.stringify(this.searchWithinResultsKeywords));
                this.keywordFacetOption = {
                    type: "Keyword", value: this.searchWithinResultsInput, count: 0, selected: true
                };
                // emit event telling Breadbox component to add this facet option to its displayed set
                this.updateSelectedFacetOptions(this.keywordFacetOption);
                this.SearchUtilService.executeSearch(this.eventModule, this.keywordFacetOption);
            }
            // reset input to blank
            this.searchWithinResultsInput = "";
        };
        BaseSearchWithinResultsService.prototype.clearSelectedFacetOption = function (selectedOption) {
            this.$log.debug("clearSelectedFacetOption - selectedOption: %s", JSON.stringify(selectedOption));
            this.$log.debug("before - this.searchWithinResultsKeywords: %s", JSON.stringify(this.searchWithinResultsKeywords));
            for (var i = 0; i < this.searchWithinResultsKeywords.length; i++) {
                if (this.searchWithinResultsKeywords[i] === selectedOption.value || this.searchWithinResultsKeywords[i] === '*' + selectedOption.value + '*') {
                    this.searchWithinResultsKeywords.splice(i, 1);
                    break;
                }
            }
            this.$log.debug("after - this.searchWithinResultsKeywords: %s", JSON.stringify(this.searchWithinResultsKeywords));
        };
        BaseSearchWithinResultsService.prototype.init = function () {
            var _this = this;
            // listening here for an event targeted specifically to this Keyword "Facet" instance
            var clearSelectedFacetOptionEventId = this.SearchUtilService.buildEventId(this.eventModule, "Keyword" + search_constants_1.SearchConstants.EVENT_TARGET_COMPONENT_FACET, search_constants_1.SearchConstants.EVENT_TARGET_METHOD_CLEAR_SELECTED_FACET_OPTION);
            var clearSelectedFacetOptionEventHandler = this.$rootScope.$on(clearSelectedFacetOptionEventId, function (event, data) {
                // this.$log.debug("caught " + clearSelectedFacetOptionEventId + " event");
                _this.clearSelectedFacetOption(data);
            });
            this.$rootScope.$on('$destroy', function () {
                clearSelectedFacetOptionEventHandler();
            });
        };
        BaseSearchWithinResultsService.prototype.getSearchWithinResultsKeywords = function () {
            return this.searchWithinResultsKeywords;
        };
        BaseSearchWithinResultsService.prototype.updateSelectedFacetOptions = function (facetOption) {
            this.SelectedFacetOptionsBreadboxService.updateSelectedFacetOptions(facetOption);
        };
        return BaseSearchWithinResultsService;
    }());
    exports.BaseSearchWithinResultsService = BaseSearchWithinResultsService;
});
//# sourceMappingURL=baseSearchWithinResults.service.js.map