export class SearchInputController {
    private controllerName:string = "SearchInputController Directive";

    // Passed in from the directive
    public searchInputData:string;
    public searchPlaceholder:string;

    //@inject
    constructor(private $log, private $scope) {
        this.$log.debug('%s - Start', this.controllerName);
    }

    public executeSearch(){
        this.$log.debug("%s - Search criteria: %s", this.controllerName, this.searchInputData);
        this.$scope.executeSearch({ searchCriteria : this.searchInputData });  // Calls parent controller search
    }

}