define(["require", "exports"], function (require, exports) {
    'use strict';
    var Facet = (function () {
        function Facet() {
            this.templateUrl = "src/_directives/searchComponents/facet/facet.html";
            this.restrict = 'E'; // E = element, A = attribute, C = class, M = comment
            this.scope = {
                config: '='
            };
            Facet.prototype.link = function (scope, element, attr) {
            };
        }
        Facet.Factory = function () {
            var directive = function () {
                return new Facet();
            };
            return directive;
        };
        return Facet;
    }());
    exports.Facet = Facet;
});
//# sourceMappingURL=facet.directive.js.map