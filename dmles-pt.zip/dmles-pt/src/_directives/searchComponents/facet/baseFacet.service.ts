'use strict';

import {FacetConfiguration} from "../../../_models/facetConfiguration.model";
import {FacetOption} from "../../../_models/facetOption.model";
import {SearchConstants} from "../../../_constants/search.constants";

export class BaseFacetService {
    public facetConfiguration: FacetConfiguration;

    // the options (values) associated with the Facet instance
    public facetOptions: Array<FacetOption> = [];
    public facetOptionsWithNonZeroCounts: Array<FacetOption> = [];

    // used to filter the displayed facet options to only those that match (contain) the text string
    public matchText: string = "";

    // the current state of whether the facet is expanded or collapsed
    public collapseFacet: boolean = false;

    // used to calculate the current height of the facet
    public heightPerFacetOptionDisplayed: number = 20;
    public maxFacetOptionsDisplayed: number = 10;
    public minFacetOptionsDisplayed: number = 0;
    public facetOptionsDisplayed: number = this.maxFacetOptionsDisplayed;
    public facetOptionMaxStringLength: number = 50;
    public height: any = {
        "height": (this.maxFacetOptionsDisplayed * this.heightPerFacetOptionDisplayed) + "px"
    };

    public lastFacetOptionUpdated: FacetOption = null;
    public haveFacetOptionCountsBeenUpdated: boolean = false;

    // this module (for event purposes)
    public eventModule: string = SearchConstants.EVENT_MODULE_BASE;

    // @ngInject
    constructor(private $log, private $rootScope, facetConfiguration: FacetConfiguration,
                private SearchUtilService) {

        this.facetConfiguration = facetConfiguration;
    }

    public buildSearchClause(elasticSearchFieldName: string): string {
       
        let returnValue: string = "";

        // build selectedOptions
        let selectedOptions = [];
        let n: string;
        for (n in this.facetOptions) {
            if (this.facetOptions[n].selected === true) {
                let facetOption = this.facetOptions[n];
                selectedOptions.push(facetOption);
            }
        }

        let i: number = 0;
        for (i = 0; i < selectedOptions.length; i++) {
            if (i > 0) {
                returnValue = returnValue + " OR ";
            }
            if (selectedOptions[i].value !== "") {
                // escape special characters that might be embedded in DMLSS/DML-ES data
                // not doing this causes issues for elasticsearch
                returnValue = returnValue
                    + elasticSearchFieldName + ".keyword"
                    + " EQ "
                    + "'"
                    + selectedOptions[i].value.replace(/[!@#$%^&()+=\-[\]\\';,./{}|":<>?~_]/g, "\\$&")
                    + "'";
            }
        }

        if (returnValue) {
            returnValue = "(" + returnValue + ")";
            returnValue = "AND " + returnValue;
        }

        // this.$log.debug("returnValue: %s", JSON.stringify(returnValue));
        return returnValue;
    }

    public calculateHeight(): any {
        // calculate height
        if (this.collapseFacet === true) {
            // the facet is CLOSED
            this.facetOptionsDisplayed = this.minFacetOptionsDisplayed;
        } else {
            // the facet is OPEN
            if (this.facetOptionsWithNonZeroCounts.length >= this.maxFacetOptionsDisplayed) {
                this.facetOptionsDisplayed = this.maxFacetOptionsDisplayed;
            } else {
                this.facetOptionsDisplayed = this.facetOptionsWithNonZeroCounts.length;
                for (let i: number = 0; i < this.facetOptionsWithNonZeroCounts.length; i++) {
                    if (this.facetOptionsWithNonZeroCounts[i].value.length > this.facetOptionMaxStringLength) {
                        this.facetOptionsDisplayed += 1;
                    }
                }
            }
        }
        this.height = {
            "height": (this.facetOptionsDisplayed * this.heightPerFacetOptionDisplayed) + "px"
        };

        //this.$log.debug("facetOptionsWithNonZeroCounts: %s", JSON.stringify(facetOptionsWithNonZeroCounts));
        //this.$log.debug("this.height: %s", JSON.stringify(this.height));
        return this.height;
    }

    private clearAllSelectedFacetOptions() {
        // when we clear all selected facet options, also clear the matchText used to filter the facet
        this.matchText = "";

        for (let i: number = 0; i < this.facetOptions.length; i++) {
            if (this.facetOptions[i].selected) {
                this.facetOptions[i].selected = false;

                this.lastFacetOptionUpdated = this.facetOptions[i];

                this.$rootScope.$emit(
                    this.SearchUtilService.buildEventId(
                        this.eventModule,
                        SearchConstants.EVENT_TARGET_COMPONENT_SELECTED_FACET_OPTIONS_BREADBOX,
                        SearchConstants.EVENT_TARGET_METHOD_REMOVE_SELECTED_FACET_OPTION), this.facetOptions[i]);
            }
        }
        this.haveFacetOptionCountsBeenUpdated = false;
    }

    private clearFilteringMatchString() {
        this.matchText = "";
    }

    public clearSelectedFacetOption(selectedOption) {
        this.$log.debug("clearSelectedFacetOption - selectedOption: %s", JSON.stringify(selectedOption));

        for (let i: number = 0; i < this.facetOptions.length; i++) {
            if (this.facetOptions[i].value === selectedOption.value) {
                this.facetOptions[i].selected = false;
                this.$log.debug("clearing this selectedOption: %s", JSON.stringify(this.facetOptions[i]));
                break;
            }
        }
    }

    public clearSelectedFacetOptionsWithZeroCounts() {
        for (let n in this.facetOptions) {
            if (this.facetOptions[n].selected && this.facetOptions[n].count === 0) {
                this.facetOptions[n].selected = false;

                this.lastFacetOptionUpdated = this.facetOptions[n];

                this.$rootScope.$emit(
                    this.SearchUtilService.buildEventId(
                        this.eventModule,
                        SearchConstants.EVENT_TARGET_COMPONENT_SELECTED_FACET_OPTIONS_BREADBOX,
                        SearchConstants.EVENT_TARGET_METHOD_REMOVE_SELECTED_FACET_OPTION), this.facetOptions[n]);
            }
        }
    }

    public determineFacetOptionsWithNonZeroCounts() {
        // re-initialize
        this.facetOptionsWithNonZeroCounts = [];
        let j: number = 0;
        for (let i: number = 0; i < this.facetOptions.length; i++) {
            if (this.facetOptions[i].count) {
                this.facetOptionsWithNonZeroCounts[j++] = this.facetOptions[i];
            }
        }

        /***
         if (this.facetOptionsWithNonZeroCounts.length === 1) {
            this.$log.debug("this.facetOptionsWithNonZeroCounts is suppressed because it only contains one facet option: %s",
                JSON.stringify(this.facetOptionsWithNonZeroCounts));
        }
         ***/
    }

    public getNumberOfFacetOptionsWithNonZeroCounts(): number {
        this.determineFacetOptionsWithNonZeroCounts();
        return this.facetOptionsWithNonZeroCounts.length;
    }

    public executeSearch() {
        this.SearchUtilService.executeSearch(this.eventModule, this.lastFacetOptionUpdated);
    }

    public init() {
        // listening here for an event targeted specifically to a Facet instance (i.e. to the ManufactureFacet)
        let clearSelectedFacetOptionEventId: string = this.SearchUtilService.buildEventId(
            this.eventModule,
            this.facetConfiguration.displayLabel + SearchConstants.EVENT_TARGET_COMPONENT_FACET,
            SearchConstants.EVENT_TARGET_METHOD_CLEAR_SELECTED_FACET_OPTION);

        let clearSelectedFacetOptionEventHandler = this.$rootScope.$on(clearSelectedFacetOptionEventId, (event: ng.IAngularEvent, data: FacetOption) => {
            // this.$log.debug("caught " + clearSelectedFacetOptionEventId + " event");
            this.clearSelectedFacetOption(data);
        });
        this.$rootScope.$on('$destroy', function () {
            clearSelectedFacetOptionEventHandler();
        });

        // listening here for an event targeted specifically to a Facet instance (i.e. to the ManufactureFacet)
        let clearFilteringMatchStringEventId: string = this.SearchUtilService.buildEventId(
            this.eventModule,
            this.facetConfiguration.displayLabel + SearchConstants.EVENT_TARGET_COMPONENT_FACET,
            SearchConstants.EVENT_TARGET_METHOD_CLEAR_FILTERING_MATCH_STRING);

        let clearFilteringMatchStringEventHandler = this.$rootScope.$on(clearFilteringMatchStringEventId, (event: ng.IAngularEvent) => {
            // this.$log.debug("caught " + clearFilteringMatchStringEventId + " event");
            this.clearFilteringMatchString();
        });
        this.$rootScope.$on('$destroy', function () {
            clearFilteringMatchStringEventHandler();
        });
    }

    public initialize() {
        this.facetOptions = [];
    }

    public isAnOptionSelected(): boolean {
        let returnValue: boolean = false;
        let n: string;
        for (n in this.facetOptions) {
            if (this.facetOptions[n].selected === true) {
                returnValue = true;
                break;
            }
        }
        return returnValue;
    }

    public populate(abiAggregations: any) {
        this.initialize();

        if (abiAggregations && abiAggregations[this.facetConfiguration.aggregationIdentifier] && abiAggregations[this.facetConfiguration.aggregationIdentifier].buckets) {
            let values = abiAggregations[this.facetConfiguration.aggregationIdentifier].buckets;
            for (let i in values) {
                let option: FacetOption = new FacetOption();
                option.type = this.facetConfiguration.displayLabel;
                option.value = values[i].key;
                option.count = values[i].doc_count;
                option.selected = false;
                this.facetOptions.push(option);
            }
        }
        this.haveFacetOptionCountsBeenUpdated = false;
    }

    public reset() {
        this.initialize();
    }

    public togglePanel() {
        this.collapseFacet = !this.collapseFacet;
    }

    public updateExistingFacetOptionCounts(abiAggregations: any) {
        if (abiAggregations && abiAggregations[this.facetConfiguration.aggregationIdentifier] && abiAggregations[this.facetConfiguration.aggregationIdentifier].buckets) {
            let values = abiAggregations[this.facetConfiguration.aggregationIdentifier].buckets;
            for (let n in this.facetOptions) {
                // reinitialize all facet option counts to 0
                this.facetOptions[n].count = 0;
            }
            // now update the counts for the existing facet options and add any newly found facet options
            for (let i in values) {
                for (let n in this.facetOptions) {
                    if (this.facetOptions[n].value === values[i].key) {
                        // update its count with results from latest aggregation
                        this.facetOptions[n].count = values[i].doc_count;
                        break;
                    }
                }
            }
            this.haveFacetOptionCountsBeenUpdated = true;
        }
    }

    public updateSelectedFacetOptions(facetOption: FacetOption) {
        this.lastFacetOptionUpdated = facetOption;
        this.SearchUtilService.updateSelectedFacetOptions(this.eventModule, facetOption);
    }
}