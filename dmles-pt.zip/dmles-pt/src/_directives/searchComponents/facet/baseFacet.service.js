define(["require", "exports", "../../../_models/facetOption.model", "../../../_constants/search.constants"], function (require, exports, facetOption_model_1, search_constants_1) {
    'use strict';
    var BaseFacetService = (function () {
        // @ngInject
        function BaseFacetService($log, $rootScope, facetConfiguration, SearchUtilService) {
            this.$log = $log;
            this.$rootScope = $rootScope;
            this.SearchUtilService = SearchUtilService;
            // the options (values) associated with the Facet instance
            this.facetOptions = [];
            this.facetOptionsWithNonZeroCounts = [];
            // used to filter the displayed facet options to only those that match (contain) the text string
            this.matchText = "";
            // the current state of whether the facet is expanded or collapsed
            this.collapseFacet = false;
            // used to calculate the current height of the facet
            this.heightPerFacetOptionDisplayed = 20;
            this.maxFacetOptionsDisplayed = 10;
            this.minFacetOptionsDisplayed = 0;
            this.facetOptionsDisplayed = this.maxFacetOptionsDisplayed;
            this.facetOptionMaxStringLength = 50;
            this.height = {
                "height": (this.maxFacetOptionsDisplayed * this.heightPerFacetOptionDisplayed) + "px"
            };
            this.lastFacetOptionUpdated = null;
            this.haveFacetOptionCountsBeenUpdated = false;
            // this module (for event purposes)
            this.eventModule = search_constants_1.SearchConstants.EVENT_MODULE_BASE;
            this.facetConfiguration = facetConfiguration;
        }
        BaseFacetService.prototype.buildSearchClause = function (elasticSearchFieldName) {
            var returnValue = "";
            // build selectedOptions
            var selectedOptions = [];
            var n;
            for (n in this.facetOptions) {
                if (this.facetOptions[n].selected === true) {
                    var facetOption = this.facetOptions[n];
                    selectedOptions.push(facetOption);
                }
            }
            var i = 0;
            for (i = 0; i < selectedOptions.length; i++) {
                if (i > 0) {
                    returnValue = returnValue + " OR ";
                }
                if (selectedOptions[i].value !== "") {
                    // escape special characters that might be embedded in DMLSS/DML-ES data
                    // not doing this causes issues for elasticsearch
                    returnValue = returnValue
                        + elasticSearchFieldName + ".keyword"
                        + " EQ "
                        + "'"
                        + selectedOptions[i].value.replace(/[!@#$%^&()+=\-[\]\\';,./{}|":<>?~_]/g, "\\$&")
                        + "'";
                }
            }
            if (returnValue) {
                returnValue = "(" + returnValue + ")";
                returnValue = "AND " + returnValue;
            }
            // this.$log.debug("returnValue: %s", JSON.stringify(returnValue));
            return returnValue;
        };
        BaseFacetService.prototype.calculateHeight = function () {
            // calculate height
            if (this.collapseFacet === true) {
                // the facet is CLOSED
                this.facetOptionsDisplayed = this.minFacetOptionsDisplayed;
            }
            else {
                // the facet is OPEN
                if (this.facetOptionsWithNonZeroCounts.length >= this.maxFacetOptionsDisplayed) {
                    this.facetOptionsDisplayed = this.maxFacetOptionsDisplayed;
                }
                else {
                    this.facetOptionsDisplayed = this.facetOptionsWithNonZeroCounts.length;
                    for (var i = 0; i < this.facetOptionsWithNonZeroCounts.length; i++) {
                        if (this.facetOptionsWithNonZeroCounts[i].value.length > this.facetOptionMaxStringLength) {
                            this.facetOptionsDisplayed += 1;
                        }
                    }
                }
            }
            this.height = {
                "height": (this.facetOptionsDisplayed * this.heightPerFacetOptionDisplayed) + "px"
            };
            //this.$log.debug("facetOptionsWithNonZeroCounts: %s", JSON.stringify(facetOptionsWithNonZeroCounts));
            //this.$log.debug("this.height: %s", JSON.stringify(this.height));
            return this.height;
        };
        BaseFacetService.prototype.clearAllSelectedFacetOptions = function () {
            // when we clear all selected facet options, also clear the matchText used to filter the facet
            this.matchText = "";
            for (var i = 0; i < this.facetOptions.length; i++) {
                if (this.facetOptions[i].selected) {
                    this.facetOptions[i].selected = false;
                    this.lastFacetOptionUpdated = this.facetOptions[i];
                    this.$rootScope.$emit(this.SearchUtilService.buildEventId(this.eventModule, search_constants_1.SearchConstants.EVENT_TARGET_COMPONENT_SELECTED_FACET_OPTIONS_BREADBOX, search_constants_1.SearchConstants.EVENT_TARGET_METHOD_REMOVE_SELECTED_FACET_OPTION), this.facetOptions[i]);
                }
            }
            this.haveFacetOptionCountsBeenUpdated = false;
        };
        BaseFacetService.prototype.clearFilteringMatchString = function () {
            this.matchText = "";
        };
        BaseFacetService.prototype.clearSelectedFacetOption = function (selectedOption) {
            this.$log.debug("clearSelectedFacetOption - selectedOption: %s", JSON.stringify(selectedOption));
            for (var i = 0; i < this.facetOptions.length; i++) {
                if (this.facetOptions[i].value === selectedOption.value) {
                    this.facetOptions[i].selected = false;
                    this.$log.debug("clearing this selectedOption: %s", JSON.stringify(this.facetOptions[i]));
                    break;
                }
            }
        };
        BaseFacetService.prototype.clearSelectedFacetOptionsWithZeroCounts = function () {
            for (var n in this.facetOptions) {
                if (this.facetOptions[n].selected && this.facetOptions[n].count === 0) {
                    this.facetOptions[n].selected = false;
                    this.lastFacetOptionUpdated = this.facetOptions[n];
                    this.$rootScope.$emit(this.SearchUtilService.buildEventId(this.eventModule, search_constants_1.SearchConstants.EVENT_TARGET_COMPONENT_SELECTED_FACET_OPTIONS_BREADBOX, search_constants_1.SearchConstants.EVENT_TARGET_METHOD_REMOVE_SELECTED_FACET_OPTION), this.facetOptions[n]);
                }
            }
        };
        BaseFacetService.prototype.determineFacetOptionsWithNonZeroCounts = function () {
            // re-initialize
            this.facetOptionsWithNonZeroCounts = [];
            var j = 0;
            for (var i = 0; i < this.facetOptions.length; i++) {
                if (this.facetOptions[i].count) {
                    this.facetOptionsWithNonZeroCounts[j++] = this.facetOptions[i];
                }
            }
            /***
             if (this.facetOptionsWithNonZeroCounts.length === 1) {
                this.$log.debug("this.facetOptionsWithNonZeroCounts is suppressed because it only contains one facet option: %s",
                    JSON.stringify(this.facetOptionsWithNonZeroCounts));
            }
             ***/
        };
        BaseFacetService.prototype.getNumberOfFacetOptionsWithNonZeroCounts = function () {
            this.determineFacetOptionsWithNonZeroCounts();
            return this.facetOptionsWithNonZeroCounts.length;
        };
        BaseFacetService.prototype.executeSearch = function () {
            this.SearchUtilService.executeSearch(this.eventModule, this.lastFacetOptionUpdated);
        };
        BaseFacetService.prototype.init = function () {
            var _this = this;
            // listening here for an event targeted specifically to a Facet instance (i.e. to the ManufactureFacet)
            var clearSelectedFacetOptionEventId = this.SearchUtilService.buildEventId(this.eventModule, this.facetConfiguration.displayLabel + search_constants_1.SearchConstants.EVENT_TARGET_COMPONENT_FACET, search_constants_1.SearchConstants.EVENT_TARGET_METHOD_CLEAR_SELECTED_FACET_OPTION);
            var clearSelectedFacetOptionEventHandler = this.$rootScope.$on(clearSelectedFacetOptionEventId, function (event, data) {
                // this.$log.debug("caught " + clearSelectedFacetOptionEventId + " event");
                _this.clearSelectedFacetOption(data);
            });
            this.$rootScope.$on('$destroy', function () {
                clearSelectedFacetOptionEventHandler();
            });
            // listening here for an event targeted specifically to a Facet instance (i.e. to the ManufactureFacet)
            var clearFilteringMatchStringEventId = this.SearchUtilService.buildEventId(this.eventModule, this.facetConfiguration.displayLabel + search_constants_1.SearchConstants.EVENT_TARGET_COMPONENT_FACET, search_constants_1.SearchConstants.EVENT_TARGET_METHOD_CLEAR_FILTERING_MATCH_STRING);
            var clearFilteringMatchStringEventHandler = this.$rootScope.$on(clearFilteringMatchStringEventId, function (event) {
                // this.$log.debug("caught " + clearFilteringMatchStringEventId + " event");
                _this.clearFilteringMatchString();
            });
            this.$rootScope.$on('$destroy', function () {
                clearFilteringMatchStringEventHandler();
            });
        };
        BaseFacetService.prototype.initialize = function () {
            this.facetOptions = [];
        };
        BaseFacetService.prototype.isAnOptionSelected = function () {
            var returnValue = false;
            var n;
            for (n in this.facetOptions) {
                if (this.facetOptions[n].selected === true) {
                    returnValue = true;
                    break;
                }
            }
            return returnValue;
        };
        BaseFacetService.prototype.populate = function (abiAggregations) {
            this.initialize();
            if (abiAggregations && abiAggregations[this.facetConfiguration.aggregationIdentifier] && abiAggregations[this.facetConfiguration.aggregationIdentifier].buckets) {
                var values = abiAggregations[this.facetConfiguration.aggregationIdentifier].buckets;
                for (var i in values) {
                    var option = new facetOption_model_1.FacetOption();
                    option.type = this.facetConfiguration.displayLabel;
                    option.value = values[i].key;
                    option.count = values[i].doc_count;
                    option.selected = false;
                    this.facetOptions.push(option);
                }
            }
            this.haveFacetOptionCountsBeenUpdated = false;
        };
        BaseFacetService.prototype.reset = function () {
            this.initialize();
        };
        BaseFacetService.prototype.togglePanel = function () {
            this.collapseFacet = !this.collapseFacet;
        };
        BaseFacetService.prototype.updateExistingFacetOptionCounts = function (abiAggregations) {
            if (abiAggregations && abiAggregations[this.facetConfiguration.aggregationIdentifier] && abiAggregations[this.facetConfiguration.aggregationIdentifier].buckets) {
                var values = abiAggregations[this.facetConfiguration.aggregationIdentifier].buckets;
                for (var n in this.facetOptions) {
                    // reinitialize all facet option counts to 0
                    this.facetOptions[n].count = 0;
                }
                // now update the counts for the existing facet options and add any newly found facet options
                for (var i in values) {
                    for (var n in this.facetOptions) {
                        if (this.facetOptions[n].value === values[i].key) {
                            // update its count with results from latest aggregation
                            this.facetOptions[n].count = values[i].doc_count;
                            break;
                        }
                    }
                }
                this.haveFacetOptionCountsBeenUpdated = true;
            }
        };
        BaseFacetService.prototype.updateSelectedFacetOptions = function (facetOption) {
            this.lastFacetOptionUpdated = facetOption;
            this.SearchUtilService.updateSelectedFacetOptions(this.eventModule, facetOption);
        };
        return BaseFacetService;
    }());
    exports.BaseFacetService = BaseFacetService;
});
//# sourceMappingURL=baseFacet.service.js.map