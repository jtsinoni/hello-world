define(["require", "exports", './searchInput.directive', "./searchInput.controller", './category/baseCategory.service', './category/category.directive', './categoryBreadcrumb/baseCategoryBreadcrumb.service', './categoryBreadcrumb/categoryBreadcrumb.directive', './facet/baseFacet.service', './facet/facet.directive', './searchWithinResults/baseSearchWithinResults.service', './searchWithinResults/searchWithinResults.directive', './selectedFacetOptionsBreadbox/baseSelectedFacetOptions.service', './selectedFacetOptionsBreadbox/selectedFacetOptionsBreadbox.directive'], function (require, exports, searchInput_directive_1, searchInput_controller_1, baseCategory_service_1, category_directive_1, baseCategoryBreadcrumb_service_1, categoryBreadcrumb_directive_1, baseFacet_service_1, facet_directive_1, baseSearchWithinResults_service_1, searchWithinResults_directive_1, baseSelectedFacetOptions_service_1, selectedFacetOptionsBreadbox_directive_1) {
    "use strict";
    var dmlesSearchComponentsModule = angular.module('DmlesSearchComponentsModule', []);
    dmlesSearchComponentsModule.directive('searchInput', searchInput_directive_1.SearchInput.Factory());
    dmlesSearchComponentsModule.controller('SearchInputController', searchInput_controller_1.SearchInputController);
    dmlesSearchComponentsModule.service('BaseCategoryService', baseCategory_service_1.BaseCategoryService);
    dmlesSearchComponentsModule.directive('category', category_directive_1.Category.Factory());
    dmlesSearchComponentsModule.service('BaseCategoryBreadcrumbService', baseCategoryBreadcrumb_service_1.BaseCategoryBreadcrumbService);
    dmlesSearchComponentsModule.directive('categoryBreadcrumb', categoryBreadcrumb_directive_1.CategoryBreadcrumb.Factory());
    dmlesSearchComponentsModule.service('BaseFacetService', baseFacet_service_1.BaseFacetService);
    dmlesSearchComponentsModule.directive('facet', facet_directive_1.Facet.Factory());
    dmlesSearchComponentsModule.service('BaseSearchWithinResultsService', baseSearchWithinResults_service_1.BaseSearchWithinResultsService);
    dmlesSearchComponentsModule.directive('searchWithinResults', searchWithinResults_directive_1.SearchWithinResults.Factory());
    dmlesSearchComponentsModule.service('BaseSelectedFacetOptionsService', baseSelectedFacetOptions_service_1.BaseSelectedFacetOptionsService);
    dmlesSearchComponentsModule.directive('selectedFacetOptionsBreadbox', selectedFacetOptionsBreadbox_directive_1.SelectedFacetOptionsBreadbox.Factory());
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = dmlesSearchComponentsModule;
});
//# sourceMappingURL=module.js.map