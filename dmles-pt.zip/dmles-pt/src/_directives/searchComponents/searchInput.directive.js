define(["require", "exports", "./searchInput.controller"], function (require, exports, searchInput_controller_1) {
    "use strict";
    var SearchInput = (function () {
        // @ngInject
        function SearchInput($log) {
            this.$log = $log;
            this.restrict = "EA";
            //public transclude: boolean = false;
            this.controller = searchInput_controller_1.SearchInputController;
            this.controllerAs = 'ctrl';
            this.templateUrl = "./src/_directives/searchComponents/searchInput.template.html";
            this.bindToController = {
                searchInputData: '=',
                searchPlaceholder: '@'
            };
            this.scope = {
                executeSearch: '&'
            };
        }
        SearchInput.Factory = function () {
            var directive = function ($log) { return new SearchInput($log); };
            directive.$inject = ['$log'];
            return directive;
        };
        return SearchInput;
    }());
    exports.SearchInput = SearchInput;
});
//# sourceMappingURL=searchInput.directive.js.map