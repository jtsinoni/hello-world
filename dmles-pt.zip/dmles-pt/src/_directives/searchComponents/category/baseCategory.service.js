define(["require", "exports", "../../../_models/categoryOption.model", "../../../_constants/search.constants"], function (require, exports, categoryOption_model_1, search_constants_1) {
    'use strict';
    var BaseCategoryService = (function () {
        // @ngInject
        function BaseCategoryService($log, $rootScope, categoryConfiguration, SearchUtilService) {
            this.$log = $log;
            this.$rootScope = $rootScope;
            this.SearchUtilService = SearchUtilService;
            // for now, handle a category with up to 10 levels
            this.categoryLevels = [[], [], [], [], [], [], [], [], [], []];
            // stores one selected category option per level
            // sent to breadcrumb component as event data each time a new category option is selected
            this.selectedCategoryOptions = [];
            // used to filter the displayed category options to only those that match (contain) the text string
            this.matchText = "";
            // the current state of whether the category is expanded or collapsed
            this.collapseCategory = false;
            // used to calculate the current height of the category
            this.heightPerCategoryOptionDisplayed = 17.4;
            this.maxCategoryOptionsDisplayed = 12;
            this.minCategoryOptionsDisplayed = 0;
            this.categoryOptionsDisplayed = this.maxCategoryOptionsDisplayed;
            this.height = {
                "height": (this.maxCategoryOptionsDisplayed * this.heightPerCategoryOptionDisplayed) + "px"
            };
            // this module (for event purposes)    
            this.eventModule = search_constants_1.SearchConstants.EVENT_MODULE_BASE;
            this.categoryConfiguration = categoryConfiguration;
        }
        BaseCategoryService.prototype.buildSelectedCategoryOptions = function () {
            var categoryLevels = this.categoryLevels;
            var foundSelectedCategoryOptionForThisLevel = false;
            // reinitialize
            this.selectedCategoryOptions = [];
            for (var i = 0; i < categoryLevels.length; i++) {
                var n = void 0;
                for (n in categoryLevels[i]) {
                    if (categoryLevels[i][n].isSelected === true) {
                        foundSelectedCategoryOptionForThisLevel = true;
                        break;
                    }
                }
                if (foundSelectedCategoryOptionForThisLevel) {
                    this.selectedCategoryOptions[i] = categoryLevels[i][n];
                    foundSelectedCategoryOptionForThisLevel = false;
                }
            }
        };
        BaseCategoryService.prototype.buildSearchClause = function (elasticSearchFieldNames) {
            var returnValue = "";
            var selectedCategoryOptions = [];
            // this.$log.debug("buildSearchClause() - this.categoryLevels: %s", JSON.stringify(this.categoryLevels));
            // Look through category levels for a selected category option
            for (var i = 0; i < elasticSearchFieldNames.length; i++) {
                var n = void 0;
                for (n in this.categoryLevels[i]) {
                    if (this.categoryLevels[i][n].isSelected === true) {
                        selectedCategoryOptions.push(this.categoryLevels[i][n]);
                    }
                }
            }
            // this.$log.debug("buildSearchClause() - selectedCategoryOptions: %s", JSON.stringify(selectedCategoryOptions));
            for (var i = 0; i < selectedCategoryOptions.length; i++) {
                if (i > 0) {
                    returnValue = returnValue + " AND ";
                }
                if (selectedCategoryOptions[i].optionValue !== "") {
                    // escape special characters that might be embedded in DMLSS/DML-ES data
                    // not doing this causes issues for elasticsearch
                    returnValue = returnValue
                        + elasticSearchFieldNames[selectedCategoryOptions[i].level] + ".keyword"
                        + " EQ "
                        + "'"
                        + selectedCategoryOptions[i].optionValue.replace(/[!@#$%^&()+=\-[\]\\';,./{}|":<>?~_]/g, "\\$&")
                        + "'";
                }
            }
            if (returnValue) {
                returnValue = "(" + returnValue + ")";
                returnValue = "AND " + returnValue;
            }
            this.$log.debug("buildSearchClause() - returnValue: %s", JSON.stringify(returnValue));
            return returnValue;
        };
        BaseCategoryService.prototype.calculateHeight = function () {
            // calculate height
            if (this.collapseCategory === true) {
                // the category is CLOSED
                this.categoryOptionsDisplayed = this.minCategoryOptionsDisplayed;
            }
            else {
                var numberOfCategoryLevelsSelected = this.selectedCategoryOptions.length;
                if (numberOfCategoryLevelsSelected === 0) {
                    if (this.categoryLevels[0].length >= this.maxCategoryOptionsDisplayed) {
                        this.categoryOptionsDisplayed = this.maxCategoryOptionsDisplayed;
                    }
                    else {
                        this.categoryOptionsDisplayed = this.categoryLevels[0].length;
                    }
                }
                else if (numberOfCategoryLevelsSelected === 1) {
                    if ((this.categoryLevels[0].length + this.categoryLevels[1].length) >= this.maxCategoryOptionsDisplayed) {
                        this.categoryOptionsDisplayed = this.maxCategoryOptionsDisplayed;
                    }
                    else {
                        this.categoryOptionsDisplayed = this.categoryLevels[0].length + this.categoryLevels[1].length;
                    }
                }
                else if (numberOfCategoryLevelsSelected === 2) {
                    if ((this.categoryLevels[0].length + this.categoryLevels[1].length + this.categoryLevels[2].length) >= this.maxCategoryOptionsDisplayed) {
                        this.categoryOptionsDisplayed = this.maxCategoryOptionsDisplayed;
                    }
                    else {
                        this.categoryOptionsDisplayed = this.categoryLevels[0].length + this.categoryLevels[1].length + this.categoryLevels[2].length;
                    }
                }
                else if (numberOfCategoryLevelsSelected === 3) {
                    if ((this.categoryLevels[0].length + this.categoryLevels[1].length + this.categoryLevels[2].length + this.categoryLevels[3].length) >= this.maxCategoryOptionsDisplayed) {
                        this.categoryOptionsDisplayed = this.maxCategoryOptionsDisplayed;
                    }
                    else {
                        this.categoryOptionsDisplayed = this.categoryLevels[0].length + this.categoryLevels[1].length + this.categoryLevels[2].length + this.categoryLevels[3].length;
                    }
                }
                else if (numberOfCategoryLevelsSelected === 4) {
                    if ((this.categoryLevels[0].length + this.categoryLevels[1].length + this.categoryLevels[2].length + this.categoryLevels[3].length + this.categoryLevels[4].length) >= this.maxCategoryOptionsDisplayed) {
                        this.categoryOptionsDisplayed = this.maxCategoryOptionsDisplayed;
                    }
                    else {
                        this.categoryOptionsDisplayed = this.categoryLevels[0].length + this.categoryLevels[1].length + this.categoryLevels[2].length + this.categoryLevels[3].length + this.categoryLevels[4].length;
                    }
                }
                else {
                    this.categoryOptionsDisplayed = this.maxCategoryOptionsDisplayed;
                }
            }
            this.height = {
                "height": (this.categoryOptionsDisplayed * this.heightPerCategoryOptionDisplayed) + "px"
            };
            //this.$log.debug("categoryOptionsWithNonZeroCounts: %s", JSON.stringify(categoryOptionsWithNonZeroCounts));
            //this.$log.debug("this.height: %s", JSON.stringify(this.height));
            return this.height;
        };
        BaseCategoryService.prototype.determineIndentation = function (level) {
            var returnValue = "";
            var fourSpaces = "\u00A0\u00A0\u00A0\u00A0";
            for (var i = 0; i < level; i++) {
                returnValue += fourSpaces;
            }
            return returnValue;
        };
        BaseCategoryService.prototype.init = function () {
            var _this = this;
            // listening here for an event targeted specifically to a Category instance (i.e. to the UNSPSC Taxonomy)
            var updateCategoryOptionSelectionsPerBreadcrumbClickEventId = this.SearchUtilService.buildEventId(this.eventModule, this.categoryConfiguration.displayLabel + search_constants_1.SearchConstants.EVENT_TARGET_COMPONENT_CATEGORY, search_constants_1.SearchConstants.EVENT_TARGET_METHOD_UPDATE_CATEGORY_OPTION_SELECTIONS_PER_BREADCRUMB_CLICK);
            var updateCategoryOptionSelectionsPerBreadcrumbClickEventHandler = this.$rootScope.$on(updateCategoryOptionSelectionsPerBreadcrumbClickEventId, function (event, data) {
                // this.$log.debug("caught " + updateCategoryOptionSelectionsPerBreadcrumbClickEventId + " event");
                _this.updateCategoryOptionSelectionsPerBreadcrumbClick(data);
            });
            this.$rootScope.$on('$destroy', function () {
                updateCategoryOptionSelectionsPerBreadcrumbClickEventHandler();
            });
            // listening here for an event targeted specifically to a Category instance (i.e. to the UNSPSC Taxonomy)
            var clearAllCategoryOptionSelectionsEventId = this.SearchUtilService.buildEventId(this.eventModule, this.categoryConfiguration.displayLabel + search_constants_1.SearchConstants.EVENT_TARGET_COMPONENT_CATEGORY, search_constants_1.SearchConstants.EVENT_TARGET_METHOD_CLEAR_ALL_CATEGORY_OPTION_SELECTIONS);
            var clearAllCategoryOptionSelectionsEventHandler = this.$rootScope.$on(clearAllCategoryOptionSelectionsEventId, function (event, data) {
                // this.$log.debug("caught " + clearAllCategoryOptionSelectionsEventId + " event");
                _this.clearAllCategoryOptionSelections(data);
            });
            this.$rootScope.$on('$destroy', function () {
                clearAllCategoryOptionSelectionsEventHandler();
            });
        };
        BaseCategoryService.prototype.initialize = function () {
            this.selectedCategoryOptions = [];
            this.categoryLevels = [[], [], [], [], [], [], [], [], [], []];
            // this.$log.debug("initialize() - this.categoryLevels: %s", JSON.stringify(this.categoryLevels));
            this.categoryLevels[0] = this.categoryConfiguration.topLevelInitialCategoryOptions;
            angular.forEach(this.categoryLevels[0], function (categoryOption) {
                categoryOption.isSelected = false;
            });
            this.matchText = "";
            // this.$log.debug("initialize() - this.categoryLevels[0]: %s", JSON.stringify(this.categoryLevels[0]));
        };
        BaseCategoryService.prototype.populate = function (category, numberOfCategoriesWithOptionsSelected, abiAggregations, numberOfSearchResults) {
            var categoryLevels = this.categoryLevels;
            var foundSelectedCategoryOption = false;
            this.$log.debug("BaseCategoryService populate() - this.selectedCategoryOptions: %s", JSON.stringify(this.selectedCategoryOptions));
            // Working from the one sub-level lower than the level with a selection - up the hierarchy
            for (var i = this.selectedCategoryOptions.length; i >= 0; i--) {
                var n = void 0;
                for (n in categoryLevels[i]) {
                    if (categoryLevels[i][n].isSelected === true) {
                        foundSelectedCategoryOption = true;
                        break;
                    }
                }
                // On a given level, if no category options are selected then we need to update them
                // with the appropriate aggregation from the latest search result
                if (!foundSelectedCategoryOption) {
                    // if we are handling a UNSPSC Segment and there are no search results, need to reinitialize
                    if (i === 0 && numberOfSearchResults === 0) {
                        this.$log.debug("Reinitializing the level 0 values");
                        this.initialize();
                    }
                    else {
                        // initialize the level's categoryLevels that we are going to update
                        categoryLevels[i] = [];
                        // this.$log.debug("abiAggregations: %s", JSON.stringify(abiAggregations));
                        if (abiAggregations && abiAggregations[category.categoryConfiguration.aggregationIdentifiers[i]] && abiAggregations[category.categoryConfiguration.aggregationIdentifiers[i]].buckets) {
                            var values = abiAggregations[category.categoryConfiguration.aggregationIdentifiers[i]].buckets;
                            // this.$log.debug("values: %s", JSON.stringify(values));
                            for (var j in values) {
                                var option = new categoryOption_model_1.CategoryOption();
                                option.optionValue = values[j].key;
                                option.isSelected = false;
                                option.level = i;
                                categoryLevels[i].push(option);
                            }
                        }
                        this.categoryLevels[i] = categoryLevels[i];
                    }
                }
                else {
                    // there is a selection on this level
                    if (numberOfCategoriesWithOptionsSelected > 1) {
                        // update the category option values on this level where there is a selection
                        // initialize the level's categoryLevels that we are going to update
                        categoryLevels[i] = [];
                        // this.$log.debug("abiAggregations: %s", JSON.stringify(abiAggregations));
                        if (abiAggregations && abiAggregations[category.categoryConfiguration.aggregationIdentifiers[i]] && abiAggregations[category.categoryConfiguration.aggregationIdentifiers[i]].buckets) {
                            var values = abiAggregations[category.categoryConfiguration.aggregationIdentifiers[i]].buckets;
                            // this.$log.debug("values: %s", JSON.stringify(values));
                            for (var j in values) {
                                var option = new categoryOption_model_1.CategoryOption();
                                option.optionValue = values[j].key;
                                if (option.optionValue === this.selectedCategoryOptions[i].optionValue) {
                                    option.isSelected = true;
                                }
                                else {
                                    option.isSelected = false;
                                }
                                option.level = i;
                                categoryLevels[i].push(option);
                            }
                        }
                        this.categoryLevels[i] = categoryLevels[i];
                        this.$log.debug("BaseCategoryService populate() - this.categoryLevels[i] = %s, i = %d", JSON.stringify(this.categoryLevels[i]), i);
                    }
                }
            }
        };
        BaseCategoryService.prototype.setGivenCategoryOptionsToNotSelected = function (categoryOptions) {
            for (var i = 0; i < categoryOptions.length; i++) {
                categoryOptions[i].isSelected = false;
            }
        };
        // there can only be one category option selected for a given level
        BaseCategoryService.prototype.setOptionValueAsOnlyOneSelectedInGivenCategoryOptions = function (categoryOptions, optionValue) {
            for (var i = 0; i < categoryOptions.length; i++) {
                if (optionValue === categoryOptions[i].optionValue) {
                    // toggle the current isSelected setting associated with optionValue
                    if (categoryOptions[i].isSelected === true) {
                        categoryOptions[i].isSelected = false;
                    }
                    else {
                        categoryOptions[i].isSelected = true;
                    }
                }
                else {
                    categoryOptions[i].isSelected = false;
                }
            }
        };
        // there can only be one category option selected for a given level
        // also reset all sub-category options to not selected
        BaseCategoryService.prototype.setSelectedCategoryOptionForGivenLevel = function (level, optionValue, executeSearch) {
            this.setOptionValueAsOnlyOneSelectedInGivenCategoryOptions(this.categoryLevels[level], optionValue);
            for (var i = level + 1; i < this.categoryConfiguration.aggregationIdentifiers.length; i++) {
                if (this.categoryLevels[i] !== []) {
                    this.setGivenCategoryOptionsToNotSelected(this.categoryLevels[i]);
                }
            }
            // update selected Category Options
            this.buildSelectedCategoryOptions();
            // emit event to the associated category breadcrumb component 
            // to tell it to update itself with the latest selectedCategoryOptions
            this.updateBreadcrumb();
            if (executeSearch) {
                // emit event to the search component to tell it to execute a search
                this.SearchUtilService.executeSearch(this.eventModule, null);
            }
        };
        BaseCategoryService.prototype.togglePanel = function () {
            this.collapseCategory = !this.collapseCategory;
        };
        BaseCategoryService.prototype.updateBreadcrumb = function () {
            var eventId = this.SearchUtilService.buildEventId(this.eventModule, this.categoryConfiguration.displayLabel + search_constants_1.SearchConstants.EVENT_TARGET_COMPONENT_CATEGORY_BREADCRUMB, search_constants_1.SearchConstants.EVENT_TARGET_METHOD_UPDATE_BREADCRUMB_PER_CATEGORY_OPTION_SELECTION);
            this.$log.debug("emit: %s", JSON.stringify(eventId));
            this.$rootScope.$emit(eventId, this.selectedCategoryOptions);
        };
        BaseCategoryService.prototype.updateCategoryOptionSelectionsPerBreadcrumbClick = function (categoryOption) {
            // we want the breadcrumb category option that was clicked to now be the lowest level category option selected
            // so we need to find the selected category option for the next level down and act like we clicked on it
            if (this.selectedCategoryOptions[categoryOption.level + 1]) {
                var relevantCategoryOption = this.selectedCategoryOptions[categoryOption.level + 1];
                // call function to unselect the relevantCategoryOption and all lower level options
                this.setSelectedCategoryOptionForGivenLevel(relevantCategoryOption.level, relevantCategoryOption.optionValue, true);
            }
        };
        BaseCategoryService.prototype.clearAllCategoryOptionSelections = function (executeSearch) {
            // reinitialize
            this.initialize();
            // emit event to the associated category breadcrumb component
            // to tell it to update itself with the latest selectedCategoryOptions
            this.updateBreadcrumb();
            // emit event to the search component to tell it to execute a search       
            if (executeSearch) {
                // emit event to the search component to tell it to execute a search
                this.SearchUtilService.executeSearch(this.eventModule, null);
            }
        };
        return BaseCategoryService;
    }());
    exports.BaseCategoryService = BaseCategoryService;
});
//# sourceMappingURL=baseCategory.service.js.map