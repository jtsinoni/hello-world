define(["require", "exports"], function (require, exports) {
    'use strict';
    var Category = (function () {
        function Category() {
            this.templateUrl = "src/_directives/searchComponents/category/category.html";
            this.restrict = 'E'; // E = element, A = attribute, C = class, M = comment
            this.scope = {
                config: '='
            };
            Category.prototype.link = function (scope, element, attr) {
            };
        }
        Category.Factory = function () {
            var directive = function () {
                return new Category();
            };
            return directive;
        };
        return Category;
    }());
    exports.Category = Category;
});
//# sourceMappingURL=category.directive.js.map