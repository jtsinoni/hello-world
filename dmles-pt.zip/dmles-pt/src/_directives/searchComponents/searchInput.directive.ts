import {SearchInputController} from "./searchInput.controller";

export class SearchInput implements ng.IDirective {
    public restrict: string = "EA";
    //public transclude: boolean = false;
    public controller = SearchInputController;
    public controllerAs: string = 'ctrl';
    public templateUrl: string = "./src/_directives/searchComponents/searchInput.template.html";

    public bindToController: any = {
        searchInputData: '=',
        searchPlaceholder: '@'
    };

    public scope:any = {
        executeSearch: '&'
    };

    // @ngInject
    constructor(private $log) {
    }

    public static Factory() {
        const directive = ($log) => new SearchInput($log);
        directive.$inject = ['$log'];
        return directive;
    }
}