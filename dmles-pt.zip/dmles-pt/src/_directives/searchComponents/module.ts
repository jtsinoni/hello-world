import {SearchInput} from './searchInput.directive';
import {SearchInputController} from "./searchInput.controller";

var dmlesSearchComponentsModule = angular.module('DmlesSearchComponentsModule', []);
dmlesSearchComponentsModule.directive('searchInput', SearchInput.Factory());

dmlesSearchComponentsModule.controller('SearchInputController', SearchInputController);

export default dmlesSearchComponentsModule;