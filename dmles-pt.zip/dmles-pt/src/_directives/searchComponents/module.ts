import {SearchInput} from './searchInput.directive';
import {SearchInputController} from "./searchInput.controller";

import {BaseCategoryService} from './category/baseCategory.service';
import {Category} from './category/category.directive';

import {BaseCategoryBreadcrumbService} from './categoryBreadcrumb/baseCategoryBreadcrumb.service';
import {CategoryBreadcrumb} from './categoryBreadcrumb/categoryBreadcrumb.directive';

import {BaseFacetService} from './facet/baseFacet.service';
import {Facet} from './facet/facet.directive';

import {BaseSearchWithinResultsService} from './searchWithinResults/baseSearchWithinResults.service';
import {SearchWithinResults} from './searchWithinResults/searchWithinResults.directive';

import {BaseSelectedFacetOptionsService} from './selectedFacetOptionsBreadbox/baseSelectedFacetOptions.service';
import {SelectedFacetOptionsBreadbox} from './selectedFacetOptionsBreadbox/selectedFacetOptionsBreadbox.directive';

var dmlesSearchComponentsModule = angular.module('DmlesSearchComponentsModule', []);

dmlesSearchComponentsModule.directive('searchInput', SearchInput.Factory());
dmlesSearchComponentsModule.controller('SearchInputController', SearchInputController);

dmlesSearchComponentsModule.service('BaseCategoryService', BaseCategoryService);
dmlesSearchComponentsModule.directive('category', Category.Factory());

dmlesSearchComponentsModule.service('BaseCategoryBreadcrumbService', BaseCategoryBreadcrumbService);
dmlesSearchComponentsModule.directive('categoryBreadcrumb', CategoryBreadcrumb.Factory());

dmlesSearchComponentsModule.service('BaseFacetService', BaseFacetService);
dmlesSearchComponentsModule.directive('facet', Facet.Factory());

dmlesSearchComponentsModule.service('BaseSearchWithinResultsService', BaseSearchWithinResultsService);
dmlesSearchComponentsModule.directive('searchWithinResults', SearchWithinResults.Factory());

dmlesSearchComponentsModule.service('BaseSelectedFacetOptionsService', BaseSelectedFacetOptionsService);
dmlesSearchComponentsModule.directive('selectedFacetOptionsBreadbox', SelectedFacetOptionsBreadbox.Factory());

export default dmlesSearchComponentsModule;