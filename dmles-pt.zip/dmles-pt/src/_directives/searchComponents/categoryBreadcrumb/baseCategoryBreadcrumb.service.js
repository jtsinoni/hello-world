define(["require", "exports", "../../../_constants/search.constants"], function (require, exports, search_constants_1) {
    'use strict';
    var BaseCategoryBreadcrumbService = (function () {
        // @ngInject
        function BaseCategoryBreadcrumbService($log, $rootScope, displayLabel, SearchUtilService) {
            this.$log = $log;
            this.$rootScope = $rootScope;
            this.SearchUtilService = SearchUtilService;
            // used for category breadcrumb - stores one selected category option per level
            this.selectedCategoryOptions = [];
            this.displayLabel = "";
            // this module (for event purposes)    
            this.eventModule = search_constants_1.SearchConstants.EVENT_MODULE_BASE;
            this.displayLabel = displayLabel;
        }
        BaseCategoryBreadcrumbService.prototype.clearAllCategoryOptionSelections = function (executeSearch) {
            // emit event
            var eventId = this.SearchUtilService.buildEventId(this.eventModule, this.displayLabel + search_constants_1.SearchConstants.EVENT_TARGET_COMPONENT_CATEGORY, search_constants_1.SearchConstants.EVENT_TARGET_METHOD_CLEAR_ALL_CATEGORY_OPTION_SELECTIONS);
            this.$log.debug("emit: %s", JSON.stringify(eventId));
            this.$rootScope.$emit(eventId, executeSearch);
        };
        BaseCategoryBreadcrumbService.prototype.clearBreadcrumb = function () {
            var executeSearch = true;
            this.clearAllCategoryOptionSelections(executeSearch);
            this.clearSelectedCategoryOptions();
        };
        BaseCategoryBreadcrumbService.prototype.clearSelectedCategoryOptions = function () {
            this.selectedCategoryOptions = [];
        };
        BaseCategoryBreadcrumbService.prototype.getSelectedCategoryOptions = function () {
            // this.$log.debug("getSelectedCategoryOptions() - this.selectedCategoryOptions: %s", JSON.stringify(this.selectedCategoryOptions));
            return this.selectedCategoryOptions;
        };
        BaseCategoryBreadcrumbService.prototype.init = function () {
            var _this = this;
            // listening here for an event targeted specifically to this Breadcrumb instance       
            var updateBreadcrumbPerCategoryOptionSelectionEventId = this.SearchUtilService.buildEventId(this.eventModule, this.displayLabel + search_constants_1.SearchConstants.EVENT_TARGET_COMPONENT_CATEGORY_BREADCRUMB, search_constants_1.SearchConstants.EVENT_TARGET_METHOD_UPDATE_BREADCRUMB_PER_CATEGORY_OPTION_SELECTION);
            var updateBreadcrumbPerCategoryOptionSelectionEventHandler = this.$rootScope.$on(updateBreadcrumbPerCategoryOptionSelectionEventId, function (event, data) {
                // this.$log.debug("caught " + updateBreadcrumbPerCategoryOptionSelectionEventId + " event");
                _this.updateBreadcrumbPerCategoryOptionSelection(data);
            });
            this.$rootScope.$on('$destroy', function () {
                updateBreadcrumbPerCategoryOptionSelectionEventHandler();
            });
        };
        BaseCategoryBreadcrumbService.prototype.updateCategoryOptionSelectionPerBreadcrumbClick = function (categoryOption) {
            this.$log.debug("categoryOption: %s", JSON.stringify(categoryOption));
            // emit event
            var eventId = this.SearchUtilService.buildEventId(this.eventModule, this.displayLabel + search_constants_1.SearchConstants.EVENT_TARGET_COMPONENT_CATEGORY, search_constants_1.SearchConstants.EVENT_TARGET_METHOD_UPDATE_CATEGORY_OPTION_SELECTIONS_PER_BREADCRUMB_CLICK);
            this.$log.debug("emit: %s", JSON.stringify(eventId));
            this.$rootScope.$emit(eventId, categoryOption);
        };
        BaseCategoryBreadcrumbService.prototype.updateBreadcrumbPerCategoryOptionSelection = function (selectedCategoryOptions) {
            // update the set of category options that are selected - based on data passed with
            // the new category option selection
            this.selectedCategoryOptions = selectedCategoryOptions;
            // this.$log.debug("updateBreadcrumbPerCategoryOptionSelection() - this.selectedCategoryOptions: %s", JSON.stringify(this.selectedCategoryOptions));
        };
        return BaseCategoryBreadcrumbService;
    }());
    exports.BaseCategoryBreadcrumbService = BaseCategoryBreadcrumbService;
});
//# sourceMappingURL=baseCategoryBreadcrumb.service.js.map