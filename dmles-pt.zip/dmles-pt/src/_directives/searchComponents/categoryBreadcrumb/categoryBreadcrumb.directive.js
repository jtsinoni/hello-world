define(["require", "exports"], function (require, exports) {
    'use strict';
    var CategoryBreadcrumb = (function () {
        // @ngInject
        function CategoryBreadcrumb() {
            this.templateUrl = "src/_directives/searchComponents/categoryBreadcrumb/categoryBreadcrumb.html";
            this.restrict = 'E'; // E = element, A = attribute, C = class, M = comment    
            this.scope = {
                config: '='
            };
            CategoryBreadcrumb.prototype.link = function (scope, element, attr) {
            };
        }
        CategoryBreadcrumb.Factory = function () {
            var directive = function () {
                return new CategoryBreadcrumb();
            };
            return directive;
        };
        return CategoryBreadcrumb;
    }());
    exports.CategoryBreadcrumb = CategoryBreadcrumb;
});
//# sourceMappingURL=categoryBreadcrumb.directive.js.map