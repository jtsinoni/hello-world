define(["require", "exports"], function (require, exports) {
    'use strict';
    var DmlesModalController = (function () {
        function DmlesModalController($log, $scope, $uibModal) {
            this.$log = $log;
            this.$scope = $scope;
            this.$uibModal = $uibModal;
            this.controllerName = "DmlesModalController Directive";
            this.loading = false;
            this.$log.debug('%s - Start ->', this.controllerName);
            this.init();
        }
        DmlesModalController.prototype.init = function () {
            var _this = this;
            if (!this.size) {
                this.size = "md";
            }
            if (!this.backdrop) {
                this.backdrop = "static";
            }
            if (!this.okText) {
                this.okText = "Ok";
            }
            if (!this.okStyle) {
                this.okStyle = "btn-primary";
            }
            if (!this.cancelText) {
                this.cancelText = "Cancel";
            }
            if (!this.cancelStyle) {
                this.cancelStyle = "btn-default";
            }
            if (!this.commentLabel) {
                this.commentLabel = "Please Explain";
            }
            if (!this.commentTooltip) {
                this.commentTooltip = "Please Explain";
            }
            this.$scope.$watch(function () { return _this.isOpen; }, function (newVal) {
                console.log('isOpen changed to ' + newVal);
                if (newVal === true) {
                    _this.open();
                }
            });
        };
        DmlesModalController.prototype.open = function () {
            this.modalInstance = this.$uibModal.open({
                animation: true,
                ariaLabelledBy: 'modal-title',
                ariaDescribedBy: 'modal-body',
                backdrop: this.backdrop,
                keyboard: true,
                size: this.size,
                templateUrl: './src/_directives/modals/dmlesModal.template.html',
                scope: this.$scope
            });
            this.isOpen = false;
            // this.modalInstance.result.then(function(selectedItem) {
            //     //this.title = "TEST!";
            //     this.$log.debug('%s - Loaded', this.controllerName);
            // }, function() {});
        };
        DmlesModalController.prototype.ok = function () {
            var _this = this;
            this.loading = true;
            var okClick = this.okClick();
            okClick.then(function (result) {
                _this.loading = false;
                _this.dismiss();
            });
            this.$log.debug('%s - OK!', this.controllerName);
        };
        DmlesModalController.prototype.cancel = function () {
            this.loading = true;
            if (angular.isDefined(this.cancelClick())) {
                this.cancelClick();
            }
            this.loading = false;
            this.$log.debug('%s - Cancel!', this.controllerName);
            this.dismiss();
            if (this.commentData) {
                this.commentData = null;
            }
        };
        DmlesModalController.prototype.dismiss = function () {
            this.$log.debug('%s - Close!', this.controllerName);
            this.modalInstance.dismiss('close');
        };
        return DmlesModalController;
    }());
    exports.DmlesModalController = DmlesModalController;
});
//# sourceMappingURL=dmlesModal.controller.js.map