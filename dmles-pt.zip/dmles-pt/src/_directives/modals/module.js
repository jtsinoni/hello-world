define(["require", "exports", './dmlesModal.controller', './dmlesModal.directive'], function (require, exports, dmlesModal_controller_1, dmlesModal_directive_1) {
    "use strict";
    var dmlesModalModule = angular.module('DmlesModalModule', []);
    dmlesModalModule.controller('DmlesModalController', dmlesModal_controller_1.DmlesModalController);
    dmlesModalModule.directive('dmlesModal', dmlesModal_directive_1.DmlesModal.Factory());
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = dmlesModalModule;
});
//# sourceMappingURL=module.js.map