
import {DmlesModalController} from './dmlesModal.controller';
import {DmlesModal} from './dmlesModal.directive';

var dmlesModalModule = angular.module('DmlesModalModule', []);
dmlesModalModule.controller('DmlesModalController', DmlesModalController);
dmlesModalModule.directive('dmlesModal', DmlesModal.Factory());

export default dmlesModalModule;

