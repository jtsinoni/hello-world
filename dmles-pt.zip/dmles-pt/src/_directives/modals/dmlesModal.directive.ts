import {DmlesModalController} from "./dmlesModal.controller";

/*
 title: Title of the modal,
 content1: Modal text content,
 content2: Optional modal text content,
 content3: Optional modal text content,
 size: "lg", "md", "sm".  Defaulted to 'md',
 backdrop: "static", "true", "false". Defaulted to 'static'.
 isOpen: Tells the directive when to open the modal,
 okClick: On OK click action, passed back to view controller, this call needs to be to an api service that will return a boolean
 titleIcon: Optional Title Icon, defaulted to none.
 okIcon: Optional OK Icon, defaulted to none.
 okText: Optional OK Text, defaulted to 'Ok'.
 okStyle: Optional OK Style, defaulted to 'fa fa-success'.
 cancelClick: Optional On cancel action, passes back to view controller, this call needs to be to an api service that will return a boolean
 cancelIcon: Optional Cancel Icon, defaulted to none.
 cancelText: Optional Cancel Text, defaulted to Cancel.
 cancelStyle: Optional Cancel Style, defaulted to none.
 commentData: Required if comment is allowed the ng-model for the comment
 commentRequired: whether the comment is required to continue with the action
 commentLabel: Optional the label of the comment
 commentTooltip: Optional comment tooltip
 commentAllowed: this is whether a comment is allowed or not. Comments could be optional. NOTE if comment is Required this has to be true to display the input field
 */

export class DmlesModal implements ng.IDirective {
    public restrict:string = "EA";
    public controller = DmlesModalController;
    public controllerAs: string = 'modal';

    public bindToController:any = {
        title: '@',
        content1: '@',
        content2: '@',
        content3: '@',
        size: '@',
        backdrop: '@',
        isOpen: '=',
        okClick: '&',
        titleIcon: '@',
        okIcon: '@',
        okText: '@',
        okStyle: '@',
        cancelClick: '&',
        cancelIcon: '@',
        cancelText: '@',
        cancelStyle: '@',
        commentData: '=',
        commentRequired: '=',
        commentLabel: '@',
        commentTooltip: '@',
        commentAllowed: '='
    };

    public scope: any = {};

    // @ngInject
    constructor(private $log) {}

    public static Factory() {
        const directive = ($log) => new DmlesModal($log);
        directive.$inject = ['$log'];
        return directive;
    }
}