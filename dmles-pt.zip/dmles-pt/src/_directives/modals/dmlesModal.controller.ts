'use strict';

export class DmlesModalController {
    private controllerName:string = "DmlesModalController Directive";

    public loading:boolean = false;
    public modalInstance: any;

    // Passed in from directive
    public title: string;
    public content1: string;
    public content2: string;
    public content3: string;
    public size: string;
    public backdrop: string;
    public isOpen: boolean;
    public okIcon: string;
    public okClick;
    public okTitle: string;
    public okText: string;
    public okStyle: string;
    public cancelClick;
    public cancelIcon: string;
    public cancelText: string;
    public cancelStyle: string;
    public commentData;
    public commentRequired;
    public commentLabel: string;
    public commentTooltip: string;
    public commentAllowed;

    constructor(private $log, public $scope, private $uibModal) {
        this.$log.debug('%s - Start ->', this.controllerName);
        this.init();
    }

    private init(){
        if(!this.size){
            this.size = "md";
        }

        if(!this.backdrop){
            this.backdrop = "static";
        }

        if(!this.okText){
            this.okText = "Ok";
        }

        if(!this.okStyle){
            this.okStyle = "btn-primary";
        }

        if(!this.okIcon){
            this.okIcon = "fa fa-thumbs-up";
        }

        if(!this.cancelText){
            this.cancelText = "Cancel";
        }

        if(!this.cancelStyle){
            this.cancelStyle = "btn-default";
        }

        if(!this.commentLabel){
            this.commentLabel = "Please Explain";
        }

        if(!this.commentTooltip){
            this.commentTooltip = "Please Explain";
        }

        this.$scope.$watch(() => this.isOpen, (newVal) => {
            console.log('isOpen changed to ' + newVal);
            if(newVal === true){
                this.open();
            }
        });

    }

    public open(){
        this.modalInstance = this.$uibModal.open({
            animation: true,
            ariaLabelledBy: 'modal-title',
            ariaDescribedBy: 'modal-body',
            backdrop: this.backdrop,
            keyboard: true,
            size: this.size,
            templateUrl: './src/_directives/modals/dmlesModal.template.html',
            scope: this.$scope
        });

        this.isOpen = false;

        // this.modalInstance.result.then(function(selectedItem) {
        //     //this.title = "TEST!";
        //     this.$log.debug('%s - Loaded', this.controllerName);
        // }, function() {});

    }

    public ok(){
        this.loading = true;
        var okClick = this.okClick();
        okClick.then(result => {
            this.loading = false;
            this.dismiss();
        });
        this.$log.debug('%s - OK!', this.controllerName);
    }

    public cancel(){
        this.loading = true;
        if(angular.isDefined(this.cancelClick())) {
            this.cancelClick();
        }
        this.loading = false;
        this.$log.debug('%s - Cancel!', this.controllerName);
        this.dismiss();
    }

    public dismiss(){
        this.$log.debug('%s - Close!', this.controllerName);
        if(this.commentData){
            this.commentData = null;
        }
        this.modalInstance.dismiss('close');
    }

}