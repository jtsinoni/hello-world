define(["require", "exports", './panels/leftSidePanel.directive', './panels/rightSidePanel.directive', './panels/viewNotesPanel.directive', './panels/viewAttachmentsPanel.directive', './elementChecker/elementChecker.directive', './mainNav/mainNav.directive', './mainNav/mainNav.controller', './mainNav/mainNav.service', './utils/dmlesHideAttr.directive', './tables/dmlesPanelTable.controller', './tables/dmlesPanelTable.directive', './tables/dmlesTable.directive', './tables/dmlesTable.controller', './tables/dmlesTest.directive', './tables/dmlesTest.controller', './tooltips/dmlesToolTip.directive', './tooltips/dmlesToolTip.controller', './buttons/removeButton.directive'], function (require, exports, leftSidePanel_directive_1, rightSidePanel_directive_1, viewNotesPanel_directive_1, viewAttachmentsPanel_directive_1, elementChecker_directive_1, mainNav_directive_1, mainNav_controller_1, mainNav_service_1, dmlesHideAttr_directive_1, dmlesPanelTable_controller_1, dmlesPanelTable_directive_1, dmlesTable_directive_1, dmlesTable_controller_1, dmlesTest_directive_1, dmlesTest_controller_1, dmlesToolTip_directive_1, dmlesToolTip_controller_1, removeButton_directive_1) {
    "use strict";
    var directivesModule = angular.module('DirectivesModule', []);
    directivesModule.controller('MainNavController', mainNav_controller_1.MainNavController);
    directivesModule.controller('DmlesPanelTableController', dmlesPanelTable_controller_1.DmlesPanelTableController);
    directivesModule.controller('DmlesTableController', dmlesTable_controller_1.DmlesTableController);
    directivesModule.controller('DmlesTestController', dmlesTest_controller_1.DmlesTestController);
    directivesModule.controller('DmlesToolTipController', dmlesToolTip_controller_1.DmlesToolTipController);
    directivesModule.directive('dmlesTest', dmlesTest_directive_1.DmlesTest.Factory());
    directivesModule.directive('leftSidePanel', leftSidePanel_directive_1.LeftSidePanel.Factory());
    directivesModule.directive('rightSidePanel', rightSidePanel_directive_1.RightSidePanel.Factory());
    directivesModule.directive('viewNotesPanel', viewNotesPanel_directive_1.ViewNotesPanel.Factory());
    directivesModule.directive('viewAttachmentsPanel', viewAttachmentsPanel_directive_1.ViewAttachmentsPanel.Factory());
    directivesModule.directive('elementChecker', elementChecker_directive_1.elementChecker.Factory());
    directivesModule.directive('mainNav', mainNav_directive_1.MainNav.Factory());
    directivesModule.directive('dmlesHideAttr', dmlesHideAttr_directive_1.DmlesHideAttr.Factory());
    directivesModule.directive('dmlesPanelTable', dmlesPanelTable_directive_1.DmlesPanelTable.Factory());
    directivesModule.directive('dmlesTable', dmlesTable_directive_1.DmlesTable.Factory());
    directivesModule.directive('dmlesToolTip', dmlesToolTip_directive_1.DmlesToolTip.Factory());
    directivesModule.directive('removeButton', removeButton_directive_1.RemoveButton.Factory());
    directivesModule.service('MainNavService', mainNav_service_1.MainNavService);
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = directivesModule;
});
//# sourceMappingURL=module.js.map