define(["require", "exports", './panels/leftSidePanel.directive', './panels/rightSidePanel.directive', './panels/viewNotesPanel.directive', './panels/viewAttachmentsPanel.directive', './panels/viewNotesPanel.controller', './elementChecker/elementChecker.directive', './mainNav/mainNav.directive', './mainNav/mainNav.controller', './mainNav/mainNav.service', './tooltips/dmlesToolTip.directive', './tooltips/dmlesToolTip.controller', './tree/dmlesTree.directive', './tree/dmlesTree.controller', './tree/dmlesTreeData.model', './buttons/removeButton.directive', './fields/module', './fileUpload/module', './formInputs/module', './formOther/module', './modals/module', './notes/module', './searchComponents/module', './tables/module', './utils/module'], function (require, exports, leftSidePanel_directive_1, rightSidePanel_directive_1, viewNotesPanel_directive_1, viewAttachmentsPanel_directive_1, viewNotesPanel_controller_1, elementChecker_directive_1, mainNav_directive_1, mainNav_controller_1, mainNav_service_1, dmlesToolTip_directive_1, dmlesToolTip_controller_1, dmlesTree_directive_1, dmlesTree_controller_1, dmlesTreeData_model_1, removeButton_directive_1, module_1, module_2, module_3, module_4, module_5, module_6, module_7, module_8, module_9) {
    "use strict";
    var directivesModule = angular.module('DirectivesModule', [
        module_1.default.name,
        module_2.default.name,
        module_3.default.name,
        module_4.default.name,
        module_5.default.name,
        module_6.default.name,
        module_7.default.name,
        module_8.default.name,
        module_9.default.name
    ]);
    directivesModule.controller('MainNavController', mainNav_controller_1.MainNavController);
    directivesModule.controller('DmlesToolTipController', dmlesToolTip_controller_1.DmlesToolTipController);
    directivesModule.controller('DmlesTreeController', dmlesTree_controller_1.DmlesTreeController);
    directivesModule.controller('ViewNotesPanelController', viewNotesPanel_controller_1.ViewNotesPanelController);
    directivesModule.directive('leftSidePanel', leftSidePanel_directive_1.LeftSidePanel.Factory());
    directivesModule.directive('rightSidePanel', rightSidePanel_directive_1.RightSidePanel.Factory());
    directivesModule.directive('viewNotesPanel', viewNotesPanel_directive_1.ViewNotesPanel.Factory());
    directivesModule.directive('viewAttachmentsPanel', viewAttachmentsPanel_directive_1.ViewAttachmentsPanel.Factory());
    directivesModule.directive('elementChecker', elementChecker_directive_1.elementChecker.Factory());
    directivesModule.directive('mainNav', mainNav_directive_1.MainNav.Factory());
    directivesModule.directive('dmlesTree', dmlesTree_directive_1.DmlesTree.Factory());
    directivesModule.directive('dmlesToolTip', dmlesToolTip_directive_1.DmlesToolTip.Factory());
    directivesModule.directive('removeButton', removeButton_directive_1.RemoveButton.Factory());
    directivesModule.service('MainNavService', mainNav_service_1.MainNavService);
    directivesModule.value('DmlesTreeData', dmlesTreeData_model_1.DmlesTreeData);
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = directivesModule;
});
//# sourceMappingURL=module.js.map