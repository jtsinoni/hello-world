import {DmlesGridController} from "./dmlesGrid.controller";

/*
UI Grid Ref: http://ui-grid.info/docs/#/tutorial

HTML View Example:
 <dmles-grid
    grid-style="width: 800px; height: 300px;"  // (Optional) Developer can set a prefered height and width, defaults to 100%
    grid-data="vm.gData"               // (Required) Data used within grid
    grid-loading-message="Loading organizations" // (Optional) Loading message
    grid-name="gridTest"               // (Required) Name/Id of grid, must be unique if more than one is on a page
    grid-opts="vm.gOpts"               // (Required) Grid Options
    grid-title="Org Table"             // (Required) Grid Header/Title
    grid-title-icon="fa-coffee"        // (Optional) Grid Header/Title icon
    grid-select="vm.getGridRowClick(rowData)"  // (Optionally Required) Select callback
    grid-select-many="vm.getGridBatchRowClick(rowDataArray)" // (Optionally Required) Multi-select callback
 ></dmles-grid>

Controller Example:
 public gOpts:any = {};
 public gData:any = {};

 private buildGridOpts(){
     this.gOpts = {
        data: null,
        enableCellEditOnFocus: false,   // Coming soon
        enableColumnResizing: false,    // User can change the column size
        enableFiltering: true,          // User can filter per column
        enableGridMenu: true,           // User has more options via table menu
        enableRowHeaderSelection: true, // User can select all or un-select all
        enableRowSelection: true,       // User can select a row
        enableSelectAll: true,          // User can select all
        enableSorting: true,            // User can sort
        exporterCsvFilename: 'logiColeData.csv',  // Export filename
        multiSelect: true,              // User can multi-select
        showColumnFooter: false,        // Calculations are shown in the footer, coming soon
        showGridFooter:true,            // Stats or item counts are shown in the footer
        columnDefs: [
            { field: 'name', displayName: 'Name', width: 200, enablePinning:true, pinnedLeft:true },
            { field: 'guid', displayName: 'GUID', width: 200, enableCellEdit: true },
            { field: 'treeLevel', displayName: 'Tree Level', width: 100 },
            { field: 'nodeChain', displayName: 'Tree Chain', width: 500 }
        ]
     };

     // Note: Pinning is available, see columnDefs, cell editing still needs some work
 }

 private getGridData(){
    this.OrganizationManagementService.getNodes(false).then((data: any) => {
        this.gData = data;
    });
 }

 */

export class DmlesGrid implements ng.IDirective {
    public restrict: string = "EA";
    public controller = DmlesGridController;
    public controllerAs: string = 'ctrl';
    public templateUrl: string = "./src/_directives/tables/dmlesGrid.template.html";

    public bindToController: any = {
        gridCanRefresh: '=',
        gridData: '=',
        gridIsSub: '=',
        gridLoadingMessage: '@',
        gridName: '@',
        gridOpts: '=',
        gridStyleHeight: '@',
        gridStyleWidth: '@',
        gridPanelClass: '@',
        gridClass: '@',
        gridTitleIcon: '@',
        gridTitle: '@'
    };

    public scope: any = {
        gridRefresh: '&',
        gridSelect: '&',
        gridSelectMany: '&'
    };

    // @ngInject
    constructor(private $log) {
    }

    public static Factory() {
        const directive = ($log) => new DmlesGrid($log);
        directive.$inject = ['$log'];
        return directive;
    }
}