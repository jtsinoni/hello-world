import {DmlesGridTreeController} from "./dmlesGridTree.controller";

/*
UI Grid Ref: http://ui-grid.info/docs/#/tutorial
*/

export class DmlesGridTree implements ng.IDirective {
    public restrict: string = "EA";
    public controller = DmlesGridTreeController;
    public controllerAs: string = 'ctrl';
    public templateUrl: string = "./src/_directives/tables/dmlesGridTree.template.html";

    public bindToController: any = {
        treeId: '@',
        treeData: '=',
        treeOptions: '=',
        treeIsLoading: '=',
        treeItemPreSelection: '=',
        treeItemScrollTo: '=',
        height: '@',
        width: '@'
    };

    public scope: any = {
        treeItemSelection: '&',
    };

    // @ngInject
    constructor(private $log) {
    }

    public static Factory() {
        const directive = ($log) => new DmlesGridTree($log);
        directive.$inject = ['$log'];
        return directive;
    }
}