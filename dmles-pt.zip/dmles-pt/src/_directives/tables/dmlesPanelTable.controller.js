define(["require", "exports"], function (require, exports) {
    "use strict";
    var DmlesPanelTableController = (function () {
        //@inject
        function DmlesPanelTableController($scope, $log, $q, $timeout, LocalStorageService, ngTableEventsChannel, NgTableParams, UserService, UtilService) {
            this.$scope = $scope;
            this.$log = $log;
            this.$q = $q;
            this.$timeout = $timeout;
            this.LocalStorageService = LocalStorageService;
            this.ngTableEventsChannel = ngTableEventsChannel;
            this.NgTableParams = NgTableParams;
            this.UserService = UserService;
            this.UtilService = UtilService;
            this.controllerName = "DmlesPanelTableController Directive";
            this.allTableEvents = [];
            this.exportHeaders = [];
            this.exportExtension = ".csv";
            this.$log.debug('%s - Start', this.controllerName);
            this.isLoading = true;
            this.userPkiDn = this.UserService.currentUser.pkiDn;
            this.cacheKeyPage = this.userPkiDn + "_" + this.tableName + "_" + "pageKey";
            this.cacheKeySearch = this.userPkiDn + "_" + this.tableName + "_" + "searchKey";
            this.cacheKeyFilter = this.userPkiDn + "_" + this.tableName + "_" + "filterKey";
            this.cacheKeySorting = this.userPkiDn + "_" + this.tableName + "_" + "sortingKey";
            this.allTableEvents = [];
            this.init();
        }
        DmlesPanelTableController.prototype.filter = function () {
            this.LocalStorageService.storeData(this.cacheKeySearch, this.search, false);
            this.tableParams.filter({ $: this.search });
            this.tableParams.reload();
        };
        DmlesPanelTableController.prototype.init = function () {
            var _this = this;
            this.searchName = this.tableName + "Search";
            this.$log.debug('%s - canExport: %s', this.controllerName, this.canExport);
            this.$log.debug('%s - canFilterGlobal: %s', this.controllerName, this.canFilterGlobal);
            this.$log.debug('%s - canFilterByColumn: %s', this.controllerName, this.canFilterByColumn);
            this.$log.debug('%s - title: %s', this.controllerName, this.title);
            this.$log.debug('%s - tableName: %s', this.controllerName, this.tableName);
            this.$log.debug('%s - searchName: %s', this.controllerName, this.searchName);
            this.$log.debug('%s - data: %s', this.controllerName, JSON.stringify(this.data));
            //this.$log.debug('%s - initFilter: %s', this.controllerName, JSON.stringify(this.initFilter));
            // Note: I really did not want to put this here, but there seems to be an issue with the data coming in after the directive or the table is
            // initialized.  This still needs to be debugged and my be a bigger issue later with large datasets.
            this.$timeout(function () {
                _this.isLoading = false;
                _this.tableParams = new _this.NgTableParams({ sorting: _this.initSort }, { dataset: _this.data });
                _this.setupExport();
                _this.applyCachedParams();
                _this.subscribeToTableEvents();
            }, 1000);
        };
        DmlesPanelTableController.prototype.applyCachedParams = function () {
            if (this.LocalStorageService.getData(this.cacheKeyPage)) {
                var page = this.LocalStorageService.getData(this.cacheKeyPage);
                if (this.tableParams.page() <= page) {
                    this.tableParams.page(page);
                    this.$log.debug("%s - Page cache applied: %s", this.controllerName, page);
                }
                else {
                    this.LocalStorageService.storeData(this.cacheKeyPage, this.tableParams.page(), false);
                }
            }
            if (this.LocalStorageService.getData(this.cacheKeySearch)) {
                this.search = this.LocalStorageService.getData(this.cacheKeySearch);
                this.tableParams.filter({ $: this.search });
                this.$log.debug("%s - Global search cache applied: %s", this.controllerName, this.search);
            }
            var cachedFiltering = this.LocalStorageService.getData(this.cacheKeyFilter);
            if (!this.UtilService.isObjectEmpty(cachedFiltering)) {
                this.$log.debug("%s - Filtering cache applied: %s", this.controllerName, JSON.stringify(cachedFiltering));
                this.tableParams.filter(cachedFiltering);
            }
            var cachedSorting = this.LocalStorageService.getData(this.cacheKeySorting);
            if (!this.UtilService.isObjectEmpty(cachedSorting)) {
                this.$log.debug("%s - Sorting cache applied: %s", this.controllerName, JSON.stringify(cachedSorting));
                this.tableParams.sorting(cachedSorting);
            }
        };
        DmlesPanelTableController.prototype.setupExport = function () {
            if (this.canExport) {
                if (this.data && this.data[0] && this.exportHeaders.length == 0) {
                    var tableObj = this.data[0];
                    this.exportHeaders = Object.keys(tableObj);
                    var fileDate = new Date().getTime();
                    this.exportFilename = this.title + "_export_" + fileDate + this.exportExtension;
                    this.$log.debug("%s - Exporting ability setup", this.controllerName);
                }
            }
        };
        DmlesPanelTableController.prototype.subscribeToTableEvents = function () {
            this.ngTableEventsChannel.onPagesChanged(this.logEvent(this.allTableEvents, "pageChangedEvent"), this.$scope);
            this.ngTableEventsChannel.onAfterDataFiltered(this.logEvent(this.allTableEvents, "dataFilteredEvent"), this.$scope);
            this.ngTableEventsChannel.onAfterDataSorted(this.logEvent(this.allTableEvents, "dataSortedEvent"), this.$scope);
            //this.ngTableEventsChannel.onAfterCreated(this.logEvent(this.allTableEvents, "afterCreated"), this.$scope);
            //this.ngTableEventsChannel.onAfterReloadData(this.logEvent(this.allTableEvents, "afterReloadData"), this.$scope);
            //this.ngTableEventsChannel.onDatasetChanged(this.logEvent(this.allTableEvents, "datasetChanged"), this.$scope);
            this.$log.debug("%s - Subscribed to table events", this.controllerName);
        };
        DmlesPanelTableController.prototype.logEvent = function (list, name) {
            var _this = this;
            //this.$log.debug('logged event: %s', name);
            //this.$log.debug('logged list: %s', list);
            //var list = list;
            //var name = name;
            return function () {
                if (name == "pageChangedEvent") {
                    _this.$log.debug("%s - Page stored cache", _this.controllerName, _this.tableParams.page());
                    _this.LocalStorageService.storeData(_this.cacheKeyPage, _this.tableParams.page(), false);
                }
                if (name == "dataFilteredEvent" && !_this.UtilService.isObjectEmpty(_this.tableParams.filter())) {
                    _this.$log.debug("%s - Filter object in cache", _this.controllerName, JSON.stringify(_this.tableParams.filter()));
                    _this.LocalStorageService.storeData(_this.cacheKeyFilter, _this.tableParams.filter(), true);
                }
                if (name == "dataSortedEvent" && !_this.UtilService.isObjectEmpty(_this.tableParams.sorting())) {
                    _this.$log.debug("%s - Sorting object in cache", _this.controllerName, JSON.stringify(_this.tableParams.sorting()));
                    _this.LocalStorageService.storeData(_this.cacheKeySorting, _this.tableParams.sorting(), true);
                }
            };
        };
        return DmlesPanelTableController;
    }());
    exports.DmlesPanelTableController = DmlesPanelTableController;
});
//# sourceMappingURL=dmlesPanelTable.controller.js.map