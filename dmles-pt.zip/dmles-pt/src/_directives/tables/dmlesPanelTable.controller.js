define(["require", "exports"], function (require, exports) {
    "use strict";
    var DmlesPanelTableController = (function () {
        //@inject
        function DmlesPanelTableController($scope, $log, $q, $timeout, LocalStorageService, ngTableEventsChannel, NgTableParams, UserService, UtilService) {
            var _this = this;
            this.$scope = $scope;
            this.$log = $log;
            this.$q = $q;
            this.$timeout = $timeout;
            this.LocalStorageService = LocalStorageService;
            this.ngTableEventsChannel = ngTableEventsChannel;
            this.NgTableParams = NgTableParams;
            this.UserService = UserService;
            this.UtilService = UtilService;
            this.controllerName = "DmlesPanelTableController Directive";
            this.allTableEvents = [];
            this.enableLoadingMessage = false;
            this.exportHeaders = [];
            this.exportExtension = ".csv";
            this.$log.debug('%s - Start', this.controllerName);
            this.userPkiDn = this.UserService.currentUser.pkiDn;
            this.cacheKeyPage = this.userPkiDn + "_" + this.tableName + "_" + "pageKey";
            this.cacheKeySearch = this.userPkiDn + "_" + this.tableName + "_" + "searchKey";
            this.cacheKeyFilter = this.userPkiDn + "_" + this.tableName + "_" + "filterKey";
            //this.cacheKeySorting = this.userPkiDn + "_" + this.tableName + "_" + "sortingKey";
            this.allTableEvents = [];
            ////////////////////////////////////////////////////////////////////////////////////////////////
            // For details on how and why this $scope.$watch works, refer to this page:
            // http://dotnetbyexample.blogspot.com/2014/07/angularjs-typescript-how-to-setup-watch.html 
            // other attempts to do $scope.$watch('data', ...) just don't work - perhaps variable 
            // needs fully qualified with namespace?
            ////////////////////////////////////////////////////////////////////////////////////////////////
            this.$scope.$watch(function () { return _this.data; }, function (newValue, oldValue) {
                _this.init(true);
            });
            this.init(false);
        }
        DmlesPanelTableController.prototype.filter = function () {
            this.LocalStorageService.storeData(this.cacheKeySearch, this.search, false);
            this.tableParams.filter({ $: this.search });
            this.tableParams.reload();
        };
        DmlesPanelTableController.prototype.init = function (isFromWatcher) {
            this.isLoading = true;
            this.searchName = this.tableName + "Search";
            this.tableParams = new this.NgTableParams({ sorting: this.initSort }, { dataset: this.data });
            this.setupExport();
            this.applyCachedParams();
            this.subscribeToTableEvents();
            if (isFromWatcher && Array.isArray(this.data)) {
                this.isLoading = false;
            }
        };
        DmlesPanelTableController.prototype.applyCachedParams = function () {
            if (this.LocalStorageService.getData(this.cacheKeyPage)) {
                var page = this.LocalStorageService.getData(this.cacheKeyPage);
                if (this.tableParams.page() <= page) {
                    this.tableParams.page(page);
                    this.$log.debug("%s - Page cache applied: %s", this.controllerName, page);
                }
                else {
                    this.LocalStorageService.storeData(this.cacheKeyPage, this.tableParams.page(), false);
                }
            }
            if (this.LocalStorageService.getData(this.cacheKeySearch)) {
                this.search = this.LocalStorageService.getData(this.cacheKeySearch);
                this.tableParams.filter({ $: this.search });
                this.$log.debug("%s - Global search cache applied: %s", this.controllerName, this.search);
            }
            var cachedFiltering = this.LocalStorageService.getData(this.cacheKeyFilter);
            if (!this.UtilService.isObjectEmpty(cachedFiltering)) {
                this.$log.debug("%s - Filtering cache applied: %s", this.controllerName, JSON.stringify(cachedFiltering));
                this.tableParams.filter(cachedFiltering);
            }
            //var cachedSorting:any = this.LocalStorageService.getData(this.cacheKeySorting);
            //if(!this.UtilService.isObjectEmpty(cachedSorting)){
            //    this.$log.debug("%s - Sorting cache applied: %s", this.controllerName, JSON.stringify(cachedSorting));
            //    this.tableParams.sorting(cachedSorting);
            //}
        };
        DmlesPanelTableController.prototype.setupExport = function () {
            if (this.canExport) {
                if (this.data && this.data[0] && this.exportHeaders.length == 0) {
                    var tableObj = this.data[0];
                    this.exportHeaders = Object.keys(tableObj);
                    var fileDate = new Date().getTime();
                    this.exportFilename = this.title + "_export_" + fileDate + this.exportExtension;
                    this.$log.debug("%s - Exporting ability setup", this.controllerName);
                }
            }
        };
        DmlesPanelTableController.prototype.refreshTableDirClick = function () {
            this.$log.debug("%s - Refresh Table Directive Clicked", this.controllerName);
            this.init(false);
        };
        DmlesPanelTableController.prototype.subscribeToTableEvents = function () {
            this.ngTableEventsChannel.onPagesChanged(this.logEvent(this.allTableEvents, "pageChangedEvent"), this.$scope);
            this.ngTableEventsChannel.onAfterDataFiltered(this.logEvent(this.allTableEvents, "dataFilteredEvent"), this.$scope);
            this.ngTableEventsChannel.onAfterDataSorted(this.logEvent(this.allTableEvents, "dataSortedEvent"), this.$scope);
            //this.ngTableEventsChannel.onAfterCreated(this.logEvent(this.allTableEvents, "afterCreated"), this.$scope);
            //this.ngTableEventsChannel.onAfterReloadData(this.logEvent(this.allTableEvents, "afterReloadData"), this.$scope);
            //this.ngTableEventsChannel.onDatasetChanged(this.logEvent(this.allTableEvents, "datasetChanged"), this.$scope);
            this.$log.debug("%s - Subscribed to table events", this.controllerName);
        };
        DmlesPanelTableController.prototype.logEvent = function (list, name) {
            var _this = this;
            //this.$log.debug('logged event: %s', name);
            //this.$log.debug('logged list: %s', list);
            //var list = list;
            //var name = name;
            return function () {
                if (name == "pageChangedEvent") {
                    //this.$log.debug("%s - Event fired: Page stored cache", this.controllerName, this.tableParams.page());
                    _this.LocalStorageService.storeData(_this.cacheKeyPage, _this.tableParams.page(), false);
                }
                if (name == "dataFilteredEvent" && !_this.UtilService.isObjectEmpty(_this.tableParams.filter())) {
                    //this.$log.debug("%s - Event fired: Filter object in cache", this.controllerName, JSON.stringify(this.tableParams.filter()));
                    _this.LocalStorageService.storeData(_this.cacheKeyFilter, _this.tableParams.filter(), true);
                }
                //if(name == "dataSortedEvent" && !this.UtilService.isObjectEmpty(this.tableParams.sorting())){
                //    //this.$log.debug("%s - Event fired: Sorting object in cache", this.controllerName, JSON.stringify(this.tableParams.sorting()));
                //    this.LocalStorageService.storeData(this.cacheKeySorting, this.tableParams.sorting(), true);
                //}
            };
        };
        return DmlesPanelTableController;
    }());
    exports.DmlesPanelTableController = DmlesPanelTableController;
});
//# sourceMappingURL=dmlesPanelTable.controller.js.map