define(["require", "exports", "./dmlesTable.controller"], function (require, exports, dmlesTable_controller_1) {
    "use strict";
    /*
     <dmles-table id="trainingTable"
        data="vm.RequestService.request.requestInformation.training"
        columns="vm.trainingCols"
        sort-on="trainees"
        sort-descending="false"
        clickable-row="false"
     >
     </dmles-table>
    
     id: table ID, needed by selenium tests
     data: table data
     columns: custom headers, array of { name: 'Type', modelName: 'type', dataType: 'text' }
     sort-on: model name to sort on
     sort-descending: sort descending or ascending
     clickable: is the row clickable, if so, then the data for the row is passed back the directive controller
     */
    var DmlesTable = (function () {
        // @ngInject
        function DmlesTable($log) {
            this.$log = $log;
            this.restrict = "EA";
            this.controller = dmlesTable_controller_1.DmlesTableController;
            this.controllerAs = 'vm';
            this.bindToController = false;
            this.templateUrl = "./src/_directives/tables/dmlesTable.template.html";
            this.scope = {
                id: '@',
                clickableRow: '=',
                columns: '=',
                data: '=',
                sortOn: '@',
                sortDescending: '@',
                action: '&'
            };
        }
        DmlesTable.Factory = function () {
            var directive = function ($log) { return new DmlesTable($log); };
            directive.$inject = ['$log'];
            return directive;
        };
        return DmlesTable;
    }());
    exports.DmlesTable = DmlesTable;
});
//# sourceMappingURL=dmlesTable.directive.js.map