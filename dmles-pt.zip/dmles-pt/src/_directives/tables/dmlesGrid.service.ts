'use strict';

export class DmlesGridService {

    private gridApi: any;
    private gridState: any = {};

    // @ngInject
    constructor(private $log, private $timeout, private uiGridConstants) {
        this.$log.debug("DmlesGridService initialized");
    }

    public setGridApi(gridApi) {
        this.gridApi = gridApi;
    }

    public clearAllFilters() {
        if (this.gridApi) {
            this.$log.debug("DmlesGridService - clearAllFilters()");
            this.$timeout(() => {
                this.gridApi.grid.clearAllFilters();
            }, 0);
        }
    }

    public handleWindowResize() {
        if (this.gridApi) {
            this.$log.debug("DmlesGridService - handleWindowResize()");
            this.$timeout(() => {
                this.gridApi.core.handleWindowResize();
            }, 0);
        }
    }

    public goToPage(page: number) {
        if (this.gridApi) {
            this.$log.debug("DmlesGridService - goToPage(%d)", page);
            this.gridApi.pagination.seek(page);
        }
    }

    public notifyDataChangeAll() {
        if (this.gridApi) {
            this.$log.debug("DmlesGridService - notifyDataChangeAll()");
            this.$timeout(() => {
                this.gridApi.core.notifyDataChange(this.uiGridConstants.dataChange.ALL);
            }, 0);
        }
    }

    public notifyDataChangeOptions() {
        if (this.gridApi) {
            this.$log.debug("DmlesGridService - notifyDataChangeOptions()");
            this.$timeout(() => {
                this.gridApi.core.notifyDataChange(this.uiGridConstants.dataChange.OPTIONS);
            }, 0);
        }
    }

    public queueGridRefresh() {
        if (this.gridApi) {
            this.$log.debug("DmlesGridService - queueGridRefresh()");
            this.$timeout(() => {
                this.gridApi.core.queueGridRefresh();
            }, 0);
        }
    }

    public refresh() {
        if (this.gridApi) {
            this.$log.debug("DmlesGridService - refresh()");
            this.$timeout(() => {
                this.gridApi.core.refresh();
            }, 0);
        }
    }

    public refreshRows() {
        if (this.gridApi) {
            this.$log.debug("DmlesGridService - refreshRows()");
            this.$timeout(() => {
                this.gridApi.core.refreshRows();
            }, 0);
        }
    }

    // restore this.gridState
    public restoreGridState() {
        if (this.gridApi) {
            this.$log.debug("DmlesGridService - restoreGridState()");
            this.$timeout(() => {
                this.gridApi.saveState.restore(this, this.gridState);
            }, 0);
        }
    }

    // saves this.gridState
    public saveGridState() {
        if (this.gridApi) {
            this.$log.debug("DmlesGridService - saveGridState()");
            this.gridState = this.gridApi.saveState.save();
        }
    }

    // restore passed in gridState
    public restoreProvidedGridState(gridState) {
        if (this.gridApi) {
            this.$log.debug("DmlesGridService - restoreProvidedGridState()");
            this.$timeout(() => {
                this.gridApi.saveState.restore(this, gridState);
            }, 0);
        }
    }

    // save and return gridState to calling function
    public retrieveGridState(): any {
        if (this.gridApi) {
            this.$log.debug("DmlesGridService - retrieveGridState()");
            return this.gridApi.saveState.save();
        }
    }
}
