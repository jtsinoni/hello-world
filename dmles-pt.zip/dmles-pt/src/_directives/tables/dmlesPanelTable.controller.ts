export class DmlesPanelTableController {
    private controllerName:string = "DmlesPanelTableController";

    public exportFilename:string;
    public exportHeaders:string[] = [];
    public exportExtension:string = ".csv";
    public tableParams:any;
    public search:string;
    public searchName:string;

    public tableEvents:string[] = [];

    // Passed in from the directive
    public cols:any;
    public count:number;
    public data:any;
    public canExport:boolean = true;
    public canFilterGlobal:boolean = true;
    public canFilterByColumn:boolean = false;
    public title:string;
    public tableName:string;

    //@inject
    constructor(public $scope, private $log, private $q, private LocalStorageService, private ngTableEventsChannel,  private NgTableParams) {
        this.$log.debug('%s - Start', this.controllerName);

        this.cols = this.$scope.cols;
        this.count = this.$scope.count;
        this.data = this.$scope.data;
        this.canExport = this.$scope.canExport;
        this.canFilterGlobal = this.$scope.canFilterGlobal;
        this.canFilterByColumn = this.$scope.canFilterByColumn;
        this.title = this.$scope.title;
        this.tableName = this.$scope.tableName;
        this.searchName = this.tableName + "Search";

        if(this.canExport){
            if(this.data && this.data[0] && this.exportHeaders.length == 0){
                var tableObj = this.data[0];
                this.exportHeaders = Object.keys(tableObj);

                var fileDate = new Date().getTime();
                this.exportFilename = this.title + "_export_" + fileDate + this.exportExtension;
            }
        }

        if(!this.cols){
            this.$log.error('dmlesPanelTable controller missing cols');
        }

        this.$log.debug('data: %s', JSON.stringify(this.data));
        //this.$log.debug('cols: %s', JSON.stringify(this.cols));
        //this.$log.debug('exportHeaders: %s', JSON.stringify(this.exportHeaders));


        this.$scope.$watch(this.$scope.data, () => {
            if(this.$scope.data){
                this.$log.debug('data delta: %s', JSON.stringify(this.$scope.data));
                this.data = this.$scope.data;

                if(this.tableParams){
                    this.tableParams.reload();
                    this.$log.debug('dmlesPanelTableController Dir watchDataChanges: table reloaded');
                }else{
                    this.loadData().then(() => {
                        this.$log.debug('dmlesPanelTableController Dir > watchDataChanges: table data dynamically loaded');
                    });
                }

            }
        });

        //this.$scope.$watch(this.tableParams, () => {
        //    this.$log.debug('dmlesPanelTableController Dir: tableParams delta');
        //    //this.LocalStorageService.storeData(this.tableName, this.tableParams);
        //}, true);

        this.loadData().then(() => {
            //this.watchTableFilters();
            //this.watchDataChanges();

            var cachedSearch:string = this.LocalStorageService.getData(this.searchName);
            if(cachedSearch){
                this.search = cachedSearch;
                this.filter();
            }

            //$scope.$watch("filter.$", this.logIt());
            //this.$scope.$watch("params.filter()[name]", this.logIt());


            //this.subscribeToTable();
            //$scope.$watch(this.tableParams, subscribeToTable());
            //$scope.$watch("tableParams", this.subscribeToTable);

            //params.filter()[name]
            //tableParams.$params.filter()[name]
            //this.$scope.$watch('params.$filter', (newValue, oldValue, scope) => {
                //Do anything with $scope.letters
                //this.$log.debug('**watch**');
            //}, true);

        });

    }

    public logIt(){
        this.$log.debug("HIT");
    }

    public filter(){
        this.LocalStorageService.storeData(this.searchName, this.search);
        this.tableParams.filter({$: this.search});
        this.tableParams.reload();
    }

    public loadData(){
        var deferred = this.$q.defer();

        //var cachedTableParams = this.LocalStorageService.getData(this.tableName);
        //if (cachedTableParams) {
        //    this.tableParams = cachedTableParams;
        //} else {
            this.tableParams = new this.NgTableParams({
                page: 1, // show first page
                count: this.count // count per page
            }, {
                filterDelay: 0,
                dataset: this.data
            });

        //this.tableParams.settings({
        //    dataset: this.data
        //});

        //}

        this.$log.debug("dmlesPanelTableController > loadData: PanelTable data loaded");
        deferred.resolve(null);
        return deferred.promise;
    }

    public subscribeToTable(tableParams){
        if (!tableParams) return;

        var logAfterCreatedEvent = this.logEvent (this.tableEvents, "afterCreated");
        this.ngTableEventsChannel.onAfterCreated(logAfterCreatedEvent, this.$scope, this.$scope.tableParams);
        var logAfterReloadDataEvent = this.logEvent ( this.tableEvents, "afterReloadData");
        this.ngTableEventsChannel.onAfterReloadData(logAfterReloadDataEvent, this.$scope, this.$scope.tableParams);
    }

    public logEvent(list, name){
        this.$log.debug('logged event: %s', name);
        var list = list;
        var name = name;
        return () => {
            this.$log.debug(">>>>>>> " + name);
        };
    }

    public watchDataChanges(){
        this.$scope.$watch(this.$scope.data, () => {
            if(this.$scope.data){
                this.$log.debug('data delta: %s', JSON.stringify(this.$scope.data));
                this.data = this.$scope.data;

                if(this.tableParams){
                    this.tableParams.reload();
                    this.$log.debug('dmlesPanelTableController Dir watchDataChanges: table reloaded');
                }else{
                    this.loadData().then(() => {
                        this.$log.debug('dmlesPanelTableController Dir watchDataChanges: table data loaded');
                    });
                }

            }
        });
    }

    /*
    public watchTableFilters(){
        if(this.tableParams){
            this.$scope.$watch(this.tableParams.$params, () => {
                this.$log.debug('dmlesPanelTableController Dir: tableParams delta');
                this.LocalStorageService.storeData(this.tableName, this.tableParams.$params);
            }, true);
        }
    }
    */

}