import {DmlesPanelTableController} from "./dmlesPanelTable.controller";

/*
 <dmles-table id="trainingTable"
    data="vm.RequestService.request.requestInformation.training"
    columns="vm.trainingCols"
    sort-on="trainees"
    sort-descending="false"
    clickable-row="false"
 >
 </dmles-table>

 id: table ID, needed by selenium tests
 data: table data
 columns: custom headers, array of { name: 'Type', modelName: 'type', dataType: 'text' }
 sort-on: model name to sort on
 sort-descending: sort descending or ascending
 clickable: is the row clickable, if so, then the data for the row is passed back the directive controller
 */

export class DmlesPanelTable implements ng.IDirective {
    public restrict:string = "EA";
    public controller = DmlesPanelTableController;
    public controllerAs:string = 'vm';
    public bindToController:boolean = false;
    public templateUrl:string = "./src/_directives/tables/dmlesPanelTable.template.html";

    public scope:any = {
        cols: '=',
        count: '@',
        canExport: '=',
        canFilterGlobal: '=',
        canFilterByColumn: '=',
        data: '=',
        rowClick: '&',
        tableName: '@',
        title: '@'
    };

    // @ngInject
    constructor(private $log) {}

    public static Factory() {
        const directive = ($log) => new DmlesPanelTable($log);
        directive.$inject = ['$log'];
        return directive;
    }
}