import {
    DmlesPanelTableController
} from "./dmlesPanelTable.controller";

/*
 <dmles-panel-table
     can-export="true"
     can-filter-by-column="false"
     can-filter-global="true"
     can-refresh="true"
     cols="vm.pendingUsersCols"
     count="20"
     data="vm.UserProfileManagementService.pendingUsersData"
     refresh-click="vm.regRefreshClick()"
     row-click="vm.regRowClick(rowData)"
     title="Pending Registrations"
     table-name="pendingRegsTable"
 ></dmles-panel-table>

 can-export: show export button and can export table data
 can-filter-by-column: show column filters
 can-filter-global: show global search
 cols: table column info and options: DmlesPanelTableColumns Model
 count: number of records shown before paging
 data: table data
 refresh-click: callback to refresh the table's data
 row-click: clickable row and function called
 title: table title
 table-name: table ID, needed by selenium tests

 */

export class DmlesPanelTable implements ng.IDirective {
    public restrict: string = "EA";
    public controller = DmlesPanelTableController;
    public controllerAs: string = 'ctrl';
    public templateUrl: string = "./src/_directives/tables/dmlesPanelTable.template.html";

    public bindToController: any = {
        cols: '=',
        count: '@',
        canExport: '=',
        canFilterGlobal: '=',
        canFilterByColumn: '=',
        canRefresh: '=',
        data: '=',
        getClass: '&',
        //initFilter: '=',  // TODO: Doesn't work yet
        initSort: '=',
        refreshDataClick: '&',
        rowClick: '&',
        tableName: '@',
        enableLoadingMessage: '@',
        title: '@'
    };

    public scope: any = {};

    // @ngInject
    constructor(private $log) {
    }

    public static Factory() {
        const directive = ($log) => new DmlesPanelTable($log);
        directive.$inject = ['$log'];
        console.log("inside dmlesPanelTable directive Factory...");
        return directive;
    }
}