define(["require", "exports"], function (require, exports) {
    "use strict";
    var DmlesGridController = (function () {
        //@inject
        function DmlesGridController($interval, $log, $scope, AbiGridStateService, DmlesGridService) {
            var _this = this;
            this.$interval = $interval;
            this.$log = $log;
            this.$scope = $scope;
            this.AbiGridStateService = AbiGridStateService;
            this.DmlesGridService = DmlesGridService;
            this.controllerName = "DmlesGridController Directive";
            //private cacheKeyPage:string;
            //private cacheKeyFilter:string;
            //private cacheKeySearch:string;
            this.testStyle = "{width:500px}";
            this.subPanelHeadingStyle = "sub-sub-panel-heading";
            this.subPanelStyleApplied = "";
            this.DEFAULT_EXCESS_ROWS = 4;
            this.DEFAULT_MIN_ROWS_TO_SHOW = 10;
            this.DEFAULT_ROW_HEIGHT = 30;
            this.DEFAULT_VIRTUALIZATION_THRESHOLD = 20;
            this.$log.debug('%s - Start', this.controllerName);
            this.isGridLoading = true;
            // TODO: Enable caching
            //this.cacheKeyFilter = this.userPkiDn + "_" + this.tableName + "_" + "filterKey";
            //this.cacheKeySorting = this.userPkiDn + "_" + this.tableName + "_" + "sortingKey";
            ////////////////////////////////////////////////////////////////////////////////////////////////
            // For details on how and why this $scope.$watch works, refer to this page:
            // http://dotnetbyexample.blogspot.com/2014/07/angularjs-typescript-how-to-setup-watch.html 
            // other attempts to do $scope.$watch('data', ...) just don't work - perhaps variable 
            // needs fully qualified with namespace?
            ////////////////////////////////////////////////////////////////////////////////////////////////
            this.$scope.$watch(function () {
                return _this.gridData;
            }, function (newValue, oldValue) {
                _this.loadData();
            });
            this.buildOpts();
            // we get here anytime we land on a page with a ui-grid
            // including when the user navigated here using breadcrumbs (instead of a Back button with a defined goNNN() function)
            // hate to put module specific code here but couldn't think of a better way to handle the "return to page via breadcrumb" issue
            if (this.gridName) {
                this.$log.debug("%s", this.gridName);
                // if appropriate, restore ui-grid state 
                if (this.gridName === "gridAbiSearch") {
                    this.DmlesGridService.restoreProvidedGridState(this.AbiGridStateService.searchSummaryResultsGridState);
                }
            }
        }
        DmlesGridController.prototype.buildOpts = function () {
            var _this = this;
            if (this.gridIsSub) {
                this.subPanelStyleApplied = this.subPanelHeadingStyle;
            }
            var exportFilename = "logiColeData.csv";
            if (this.gridOpts.exporterCsvFilename) {
                exportFilename = this.gridOpts.exporterCsvFilename;
            }
            if (!this.gridName) {
                this.gridName = "logiColeGrid-" + new Date().getTime();
            }
            this.gridOptions = {
                appScopeProvider: this.gridOpts.appScopeProvider,
                data: null,
                enableCellEditOnFocus: this.gridOpts.enableCellEditOnFocus,
                enableColumnResizing: this.gridOpts.enableColumnResizing,
                enableFiltering: this.gridOpts.enableFiltering,
                enableGridMenu: this.gridOpts.enableGridMenu,
                enablePaginationControls: this.gridOpts.enablePaginationControls,
                enableRowHeaderSelection: this.gridOpts.enableRowHeaderSelection,
                enableRowSelection: this.gridOpts.enableRowSelection,
                enableSelectAll: this.gridOpts.enableSelectAll,
                enableSorting: this.gridOpts.enableSorting,
                excessRows: (this.gridOpts.excessRows) ? this.gridOpts.excessRows : this.DEFAULT_EXCESS_ROWS,
                exporterCsvFilename: exportFilename,
                exporterMenuPdf: false,
                fastWatch: true,
                multiSelect: this.gridOpts.multiSelect,
                minRowsToShow: (this.gridOpts.minRowsToShow) ? this.gridOpts.minRowsToShow : this.DEFAULT_MIN_ROWS_TO_SHOW,
                paginationPageSizes: [25, 50, 75],
                paginationPageSize: 25,
                rowHeight: (this.gridOpts.rowHeight) ? this.gridOpts.rowHeight : this.DEFAULT_ROW_HEIGHT,
                showGridFooter: this.gridOpts.showGridFooter,
                showColumnFooter: this.gridOpts.showColumnFooter,
                virtualizationThreshold: (this.gridOpts.virtualizationThreshold) ? this.gridOpts.virtualizationThreshold : this.DEFAULT_VIRTUALIZATION_THRESHOLD,
                importerDataAddCallback: function importerDataAddCallback(grid, newObjects) {
                    this.gridOpts.data = this.data.concat(newObjects);
                },
                columnDefs: this.gridOpts.columnDefs,
                onRegisterApi: function (gridApi) {
                    _this.gridApi = gridApi;
                    _this.DmlesGridService.setGridApi(gridApi);
                    _this.$interval(function () {
                        _this.determineHeightWidth();
                    }, 0, 1);
                    // Select or UnSelect One, Note: Only Select calls the parent method
                    _this.gridApi.selection.on.rowSelectionChanged(_this.$scope, function (row) {
                        var msg = 'row selected ' + row.isSelected;
                        if (row.isSelected) {
                            //this.$log.debug("%s - Row selected: %s", this.controllerName, JSON.stringify(row.entity));
                            // Calls parent controller to pass selected data
                            _this.$scope.gridSelect({ rowData: row.entity });
                        }
                        else {
                        }
                    });
                    // Select or UnSelect All, Note: Only Select calls the parent method
                    _this.gridApi.selection.on.rowSelectionChangedBatch(_this.$scope, function (rows) {
                        var msg = 'rows changed ' + rows.length;
                        _this.$log.debug("%s - %s", _this.controllerName, msg);
                        if (rows.length > 0) {
                            // Calls parent controller to pass selected data
                            _this.$scope.gridSelectMany({ rowDataArray: rows });
                        }
                        else {
                        }
                    });
                }
            };
        };
        DmlesGridController.prototype.determineHeightWidth = function () {
            if (this.gridStyleHeight || this.gridStyleWidth) {
                if (this.gridStyleHeight && this.gridStyleWidth) {
                    this.gridStyle = "height:" + this.gridStyleHeight + "; " + "width:" + this.gridStyleWidth + ";";
                }
                else if (!this.gridStyleHeight && this.gridStyleWidth) {
                    this.gridStyle = "width:" + this.gridStyleWidth + ";";
                }
                else if (this.gridStyleHeight && !this.gridStyleWidth) {
                    this.gridStyle = "height:" + this.gridStyleHeight + ";";
                }
                if (this.gridStyleWidth) {
                    this.gridPanelStyle = "width:" + this.gridStyleWidth + ";";
                }
                this.$log.debug("%s - Custom Height: %s and Width: %s", this.controllerName, this.gridStyleHeight, this.gridStyleWidth);
            }
        };
        DmlesGridController.prototype.loadData = function () {
            if (Array.isArray(this.gridData) && this.gridOpts) {
                this.gridOptions.data = this.gridData;
                this.$log.debug("this.gridOptions.data.length: %d", this.gridOptions.data.length);
                this.isGridLoading = false;
                this.$log.debug("%s - Loaded from the watcher", this.controllerName);
            }
        };
        DmlesGridController.prototype.applyCachedParams = function () {
            // TODO
        };
        // TODO
        DmlesGridController.prototype.refreshDataClick = function () {
            this.$log.debug("%s - Refresh Grid Clicked", this.controllerName);
            this.$scope.gridRefresh(); // Calls parent controller to refresh data
        };
        return DmlesGridController;
    }());
    exports.DmlesGridController = DmlesGridController;
});
//# sourceMappingURL=dmlesGrid.controller.js.map