define(["require", "exports", "./dmlesPanelTable.controller"], function (require, exports, dmlesPanelTable_controller_1) {
    "use strict";
    /*
     <dmles-panel-table
         can-export="true"
         can-filter-by-column="false"
         can-filter-global="true"
         cols="vm.pendingUsersCols"
         count="20"
         data="vm.UserProfileManagementService.pendingUsersData"
         row-click="vm.regRowClick(rowData)"
         title="Pending Registrations"
         table-name="pendingRegsTable"
     ></dmles-panel-table>
    
     can-export: show export button and can export table data
     can-filter-by-column: show column filters
     can-filter-global: show global search
     cols: table column info and options: DmlesPanelTableColumns Model
     count: number of records shown before paging
     data: table data
     row-click: clickable row and function called
     title: table title
     table-name: table ID, needed by selenium tests
    
     */
    var DmlesPanelTable = (function () {
        // @ngInject
        function DmlesPanelTable($log) {
            this.$log = $log;
            this.restrict = "EA";
            this.controller = dmlesPanelTable_controller_1.DmlesPanelTableController;
            this.controllerAs = 'ctrl';
            this.templateUrl = "./src/_directives/tables/dmlesPanelTable.template.html";
            this.bindToController = {
                cols: '=',
                count: '@',
                canExport: '=',
                canFilterGlobal: '=',
                canFilterByColumn: '=',
                data: '=',
                getClass: '&',
                //initFilter: '=',  // TODO: Doesn't work yet
                initSort: '=',
                rowClick: '&',
                tableName: '@',
                title: '@'
            };
            this.scope = {};
        }
        DmlesPanelTable.Factory = function () {
            var directive = function ($log) { return new DmlesPanelTable($log); };
            directive.$inject = ['$log'];
            return directive;
        };
        return DmlesPanelTable;
    }());
    exports.DmlesPanelTable = DmlesPanelTable;
});
//# sourceMappingURL=dmlesPanelTable.directive.js.map