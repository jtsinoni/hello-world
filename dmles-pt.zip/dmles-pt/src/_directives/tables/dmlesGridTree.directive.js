define(["require", "exports", "./dmlesGridTree.controller"], function (require, exports, dmlesGridTree_controller_1) {
    "use strict";
    /*
    UI Grid Ref: http://ui-grid.info/docs/#/tutorial
    */
    var DmlesGridTree = (function () {
        // @ngInject
        function DmlesGridTree($log) {
            this.$log = $log;
            this.restrict = "EA";
            this.controller = dmlesGridTree_controller_1.DmlesGridTreeController;
            this.controllerAs = 'ctrl';
            this.templateUrl = "./src/_directives/tables/dmlesGridTree.template.html";
            this.bindToController = {
                treeId: '@',
                treeData: '=',
                treeOptions: '=',
                treeIsLoading: '=',
                treeItemPreSelection: '=',
                treeItemScrollTo: '=',
                height: '@',
                width: '@'
            };
            this.scope = {
                treeItemSelection: '&',
            };
        }
        DmlesGridTree.Factory = function () {
            var directive = function ($log) { return new DmlesGridTree($log); };
            directive.$inject = ['$log'];
            return directive;
        };
        return DmlesGridTree;
    }());
    exports.DmlesGridTree = DmlesGridTree;
});
//# sourceMappingURL=dmlesGridTree.directive.js.map