import {
    DmlesCheckboxTableController
} from "./dmlesCheckboxTable.controller";

/*
 <dmles-checkbox-table 
    cols="vm.productsColumns" 
    count="20" 
    data="vm.productsData" 
    can-export="true" 
    can-filter-global="true"
    can-filter-by-column="false" 
    can-refresh="true" 
    init-sort="vm.pendingUsersInitialSort" 
    row-click="vm.regRowClick(rowData)"
    title="ABi Staging" 
    table-name="productsTable" 
    selected-rows="vm.selectedRows"
    placeholder-text="Filter ..."
    >
</dmles-checkbox-table>

 can-export: show export button and can export table data
 can-filter-by-column: show column filters
 can-filter-global: show global search
 cols: table column info and options: DmlesPanelTableColumns Model
 count: number of records shown before paging
 data: table data
 refresh-click: callback to refresh the table's data
 row-click: clickable row and function called
 title: table title
 table-name: table ID, needed by selenium tests
 selected-rows: an array of row numbers that are currently selected
 placeholder-text: text string defining placeholder for filter search 
                   text box. Defaults to 'Search ...'
 */

//////////////////////////////////////////////////////////////////////////////
// NOTE: The 'data' attribute of this directive must contain an array of
// objects that have properties corresponding to the properties in cols
// array.
//
// For the checkbox processing to work, each row in the data array
// must have a unique 'id' field.
// 
// The selectedRows (selected-rows) attribute of this directive is a two
// way binding that contains row indexes for selected rows (e.g. [ 3, 7, 8])
//
//////////////////////////////////////////////////////////////////////////////
export class DmlesCheckboxTable implements ng.IDirective {
    public restrict: string = "EA";
    public controller = DmlesCheckboxTableController;
    public controllerAs: string = 'ctrl';
    public templateUrl: string = "./src/_directives/tables/dmlesCheckboxTable.template.html";

    public bindToController: any = {
        cols: '=',
        canExport: '=',
        canFilterGlobal: '=',
        canFilterByColumn: '=',
        canRefresh: '=',
        data: '=',
        //initFilter: '=',  // TODO: Doesn't work yet
        initSort: '=',
        tableName: '@',
        enableLoadingMessage: '@',
        title: '@',
        selectedRows: '=',
        placeholderText: '@',
        filteredRowCount: '=',
        allowRowClick: '@',
    };

    public scope: any = {
        refreshDataClick: '&',
        rowClick: '&',
    };

    // @ngInject
    constructor(private $log) {
    }

    public static Factory() {
        const directive = ($log) => new DmlesCheckboxTable($log);
        directive.$inject = ['$log'];
        return directive;
    }
}