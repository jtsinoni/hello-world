import {DmlesCheckboxTableController} from './dmlesCheckboxTable.controller';
import {DmlesCheckboxTable} from './dmlesCheckboxTable.directive';
import {DmlesGridController} from './dmlesGrid.controller';
import {DmlesGridTreeController} from './dmlesGridTree.controller';
import {DmlesGrid} from './dmlesGrid.directive';
import {DmlesGridTree} from './dmlesGridTree.directive';
import {DmlesPanelTableController} from './dmlesPanelTable.controller';
import {DmlesPanelTable} from './dmlesPanelTable.directive';
import {DmlesTable} from './dmlesTable.directive';
import {DmlesTableController} from './dmlesTable.controller';

var dmlesTableModule = angular.module('DmlesTableModule', []);

dmlesTableModule.controller('DmlesCheckboxTableController', DmlesCheckboxTableController);
dmlesTableModule.controller('DmlesGridController', DmlesGridController);
dmlesTableModule.controller('DmlesGridTreeController', DmlesGridTreeController);
dmlesTableModule.controller('DmlesPanelTableController', DmlesPanelTableController);
dmlesTableModule.controller('DmlesTableController', DmlesTableController);

dmlesTableModule.directive('dmlesCheckboxTable', DmlesCheckboxTable.Factory());
dmlesTableModule.directive('dmlesGrid', DmlesGrid.Factory());
dmlesTableModule.directive('dmlesGridTree', DmlesGridTree.Factory());
dmlesTableModule.directive('dmlesPanelTable', DmlesPanelTable.Factory());
dmlesTableModule.directive('dmlesTable', DmlesTable.Factory());
dmlesTableModule.directive('dmlesTable', DmlesTable.Factory());

export default dmlesTableModule;