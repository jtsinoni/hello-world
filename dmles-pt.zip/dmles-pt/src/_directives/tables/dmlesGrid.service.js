define(["require", "exports"], function (require, exports) {
    'use strict';
    var DmlesGridService = (function () {
        // @ngInject
        function DmlesGridService($log, $timeout, uiGridConstants) {
            this.$log = $log;
            this.$timeout = $timeout;
            this.uiGridConstants = uiGridConstants;
            this.gridState = {};
            this.$log.debug("DmlesGridService initialized");
        }
        DmlesGridService.prototype.setGridApi = function (gridApi) {
            this.gridApi = gridApi;
        };
        DmlesGridService.prototype.clearAllFilters = function () {
            var _this = this;
            if (this.gridApi) {
                this.$log.debug("DmlesGridService - clearAllFilters()");
                this.$timeout(function () {
                    _this.gridApi.grid.clearAllFilters();
                }, 0);
            }
        };
        DmlesGridService.prototype.handleWindowResize = function () {
            var _this = this;
            if (this.gridApi) {
                this.$log.debug("DmlesGridService - handleWindowResize()");
                this.$timeout(function () {
                    _this.gridApi.core.handleWindowResize();
                }, 0);
            }
        };
        DmlesGridService.prototype.notifyDataChangeAll = function () {
            var _this = this;
            if (this.gridApi) {
                this.$log.debug("DmlesGridService - notifyDataChangeAll()");
                this.$timeout(function () {
                    _this.gridApi.core.notifyDataChange(_this.uiGridConstants.dataChange.ALL);
                }, 0);
            }
        };
        DmlesGridService.prototype.notifyDataChangeOptions = function () {
            var _this = this;
            if (this.gridApi) {
                this.$log.debug("DmlesGridService - notifyDataChangeOptions()");
                this.$timeout(function () {
                    _this.gridApi.core.notifyDataChange(_this.uiGridConstants.dataChange.OPTIONS);
                }, 0);
            }
        };
        DmlesGridService.prototype.queueGridRefresh = function () {
            var _this = this;
            if (this.gridApi) {
                this.$log.debug("DmlesGridService - queueGridRefresh()");
                this.$timeout(function () {
                    _this.gridApi.core.queueGridRefresh();
                }, 0);
            }
        };
        DmlesGridService.prototype.refresh = function () {
            var _this = this;
            if (this.gridApi) {
                this.$log.debug("DmlesGridService - refresh()");
                this.$timeout(function () {
                    _this.gridApi.core.refresh();
                }, 0);
            }
        };
        DmlesGridService.prototype.refreshRows = function () {
            var _this = this;
            if (this.gridApi) {
                this.$log.debug("DmlesGridService - refreshRows()");
                this.$timeout(function () {
                    _this.gridApi.core.refreshRows();
                }, 0);
            }
        };
        // uses this.gridState
        DmlesGridService.prototype.restoreGridState = function () {
            var _this = this;
            if (this.gridApi) {
                this.$log.debug("DmlesGridService - restoreState()");
                this.$timeout(function () {
                    _this.gridApi.saveState.restore(_this, _this.gridState);
                }, 0);
            }
        };
        // uses passed in gridState
        DmlesGridService.prototype.restoreProvidedGridState = function (gridState) {
            var _this = this;
            if (this.gridApi) {
                this.$log.debug("DmlesGridService - restorePassedInState()");
                this.$timeout(function () {
                    _this.gridApi.saveState.restore(_this, gridState);
                }, 0);
            }
        };
        // uses this.gridState
        DmlesGridService.prototype.saveGridState = function () {
            if (this.gridApi) {
                this.$log.debug("DmlesGridService - saveState()");
                this.gridState = this.gridApi.saveState.save();
            }
        };
        // returns gridState to calling function
        DmlesGridService.prototype.retrieveGridState = function () {
            if (this.gridApi) {
                this.$log.debug("DmlesGridService - saveState()");
                return this.gridApi.saveState.save();
            }
        };
        return DmlesGridService;
    }());
    exports.DmlesGridService = DmlesGridService;
});
//# sourceMappingURL=dmlesGrid.service.js.map