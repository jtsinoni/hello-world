export class DmlesGridTreeController {
    private controllerName:string = "DmlesGridTreeController Directive";

    private origData:any;

    public gridTreeApi:any;

    public searchText:string;
    public gridTreeOptions:any;
    public treeDataLoading:boolean;
    public gridTreeStyle:string;

    // Passed in from the directive
    public treeData:any;
    public treeId:string;
    public treeOptions:any;
    public treeIsLoading:boolean;
    public treeItemPreSelection:any;
    public treeItemScrollTo:any;
    public height:string;
    public width:string;

    //@inject
    constructor(private $filter, private $interval, private $log, private $scope, private $timeout, private uiGridConstants, private uiGridTreeViewConstants) {
        this.$log.debug('%s - Start', this.controllerName);

        this.treeDataLoading = true;
        this.determineHeightWidth();

        // Watches for data changes from parent
        this.$scope.$watch(() => { return this.treeData; }, (newValue, oldValue) => {
            this.treeDataLoading = true;
            this.loadData();
        });

        this.buildOpts();
    }

    private buildOpts(){

        if(!this.treeId){
            this.treeId = "logiColeTree-" + new Date().getTime();
        }

        this.gridTreeOptions = {
            enableColumnMenus:        false,
            enableRowSelection:       this.treeOptions.enableRowSelection,
            enableRowHeaderSelection: this.treeOptions.enableRowHeaderSelection,
            enableSelectAll:          false,
            multiSelect:              this.treeOptions.multiSelect,
            selectionRowHeaderWidth:  this.treeOptions.selectionRowHeaderWidth,
            rowHeight:                this.treeOptions.rowHeight,
            showGridFooter:           this.treeOptions.showGridFooter,
            enableFiltering:          true,
            showTreeExpandNoChildren: false,
            columnDefs:               this.treeOptions.columnDefs,
            onRegisterApi: ( gridTreeApi ) => {
                this.gridTreeApi = gridTreeApi;

                // Select or UnSelect One, Note: Only Select calls the parent method
                this.gridTreeApi.selection.on.rowSelectionChanged(this.$scope,(row)=>{
                    var msg = 'row selected ' + row.isSelected;
                    if(row.isSelected){
                        this.$log.debug("%s - Row selected: %s", this.controllerName, JSON.stringify(row.entity));
                        // Calls parent controller to pass selected data
                        this.$scope.treeItemSelection( { itemData : row.entity } );
                    }else{
                        this.$log.debug("%s - Row unselected: %s", this.controllerName, JSON.stringify(row.entity));
                    }

                });

                // this.gridTreeApi.cellNav.on.navigate(null, function(newRowCol, oldRowCol){
                //     this.gridTreeApi.selection.selectRow(newRowCol.row.entity);
                //     this.gridTreeApi.core.notifyDataChange( this.gridTreeApi.grid,  this.uiGridConstants.dataChange.COLUMN );
                //
                //     this.$log.debug("%s - Row selected: %s", this.controllerName, JSON.stringify(newRowCol.row.entity));
                //     // Calls parent controller to pass selected data
                //     this.$scope.treeItemSelection( { itemData : newRowCol.row.entity } );
                //
                // });

                this.checkIfLoaded();
            }
        };

    }

    private checkIfLoaded(){
        if(this.gridTreeOptions && Array.isArray(this.gridTreeOptions.data)){
            this.treeDataLoading = false;
            this.$log.debug("%s - Tree loaded", this.controllerName);
        }
    }

    private determineHeightWidth(){
        if(this.height || this.width){
            if(this.height && this.width){
                this.gridTreeStyle = "{'height' : '" + this.height + "', " + " 'width' : '" + this.width + "'}";
            }
            else if(!this.height && this.width){
                this.gridTreeStyle = "{'width' : '" + this.width + "'}";
            }
            else if(this.height && !this.width){
                this.gridTreeStyle = "{'height' : " + this.height + "'}";
            }
        }
    }

    private loadData(){
        if(Array.isArray(this.treeData) && this.gridTreeOptions){
            this.gridTreeOptions.data = this.treeData;

            // pre select a row
            if(this.gridTreeApi){

                // $interval whilst we wait for the grid to digest the data we just gave it
                // Auto select's a row
                this.$interval( ()=> {
                    this.expandAll();

                    if(this.treeItemPreSelection){
                        this.$log.debug("%s - Pre-selection applied for item: %s", this.controllerName, this.treeItemPreSelection);
                        this.gridTreeApi.selection.selectRow(this.gridTreeOptions.data[this.treeItemPreSelection]);
                        //this.scrollTo(this.treeItemScrollTo);

                        this.$timeout( ()=> {
                            this.searchText = this.gridTreeOptions.data[this.treeItemPreSelection].name;
                            this.filterTree();
                        }, 500);

                    }

                    if(this.treeItemScrollTo){
                        this.scrollTo(this.treeItemScrollTo);
                    }

                }, 0, 1);


            }

            this.checkIfLoaded();
            this.$log.debug("%s - Loaded from the watcher", this.controllerName);
        }
    }

    private scrollTo( rowIndex ) {
        if(this.treeItemScrollTo && rowIndex) {
            this.$timeout(()=> {
                this.gridTreeApi.cellNav.scrollToFocus(this.gridTreeOptions.data[rowIndex], this.gridTreeOptions.columnDefs[1]);
            }, 1000);
        }
    }

    public clearAll(){
        this.gridTreeApi.selection.clearSelectedRows();
        this.gridTreeApi.grid.clearAllFilters();
        this.gridTreeApi.treeBase.collapseAllRows();
    }

    public expandAll(){
        this.gridTreeApi.treeBase.expandAllRows();
    }

    public filterTree(){
        this.gridTreeApi.grid.columns[2].filters[0].term=this.searchText;
        this.$log.debug("%s - filtered on: %s", this.controllerName, this.searchText);
    }

}