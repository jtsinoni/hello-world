define(["require", "exports"], function (require, exports) {
    "use strict";
    var DmlesTestController = (function () {
        //@inject
        function DmlesTestController($log, $compile, $element, $scope) {
            this.$log = $log;
            this.$compile = $compile;
            this.$element = $element;
            this.$scope = $scope;
            this.controllerName = "DmlesTestController";
            this.$log.debug('%s - Start', this.controllerName);
            this.init();
        }
        DmlesTestController.prototype.init = function () {
            this.items = angular.copy(this.$scope.datasource);
            this.$log.debug('%s - Init', this.controllerName);
        };
        DmlesTestController.prototype.addItem = function (item) {
            this.items.push({
                name: item
            });
            this.$log.debug('%s - Push', this.controllerName);
        };
        return DmlesTestController;
    }());
    exports.DmlesTestController = DmlesTestController;
});
//# sourceMappingURL=dmlesTest.controller.js.map