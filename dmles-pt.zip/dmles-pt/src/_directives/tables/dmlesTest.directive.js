define(["require", "exports", "./dmlesTest.controller"], function (require, exports, dmlesTest_controller_1) {
    "use strict";
    var DmlesTest = (function () {
        // @ngInject
        function DmlesTest($log) {
            this.$log = $log;
            this.restrict = "EA";
            this.controller = dmlesTest_controller_1.DmlesTestController;
            this.controllerAs = 'vm';
            this.bindToController = false; //required in 1.3+ with controllerAs
            this.templateUrl = "./src/_directives/tables/dmlesTest.template.html";
            this.scope = {
                datasource: '=',
                add: '&'
            };
        }
        DmlesTest.Factory = function () {
            var directive = function ($log) { return new DmlesTest($log); };
            directive.$inject = ['$log'];
            return directive;
        };
        return DmlesTest;
    }());
    exports.DmlesTest = DmlesTest;
});
//# sourceMappingURL=dmlesTest.directive.js.map