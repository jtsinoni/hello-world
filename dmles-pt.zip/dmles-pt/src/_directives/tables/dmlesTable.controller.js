define(["require", "exports"], function (require, exports) {
    "use strict";
    var DmlesTableController = (function () {
        //@inject
        function DmlesTableController($log, $scope) {
            this.$log = $log;
            this.$scope = $scope;
            this.controllerName = "DmlesTableController";
            this.clickableRow = false;
            this.sortDescending = false;
            this.$log.debug('%s - Start', this.controllerName);
            this.data = this.$scope.data;
            this.columns = this.$scope.columns;
            this.id = this.$scope.id;
            if (this.$scope.clickableRow) {
                this.clickableRow = this.$scope.clickableRow;
                this.$log.debug('clickableRow: %s', this.clickableRow);
            }
            if (this.$scope.sortOn) {
                this.sortOn = this.$scope.sortOn;
            }
            if (this.$scope.sortDescending) {
                this.sortDescending = this.$scope.sortDescending;
            }
        }
        DmlesTableController.prototype.addItem = function (item) {
            this.$log.debug('%s - Table Row Clicked: %s', this.controllerName, JSON.stringify(item));
            return false;
        };
        DmlesTableController.prototype.headerClick = function (item) {
            this.$log.debug('%s - Header Clicked: %s', this.controllerName, JSON.stringify(item));
            this.sortOn = item;
            this.sortDescending = !this.sortDescending;
        };
        return DmlesTableController;
    }());
    exports.DmlesTableController = DmlesTableController;
});
//# sourceMappingURL=dmlesTable.controller.js.map