define(["require", "exports", './dmlesCheckboxTable.controller', './dmlesCheckboxTable.directive', './dmlesGrid.controller', './dmlesGrid.service', './dmlesGridTree.controller', './dmlesGrid.directive', './dmlesGridTree.directive', './dmlesPanelTable.controller', './dmlesPanelTable.directive', './dmlesTable.directive', './dmlesTable.controller'], function (require, exports, dmlesCheckboxTable_controller_1, dmlesCheckboxTable_directive_1, dmlesGrid_controller_1, dmlesGrid_service_1, dmlesGridTree_controller_1, dmlesGrid_directive_1, dmlesGridTree_directive_1, dmlesPanelTable_controller_1, dmlesPanelTable_directive_1, dmlesTable_directive_1, dmlesTable_controller_1) {
    "use strict";
    var dmlesTableModule = angular.module('DmlesTableModule', []);
    dmlesTableModule.controller('DmlesCheckboxTableController', dmlesCheckboxTable_controller_1.DmlesCheckboxTableController);
    dmlesTableModule.controller('DmlesGridController', dmlesGrid_controller_1.DmlesGridController);
    dmlesTableModule.controller('DmlesGridTreeController', dmlesGridTree_controller_1.DmlesGridTreeController);
    dmlesTableModule.controller('DmlesPanelTableController', dmlesPanelTable_controller_1.DmlesPanelTableController);
    dmlesTableModule.controller('DmlesTableController', dmlesTable_controller_1.DmlesTableController);
    dmlesTableModule.directive('dmlesCheckboxTable', dmlesCheckboxTable_directive_1.DmlesCheckboxTable.Factory());
    dmlesTableModule.directive('dmlesGrid', dmlesGrid_directive_1.DmlesGrid.Factory());
    dmlesTableModule.directive('dmlesGridTree', dmlesGridTree_directive_1.DmlesGridTree.Factory());
    dmlesTableModule.directive('dmlesPanelTable', dmlesPanelTable_directive_1.DmlesPanelTable.Factory());
    dmlesTableModule.directive('dmlesTable', dmlesTable_directive_1.DmlesTable.Factory());
    dmlesTableModule.directive('dmlesTable', dmlesTable_directive_1.DmlesTable.Factory());
    dmlesTableModule.service('DmlesGridService', dmlesGrid_service_1.DmlesGridService);
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = dmlesTableModule;
});
//# sourceMappingURL=module.js.map