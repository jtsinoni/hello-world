export class DmlesGridController {
    private controllerName:string = "DmlesGridController Directive";

    //private cacheKeyPage:string;
    //private cacheKeyFilter:string;
    //private cacheKeySearch:string;

    private gridApi:any;
    private currentState:string;

    public exportFilename:string;
    public gridOptions:any;
    public isGridLoading:boolean;
    public subPanelHeadingStyle:string = "sub-sub-panel-heading";
    public subPanelStyleApplied:string = "";

    // Passed in from the directive
    public gridCanRefresh:boolean;
    public gridOpts:any;
    public gridData:any;
    public gridIsSub:boolean;
    public gridName:string;
    public gridLoadingMessage:string;
    public gridStyle:string;
    public gridStyleHeight:string;
    public gridStyleWidth:string;
    public gridTitle:string;
    public gridTitleIcon:string;

    //@inject
    constructor(private $log, private $scope, private uiGridConstants) {
        this.$log.debug('%s - Start', this.controllerName);

        this.isGridLoading = true;
        this.determineHeightWidth();

        // TODO: Enable caching
        //this.cacheKeyFilter = this.userPkiDn + "_" + this.tableName + "_" + "filterKey";
        //this.cacheKeySorting = this.userPkiDn + "_" + this.tableName + "_" + "sortingKey";

        ////////////////////////////////////////////////////////////////////////////////////////////////
        // For details on how and why this $scope.$watch works, refer to this page:
        // http://dotnetbyexample.blogspot.com/2014/07/angularjs-typescript-how-to-setup-watch.html 
        // other attempts to do $scope.$watch('data', ...) just don't work - perhaps variable 
        // needs fully qualified with namespace?
        ////////////////////////////////////////////////////////////////////////////////////////////////
        this.$scope.$watch(() => { return this.gridData; }, (newValue, oldValue) => {
            this.loadData();
        });

        this.buildOpts();
    }

    private buildOpts(){

        if(this.gridIsSub){
            this.subPanelStyleApplied = this.subPanelHeadingStyle;
        }

        var exportFilename = "logiColeData.csv";
        if(this.gridOpts.exporterCsvFilename){
            exportFilename = this.gridOpts.exporterCsvFilename;
        }

        if(!this.gridName){
            this.gridName = "logiColeGrid-" + new Date().getTime();
        }

        this.gridOptions = {
            data: null,
            enableCellEditOnFocus:    this.gridOpts.enableCellEditOnFocus,
            enableColumnResizing:     this.gridOpts.enableColumnResizing,
            enableFiltering:          this.gridOpts.enableFiltering,
            enableGridMenu:           this.gridOpts.enableGridMenu,
            enablePaginationControls: this.gridOpts.enablePaginationControls,
            enableRowHeaderSelection: this.gridOpts.enableRowHeaderSelection,
            enableRowSelection:       this.gridOpts.enableRowSelection,
            enableSelectAll:          this.gridOpts.enableSelectAll,
            enableSorting:            this.gridOpts.enableSorting,
            exporterCsvFilename:      exportFilename,
            exporterMenuPdf:          false,
            fastWatch:                true,
            multiSelect:              this.gridOpts.multiSelect,
            paginationPageSizes:      [25, 50, 75],
            paginationPageSize:       25,
            showGridFooter:           this.gridOpts.showGridFooter,
            showColumnFooter:         this.gridOpts.showColumnFooter,
            importerDataAddCallback: function importerDataAddCallback( grid, newObjects )  {
                this.gridOpts.data = this.data.concat( newObjects );
            },
            columnDefs: this.gridOpts.columnDefs,
            onRegisterApi: ( gridApi ) => {
                this.gridApi = gridApi;

                // Select or UnSelect One, Note: Only Select calls the parent method
                this.gridApi.selection.on.rowSelectionChanged(this.$scope,(row)=>{
                    var msg = 'row selected ' + row.isSelected;
                    if(row.isSelected){
                        //this.$log.debug("%s - Row selected: %s", this.controllerName, JSON.stringify(row.entity));
                        // Calls parent controller to pass selected data
                        this.$scope.gridSelect( { rowData : row.entity } );
                    }else{
                        //this.$log.debug("%s - Row unselected: %s", this.controllerName, JSON.stringify(row.entity));
                    }

                });

                // Select or UnSelect All, Note: Only Select calls the parent method
                this.gridApi.selection.on.rowSelectionChangedBatch(this.$scope,(rows)=>{
                    var msg = 'rows changed ' + rows.length;
                    this.$log.debug("%s - %s", this.controllerName, msg);

                    if(rows.length > 0){
                        // Calls parent controller to pass selected data
                        this.$scope.gridSelectMany( { rowDataArray : rows } );
                    }else{
                        //this.$log.debug("%s - Rows unselected: %s", this.controllerName);
                    }

                });


            }
        };

    }

    private determineHeightWidth(){
        if(this.gridStyleHeight && this.gridStyleWidth){
            this.gridStyle = this.gridStyleHeight + " " + this.gridStyleWidth;
        }
        else if(!this.gridStyleHeight && this.gridStyleWidth){
            this.gridStyle = this.gridStyleWidth;
        }
        else if(this.gridStyleHeight && !this.gridStyleWidth){
            this.gridStyle = this.gridStyleHeight;
        }
    }

    private loadData(){
        if(Array.isArray(this.gridData) && this.gridOpts){
            this.gridOptions.data = this.gridData;
            this.isGridLoading = false;
            this.$log.debug("%s - Loaded from the watcher", this.controllerName);
        }
    }

    private applyCachedParams(){
        // TODO

    }

    // TODO
    public refreshDataClick(){
        this.$log.debug("%s - Refresh Grid Clicked", this.controllerName);
        this.$scope.gridRefresh();  // Calls parent controller to refresh data
    }

    /*
     $scope.addData = function() {
     var n = $scope.gridOpts.data.length + 1;
     $scope.gridOpts.data.push({
     "firstName": "New " + n,
     "lastName": "Person " + n,
     "company": "abc",
     "employed": true,
     "gender": "male"
     });
     };
     */

    /*
     $scope.getCurrentFocus = function(){
     var rowCol = $scope.gridApi.cellNav.getFocusedCell();
     if(rowCol !== null) {
     $scope.currentFocused = 'Row Id:' + rowCol.row.entity.id + ' col:' + rowCol.col.colDef.name;
     }
     };
     */

    /*
     $scope.scrollTo = function( rowIndex, colIndex ) {
     $scope.gridApi.core.scrollTo( $scope.gridOptions.data[rowIndex], $scope.gridOptions.columnDefs[colIndex]);
     };

     $scope.scrollToFocus = function( rowIndex, colIndex ) {
     $scope.gridApi.cellNav.scrollToFocus( $scope.gridOptions.data[rowIndex], $scope.gridOptions.columnDefs[colIndex]);
     };
     */

}