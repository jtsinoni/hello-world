export class DmlesTableController {
    private controllerName:string = "DmlesTableController";

    public clickableRow:boolean = false;
    public columns:any;
    public data:any;
    public id:string;
    public sortOn:string;
    public sortDescending:boolean = false;

    //@inject
    constructor(private $log, public $scope) {
        this.$log.debug('%s - Start', this.controllerName);

        this.data = this.$scope.data;
        this.columns = this.$scope.columns;
        this.id = this.$scope.id;

        if(this.$scope.clickableRow){
            this.clickableRow = this.$scope.clickableRow;
            this.$log.debug('clickableRow: %s', this.clickableRow);
        }

        if(this.$scope.sortOn){
            this.sortOn = this.$scope.sortOn;
        }

        if(this.$scope.sortDescending){
            this.sortDescending = this.$scope.sortDescending;
        }

    }

    public addItem(item){
        this.$log.debug('%s - Table Row Clicked: %s', this.controllerName, JSON.stringify(item));
        return false;
    }

    public headerClick(item){
        this.$log.debug('%s - Header Clicked: %s', this.controllerName, JSON.stringify(item));
        this.sortOn = item;
        this.sortDescending = !this.sortDescending;
    }

}