import {DmlesTestController} from "./dmlesTest.controller";
export class DmlesTest implements ng.IDirective {
    public restrict:string = "EA";
    public controller = DmlesTestController;
    public controllerAs:string = 'vm';
    public bindToController:boolean = false; //required in 1.3+ with controllerAs
    public templateUrl:string = "./src/_directives/tables/dmlesTest.template.html";

    public scope:any = {
        datasource: '=',
        add: '&'
    };

    // @ngInject
    constructor(private $log) {}

    public static Factory() {
        const directive = ($log) => new DmlesTest($log);
        directive.$inject = ['$log'];
        return directive;
    }
}