export class DmlesCheckboxTableController {
    private controllerName:string = "DmlesPanelTableController Directive";

    private allTableEvents:any[] = [];
    private cacheKeyPage:string;
    private cacheKeyFilter:string;
    private cacheKeySearch:string;
    //private cacheKeySorting:string;
    private userPkiDn:string;

    public exportFilename:string;
    public exportHeaders:string[] = [];
    public exportExtension:string = ".csv";
    public isLoading:boolean;
    public tableParams:any;
    public search:string;
    public searchName:string;

    // Passed in from the directive
    public cols:any;
    public count:number;
    public canExport:boolean;
    public canFilterGlobal:boolean;
    public canFilterByColumn:boolean;
    public canRefresh:boolean;
    public data:any;
    //public initFilter:any;
    public initSort:any;
    public title:string;
    public tableName:string;
    public selectedRows: Array<number> = [];
    public placeholderText: string;

    //@inject
    constructor(public $scope, private $log, private $q, private $timeout, private LocalStorageService, private ngTableEventsChannel,  private NgTableParams,
                private UserService, private UtilService, private $document) {
        this.$log.debug('%s - Start', this.controllerName);

        this.isLoading = true;
        this.userPkiDn = this.UserService.currentUser.pkiDn;
        this.cacheKeyPage = this.userPkiDn + "_" + this.tableName + "_" + "pageKey";
        this.cacheKeySearch = this.userPkiDn + "_" + this.tableName + "_" + "searchKey";
        this.cacheKeyFilter = this.userPkiDn + "_" + this.tableName + "_" + "filterKey";
        //this.cacheKeySorting = this.userPkiDn + "_" + this.tableName + "_" + "sortingKey";
        this.allTableEvents = [];

        this.setFilterPlaceholder();

        ////////////////////////////////////////////////////////////////////////////////////////////////
        // For details on how and why this $scope.$watch works, refer to this page:
        // http://dotnetbyexample.blogspot.com/2014/07/angularjs-typescript-how-to-setup-watch.html 
        // other attempts to do $scope.$watch('data', ...) just don't work - perhaps variable 
        // needs fully qualified with namespace?
        ////////////////////////////////////////////////////////////////////////////////////////////////
        this.$scope.$watch(() => { return this.data; }, (newValue, oldValue) => {
            this.init();
        });

        ////////////////////////////////////////////////////////////////////////////////////////////////
        // The previous watch does not activate when the 'data' attribute is first set, which is why
        // it uses the (newValue, oldValue) form for the second parameter.
        // In the following watch, we want to add this column anytime the cols attribute changes, so
        // the () form for the second parameter is used.
        ////////////////////////////////////////////////////////////////////////////////////////////////
        this.$scope.$watch(() => { return this.cols; }, () => {
            this.cols[0] = { title: 'Selected', field: 'selected', show: true, sortable: 'selected', type: 'boolean', filter: null, filterData: null };
        });

        this.init();
    }

    public filter(){
        this.LocalStorageService.storeData(this.cacheKeySearch, this.search, false);
        this.tableParams.filter({$: this.search}); 
        this.tableParams.reload();
    }

    public itemSelected(rowId) {
        this.$log.debug("item " + rowId + " selected...");
        if (this.selectedRows === undefined) {
            return;
        }

        var rowDataIndex = this.FindRowIndex(this.data, rowId);

        if (rowDataIndex === -1) {
            this.$log.debug("Error - couldn't find row in data array...");
        } else {
            var selectedRowIndex = this.selectedRows.indexOf(rowDataIndex);
            if (selectedRowIndex === -1) {
                this.selectedRows.push(rowDataIndex);
            } else {
                this.selectedRows.splice(selectedRowIndex, 1);
            }
        }
        this.selectedRows.sort();
    }

    private init(){

        this.searchName = this.tableName + "Search";

        this.isLoading = false;
        this.tableParams = new this.NgTableParams({ sorting: this.initSort }, { dataset: this.data });
        this.setupExport();
        this.applyCachedParams();
        this.subscribeToTableEvents();
    }

    private applyCachedParams(){
        if(this.LocalStorageService.getData(this.cacheKeyPage)){
            var page:number = this.LocalStorageService.getData(this.cacheKeyPage);
            if(this.tableParams.page() <= page){
                this.tableParams.page(page);
                this.$log.debug("%s - Page cache applied: %s", this.controllerName, page);
            }else{
                this.LocalStorageService.storeData(this.cacheKeyPage, this.tableParams.page(), false)
            }
        }

        if(this.LocalStorageService.getData(this.cacheKeySearch)){
            this.search = this.LocalStorageService.getData(this.cacheKeySearch);
            this.tableParams.filter({$: this.search});
            this.$log.debug("%s - Global search cache applied: %s", this.controllerName, this.search);
        }

        var cachedFiltering:any = this.LocalStorageService.getData(this.cacheKeyFilter);
        if(!this.UtilService.isObjectEmpty(cachedFiltering)){
            this.$log.debug("%s - Filtering cache applied: %s", this.controllerName, JSON.stringify(cachedFiltering));
            this.tableParams.filter(cachedFiltering);
        }

        //var cachedSorting:any = this.LocalStorageService.getData(this.cacheKeySorting);
        //if(!this.UtilService.isObjectEmpty(cachedSorting)){
        //    this.$log.debug("%s - Sorting cache applied: %s", this.controllerName, JSON.stringify(cachedSorting));
        //    this.tableParams.sorting(cachedSorting);
        //}

    }

    private setupExport(){
        if(this.canExport){
            if(this.data && this.data[0] && this.exportHeaders.length == 0){
                var tableObj = this.data[0];
                this.exportHeaders = Object.keys(tableObj);

                var fileDate = new Date().getTime();
                this.exportFilename = this.title + "_export_" + fileDate + this.exportExtension;

                this.$log.debug("%s - Exporting ability setup", this.controllerName);
            }
        }
    }

    public refreshTableDirClick(){
        this.$log.debug("%s - Refresh Table Directive Clicked", this.controllerName);
        this.init();
    }

    public subscribeToTableEvents(){

        this.ngTableEventsChannel.onPagesChanged(this.logEvent(this.allTableEvents, "pageChangedEvent"), this.$scope);
        this.ngTableEventsChannel.onAfterDataFiltered(this.logEvent(this.allTableEvents, "dataFilteredEvent"), this.$scope);
        this.ngTableEventsChannel.onAfterDataSorted(this.logEvent(this.allTableEvents, "dataSortedEvent"), this.$scope);

        this.$log.debug("%s - Subscribed to table events", this.controllerName);
    }

    public logEvent(list, name){
        return () => {

            if(name == "pageChangedEvent"){
                this.LocalStorageService.storeData(this.cacheKeyPage, this.tableParams.page(), false);
            }

            if(name == "dataFilteredEvent" && !this.UtilService.isObjectEmpty(this.tableParams.filter())){
                this.LocalStorageService.storeData(this.cacheKeyFilter, this.tableParams.filter(), true);
            }

        };
    }

    private setFilterPlaceholder() {
        var doc = this.$document[0];
        var elmt = doc.getElementById("filterField");
        if ((this.placeholderText !== null) && (this.placeholderText !== undefined)) {
            elmt.placeholder = this.placeholderText;
        } else {
            elmt.placeholder = "Search ...";
        }
    }

    private FindRowIndex(dataArray, rowId) {
        var rowIndex: number = -1;
        if (dataArray instanceof Array) {
            for (var i = 0; i < dataArray.length; i++) {
                if (dataArray[i].id == rowId) {
                    rowIndex = i;
                    break;
                }
            }
        }
        return rowIndex;
    }
}