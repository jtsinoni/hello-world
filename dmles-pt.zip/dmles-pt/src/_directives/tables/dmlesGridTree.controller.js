define(["require", "exports"], function (require, exports) {
    "use strict";
    var DmlesGridTreeController = (function () {
        //@inject
        function DmlesGridTreeController($filter, $interval, $log, $scope, $timeout, uiGridConstants, uiGridTreeViewConstants) {
            var _this = this;
            this.$filter = $filter;
            this.$interval = $interval;
            this.$log = $log;
            this.$scope = $scope;
            this.$timeout = $timeout;
            this.uiGridConstants = uiGridConstants;
            this.uiGridTreeViewConstants = uiGridTreeViewConstants;
            this.controllerName = "DmlesGridTreeController Directive";
            this.$log.debug('%s - Start', this.controllerName);
            this.treeDataLoading = true;
            this.determineHeightWidth();
            // Watches for data changes from parent
            this.$scope.$watch(function () { return _this.treeData; }, function (newValue, oldValue) {
                _this.treeDataLoading = true;
                _this.loadData();
            });
            this.buildOpts();
        }
        DmlesGridTreeController.prototype.buildOpts = function () {
            var _this = this;
            if (!this.treeId) {
                this.treeId = "logiColeTree-" + new Date().getTime();
            }
            this.gridTreeOptions = {
                enableColumnMenus: false,
                enableRowSelection: this.treeOptions.enableRowSelection,
                enableRowHeaderSelection: this.treeOptions.enableRowHeaderSelection,
                enableSelectAll: false,
                multiSelect: this.treeOptions.multiSelect,
                selectionRowHeaderWidth: this.treeOptions.selectionRowHeaderWidth,
                rowHeight: this.treeOptions.rowHeight,
                showGridFooter: this.treeOptions.showGridFooter,
                enableFiltering: true,
                showTreeExpandNoChildren: false,
                columnDefs: this.treeOptions.columnDefs,
                onRegisterApi: function (gridTreeApi) {
                    _this.gridTreeApi = gridTreeApi;
                    // Select or UnSelect One, Note: Only Select calls the parent method
                    _this.gridTreeApi.selection.on.rowSelectionChanged(_this.$scope, function (row) {
                        var msg = 'row selected ' + row.isSelected;
                        if (row.isSelected) {
                            _this.$log.debug("%s - Row selected: %s", _this.controllerName, JSON.stringify(row.entity));
                            // Calls parent controller to pass selected data
                            _this.$scope.treeItemSelection({ itemData: row.entity });
                        }
                        else {
                            _this.$log.debug("%s - Row unselected: %s", _this.controllerName, JSON.stringify(row.entity));
                        }
                    });
                    // this.gridTreeApi.cellNav.on.navigate(null, function(newRowCol, oldRowCol){
                    //     this.gridTreeApi.selection.selectRow(newRowCol.row.entity);
                    //     this.gridTreeApi.core.notifyDataChange( this.gridTreeApi.grid,  this.uiGridConstants.dataChange.COLUMN );
                    //
                    //     this.$log.debug("%s - Row selected: %s", this.controllerName, JSON.stringify(newRowCol.row.entity));
                    //     // Calls parent controller to pass selected data
                    //     this.$scope.treeItemSelection( { itemData : newRowCol.row.entity } );
                    //
                    // });
                    _this.checkIfLoaded();
                }
            };
        };
        DmlesGridTreeController.prototype.checkIfLoaded = function () {
            if (this.gridTreeOptions && Array.isArray(this.gridTreeOptions.data)) {
                this.treeDataLoading = false;
                this.$log.debug("%s - Tree loaded", this.controllerName);
            }
        };
        DmlesGridTreeController.prototype.determineHeightWidth = function () {
            if (this.height || this.width) {
                if (this.height && this.width) {
                    this.gridTreeStyle = "{'height' : '" + this.height + "', " + " 'width' : '" + this.width + "'}";
                }
                else if (!this.height && this.width) {
                    this.gridTreeStyle = "{'width' : '" + this.width + "'}";
                }
                else if (this.height && !this.width) {
                    this.gridTreeStyle = "{'height' : " + this.height + "'}";
                }
            }
        };
        DmlesGridTreeController.prototype.loadData = function () {
            var _this = this;
            if (Array.isArray(this.treeData) && this.gridTreeOptions) {
                this.gridTreeOptions.data = this.treeData;
                // pre select a row
                if (this.gridTreeApi) {
                    // $interval whilst we wait for the grid to digest the data we just gave it
                    // Auto select's a row
                    this.$interval(function () {
                        _this.expandAll();
                        if (_this.treeItemPreSelection) {
                            _this.$log.debug("%s - Pre-selection applied for item: %s", _this.controllerName, _this.treeItemPreSelection);
                            _this.gridTreeApi.selection.selectRow(_this.gridTreeOptions.data[_this.treeItemPreSelection]);
                            _this.$timeout(function () {
                                _this.searchText = _this.gridTreeOptions.data[_this.treeItemPreSelection].name;
                                _this.filterTree();
                            }, 500);
                        }
                        if (_this.treeItemScrollTo) {
                            _this.scrollTo(_this.treeItemScrollTo);
                        }
                    }, 0, 1);
                }
                this.checkIfLoaded();
                this.$log.debug("%s - Loaded from the watcher", this.controllerName);
            }
        };
        DmlesGridTreeController.prototype.scrollTo = function (rowIndex) {
            var _this = this;
            if (this.treeItemScrollTo && rowIndex) {
                this.$timeout(function () {
                    _this.gridTreeApi.cellNav.scrollToFocus(_this.gridTreeOptions.data[rowIndex], _this.gridTreeOptions.columnDefs[1]);
                }, 1000);
            }
        };
        DmlesGridTreeController.prototype.clearAll = function () {
            this.gridTreeApi.selection.clearSelectedRows();
            this.gridTreeApi.grid.clearAllFilters();
            this.gridTreeApi.treeBase.collapseAllRows();
        };
        DmlesGridTreeController.prototype.expandAll = function () {
            this.gridTreeApi.treeBase.expandAllRows();
        };
        DmlesGridTreeController.prototype.filterTree = function () {
            this.gridTreeApi.grid.columns[3].filters[0].term = this.searchText;
            this.$log.debug("%s - filtered on: %s", this.controllerName, this.searchText);
        };
        return DmlesGridTreeController;
    }());
    exports.DmlesGridTreeController = DmlesGridTreeController;
});
//# sourceMappingURL=dmlesGridTree.controller.js.map