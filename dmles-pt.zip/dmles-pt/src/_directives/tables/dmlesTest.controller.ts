export class DmlesTestController {
    private controllerName:string = "DmlesTestController";
    public items:any;

    //@inject
    constructor(private $log, public $compile, public $element, public $scope) {
        this.$log.debug('%s - Start', this.controllerName);
        this.init();
    }

    private init(){
        this.items = angular.copy(this.$scope.datasource);
        this.$log.debug('%s - Init', this.controllerName);
    }

    public addItem(item){
        this.items.push({
            name: item
        });
        this.$log.debug('%s - Push', this.controllerName);
    }
}