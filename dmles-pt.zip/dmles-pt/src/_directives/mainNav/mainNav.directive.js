define(["require", "exports"], function (require, exports) {
    "use strict";
    var MainNav = (function () {
        // @ngInject
        function MainNav($log, $state, Authentication, MainNavService) {
            var _this = this;
            this.$log = $log;
            this.$state = $state;
            this.Authentication = Authentication;
            this.MainNavService = MainNavService;
            this.restrict = 'E';
            this.templateUrl = './src/_directives/mainNav/mainNav.template.html';
            this.controller = 'MainNavController as vm';
            this.scope = true;
            this.link = function ($scope, $element, $attr) {
                var args = [];
                for (var _i = 3; _i < arguments.length; _i++) {
                    args[_i - 3] = arguments[_i];
                }
                if (_this.Authentication.isLoggedIn()) {
                    // On load
                    if (_this.$state.$current.name) {
                        _this.MainNavService.activateMainNav(_this.$state.$current.name);
                    }
                    // On state change
                    $scope.$on('$stateChangeSuccess', function (event, toState, toParams, fromState, fromParams) {
                        if (toState && toState.name) {
                            _this.MainNavService.activateMainNav(toState.name);
                        }
                    });
                }
            };
            MainNav.prototype.link = function (scope, element, attr) { };
        }
        MainNav.Factory = function () {
            var directive = function ($log, $state, Authentication, MainNavService) { return new MainNav($log, $state, Authentication, MainNavService); };
            directive.$inject = ['$log', '$state', 'Authentication', 'MainNavService'];
            return directive;
        };
        return MainNav;
    }());
    exports.MainNav = MainNav;
});
//# sourceMappingURL=mainNav.directive.js.map