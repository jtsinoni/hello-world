define(["require", "exports", "../../_constants/state.constants"], function (require, exports, state_constants_1) {
    "use strict";
    var MainNavController = (function () {
        //@inject
        function MainNavController($log, $state, MainNavService) {
            this.$log = $log;
            this.$state = $state;
            this.MainNavService = MainNavService;
            this.controllerName = "MainNavController";
            this.status = { isopen: false };
            this.$log.debug('%s - Start', this.controllerName);
            this.init();
        }
        MainNavController.prototype.init = function () {
            var _this = this;
            this.MainNavService.getMyNavItems().then(function (data) {
                _this.MainNavService.mainNavItems = data;
                _this.$log.debug('%s - Main nav loaded: ', JSON.stringify(data));
            });
        };
        MainNavController.prototype.goTo = function (serviceItem) {
            this.$state.go(serviceItem.state);
        };
        ;
        MainNavController.prototype.goToDashboard = function () {
            this.$state.go(state_constants_1.StateConstants.MY_DASHBOARD);
        };
        ;
        MainNavController.prototype.toggleDropdown = function ($event) {
            $event.preventDefault();
            $event.stopPropagation();
            this.status.isopen = !this.status.isopen;
        };
        return MainNavController;
    }());
    exports.MainNavController = MainNavController;
});
//# sourceMappingURL=mainNav.controller.js.map