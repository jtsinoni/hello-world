export class MainNav implements ng.IDirective {
    public restrict:string = 'E';
    public templateUrl:string = './src/_directives/mainNav/mainNav.template.html';
    public controller:string = 'MainNavController as vm';
    public scope:boolean = true;

    public link = ($scope, $element, $attr, ...args) => {
        if (this.Authentication.isLoggedIn()) {

            // On load
            if (this.$state.$current.name) {
                this.MainNavService.activateMainNav(this.$state.$current.name);
            }

            // On state change
            $scope.$on('$stateChangeSuccess', (event, toState, toParams, fromState, fromParams) => {
                if (toState && toState.name) {
                    this.MainNavService.activateMainNav(toState.name);
                }
            });

        }

    };

    // @ngInject
    constructor(private $log, private $state, private Authentication, private MainNavService) {
        MainNav.prototype.link = (scope, element, attr) => {};
    }

    public static Factory() {
        const directive = ($log, $state, Authentication, MainNavService) => new MainNav($log, $state, Authentication, MainNavService);
        directive.$inject = ['$log', '$state', 'Authentication', 'MainNavService'];
        return directive;
    }
}
