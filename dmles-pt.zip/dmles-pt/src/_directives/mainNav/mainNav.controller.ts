import {StateConstants} from "../../_constants/state.constants";

export class MainNavController {
    private controllerName:string = "MainNavController";
    public status:any = { isopen: false };

    //@inject
    constructor(private $log, private $state, private MainNavService) {
        this.$log.debug('%s - Start', this.controllerName);
        this.init();
    }

    private init(){
        this.MainNavService.getMyNavItems().then((data) => {
            this.MainNavService.mainNavItems = data;
            //this.$log.debug('%s - Main nav loaded: ', JSON.stringify(data));
        });
    }

    public goTo(serviceItem):void {
        this.$state.go(serviceItem.state);
    };

    public goToDashboard():void {
        this.$state.go(StateConstants.MY_DASHBOARD);
    };

    public toggleDropdown($event){
        $event.preventDefault();
        $event.stopPropagation();
        this.status.isopen = !this.status.isopen;
    }

}