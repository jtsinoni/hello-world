'use strict';

export class MainNavService {
    private serviceName:string = "MainNavService";
    private masterNav: Array<any> = [];  // TODO: Move to MongoDB

    public myNav: Array<any> = [];
    public currentService: any;
    public mainNavItems: any;

    //@inject
    constructor(private $log, private $q, private PermissionService, private ResourceConstants, private StateConstants, private UserService, private UtilService) {
        this.$log.debug('%s - Start', this.serviceName);

        // TODO: Move to MongoDB
        this.masterNav = [
            {
                "id": "dashboardButton",
                "active": false,
                "tooltip": "My Dashboard",
                "icon": "fa fa-dashboard fa-2x",
                "shown": true,
                "statesCovered": [
                    {"state": this.StateConstants.MY_DASHBOARD}
                ],
                "navChoices": null
            },
            {
                "id": "requestButton",
                "active": false,
                "tooltip": "Equipment Request",
                "icon": "fa fa-ambulance fa-2x",
                "shown": true,
                "statesCovered": [
                    {"state": this.StateConstants.EQUIP_REQUEST_SHELL},
                    {"state": this.StateConstants.CATALOG_SHELL}
                ],
                "navChoices": [
                    {   "id": "equipmentRequestsButton",
                        "icon": "fa fa-file-text-o fa-fw",
                        "perm": this.ResourceConstants.EQUIP_REQUESTS_MY_REQUESTS,
                        "state": this.StateConstants.EQUIP_REQUEST_MY_REQUESTS,
                        "text": "Equipment Requests",
                        "shown": true
                    },
                    {
                        "id": "equipmentCatalogButton",
                        "icon": "fa fa fa-search fa-fw",
                        "perm": this.ResourceConstants.CATALOG_VIEW,
                        "state": this.StateConstants.CATALOG_SEARCH,
                        "text": "Equipment Catalog Search",
                        "shown": true
                    },
                    {
                        "id": "workflowManagementButton",
                        "icon": "fa fa fa-map-signs fa-fw",
                        "perm": this.ResourceConstants.WORKFLOW_MANAGEMENT,
                        "state": this.StateConstants.EQUIP_REQUEST_WORKFLOW_MNG,
                        "text": "Workflow Management",
                        "shown": true
                    }
                ]
            },
            {
                "id": "recordButton",
                "active": false,
                "tooltip": "Equipment Record",
                "icon": "fa fa-clipboard fa-2x",
                "shown": true,
                "statesCovered": [
                    {"state": this.StateConstants.EQUIP_RECORD_SEARCH}
                ],
                "navChoices": [
                    {
                        "id": "recordSearchButton",
                        "active": false,
                        "icon": "fa fa-search fa-fw",
                        "perm": this.ResourceConstants.EQUIP_RECORDS_VIEW,
                        "state": this.StateConstants.EQUIP_RECORD_SEARCH,
                        "text": "Equipment Record Search",
                        "shown": true
                    },
                    {
                        "id": "dataManagementButton",
                        "active": false,
                        "icon": "fa fa-coffee fa-fw",
                        "perm": this.ResourceConstants.EQUIP_RECORD_DATA_MANAGEMENT,
                        "state": this.StateConstants.EQUIP_RECORD_DATA_MANAGEMENT,
                        "text": "Data Management",
                        "shown": true
                    }
                ]
            },
            {
                "id": "jmarButton",
                "active": false,
                "tooltip": "JMAR Search",
                "icon": "fa fa-cloud fa-2x",
                "shown": true,
                "statesCovered": [
                    {"state": this.StateConstants.JMAR_SHELL}
                ],
                "navChoices": [
                    {
                        "id": "jmarSearchButton",
                        "active": false,
                        "icon": "fa fa-search fa-fw",
                        "perm": this.ResourceConstants.JMAR_VIEW,
                        "state": this.StateConstants.JMAR_SHELL,
                        "text": "JMAR Catalog Search",
                        "shown": true
                    }
                ]
            },
            {
                "id": "adminButton",
                "active": false,
                "tooltip": "User Profile and Role Administration",
                "icon": "fa fa-group fa-2x",
                "shown": true,
                "statesCovered": [
                    {"state": this.StateConstants.ADMIN_SHELL}
                ],
                "navChoices": [
                    {
                        "id": "userProfileButton",
                        "active": false,
                        "icon": "fa fa-user fa-fw",
                        "perm": this.ResourceConstants.USER_PROFILE_MANAGEMENT,
                        "state": this.StateConstants.ADMIN_USER_PROFILE_MNG,
                        "text": "User Profile Management",
                        "shown": true
                    },
                    {
                        "id": "roleManagementButton",
                        "active": false,
                        "icon": "fa fa-graduation-cap fa-fw",
                        "perm": this.ResourceConstants.ROLE_MANAGEMENT,
                        "state": this.StateConstants.ADMIN_ROLE_MNG,
                        "text": "Role Management",
                        "shown": true
                    },
                    {
                        "id": "permissionManagementButton",
                        "active": false,
                        "icon": "fa fa-balance-scale fa-fw",
                        "perm": this.ResourceConstants.PERMISSION_MANAGEMENT,
                        "state": this.StateConstants.ADMIN_PERMISSION_MNG,
                        "text": "Permission Management",
                        "shown": true
                    }
                ]
            }
        ];
    }

    public activateMainNav(currentState: string): void {
        angular.forEach(this.myNav, (nav: any) => {
            nav.active = false;
            angular.forEach(nav.statesCovered, (navItem: any) => {
                if (navItem.state && this.UtilService.isStringFound(navItem.state, currentState)) {
                    nav.active = true;
                }
                return false;
            });
        });
    }

    private loadMyNavPerRole() {
        this.myNav = angular.copy(this.masterNav);

        var currUser = this.UserService.currentUser;
        angular.forEach(this.myNav, (mainNavItem, navKey) => {

            var mainNavCount: number = 0;

            angular.forEach(mainNavItem.navChoices, (navMenuItem, menuKey) => {

                var perm = navMenuItem.perm;
                var isFound = this.PermissionService.isAssignedPermissionFound(perm, currUser.elements);
                if (isFound) {
                    mainNavCount = mainNavCount + 1;
                } else {
                    this.myNav[navKey].navChoices[menuKey].shown = false;
                }
            });

            if (0 === mainNavCount) {
                this.myNav[navKey].shown = false;
            }
        });
    }

    public clearCurrentService(): void {
        this.currentService = null;
    };

    public getMyNavItems() {
        var deferred = this.$q.defer();
        this.loadMyNavPerRole();
        deferred.resolve(this.myNav);
        return deferred.promise;
    };

}
