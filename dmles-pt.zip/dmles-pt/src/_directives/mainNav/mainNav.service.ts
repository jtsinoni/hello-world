'use strict';

export class MainNavService {
    private serviceName: string = "MainNavService";
    private masterNav: Array<any> = [];  // TODO: Move to MongoDB
    private animateOut:String = "animated fadeOutRight";
    private animateIn:String = "animated fadeInLeft";

    public animation:String = "";
    public myNav: Array<any> = [];
    public currentService: any;
    public mainNavItems: any;

    //@inject
    constructor(private $log, private $q, private PermissionService, private ResourceConstants, private StateConstants, private UserService, private UtilService) {
        this.$log.debug('%s - Start', this.serviceName);

        // TODO: Move to MongoDB
        this.masterNav = [
            {
                "id": "dashboard",
                "active": false,
                "tooltip": "My Dashboard",
                "icon": "fa fa-dashboard fa-2x",
                "shown": true,
                "statesCovered": [
                    {"state": this.StateConstants.MY_DASHBOARD}
                ],
                "navChoices": null
            },
            {
                "id": "catalog",
                "active": false,
                "tooltip": "Catalog",
                "icon": "fa fa-search fa-2x",
                "shown": true,
                "statesCovered": [
                    {"state": this.StateConstants.ABI_SHELL},
                    {"state": this.StateConstants.CATALOG_SHELL}
                ],
                "navChoices": [
                    {
                        "id": "abi",
                        "icon": "",
                        "perm": this.ResourceConstants.ABI,
                        "state": this.StateConstants.ABI_SEARCH,
                        "text": "ABi Search",
                        "shown": true
                    },
                    {
                        "id": "equipmentCatalog",
                        "icon": "",
                        "perm": this.ResourceConstants.CATALOG_VIEW,
                        "state": this.StateConstants.CATALOG_SEARCH,
                        "text": "Equipment Catalog Search",
                        "shown": true
                    },
                    {
                        "id": "customerCatalog",
                        "icon": "",
                        "perm": this.ResourceConstants.CUSTOMER_CATALOG_VIEW,
                        "state": this.StateConstants.CUSTOMER_CATALOG,
                        "text": "Customer Catalog",
                        "shown": true
                    }
                ]
            },
            {
                "id": "equipment",
                "active": false,
                "tooltip": "Equipment",
                "icon": "fa fa-medkit fa-2x",
                "shown": true,
                "statesCovered": [
                    {"state": this.StateConstants.EQUIP_SHELL}
                ],
                "navChoices": [
                    {   "id": "equipmentRequest",
                        "icon": "",
                        "perm": this.ResourceConstants.EQUIP_REQUESTS_MY_REQUESTS,
                        "state": this.StateConstants.EQUIP_REQUEST_MY_REQUESTS,
                        "text": "Equipment Request",
                        "shown": true
                    },
                    {
                        "id": "equipmentRecord",
                        "active": false,
                        "icon": "",
                        "perm": this.ResourceConstants.EQUIP_RECORDS_VIEW,
                        "state": this.StateConstants.EQUIP_RECORD_SEARCH,
                        "text": "Equipment Record",
                        "shown": true
                    }
                ]
            },
            {
                "id": "assetManagement",
                "active": false,
                "tooltip": "Asset Management",
                "icon": "fa fa-bank fa-2x",
                "shown": true,
                "statesCovered" : [
                    {"state": this.StateConstants.ASSET_MANAGEMENT_SHELL}
                ],
                "navChoices":[
                    {   "id": "assetManagement",
                        "icon": "",
                        "perm": this.ResourceConstants.ASSET_MANAGEMENT_MAIN_VIEW,
                        "state": this.StateConstants.ASSET_MANAGEMENT_MAIN,
                        "text": "Asset Lookup",
                        "shown": true
                    },
                    {   "id": "medicalEquipment",
                        "icon": "",
                        "perm": this.ResourceConstants.ASSET_MANAGEMENT_MEDICAL_EQUIPMENT_VIEW,
                        "state": this.StateConstants.ASSET_MANAGEMENT_MEDICAL_EQUIPMENT,
                        "text": "Medical Equipment",
                        "shown": true
                    },
                    {   "id": "realPropertyInstalled",
                        "icon": "",
                        "perm": this.ResourceConstants.ASSET_MANAGEMENT_REAL_PROPERTY_INSTALLED_VIEW,
                        "state": this.StateConstants.ASSET_MANAGEMENT_REAL_PROPERTY_INSTALLED,
                        "text": "Real Property Installed Equipment",
                        "shown": true
                    }
                ]
            },
            {
                "id": "inventory",
                "active": false,
                "tooltip": "Inventory",
                "icon": "fa fa-cubes fa-2x",
                "shown": true,
                "statesCovered": [
                    {"state": this.StateConstants.INVENTORY_SHELL}
                ],
                "navChoices": [
                    {
                        "id": "inventoryRecord",
                        "icon": "",
                        "perm": this.ResourceConstants.INVENTORY_RECORD_VIEW,
                        "state": this.StateConstants.INVENTORY_RECORD,
                        "text": "Inventory Record",
                        "shown": true
                    },
                    {
                        "id": "physicalInventory",
                        "icon": "",
                        "perm": this.ResourceConstants.INVENTORY_PHYSICAL_VIEW,
                        "state": this.StateConstants.INVENTORY_PHYSICAL,
                        "text": "Physical Inventory",
                        "shown": true
                    },
                    {
                        "id": "storageManagement",
                        "icon": "",
                        "perm": this.ResourceConstants.INVENTORY_STORAGE_VIEW,
                        "state": this.StateConstants.INVENTORY_STORAGE,
                        "text": "Storage Management",
                        "shown": true
                    },
                    {
                        "id": "gainLoss",
                        "icon": "",
                        "perm": this.ResourceConstants.INVENTORY_GAIN_LOSS_VIEW,
                        "state": this.StateConstants.INVENTORY_GAIN_LOSS,
                        "text": "Gain and Loss",
                        "shown": true
                    },
                    {
                        "id": "transfer",
                        "icon": "",
                        "perm": this.ResourceConstants.INVENTORY_TRANSFER_VIEW,
                        "state": this.StateConstants.INVENTORY_TRANSFER,
                        "text": "Transfer",
                        "shown": true
                    }
                ]
            },
            {
                "id": "customer",
                "active": false,
                "tooltip": "Customer",
                "icon": "fa fa-user-md fa-2x",
                "shown": true,
                "statesCovered": [
                    {"state": this.StateConstants.BUYER_SHELL}
                ],
                "navChoices": [
                    {
                        "id": "customerMain",
                        "icon": "",
                        "perm": this.ResourceConstants.BUYER_VIEW,
                        "state": this.StateConstants.BUYER_MAIN,
                        "text": "Customer",
                        "shown": true
                    },
                    {
                        "id": "purchases",
                        "icon": "",
                        "perm": this.ResourceConstants.BUYER_PURCHASES_VIEW,
                        "state": this.StateConstants.BUYER_PURCHASES,
                        "text": "Purchases",
                        "shown": true
                    },
                    {
                        "id": "requisition",
                        "icon": "",
                        "perm": this.ResourceConstants.BUYER_REQUISITION_VIEW,
                        "state": this.StateConstants.BUYER_REQUISITION,
                        "text": "Requisition",
                        "shown": true
                    },
                    {
                        "id": "receipts",
                        "icon": "",
                        "perm": this.ResourceConstants.BUYER_RECEIPTS_VIEW,
                        "state": this.StateConstants.BUYER_RECEIPTS,
                        "text": "Receipts",
                        "shown": true
                    },
                    {
                        "id": "orderStatus",
                        "icon": "",
                        "perm": this.ResourceConstants.BUYER_ORDER_STATUS_VIEW,
                        "state": this.StateConstants.BUYER_ORDER_STATUS,
                        "text": "Order Status",
                        "shown": true
                    }
                ]
            },
            {
                "id": "supplier",
                "active": false,
                "tooltip": "Supplier",
                "icon": "fa fa-ambulance fa-2x",
                "shown": true,
                "statesCovered": [
                    {"state": this.StateConstants.SELLER_SHELL}
                ],
                "navChoices": [
                    {
                        "id": "supplierMain",
                        "icon": "",
                        "perm": this.ResourceConstants.SELLER_VIEW,
                        "state": this.StateConstants.SELLER_MAIN,
                        "text": "Supplier",
                        "shown": true
                    },
                    {
                        "id": "orderFulfillment",
                        "icon": "",
                        "perm": this.ResourceConstants.SELLER_FULFILLMENT_VIEW,
                        "state": this.StateConstants.SELLER_FULFILLMENT,
                        "text": "Order Fulfillment",
                        "shown": true
                    },
                    {
                        "id": "backOrderStatus",
                        "icon": "",
                        "perm": this.ResourceConstants.SELLER_BACK_ORDER_STATUS_VIEW,
                        "state": this.StateConstants.SELLER_BACK_ORDER_STATUS,
                        "text": "Back Order Status",
                        "shown": true
                    }
                ]
            },
            {
                "id": "finance",
                "active": false,
                "tooltip": "Finance",
                "icon": "fa fa-calculator fa-2x",
                "shown": true,
                "statesCovered": [
                    {"state": this.StateConstants.FIN_SHELL}
                ],
                "navChoices": [
                    {
                        "id": "financeLanding",
                        "icon": "",
                        "perm": this.ResourceConstants.FIN_LANDING_VIEW,
                        "state": this.StateConstants.FIN_LANDING,
                        "text": "Finance",
                        "shown": true
                    },
                    {   "id": "financeAdminAppropriations",
                        "icon": "",
                        "perm": this.ResourceConstants.FIN_APPROPRIATIONS_VIEW,
                        "state": this.StateConstants.FIN_MY_APPROPRIATIONS,
                        "text": "My Appropriations",
                        "shown": true
                    },
                ]
            },
            {
                "id": "realEstateManagement",
                "active": false,
                "tooltip": "Real Property Management",
                "icon": "fa fa-hospital-o fa-2x",
                "shown": true,
                "text": "Real Property Management",
                "statesCovered": [
                    {"state": this.StateConstants.REAL_ESTATE_SHELL}
                ],
                "navChoices": [
                    {
                        "id": "installations",
                        "icon": "",
                        "perm": this.ResourceConstants.REAL_ESTATE_INSTALLATION_RECORD_VIEW,
                        "state": this.StateConstants.REAL_ESTATE_INSTALLATION_RECORD_VIEW,
                        "text": "Installations/Sites",
                        "shown": true
                    }
                ]
            },
            {
                "id": "buyerManagement",
                "active": false,
                "tooltip": "Buyer Management",
                "icon": "fa fa-suitcase fa-2x",
                "shown": true,
                "perm": this.ResourceConstants.BUYER_DETAIL_VIEW,
                "state": this.StateConstants.BUYER_SHELL,
                "text": "Buyer Management",
                "statesCovered": [
                    {"state": this.StateConstants.BUYER_SHELL}
                ],
                "navChoices": [
                    {
                        "id":   "buyerDetails",
                        "active": false,
                        "icon": "fa fa-calculator fa-fw",
                        "perm": this.ResourceConstants.BUYER_DETAIL_VIEW,
                        "state": this.StateConstants.BUYER_DETAIL_VIEW,
                        "text": "Buyer Details",
                        "shown": true
                    },
                    {
                        "id":   "buyerLookupDetails",
                        "icon": "fa fa-file-text-o fa-fw",
                        "perm": this.ResourceConstants.BUYER_LOOKUP_VIEW,
                        "state": this.StateConstants.BUYER_LOOKUP_VIEW,
                        "text": "Buyer Lookup Details",
                        "shown": true
                    }
                ]
            },
            {
                "id": "userAdminButton",
                "active": false,
                "tooltip": "User and Role Administration",
                "icon": "fa fa-group fa-2x",
                "shown": true,
                "statesCovered": [
                    {"state": this.StateConstants.ADMIN_SHELL}
                ],
                "navChoices": [
                    {
                        "id": "users",
                        "icon": "",
                        "perm": this.ResourceConstants.USER_PROFILE_MANAGEMENT,
                        "state": this.StateConstants.ADMIN_USER_PROFILE_MNG,
                        "text": "User Profile Management",
                        "shown": true
                    },
                    {
                        "id": "roles",
                        "icon": "",
                        "perm": this.ResourceConstants.ROLE_MANAGEMENT,
                        "state": this.StateConstants.ADMIN_ROLE_MNG,
                        "text": "Role Management",
                        "shown": true
                    },
                    {
                        "id": "permissions",
                        "icon": "",
                        "perm": this.ResourceConstants.PERMISSION_MANAGEMENT,
                        "state": this.StateConstants.ADMIN_PERMISSION_MNG,
                        "text": "Permission Management",
                        "shown": true
                    },
                    {
                        "id": "organization",
                        "icon": "",
                        "perm": this.ResourceConstants.ORGANIZATION_MANAGEMENT,
                        "state": this.StateConstants.ADMIN_ORG_MNG,
                        "text": "Organization Management",
                        "shown": true
                    }
                ]
            },
            {
                "id": "jmlfdcAdmin",
                "active": false,
                "tooltip": "JMLFDC Administration",
                "icon": "fa fa-gears fa-2x",
                "shown": true,
                "statesCovered": [
                    {"state": this.StateConstants.JMLFDC_ADMIN_SHELL},
                    {"state": this.StateConstants.ABI_STAGING_SHELL }
                ],
                "navChoices": [
                    {
                        "id": "manageVirtualItemMasterCatalog",
                        "icon": "",
                        "perm": this.ResourceConstants.MANAGE_ABI_STAGING,
                        "state": this.StateConstants.ABI_STAGING_VIEW,
                        "text": "Manage ABi Staging",
                        "shown": true
                    }
                ]
            }
        ];
    }

    private loadMyNavPerRole() {
        this.myNav = angular.copy(this.masterNav);
        //this.myNav = [];

        var currUser = this.UserService.currentUser;
        angular.forEach(this.masterNav, (mainNavItem, navKey) => {

            var mainNavCount: number = 0;

            angular.forEach(mainNavItem.navChoices, (navMenuItem, menuKey) => {

                var perm = navMenuItem.perm;
                var isFound = this.PermissionService.isAssignedPermissionFound(perm, currUser.elements);
                if (isFound) {
                    mainNavCount = mainNavCount + 1;
                } else {
                    this.myNav[navKey].navChoices[menuKey].shown = false;
                }
            });

            if (0 === mainNavCount && "dashboard" !== mainNavItem.id) {
                this.myNav[navKey].shown = false;
            }

        });
    }

    public activateMainNav(currentState: string): void {
        angular.forEach(this.myNav, (nav: any) => {
            nav.active = false;
            angular.forEach(nav.statesCovered, (navItem: any) => {
                if (navItem.state && this.UtilService.isStringFound(navItem.state, currentState)) {
                    nav.active = true;
                }
                return false;
            });
        });
    }

    public animateOutNavItems(): void {
        this.animation = this.animateOut;
    };

    public animateInNavItems(): void {
        this.animation = this.animateIn;
    };

    public clearCurrentService(): void {
        this.currentService = null;
    };

    public getMyNavItems() {
        var deferred = this.$q.defer();
        this.loadMyNavPerRole();
        deferred.resolve(this.myNav);
        return deferred.promise;
    };

}
