
export class RemoveButton implements ng.IDirective {
    public restrict:string = "EA";
    public transclude:boolean = true;
    public templateUrl:string = "./src/_directives/buttons/removeButton.template.html";

    public scope:any = {
        buttonId: '@',
        canShow: '=',
        buttonClick: '&',
        isDisabled: '=',
        title: '@'
    };


    // @ngInject
    constructor(private $log) {}

    public static Factory() {
        const directive = ($log) => new RemoveButton($log);
        directive.$inject = ['$log'];
        return directive;
    }
}