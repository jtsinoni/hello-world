define(["require", "exports"], function (require, exports) {
    "use strict";
    var RemoveButton = (function () {
        // @ngInject
        function RemoveButton($log) {
            this.$log = $log;
            this.restrict = "EA";
            this.transclude = true;
            this.templateUrl = "./src/_directives/buttons/removeButton.template.html";
            this.scope = {
                buttonId: '@',
                canShow: '=',
                buttonClick: '&',
                isDisabled: '=',
                title: '@'
            };
        }
        RemoveButton.Factory = function () {
            var directive = function ($log) { return new RemoveButton($log); };
            directive.$inject = ['$log'];
            return directive;
        };
        return RemoveButton;
    }());
    exports.RemoveButton = RemoveButton;
});
//# sourceMappingURL=removeButton.directive.js.map