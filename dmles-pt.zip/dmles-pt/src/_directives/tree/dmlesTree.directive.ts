import { DmlesTreeController } from "./dmlesTree.controller";

/*

Example:
 <dmles-tree
     comparator="false"
     pre-lookup="vm.preLookup"
     selected-node="vm.selectedNode"
     tree-data="vm.treeData"
     tree-type="tree-logical"
     show-selected="vm.showSelected"
 ></dmles-tree>

Tree Types (Correspond with tree-control-css and images):
 tree-logical
 tree-boot
 tree-classic

Ref: https://github.com/wix/angular-tree-control

 */

export class DmlesTree implements ng.IDirective {
    public restrict: string = "EA";
    public controller = DmlesTreeController;
    public controllerAs: string = 'ctrl';
    public templateUrl: string = "./src/_directives/tree/dmlesTree.template.html";

    public bindToController: any = {
        comparator: '=',
        preLookup: '=',
        selectedNode: '=',
        treeData: '=',
        treeType: '@',
        showSelected: '&'
    };

    public scope: any = {};

    // @ngInject
    constructor(private $log) {
    }

    public static Factory() {
        const directive = ($log) => new DmlesTree($log);
        directive.$inject = ['$log'];
        return directive;
    }
}