define(["require", "exports"], function (require, exports) {
    'use strict';
    var DmlesTreeData = (function () {
        function DmlesTreeData(obj) {
            this.id = "";
            this.value = "";
            this.description = "";
            this.type = "";
            this.children = [];
            this.tagData = null;
            this.id = obj && obj.id || "";
            this.type = obj && obj.description || "";
            this.description = obj && obj.description || "";
            this.value = obj && obj.description || "";
            this.children = obj && obj.children || [];
        }
        return DmlesTreeData;
    }());
    exports.DmlesTreeData = DmlesTreeData;
});
//# sourceMappingURL=dmlesTreeData.model.js.map