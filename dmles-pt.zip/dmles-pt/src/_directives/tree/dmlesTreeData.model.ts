'use strict';

export class DmlesTreeData {
    public id:any = "";
    public value:string = "";
    public description:string = "";
    public type:string = "";
    public children:Array<DmlesTreeData> = [];
    public tagData:any = null;
    
    constructor();
    constructor(obj:DmlesTreeData);
    constructor(obj?:any) {
        this.id = obj && obj.id || "";
        this.type = obj && obj.description || "";
        this.description = obj && obj.description || "";
        this.value = obj && obj.description || "";
        this.children = obj && obj.children || [];
    }
}