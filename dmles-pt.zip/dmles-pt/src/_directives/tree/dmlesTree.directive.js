define(["require", "exports", "./dmlesTree.controller"], function (require, exports, dmlesTree_controller_1) {
    "use strict";
    /*
    
    Example:
     <dmles-tree
         comparator="false"
         pre-lookup="vm.preLookup"  // Pre-populates the search field
         selected-node="vm.selectedNode"  // Is the selected node
         tree-data="vm.treeData"  // The tree data
         tree-type="tree-logical"  // The tree type
         on-node-selected="vm.myNodeSelectedFunction(node, selected)"
         on-node-toggle="vm.myNodeToggledFunction(node, expanded)"
         on-node-clicked="vm.onNodeClicked(nodeData)"  // The outer controller's call back when a node is clicked
         expanded-node-list="vm.expandedNodeList"
     ></dmles-tree>
    
    Tree Types (Correspond with tree-control-css and images):
     tree-logical
     tree-boot
     tree-classic
    
    Ref: https://github.com/wix/angular-tree-control
    
    IMPORTANT NOTE: For the event functions, be sure to specify the function parameters
        EXACTLY as they are shown above. The directive will only bind to the 'node',
        'selected', 'expanded', and 'nodeData' parameters as shown above.
    
    expanded-node-list: this is an array of DmlesTreeData elements that should be expanded in the tree
    
     */
    var DmlesTree = (function () {
        // @ngInject
        function DmlesTree($log) {
            this.$log = $log;
            this.restrict = "EA";
            this.controller = dmlesTree_controller_1.DmlesTreeController;
            this.controllerAs = 'ctrl';
            this.templateUrl = "./src/_directives/tree/dmlesTree.template.html";
            this.bindToController = {
                preLookup: '=',
                selectedNode: '=',
                treeData: '=',
                treeType: '@',
                onNodeSelected: '&',
                onNodeToggle: '&',
                onNodeClicked: '&'
            };
            this.scope = {};
        }
        DmlesTree.Factory = function () {
            var directive = function ($log) { return new DmlesTree($log); };
            directive.$inject = ['$log'];
            return directive;
        };
        return DmlesTree;
    }());
    exports.DmlesTree = DmlesTree;
});
//# sourceMappingURL=dmlesTree.directive.js.map