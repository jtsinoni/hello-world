import {DmlesTreeData} from "./dmlesTreeData.model";
export class DmlesTreeController {

    private controllerName:string = "DmlesTreeController Directive";
    private expandAll:Array<DmlesTreeData> = [];
    private collapseAll:Array<DmlesTreeData> = [];
    public expandedNodeList:any;
    public comparator:boolean;

    public treeOptions:any = {};  // TODO: Could pass in, in the future
    public treeSearch:string = "";

    // Passed in from the directive
    public preLookup:string;
    public selectedNode:DmlesTreeData;
    public treeData:Array<DmlesTreeData>;
    public treeType:string;
    public onNodeSelected: (any) => void;
    public onNodeToggle: (any) => void;

    //@inject
    constructor(private $log) {
        this.$log.debug('%s - Start', this.controllerName);
        this.$log.debug('%s - preLookup: %s', this.controllerName, this.preLookup);
        this.$log.debug('%s - selectedNode: %s', this.controllerName, JSON.stringify(this.selectedNode));
        this.$log.debug('%s - treeData: %s', this.controllerName, JSON.stringify(this.treeData));
        this.$log.debug('%s - treeType: %s', this.controllerName, this.treeType);

        this.init();
    }

    private init(){
        this.buildTree();
        this.treeSearch = angular.copy(this.preLookup);
    }

    private addToAllNodes(children) {
        if (!children || children.length == 0) {
            return;
        }
        for (var i = 0; i < children.length; i++) {
            this.expandAll.push(children[i]);
            this.addToAllNodes(children[i].children);
        }
    }

    private buildTree(){

        this.treeOptions = {
            nodeChildren: "children",
            dirSelectable: true,
            multiSelection: false
        };

        /*
        this.treeData =
            [
                { "name" : "Joe", "age" : "21", "children" : [
                    { "name" : "Smith", "age" : "42", type: "home", "children" : [] },
                    { "name" : "Gary", "age" : "21", type: "", "children" : [
                        { "name" : "Jenifer", "age" : "23", type: "", "children" : [
                            { "name" : "Dani", "age" : "32", type: "", "children" : [] },
                            { "name" : "Max", "age" : "34", type: "", "children" : [] }
                        ]}
                    ]}
                ]},
                { "name" : "Albert", "age" : "33", type: "", "children" : [] },
                { "name" : "Ron", "age" : "29", type: "", "children" : [] }
            ];
        */

        // Sets up expand all ability
        this.addToAllNodes(angular.copy(this.treeData));

        if(this.selectedNode !== null){
            this.expandNodes();
            this.preLookup = this.selectedNode.value;
        }
    }

    public expandNodes(){
        this.expandedNodeList = this.expandAll;
    }

    public collapseNodes(){
        this.expandedNodeList = this.collapseAll;
    }

    public onDirectiveSelection(node:DmlesTreeData, selected:boolean) {
        // this.$log.info("dmlesTreeController.onDirectiveSelection(). Node is " + JSON.stringify(node, null, 3));
        // this.$log.info("dmlesTreeController.onDirectiveSelection(). selected is " + selected);
        // this.$log.info("onNodeSelected() callback: " + this.onNodeSelected);
        // if (this.onNodeSelected) {
        //     this.$log.info("Calling onNodeSelected() callback function.");
        //     this.onNodeSelected({ node: node, selected: selected });
        // } else {
        //     this.$log.info("onNodeSelected() callback function is not defined.");
        // }
        if (this.onNodeSelected) {
            this.onNodeSelected({ node: node, selected: selected });
        }
    }

    public onDirectiveNodeToggle(node:any, expanded: boolean) {
        // this.$log.info("dmlesTreeController.onDirectiveNodeToggle(). Node is " + JSON.stringify(node, null, 3));
        // this.$log.info("dmlesTreeController.onDirectiveNodeToggle(). expanded is " + expanded);
        // this.$log.info("onNodeToggle() callback: " + this.onNodeToggle);
        // if (this.onNodeToggle) {
        //     this.$log.info("Calling onNodeToggle() callback function.");
        //     this.onNodeToggle({ node: node, expanded: expanded });
        // } else {
        //     this.$log.info("onNodeToggle() callback function is not defined.");
        // }
        if (this.onNodeToggle) {
            this.onNodeToggle({ node: node, expanded: expanded });
        }
    }
}