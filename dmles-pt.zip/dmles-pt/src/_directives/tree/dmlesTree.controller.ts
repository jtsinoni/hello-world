import {DmlesTreeData} from "./dmlesTreeData.model";
export class DmlesTreeController {

    private controllerName:string = "DmlesTreeController Directive";
    private expandAll:Array<DmlesTreeData> = [];
    private collapseAll:Array<DmlesTreeData> = [];

    public expandOrCollapse:Array<DmlesTreeData> = [];
    public treeOptions:any = {};  // TODO: Could pass in, in the future
    public treeSearch:string = "";

    // Passed in from the directive
    public comparator:boolean;
    public preLookup:string;
    public selectedNode:DmlesTreeData;
    public treeData:Array<DmlesTreeData>;
    public treeType:string;

    //@inject
    constructor(private $log) {
        this.$log.debug('%s - Start', this.controllerName);
        this.$log.debug('%s - comparator: %s', this.controllerName, this.comparator);
        this.$log.debug('%s - preLookup: %s', this.controllerName, this.preLookup);
        this.$log.debug('%s - selectedNode: %s', this.controllerName, JSON.stringify(this.selectedNode));
        this.$log.debug('%s - treeData: %s', this.controllerName, JSON.stringify(this.treeData));
        this.$log.debug('%s - treeType: %s', this.controllerName, this.treeType);

        this.init();
    }

    private init(){
        this.buildTree();
        this.treeSearch = angular.copy(this.preLookup);
    }

    private addToAllNodes(children) {
        if (!children || typeof(children) == "array" && children.length == 0) {
            return;
        }
        for (var i = 0; i < children.length; i++) {
            this.expandAll.push(children[i]);
            this.addToAllNodes(children[i].children);
        }
    }

    private buildTree(){

        this.treeOptions = {
            nodeChildren: "children",
            dirSelectable: true,
            multiSelection: false
        };

        /*
        this.treeData =
            [
                { "name" : "Joe", "age" : "21", "children" : [
                    { "name" : "Smith", "age" : "42", type: "home", "children" : [] },
                    { "name" : "Gary", "age" : "21", type: "", "children" : [
                        { "name" : "Jenifer", "age" : "23", type: "", "children" : [
                            { "name" : "Dani", "age" : "32", type: "", "children" : [] },
                            { "name" : "Max", "age" : "34", type: "", "children" : [] }
                        ]}
                    ]}
                ]},
                { "name" : "Albert", "age" : "33", type: "", "children" : [] },
                { "name" : "Ron", "age" : "29", type: "", "children" : [] }
            ];
        */

        // Sets up expand all ability
        this.addToAllNodes(angular.copy(this.treeData));

        if(this.selectedNode !== null){
            this.expandNodes();
            this.preLookup = this.selectedNode.value;
        }
    }

    public expandNodes(){
        this.expandOrCollapse = this.expandAll;
    }

    public collapseNodes(){
        this.expandOrCollapse = this.collapseAll;
    }

}