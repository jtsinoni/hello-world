'use strict';

import {CurrentUserProfile} from "../../_models/currentUserProfile.model";

export class elementChecker implements ng.IDirective {
    public restrict = 'A';
    public transclude = false;
    public terminal = false;
    public priority = 0;
    private ngIf:any = null;

    // @ngInject
    constructor(private $log, private $state, private ngIfDirective, private PermissionService, private UserService) {
        this.ngIf = ngIfDirective[0];

        this.transclude = this.ngIf.transclude;
        this.priority = this.ngIf.priority;
        this.terminal = this.ngIf.terminal;
        this.restrict = this.ngIf.restrict;
    }

    link = ($scope, $element, $attr, ...args) => {
        var hasAccess:boolean = false;
        var currUser:CurrentUserProfile = this.UserService.currentUser;
        var item:any = $attr['elementChecker'];  // TODO: Could be updated to splice an array of items

        // this.$log.debug("currUser: %s", JSON.stringify(currUser));
        // this.$log.debug("item: %s", JSON.stringify(item));
        if (currUser && currUser.elements) {
            hasAccess = this.PermissionService.checkElements(item);
            // this.$log.debug("hasAccess: %s", hasAccess);
            $attr.ngIf = function () {
                return hasAccess;
            };

            // use the same arguments that were passed in to link fn
            // TODO figure out how to access js 'arguments' in typescript, below is a work-around
            var args:any[] = [$scope, $element, $attr, ...args];
            this.ngIf.link.apply(this.ngIf, args);
            // this.$log.debug("Element Checker Directive - Access: %s", hasAccess);
        } else {
            // this.$log.debug("Element Checker Directive - WARNING, currUser.elements not found, returning false");
            return false;            
        }

    };

    public static Factory() {
        const directive = ($log, $state, ngIfDirective, PermissionService, UserService) => new elementChecker($log, $state, ngIfDirective, PermissionService, UserService);
        directive.$inject = ['$log', '$state', 'ngIfDirective', 'PermissionService', 'UserService'];

        return directive;
    }
}

