define(["require", "exports"], function (require, exports) {
    'use strict';
    var elementChecker = (function () {
        // @ngInject
        function elementChecker($log, $state, ngIfDirective, PermissionService, UserService) {
            var _this = this;
            this.$log = $log;
            this.$state = $state;
            this.ngIfDirective = ngIfDirective;
            this.PermissionService = PermissionService;
            this.UserService = UserService;
            this.restrict = 'A';
            this.transclude = false;
            this.terminal = false;
            this.priority = 0;
            this.ngIf = null;
            this.link = function ($scope, $element, $attr) {
                var args = [];
                for (var _i = 3; _i < arguments.length; _i++) {
                    args[_i - 3] = arguments[_i];
                }
                var hasAccess = false;
                var currUser = _this.UserService.currentUser;
                var item = $attr['elementChecker']; // TODO: Could be updated to splice an array of items
                // this.$log.debug("currUser: %s", JSON.stringify(currUser));
                // this.$log.debug("item: %s", JSON.stringify(item));
                if (currUser && currUser.elements) {
                    hasAccess = _this.PermissionService.checkElements(item);
                    // this.$log.debug("hasAccess: %s", hasAccess);
                    $attr.ngIf = function () {
                        return hasAccess;
                    };
                    // use the same arguments that were passed in to link fn
                    // TODO figure out how to access js 'arguments' in typescript, below is a work-around
                    var args = [$scope, $element, $attr].concat(args);
                    _this.ngIf.link.apply(_this.ngIf, args);
                }
                else {
                    // this.$log.debug("Element Checker Directive - WARNING, currUser.elements not found, returning false");
                    return false;
                }
            };
            this.ngIf = ngIfDirective[0];
            this.transclude = this.ngIf.transclude;
            this.priority = this.ngIf.priority;
            this.terminal = this.ngIf.terminal;
            this.restrict = this.ngIf.restrict;
        }
        elementChecker.Factory = function () {
            var directive = function ($log, $state, ngIfDirective, PermissionService, UserService) { return new elementChecker($log, $state, ngIfDirective, PermissionService, UserService); };
            directive.$inject = ['$log', '$state', 'ngIfDirective', 'PermissionService', 'UserService'];
            return directive;
        };
        return elementChecker;
    }());
    exports.elementChecker = elementChecker;
});
//# sourceMappingURL=elementChecker.directive.js.map