'use strict';

export class ViewNotesPanel implements ng.IDirective {
    public restrict:string = 'E';  // E = element, A = attribute, C = class, M = comment
    public templateUrl:string = "./src/_directives/panels/viewNotesPanel.html";
    public scope:boolean = true;
    // DOM manipulation
    public link = ($scope, $element, $attr, ...args) => {
        $scope.showSection =  $attr['section'];
        $scope.identifier =  $attr['id'];
    };

    // @ngInject
    constructor(private $log, private RequestService) {
        ViewNotesPanel.prototype.link = (scope, element, attr) => {
        };
    }

    public static Factory() {
        const directive = ($log, RequestService) => new ViewNotesPanel($log, RequestService);
        directive.$inject = ['$log', 'RequestService'];
        return directive;
    }
}