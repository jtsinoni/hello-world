import {ViewNotesPanelController} from './viewNotesPanel.controller'
export class ViewNotesPanel implements ng.IDirective {
    public restrict:string = 'EA';  // E = element, A = attribute, C = class, M = comment
    public controller = ViewNotesPanelController;
    public controllerAs: string = 'ctrl';
    public templateUrl:string = "./src/_directives/panels/viewNotesPanel.html";
    public transclude:boolean = false;
    public scope: any = {};

    public bindToController:any = {
        identifier: '@',
        data: '=',
        section: '@'
    };

    // @ngInject
    constructor(private $log) {
    }

    public static Factory() {
        const directive = ($log) => new ViewNotesPanel($log);
        directive.$inject = ['$log'];
        return directive;
    }
}