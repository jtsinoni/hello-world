define(["require", "exports"], function (require, exports) {
    'use strict';
    var ViewAttachmentsPanel = (function () {
        // @ngInject
        function ViewAttachmentsPanel($log, FileManagerService) {
            this.$log = $log;
            this.FileManagerService = FileManagerService;
            this.restrict = 'E'; // E = element, A = attribute, C = class, M = comment
            this.templateUrl = "./src/_directives/panels/viewAttachmentsPanel.html";
            this.transclude = false;
            // DOM manipulation
            this.scope = {
                identifier: '@',
                data: '=',
                section: '@',
                filterBySection: '='
            };
        }
        ViewAttachmentsPanel.Factory = function () {
            var directive = function ($log, FileManagerService) { return new ViewAttachmentsPanel($log, FileManagerService); };
            directive.$inject = ['$log', 'FileManagerService'];
            return directive;
        };
        return ViewAttachmentsPanel;
    }());
    exports.ViewAttachmentsPanel = ViewAttachmentsPanel;
});
//# sourceMappingURL=viewAttachmentsPanel.directive.js.map