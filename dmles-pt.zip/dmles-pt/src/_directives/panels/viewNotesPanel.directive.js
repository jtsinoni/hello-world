define(["require", "exports", './viewNotesPanel.controller'], function (require, exports, viewNotesPanel_controller_1) {
    "use strict";
    var ViewNotesPanel = (function () {
        // @ngInject
        function ViewNotesPanel($log) {
            this.$log = $log;
            this.restrict = 'EA'; // E = element, A = attribute, C = class, M = comment
            this.controller = viewNotesPanel_controller_1.ViewNotesPanelController;
            this.controllerAs = 'ctrl';
            this.templateUrl = "./src/_directives/panels/viewNotesPanel.html";
            this.transclude = false;
            this.scope = {};
            this.bindToController = {
                identifier: '@',
                data: '=',
                section: '@'
            };
        }
        ViewNotesPanel.Factory = function () {
            var directive = function ($log) { return new ViewNotesPanel($log); };
            directive.$inject = ['$log'];
            return directive;
        };
        return ViewNotesPanel;
    }());
    exports.ViewNotesPanel = ViewNotesPanel;
});
//# sourceMappingURL=viewNotesPanel.directive.js.map