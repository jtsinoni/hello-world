define(["require", "exports"], function (require, exports) {
    'use strict';
    var ViewNotesPanel = (function () {
        // @ngInject
        function ViewNotesPanel($log, RequestService) {
            this.$log = $log;
            this.RequestService = RequestService;
            this.restrict = 'E'; // E = element, A = attribute, C = class, M = comment
            this.templateUrl = "./src/_directives/panels/viewNotesPanel.html";
            this.scope = true;
            // DOM manipulation
            this.link = function ($scope, $element, $attr) {
                var args = [];
                for (var _i = 3; _i < arguments.length; _i++) {
                    args[_i - 3] = arguments[_i];
                }
                $scope.showSection = $attr['section'];
                $scope.identifier = $attr['id'];
            };
            ViewNotesPanel.prototype.link = function (scope, element, attr) {
            };
        }
        ViewNotesPanel.Factory = function () {
            var directive = function ($log, RequestService) { return new ViewNotesPanel($log, RequestService); };
            directive.$inject = ['$log', 'RequestService'];
            return directive;
        };
        return ViewNotesPanel;
    }());
    exports.ViewNotesPanel = ViewNotesPanel;
});
//# sourceMappingURL=viewNotesPanel.directive.js.map