define(["require", "exports"], function (require, exports) {
    "use strict";
    var ViewNotesPanelController = (function () {
        function ViewNotesPanelController($log) {
            this.$log = $log;
            this.controllerName = "ViewNotesPanelController Directive";
            this.$log.debug('%s - Start', this.controllerName);
            this.collapsed = true;
        }
        ViewNotesPanelController.prototype.collapse = function () {
            this.collapsed = !this.collapsed;
        };
        return ViewNotesPanelController;
    }());
    exports.ViewNotesPanelController = ViewNotesPanelController;
});
//# sourceMappingURL=viewNotesPanel.controller.js.map