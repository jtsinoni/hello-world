'use strict';

export class RightSidePanel implements ng.IDirective {
    public restrict:string = 'E';  // E = element, A = attribute, C = class, M = comment
    public transclude:boolean = true;
    public templateUrl:string = "./src/_directives/panels/rightSidePanel.template.html";
    public scope:boolean = true;

    // DOM manipulation
    public link = ($scope, $element, $attr, ...args) => {
        var isOpen:string = $attr['isopen'];
        var panelWidth:string = $attr['panelwidth'];
        this.$log.info("Right side panel open: %s", isOpen);
        this.$log.info("Right side panel width: %s", panelWidth);

        if(panelWidth){
            this.SidePanelService.rightPanelWidthOpened = panelWidth;
        }

        if(isOpen){
            if("true" === isOpen.toLowerCase()){
                this.SidePanelService.toggleRightPanel();
            }
        }
    };

    // @ngInject
    constructor(private $log, private SidePanelService) {
        RightSidePanel.prototype.link = (scope, element, attr) => {
        };
    }

    public static Factory() {
        const directive = ($log, SidePanelService) => new RightSidePanel($log, SidePanelService);
        directive.$inject = ['$log', 'SidePanelService'];
        return directive;
    }
}