'use strict';

export class ViewAttachmentsPanel implements ng.IDirective {
    public restrict:string = 'E';  // E = element, A = attribute, C = class, M = comment
    public templateUrl:string = "./src/_directives/panels/viewAttachmentsPanel.html";
    public transclude:boolean = false;
    // DOM manipulation
    public scope:any = {
        identifier: '@',
        data: '=',
        section: '@',
        filterBySection: '='
    };

    // @ngInject
    constructor(private $log, private FileManagerService) {}

    public static Factory() {
        const directive = ($log, FileManagerService) => new ViewAttachmentsPanel($log, FileManagerService);
        directive.$inject = ['$log', 'FileManagerService'];
        return directive;
    }
}