'use strict';

export class LeftSidePanel implements ng.IDirective {
    public restrict:string = 'E';  // E = element, A = attribute, C = class, M = comment
    public transclude:boolean = true;
    public templateUrl:string = "./src/_directives/panels/leftSidePanel.template.html";
    public scope:boolean = true;

    // DOM manipulation
    public link = ($scope, $element, $attr, ...args) => {
        var isOpen:string = $attr['isopen'];
        var panelWidth:string = $attr['panelwidth'];
        this.$log.info("Left side panel open: %s", isOpen);
        this.$log.info("Left side panel width: %s", panelWidth);

        if(panelWidth){
            this.SidePanelService.leftPanelWidthOpened = panelWidth;
        }

        if(isOpen){
            if("true" === isOpen.toLowerCase()){
                this.SidePanelService.toggleLeftPanel();
            }
        }
    };

    // @ngInject
    constructor(private $log, private SidePanelService) {
        LeftSidePanel.prototype.link = (scope, element, attr) => {
        };
    }

    public static Factory() {
        const directive = ($log, SidePanelService) => new LeftSidePanel($log, SidePanelService);
        directive.$inject = ['$log', 'SidePanelService'];
        return directive;
    }
}