define(["require", "exports"], function (require, exports) {
    'use strict';
    var RightSidePanel = (function () {
        // @ngInject
        function RightSidePanel($log, SidePanelService) {
            var _this = this;
            this.$log = $log;
            this.SidePanelService = SidePanelService;
            this.restrict = 'E'; // E = element, A = attribute, C = class, M = comment
            this.transclude = true;
            this.templateUrl = "./src/_directives/panels/rightSidePanel.template.html";
            this.scope = true;
            // DOM manipulation
            this.link = function ($scope, $element, $attr) {
                var args = [];
                for (var _i = 3; _i < arguments.length; _i++) {
                    args[_i - 3] = arguments[_i];
                }
                var isOpen = $attr['isopen'];
                var panelWidth = $attr['panelwidth'];
                _this.$log.info("Right side panel open: %s", isOpen);
                _this.$log.info("Right side panel width: %s", panelWidth);
                if (panelWidth) {
                    _this.SidePanelService.rightPanelWidthOpened = panelWidth;
                }
                if (isOpen) {
                    if ("true" === isOpen.toLowerCase()) {
                        _this.SidePanelService.toggleRightPanel();
                    }
                }
            };
            RightSidePanel.prototype.link = function (scope, element, attr) {
            };
        }
        RightSidePanel.Factory = function () {
            var directive = function ($log, SidePanelService) { return new RightSidePanel($log, SidePanelService); };
            directive.$inject = ['$log', 'SidePanelService'];
            return directive;
        };
        return RightSidePanel;
    }());
    exports.RightSidePanel = RightSidePanel;
});
//# sourceMappingURL=rightSidePanel.directive.js.map