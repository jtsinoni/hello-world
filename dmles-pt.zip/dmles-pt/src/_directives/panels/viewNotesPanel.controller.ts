export class ViewNotesPanelController {
    private controllerName:string = "ViewNotesPanelController Directive";

    public collapsed:boolean;

    constructor( private $log) {
        this.$log.debug('%s - Start', this.controllerName);
        this.collapsed = true;
    }

    public collapse(){
        this.collapsed=!this.collapsed;
    }
}