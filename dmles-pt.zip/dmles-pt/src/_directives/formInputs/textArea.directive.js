define(["require", "exports", "./textArea.controller"], function (require, exports, textArea_controller_1) {
    "use strict";
    var TextArea = (function () {
        // @ngInject
        function TextArea($log) {
            this.$log = $log;
            this.restrict = "EA";
            this.controller = textArea_controller_1.TextAreaController;
            this.controllerAs = 'ctrl';
            this.transclude = false;
            this.templateUrl = "./src/_directives/formInputs/textArea.template.html";
            this.bindToController = {
                charLimit: '@',
                dmlesValue: '=',
                inputId: '@',
                label: '@',
                required: '=',
                onChange: '&',
                placeholder: '@',
                isReadOnly: '=',
                title: '@'
            };
            this.scope = {};
        }
        TextArea.Factory = function () {
            var directive = function ($log) { return new TextArea($log); };
            directive.$inject = ['$log'];
            return directive;
        };
        return TextArea;
    }());
    exports.TextArea = TextArea;
});
//# sourceMappingURL=textArea.directive.js.map