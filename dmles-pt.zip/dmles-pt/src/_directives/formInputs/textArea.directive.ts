import
{TextAreaController} from "./textArea.controller";

export class TextArea implements ng.IDirective {
    public restrict:string = "EA";
    public controller = TextAreaController;
    public controllerAs: string = 'ctrl';
    public transclude:boolean = false;
    public templateUrl:string = "./src/_directives/formInputs/textArea.template.html";

    public bindToController:any = {
        charLimit: '@', //Has to be greater than 20
        dmlesValue: '=',
        inputId: '@',
        label: '@',
        required: '=',
        onChange: '&',
        placeholder: '@',
        isReadOnly: '=',
        title: '@'
    };

    public scope: any = {};

    // @ngInject
    constructor(private $log) {}

    public static Factory() {
        const directive = ($log) => new TextArea($log);
        directive.$inject = ['$log'];
        return directive;
    }
}