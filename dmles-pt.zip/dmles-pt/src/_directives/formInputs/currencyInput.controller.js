define(["require", "exports"], function (require, exports) {
    "use strict";
    var CurrencyInputController = (function () {
        function CurrencyInputController($scope, $log) {
            var _this = this;
            this.$scope = $scope;
            this.$log = $log;
            this.controllerName = "CurrencyInputController Directive";
            this.$log.debug('%s - Start', this.controllerName);
            this.$scope.$watch(function () { return _this.dmlesValue; }, function (newValue, oldValue) {
                _this.onChange();
            });
        }
        return CurrencyInputController;
    }());
    exports.CurrencyInputController = CurrencyInputController;
});
//# sourceMappingURL=currencyInput.controller.js.map