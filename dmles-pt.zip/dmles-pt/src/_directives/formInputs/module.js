define(["require", "exports", './currencyInput.controller', './currencyInput.directive', './quantityInput.controller', './quantityInput.directive', './textArea.controller', './textArea.directive', './textInput.controller', './textInput.directive', './textInputwButton.controller', './textInputwButton.directive'], function (require, exports, currencyInput_controller_1, currencyInput_directive_1, quantityInput_controller_1, quantityInput_directive_1, textArea_controller_1, textArea_directive_1, textInput_controller_1, textInput_directive_1, textInputwButton_controller_1, textInputwButton_directive_1) {
    "use strict";
    var formInputsModule = angular.module('FormInputsModule', []);
    formInputsModule.controller('CurrencyInputController', currencyInput_controller_1.CurrencyInputController);
    formInputsModule.controller('QuantityInputController', quantityInput_controller_1.QuantityInputController);
    formInputsModule.controller('TextAreaController', textArea_controller_1.TextAreaController);
    formInputsModule.controller('TextInputController', textInput_controller_1.TextInputController);
    formInputsModule.controller('TextInputwButtonController', textInputwButton_controller_1.TextInputwButtonController);
    formInputsModule.directive('dmlesCurrencyInput', currencyInput_directive_1.CurrencyInput.Factory());
    formInputsModule.directive('dmlesQuantityInput', quantityInput_directive_1.QuantityInput.Factory());
    formInputsModule.directive('dmlesTextArea', textArea_directive_1.TextArea.Factory());
    formInputsModule.directive('dmlesTextInput', textInput_directive_1.TextInput.Factory());
    formInputsModule.directive('dmlesTextInputwButton', textInputwButton_directive_1.TextInputwButton.Factory());
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = formInputsModule;
});
//# sourceMappingURL=module.js.map