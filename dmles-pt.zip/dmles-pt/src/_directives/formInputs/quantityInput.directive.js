define(["require", "exports", "./quantityInput.controller"], function (require, exports, quantityInput_controller_1) {
    "use strict";
    var QuantityInput = (function () {
        // @ngInject
        function QuantityInput($log) {
            this.$log = $log;
            this.restrict = "EA";
            this.controller = quantityInput_controller_1.QuantityInputController;
            this.controllerAs = 'ctrl';
            this.templateUrl = "./src/_directives/formInputs/quantityInput.template.html";
            this.bindToController = {
                dmlesValue: '=',
                formPathInvalid: '=',
                inputId: '@',
                label: '@',
                max: '@',
                min: '@',
                required: '=',
                onChange: '&',
                isReadOnly: '=',
                title: '@'
            };
            this.scope = {};
        }
        QuantityInput.Factory = function () {
            var directive = function ($log) { return new QuantityInput($log); };
            directive.$inject = ['$log'];
            return directive;
        };
        return QuantityInput;
    }());
    exports.QuantityInput = QuantityInput;
});
//# sourceMappingURL=quantityInput.directive.js.map