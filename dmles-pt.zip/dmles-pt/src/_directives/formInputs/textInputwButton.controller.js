define(["require", "exports"], function (require, exports) {
    "use strict";
    var TextInputwButtonController = (function () {
        function TextInputwButtonController($scope, $log) {
            var _this = this;
            this.$scope = $scope;
            this.$log = $log;
            this.controllerName = "TextInputwButtonController Directive";
            this.defaultMaxChar = 120;
            this.$log.debug('%s - Start', this.controllerName);
            this.$scope.$watch(function () { return _this.dmlesValue; }, function (newValue, oldValue) {
                _this.onChange();
            });
            this.init();
        }
        TextInputwButtonController.prototype.init = function () {
            if (this.charLimit == null) {
                this.charLimit = this.defaultMaxChar;
            }
        };
        return TextInputwButtonController;
    }());
    exports.TextInputwButtonController = TextInputwButtonController;
});
//# sourceMappingURL=textInputwButton.controller.js.map