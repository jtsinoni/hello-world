define(["require", "exports"], function (require, exports) {
    "use strict";
    var QuantityInputController = (function () {
        function QuantityInputController($scope, $log) {
            var _this = this;
            this.$scope = $scope;
            this.$log = $log;
            this.controllerName = "QuantityInputController Directive";
            this.defaultMax = 99999;
            this.defaultMin = 1;
            this.$log.debug('%s - Start', this.controllerName);
            //This is fires the onChange event
            this.$scope.$watch(function () { return _this.dmlesValue; }, function (newValue, oldValue) {
                _this.onChange();
            });
            this.init();
        }
        QuantityInputController.prototype.init = function () {
            if (this.max == null) {
                this.max = this.defaultMax;
            }
            if (this.min == null) {
                this.min = this.defaultMin;
            }
        };
        return QuantityInputController;
    }());
    exports.QuantityInputController = QuantityInputController;
});
//# sourceMappingURL=quantityInput.controller.js.map