import
{TextInputController} from "./textInput.controller";

export class TextInput implements ng.IDirective {
    public restrict:string = "EA";
    public controller = TextInputController;
    public controllerAs: string = 'ctrl';
    public transclude:boolean = false;
    public templateUrl:string = "./src/_directives/formInputs/textInput.template.html";

    public bindToController:any = {
        charLimit: '@', //Has to be greater than 20
        dmlesValue: '=',
       // formPathInvalid: '=', //ie: parentFormName.elementName.$invalid. This will show or hide the invalid input error popover
        inputId: '@',
        label: '@',
        required: '=',
        onChange: '&',
        placeholder: '@',
        isReadOnly: '=',
        title: '@'
    };

    public scope: any = {};

    // @ngInject
    constructor(private $log) {}

    public static Factory() {
        const directive = ($log) => new TextInput($log);
        directive.$inject = ['$log'];
        return directive;
    }
}