define(["require", "exports", "./currencyInput.controller"], function (require, exports, currencyInput_controller_1) {
    "use strict";
    var CurrencyInput = (function () {
        // @ngInject
        function CurrencyInput($log) {
            this.$log = $log;
            this.restrict = "EA";
            this.controller = currencyInput_controller_1.CurrencyInputController;
            this.controllerAs = 'ctrl';
            this.transclude = false;
            this.templateUrl = "./src/_directives/formInputs/currencyInput.template.html";
            this.bindToController = {
                dmlesValue: '=',
                formPathInvalid: '=',
                inputId: '@',
                label: '@',
                required: '=',
                onChange: '&',
                isReadOnly: '=',
                title: '@'
            };
            this.scope = {};
        }
        CurrencyInput.Factory = function () {
            var directive = function ($log) { return new CurrencyInput($log); };
            directive.$inject = ['$log'];
            return directive;
        };
        return CurrencyInput;
    }());
    exports.CurrencyInput = CurrencyInput;
});
//# sourceMappingURL=currencyInput.directive.js.map