export class CurrencyInputController {
    private controllerName:string = "CurrencyInputController Directive";

    public dmlesValue:any;
    public onChange;

    constructor(public $scope, private $log) {
        this.$log.debug('%s - Start', this.controllerName);


        this.$scope.$watch(() => { return this.dmlesValue;}, (newValue, oldValue) => {
            this.onChange();
        });
    }
}