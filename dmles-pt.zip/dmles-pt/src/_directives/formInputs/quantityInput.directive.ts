import
{QuantityInputController} from "./quantityInput.controller";

export class QuantityInput implements ng.IDirective {
    public restrict:string = "EA";
    public controller = QuantityInputController;
    public controllerAs: string = 'ctrl';
    public templateUrl:string = "./src/_directives/formInputs/quantityInput.template.html";

    public bindToController:any = {
        dmlesValue: '=',
        formPathInvalid: '=', //ie: parentFormName.elementName.$invalid. This will show or hide the invalid input error popover
        inputId: '@',
        label: '@',
        required: '=',
        onChange: '&',
        isReadOnly: '=',
        title: '@'
    };

    public scope: any = {};

    // @ngInject
    constructor(private $log) {}

    public static Factory() {
        const directive = ($log) => new QuantityInput($log);
        directive.$inject = ['$log'];
        return directive;
    }
}