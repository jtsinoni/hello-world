export class TextAreaController {
    private controllerName:string = "TextAreaController Directive";

    private defaultMaxChar:number = 4000;

    public charLimit:number;
    public dmlesValue:any;
    public onChange;

    constructor(public $scope, private $log) {
        this.$log.debug('%s - Start', this.controllerName);

        this.$scope.$watch(() => { return this.dmlesValue;}, (newValue, oldValue) => {
            this.onChange();
        });

        this.init();
    }

    private init(){
        if (this.charLimit == null){
            this.charLimit = this.defaultMaxChar;
        }
    }
}