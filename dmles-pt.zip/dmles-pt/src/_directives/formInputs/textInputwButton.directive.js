define(["require", "exports", "./textInputwButton.controller"], function (require, exports, textInputwButton_controller_1) {
    "use strict";
    var TextInputwButton = (function () {
        // @ngInject
        function TextInputwButton($log) {
            this.$log = $log;
            this.restrict = "EA";
            this.controller = textInputwButton_controller_1.TextInputwButtonController;
            this.controllerAs = 'ctrl';
            this.transclude = false;
            this.templateUrl = "./src/_directives/formInputs/textInputwButton.template.html";
            this.bindToController = {
                buttonPosition: '@',
                buttonIcon: '@',
                buttonStyleClasses: '@',
                buttonText: '@',
                charLimit: '@',
                dmlesValue: '=',
                inputId: '@',
                label: '@',
                required: '=',
                onChange: '&',
                onClick: '&',
                placeholder: '@',
                isFieldReadOnly: '=',
                title: '@'
            };
            this.scope = {};
        }
        TextInputwButton.Factory = function () {
            var directive = function ($log) { return new TextInputwButton($log); };
            directive.$inject = ['$log'];
            return directive;
        };
        return TextInputwButton;
    }());
    exports.TextInputwButton = TextInputwButton;
});
//# sourceMappingURL=textInputwButton.directive.js.map