define(["require", "exports"], function (require, exports) {
    "use strict";
    var TextInputController = (function () {
        function TextInputController($scope, $log) {
            var _this = this;
            this.$scope = $scope;
            this.$log = $log;
            this.controllerName = "TextInputController Directive";
            this.defaultMaxChar = 120;
            this.$log.debug('%s - Start', this.controllerName);
            this.$scope.$watch(function () { return _this.dmlesValue; }, function (newValue, oldValue) {
                _this.onChange();
            });
            this.init();
        }
        TextInputController.prototype.init = function () {
            if (this.charLimit == null) {
                this.charLimit = this.defaultMaxChar;
            }
        };
        return TextInputController;
    }());
    exports.TextInputController = TextInputController;
});
//# sourceMappingURL=textInput.controller.js.map