import
{CurrencyInputController} from "./currencyInput.controller";

export class CurrencyInput implements ng.IDirective {
    public restrict:string = "EA";
    public controller = CurrencyInputController;
    public controllerAs: string = 'ctrl';
    public transclude:boolean = false;
    public templateUrl:string = "./src/_directives/formInputs/currencyInput.template.html";

    public bindToController:any = {
        dmlesValue: '=',
        formPathInvalid: '=', //ie: parentFormName.elementName.$invalid. This will show or hide the invalid input error popover
        inputId: '@',
        label: '@',
        required: '=',
        onChange: '&',
        isReadOnly: '=',
        title: '@'
    };

    public scope: any = {};

    // @ngInject
    constructor(private $log) {}

    public static Factory() {
        const directive = ($log) => new CurrencyInput($log);
        directive.$inject = ['$log'];
        return directive;
    }
}