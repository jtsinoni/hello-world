import
{TextInputwButtonController} from "./textInputwButton.controller";

export class TextInputwButton implements ng.IDirective {
    public restrict:string = "EA";
    public controller = TextInputwButtonController;
    public controllerAs: string = 'ctrl';
    public transclude:boolean = false;
    public templateUrl:string = "./src/_directives/formInputs/textInputwButton.template.html";

    public bindToController:any = {
        buttonPosition: '@', //Can either be 'left' or 'right'
        buttonIcon: '@',
        buttonStyleClasses: '@',
        buttonText: '@',
        charLimit: '@', //Has to be greater than 20
        dmlesValue: '=',
        inputId: '@',
        label: '@',
        required: '=',
        onChange: '&',
        onClick: '&',
        placeholder: '@',
        isFieldReadOnly: '=',
        title: '@'
    };

    public scope: any = {};

    // @ngInject
    constructor(private $log) {}

    public static Factory() {
        const directive = ($log) => new TextInputwButton($log);
        directive.$inject = ['$log'];
        return directive;
    }
}