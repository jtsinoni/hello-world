define(["require", "exports", "./textInput.controller"], function (require, exports, textInput_controller_1) {
    "use strict";
    var TextInput = (function () {
        // @ngInject
        function TextInput($log) {
            this.$log = $log;
            this.restrict = "EA";
            this.controller = textInput_controller_1.TextInputController;
            this.controllerAs = 'ctrl';
            this.transclude = false;
            this.templateUrl = "./src/_directives/formInputs/textInput.template.html";
            this.bindToController = {
                charLimit: '@',
                dmlesValue: '=',
                // formPathInvalid: '=', //ie: parentFormName.elementName.$invalid. This will show or hide the invalid input error popover
                inputId: '@',
                label: '@',
                required: '=',
                onChange: '&',
                placeholder: '@',
                isReadOnly: '=',
                title: '@'
            };
            this.scope = {};
        }
        TextInput.Factory = function () {
            var directive = function ($log) { return new TextInput($log); };
            directive.$inject = ['$log'];
            return directive;
        };
        return TextInput;
    }());
    exports.TextInput = TextInput;
});
//# sourceMappingURL=textInput.directive.js.map