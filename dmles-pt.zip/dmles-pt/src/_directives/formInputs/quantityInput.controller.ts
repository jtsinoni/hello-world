export class QuantityInputController {
    private controllerName:string = "QuantityInputController Directive";

    public dmlesValue:any;
    public onChange;

    constructor(public $scope, private $log) {
        this.$log.debug('%s - Start', this.controllerName);


        //This is fires the onChange event
        this.$scope.$watch(() => { return this.dmlesValue;}, (newValue, oldValue) => {
            this.onChange();
        });
    }
}