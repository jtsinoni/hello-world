export class QuantityInputController {
    private controllerName:string = "QuantityInputController Directive";

    private defaultMax:number = 99999;
    private defaultMin:number = 1;

    public dmlesValue:any;
    public max:number;
    public min:number;
    public onChange;

    constructor(public $scope, private $log) {
        this.$log.debug('%s - Start', this.controllerName);

        //This is fires the onChange event
        this.$scope.$watch(() => { return this.dmlesValue;}, (newValue, oldValue) => {
            this.onChange();
        });

        this.init();
    }

    private init(){
        if (this.max == null){
            this.max = this.defaultMax;
        }

        if (this.min == null){
            this.min = this.defaultMin;
        }
    }
}