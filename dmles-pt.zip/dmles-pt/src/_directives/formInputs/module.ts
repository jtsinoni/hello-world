import {CurrencyInputController} from './currencyInput.controller';
import {CurrencyInput} from './currencyInput.directive';
import {QuantityInputController} from './quantityInput.controller';
import {QuantityInput} from './quantityInput.directive';
import {TextAreaController} from './textArea.controller';
import {TextArea} from './textArea.directive';
import {TextInputController} from './textInput.controller';
import {TextInput} from './textInput.directive';
import {TextInputwButtonController} from './textInputwButton.controller'
import {TextInputwButton} from './textInputwButton.directive';

var formInputsModule = angular.module('FormInputsModule', []);
formInputsModule.controller('CurrencyInputController', CurrencyInputController);
formInputsModule.controller('QuantityInputController', QuantityInputController);
formInputsModule.controller('TextAreaController', TextAreaController);
formInputsModule.controller('TextInputController', TextInputController);
formInputsModule.controller('TextInputwButtonController', TextInputwButtonController);
formInputsModule.directive('dmlesCurrencyInput', CurrencyInput.Factory());
formInputsModule.directive('dmlesQuantityInput', QuantityInput.Factory());
formInputsModule.directive('dmlesTextArea', TextArea.Factory());
formInputsModule.directive('dmlesTextInput', TextInput.Factory());
formInputsModule.directive('dmlesTextInputwButton', TextInputwButton.Factory());

export default formInputsModule;