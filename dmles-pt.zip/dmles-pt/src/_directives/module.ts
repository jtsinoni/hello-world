import {LeftSidePanel} from './panels/leftSidePanel.directive';
import {RightSidePanel} from './panels/rightSidePanel.directive';
import {ViewNotesPanel} from './panels/viewNotesPanel.directive';
import {ViewAttachmentsPanel} from './panels/viewAttachmentsPanel.directive';
import {elementChecker} from './elementChecker/elementChecker.directive';
import {MainNav} from './mainNav/mainNav.directive';
import {MainNavController} from './mainNav/mainNav.controller';
import {MainNavService} from './mainNav/mainNav.service';
import {DmlesHideAttr} from './utils/dmlesHideAttr.directive';
import {DmlesPanelTableController} from './tables/dmlesPanelTable.controller';
import {DmlesPanelTable} from './tables/dmlesPanelTable.directive';
import {DmlesTable} from './tables/dmlesTable.directive';
import {DmlesTableController} from './tables/dmlesTable.controller';
import {DmlesTest} from './tables/dmlesTest.directive';
import {DmlesTestController} from './tables/dmlesTest.controller';
import {DmlesToolTip} from './tooltips/dmlesToolTip.directive';
import {DmlesToolTipController} from './tooltips/dmlesToolTip.controller';
import {DmlesTree} from './tree/dmlesTree.directive';
import {DmlesTreeController} from './tree/dmlesTree.controller';
import {DmlesTreeData} from './tree/dmlesTreeData.model';
import {RemoveButton} from './buttons/removeButton.directive';
import {DmlesCheckboxTableController} from './tables/dmlesCheckboxTable.controller';
import {DmlesCheckboxTable} from './tables/dmlesCheckboxTable.directive';

// TODO: Break these up into separate modules per directive

import formInputsModule from './formInputs/module';

var directivesModule = angular.module('DirectivesModule', [
    formInputsModule.name,
]);
directivesModule.controller('MainNavController', MainNavController);
directivesModule.controller('DmlesPanelTableController', DmlesPanelTableController);
directivesModule.controller('DmlesTableController', DmlesTableController);
directivesModule.controller('DmlesTestController', DmlesTestController);
directivesModule.controller('DmlesToolTipController', DmlesToolTipController);
directivesModule.controller('DmlesTreeController', DmlesTreeController);
directivesModule.directive('dmlesTest', DmlesTest.Factory());
directivesModule.directive('leftSidePanel', LeftSidePanel.Factory());
directivesModule.directive('rightSidePanel', RightSidePanel.Factory());
directivesModule.directive('viewNotesPanel', ViewNotesPanel.Factory());
directivesModule.directive('viewAttachmentsPanel', ViewAttachmentsPanel.Factory());
directivesModule.directive('elementChecker', elementChecker.Factory());
directivesModule.directive('mainNav', MainNav.Factory());
directivesModule.directive('dmlesHideAttr', DmlesHideAttr.Factory());
directivesModule.directive('dmlesPanelTable', DmlesPanelTable.Factory());
directivesModule.directive('dmlesTable', DmlesTable.Factory());
directivesModule.directive('dmlesTree', DmlesTree.Factory());
directivesModule.directive('dmlesToolTip', DmlesToolTip.Factory());
directivesModule.directive('removeButton', RemoveButton.Factory());
directivesModule.service('MainNavService', MainNavService);
directivesModule.value('DmlesTreeData', DmlesTreeData);
directivesModule.controller('DmlesCheckboxTableController', DmlesCheckboxTableController);
directivesModule.directive('dmlesCheckboxTable', DmlesCheckboxTable.Factory());

export default directivesModule;