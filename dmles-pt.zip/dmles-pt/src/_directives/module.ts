import {LeftSidePanel} from './panels/leftSidePanel.directive';
import {RightSidePanel} from './panels/rightSidePanel.directive';
import {ViewNotesPanel} from './panels/viewNotesPanel.directive';
import {ViewAttachmentsPanel} from './panels/viewAttachmentsPanel.directive';
import {ViewNotesPanelController} from './panels/viewNotesPanel.controller'
import {elementChecker} from './elementChecker/elementChecker.directive';
import {MainNav} from './mainNav/mainNav.directive';
import {MainNavController} from './mainNav/mainNav.controller';
import {MainNavService} from './mainNav/mainNav.service';
import {DmlesToolTip} from './tooltips/dmlesToolTip.directive';
import {DmlesToolTipController} from './tooltips/dmlesToolTip.controller';
import {DmlesTree} from './tree/dmlesTree.directive';
import {DmlesTreeController} from './tree/dmlesTree.controller';
import {DmlesTreeData} from './tree/dmlesTreeData.model';
import {RemoveButton} from './buttons/removeButton.directive';

import fieldsModule from './fields/module';
import fileUploadModule from './fileUpload/module';
import formInputsModule from './formInputs/module';
import formOtherModule from './formOther/module';
import modalModule from './modals/module';
import notesModule from './notes/module';
import searchComponentsModule from './searchComponents/module';
import tableModule from './tables/module';
import utilsModule from './utils/module';

var directivesModule = angular.module('DirectivesModule', [
    fieldsModule.name,
    fileUploadModule.name,
    formInputsModule.name,
    formOtherModule.name,
    modalModule.name,
    notesModule.name,
    searchComponentsModule.name,
    tableModule.name,
    utilsModule.name
]);

directivesModule.controller('MainNavController', MainNavController);
directivesModule.controller('DmlesToolTipController', DmlesToolTipController);
directivesModule.controller('DmlesTreeController', DmlesTreeController);
directivesModule.controller('ViewNotesPanelController', ViewNotesPanelController);
directivesModule.directive('leftSidePanel', LeftSidePanel.Factory());
directivesModule.directive('rightSidePanel', RightSidePanel.Factory());
directivesModule.directive('viewNotesPanel', ViewNotesPanel.Factory());
directivesModule.directive('viewAttachmentsPanel', ViewAttachmentsPanel.Factory());
directivesModule.directive('elementChecker', elementChecker.Factory());
directivesModule.directive('mainNav', MainNav.Factory());
directivesModule.directive('dmlesTree', DmlesTree.Factory());
directivesModule.directive('dmlesToolTip', DmlesToolTip.Factory());
directivesModule.directive('removeButton', RemoveButton.Factory());
directivesModule.service('MainNavService', MainNavService);
directivesModule.value('DmlesTreeData', DmlesTreeData);

export default directivesModule;