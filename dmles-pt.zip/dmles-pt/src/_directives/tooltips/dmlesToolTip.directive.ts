import {DmlesToolTipController} from "./dmlesToolTip.controller";

export class DmlesToolTip implements ng.IDirective {
    public restrict:string = 'E';  // E = element, A = attribute, C = class, M = comment
    public transclude:boolean = true;
    public templateUrl:string = "./src/_directives/tooltips/dmlesToolTip.template.html";
    public scope:any = {
        tip: '@',
        position: '@'
    };

    // @ngInject
    constructor(private $log, private $compile) {}

    public static Factory() {
        const directive = ($log, $compile) => new DmlesToolTip($log, $compile);
        directive.$inject = ['$log', '$compile'];
        return directive;
    }
}