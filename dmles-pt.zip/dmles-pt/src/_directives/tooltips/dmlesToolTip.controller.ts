export class DmlesToolTipController {
    private controllerName:string = "DmlesToolTipController";

    public dmlesTip:string = null;
    public dmlesPosition:string = null;

    //@inject
    constructor(private $log, public $compile, public $element) {
        this.$log.debug('%s - Start', this.controllerName);

        this.dmlesTip = $element.attr('tip');
        this.dmlesPosition = $element.attr('position');
        this.$log.debug("controller tip: %s", this.dmlesTip);
        this.$log.debug("controller position: %s", this.dmlesPosition);

    }

}