define(["require", "exports"], function (require, exports) {
    "use strict";
    var DmlesToolTip = (function () {
        // @ngInject
        function DmlesToolTip($log, $compile) {
            this.$log = $log;
            this.$compile = $compile;
            this.restrict = 'E'; // E = element, A = attribute, C = class, M = comment
            this.transclude = true;
            this.templateUrl = "./src/_directives/tooltips/dmlesToolTip.template.html";
            this.scope = {
                tip: '@',
                position: '@'
            };
        }
        DmlesToolTip.Factory = function () {
            var directive = function ($log, $compile) { return new DmlesToolTip($log, $compile); };
            directive.$inject = ['$log', '$compile'];
            return directive;
        };
        return DmlesToolTip;
    }());
    exports.DmlesToolTip = DmlesToolTip;
});
//# sourceMappingURL=dmlesToolTip.directive.js.map