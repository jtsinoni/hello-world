define(["require", "exports"], function (require, exports) {
    "use strict";
    var DmlesToolTipController = (function () {
        //@inject
        function DmlesToolTipController($log, $compile, $element) {
            this.$log = $log;
            this.$compile = $compile;
            this.$element = $element;
            this.controllerName = "DmlesToolTipController";
            this.dmlesTip = null;
            this.dmlesPosition = null;
            this.$log.debug('%s - Start', this.controllerName);
            this.dmlesTip = $element.attr('tip');
            this.dmlesPosition = $element.attr('position');
            this.$log.debug("controller tip: %s", this.dmlesTip);
            this.$log.debug("controller position: %s", this.dmlesPosition);
        }
        return DmlesToolTipController;
    }());
    exports.DmlesToolTipController = DmlesToolTipController;
});
//# sourceMappingURL=dmlesToolTip.controller.js.map