define(["require", "exports", "./noteTable.controller"], function (require, exports, noteTable_controller_1) {
    "use strict";
    var NoteTable = (function () {
        // @ngInject
        function NoteTable($log) {
            this.$log = $log;
            this.restrict = "EA";
            this.controller = noteTable_controller_1.NoteTableController;
            this.controllerAs = 'ctrl';
            this.templateUrl = "./src/_directives/notes/noteTable.template.html";
            this.transclude = true;
            this.bindToController = {
                filterBySection: '=',
                heading: '@',
                data: '=',
                isReadOnly: '=',
                onRemoveNote: '&',
                onSaveNote: '&',
                section: '@',
                showSections: '='
            };
            this.scope = {};
        }
        NoteTable.Factory = function () {
            var directive = function ($log) { return new NoteTable($log); };
            directive.$inject = ['$log'];
            return directive;
        };
        return NoteTable;
    }());
    exports.NoteTable = NoteTable;
});
//# sourceMappingURL=noteTable.directive.js.map