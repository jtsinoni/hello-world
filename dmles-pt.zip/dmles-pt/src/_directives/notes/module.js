define(["require", "exports", './noteTable.controller', './noteTable.directive'], function (require, exports, noteTable_controller_1, noteTable_directive_1) {
    "use strict";
    var dmlesNotesModule = angular.module('DmlesNotesModule', []);
    dmlesNotesModule.controller('NoteTableController', noteTable_controller_1.NoteTableController);
    dmlesNotesModule.directive('dmlesNoteTable', noteTable_directive_1.NoteTable.Factory());
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = dmlesNotesModule;
});
//# sourceMappingURL=module.js.map