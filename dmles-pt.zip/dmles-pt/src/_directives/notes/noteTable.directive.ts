import
{NoteTableController} from "./noteTable.controller";

export class NoteTable implements ng.IDirective {
    public restrict:string = "EA";
    public controller = NoteTableController;
    public controllerAs: string = 'ctrl';
    public templateUrl:string = "./src/_directives/notes/noteTable.template.html";
    public transclude: boolean = true;

    public bindToController:any = {
        filterBySection: '=',
        heading: '@',
        data: '=',
        isReadOnly: '=',
        onRemoveNote: '&',
        onSaveNote: '&',
        section: '@',
        showSections: '='
    };

    public scope: any = {};

    // @ngInject
    constructor(private $log) {}

    public static Factory() {
        const directive = ($log) => new NoteTable($log);
        directive.$inject = ['$log'];
        return directive;
    }
}