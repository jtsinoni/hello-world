define(["require", "exports", '../../_models/currentUserProfile.model'], function (require, exports, currentUserProfile_model_1) {
    'use strict';
    var NoteTableController = (function () {
        function NoteTableController($scope, $log, UserService) {
            this.$scope = $scope;
            this.$log = $log;
            this.UserService = UserService;
            this.controllerName = "NoteTableController Directive";
            this.currentUser = new currentUserProfile_model_1.CurrentUserProfile();
            this.isEditing = false;
            this.$log.debug('%s - Start ->', this.controllerName);
            this.currentUser = this.UserService.currentUser;
            if (this.showSections == null) {
                this.showSections = true;
            }
        }
        NoteTableController.prototype.cancelEdit = function () {
            this.isEditing = false;
            this.noteToEdit = null;
        };
        NoteTableController.prototype.editNote = function (note) {
            this.noteToEdit = angular.copy(note);
            this.isEditing = true;
        };
        NoteTableController.prototype.saveNote = function () {
            this.noteToEdit.section = this.section;
            this.onSaveNote({ note: this.noteToEdit });
            this.noteToEdit = null;
            this.isEditing = false;
        };
        NoteTableController.prototype.removeNote = function (noteToBeDeleted) {
            this.onRemoveNote({ note: noteToBeDeleted });
        };
        return NoteTableController;
    }());
    exports.NoteTableController = NoteTableController;
});
//# sourceMappingURL=noteTable.controller.js.map