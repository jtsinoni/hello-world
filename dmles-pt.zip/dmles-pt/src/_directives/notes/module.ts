import {NoteTableController} from './noteTable.controller';
import {NoteTable} from './noteTable.directive';



var dmlesNotesModule = angular.module('DmlesNotesModule', []);
dmlesNotesModule.controller('NoteTableController', NoteTableController);
dmlesNotesModule.directive('dmlesNoteTable', NoteTable.Factory());



export default dmlesNotesModule;
