'use strict';
import {CurrentUserProfile} from '../../_models/currentUserProfile.model';
import {Note} from '../../_models/note.model';

export class NoteTableController {

    protected controllerName: string = "NoteTableController Directive";
    private currentUser:CurrentUserProfile = new CurrentUserProfile();

    public filterBySection:boolean;
    public isEditing:boolean = false;
    public noteToEdit:Note;
    public onRemoveNote: (any) => void;
    public onSaveNote: (any) => void;
    public section:string;
    public showSections:boolean;

    constructor(public $scope, protected $log, private UserService) {
        this.$log.debug('%s - Start ->', this.controllerName);

        this.currentUser = this.UserService.currentUser;

        if(this.showSections == null){
            this.showSections = true;
        }
    }

    public cancelEdit(){
        this.isEditing = false;
        this.noteToEdit = null;
    }

    public editNote(note) {
        this.noteToEdit = angular.copy(note);
        this.isEditing = true;
    }

    public saveNote(){
        this.noteToEdit.section = this.section;
        this.onSaveNote({note:this.noteToEdit});
        this.noteToEdit = null;
        this.isEditing = false;
    }

    public removeNote(noteToBeDeleted){
        this.onRemoveNote({note:noteToBeDeleted});
    }

}