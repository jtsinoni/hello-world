'use strict';

//This is specificallt used for Notes and Attachments
export default function SectionFilter() {
    return function (input:Array<any>, section:string, doFilter:boolean):Array<any> {
        let out = [];
        if (!doFilter) {
            return input;
        }
        angular.forEach(input, function (f:any) {
            if (f.section == section) {
                out.push(f);
            }

        });
        return out;
    }
}