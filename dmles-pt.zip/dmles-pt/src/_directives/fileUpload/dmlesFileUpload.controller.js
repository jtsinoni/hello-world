define(["require", "exports", '../../_models/attachment.model'], function (require, exports, attachment_model_1) {
    'use strict';
    var DmlesFileUploadController = (function () {
        function DmlesFileUploadController($scope, $log, $sce, $uibModal, FileManagerService, FileSaver, FileUploader, NotificationService) {
            this.$scope = $scope;
            this.$log = $log;
            this.$sce = $sce;
            this.$uibModal = $uibModal;
            this.FileManagerService = FileManagerService;
            this.FileSaver = FileSaver;
            this.FileUploader = FileUploader;
            this.NotificationService = NotificationService;
            this.controllerName = "DmlesFileUploadController Directive";
            this._maxPostSize = 102123;
            this.editingDescription = false;
            this.showDescriptionInput = false;
            this.success = true;
            this.isModalRemoveFileOpen = false;
            this.modalRemoveFileTitle = "Remove File";
            this.modalOkText = "Confirm";
            this.modalOkIcon = "fa fa-thumbs-up";
            this.modalCancelIcon = "fa fa-close";
            this.$log.debug('%s - Start ->', this.controllerName);
            this.init(FileUploader);
            this.EventsHandlers();
        }
        Object.defineProperty(DmlesFileUploadController.prototype, "data", {
            get: function () { return this._data; },
            set: function (value) { this._data = value; },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DmlesFileUploadController.prototype, "onCompleteAll", {
            //get onUploadFailed(): (any) => void { return this._onUploadFailed; }
            //set onUploadFailed(value: (any) => void) { this._onUploadFailed = value; }
            //
            //get onUploadCancelled(): (any) => void { return this._onUploadCancelled; }
            //set onUploadCancelled(value: (any) => void) { this._onUploadCancelled = value; }
            //
            //get onUploadCompleted(): (any) => void { return this._onUploadCompleted;  }
            //set onUploadCompleted(value: (any) => void) { this._onUploadCompleted = value; }
            get: function () { return this._onCompleteAll; },
            set: function (value) { this._onCompleteAll = value; },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DmlesFileUploadController.prototype, "onSuccessItem", {
            get: function () { return this._onSuccessItem; },
            set: function (value) { this._onSuccessItem = value; },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DmlesFileUploadController.prototype, "Uploader", {
            //get onCompleteItem(): (any) => void { return this._onCompleteItem; }
            //set onCompleteItem(value: (any) => void) { this._onCompleteItem = value; }
            //
            //get onAfterAddingAll(): (any) => void { return this._onAfterAddingAll;  }
            //set onAfterAddingAll(value: (any) => void) { this._onAfterAddingAll = value; }
            //get onAfterAddingFile(): (any) => void { return this._onAfterAddingFile;  }
            //set onAfterAddingFile(value: (any) => void) { this._onAfterAddingFile = value;  }
            //
            //get onWhenAddingFileFailed(): (any) => void { return this._onWhenAddingFileFailed;  }
            //set onWhenAddingFileFailed(value: (any) => void) { this._onWhenAddingFileFailed = value;  }
            get: function () { return this._Uploader; },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DmlesFileUploadController.prototype, "fileuploader", {
            get: function () { return this._Uploader; },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DmlesFileUploadController.prototype, "section", {
            get: function () { return this._section; },
            set: function (value) { this._section = value; },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DmlesFileUploadController.prototype, "maxPostSize", {
            get: function () { return this._maxPostSize; },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DmlesFileUploadController.prototype, "pemittedFileExtensions", {
            get: function () { return this._permittedFileExtensions; },
            enumerable: true,
            configurable: true
        });
        DmlesFileUploadController.prototype.init = function (FileUploader) {
            var _this = this;
            var mainThis = this;
            this._Uploader = new FileUploader(this.FileManagerService.getUploadConfiguration());
            this.FileManagerService.getMaxPostSize()
                .then(function (returnedVal) {
                _this._maxPostSize = returnedVal.data;
            }, function (reason) {
                _this.$log.debug('%s - Error retrieving Max Post Size: ', reason);
            });
            this.FileManagerService.getPermittedFileExtensions()
                .then(function (returnedVal) {
                _this._permittedFileExtensions = returnedVal.data;
            }, function (reason) {
                _this.$log.debug('%s - Error retrieving permitted File Extensions: ', reason);
            });
            this.Uploader.filters.push({
                name: 'enforceNoDuplicates',
                fn: function (item) {
                    var returnValue = true;
                    mainThis.fileuploader.queue.forEach(function (currrent) {
                        if (currrent.file.name === item.name && currrent.file.size === item.size) {
                            returnValue = false;
                        }
                    });
                    return returnValue;
                }
            });
            this.Uploader.filters.push({
                name: 'enforceMaxFileSize',
                fn: function (item) { return item.size <= mainThis.maxPostSize; }
            });
            this.Uploader.filters.push({
                name: 'enforcePermittedFileExtensions',
                fn: function (item) {
                    var returnValue = true;
                    var name = item.name;
                    for (var index in mainThis.pemittedFileExtensions) {
                        if (name.toUpperCase().indexOf(mainThis.pemittedFileExtensions[index]) > 0) {
                            returnValue = false;
                            break;
                        }
                    }
                    return returnValue;
                }
            });
        };
        DmlesFileUploadController.prototype.EventsHandlers = function () {
            var _this = this;
            this.Uploader.onWhenAddingFileFailed = function (item, filter, options) {
                _this.$log.debug('%s - onWhenAddingFileFailed: ', _this.controllerName, item);
                if (filter != undefined) {
                    switch (filter.name) {
                        case 'enforceMaxFileSize':
                            var sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
                            var index = Math.floor(Math.log(_this.maxPostSize) / Math.log(1000));
                            var number = parseFloat((_this.maxPostSize / Math.pow(1000, index)).toFixed(2));
                            var size = number + ' ' + sizes[index];
                            _this.NotificationService.errorMsg(item.name + " exceeds the maximum file upload size of " + size);
                            break;
                        case 'enforcePermittedFileExtensions':
                            _this.NotificationService.errorMsg('The file (' + item.name + ") is an invalid upload type");
                            break;
                        case 'enforceNoDuplicates':
                            _this.NotificationService.errorMsg('The file (' + item.name + ") already within upload list");
                            break;
                    }
                    _this.$log.debug('%s - onWhenAddingFileFailed: ', _this.controllerName, filter);
                }
                //   this.onWhenAddingFileFailed({item: item, filter: filter, options: options});
            };
            //this.Uploader.onAfterAddingFile = (fileItem: any) => {
            //    this.$log.debug('%s - onAfterAddingFile: ', this.controllerName, fileItem);
            //
            // //   this.onAfterAddingFile({fileItem: fileItem});
            //};
            this.Uploader._onAfterAddingAll = function (addedFileItems) {
                if (_this.showDescription || _this.showDescription == null) {
                    _this.showDescriptionInput = true;
                    _this.descriptionInput = _this.description;
                }
                else {
                    _this.descriptionInput = _this.heading;
                    _this.uploadFiles();
                }
                //    this.onAfterAddingAll({addedFileItems: addedFileItems});
            };
            this.Uploader.onBeforeUploadItem = function (item) {
                _this.success = true;
            };
            //this.Uploader.onProgressItem = (fileItem: any, progress: any) => {
            //    console.info('onProgressItem', fileItem, progress);
            //};
            //
            //this.Uploader.onProgressAll = (progress: any) => {
            //    this.$log.debug('%s - DmlesAdvancedFileUploadController: onProgressAll', this.controllerName);
            //};
            this.Uploader.onSuccessItem = function (fileItem, response, status, headers) {
                if (status == 200) {
                    fileItem.remove();
                }
                var attachment = new attachment_model_1.Attachment();
                attachment.description = _this.descriptionInput;
                attachment.section = _this.section;
                attachment.fileRef = response[0];
                _this.data = attachment;
                _this.onSuccessItem({ response: attachment });
            };
            this.Uploader.onErrorItem = function (fileItem, response, status, headers) {
                _this.NotificationService.errorMsg(response);
            };
            //this.Uploader.onCancelItem = (fileItem: any, response: any, status: any, headers: any) => {
            //    this.onUploadCancelled({fileItem: fileItem, response: response, status: status, headers: headers});
            //};
            this.Uploader.onCompleteItem = function (fileItem, response, status, headers) {
                _this.showDescriptionInput = false;
                _this.descriptionInput = _this.description;
                if (status != 200) {
                    _this.success = false;
                }
                //   this.onCompleteItem({fileItem: fileItem, response: response, status: status, headers: status});
            };
            this.Uploader.onCompleteAll = function () {
                _this.onCompleteAll({ success: _this.success });
            };
        };
        DmlesFileUploadController.prototype.cancelEditDescription = function () {
            this.editingDescription = false;
            this.fileToEdit = null;
        };
        DmlesFileUploadController.prototype.editDescription = function (file) {
            this.editingDescription = true;
            this.fileToEdit = angular.copy(file);
        };
        DmlesFileUploadController.prototype.embedFileToPage = function (fileId) {
            var _this = this;
            this.FileManagerService.download(fileId)
                .success(function (data, status, headers, config) {
                var file = new Blob([data], { type: 'Aplication/pdf' });
                var fileURL = URL.createObjectURL(file);
                _this.FileManagerService.embedContentToDisplay = _this.$sce.trustAsResourceUrl(fileURL);
                var modalInstance = _this.$uibModal.open({
                    animation: true,
                    ariaLabelledBy: 'modal-title',
                    ariaDescribedBy: 'modal-body',
                    backdrop: 'static',
                    size: 'lg',
                    templateUrl: "/src/_directives/fileUpload/embedFileModal.html",
                    controllerAs: 'vm',
                    controller: 'EmbedFileModalInstanceController'
                });
            }).error(function (data, status, headers, config) {
                _this.$log.debug('%s - Error retrieving Max Post Size: ', headers);
            });
        };
        DmlesFileUploadController.prototype.isFileImage = function (fileName) {
            if (fileName.indexOf(".jpg") != -1 ||
                fileName.indexOf(".jpeg") != -1 ||
                fileName.indexOf(".jpe") != -1 ||
                fileName.indexOf(".png") != -1 ||
                fileName.indexOf(".bmp") != -1 ||
                fileName.indexOf(".gif") != -1) {
                return true;
            }
            else {
                return false;
            }
        };
        DmlesFileUploadController.prototype.openFile = function (fileid) {
            var _this = this;
            this.$log.debug('%s - onCompleteAll: ', this.controllerName);
            this.FileManagerService.download(fileid)
                .success(function (data, status, headers, config) {
                var filename = "downloadFile";
                var header = headers('content-disposition');
                if (header && header.indexOf('attachment') !== -1) {
                    var regex = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/;
                    var matches = regex.exec(header);
                    if (matches != null && matches[1]) {
                        filename = matches[1].replace(/['"]/g, '');
                    }
                }
                var file = new Blob([data], { type: 'Aplication/pdf' });
                _this.FileSaver.saveAs(file, filename);
            }).error(function (data, status, headers, config) {
                _this.$log.debug('%s - Error retrieving Max Post Size: ', headers);
            });
        };
        DmlesFileUploadController.prototype.openRemoveFile = function (file) {
            this.fileToBeDeleted = angular.copy(file);
            this.isModalRemoveFileOpen = true;
        };
        DmlesFileUploadController.prototype.removeFile = function () {
            var _this = this;
            var removeFile = this.FileManagerService.removeFile(this.fileToBeDeleted.fileRef.fileId);
            return removeFile.then(function (result) {
                if (result.status == 200) {
                    _this.$log.debug(result);
                    return _this.onRemoveFile({ file: _this.fileToBeDeleted });
                }
                else {
                    _this.NotificationService.errorMsg("There was an error removing the file. Please contact your system administrator.");
                }
            });
        };
        DmlesFileUploadController.prototype.saveFile = function (data, headers) {
            var filename = "downloadFile";
            var header = headers('content-disposition');
            if (header && header.indexOf('attachment') !== -1) {
                var regex = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/;
                var matches = regex.exec(header);
                if (matches != null && matches[1]) {
                    filename = matches[1].replace(/['"]/g, '');
                }
            }
            var file = new Blob([data], { type: 'Aplication/pdf' });
            this.FileSaver.saveAs(file, filename);
        };
        DmlesFileUploadController.prototype.uploadFiles = function () {
            angular.forEach(this.Uploader.queue, function (file) {
                file.upload();
            });
        };
        DmlesFileUploadController.prototype.updateDescription = function () {
            this.data.description = this.fileToEdit.description;
            this.onCompleteAll({ success: this.success });
            this.editingDescription = false;
            this.fileToEdit = null;
        };
        return DmlesFileUploadController;
    }());
    exports.DmlesFileUploadController = DmlesFileUploadController;
});
//# sourceMappingURL=dmlesFileUpload.controller.js.map