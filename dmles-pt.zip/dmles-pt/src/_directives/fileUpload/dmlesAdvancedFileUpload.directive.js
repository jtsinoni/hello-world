define(["require", "exports", "./dmlesAdvancedFileUpload.controller"], function (require, exports, dmlesAdvancedFileUpload_controller_1) {
    "use strict";
    /*
     <dmles-advanced-file-upload
        data="vm.RequestService.request.attachments"
        section="General"
        show-sections="true"
        is-read-only="vm.WorkFlowService.showReadOnly()"
        filter-by-section="false"
        on-success-item="vm.RequestService.onSuccessItem(response)"
        on-complete-all="vm.RequestService.onCompleteAll()"
        on-remove-file="vm.RequestService.onRemoveFile(file)"
        heading="">
     </dmles-advanced-file-upload>
    
     data: this is the array of attachments
     section: (Optional) This is a particular section the attachment is associated with. This would be useful if your object is broken up
                into sections
     show-sections:boolean = (Optional-default is false) show the sections as part of the list or not
     is-read-only:boolean = (Optional-default is false) is the table read only. Only the data is displayed, nothing can be added or edited to the attachent list
     filter-by-section:boolean = (Optional-default is false) do you want the list to only display the other attachments belonging to the same section
     on-success-item:this is the call that returns when an file is uploaded. The function HAS to have an attribute (response:Attachment)
     on-complete-all:this is the call that returns when all files are completed successfully or there was an error.
                The function HAS to have an attribute (success:boolean) This will tell you is it was successful or not "
     on-remove-file: this call returns removes the file from the File Manager and returns it to the function so you can delete
                it out of whatever collect you are saving the attachment to. The function HAS to have an attribute (file:Attachment)
     heading:(Optional)Heading on the file upload area
    
     */
    var DmlesAdvancedFileUpload = (function () {
        // @ngInject
        function DmlesAdvancedFileUpload($log) {
            this.$log = $log;
            this.restrict = "EA";
            this.controller = dmlesAdvancedFileUpload_controller_1.DmlesAdvancedFileUploadController;
            this.controllerAs = 'ctrl';
            this.templateUrl = "./src/_directives/fileUpload/dmlesAdvancedFileUpload.template.html";
            this.transclude = true;
            this.bindToController = {
                filterBySection: '=',
                heading: '@',
                data: '=',
                isReadOnly: '=',
                // onUploadCompleted: '&',
                // onUploadFailed: '&',
                // onUploadCancelled: '&',
                //onCompleteItem: '&',
                //onWhenAddingFileFailed: '&',
                //onAfterAddingAll: '&',
                //onAfterAddingFile: '&',
                onSuccessItem: '&',
                onCompleteAll: '&',
                onRemoveFile: '&',
                section: '@',
                showSections: '='
            };
            this.scope = {};
        }
        DmlesAdvancedFileUpload.Factory = function () {
            var directive = function ($log) { return new DmlesAdvancedFileUpload($log); };
            directive.$inject = ['$log'];
            return directive;
        };
        return DmlesAdvancedFileUpload;
    }());
    exports.DmlesAdvancedFileUpload = DmlesAdvancedFileUpload;
});
//# sourceMappingURL=dmlesAdvancedFileUpload.directive.js.map