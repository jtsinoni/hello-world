define(["require", "exports"], function (require, exports) {
    'use strict';
    //This is specificallt used for Notes and Attachments
    function SectionFilter() {
        return function (input, section, doFilter) {
            var out = [];
            if (!doFilter) {
                return input;
            }
            angular.forEach(input, function (f) {
                if (f.section == section) {
                    out.push(f);
                }
            });
            return out;
        };
    }
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = SectionFilter;
});
//# sourceMappingURL=sectionFilter.filter.js.map