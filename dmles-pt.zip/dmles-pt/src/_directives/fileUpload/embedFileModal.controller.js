define(["require", "exports"], function (require, exports) {
    'use strict';
    var EmbedFileModalInstanceController = (function () {
        // @ngInject
        function EmbedFileModalInstanceController($log, $uibModalInstance, FileManagerService) {
            this.$log = $log;
            this.$uibModalInstance = $uibModalInstance;
            this.FileManagerService = FileManagerService;
        }
        EmbedFileModalInstanceController.prototype.close = function () {
            this.FileManagerService.embedContentToDisplay = null;
            this.$uibModalInstance.dismiss('cancel');
        };
        return EmbedFileModalInstanceController;
    }());
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = EmbedFileModalInstanceController;
});
//# sourceMappingURL=embedFileModal.controller.js.map