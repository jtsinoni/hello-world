var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", '../../_models/attachment.model', "./dmlesFileUpload.controller"], function (require, exports, attachment_model_1, dmlesFileUpload_controller_1) {
    'use strict';
    var DmlesAdvancedFileUploadController = (function (_super) {
        __extends(DmlesAdvancedFileUploadController, _super);
        function DmlesAdvancedFileUploadController($scope, $log, $sce, $uibModal, FileManagerService, FileSaver, FileUploader, NotificationService) {
            _super.call(this, $scope, $log, $sce, $uibModal, FileManagerService, FileSaver, FileUploader, NotificationService);
            this.$scope = $scope;
            this.$log = $log;
            this.$sce = $sce;
            this.$uibModal = $uibModal;
            this.FileManagerService = FileManagerService;
            this.FileSaver = FileSaver;
            this.FileUploader = FileUploader;
            this.NotificationService = NotificationService;
            this.advanceEventsHandlers();
        }
        Object.defineProperty(DmlesAdvancedFileUploadController.prototype, "advanceuploader", {
            //get data(): any { return this._data; }
            //set data(value: any) { this._data = value; }
            get: function () { return this.Uploader; },
            enumerable: true,
            configurable: true
        });
        DmlesAdvancedFileUploadController.prototype.advanceEventsHandlers = function () {
            var _this = this;
            this.advanceuploader.onSuccessItem = function (fileItem, response, status, headers) {
                if (status == 200) {
                    fileItem.remove();
                }
                var attachment = new attachment_model_1.Attachment();
                attachment.description = _this.descriptionInput;
                attachment.section = _this.section;
                attachment.fileRef = response[0];
                _this.onSuccessItem({ response: attachment });
            };
            this.advanceuploader.onCompleteAll = function () {
                _this.showDescriptionInput = false;
                _this.descriptionInput = "";
                _this.onCompleteAll({ success: _this.success });
            };
            this.advanceuploader.onCompleteItem = function (fileItem, response, status, headers) {
                if (status != 200) {
                    _this.success = false;
                }
                //   this.onCompleteItem({fileItem: fileItem, response: response, status: status, headers: status});
            };
        };
        DmlesAdvancedFileUploadController.prototype.updateDescription = function () {
            var _this = this;
            angular.forEach(this.data, function (attachment) {
                if (attachment.fileRef.fileId == _this.fileToEdit.fileRef.fileId) {
                    attachment.description = _this.fileToEdit.description;
                    return;
                }
            });
            this.onCompleteAll({ success: this.success });
            this.editingDescription = false;
            this.fileToEdit = null;
        };
        return DmlesAdvancedFileUploadController;
    }(dmlesFileUpload_controller_1.DmlesFileUploadController));
    exports.DmlesAdvancedFileUploadController = DmlesAdvancedFileUploadController;
});
//# sourceMappingURL=dmlesAdvancedFileUpload.controller.js.map