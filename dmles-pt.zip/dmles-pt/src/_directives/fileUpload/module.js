define(["require", "exports", './dmlesFileUpload.controller', './dmlesFileUpload.directive', './dmlesAdvancedFileUpload.controller', './dmlesAdvancedFileUpload.directive', './embedFileModal.controller', './sectionFilter.filter'], function (require, exports, dmlesFileUpload_controller_1, dmlesFileUpload_directive_1, dmlesAdvancedFileUpload_controller_1, dmlesAdvancedFileUpload_directive_1, embedFileModal_controller_1, sectionFilter_filter_1) {
    "use strict";
    var dmlesFileUploadModule = angular.module('DmlesFileUploadModule', []);
    dmlesFileUploadModule.controller('DmlesFileUploadController', dmlesFileUpload_controller_1.DmlesFileUploadController);
    dmlesFileUploadModule.directive('dmlesFileUpload', dmlesFileUpload_directive_1.DmlesFileUpload.Factory());
    dmlesFileUploadModule.controller('DmlesAdvancedFileUploadController', dmlesAdvancedFileUpload_controller_1.DmlesAdvancedFileUploadController);
    dmlesFileUploadModule.directive('dmlesAdvancedFileUpload', dmlesAdvancedFileUpload_directive_1.DmlesAdvancedFileUpload.Factory());
    dmlesFileUploadModule.controller('EmbedFileModalInstanceController', embedFileModal_controller_1.default);
    dmlesFileUploadModule.filter('sectionFilter', sectionFilter_filter_1.default);
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = dmlesFileUploadModule;
});
//# sourceMappingURL=module.js.map