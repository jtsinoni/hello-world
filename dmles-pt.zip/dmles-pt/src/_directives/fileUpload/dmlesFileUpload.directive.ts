import {DmlesFileUploadController} from "./dmlesFileUpload.controller";

export class DmlesFileUpload implements ng.IDirective {
    public restrict:string = "EA";
    public controller = DmlesFileUploadController;
    public controllerAs: string = 'ctrl';
    public templateUrl:string = "./src/_directives/fileUpload/dmlesFileUpload.template.html";

    public bindToController:any = {
        label: '@',
        description: '=',
        onUploadCompleted: '&',
        onUploadFailed: '&',
        onUploadCancelled: '&'
    };

    public scope: any = {};

    // @ngInject
    constructor(private $log) {}

    public static Factory() {
        const directive = ($log) => new DmlesFileUpload($log);
        directive.$inject = ['$log'];
        return directive;
    }
}