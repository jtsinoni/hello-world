import {DmlesFileUploadController} from "./dmlesFileUpload.controller";


/****Note: This is the simple file upload. This is for uploading a single file.
 * It is takes up a small area on the screen and is perfect for use inside a form
 * If you want the user to be able many files then see the advancedFileUpload directive
 */

/*
 <dmles-file-upload
    data="source.justificationLetter"
    description="Justification Letter"
    section="{{vm.RequestSection.SUGGESTED_SOURCES}}"
    show-description="false"
    is-disabled="vm.isSuggestedSourceFormDisabled()"
    on-success-item="vm.RequestService.onSuccessItem(response)"
    on-complete-all="vm.onCompleteAddingJustification(success)"
    on-remove-file="vm.RequestService.onRemoveFile(file)"
    heading="Justification Letter">
 </dmles-file-upload>

 data: this is an Attachment object. Note is is a single attahcment, not an array
 description:(Optional-default is the heading will be used for this) a description of the file.
 section: (Optional) This is a particular section the attachment is associated with. This would be useful if your object is broken up
        into sections
 show-description:boolean - This is if you want the description shown. If it is shown, then it is editable by the user.
 is-read-only:boolean = (Optional-default is false) is the table read only. Only the data is displayed, nothing can be added or edited to the attachent list
 is-disabled:boolean = (Optional-default is false) Is the button to upload files disabled
 on-success-item:this is the call that returns when an file is uploaded. The function HAS to have an attribute (response:Attachment)
 on-complete-all:this is the call that returns when all files are completed successfully or there was an error.
 The function HAS to have an attribute (success:boolean) This will tell you is it was successful or not "
 on-remove-file: this call returns removes the file from the File Manager and returns it to the function so you can delete
 it out of whatever collect you are saving the attachment to. The function HAS to have an attribute (file:Attachment)
 heading:(Optional) Label on the file upload area, this will be used for the description

 */

export class DmlesFileUpload implements ng.IDirective {
    public restrict:string = "EA";
    public controller = DmlesFileUploadController;
    public controllerAs: string = 'ctrl';
    public templateUrl:string = "./src/_directives/fileUpload/dmlesFileUpload.template.html";

    public bindToController:any = {
        isDisabled: '=',
        heading: '@',
        data: '=',
        description: '@',
        isReadOnly: '=',
        showDescription: '=',
       // onUploadCompleted: '&',
        //onUploadFailed: '&',
        //onUploadCancelled: '&',
       // onCompleteItem: '&',
       // onWhenAddingFileFailed: '&',
        //onAfterAddingAll: '&',
        //onAfterAddingFile: '&',
        onSuccessItem: '&',
        onCompleteAll: '&',
        onRemoveFile: '&',
        section: '@',
    };

    public scope: any = {};

    // @ngInject
    constructor(private $log) {}

    public static Factory() {
        const directive = ($log) => new DmlesFileUpload($log);
        directive.$inject = ['$log'];
        return directive;
    }
}