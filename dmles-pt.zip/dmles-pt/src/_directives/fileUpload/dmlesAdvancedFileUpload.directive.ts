import
{DmlesAdvancedFileUploadController} from "./dmlesAdvancedFileUpload.controller";

export class DmlesAdvancedFileUpload implements ng.IDirective {
    public restrict:string = "EA";
    public controller = DmlesAdvancedFileUploadController;
    public controllerAs: string = 'ctrl';
    public templateUrl:string = "./src/_directives/fileUpload/dmlesAdvancedFileUpload.template.html";
    public transclude: boolean = true;

    public bindToController:any = {
        label: '@',
        description: '=',
        onUploadCompleted: '&',
        onUploadFailed: '&',
        onUploadCancelled: '&',
    };

    public scope: any = {};

    // @ngInject
    constructor(private $log) {}

    public static Factory() {
        const directive = ($log) => new DmlesAdvancedFileUpload($log);
        directive.$inject = ['$log'];
        return directive;
    }
}