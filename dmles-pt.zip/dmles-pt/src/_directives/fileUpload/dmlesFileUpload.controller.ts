'use strict';

import {Attachment} from '../../_models/attachment.model';

export class DmlesFileUploadController {

    protected controllerName: string = "DmlesFileUploadController Directive";
    private _section: string;
    private _maxPostSize: number = 102123;
    private _Uploader: any;

    private _permittedFileExtensions: Array<string>;
  //  private _onWhenAddingFileFailed: (any) => void;
  //  private _onAfterAddingFile: (any) => void;
  //  private _onAfterAddingAll: (any) => void;
 //   private _onCompleteItem: (any) => void;
    private _onSuccessItem: (any) => void;
    private _onCompleteAll: (boolean) => void;
 //   private _onUploadCompleted: (any) => void;
//    private _onUploadCancelled: (any) => void;
//    private _onUploadFailed: (any) => void;

    public onRemoveFile: (any) => void;

    private _data:(any) => void;
    public description: string;
    public descriptionInput:string;
    public editingDescription:boolean = false;
    public fileToBeDeleted:Attachment;
    public fileToEdit:Attachment;
    public heading:string;
    public showDescription;
    public showDescriptionInput:boolean = false;
    public success:boolean = true;

    public isModalRemoveFileOpen: boolean = false;
    public modalRemoveFileTitle: string = "Remove File";
    public modalOkText: string = "Confirm";
    public modalOkIcon: string = "fa fa-thumbs-up";
    public modalCancelIcon: string = "fa fa-close";

    get data(): any { return this._data; }
    set data(value: any) { this._data = value; }

    //get onUploadFailed(): (any) => void { return this._onUploadFailed; }
    //set onUploadFailed(value: (any) => void) { this._onUploadFailed = value; }
    //
    //get onUploadCancelled(): (any) => void { return this._onUploadCancelled; }
    //set onUploadCancelled(value: (any) => void) { this._onUploadCancelled = value; }
    //
    //get onUploadCompleted(): (any) => void { return this._onUploadCompleted;  }
    //set onUploadCompleted(value: (any) => void) { this._onUploadCompleted = value; }

    get onCompleteAll(): (boolean) => void { return this._onCompleteAll; }
    set onCompleteAll(value: (boolean) => void) { this._onCompleteAll = value;  }

    get onSuccessItem(): (any) => void { return this._onSuccessItem;  }
    set onSuccessItem(value: (any) => void) { this._onSuccessItem = value; }

    //get onCompleteItem(): (any) => void { return this._onCompleteItem; }
    //set onCompleteItem(value: (any) => void) { this._onCompleteItem = value; }
    //
    //get onAfterAddingAll(): (any) => void { return this._onAfterAddingAll;  }
    //set onAfterAddingAll(value: (any) => void) { this._onAfterAddingAll = value; }

    //get onAfterAddingFile(): (any) => void { return this._onAfterAddingFile;  }
    //set onAfterAddingFile(value: (any) => void) { this._onAfterAddingFile = value;  }
    //
    //get onWhenAddingFileFailed(): (any) => void { return this._onWhenAddingFileFailed;  }
    //set onWhenAddingFileFailed(value: (any) => void) { this._onWhenAddingFileFailed = value;  }

    get Uploader(): any { return this._Uploader; }

    get fileuploader(): any { return this._Uploader; }

    get section(): string { return this._section;  }
    set section(value: string) { this._section = value; }

    get maxPostSize(): number { return this._maxPostSize; }

    get pemittedFileExtensions(): Array<string> { return this._permittedFileExtensions; }


    constructor(public $scope, protected $log, protected $sce, protected $uibModal, protected FileManagerService, protected FileSaver, protected FileUploader: any, protected NotificationService) {
        this.$log.debug('%s - Start ->', this.controllerName);

        this.init(FileUploader);
        this.EventsHandlers();

    }


    private init(FileUploader: any): void {

        let mainThis = this;

        this._Uploader = new FileUploader(
            this.FileManagerService.getUploadConfiguration()
        );

        this.FileManagerService.getMaxPostSize()
            .then((returnedVal) => {
                this._maxPostSize = returnedVal.data;
            }, reason => {
                this.$log.debug('%s - Error retrieving Max Post Size: ', reason);
            });

        this.FileManagerService.getPermittedFileExtensions()
            .then((returnedVal) => {
                this._permittedFileExtensions = returnedVal.data;
            }, reason => {
                this.$log.debug('%s - Error retrieving permitted File Extensions: ', reason);
            });

        this.Uploader.filters.push({
                name: 'enforceNoDuplicates',
                fn: item => {
                    let returnValue: boolean = true;
                    mainThis.fileuploader.queue.forEach(currrent => {
                        if (currrent.file.name === item.name && currrent.file.size === item.size) {
                            returnValue = false;
                        }
                    });
                    return returnValue;
                }
            }
        );


        this.Uploader.filters.push({
            name: 'enforceMaxFileSize',
            fn: item => item.size <= mainThis.maxPostSize
        });

        this.Uploader.filters.push({
                name: 'enforcePermittedFileExtensions',
                fn: item => {
                    let returnValue: boolean = true;
                    let name: string = item.name;
                    for (let index in mainThis.pemittedFileExtensions) {
                        if (name.toUpperCase().indexOf(mainThis.pemittedFileExtensions[index]) > 0) {
                            returnValue = false;
                            break;
                        }
                    }
                    return returnValue;
                }
            }
        );

    }

    private EventsHandlers(): void {

        this.Uploader.onWhenAddingFileFailed = (item: any, filter: any, options: any) => {

            this.$log.debug('%s - onWhenAddingFileFailed: ', this.controllerName, item);

            if (filter != undefined) {
                switch (filter.name) {
                    case 'enforceMaxFileSize':
                        let sizes: string[] = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
                        let index: number = Math.floor(Math.log(this.maxPostSize) / Math.log(1000));
                        let number: number = parseFloat((this.maxPostSize / Math.pow(1000, index)).toFixed(2));
                        let size: any = number + ' ' + sizes[index];
                        this.NotificationService.errorMsg(item.name + " exceeds the maximum file upload size of " + size);
                        break;
                    case 'enforcePermittedFileExtensions':
                        this.NotificationService.errorMsg('The file (' + item.name + ") is an invalid upload type");
                        break;
                    case 'enforceNoDuplicates':
                        this.NotificationService.errorMsg('The file (' + item.name + ") already within upload list");
                        break;
                }

                this.$log.debug('%s - onWhenAddingFileFailed: ', this.controllerName, filter);
            }

         //   this.onWhenAddingFileFailed({item: item, filter: filter, options: options});
        }


        //this.Uploader.onAfterAddingFile = (fileItem: any) => {
        //    this.$log.debug('%s - onAfterAddingFile: ', this.controllerName, fileItem);
        //
        // //   this.onAfterAddingFile({fileItem: fileItem});
        //};


        this.Uploader._onAfterAddingAll = (addedFileItems: any) => {
            if(this.showDescription || this.showDescription == null) {
                this.showDescriptionInput = true;
                this.descriptionInput = this.description;
            }
            else{
                this.descriptionInput = this.heading;
                this.uploadFiles();
            }
        //    this.onAfterAddingAll({addedFileItems: addedFileItems});
        };

        this.Uploader.onBeforeUploadItem = (item: any) => {
            this.success = true;
        };

        //this.Uploader.onProgressItem = (fileItem: any, progress: any) => {
        //    console.info('onProgressItem', fileItem, progress);
        //};
        //
        //this.Uploader.onProgressAll = (progress: any) => {
        //    this.$log.debug('%s - DmlesAdvancedFileUploadController: onProgressAll', this.controllerName);
        //};

        this.Uploader.onSuccessItem = (fileItem: any, response: any, status: any, headers: any) => {

            if(status == 200){
                fileItem.remove();
            }
            let attachment:Attachment = new Attachment();
            attachment.description = this.descriptionInput;
            attachment.section = this.section;
            attachment.fileRef = response[0];
            this.data = attachment;
            this.onSuccessItem({response: attachment});
        };

        this.Uploader.onErrorItem = (fileItem: any, response: any, status: any, headers: any) => {
            this.NotificationService.errorMsg("There was an error uploading the file(s)");
        };

        //this.Uploader.onCancelItem = (fileItem: any, response: any, status: any, headers: any) => {
        //    fileItem.remove();
        //};

        this.Uploader.onCompleteItem = (fileItem: any, response: any, status: number, headers: any) => {

            this.showDescriptionInput = false;
            this.descriptionInput = this.description;
            if(status != 200){
                this.success = false;
            }

         //   this.onCompleteItem({fileItem: fileItem, response: response, status: status, headers: status});
        };

        this.Uploader.onCompleteAll = () => {

            this.onCompleteAll({success: this.success});
        };

    }

    public cancelEditDescription(){
        this.editingDescription = false;
        this.fileToEdit = null;
    }

    public editDescription(file){
        this.editingDescription = true;
        this.fileToEdit = angular.copy(file);
    }

    public embedFileToPage(fileId, fileName){
        this.FileManagerService.download(fileId)
            .success((data, status, headers, config) => {
                let file = new Blob([data], {type: 'Aplication/pdf'});
                let fileURL = URL.createObjectURL(file);
                this.FileManagerService.embedContentToDisplayFileName = fileName;
                this.FileManagerService.embedContentToDisplay = this.$sce.trustAsResourceUrl(fileURL);
                var modalInstance = this.$uibModal.open({
                    animation: true,
                    ariaLabelledBy: 'modal-title',
                    ariaDescribedBy: 'modal-body',
                    backdrop: 'static',
                    size: 'lg',
                    templateUrl: "/src/_directives/fileUpload/embedFileModal.html",
                    controllerAs: 'vm',
                    controller: 'EmbedFileModalInstanceController'
                });
            }).error((data, status, headers, config) => {
            this.$log.debug('%s - Error retrieving Max Post Size: ', headers);
        });
    }

    public isFileImage(fileName){
        if(fileName.indexOf(".jpg") != -1 ||
            fileName.indexOf(".jpeg") != -1 ||
            fileName.indexOf(".jpe") != -1 ||
            fileName.indexOf(".png") != -1 ||
            fileName.indexOf(".bmp") != -1 ||
            fileName.indexOf(".gif") != -1){
                return true;
            }
        else{
            return false;
        }
    }

    public openFile(fileid) {
        this.$log.debug('%s - onCompleteAll: ', this.controllerName);
        this.FileManagerService.download(fileid)
            .success((data, status, headers, config) => {
                let filename: any = "downloadFile";
                let header: any = headers('content-disposition');
                if (header && header.indexOf('attachment') !== -1) {
                    let regex = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/;
                    let matches = regex.exec(header);
                    if (matches != null && matches[1]) {
                        filename = matches[1].replace(/['"]/g, '');
                    }
                }

                let file = new Blob([data], {type: 'Aplication/pdf'});
                this.FileSaver.saveAs(file, filename);
            }).error((data, status, headers, config) => {
            this.$log.debug('%s - Error retrieving Max Post Size: ', headers);
        });

    }

    public openRemoveFile(file){
        this.fileToBeDeleted = angular.copy(file);
        this.isModalRemoveFileOpen = true;
    }

    public removeFile(){
        var removeFile = this.FileManagerService.removeFile(this.fileToBeDeleted.fileRef.fileId);
        return removeFile.then(result => {
            if(result.status == 200) {
                this.$log.debug(result);
                return this.onRemoveFile({file: this.fileToBeDeleted});
            }
            else{
                this.NotificationService.errorMsg("There was an error removing the file. Please contact your system administrator.");
            }
        });
    }

    public saveFile(data,headers){
        let filename: any = "downloadFile";
        let header: any = headers('content-disposition');
        if (header && header.indexOf('attachment') !== -1) {
            let regex = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/;
            let matches = regex.exec(header);
            if (matches != null && matches[1]) {
                filename = matches[1].replace(/['"]/g, '');
            }
        }

        let file = new Blob([data], {type: 'Aplication/pdf'});
        this.FileSaver.saveAs(file, filename);
    }

    public uploadFiles(){
        angular.forEach(this.Uploader.queue, (file) => {
            file.upload();
        });
    }

    public updateDescription(){
        this.data.description = this.fileToEdit.description
        this.onCompleteAll({success: this.success});
        this.editingDescription = false;
        this.fileToEdit = null;
    }
}