'use strict';

import {Attachment} from '../../_models/attachment.model';
import {DmlesFileUploadController} from "./dmlesFileUpload.controller";


export class DmlesAdvancedFileUploadController extends DmlesFileUploadController {

    public data:Array<any>;
    public filterBySection:boolean;
    //get data(): any { return this._data; }
    //set data(value: any) { this._data = value; }

    get advanceuploader(): any { return this.Uploader;  }

    constructor(public $scope, protected $log, protected $sce, protected $uibModal, protected FileManagerService,  protected FileSaver, protected FileUploader, protected NotificationService) {
        super($scope, $log, $sce, $uibModal, FileManagerService, FileSaver, FileUploader, NotificationService);
        this.advanceEventsHandlers();
    }
    private advanceEventsHandlers(): void {
        this.advanceuploader.onSuccessItem = (fileItem:any, response:any, status:any, headers:any) => {
            if (status == 200) {
                fileItem.remove();
            }
            let attachment:Attachment = new Attachment();
            attachment.description = this.descriptionInput;
            attachment.section = this.section;
            attachment.fileRef = response[0];
            this.onSuccessItem({response: attachment});
        };

        this.advanceuploader.onCompleteAll = () => {
            this.showDescriptionInput = false;
            this.descriptionInput = "";

            this.onCompleteAll({success: this.success});
        };

        this.advanceuploader.onCompleteItem = (fileItem: any, response: any, status: number, headers: any) => {

            if(status != 200){
                this.success = false;
            }

            //   this.onCompleteItem({fileItem: fileItem, response: response, status: status, headers: status});
        };
    }

    public updateDescription(){
        angular.forEach(this.data, (attachment:Attachment) => {
            if (attachment.fileRef.fileId == this.fileToEdit.fileRef.fileId) {
                attachment.description = this.fileToEdit.description;
                return;
            }
        });
        this.onCompleteAll({success: this.success});
        this.editingDescription = false;
        this.fileToEdit = null;
    }
}