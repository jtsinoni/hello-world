'use strict';

import {ApiConstants} from '../../_constants/api.constants';
import {ConfigConstants} from '../../_constants/config.constants';




export class DmlesAdvancedFileUploadController {
    private controllerName:string = "DmlesAdvancedFileUploadController Directive";
    private _description:string;
    public onUploadCompleted: (any) => void;
    public onUploadCancelled: (any) => void;
    public onUploadFailed: (any) => void;

    private uploader:any;

    get advanceuploader():any {
        return this.uploader;
    }

    get description():string {
        return this._description;
    }

    set description(theDescription:string){
        this._description = theDescription;
    }



    constructor(public $scope, private $log, private FileManagerService, private FileUploader) {
        this.$log.debug('%s - Start:', this.controllerName);

        let _this = this;

        
        this.uploader = new FileUploader(
           this.FileManagerService.getUploadConfiguration()
        );

        this.uploader.onWhenAddingFileFailed = function(item /*{File|FileLikeObject}*/, filter, options) {
            console.info('onWhenAddingFileFailed', item, filter, options);
        };
        this.uploader.onAfterAddingFile = function(fileItem) {
            console.info('onAfterAddingFile', fileItem);
        };
        this.uploader.onAfterAddingAll = function(addedFileItems) {
            console.info('onAfterAddingAll', addedFileItems);
        };


        this.uploader.onBeforeUploadItem = function(item) {

            var formData = [
                { description: _this.description}
            ]
            Array.prototype.push.apply(item.formData, formData );
            _this.$log.debug('%s - onBeforeUploadItem: ', _this.controllerName, item.formData);
        };


        this.uploader.onProgressItem = function(fileItem, progress) {
            console.info('onProgressItem', fileItem, progress);
        };
        this.uploader.onProgressAll = function(progress) {
            console.info('onProgressAll', progress);
        };
        this.uploader.onSuccessItem = function(fileItem, response, status, headers) {
            console.info('onSuccessItem', fileItem, response, status, headers);
        };
        this.uploader.onErrorItem = function(fileItem, response, status, headers) {
            console.info('onErrorItem', fileItem, response, status, headers);
            _this.onUploadFailed({ failedFileInfo: response });
        };
        this.uploader.onCancelItem = function(fileItem, response, status, headers) {
            console.info('onCancelItem', fileItem, response, status, headers);
            _this.onUploadCancelled({ cancelledFileInfo: response });
        };
        this.uploader.onCompleteItem = function(fileItem, response, status, headers) {
            console.info('onCompleteItem', fileItem, response, status, headers);
            _this.onUploadCompleted({ uploadedFileInfo: response });
        };
        this.uploader.onCompleteAll = function() {
            console.info('onCompleteAll');
        };


    }
}