import {DmlesFileUploadController} from './dmlesFileUpload.controller';
import {DmlesFileUpload} from './dmlesFileUpload.directive';
import {DmlesAdvancedFileUploadController} from './dmlesAdvancedFileUpload.controller';
import {DmlesAdvancedFileUpload} from './dmlesAdvancedFileUpload.directive';
import EmbedFileModalInstanceController from './embedFileModal.controller';
import SectionFilter from './sectionFilter.filter';



var dmlesFileUploadModule = angular.module('DmlesFileUploadModule', []);
dmlesFileUploadModule.controller('DmlesFileUploadController', DmlesFileUploadController);
dmlesFileUploadModule.directive('dmlesFileUpload', DmlesFileUpload.Factory());

dmlesFileUploadModule.controller('DmlesAdvancedFileUploadController', DmlesAdvancedFileUploadController);
dmlesFileUploadModule.directive('dmlesAdvancedFileUpload', DmlesAdvancedFileUpload.Factory());

dmlesFileUploadModule.controller('EmbedFileModalInstanceController', EmbedFileModalInstanceController);

dmlesFileUploadModule.filter('sectionFilter', SectionFilter);


export default dmlesFileUploadModule;
