import {DmlesFileUploadController} from './dmlesFileUpload.controller';
import {DmlesFileUpload} from './dmlesFileUpload.directive';
import {DmlesAdvancedFileUploadController} from './dmlesAdvancedFileUpload.controller';
import {DmlesAdvancedFileUpload} from './dmlesAdvancedFileUpload.directive';


var dmlesFileUploadModule = angular.module('DmlesFileUploadModule', []);
dmlesFileUploadModule.controller('DmlesFileUploadController', DmlesFileUploadController);
dmlesFileUploadModule.directive('dmlesFileUpload', DmlesFileUpload.Factory());

dmlesFileUploadModule.controller('DmlesAdvancedFileUploadController', DmlesAdvancedFileUploadController);
dmlesFileUploadModule.directive('dmlesAdvancedFileUpload', DmlesAdvancedFileUpload.Factory());

export default dmlesFileUploadModule;
