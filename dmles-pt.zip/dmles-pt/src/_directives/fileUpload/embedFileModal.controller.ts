'use strict';

export default class EmbedFileModalInstanceController{

    // @ngInject
    constructor(private $log, private $uibModalInstance, private FileManagerService) {

    }

    public close(){
        this.FileManagerService.embedContentToDisplay = null;
        this.$uibModalInstance.dismiss('cancel');
    }
}