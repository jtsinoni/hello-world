export class DmlesTextareaFieldController {
    private controllerName: string = "DmlesTextareaFieldController Directive";

    // attributes from Directive
    public tafId: string;
    public tafLabel: string;
    public tafRows: any;
    public tafModel: any;
    public tafReadonly: string;

    //@inject
    constructor(public $scope, private $log, private $q, private $timeout) {
    }

    public init() {
    }
}