import {DmlesTextareaFieldController} from "./dmlesTextareaField.controller";

//
// Usage:
// <dmles-textarea-field 
//      taf-id="ndc"
//      taf-label="National Drug Code"
//      taf-rows="4"
//      taf-model="vm.record.ndc"
//      taf-readonly="false"
// </dmles-textarea-field>
//

export class DmlesTextareaField implements ng.IDirective {
    public restrict:string = "EA";
    public transclude:boolean = true;
    public controller = DmlesTextareaFieldController;
    public controllerAs:string = 'vm';
    public templateUrl:string = "./src/_directives/fields/dmlesTextareaField/dmlesTextareaField.template.html";
    //public replace:boolean = true;

    public bindToController:any = {
        tafId: '@',
        tafLabel: '@',
        tafRows: '@',
        tafModel: '=',
        tafReadonly: '@'
    };

    public scope:any = {};

    // @ngInject
    constructor(private $log) {}

    public static Factory() {
        const directive = ($log) => new DmlesTextareaField($log);
        directive.$inject = ['$log'];
        return directive;
    }
}