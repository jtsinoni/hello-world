define(["require", "exports", "./dmlesTextareaField.controller"], function (require, exports, dmlesTextareaField_controller_1) {
    "use strict";
    //
    // Usage:
    // <dmles-textarea-field 
    //      taf-id="ndc"
    //      taf-label="National Drug Code"
    //      taf-rows="4"
    //      taf-model="vm.record.ndc"
    //      taf-readonly="false"
    // </dmles-textarea-field>
    //
    var DmlesTextareaField = (function () {
        // @ngInject
        function DmlesTextareaField($log) {
            this.$log = $log;
            this.restrict = "EA";
            this.transclude = true;
            this.controller = dmlesTextareaField_controller_1.DmlesTextareaFieldController;
            this.controllerAs = 'vm';
            this.templateUrl = "./src/_directives/fields/dmlesTextareaField/dmlesTextareaField.template.html";
            //public replace:boolean = true;
            this.bindToController = {
                tafId: '@',
                tafLabel: '@',
                tafRows: '@',
                tafModel: '=',
                tafReadonly: '@'
            };
            this.scope = {};
        }
        DmlesTextareaField.Factory = function () {
            var directive = function ($log) { return new DmlesTextareaField($log); };
            directive.$inject = ['$log'];
            return directive;
        };
        return DmlesTextareaField;
    }());
    exports.DmlesTextareaField = DmlesTextareaField;
});
//# sourceMappingURL=dmlesTextareaField.directive.js.map