define(["require", "exports"], function (require, exports) {
    "use strict";
    var DmlesTextareaFieldController = (function () {
        //@inject
        function DmlesTextareaFieldController($scope, $log, $q, $timeout) {
            this.$scope = $scope;
            this.$log = $log;
            this.$q = $q;
            this.$timeout = $timeout;
            this.controllerName = "DmlesTextareaFieldController Directive";
        }
        DmlesTextareaFieldController.prototype.init = function () {
        };
        return DmlesTextareaFieldController;
    }());
    exports.DmlesTextareaFieldController = DmlesTextareaFieldController;
});
//# sourceMappingURL=dmlesTextareaField.controller.js.map