export class DmlesFileUploadListFieldController {
    private controllerName: string = "DmlesFileUploadListFieldController Directive";

    // attributes from Directive
    public fulId: string;
    public fulDescription: string;
    public fulLabel: string;
    public fulModel: Array<string>;

    // These are the member variables

    public contentType: string;

    public fileUploadListSummary: string = "0 items.";
    public showPanel: boolean = false;
    public topRowMode: string = "";
    public valueToDelete: string = "need to fill this in";
    public selectedListItem: any = "";
    public workingList: Array < any > = [];

    public downloadFileInfo: any = null;

    //@inject
    constructor(public $scope, private $log, private $q, private $timeout, private ApiConstants, private AppConfig, private FileManagerService, private $document) {
    }

    public init() {
        this.createWorkingList();
        this.updatefileUploadListSummary();
    }

    public onClick() {
        this.showPanel = !this.showPanel;
    }

    public onAddButtonClicked() {
        this.topRowMode = "add";
    }

    public onDeleteButtonClicked() {
        this.valueToDelete = this.workingList[this.selectedListItem].value;
        this.topRowMode = "delete";
    }

    public onDeleteYesButtonClicked() {
        this.topRowMode = "";
        this.workingList.splice(this.selectedListItem, 1);
        this.refreshModel();
    }

    public onDeleteNoButtonClicked() {
        this.topRowMode = "";
    }

    private updatefileUploadListSummary() {
        this.fileUploadListSummary = this.fulModel.length + " items.";
    }

    private createWorkingList() {
        this.workingList = [];
        for (var i = 0; i < this.fulModel.length; i++) {
            this.workingList.push({
                'index': i,
                'value': this.fulModel[i]
            });
        }
    }

    private refreshModel() {
        this.fulModel = [];
        for (var i = 0; i < this.workingList.length; i++) {
            this.workingList[i].index = i;
            this.fulModel.push(this.workingList[i].value);
        }
        this.updatefileUploadListSummary();
        // this.$scope.$apply();
    }

    public getRawDataForSelectedItem() : void {
        var index = this.selectedListItem;
        var url = this.workingList[index].value;

        var fileId = this.getFileIdFromUrl(url);
        this.FileManagerService.getManagedFileInfo(fileId).then((fileInfoResponse) => {
            var uploadDate = fileInfoResponse.data.uploadDateTime;
            var formattedDate = uploadDate.monthValue + "/" + uploadDate.dayOfMonth + "/" + uploadDate.year;
            this.downloadFileInfo = {
                fileName: fileInfoResponse.data.fileName,
                description: fileInfoResponse.data.description,
                uploadDate: formattedDate,
                fileSize: fileInfoResponse.data.fileSize,
                uploadedBy: fileInfoResponse.data.uploadedBy
            };

            this.FileManagerService.base64download(fileId).then((downloadResponse) => {
                var doc = this.$document[0];
                var elmt = doc.getElementById("selectedImagePreview");
                var responseHeaders = downloadResponse.headers();
                this.contentType = responseHeaders["content-type"];
                var data = downloadResponse.data;
                elmt.src = "data:" + this.contentType + ";base64," + data;
            });
        });
    }

    public onUploadCompleted(response: any): void {
        this.$log.debug("onUploadCompleted: response is " + JSON.stringify(response, null, 3));
        var newItem = {
            'index': this.workingList.length + 1,
            'value': this.AppConfig.BT_BASE_URL + this.ApiConstants.FILE_MANAGER_API + 'download?fileId=' +
                     response.fileRef.fileId,
        };
        this.workingList.push(newItem);
        this.refreshModel();
    }

    public onCompleteAll(success: boolean): void {
    }

    public onRemoveFile(file: any): void {
    }

    public getFileIdFromUrl(url: string): string {
        var fileId = "";
        var fileIdPos = url.lastIndexOf("fileId=");
        if (fileIdPos >= 0) {
            fileId = url.substring(fileIdPos + 7);
        }
        return fileId;
    }
}