define(["require", "exports"], function (require, exports) {
    "use strict";
    var DmlesFileUploadListFieldController = (function () {
        //@inject
        function DmlesFileUploadListFieldController($scope, $log, $q, $timeout, ApiConstants, ConfigConstants, FileManagerService, $document) {
            this.$scope = $scope;
            this.$log = $log;
            this.$q = $q;
            this.$timeout = $timeout;
            this.ApiConstants = ApiConstants;
            this.ConfigConstants = ConfigConstants;
            this.FileManagerService = FileManagerService;
            this.$document = $document;
            this.controllerName = "DmlesFileUploadListFieldController Directive";
            this.fileUploadListSummary = "0 items.";
            this.showPanel = false;
            this.topRowMode = "";
            this.valueToDelete = "need to fill this in";
            this.selectedListItem = "";
            this.workingList = [];
            this.downloadFileInfo = null;
        }
        DmlesFileUploadListFieldController.prototype.init = function () {
            this.createWorkingList();
            this.updatefileUploadListSummary();
        };
        DmlesFileUploadListFieldController.prototype.onClick = function () {
            this.showPanel = !this.showPanel;
        };
        DmlesFileUploadListFieldController.prototype.onAddButtonClicked = function () {
            this.topRowMode = "add";
        };
        DmlesFileUploadListFieldController.prototype.onDeleteButtonClicked = function () {
            this.valueToDelete = this.workingList[this.selectedListItem].value;
            this.topRowMode = "delete";
        };
        DmlesFileUploadListFieldController.prototype.onDeleteYesButtonClicked = function () {
            this.topRowMode = "";
            this.workingList.splice(this.selectedListItem, 1);
            this.refreshModel();
        };
        DmlesFileUploadListFieldController.prototype.onDeleteNoButtonClicked = function () {
            this.topRowMode = "";
        };
        DmlesFileUploadListFieldController.prototype.updatefileUploadListSummary = function () {
            this.fileUploadListSummary = this.fulModel.length + " items.";
        };
        DmlesFileUploadListFieldController.prototype.createWorkingList = function () {
            this.workingList = [];
            for (var i = 0; i < this.fulModel.length; i++) {
                this.workingList.push({
                    'index': i,
                    'value': this.fulModel[i]
                });
            }
        };
        DmlesFileUploadListFieldController.prototype.refreshModel = function () {
            this.fulModel = [];
            for (var i = 0; i < this.workingList.length; i++) {
                this.workingList[i].index = i;
                this.fulModel.push(this.workingList[i].value);
            }
            this.updatefileUploadListSummary();
            // this.$scope.$apply();
        };
        DmlesFileUploadListFieldController.prototype.getRawDataForSelectedItem = function () {
            var _this = this;
            var index = this.selectedListItem;
            var url = this.workingList[index].value;
            var fileId = this.getFileIdFromUrl(url);
            this.FileManagerService.getManagedFileInfo(fileId).then(function (fileInfoResponse) {
                var uploadDate = fileInfoResponse.data.uploadDateTime;
                var formattedDate = uploadDate.monthValue + "/" + uploadDate.dayOfMonth + "/" + uploadDate.year;
                _this.downloadFileInfo = {
                    fileName: fileInfoResponse.data.fileName,
                    description: fileInfoResponse.data.description,
                    uploadDate: formattedDate,
                    fileSize: fileInfoResponse.data.fileSize,
                    uploadedBy: fileInfoResponse.data.uploadedBy
                };
                _this.FileManagerService.base64download(fileId).then(function (downloadResponse) {
                    var doc = _this.$document[0];
                    var elmt = doc.getElementById("selectedImagePreview");
                    var responseHeaders = downloadResponse.headers();
                    _this.contentType = responseHeaders["content-type"];
                    var data = downloadResponse.data;
                    elmt.src = "data:" + _this.contentType + ";base64," + data;
                });
            });
        };
        DmlesFileUploadListFieldController.prototype.onUploadCompleted = function (uploadedFileInfo) {
            var newItem = {
                'index': this.workingList.length + 1,
                'value': this.ConfigConstants.BT_BASE_URL + this.ApiConstants.FILE_MANAGER_API + 'download?fileId=' +
                    uploadedFileInfo[0].fileId,
            };
            this.workingList.push(newItem);
            this.refreshModel();
        };
        DmlesFileUploadListFieldController.prototype.onUploadCancelled = function (cancelledFileInfo) {
        };
        DmlesFileUploadListFieldController.prototype.onUploadFailed = function (failedFileInfo) {
        };
        DmlesFileUploadListFieldController.prototype.getFileIdFromUrl = function (url) {
            var fileId = "";
            var fileIdPos = url.lastIndexOf("fileId=");
            if (fileIdPos >= 0) {
                fileId = url.substring(fileIdPos + 7);
            }
            return fileId;
        };
        return DmlesFileUploadListFieldController;
    }());
    exports.DmlesFileUploadListFieldController = DmlesFileUploadListFieldController;
});
//# sourceMappingURL=dmlesFileUploadListField.controller.js.map