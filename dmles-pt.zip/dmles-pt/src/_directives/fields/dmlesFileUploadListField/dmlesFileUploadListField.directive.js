define(["require", "exports", "./dmlesFileUploadListField.controller"], function (require, exports, dmlesFileUploadListField_controller_1) {
    "use strict";
    var DmlesFileUploadListField = (function () {
        // @ngInject
        function DmlesFileUploadListField($log) {
            this.$log = $log;
            this.restrict = "EA";
            this.transclude = true;
            this.controller = dmlesFileUploadListField_controller_1.DmlesFileUploadListFieldController;
            this.controllerAs = 'vm';
            this.templateUrl = "./src/_directives/fields/dmlesFileUploadListField/dmlesFileUploadListField.template.html";
            //public replace:boolean = true;
            this.bindToController = {
                fulId: '@',
                fulDescription: '=',
                fulLabel: '@',
                fulModel: '=',
            };
            this.scope = {};
        }
        DmlesFileUploadListField.Factory = function () {
            var directive = function ($log) { return new DmlesFileUploadListField($log); };
            directive.$inject = ['$log'];
            return directive;
        };
        return DmlesFileUploadListField;
    }());
    exports.DmlesFileUploadListField = DmlesFileUploadListField;
});
//# sourceMappingURL=dmlesFileUploadListField.directive.js.map