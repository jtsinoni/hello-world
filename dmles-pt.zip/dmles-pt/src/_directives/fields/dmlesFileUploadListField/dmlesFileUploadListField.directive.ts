import {DmlesFileUploadListFieldController} from "./dmlesFileUploadListField.controller";

export class DmlesFileUploadListField implements ng.IDirective {
    public restrict:string = "EA";
    public transclude:boolean = true;
    public controller = DmlesFileUploadListFieldController;
    public controllerAs:string = 'vm';
    public templateUrl:string = "./src/_directives/fields/dmlesFileUploadListField/dmlesFileUploadListField.template.html";
    //public replace:boolean = true;

    public bindToController:any = {
        fulId: '@',
        fulLabel: '@',
        fulModel: '=',
    };

    public scope:any = {};

    // @ngInject
    constructor(private $log) {}

    public static Factory() {
        const directive = ($log) => new DmlesFileUploadListField($log);
        directive.$inject = ['$log'];
        return directive;
    }
}