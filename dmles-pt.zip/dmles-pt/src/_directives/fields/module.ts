import {DmlesCheckboxFieldController} from './dmlesCheckboxField/dmlesCheckboxField.controller';
import {DmlesCheckboxField} from './dmlesCheckboxField/dmlesCheckboxField.directive';

import {DmlesDateFieldController} from './dmlesDateField/dmlesDateField.controller';
import {DmlesDateField} from './dmlesDateField/dmlesDateField.directive';

import {DmlesDropDownListFieldController} from './dmlesDropDownListField/dmlesDropDownListField.controller';
import {DmlesDropDownListField} from './dmlesDropDownListField/dmlesDropDownListField.directive';

import {DmlesFileUploadListFieldController} from './dmlesFileUploadListField/dmlesFileUploadListField.controller';
import {DmlesFileUploadListField} from './dmlesFileUploadListField/dmlesFileUploadListField.directive';

import {DmlesNumberFieldController} from './dmlesNumberField/dmlesNumberField.controller';
import {DmlesNumberField} from './dmlesNumberField/dmlesNumberField.directive';

import {DmlesReadOnlyTextFieldController} from './dmlesReadOnlyTextField/dmlesReadOnlyTextField.controller';
import {DmlesReadOnlyTextField} from './dmlesReadOnlyTextField/dmlesReadOnlyTextField.directive';

import {DmlesStringFieldController} from './dmlesStringField/dmlesStringField.controller';
import {DmlesStringField} from './dmlesStringField/dmlesStringField.directive';

import {DmlesStringListFieldController} from './dmlesStringListField/dmlesStringListField.controller';
import {DmlesStringListField} from './dmlesStringListField/dmlesStringListField.directive';

import {DmlesStringListMoverFieldController} from './dmlesStringListMoverField/dmlesStringListMoverField.controller';
import {DmlesStringListMoverField} from './dmlesStringListMoverField/dmlesStringListMoverField.directive';

import {DmlesTextareaFieldController} from './dmlesTextareaField/dmlesTextareaField.controller';
import {DmlesTextareaField} from './dmlesTextareaField/dmlesTextareaField.directive';

import {DmlesTypeaheadFieldController} from './dmlesTypeaheadField/dmlesTypeaheadField.controller';
import {DmlesTypeaheadField} from './dmlesTypeaheadField/dmlesTypeaheadField.directive';

var directivesFieldsModule = angular.module('DirectivesFieldsModule', []);

directivesFieldsModule.controller('DmlesCheckboxFieldController', DmlesCheckboxFieldController);
directivesFieldsModule.directive('dmlesCheckboxField', DmlesCheckboxField.Factory());

directivesFieldsModule.controller('DmlesDateFieldController', DmlesDateFieldController);
directivesFieldsModule.directive('dmlesDateField', DmlesDateField.Factory());

directivesFieldsModule.controller('DmlesDropDownListFieldController', DmlesDropDownListFieldController);
directivesFieldsModule.directive('dmlesDropDownListField', DmlesDropDownListField.Factory());

directivesFieldsModule.controller('DmlesFileUploadListFieldController', DmlesFileUploadListFieldController);
directivesFieldsModule.directive('dmlesFileUploadListField', DmlesFileUploadListField.Factory());

directivesFieldsModule.controller('DmlesNumberFieldController', DmlesNumberFieldController);
directivesFieldsModule.directive('dmlesNumberField', DmlesNumberField.Factory());

directivesFieldsModule.controller('DmlesReadOnlyTextFieldController', DmlesReadOnlyTextFieldController);
directivesFieldsModule.directive('dmlesReadOnlyTextField', DmlesReadOnlyTextField.Factory());

directivesFieldsModule.controller('DmlesStringFieldController', DmlesStringFieldController);
directivesFieldsModule.directive('dmlesStringField', DmlesStringField.Factory());

directivesFieldsModule.controller('DmlesStringListFieldController', DmlesStringListFieldController);
directivesFieldsModule.directive('dmlesStringListField', DmlesStringListField.Factory());

directivesFieldsModule.controller('DmlesStringListMoverFieldController', DmlesStringListMoverFieldController);
directivesFieldsModule.directive('dmlesStringListMoverField', DmlesStringListMoverField.Factory());

directivesFieldsModule.controller('DmlesTextareaFieldController', DmlesTextareaFieldController);
directivesFieldsModule.directive('dmlesTextareaField', DmlesTextareaField.Factory());

directivesFieldsModule.controller('DmlesTypeaheadFieldController', DmlesTypeaheadFieldController);
directivesFieldsModule.directive('dmlesTypeaheadField', DmlesTypeaheadField.Factory());

export default directivesFieldsModule;