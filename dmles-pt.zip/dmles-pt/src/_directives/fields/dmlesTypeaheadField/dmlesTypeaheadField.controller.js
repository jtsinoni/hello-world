define(["require", "exports"], function (require, exports) {
    "use strict";
    var DmlesTypeaheadFieldController = (function () {
        //@inject
        function DmlesTypeaheadFieldController($scope, $log, $q, $timeout) {
            this.$scope = $scope;
            this.$log = $log;
            this.$q = $q;
            this.$timeout = $timeout;
            this.controllerName = "DmlesTypeaheadFieldController Directive";
            // member properties
            this.typeaheadList = [];
        }
        DmlesTypeaheadFieldController.prototype.init = function () {
        };
        DmlesTypeaheadFieldController.prototype.getTypeaheadList = function (filterData) {
            var _this = this;
            this.$log.debug("Inside refreshTypeaheadList with filterData of " + filterData);
            return this.tafTypeaheadFunction(filterData).then(function (response) {
                _this.typeaheadList = response;
                _this.$log.debug("typeaheadList => " + JSON.stringify(_this.typeaheadList, null, 3));
                return _this.typeaheadList;
            });
        };
        return DmlesTypeaheadFieldController;
    }());
    exports.DmlesTypeaheadFieldController = DmlesTypeaheadFieldController;
});
//# sourceMappingURL=dmlesTypeaheadField.controller.js.map