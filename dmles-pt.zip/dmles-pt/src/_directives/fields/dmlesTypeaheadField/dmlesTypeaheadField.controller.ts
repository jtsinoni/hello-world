export class DmlesTypeaheadFieldController {
    private controllerName: string = "DmlesTypeaheadFieldController Directive";

    // attributes from Directive
    public tafId: string;
    public tafLabel: string;
    public tafModel: any;
    public tafReadonly: string;
    public tafTypeaheadFunction: (string) => any;

    // member properties
    public typeaheadList: Array<string> = [];

    //@inject
    constructor(public $scope, private $log, private $q, private $timeout) {
    }

    public init() {
    }

    public getTypeaheadList(filterData) {
        this.$log.debug("Inside refreshTypeaheadList with filterData of " + filterData);
        return this.tafTypeaheadFunction(filterData).then((response) => {
            this.typeaheadList = response;
            this.$log.debug("typeaheadList => " + JSON.stringify(this.typeaheadList, null, 3));
            return this.typeaheadList;
        });
    }
}