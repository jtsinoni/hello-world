import {DmlesTypeaheadFieldController} from "./dmlesTypeaheadField.controller";

//
// Usage:
// <dmles-typeahead-field 
//      taf-id="mfr"
//      taf-label="Manufacturer"
//      taf-model="vm.record.manufacturer"
//      taf-readonly="false"
//      taf-typeahead-function="vm.myTypeaheadFunction(filterData)">
// </dmles-typeahead-field>
//
// where:
//      taf-typeahead-function specifies a callback function
//          that takes the current string typed into the 
//          typeahead field; use this value to search for 
//          potential values to select from in listbox
//

export class DmlesTypeaheadField implements ng.IDirective {
    public restrict:string = "EA";
    public transclude:boolean = true;
    public controller = DmlesTypeaheadFieldController;
    public controllerAs:string = 'vm';
    public templateUrl:string = "./src/_directives/fields/dmlesTypeaheadField/dmlesTypeaheadField.template.html";
    //public replace:boolean = true;

    public bindToController:any = {
        tafId: '@',
        tafLabel: '@',
        tafModel: '=',
        tafReadonly: '@',
        tafTypeaheadFunction: '&'
    };

    public scope:any = {};

    // @ngInject
    constructor(private $log) {}

    public static Factory() {
        const directive = ($log) => new DmlesTypeaheadField($log);
        directive.$inject = ['$log'];
        return directive;
    }
}