define(["require", "exports", "./dmlesTypeaheadField.controller"], function (require, exports, dmlesTypeaheadField_controller_1) {
    "use strict";
    //
    // Usage:
    // <dmles-typeahead-field 
    //      taf-id="mfr"
    //      taf-label="Manufacturer"
    //      taf-model="vm.record.manufacturer"
    //      taf-readonly="false"
    //      taf-typeahead-function="vm.myTypeaheadFunction(filterData)">
    // </dmles-typeahead-field>
    //
    // where:
    //      taf-typeahead-function specifies a callback function
    //          that takes the current string typed into the 
    //          typeahead field; use this value to search for 
    //          potential values to select from in listbox
    //
    var DmlesTypeaheadField = (function () {
        // @ngInject
        function DmlesTypeaheadField($log) {
            this.$log = $log;
            this.restrict = "EA";
            this.transclude = true;
            this.controller = dmlesTypeaheadField_controller_1.DmlesTypeaheadFieldController;
            this.controllerAs = 'vm';
            this.templateUrl = "./src/_directives/fields/dmlesTypeaheadField/dmlesTypeaheadField.template.html";
            //public replace:boolean = true;
            this.bindToController = {
                tafId: '@',
                tafLabel: '@',
                tafModel: '=',
                tafReadonly: '@',
                tafTypeaheadFunction: '&'
            };
            this.scope = {};
        }
        DmlesTypeaheadField.Factory = function () {
            var directive = function ($log) { return new DmlesTypeaheadField($log); };
            directive.$inject = ['$log'];
            return directive;
        };
        return DmlesTypeaheadField;
    }());
    exports.DmlesTypeaheadField = DmlesTypeaheadField;
});
//# sourceMappingURL=dmlesTypeaheadField.directive.js.map