define(["require", "exports", "./dmlesDateField.controller"], function (require, exports, dmlesDateField_controller_1) {
    "use strict";
    //
    // Usage:
    // <dmles-date-field 
    //      df-id="ndc"
    //      df-label="National Drug Code"
    //      df-model="vm.record.ndc"
    //      df-readonly="false"
    //      df-date-options="vm.dateOptions"
    // </dmles-date-field>
    //
    var DmlesDateField = (function () {
        // @ngInject
        function DmlesDateField($log) {
            this.$log = $log;
            this.restrict = "EA";
            this.transclude = true;
            this.controller = dmlesDateField_controller_1.DmlesDateFieldController;
            this.controllerAs = 'vm';
            this.templateUrl = "./src/_directives/fields/dmlesDateField/dmlesDateField.template.html";
            //public replace:boolean = true;
            this.bindToController = {
                dfId: '@',
                dfLabel: '@',
                dfModel: '=',
                dfReadonly: '@',
                dfDatepickerOptions: '=',
            };
            this.scope = {};
        }
        DmlesDateField.Factory = function () {
            var directive = function ($log) { return new DmlesDateField($log); };
            directive.$inject = ['$log'];
            return directive;
        };
        return DmlesDateField;
    }());
    exports.DmlesDateField = DmlesDateField;
});
//# sourceMappingURL=dmlesDateField.directive.js.map