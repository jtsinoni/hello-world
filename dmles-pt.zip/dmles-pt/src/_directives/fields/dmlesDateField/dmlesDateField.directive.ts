import {DmlesDateFieldController} from "./dmlesDateField.controller";

//
// Usage:
// <dmles-date-field 
//      df-id="ndc"
//      df-label="National Drug Code"
//      df-model="vm.record.ndc"
//      df-readonly="false"
//      df-date-options="vm.dateOptions"
// </dmles-date-field>
//

export class DmlesDateField implements ng.IDirective {
    public restrict:string = "EA";
    public transclude:boolean = true;
    public controller = DmlesDateFieldController;
    public controllerAs:string = 'vm';
    public templateUrl:string = "./src/_directives/fields/dmlesDateField/dmlesDateField.template.html";
    //public replace:boolean = true;

    public bindToController:any = {
        dfId: '@',
        dfLabel: '@',
        dfModel: '=',
        dfReadonly: '@',
        dfDatepickerOptions: '=',
    };

    public scope:any = {};

    // @ngInject
    constructor(private $log) {}

    public static Factory() {
        const directive = ($log) => new DmlesDateField($log);
        directive.$inject = ['$log'];
        return directive;
    }
}