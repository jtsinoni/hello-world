export class DmlesDateFieldController {
    private controllerName: string = "DmlesDateFieldController Directive";

    // attributes from Directive
    public dfId: string;
    public dfLabel: string;
    public dfModel: any;
    public dfReadonly: string;
    public dfDatepickerOptions: any;

    // member properties
    public isCalendarOpen: boolean = false;

    //@inject
    constructor(public $scope, private $log, private $q, private $timeout) {
        this.init();
    }

    public init() {
        this.dfModel = new Date(this.dfModel);
        var today = new Date();
        this.dfDatepickerOptions = {
            formatYear:'yyyy',
            initDate: today,
            minDate: today,
            maxMode:'month',
            startingDay: 0,
            showWeeks: false
        };
    }
}