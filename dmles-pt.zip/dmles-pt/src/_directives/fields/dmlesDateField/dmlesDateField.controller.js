define(["require", "exports"], function (require, exports) {
    "use strict";
    var DmlesDateFieldController = (function () {
        //@inject
        function DmlesDateFieldController($scope, $log, $q, $timeout) {
            this.$scope = $scope;
            this.$log = $log;
            this.$q = $q;
            this.$timeout = $timeout;
            this.controllerName = "DmlesDateFieldController Directive";
            // member properties
            this.isCalendarOpen = false;
            this.init();
        }
        DmlesDateFieldController.prototype.init = function () {
            this.dfModel = new Date(this.dfModel);
            var today = new Date();
            this.dfDatepickerOptions = {
                formatYear: 'yyyy',
                initDate: today,
                minDate: today,
                maxMode: 'month',
                startingDay: 0,
                showWeeks: false
            };
        };
        return DmlesDateFieldController;
    }());
    exports.DmlesDateFieldController = DmlesDateFieldController;
});
//# sourceMappingURL=dmlesDateField.controller.js.map