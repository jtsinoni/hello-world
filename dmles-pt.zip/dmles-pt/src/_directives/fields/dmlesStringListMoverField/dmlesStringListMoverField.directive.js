// Example Usage:
// In your HTML Template:
//
// <dmles-string-list-mover-field
//     slm-id="sampleMover"
//     slm-label="Array of Strings"
//     slm-destination-model="vm.leftArrayModel"
//     slm-source-model="vm.rightArrayModel"
//     slm-disabled="false"
// >
// </dmles-string-list-mover-field>
define(["require", "exports", "./dmlesStringListMoverField.controller"], function (require, exports, dmlesStringListMoverField_controller_1) {
    "use strict";
    var DmlesStringListMoverField = (function () {
        // @ngInject
        function DmlesStringListMoverField($log) {
            this.$log = $log;
            this.restrict = "EA";
            this.transclude = true;
            this.controller = dmlesStringListMoverField_controller_1.DmlesStringListMoverFieldController;
            this.controllerAs = 'vm';
            this.templateUrl = "./src/_directives/fields/dmlesStringListMoverField/dmlesStringListMoverField.template.html";
            //public replace:boolean = true;
            this.bindToController = {
                slmId: '@',
                slmLabel: '@',
                slmDestinationModel: '=',
                slmSourceModel: '=',
            };
            this.scope = {};
        }
        DmlesStringListMoverField.Factory = function () {
            var directive = function ($log) { return new DmlesStringListMoverField($log); };
            directive.$inject = ['$log'];
            return directive;
        };
        return DmlesStringListMoverField;
    }());
    exports.DmlesStringListMoverField = DmlesStringListMoverField;
});
//# sourceMappingURL=dmlesStringListMoverField.directive.js.map