export class DmlesStringListMoverFieldController {
    private controllerName: string = "DmlesStringListMoverFieldController Directive";

    // attributes from Directive
    public slmId: string;
    public slmLabel: string;
    public slmDestinationModel: Array<string>;
    public slmSourceModel: Array<string>;

    public stringListSummary: string = "0 items.";
    public showPanel: boolean = false;
    public leftList: Array<string> = [];
    public rightList: Array<string> = [];
    public leftSelectedItems: Array<string> = [];
    public rightSelectedItems: Array<string> = [];

    //@inject
    constructor(public $scope, private $log, private $q, private $timeout, private UtilService) {
        this.$scope.$watch(() => { return this.slmDestinationModel; }, (newValue, oldValue) => {
            this.initializeLeftList();
        });
        this.$scope.$watch(() => { return this.slmSourceModel; }, (newValue, oldValue) => {
            this.initializeRightList();
        });
    }

    public init() {
        this.initializeLeftList();
        this.initializeRightList();
    }

    public initializeLeftList() {
        this.leftList = [];
        if ((this.slmDestinationModel !== null) && (this.slmDestinationModel !== undefined)) {
            var sourceList: Array<string> = this.slmDestinationModel;
            for (var i = 0; i < sourceList.length; i++) {
                var value = sourceList[i];
                if ((!this.listContainsStringValue(this.leftList, value)) && 
                    (!this.listContainsStringValue(this.rightList, value)) &&
                    (!this.UtilService.isNullOrEmpty(value))) {
                    this.leftList.push(value);
                }
            }
        }
        this.updateStringListSummary();
    }

    public initializeRightList() {
        this.rightList = [];
        if ((this.slmSourceModel !== null) && (this.slmSourceModel !== undefined)) {
            for (var i = 0; i < this.slmSourceModel.length; i++) {
                var sourceList: Array<string> = this.slmSourceModel;
                for (var j = 0; j < sourceList.length; j++) {
                    var value = sourceList[j];
                    if ((!this.listContainsStringValue(this.leftList, value)) && 
                        (!this.listContainsStringValue(this.rightList, value)) &&
                        (!this.UtilService.isNullOrEmpty(value))) {
                        this.rightList.push(value);
                    }
                }
            }
        }
    }

    public onShowPanelClicked() {
        this.showPanel = !this.showPanel;
    }

        
    public listContainsStringValue(list: Array<string>, stringValue: string): boolean {
        var listContainsStringValue: boolean = false;
        for (var i=0; i < list.length; i++) {
            if (list[i] === stringValue) {
                listContainsStringValue = true;
                break;
            }
        }
        return listContainsStringValue;
    }

    public moveSelectedRight(): void {
        for (var i = this.leftSelectedItems.length - 1; i >= 0; i--) {
            var listIndex = this.leftSelectedItems[i];
            this.rightList.splice(this.rightList.length, 0, this.leftList[listIndex]);
            this.leftList.splice(Number(listIndex), 1);
        }
        this.rightList.sort((left, right) => {
            return (left.localeCompare(right));
        });
        this.updateDestinationModel();
    }

    public moveSelectedLeft(): void {
        for (var i = this.rightSelectedItems.length - 1; i >= 0 ; i--) {
            var listIndex = this.rightSelectedItems[i];
            this.leftList.splice(this.leftList.length, 0, this.rightList[listIndex]);
            this.rightList.splice(Number(listIndex), 1);
        }
        this.leftList.sort((left, right) => {
            return (left.localeCompare(right));
        });
        this.updateDestinationModel();
    }

    public moveAllRight(): void {
        for (var i = 0; i < this.leftList.length; i++) {
            var value = this.leftList[i];
            this.rightList.push(value);
        }
        this.leftList = [];
        this.rightList.sort((left, right) => {
            return (left.localeCompare(right));
        });
        this.updateDestinationModel();
    }

    public moveAllLeft(): void {
        for (var i = 0; i < this.rightList.length; i++) {
            var value = this.rightList[i];
            this.leftList.push(value);
        }
        this.rightList = [];
        this.leftList.sort((left, right) => {
            return (left.localeCompare(right));
        });
        this.updateDestinationModel();
    }

    private updateDestinationModel(): void {
        this.slmDestinationModel = [];
        for (var i = 0; i < this.leftList.length; i++) {
            var value = this.leftList[i];
            if (!this.UtilService.isNullOrEmpty(value)) {
                this.slmDestinationModel.push(value);
            }
        }
        this.updateStringListSummary();
    }

    private updateStringListSummary(): void {
        var numItems = this.slmDestinationModel.length;
        this.stringListSummary = numItems + ((numItems === 1) ? " item." : " items.");
    }
}