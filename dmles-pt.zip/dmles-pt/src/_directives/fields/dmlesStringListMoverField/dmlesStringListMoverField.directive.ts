// Example Usage:
// In your HTML Template:
//
// <dmles-string-list-mover-field
//     slm-id="sampleMover"
//     slm-label="Array of Strings"
//     slm-destination-model="vm.leftArrayModel"
//     slm-source-model="vm.rightArrayModel"
//     slm-disabled="false"
// >
// </dmles-string-list-mover-field>

// In your View Controller:
//
// public leftArrayModel: Array<string> = [ 'orange', 'apple', 'grapes', 'banana', 'kiwi'];
// public rightArrayModel: Array<string> = [ 'celery', 'carrots', 'lettuce', 'tomato', 'green pepper', 'cucumber', 'cabbage' ];

import {DmlesStringListMoverFieldController} from "./dmlesStringListMoverField.controller";

export class DmlesStringListMoverField implements ng.IDirective {
    public restrict:string = "EA";
    public transclude:boolean = true;
    public controller = DmlesStringListMoverFieldController;
    public controllerAs:string = 'vm';
    public templateUrl:string = "./src/_directives/fields/dmlesStringListMoverField/dmlesStringListMoverField.template.html";
    //public replace:boolean = true;

    public bindToController:any = {
        slmId: '@',
        slmLabel: '@',
        slmDestinationModel: '=',
        slmSourceModel: '=',
    };

    public scope:any = {};

    // @ngInject
    constructor(private $log) {}

    public static Factory() {
        const directive = ($log) => new DmlesStringListMoverField($log);
        directive.$inject = ['$log'];
        return directive;
    }
}