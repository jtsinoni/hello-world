define(["require", "exports"], function (require, exports) {
    "use strict";
    var DmlesStringListMoverFieldController = (function () {
        //@inject
        function DmlesStringListMoverFieldController($scope, $log, $q, $timeout) {
            var _this = this;
            this.$scope = $scope;
            this.$log = $log;
            this.$q = $q;
            this.$timeout = $timeout;
            this.controllerName = "DmlesStringListMoverFieldController Directive";
            this.stringListSummary = "0 items.";
            this.showPanel = false;
            this.leftList = [];
            this.rightList = [];
            this.leftSelectedItems = [];
            this.rightSelectedItems = [];
            this.$scope.$watch(function () { return _this.slmDestinationModel; }, function (newValue, oldValue) {
                _this.initializeLeftList();
            });
            this.$scope.$watch(function () { return _this.slmSourceModel; }, function (newValue, oldValue) {
                _this.initializeRightList();
            });
        }
        DmlesStringListMoverFieldController.prototype.init = function () {
            this.initializeLeftList();
            this.initializeRightList();
        };
        DmlesStringListMoverFieldController.prototype.initializeLeftList = function () {
            this.leftList = [];
            if ((this.slmDestinationModel !== null) && (this.slmDestinationModel !== undefined)) {
                var sourceList = this.slmDestinationModel;
                for (var i = 0; i < sourceList.length; i++) {
                    var value = sourceList[i];
                    if ((!this.listContainsStringValue(this.leftList, value)) &&
                        (!this.listContainsStringValue(this.rightList, value)) &&
                        (!this.isStringValueNullOrEmpty(value))) {
                        this.leftList.push(value);
                    }
                }
            }
            this.updateStringListSummary();
        };
        DmlesStringListMoverFieldController.prototype.initializeRightList = function () {
            this.rightList = [];
            if ((this.slmSourceModel !== null) && (this.slmSourceModel !== undefined)) {
                for (var i = 0; i < this.slmSourceModel.length; i++) {
                    var sourceList = this.slmSourceModel;
                    for (var j = 0; j < sourceList.length; j++) {
                        var value = sourceList[j];
                        if ((!this.listContainsStringValue(this.leftList, value)) &&
                            (!this.listContainsStringValue(this.rightList, value)) &&
                            (!this.isStringValueNullOrEmpty(value))) {
                            this.rightList.push(value);
                        }
                    }
                }
            }
        };
        DmlesStringListMoverFieldController.prototype.onShowPanelClicked = function () {
            this.showPanel = !this.showPanel;
        };
        DmlesStringListMoverFieldController.prototype.listContainsStringValue = function (list, stringValue) {
            var listContainsStringValue = false;
            for (var i = 0; i < list.length; i++) {
                if (list[i] === stringValue) {
                    listContainsStringValue = true;
                    break;
                }
            }
            return listContainsStringValue;
        };
        DmlesStringListMoverFieldController.prototype.moveSelectedRight = function () {
            for (var i = this.leftSelectedItems.length - 1; i >= 0; i--) {
                var listIndex = this.leftSelectedItems[i];
                this.rightList.splice(this.rightList.length, 0, this.leftList[listIndex]);
                this.leftList.splice(Number(listIndex), 1);
            }
            this.rightList.sort(function (left, right) {
                return (left.localeCompare(right));
            });
            this.updateDestinationModel();
        };
        DmlesStringListMoverFieldController.prototype.moveSelectedLeft = function () {
            for (var i = this.rightSelectedItems.length - 1; i >= 0; i--) {
                var listIndex = this.rightSelectedItems[i];
                this.leftList.splice(this.leftList.length, 0, this.rightList[listIndex]);
                this.rightList.splice(Number(listIndex), 1);
            }
            this.leftList.sort(function (left, right) {
                return (left.localeCompare(right));
            });
            this.updateDestinationModel();
        };
        DmlesStringListMoverFieldController.prototype.moveAllRight = function () {
            for (var i = 0; i < this.leftList.length; i++) {
                var value = this.leftList[i];
                this.rightList.push(value);
            }
            this.leftList = [];
            this.rightList.sort(function (left, right) {
                return (left.localeCompare(right));
            });
            this.updateDestinationModel();
        };
        DmlesStringListMoverFieldController.prototype.moveAllLeft = function () {
            for (var i = 0; i < this.rightList.length; i++) {
                var value = this.rightList[i];
                this.leftList.push(value);
            }
            this.rightList = [];
            this.leftList.sort(function (left, right) {
                return (left.localeCompare(right));
            });
            this.updateDestinationModel();
        };
        DmlesStringListMoverFieldController.prototype.updateDestinationModel = function () {
            this.slmDestinationModel = [];
            for (var i = 0; i < this.leftList.length; i++) {
                var value = this.leftList[i];
                if (!this.isStringValueNullOrEmpty(value)) {
                    this.slmDestinationModel.push(value);
                }
            }
            this.updateStringListSummary();
        };
        DmlesStringListMoverFieldController.prototype.updateStringListSummary = function () {
            var numItems = this.slmDestinationModel.length;
            this.stringListSummary = numItems + ((numItems === 1) ? " item." : " items.");
        };
        DmlesStringListMoverFieldController.prototype.isStringValueNullOrEmpty = function (value) {
            var isNullOrEmpty = false;
            if ((value === null) || (value === undefined) || (value.trim() === "")) {
                isNullOrEmpty = true;
            }
            return isNullOrEmpty;
        };
        return DmlesStringListMoverFieldController;
    }());
    exports.DmlesStringListMoverFieldController = DmlesStringListMoverFieldController;
});
//# sourceMappingURL=dmlesStringListMoverField.controller.js.map