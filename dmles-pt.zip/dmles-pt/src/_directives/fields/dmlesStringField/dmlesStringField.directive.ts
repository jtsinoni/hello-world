import {DmlesStringFieldController} from "./dmlesStringField.controller";

//
// Usage:
// <dmles-string-field 
//      sf-id="ndc"
//      sf-label="National Drug Code"
//      sf-model="vm.record.ndc"
//      sf-readonly="false"
// </dmles-string-field>
//

export class DmlesStringField implements ng.IDirective {
    public restrict:string = "EA";
    public transclude:boolean = true;
    public controller = DmlesStringFieldController;
    public controllerAs:string = 'vm';
    public templateUrl:string = "./src/_directives/fields/dmlesStringField/dmlesStringField.template.html";
    //public replace:boolean = true;

    public bindToController:any = {
        sfId: '@',
        sfLabel: '@',
        sfModel: '=',
        sfReadonly: '@'
    };

    public scope:any = {};

    // @ngInject
    constructor(private $log) {}

    public static Factory() {
        const directive = ($log) => new DmlesStringField($log);
        directive.$inject = ['$log'];
        return directive;
    }
}