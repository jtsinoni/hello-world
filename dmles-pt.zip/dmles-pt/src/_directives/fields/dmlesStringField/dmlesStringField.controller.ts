export class DmlesStringFieldController {
    private controllerName: string = "DmleStringFieldController Directive";

    // attributes from Directive
    public sfId: string;
    public sfLabel: string;
    public sfModel: any;
    public sfReadonly: string;

    //@inject
    constructor(public $scope, private $log, private $q, private $timeout) {
    }

    public init() {
    }
}