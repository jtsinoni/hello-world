define(["require", "exports", "./dmlesStringField.controller"], function (require, exports, dmlesStringField_controller_1) {
    "use strict";
    //
    // Usage:
    // <dmles-string-field 
    //      sf-id="ndc"
    //      sf-label="National Drug Code"
    //      sf-model="vm.record.ndc"
    //      sf-readonly="false"
    // </dmles-string-field>
    //
    var DmlesStringField = (function () {
        // @ngInject
        function DmlesStringField($log) {
            this.$log = $log;
            this.restrict = "EA";
            this.transclude = true;
            this.controller = dmlesStringField_controller_1.DmlesStringFieldController;
            this.controllerAs = 'vm';
            this.templateUrl = "./src/_directives/fields/dmlesStringField/dmlesStringField.template.html";
            //public replace:boolean = true;
            this.bindToController = {
                sfId: '@',
                sfLabel: '@',
                sfModel: '=',
                sfReadonly: '@'
            };
            this.scope = {};
        }
        DmlesStringField.Factory = function () {
            var directive = function ($log) { return new DmlesStringField($log); };
            directive.$inject = ['$log'];
            return directive;
        };
        return DmlesStringField;
    }());
    exports.DmlesStringField = DmlesStringField;
});
//# sourceMappingURL=dmlesStringField.directive.js.map