define(["require", "exports"], function (require, exports) {
    "use strict";
    var DmlesStringFieldController = (function () {
        //@inject
        function DmlesStringFieldController($scope, $log, $q, $timeout) {
            this.$scope = $scope;
            this.$log = $log;
            this.$q = $q;
            this.$timeout = $timeout;
            this.controllerName = "DmleStringFieldController Directive";
        }
        DmlesStringFieldController.prototype.init = function () {
        };
        return DmlesStringFieldController;
    }());
    exports.DmlesStringFieldController = DmlesStringFieldController;
});
//# sourceMappingURL=dmlesStringField.controller.js.map