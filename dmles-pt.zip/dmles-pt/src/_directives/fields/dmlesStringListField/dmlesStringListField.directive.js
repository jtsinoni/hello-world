define(["require", "exports", "./dmlesStringListField.controller"], function (require, exports, dmlesStringListField_controller_1) {
    "use strict";
    var DmlesStringListField = (function () {
        // @ngInject
        function DmlesStringListField($log) {
            this.$log = $log;
            this.restrict = "EA";
            this.transclude = true;
            this.controller = dmlesStringListField_controller_1.DmlesStringListFieldController;
            this.controllerAs = 'vm';
            this.templateUrl = "./src/_directives/fields/dmlesStringListField/dmlesStringListField.template.html";
            //public replace:boolean = true;
            this.bindToController = {
                slId: '@',
                slLabel: '@',
                slModel: '=',
                slDisabled: '=',
            };
            this.scope = {};
        }
        DmlesStringListField.Factory = function () {
            var directive = function ($log) { return new DmlesStringListField($log); };
            directive.$inject = ['$log'];
            return directive;
        };
        return DmlesStringListField;
    }());
    exports.DmlesStringListField = DmlesStringListField;
});
//# sourceMappingURL=dmlesStringListField.directive.js.map