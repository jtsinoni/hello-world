define(["require", "exports"], function (require, exports) {
    "use strict";
    var DmlesStringListFieldController = (function () {
        //@inject
        function DmlesStringListFieldController($scope, $log, $q, $timeout) {
            var _this = this;
            this.$scope = $scope;
            this.$log = $log;
            this.$q = $q;
            this.$timeout = $timeout;
            this.controllerName = "DmlesStringListFieldController Directive";
            this.stringListSummary = "0 items.";
            this.showPanel = false;
            this.newValueText = "";
            this.editValueText = "";
            this.topRowMode = "add";
            this.valueToDelete = "need to fill this in";
            this.selectedListItem = "";
            this.workingList = [];
            this.$scope.$watch(function () { return _this.slModel; }, function (newValue, oldValue) {
                _this.init();
            });
        }
        DmlesStringListFieldController.prototype.init = function () {
            this.createWorkingList();
            this.updateStringListSummary();
        };
        DmlesStringListFieldController.prototype.onClick = function () {
            this.showPanel = !this.showPanel;
        };
        DmlesStringListFieldController.prototype.onAddButtonClicked = function () {
            if (this.topRowMode === "add") {
                this.workingList.push({
                    'index': this.workingList.length + 1,
                    'value': this.newValueText
                });
                this.newValueText = "";
            }
            this.refreshModel();
        };
        DmlesStringListFieldController.prototype.onEditButtonClicked = function () {
            this.editValueText = this.workingList[this.selectedListItem].value;
            this.topRowMode = "update";
        };
        DmlesStringListFieldController.prototype.onDeleteButtonClicked = function () {
            this.valueToDelete = this.workingList[this.selectedListItem].value;
            this.topRowMode = "delete";
        };
        DmlesStringListFieldController.prototype.onUpdateButtonClicked = function () {
            this.workingList[this.selectedListItem].value = this.editValueText;
            this.topRowMode = "add";
            this.refreshModel();
        };
        DmlesStringListFieldController.prototype.onCancelUpdateButtonClicked = function () {
            this.topRowMode = "add";
        };
        DmlesStringListFieldController.prototype.onDeleteYesButtonClicked = function () {
            this.topRowMode = "add";
            this.workingList.splice(this.selectedListItem, 1);
            this.refreshModel();
        };
        DmlesStringListFieldController.prototype.onDeleteNoButtonClicked = function () {
            this.topRowMode = "add";
        };
        DmlesStringListFieldController.prototype.updateStringListSummary = function () {
            if ((this.slModel !== null) && (typeof this.slModel != 'undefined')) {
                this.stringListSummary = this.slModel.length + " items.";
            }
        };
        DmlesStringListFieldController.prototype.createWorkingList = function () {
            this.workingList = [];
            if ((this.slModel !== null) && (typeof this.slModel != 'undefined')) {
                for (var i = 0; i < this.slModel.length; i++) {
                    this.workingList.push({
                        'index': i,
                        'value': this.slModel[i]
                    });
                }
            }
        };
        DmlesStringListFieldController.prototype.refreshModel = function () {
            if ((this.slModel !== null) && (typeof this.slModel != 'undefined')) {
                this.slModel = [];
                for (var i = 0; i < this.workingList.length; i++) {
                    this.workingList[i].index = i;
                    this.slModel.push(this.workingList[i].value);
                }
                this.updateStringListSummary();
            }
        };
        return DmlesStringListFieldController;
    }());
    exports.DmlesStringListFieldController = DmlesStringListFieldController;
});
//# sourceMappingURL=dmlesStringListField.controller.js.map