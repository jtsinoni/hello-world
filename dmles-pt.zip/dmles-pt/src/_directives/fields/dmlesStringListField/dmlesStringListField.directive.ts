import {DmlesStringListFieldController} from "./dmlesStringListField.controller";

export class DmlesStringListField implements ng.IDirective {
    public restrict:string = "EA";
    public transclude:boolean = true;
    public controller = DmlesStringListFieldController;
    public controllerAs:string = 'vm';
    public templateUrl:string = "./src/_directives/fields/dmlesStringListField/dmlesStringListField.template.html";
    //public replace:boolean = true;

    public bindToController:any = {
        slId: '@',
        slLabel: '@',
        slModel: '=',
        slDisabled: '=',
    };

    public scope:any = {};

    // @ngInject
    constructor(private $log) {}

    public static Factory() {
        const directive = ($log) => new DmlesStringListField($log);
        directive.$inject = ['$log'];
        return directive;
    }
}