export class DmlesStringListFieldController {
    private controllerName: string = "DmlesStringListFieldController Directive";

    // attributes from Directive
    public slId: string;
    public slLabel: string;
    public slModel: any;
    public slDisabled: boolean;

    public stringListSummary: string = "0 items.";
    public showPanel: boolean = false;
    public newValueText: string = "";
    public editValueText: string = "";
    public topRowMode: string = "add";
    public valueToDelete: string = "need to fill this in";
    public selectedListItem: any = "";
    public workingList: Array < any > = [];

    //@inject
    constructor(public $scope, private $log, private $q, private $timeout) {
        this.$scope.$watch(() => { return this.slModel; }, (newValue, oldValue) => {
            this.init();
        });
    }

    public init() {
        this.createWorkingList();
        this.updateStringListSummary();
    }

    public onClick() {
        this.showPanel = !this.showPanel;
    }

    public onAddButtonClicked() {
        if (this.topRowMode === "add") {
            this.workingList.push({
                'index': this.workingList.length + 1,
                'value': this.newValueText
            });
            this.newValueText = "";
        }
        this.refreshModel();
    }

    public onEditButtonClicked() {
        this.editValueText = this.workingList[this.selectedListItem].value;
        this.topRowMode = "update";
    }

    public onDeleteButtonClicked() {
        this.valueToDelete = this.workingList[this.selectedListItem].value;
        this.topRowMode = "delete";
    }

    public onUpdateButtonClicked() {
        this.workingList[this.selectedListItem].value = this.editValueText;
        this.topRowMode = "add";
        this.refreshModel();
    }

    public onCancelUpdateButtonClicked() {
        this.topRowMode = "add";
    }

    public onDeleteYesButtonClicked() {
        this.topRowMode = "add";
        this.workingList.splice(this.selectedListItem, 1);
        this.refreshModel();
    }

    public onDeleteNoButtonClicked() {
        this.topRowMode = "add";
    }

    private updateStringListSummary() {
        if ((this.slModel !== null) && (typeof this.slModel != 'undefined')) {
            this.stringListSummary = this.slModel.length + " items.";
        }
    }

    private createWorkingList() {
        this.workingList = [];
        if ((this.slModel !== null) && (typeof this.slModel != 'undefined')) {
            for (var i = 0; i < this.slModel.length; i++) {
                this.workingList.push({
                    'index': i,
                    'value': this.slModel[i]
                });
            }
        }
    }

    private refreshModel() {
        if ((this.slModel !== null) && (typeof this.slModel != 'undefined')) {
            this.slModel = [];
            for (var i = 0; i < this.workingList.length; i++) {
                this.workingList[i].index = i;
                this.slModel.push(this.workingList[i].value);
            }
            this.updateStringListSummary();
            // this.$scope.$apply();
        }
    }
}