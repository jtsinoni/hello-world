define(["require", "exports"], function (require, exports) {
    "use strict";
    var DmlesDropDownListFieldController = (function () {
        //@inject
        function DmlesDropDownListFieldController($scope, $log, $q, $timeout) {
            this.$scope = $scope;
            this.$log = $log;
            this.$q = $q;
            this.$timeout = $timeout;
            this.controllerName = "DmlesDropDownListFieldController Directive";
        }
        DmlesDropDownListFieldController.prototype.init = function () {
        };
        return DmlesDropDownListFieldController;
    }());
    exports.DmlesDropDownListFieldController = DmlesDropDownListFieldController;
});
//# sourceMappingURL=dmlesDropDownListField.controller.js.map