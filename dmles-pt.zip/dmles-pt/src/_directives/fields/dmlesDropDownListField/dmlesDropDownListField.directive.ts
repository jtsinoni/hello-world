import {DmlesDropDownListFieldController} from "./dmlesDropDownListField.controller";

//
// Usage:
// <dmles-drop-down-list-field 
//      ddl-id="color"
//      ddl-label="Color"
//      ddl-model="vm.record.color"
//      ddl-value-list="vm.approvedColorList"
//      ddl-readonly="false"
//      ddl-show-label="false"
// </dmles-drop-down-list-field>
//
// ddl-show-label := { true | false }
//      when true, label is to left of dropdown list
//      when false, no label is displayed
//      if not specified, defaults to 'true'

export class DmlesDropDownListField implements ng.IDirective {
    public restrict:string = "EA";
    public transclude:boolean = true;
    public controller = DmlesDropDownListFieldController;
    public controllerAs:string = 'vm';
    public templateUrl:string = "./src/_directives/fields/dmlesDropDownListField/dmlesDropDownListField.template.html";
    //public replace:boolean = true;

    public bindToController:any = {
        ddlId: '@',
        ddlLabel: '@',
        ddlModel: '=',
        ddlValueList: '=',
        ddlReadonly: '@',
        ddlShowLabel: '@'
    };

    public scope:any = {};

    // @ngInject
    constructor(private $log) {}

    public static Factory() {
        const directive = ($log) => new DmlesDropDownListField($log);
        directive.$inject = ['$log'];
        return directive;
    }
}