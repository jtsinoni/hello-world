define(["require", "exports", "./dmlesDropDownListField.controller"], function (require, exports, dmlesDropDownListField_controller_1) {
    "use strict";
    //
    // Usage:
    // <dmles-drop-down-list-field 
    //      ddl-id="color"
    //      ddl-label="Color"
    //      ddl-model="vm.record.color"
    //      ddl-value-list="vm.approvedColorList"
    //      ddl-readonly="false"
    //      ddl-show-label="false"
    // </dmles-drop-down-list-field>
    //
    // ddl-show-label := { true | false }
    //      when true, label is to left of dropdown list
    //      when false, no label is displayed
    //      if not specified, defaults to 'true'
    var DmlesDropDownListField = (function () {
        // @ngInject
        function DmlesDropDownListField($log) {
            this.$log = $log;
            this.restrict = "EA";
            this.transclude = true;
            this.controller = dmlesDropDownListField_controller_1.DmlesDropDownListFieldController;
            this.controllerAs = 'vm';
            this.templateUrl = "./src/_directives/fields/dmlesDropDownListField/dmlesDropDownListField.template.html";
            //public replace:boolean = true;
            this.bindToController = {
                ddlId: '@',
                ddlLabel: '@',
                ddlModel: '=',
                ddlValueList: '=',
                ddlReadonly: '@',
                ddlShowLabel: '@'
            };
            this.scope = {};
        }
        DmlesDropDownListField.Factory = function () {
            var directive = function ($log) { return new DmlesDropDownListField($log); };
            directive.$inject = ['$log'];
            return directive;
        };
        return DmlesDropDownListField;
    }());
    exports.DmlesDropDownListField = DmlesDropDownListField;
});
//# sourceMappingURL=dmlesDropDownListField.directive.js.map