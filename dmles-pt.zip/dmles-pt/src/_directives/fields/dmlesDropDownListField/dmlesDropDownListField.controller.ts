export class DmlesDropDownListFieldController {
    private controllerName: string = "DmlesDropDownListFieldController Directive";

    // attributes from Directive
    public ddlId: string;
    public ddlLabel: string;
    public ddlModel: any;
    public ddlValueList: Array<string>;
    public ddlReadonly: string;
    public ddlShowLabel: string;
    
    //@inject
    constructor(public $scope, private $log, private $q, private $timeout) {
    }

    public init() {
    }
}