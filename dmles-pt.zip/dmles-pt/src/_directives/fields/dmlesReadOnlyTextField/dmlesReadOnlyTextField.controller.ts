export class DmlesReadOnlyTextFieldController {
    private controllerName: string = "DmlesReadOnlyTextFieldController Directive";

    // attributes from Directive
    public label: string;
    public data: any;
    public filter: any;

    //@inject
    constructor(public $scope, private $log, private $q, private $filter, private $timeout) {
    }

    public init() {
    }
    public applyFilter() {
        if (this.filter) {
            var tfdata = this.data
            if (this.filter.indexOf('date') >= 0) {
                if (tfdata && tfdata.charAt(0) === '"' && tfdata.charAt(tfdata.length -1) === '"')
                {
                    tfdata = tfdata.substr(1,tfdata.length -2);
                }
                return (tfdata) ? this.$filter('date')(tfdata, 'dd MMM yyyy') : null;
            } else if (this.filter.indexOf('timestamp') >= 0) {
                // parse a timestamp like 04/18/2017 10.13.19.838000, replace '.' in the time with colons: 04/18/2017 10:13:19.838000, then convert to a Date
                var tfData = this.data;
                var firstPeriod = this.data.indexOf(".");
                var lastPeriod = this.data.lastIndexOf(".");
                if (firstPeriod != -1 && lastPeriod != -1 && firstPeriod != lastPeriod) {
                    while (firstPeriod < lastPeriod) {
                        tfData = this.replaceAt(tfData, firstPeriod, ":");
                        firstPeriod = tfData.indexOf(".");
                    }
                }
                return (tfData) ? this.$filter('date')(new Date(tfData), 'dd MMM yyyy') : null;
            } else if (this.filter.indexOf('currency') >= 0) {
                return (tfdata) ? this.$filter('currency')(tfdata) : null;
            }
            return this.data;
        }
    }
    private replaceAt(input, index, replaceWith) {
        return input.substr(0, index) + replaceWith+ input.substr(index + replaceWith.length);
    }
}