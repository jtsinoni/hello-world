define(["require", "exports", "./dmlesReadOnlyTextField.controller"], function (require, exports, dmlesReadOnlyTextField_controller_1) {
    "use strict";
    //
    // Usage:
    // <dmles-readonly-text-field
    //      label="National Drug Code"
    //      data="myVm.myController.myDateField"
    //      filter="date"
    // </dmles-readonly-text-field>
    //
    var DmlesReadOnlyTextField = (function () {
        // @ngInject
        function DmlesReadOnlyTextField($log) {
            this.$log = $log;
            this.restrict = "EA";
            this.transclude = true;
            this.controller = dmlesReadOnlyTextField_controller_1.DmlesReadOnlyTextFieldController;
            this.controllerAs = 'vm';
            this.templateUrl = "./src/_directives/fields/dmlesReadOnlyTextField/dmlesReadOnlyTextField.template.html";
            this.bindToController = {
                label: '@',
                data: '@',
                filter: '@'
            };
            this.scope = {};
        }
        DmlesReadOnlyTextField.Factory = function () {
            var directive = function ($log) { return new DmlesReadOnlyTextField($log); };
            directive.$inject = ['$log'];
            return directive;
        };
        return DmlesReadOnlyTextField;
    }());
    exports.DmlesReadOnlyTextField = DmlesReadOnlyTextField;
});
//# sourceMappingURL=dmlesReadOnlyTextField.directive.js.map