import {DmlesReadOnlyTextFieldController} from "./dmlesReadOnlyTextField.controller";

//
// Usage:
// <dmles-readonly-text-field
//      label="National Drug Code"
//      data="myVm.myController.myDateField"
//      filter="date"
// </dmles-readonly-text-field>
//

export class DmlesReadOnlyTextField implements ng.IDirective {
    public restrict:string = "EA";
    public transclude:boolean = true;
    public controller = DmlesReadOnlyTextFieldController;
    public controllerAs:string = 'vm';
    public templateUrl:string = "./src/_directives/fields/dmlesReadOnlyTextField/dmlesReadOnlyTextField.template.html";

    public bindToController:any = {
        label: '@',
        data: '@',
        filter: '@'
    };

    public scope:any = {};

    // @ngInject
    constructor(private $log) {}

    public static Factory() {
        const directive = ($log) => new DmlesReadOnlyTextField($log);
        directive.$inject = ['$log'];
        return directive;
    }
}