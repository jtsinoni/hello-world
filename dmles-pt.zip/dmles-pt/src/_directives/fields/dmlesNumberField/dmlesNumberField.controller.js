define(["require", "exports"], function (require, exports) {
    "use strict";
    var DmlesNumberFieldController = (function () {
        //@inject
        function DmlesNumberFieldController($scope, $log, $q, $timeout) {
            this.$scope = $scope;
            this.$log = $log;
            this.$q = $q;
            this.$timeout = $timeout;
            this.controllerName = "DmlesNumberFieldController Directive";
        }
        DmlesNumberFieldController.prototype.init = function () {
        };
        return DmlesNumberFieldController;
    }());
    exports.DmlesNumberFieldController = DmlesNumberFieldController;
});
//# sourceMappingURL=dmlesNumberField.controller.js.map