define(["require", "exports", "./dmlesNumberField.controller"], function (require, exports, dmlesNumberField_controller_1) {
    "use strict";
    //
    // Usage:
    // <dmles-number-field 
    //      nf-id="ndc"
    //      nf-label="National Drug Code"
    //      nf-model="vm.record.ndc"
    //      nf-readonly="false"
    // </dmles-number-field>
    //
    var DmlesNumberField = (function () {
        // @ngInject
        function DmlesNumberField($log) {
            this.$log = $log;
            this.restrict = "EA";
            this.transclude = true;
            this.controller = dmlesNumberField_controller_1.DmlesNumberFieldController;
            this.controllerAs = 'vm';
            this.templateUrl = "./src/_directives/fields/dmlesNumberField/dmlesNumberField.template.html";
            //public replace:boolean = true;
            this.bindToController = {
                nfId: '@',
                nfLabel: '@',
                nfModel: '=',
                nfReadonly: '@'
            };
            this.scope = {};
        }
        DmlesNumberField.Factory = function () {
            var directive = function ($log) { return new DmlesNumberField($log); };
            directive.$inject = ['$log'];
            return directive;
        };
        return DmlesNumberField;
    }());
    exports.DmlesNumberField = DmlesNumberField;
});
//# sourceMappingURL=dmlesNumberField.directive.js.map