export class DmlesNumberFieldController {
    private controllerName: string = "DmlesNumberFieldController Directive";

    // attributes from Directive
    public nfId: string;
    public nfLabel: string;
    public nfModel: any;
    public nfReadonly: string;

    //@inject
    constructor(public $scope, private $log, private $q, private $timeout) {
    }

    public init() {
    }
}