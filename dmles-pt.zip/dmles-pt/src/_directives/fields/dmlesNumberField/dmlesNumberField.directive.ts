import {DmlesNumberFieldController} from "./dmlesNumberField.controller";

//
// Usage:
// <dmles-number-field 
//      nf-id="ndc"
//      nf-label="National Drug Code"
//      nf-model="vm.record.ndc"
//      nf-readonly="false"
// </dmles-number-field>
//

export class DmlesNumberField implements ng.IDirective {
    public restrict:string = "EA";
    public transclude:boolean = true;
    public controller = DmlesNumberFieldController;
    public controllerAs:string = 'vm';
    public templateUrl:string = "./src/_directives/fields/dmlesNumberField/dmlesNumberField.template.html";
    //public replace:boolean = true;

    public bindToController:any = {
        nfId: '@',
        nfLabel: '@',
        nfModel: '=',
        nfReadonly: '@'
    };

    public scope:any = {};

    // @ngInject
    constructor(private $log) {}

    public static Factory() {
        const directive = ($log) => new DmlesNumberField($log);
        directive.$inject = ['$log'];
        return directive;
    }
}