define(["require", "exports", './dmlesCheckboxField/dmlesCheckboxField.controller', './dmlesCheckboxField/dmlesCheckboxField.directive', './dmlesDateField/dmlesDateField.controller', './dmlesDateField/dmlesDateField.directive', './dmlesDropDownListField/dmlesDropDownListField.controller', './dmlesDropDownListField/dmlesDropDownListField.directive', './dmlesFileUploadListField/dmlesFileUploadListField.controller', './dmlesFileUploadListField/dmlesFileUploadListField.directive', './dmlesNumberField/dmlesNumberField.controller', './dmlesNumberField/dmlesNumberField.directive', './dmlesReadOnlyTextField/dmlesReadOnlyTextField.controller', './dmlesReadOnlyTextField/dmlesReadOnlyTextField.directive', './dmlesStringField/dmlesStringField.controller', './dmlesStringField/dmlesStringField.directive', './dmlesStringListField/dmlesStringListField.controller', './dmlesStringListField/dmlesStringListField.directive', './dmlesStringListMoverField/dmlesStringListMoverField.controller', './dmlesStringListMoverField/dmlesStringListMoverField.directive', './dmlesTextareaField/dmlesTextareaField.controller', './dmlesTextareaField/dmlesTextareaField.directive', './dmlesTypeaheadField/dmlesTypeaheadField.controller', './dmlesTypeaheadField/dmlesTypeaheadField.directive'], function (require, exports, dmlesCheckboxField_controller_1, dmlesCheckboxField_directive_1, dmlesDateField_controller_1, dmlesDateField_directive_1, dmlesDropDownListField_controller_1, dmlesDropDownListField_directive_1, dmlesFileUploadListField_controller_1, dmlesFileUploadListField_directive_1, dmlesNumberField_controller_1, dmlesNumberField_directive_1, dmlesReadOnlyTextField_controller_1, dmlesReadOnlyTextField_directive_1, dmlesStringField_controller_1, dmlesStringField_directive_1, dmlesStringListField_controller_1, dmlesStringListField_directive_1, dmlesStringListMoverField_controller_1, dmlesStringListMoverField_directive_1, dmlesTextareaField_controller_1, dmlesTextareaField_directive_1, dmlesTypeaheadField_controller_1, dmlesTypeaheadField_directive_1) {
    "use strict";
    var directivesFieldsModule = angular.module('DirectivesFieldsModule', []);
    directivesFieldsModule.controller('DmlesCheckboxFieldController', dmlesCheckboxField_controller_1.DmlesCheckboxFieldController);
    directivesFieldsModule.directive('dmlesCheckboxField', dmlesCheckboxField_directive_1.DmlesCheckboxField.Factory());
    directivesFieldsModule.controller('DmlesDateFieldController', dmlesDateField_controller_1.DmlesDateFieldController);
    directivesFieldsModule.directive('dmlesDateField', dmlesDateField_directive_1.DmlesDateField.Factory());
    directivesFieldsModule.controller('DmlesDropDownListFieldController', dmlesDropDownListField_controller_1.DmlesDropDownListFieldController);
    directivesFieldsModule.directive('dmlesDropDownListField', dmlesDropDownListField_directive_1.DmlesDropDownListField.Factory());
    directivesFieldsModule.controller('DmlesFileUploadListFieldController', dmlesFileUploadListField_controller_1.DmlesFileUploadListFieldController);
    directivesFieldsModule.directive('dmlesFileUploadListField', dmlesFileUploadListField_directive_1.DmlesFileUploadListField.Factory());
    directivesFieldsModule.controller('DmlesNumberFieldController', dmlesNumberField_controller_1.DmlesNumberFieldController);
    directivesFieldsModule.directive('dmlesNumberField', dmlesNumberField_directive_1.DmlesNumberField.Factory());
    directivesFieldsModule.controller('DmlesReadOnlyTextFieldController', dmlesReadOnlyTextField_controller_1.DmlesReadOnlyTextFieldController);
    directivesFieldsModule.directive('dmlesReadOnlyTextField', dmlesReadOnlyTextField_directive_1.DmlesReadOnlyTextField.Factory());
    directivesFieldsModule.controller('DmlesStringFieldController', dmlesStringField_controller_1.DmlesStringFieldController);
    directivesFieldsModule.directive('dmlesStringField', dmlesStringField_directive_1.DmlesStringField.Factory());
    directivesFieldsModule.controller('DmlesStringListFieldController', dmlesStringListField_controller_1.DmlesStringListFieldController);
    directivesFieldsModule.directive('dmlesStringListField', dmlesStringListField_directive_1.DmlesStringListField.Factory());
    directivesFieldsModule.controller('DmlesStringListMoverFieldController', dmlesStringListMoverField_controller_1.DmlesStringListMoverFieldController);
    directivesFieldsModule.directive('dmlesStringListMoverField', dmlesStringListMoverField_directive_1.DmlesStringListMoverField.Factory());
    directivesFieldsModule.controller('DmlesTextareaFieldController', dmlesTextareaField_controller_1.DmlesTextareaFieldController);
    directivesFieldsModule.directive('dmlesTextareaField', dmlesTextareaField_directive_1.DmlesTextareaField.Factory());
    directivesFieldsModule.controller('DmlesTypeaheadFieldController', dmlesTypeaheadField_controller_1.DmlesTypeaheadFieldController);
    directivesFieldsModule.directive('dmlesTypeaheadField', dmlesTypeaheadField_directive_1.DmlesTypeaheadField.Factory());
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = directivesFieldsModule;
});
//# sourceMappingURL=module.js.map