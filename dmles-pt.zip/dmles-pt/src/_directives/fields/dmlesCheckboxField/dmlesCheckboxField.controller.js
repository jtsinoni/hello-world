define(["require", "exports"], function (require, exports) {
    "use strict";
    var DmlesCheckboxFieldController = (function () {
        //@inject
        function DmlesCheckboxFieldController($scope, $log, $q, $timeout) {
            this.$scope = $scope;
            this.$log = $log;
            this.$q = $q;
            this.$timeout = $timeout;
            this.controllerName = "DmlesCheckboxFieldController Directive";
        }
        DmlesCheckboxFieldController.prototype.init = function () {
        };
        return DmlesCheckboxFieldController;
    }());
    exports.DmlesCheckboxFieldController = DmlesCheckboxFieldController;
});
//# sourceMappingURL=dmlesCheckboxField.controller.js.map