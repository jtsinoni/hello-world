define(["require", "exports", "./dmlesCheckboxField.controller"], function (require, exports, dmlesCheckboxField_controller_1) {
    "use strict";
    //
    // Usage:
    // <dmles-checkbox-field 
    //      cbf-id="ndc"
    //      cbf-label="National Drug Code"
    //      cbf-model="vm.record.ndc"
    //      cbf-readonly="false"
    //      cbf-style="margin: 0px"
    // </dmles-checkbox-field>
    //
    var DmlesCheckboxField = (function () {
        // @ngInject
        function DmlesCheckboxField($log) {
            this.$log = $log;
            this.restrict = "EA";
            this.transclude = true;
            this.controller = dmlesCheckboxField_controller_1.DmlesCheckboxFieldController;
            this.controllerAs = 'vm';
            this.templateUrl = "./src/_directives/fields/dmlesCheckboxField/dmlesCheckboxField.template.html";
            //public replace:boolean = true;
            this.bindToController = {
                cbfId: '@',
                cbfLabel: '@',
                cbfModel: '=',
                cbfReadonly: '@',
                cbfStyle: '@'
            };
            this.scope = {};
        }
        DmlesCheckboxField.Factory = function () {
            var directive = function ($log) { return new DmlesCheckboxField($log); };
            directive.$inject = ['$log'];
            return directive;
        };
        return DmlesCheckboxField;
    }());
    exports.DmlesCheckboxField = DmlesCheckboxField;
});
//# sourceMappingURL=dmlesCheckboxField.directive.js.map