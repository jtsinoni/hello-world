export class DmlesCheckboxFieldController {
    private controllerName: string = "DmlesCheckboxFieldController Directive";

    // attributes from Directive
    public cbfId: string;
    public cbfLabel: string;
    public cbfModel: any;
    public cbfReadonly: string;
    public cbfStyle: string;
    
    //@inject
    constructor(public $scope, private $log, private $q, private $timeout) {
    }

    public init() {
    }
}