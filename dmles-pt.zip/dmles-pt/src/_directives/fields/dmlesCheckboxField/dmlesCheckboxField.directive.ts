import {DmlesCheckboxFieldController} from "./dmlesCheckboxField.controller";

//
// Usage:
// <dmles-checkbox-field 
//      cbf-id="ndc"
//      cbf-label="National Drug Code"
//      cbf-model="vm.record.ndc"
//      cbf-readonly="false"
//      cbf-style="margin: 0px"
// </dmles-checkbox-field>
//

export class DmlesCheckboxField implements ng.IDirective {
    public restrict:string = "EA";
    public transclude:boolean = true;
    public controller = DmlesCheckboxFieldController;
    public controllerAs:string = 'vm';
    public templateUrl:string = "./src/_directives/fields/dmlesCheckboxField/dmlesCheckboxField.template.html";
    //public replace:boolean = true;

    public bindToController:any = {
        cbfId: '@',
        cbfLabel: '@',
        cbfModel: '=',
        cbfReadonly: '@',
        cbfStyle: '@'
    };

    public scope:any = {};

    // @ngInject
    constructor(private $log) {}

    public static Factory() {
        const directive = ($log) => new DmlesCheckboxField($log);
        directive.$inject = ['$log'];
        return directive;
    }
}