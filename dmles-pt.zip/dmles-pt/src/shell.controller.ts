'use strict';

export class ShellController {
    viewName: string;

    // @ngInject
    constructor() {
        this.init();
    }

    init(){
        this.viewName = 'Shell View';
    }
}