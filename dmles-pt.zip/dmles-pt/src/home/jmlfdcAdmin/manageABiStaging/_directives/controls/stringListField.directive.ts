import {StringListFieldController} from "./stringListField.controller";

export class StringListField implements ng.IDirective {
    public restrict:string = "EA";
    public transclude:boolean = true;
    public controller = StringListFieldController;
    public controllerAs:string = 'vm';
    public templateUrl:string = "./src/home/jmlfdcAdmin/manageAbiStaging/_directives/controls/stringListField.template.html";
    //public replace:boolean = true;

    public bindToController:any = {
        slId: '@',
        slModel: '=',
        slDisabled: '=',
    };

    public scope:any = {};

    // @ngInject
    constructor(private $log) {}

    public static Factory() {
        const directive = ($log) => new StringListField($log);
        directive.$inject = ['$log'];
        return directive;
    }
}