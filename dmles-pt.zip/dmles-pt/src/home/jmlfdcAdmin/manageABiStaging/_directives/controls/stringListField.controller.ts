export class StringListFieldController {
    private controllerName: string = "StringListFieldController Directive";

    // attributes from Directive
    public slId: string;
    public slModel: any;
    public slDisabled: boolean;

    public stringListSummary: string = "0 items.";
    public showPanel: boolean = false;
    public newValueText: string = "";
    public editValueText: string = "";
    public topRowMode: string = "add";
    public valueToDelete: string = "need to fill this in";
    public selectedListItem: any = "";
    public workingList: Array < any > = [];

    //@inject
    constructor(public $scope, private $log, private $q, private $timeout) {
        this.$log.debug('%s - Start', this.controllerName);
    }

    public init() {
        this.$log.debug("Inside %s.init().", this.controllerName);

        this.$log.debug("**********************************************************************************************************");
        this.$log.debug("**********************************************************************************************************");
        this.$log.debug("**********************************************************************************************************");
        this.$log.debug("**********************************************************************************************************");
        this.$log.debug("**********************************************************************************************************");
        this.$log.debug("**********************************************************************************************************");
        this.$log.debug("**********************************************************************************************************");
        this.$log.debug("slId is " + this.slId);
        this.$log.debug("slModel is " + JSON.stringify(this.slModel, null, 3));
        this.$log.debug("slDisabled is " + this.slDisabled);
        this.$log.debug("**********************************************************************************************************");
        this.$log.debug("**********************************************************************************************************");
        this.$log.debug("**********************************************************************************************************");
        this.$log.debug("**********************************************************************************************************");
        this.$log.debug("**********************************************************************************************************");
        this.$log.debug("**********************************************************************************************************");
        this.$log.debug("**********************************************************************************************************");


        this.createWorkingList();
        this.updateStringListSummary();
    }

    public onClick() {
        this.$log.debug("Inside %s.onClick().", this.controllerName);
        this.showPanel = !this.showPanel;
    }

    public onAddButtonClicked() {
        this.$log.debug("Inside %s.onAddButtonClicked().", this.controllerName);
        if (this.topRowMode === "add") {
            this.workingList.push({
                'index': this.workingList.length + 1,
                'value': this.newValueText
            });
            this.newValueText = "";
        }
        this.refreshModel();
    }

    public onEditButtonClicked() {
        this.$log.debug("Inside %s.onEditButtonClicked().", this.controllerName);
        this.editValueText = this.workingList[this.selectedListItem].value;
        this.topRowMode = "update";
    }

    public onDeleteButtonClicked() {
        this.valueToDelete = this.workingList[this.selectedListItem].value;

        this.$log.debug("Inside %s.onDeleteButtonClicked().", this.controllerName);
        this.$log.debug("this.selectedListItem is " + this.selectedListItem);
        this.$log.debug("this.valueToDelete is " + this.valueToDelete);
        this.topRowMode = "delete";
    }

    public onUpdateButtonClicked() {
        this.$log.debug("Inside %s.onUpdateButtonClicked().", this.controllerName);
        this.workingList[this.selectedListItem].value = this.editValueText;
        this.topRowMode = "add";
        this.refreshModel();
    }

    public onCancelUpdateButtonClicked() {
        this.$log.debug("Inside %s.onCancelUpdateButtonClicked().", this.controllerName);
        this.topRowMode = "add";
    }

    public onDeleteYesButtonClicked() {
        this.$log.debug("Inside %s.onDeleteYesButtonClicked().", this.controllerName);
        this.topRowMode = "add";
        this.workingList.splice(this.selectedListItem, 1);
        this.refreshModel();
    }

    public onDeleteNoButtonClicked() {
        this.$log.debug("Inside %s.onDeleteNoButtonClicked().", this.controllerName);
        this.topRowMode = "add";
    }

    private updateStringListSummary() {
        this.$log.debug("Inside %s.updateStringListSummary().", this.controllerName);
        this.stringListSummary = this.slModel.length + " items.";
    }

    private createWorkingList() {
        this.$log.debug("Inside %s.createWorkingList().", this.controllerName);
        this.workingList = [];
        for (var i = 0; i < this.slModel.length; i++) {
            this.workingList.push({
                'index': i,
                'value': this.slModel[i]
            });
        }
    }

    private refreshModel() {
        this.$log.debug("Inside %s.refreshModel().", this.controllerName);
        this.slModel = [];
        for (var i = 0; i < this.workingList.length; i++) {
            this.workingList[i].index = i;
            this.slModel.push(this.workingList[i].value);
        }
        this.updateStringListSummary();
        // this.$scope.$apply();
    }
}