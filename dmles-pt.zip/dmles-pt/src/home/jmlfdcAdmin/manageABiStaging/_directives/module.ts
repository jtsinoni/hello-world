'use strict';
import {StringListFieldController} from './controls/stringListField.controller';
import {StringListField} from './controls/stringListField.directive';

var directivesModule = angular.module('Dmles.Home.JmlfdcAdmin.ManageAbiStaging.Directives.Module', []);

directivesModule.controller('StringListFieldController', StringListFieldController);
directivesModule.directive('stringListField', StringListField.Factory());

export default directivesModule;
