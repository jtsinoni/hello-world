'use strict';

//import router from './router';
//import {ShellController} from '../shell.controller';

// modules
import modelsModule from './_models/module';
import recordsModule from './records/module';
import requestsModule from './requests/module';

var module = angular.module('Dmles.Equipment.Module', [
    modelsModule.name,
    recordsModule.name,
    requestsModule.name
]);

//module.controller('Dmles.Home.Equipment.ShellController', ShellController);
//module.config(router.factory);

export default module;