export class EquipmentShellController {
    viewName: string;

    // @ngInject
    constructor() {
        this.init();
    }

    init(){
        this.viewName = 'Shell View';
    }
}