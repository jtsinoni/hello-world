'use strict';

import {CorporateAddress} from '../../../_models/corporateAddress.model';

export class Manufacturer {
    public name:string;
    public corporateAddress:CorporateAddress = new CorporateAddress();

    constructor();
    constructor(obj:Manufacturer);
    constructor(obj?:any) {
        this.name = obj && obj.name || "";
        this.corporateAddress = obj && obj.corporateAddress || new CorporateAddress();
    };
}