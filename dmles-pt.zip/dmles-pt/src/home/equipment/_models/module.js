define(["require", "exports", './manufacturer.model'], function (require, exports, manufacturer_model_1) {
    'use strict';
    var modelsModule = angular.module('Dmles.Home.Equipment.Models.Module', []);
    modelsModule.value('Manufacturer', manufacturer_model_1.Manufacturer);
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = modelsModule;
});
//# sourceMappingURL=module.js.map