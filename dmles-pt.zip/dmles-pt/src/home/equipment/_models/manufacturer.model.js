define(["require", "exports", '../../../_models/corporateAddress.model'], function (require, exports, corporateAddress_model_1) {
    'use strict';
    var Manufacturer = (function () {
        function Manufacturer(obj) {
            this.corporateAddress = new corporateAddress_model_1.CorporateAddress();
            this.name = obj && obj.name || "";
            this.corporateAddress = obj && obj.corporateAddress || new corporateAddress_model_1.CorporateAddress();
        }
        ;
        return Manufacturer;
    }());
    exports.Manufacturer = Manufacturer;
});
//# sourceMappingURL=manufacturer.model.js.map