'use strict';

import {Manufacturer} from './manufacturer.model';

var modelsModule = angular.module('Dmles.Home.Equipment.Models.Module', []);
modelsModule.value('Manufacturer', Manufacturer);

export default modelsModule;