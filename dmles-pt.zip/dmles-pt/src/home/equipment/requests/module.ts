'use strict';

 import router from './router';
 import {RequestsShellController} from './requestsShell.controller';

// modules
import constantModule from './_constants/module';
import modelsModule from './_models/module';
import servicesModule from './_services/module';
import controllersModule from './_views/module';
import directivesModule from './_directives/module';
import viewRequestsModule from './viewRequests/module';
import workflowManagementModule from './workflowManagement/module';

var module = angular.module('Dmles.Home.Equipment.Requests.Module', [
	constantModule.name,
	modelsModule.name,
	servicesModule.name,
	controllersModule.name,
	directivesModule.name,
	viewRequestsModule.name,
	workflowManagementModule.name,
]);

 module.controller('RequestsShellController', RequestsShellController);
 module.config(router.factory);

export default module;