'use strict';

export class RequestsShellController {
    viewName: string;

    // @ngInject
    constructor() {
        this.init();
    }

    init(){
        this.viewName = 'Shell View';
    }
}