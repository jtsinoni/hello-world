'use strict';

export class Software {
    public title:string;
    public type:string;
    public version:string;

    constructor();
    constructor(obj:Software);
    constructor(obj?:any) {
        this.title = obj && obj.title || "";
        this.type = obj && obj.type || "";
        this.version = obj && obj.version || "";
    };
}