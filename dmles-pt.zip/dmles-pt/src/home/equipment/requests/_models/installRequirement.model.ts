'use strict';

export class InstallRequirement {
    public description:string;
    public cost:number;
    public includedCost:boolean;

    constructor();
    constructor(obj:InstallRequirement);
    constructor(obj?:any) {
        this.description = obj && obj.description || "";
        this.cost = obj && obj.cost || 0;
        this.includedCost = obj && obj.includedCost || false;
    };
}