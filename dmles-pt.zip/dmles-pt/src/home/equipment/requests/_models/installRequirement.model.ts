'use strict';

export class InstallRequirement {
    public description:string;
    public cost:number;

    constructor();
    constructor(obj:InstallRequirement);
    constructor(obj?:any) {
        this.description = obj && obj.description || "";
        this.cost = obj && obj.cost || 0;
    };
}