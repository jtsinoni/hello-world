import {Submitter} from "./submitter.model";
import {EquipmentRequirement} from "./equipmentRequirement.model";
import {CatalogItem} from "../../../catalog/_models/catalogItem.model";
import {Customer} from "../../../../_models/customer.model";
import {ExtraItem} from "./extraItem.model";
import {Manufacturer} from "../../_models/manufacturer.model";
import {Person} from '../../../../_models/person.model';
import {Organization} from "../../../../_models/organization.model";
import {ReplacementItem} from "./replacementItem.model";
import {RequestedEquipment} from "./requestedEquipment.model";
import {RequestReason} from "./requestReason.model";
import {RequestStatus} from "./requestStatus.model";
import {RequestType} from "./requestType.model";
import {SuggestedSourceItem} from "./suggestedSourceItem.model";
import {TrainingItem} from "./trainingItem.model";

export class RequestInformation {
    public criticalCode:string;
    public customer:Customer;
    public description:string;
    public equipment:RequestedEquipment;
    public equipmentRequirements:Array<EquipmentRequirement> =[];
    public extraItems:Array<ExtraItem> = [];
    public missionImpact:string;
    public missionImpactDoc:string;
    public organization:Organization;
    public quantityRequested:number;
    public replacedItems:Array<ReplacementItem>;
    public requestedDeliveryDate:Date;
    public requestedDeliveryDateReason:string;
    public requestor:Person;
    public requestNumber:string;
    public requestReason:RequestReason;
    public requestTitle:string;
    public requestType:RequestType;
    public submitter:Submitter;
    public suggestedSources:Array<SuggestedSourceItem> = [];
    public totalCompAccSupplies:number;
    public totalIncludedTrainingCost:number;
    public totalTDYCost:number;

    public training:Array<TrainingItem> = [];

    constructor();
    constructor(obj:RequestInformation);
    constructor(obj?:any) {
        this.criticalCode = obj && obj.criticalCode || "";
        this.submitter = obj && obj.submitter || new Submitter();
        this.customer = obj && obj.customer || null;
        this.description = obj && obj.description || "";
        this.equipment = obj && obj.equipment || new RequestedEquipment();
        this.equipmentRequirements = obj && obj.equipmentRequirements || [];
        this.extraItems = obj && obj.extraItems || [];
        this.missionImpact = obj && obj.missionImpact || "";
        this.missionImpactDoc = obj && obj.missionImpactDoc || "";
        this.organization = obj && obj.organization || null;
        this.quantityRequested = obj && obj.quantityRequested || null;
        this.replacedItems = obj && obj.replacedItems || [];
        this.requestedDeliveryDate = obj && obj.requestedDeliveryDate || null;
        this.requestedDeliveryDateReason = obj && obj.requestedDeliveryDateReason || "";
        this.requestor = obj && obj.requestor || new Person();
        this.requestNumber = obj && obj.requestNumber || "";
        this.requestReason = obj && obj.requestReason || null;
        this.requestTitle = obj && obj.requestTitle || "";
        this.requestType = obj && obj.requestType || null;
        this.suggestedSources = obj && obj.suggestedSources || [];
        this.totalCompAccSupplies = obj && obj.totalCompAccSupplies || 0;
        this.totalIncludedTrainingCost = obj && obj.totalIncludedTrainingCost || 0;
        this.totalTDYCost = obj && obj.totalTDYCost || 0;
        this.training = obj && obj.training || [];
    }

}