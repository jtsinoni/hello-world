'use strict';

export class RequestedEquipment {
    public catalogId:string;
    public description:string;
    public isFoundInCatalog:boolean;
    public manufacturer:string;
    public model:string;
    public deviceCode: string;
    public deviceName:string;
    public otherSystemRequired:string;
    public unitCost:number;

    constructor();
    constructor(obj:RequestedEquipment);
    constructor(obj?:any) {
        this.catalogId = obj && obj.catalogId || "";
        this.description = obj && obj.description || "";
        this.isFoundInCatalog = obj && obj.isFoundInCatalog || false;
        this.manufacturer = obj && obj.manufacturer || "";
        this.model = obj && obj.model || "";
        this.deviceCode = obj && obj.deviceCode || "";
        this.deviceName = obj && obj.deviceName || "";
        this.otherSystemRequired = obj && obj.otherSystemRequired || "";
        this.unitCost = obj && obj.unitCost || null;
    }

}