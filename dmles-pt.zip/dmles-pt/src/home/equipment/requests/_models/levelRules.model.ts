'use strict';
export class LevelRules {

    public allowAutoApproveAfterReview: boolean;
    public allowCancel: boolean;
    public allowForceUp: boolean;
    public allowHold: boolean;
    public allowModify: boolean;
    public allowNoteConcern: boolean
    public allowOwnerOverrideNegativeReviews: boolean;
    public allowReject: boolean
    public allowRequestCancel: boolean;
    public allowRetract: boolean;
    public allowRework: boolean;
    public allowReviewBypassOnApprove: boolean;
    public allowReviewSelection: boolean;

    constructor();
    constructor(obj:LevelRules);
    constructor(obj?:any) {
        this.allowAutoApproveAfterReview = obj && obj.allowAutoApproveAfterReview || false;
        this.allowCancel = obj && obj.allowCancel || false;
        this.allowForceUp = obj && obj.allowForceUp || false;
        this.allowHold = obj && obj.allowHold || false;
        this.allowModify = obj && obj.allowModify || false;
        this.allowNoteConcern = obj && obj.allowNoteConcern || false;
        this.allowOwnerOverrideNegativeReviews = obj && obj.allowOwnerOverrideNegativeReviews || false;
        this.allowReject = obj && obj.allowReject || false;
        this.allowRequestCancel = obj && obj.allowRequestCancel || false;
        this.allowRetract = obj && obj.allowRetract || false;
        this.allowRework = obj && obj.allowRework || false;
        this.allowReviewBypassOnApprove = obj && obj.allowReviewBypassOnApprove || false;
        this.allowReviewSelection = obj && obj.allowReviewSelection || false;
    }
}