'use strict';

export class NoteItem {
    public noteText:string;
    public section:string;
    public firstName:string;
    public lastName:string;
    public dateCreated:Date;

    constructor();
    constructor(obj:NoteItem);
    constructor(obj?:any) {
        this.noteText = obj && obj.noteText || "";
        this.section = obj && obj.section || "";
        this.firstName = obj && obj.firstName || "";
        this.lastName = obj && obj.lastName || "";
        this.dateCreated = obj && obj.dateCreated || null;
    };
}