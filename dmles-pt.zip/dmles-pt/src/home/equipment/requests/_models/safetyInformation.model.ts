'use strict';

export class SafetyInformation {

    public environmentalConcerns:Array<any>;
    public safetyConcerns:Array<any>;


    constructor();
    constructor(obj:SafetyInformation);
    constructor(obj?:any) {
        this.environmentalConcerns = obj && obj.environmentalConcerns ||
            [{
                name: "Hazardous Materials",
                generates: false,
                uses: false,
                comments: "",
                na: false
            },
                {
                    name: "Radiation",
                    generates: false,
                    uses: false,
                    comments: "",
                    na: false
                },
                {
                    name: "Radioactive Materials",
                    generates: false,
                    uses: false,
                    comments: "",
                    na: false
                }];
        this.safetyConcerns = obj && obj.safetyConcerns ||
            [{
                name: "Eyewash Station required?",
                required: null,
                na: false,
                comments: ""
            },
                {
                    name: "Does Item meet Ergonomic Requirements?",
                    required: null,
                    na: false,
                    comments: ""
                },
                {
                    name: "Does Item meet Safety Regulations?",
                    required: null,
                    na: false,
                    comments: ""
                },
                {
                    name: "Does Item meet Infection Control Guidelines?",
                    required: null,
                    na: false,
                    comments: ""
                },
                {
                    name: "Other",
                    required: null,
                    na: false,
                    comments: ""
                }];
    }
}
