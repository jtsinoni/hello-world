'use strict';

import {InstallRequirement} from "./installRequirement.model";
import {Literature} from "./literature.model";

export class MaintenanceInformation {

    public acceptanceInspection:string;
    public estimatedAnnualServiceCost:number;
    public installationRequired:string;
    public installationRequirements:Array<InstallRequirement> = [];
    public literature:Array<Literature>;
    public maintenanceActivity:string;
    public maintenanceByOrg:boolean;
    public maintenanceByService:boolean;
    public maintenanceByOGA:boolean;
    public maintenanceExplanation:string;
    public tmdeRequired:string;
    public totalInstallationCosts:number;
    public totalLiteratureCosts:number;

    constructor();
    constructor(obj:MaintenanceInformation);
    constructor(obj?:any) {
        this.acceptanceInspection = obj && obj.acceptanceInspection || "";
        this.estimatedAnnualServiceCost = obj && obj.estimatedAnnualServiceCost || 0;
        this.installationRequired = obj && obj.installationRequired || "";
        this.installationRequirements = obj && obj.installationRequirements || [];
        this.literature = obj && obj.literature || [];
        this.maintenanceActivity = obj && obj.maintenanceActivity || "";
        this.maintenanceByOrg = obj && obj.maintenanceByOrg || false;
        this.maintenanceByService = obj && obj.maintenanceByService || false;
        this.maintenanceByOGA = obj && obj.maintenanceByOGA || false;
        this.maintenanceExplanation = obj && obj.maintenanceExplanation || "";
        this.tmdeRequired = obj && obj.tmdeRequired || "";
        this.totalInstallationCosts = obj && obj.totalInstallationCosts || 0;
        this.totalLiteratureCosts = obj && obj.totalLiteratureCosts || 0;
    }

}