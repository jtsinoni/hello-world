define(["require", "exports"], function (require, exports) {
    "use strict";
    var ExtraItem = (function () {
        function ExtraItem(obj) {
            this.type = obj && obj.type || "";
            this.itemDescription = obj && obj.itemDescription || "";
            this.catalogNumber = obj && obj.catalogNumber || "";
            this.quantity = obj && obj.quantity || 1;
            this.unitOfPurchase = obj && obj.unitOfPurchase || "Each";
            this.unitCost = obj && obj.unitCost || 0;
        }
        ;
        return ExtraItem;
    }());
    exports.ExtraItem = ExtraItem;
});
//# sourceMappingURL=extraItem.model.js.map