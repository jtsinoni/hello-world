export class TrainingItem {
    public trainees:string;
    public people:number;
    public location:string;
    public registrationCost:number;
    public travelCost:number;
    public perDiem:number;
    public days:number;
    public total:number;
    public comments:string;

    constructor();
    constructor(obj:TrainingItem);
    constructor(obj?:any) {
        this.trainees = obj && obj.trainees || "";
        this.people = obj && obj.people || 0;
        this.location = obj && obj.location || "";
        this.registrationCost = obj && obj.registrationCost || 0;
        this.travelCost = obj && obj.travelCost || 0;
        this.perDiem = obj && obj.perDiem || 0;
        this.days = obj && obj.days || 0;
        this.total = obj && obj.total || 0;
        this.comments = obj && obj.comments || "";
    };
}