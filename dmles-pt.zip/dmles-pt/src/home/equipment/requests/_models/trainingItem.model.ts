export class TrainingItem {
    public comments:string;
    public days:number;
    public includedCost:boolean;
    public location:string;
    public people:number;
    public perDiem:number;
    public registrationCost:number;
    public total:number;
    public trainees:string;
    public travelCost:number;

    constructor();
    constructor(obj:TrainingItem);
    constructor(obj?:any) {
        this.includedCost = obj && obj.includedCost || false;
        this.trainees = obj && obj.trainees || "";
        this.people = obj && obj.people || null;
        this.location = obj && obj.location || "";
        this.registrationCost = obj && obj.registrationCost || 0;
        this.travelCost = obj && obj.travelCost || 0;
        this.perDiem = obj && obj.perDiem || 0;
        this.days = obj && obj.days || 0;
        this.total = obj && obj.total || 0;
        this.comments = obj && obj.comments || "";
    };
}