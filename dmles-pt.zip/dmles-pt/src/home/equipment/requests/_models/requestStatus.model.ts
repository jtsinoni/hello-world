'use strict';

export class RequestStatus {
    public state:string;
    public notes:string;
    public updateDate:Date;

    constructor();
    constructor(obj:RequestStatus);
    constructor(obj?:any) {
        this.state = obj && obj.state || "";
        this.notes = obj && obj.notes || "";
        this.updateDate = obj && obj.updateDate || null;
    };
}