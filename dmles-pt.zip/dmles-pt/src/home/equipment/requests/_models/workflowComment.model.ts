'use strict';

export class WorkflowComment {
    public id:string;
    public comment:string;
    public created: Date;
    public levelName:string;
    public firstName:string;
    public lastName:string;

    constructor();
    constructor(obj:WorkflowComment);
    constructor(obj?:any) {
        this.id = obj && obj.id || "";
        this.comment = obj && obj.comment || "";
        this.created = obj && obj.created || null;
        this.levelName =obj && obj.levelName || "";
        this.firstName = obj && obj.firstName || "";
        this.lastName = obj && obj.lastName || "";
    };

}
