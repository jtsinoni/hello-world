export class ExtraItem {
    public type:string;
    public itemDescription:string;
    public catalogNumber:string;
    public quantity:number;
    public unitOfPurchase:string;
    public unitCost:number;

    constructor();
    constructor(obj:ExtraItem);
    constructor(obj?:any) {
        this.type = obj && obj.type || "";
        this.itemDescription = obj && obj.itemDescription || "";
        this.catalogNumber = obj && obj.catalogNumber || "";
        this.quantity = obj && obj.quantity || null;
        this.unitOfPurchase = obj && obj.unitOfPurchase || "Each";
        this.unitCost = obj && obj.unitCost || null;
    };
}