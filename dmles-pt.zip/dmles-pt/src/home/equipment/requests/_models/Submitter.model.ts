'use strict';

export class Submitter {

    public email:string;
    public userId:string;
    public nameFirst:string;
    public nameLast:string;
    public phoneNumber:string;
    public dodaac:string;
    public serviceCode:string;
    public regionCode:string;

    constructor();
    constructor(obj:Submitter);
    constructor(obj?:any) {
        this.email = obj && obj.email || "";
        this.userId = obj && obj.userId || "";
        this.nameFirst = obj && obj.nameFirst || "";
        this.nameLast = obj && obj.nameLast || "";
        this.phoneNumber = obj && obj.phoneNumber || "";
        this.dodaac = obj && obj.dodaac || "";
        this.serviceCode = obj && obj.serviceCode || "";
        this.regionCode = obj && obj.regionCode || "";
    };
}