'use strict';
import {Review} from "./review.model";

export class WorkflowLevelProcessing {
    public id:any;

    public autoApproveAfterReviews:Boolean;
    public levelId:number;
    public levelName:string;
    public status:string;
    public reviews:Array<Review>;

    constructor();
    constructor(obj:WorkflowLevelProcessing);
    constructor(obj?:any) {
        this.id = obj && obj.id || "";
        this.autoApproveAfterReviews = obj && obj.autoApproveAfterReviews || false;
        this.levelId = obj && obj.id || null;
        this.levelName = obj && obj.id || "";
        this.status = obj && obj.id || "";
        this.reviews = obj && obj.id || [];
    }
}