'use strict';
import {WeighIn} from "./weighIn.model";

export class WorkflowLevelProcessing {
    public id:any;

    public autoApproveAfterWeighins:Boolean;
    public levelId:number;
    public levelName:string;
    public status:string;
    public weighIns:Array<WeighIn>;

    constructor();
    constructor(obj:WorkflowLevelProcessing);
    constructor(obj?:any) {
        this.id = obj && obj.id || "";
        this.autoApproveAfterWeighins = obj && obj.autoApproveAfterWeighins || false;
        this.levelId = obj && obj.id || null;
        this.levelName = obj && obj.id || "";
        this.status = obj && obj.id || "";
        this.weighIns = obj && obj.id || [];
    }
}