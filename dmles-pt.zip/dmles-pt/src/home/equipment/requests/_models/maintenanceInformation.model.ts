'use strict';

import {InstallRequirement} from "./installRequirement.model";
import {Literature} from "./literature.model";

export class MaintenanceInformation {

    public acceptanceInspection:boolean;
    public estimatedAnnualServiceCost:number;
    public installationRequired:string;
    public installationRequirements:Array<InstallRequirement> = [];
    public literature:Array<Literature>;
    public maintenanceActivity:string;
    public maintenanceProvidedBy:string;
    public maintenanceExplanation:string;
    public tmdeRequired:string;
    public totalIncludedInstallationCosts:number;
    public totalOtherInstallationCosts:number;
    public totalLiteratureCosts:number;

    constructor();
    constructor(obj:MaintenanceInformation);
    constructor(obj?:any) {
        this.acceptanceInspection = obj && obj.acceptanceInspection || null;
        this.estimatedAnnualServiceCost = obj && obj.estimatedAnnualServiceCost || null;
        this.installationRequired = obj && obj.installationRequired || "";
        this.installationRequirements = obj && obj.installationRequirements || [];
        this.literature = obj && obj.literature || [];
        this.maintenanceActivity = obj && obj.maintenanceActivity || "";
        this.maintenanceProvidedBy = obj && obj.maintenanceProvidedBy || "";
        this.maintenanceExplanation = obj && obj.maintenanceExplanation || "";
        this.tmdeRequired = obj && obj.tmdeRequired || "";
        this.totalIncludedInstallationCosts = obj && obj.totalIncludedInstallationCosts || 0;
        this.totalOtherInstallationCosts = obj && obj.totalOtherInstallationCosts || 0;
        this.totalLiteratureCosts = obj && obj.totalLiteratureCosts || 0;
    }

}