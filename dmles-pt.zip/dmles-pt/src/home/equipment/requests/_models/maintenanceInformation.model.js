define(["require", "exports"], function (require, exports) {
    'use strict';
    var MaintenanceInformation = (function () {
        function MaintenanceInformation(obj) {
            this.installationRequirements = [];
            this.acceptanceInspection = obj && obj.acceptanceInspection || false;
            this.estimatedAnnualServiceCost = obj && obj.estimatedAnnualServiceCost || null;
            this.installationRequired = obj && obj.installationRequired || "";
            this.installationRequirements = obj && obj.installationRequirements || [];
            this.literature = obj && obj.literature || [];
            this.maintenanceActivity = obj && obj.maintenanceActivity || "";
            this.maintenanceProvidedBy = obj && obj.maintenanceProvidedBy || "";
            this.maintenanceExplanation = obj && obj.maintenanceExplanation || "";
            this.tmdeRequired = obj && obj.tmdeRequired || "";
            this.totalInstallationCosts = obj && obj.totalInstallationCosts || 0;
            this.totalLiteratureCosts = obj && obj.totalLiteratureCosts || 0;
        }
        return MaintenanceInformation;
    }());
    exports.MaintenanceInformation = MaintenanceInformation;
});
//# sourceMappingURL=maintenanceInformation.model.js.map