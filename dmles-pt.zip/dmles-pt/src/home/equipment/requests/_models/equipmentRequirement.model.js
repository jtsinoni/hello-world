define(["require", "exports"], function (require, exports) {
    "use strict";
    var EquipmentRequirement = (function () {
        function EquipmentRequirement(obj) {
            this.category = obj && obj.category || "";
            this.requirement = obj && obj.requirement || "";
            this.specification = obj && obj.specification || "";
        }
        ;
        return EquipmentRequirement;
    }());
    exports.EquipmentRequirement = EquipmentRequirement;
});
//# sourceMappingURL=equipmentRequirement.model.js.map