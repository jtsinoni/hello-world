define(["require", "exports"], function (require, exports) {
    'use strict';
    var InstallRequirement = (function () {
        function InstallRequirement(obj) {
            this.description = obj && obj.description || "";
            this.cost = obj && obj.cost || 0;
        }
        ;
        return InstallRequirement;
    }());
    exports.InstallRequirement = InstallRequirement;
});
//# sourceMappingURL=installRequirement.model.js.map