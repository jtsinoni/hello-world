'use strict';

import {WorkFlowLevelDefinition} from "./workflowLevelDefinition.model";

export class WorkFlowDefinition {
    public id:any;
    public active:boolean;
    public dateCreated:Date;
    public dateUpdated:Date;
    public effectiveDate:Date;
    public levelDefinitions:Array<WorkFlowLevelDefinition>;
    public name:string;
    public reviewResponses:Array<String>;
    public service:string;
    public updatedBy:string;
    public version:string;

    constructor();
    constructor(obj:WorkFlowDefinition);
    constructor(obj?:any) {
        this.id = obj && obj.id || "";
        this.active = obj && obj.active || null;
        this.dateCreated = obj && obj.id || null;
        this.dateUpdated = obj && obj.id || null;
        this.effectiveDate = obj && obj.effectiveDate || null;
        this.levelDefinitions = obj && obj.id || [];
        this.name = obj && obj.id || "";
        this.reviewResponses = obj && obj.reviewResponses || [];
        this.service = obj && obj.id || "";
        this.updatedBy = obj && obj.updatedBy || "";
        this.version = obj && obj.id || "";
    }
}