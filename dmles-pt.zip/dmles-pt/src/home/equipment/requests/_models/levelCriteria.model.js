define(["require", "exports"], function (require, exports) {
    'use strict';
    var LevelCriteria = (function () {
        function LevelCriteria(obj) {
            this.totalCost = obj && obj.totalCost || null;
            this.totalCostThreshold = obj && obj.totalCostThreshold || null;
            this.deviceCostThreshold = obj && obj.deviceCostThreshold || null;
            this.catalogItems = obj && obj.catalogItems || [];
            this.devices = obj && obj.devices || [];
        }
        return LevelCriteria;
    }());
    exports.LevelCriteria = LevelCriteria;
});
//# sourceMappingURL=levelCriteria.model.js.map