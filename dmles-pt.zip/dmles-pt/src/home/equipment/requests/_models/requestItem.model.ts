import {CatalogItem} from "../../../catalog/_models/catalogItem.model";
import {FacilityInformation} from './facilityInformation.model';
import {MaintenanceInformation} from "./maintenanceInformation.model";
import {NoteItem} from "./noteItem.model";
import {RequestInformation} from "./requestInformation.model";
import {SafetyInformation} from "./safetyInformation.model";
import {TechnologyInformation} from "./technologyInformation.model";
import {WorkFlowProcessing} from "./workflowProcessing.model";

export class RequestItem {
    public id:any;
    public facilityInformation:FacilityInformation;
    public maintenanceInformation:MaintenanceInformation;
    public requestInformation:RequestInformation;
    public safetyInformation:SafetyInformation;
    public technologyInformation:TechnologyInformation;

    public attachments:Array<any> = [];
    public catalogItem:CatalogItem;
    public notes:Array<NoteItem> = [];
    public totalPrice:number;
    public wfProcessing: WorkFlowProcessing;
    public updatedBy:String;
    public updatedDate:Date;

    constructor();
    constructor(obj:RequestItem);
    constructor(obj?:any) {
        this.id = obj && obj.id || null;
        this.facilityInformation = obj && obj.facilityInformation || new FacilityInformation();
        this.maintenanceInformation = obj && obj.maintenanceInformation || new MaintenanceInformation();
        this.requestInformation = obj && obj.requestInformation || new RequestInformation();
        this.safetyInformation = obj && obj.safetyInformation || new SafetyInformation();
        this.technologyInformation = obj && obj.technologyInformation || new TechnologyInformation();

        this.attachments = obj && obj.attachments || [];
        this.catalogItem = obj && obj.catalogItem || null;
        this.notes = obj && obj.notes || [];
        this.totalPrice = obj && obj.totalPrice || null;
        this.wfProcessing = obj && obj.wfProcessing || null;
        this.updatedBy = obj && obj.updatedBy || "";
        this.updatedDate = obj && obj.updatedDate || null;
    }

}