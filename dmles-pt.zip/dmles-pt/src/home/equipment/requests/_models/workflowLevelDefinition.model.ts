import {LevelRules} from "./levelRules.model";
import {Review} from "./review.model";

export class WorkFlowLevelDefinition {
    public levelId: number;
    public name:string;
    public ownerRoleId:string;
    public userType:string;
    public rules:LevelRules;
    public levelDefinitionReviews:Review;

    constructor();
    constructor(obj:WorkFlowLevelDefinition);
    constructor(obj?:any) {
        this.levelId = obj && obj.levelId || null;
        this.name = obj && obj.name || "";
        this.ownerRoleId = obj && obj.ownerRoleId || "";
        this.userType = obj && obj.userType || "";
        this.rules = obj && obj.rules || new LevelRules();
        this.levelDefinitionReviews = obj && obj.levelDefinitionReviews || null;
    }
}