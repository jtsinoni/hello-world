import {LevelRules} from "./levelRules.model";
import {WeighIn} from "./weighIn.model";

export class WorkFlowLevelDefinition {
    public levelId: number;
    public name:string;
    public ownerRoleId:string;
    public userType:string;
    public rules:LevelRules;
    public levelDefinitionWeighIns:WeighIn;

    constructor();
    constructor(obj:WorkFlowLevelDefinition);
    constructor(obj?:any) {
        this.levelId = obj && obj.levelId || null;
        this.name = obj && obj.name || "";
        this.ownerRoleId = obj && obj.ownerRoleId || "";
        this.userType = obj && obj.userType || "";
        this.rules = obj && obj.rules || new LevelRules();
        this.levelDefinitionWeighIns = obj && obj.levelDefinitionWeighIns || null;
    }
}