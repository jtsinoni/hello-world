import {Comment} from "../../../../_models/comment.model";
import {ReviewUser} from "./reviewUser.model"

export class Review {
    public id:any;
    public comments:Array<Comment>;
    public elementName:string;
    public roleId:any;
    public selectedUserId:string;
    public reviewDisplayName:string;
    public reviewResult:string;
    public reviewStatus:string;
    public reviewUsers:Array<ReviewUser>;

    constructor();
    constructor(obj:Review);
    constructor(obj?:any) {
        this.id = obj && obj.id || "";
        this.comments = obj && obj.comments || [];
        this.elementName = obj && obj.elementName || "";
        this.roleId = obj && obj.roleId || "";
        this.reviewDisplayName = obj && obj.reviewDisplayName || "";
        this.selectedUserId = obj && obj.selectedUserId || "";
        this.reviewResult = obj && obj.reviewResult || "";
        this.reviewStatus = obj && obj.reviewStatus || "";
        this.reviewUsers = obj && obj.reviewUsers || [];
    }
}