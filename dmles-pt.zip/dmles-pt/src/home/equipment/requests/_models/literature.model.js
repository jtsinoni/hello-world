define(["require", "exports"], function (require, exports) {
    'use strict';
    var Literature = (function () {
        function Literature(obj) {
            this.type = obj && obj.type || "";
            this.cost = obj && obj.cost || null;
            this.quantity = obj && obj.quantity || 1;
            this.totalCost = obj && obj.totalCost || null;
        }
        ;
        return Literature;
    }());
    exports.Literature = Literature;
});
//# sourceMappingURL=literature.model.js.map