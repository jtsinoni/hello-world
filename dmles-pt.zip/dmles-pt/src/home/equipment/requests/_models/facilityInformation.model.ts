'use strict';

export class FacilityInformation {

    public facilityModificationCost:number;
    public facilityModifications:string;
    public utilities:Array<any>;

    constructor();
    constructor(obj:FacilityInformation);
    constructor(obj?:any) {
        this.facilityModificationCost = obj && obj.facilityModificationCost || 0;
        this.facilityModifications = obj && obj.facilityModifications || "";
        this.utilities = obj && obj.utilities ||
            [{
                name: "Electrical",
                specifications: "",
                required: false,
                available: false,
                comments: "",
                na: false
            },
            {
                name: "Water",
                specifications: "",
                required: false,
                available: false,
                comments: "",
                na: false
            },
            {
                name: "Drain",
                specifications: "",
                required: false,
                available: false,
                comments: "",
                na: false
            },
            {
                name: "Steam",
                specifications: "",
                required: false,
                available: false,
                comments: "",
                na: false
            },
            {
                name: "Gas",
                specifications: "",
                required: false,
                available: false,
                comments: "",
                na: false
            },
            {
                name: "HVAC",
                specifications: "",
                required: false,
                available: false,
                comments: "",
                na: false
            },
            {
                name: "Structural",
                specifications: "",
                required: false,
                available: false,
                comments: "",
                na: false
            },
            {
                name: "Lighting",
                specifications: "",
                required: false,
                available: false,
                comments: "",
                na: false
            },
            {
                name: "Ventilation",
                specifications: "",
                required: false,
                available: false,
                comments: "",
                na: false
            },
            {
                name: "Other",
                specifications: "",
                required: false,
                available: false,
                comments: "",
                na: false
            }];
    }

}