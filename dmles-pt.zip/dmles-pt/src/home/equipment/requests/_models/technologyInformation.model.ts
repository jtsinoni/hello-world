import {Software} from "./software.model";

export class TechnologyInformation {

    public software:Array<Software>;
    public technologyRequirements:Array<any>;

    constructor();
    constructor(obj:TechnologyInformation);
    constructor(obj?:any) {
        this.software = obj && obj.software || [];
        this.technologyRequirements = obj && obj.technologyRequirements ||
            [{
                name: "LAN/Network Connection",
                specifications: "",
                required: false,
                available: false,
                comments: "",
                na: false
            },
                {
                    name: "Communication",
                    specifications: "",
                    required: false,
                    available: false,
                    comments: "",
                    na: false
                },
                {
                    name: "IT Accreditation+",
                    specifications: "",
                    required: false,
                    available: false,
                    comments: "",
                    na: false
                },
                {
                    name: "Software Technical Support",
                    specifications: "",
                    required: false,
                    available: false,
                    comments: "",
                    na: false
                },
                {
                    name: "Hardware Technical Support",
                    specifications: "",
                    required: false,
                    available: false,
                    comments: "",
                    na: false
                },
                {
                    name: "Fiberoptic Connection",
                    specifications: "",
                    required: false,
                    available: false,
                    comments: "",
                    na: false
                },
                {
                    name: "Radio-Frequency Identification (RFID)",
                    specifications: "",
                    required: false,
                    available: false,
                    comments: "",
                    na: false
                },
                {
                    name: "Wi-Fi",
                    specifications: "",
                    required: false,
                    available: false,
                    comments: "",
                    na: false
                }];
    }

}