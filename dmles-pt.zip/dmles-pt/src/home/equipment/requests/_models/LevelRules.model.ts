'use strict';
export class LevelRules {

    public allowAutoApproveAfterWeighIn: boolean;
    public allowCancel: boolean;
    public allowForceUp: boolean;
    public allowHold: boolean;
    public allowModify: boolean;
    public allowNoteConcern: boolean
    public allowOwnerOverrideNegativeWeighIns: boolean;
    public allowReject: boolean
    public allowRequestCancel: boolean;
    public allowRetract: boolean;
    public allowRework: boolean;
    public allowWeighInBypassOnApprove: boolean;
    public allowWeighInSelection: boolean;

    constructor();
    constructor(obj:LevelRules);
    constructor(obj?:any) {
        this.allowAutoApproveAfterWeighIn = obj && obj.allowAutoApproveAfterWeighIn || false;
        this.allowCancel = obj && obj.allowCancel || false;
        this.allowForceUp = obj && obj.allowForceUp || false;
        this.allowHold = obj && obj.allowHold || false;
        this.allowModify = obj && obj.allowModify || false;
        this.allowNoteConcern = obj && obj.allowNoteConcern || false;
        this.allowOwnerOverrideNegativeWeighIns = obj && obj.allowOwnerOverrideNegativeWeighIns || false;
        this.allowReject = obj && obj.allowReject || false;
        this.allowRequestCancel = obj && obj.allowRequestCancel || false;
        this.allowRetract = obj && obj.allowRetract || false;
        this.allowRework = obj && obj.allowRework || false;
        this.allowWeighInBypassOnApprove = obj && obj.allowWeighInBypassOnApprove || false;
        this.allowWeighInSelection = obj && obj.allowWeighInSelection || false;
    }
}