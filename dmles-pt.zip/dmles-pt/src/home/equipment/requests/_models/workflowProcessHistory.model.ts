'use strict';

export class WorkFlowProcessHistory {
    public id:any;
    public when:Date;
    public level:string;
    public user:string;
    public action:string;

    constructor();
    constructor(obj:WorkFlowProcessHistory);
    constructor(obj?:any) {
        this.id = obj && obj.id || "";
        this.when = obj && obj.when || null;
        this.level = obj && obj.level || "";
        this.user = obj && obj.user || "";
        this.action = obj && obj.action || "";
    }
}