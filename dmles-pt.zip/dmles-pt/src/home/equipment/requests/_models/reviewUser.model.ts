export class ReviewUser {
    public id:any;
    public dodaac:string;
    public email:string;
    public firstName:string;
    public lastName:string;
    public pkiDn:string;
    public profileName:string;
    public regionCode:string;
    public serviceCode:string;
    public userType:string;

    constructor();
    constructor(obj:ReviewUser);
    constructor(obj?:any) {
        this.id = obj && obj.id || "";
        this.dodaac = obj && obj.dodaac || "";
        this.email = obj && obj.email || "";
        this.firstName = obj && obj.firstName || "";
        this.lastName = obj && obj.lastName || "";
        this.pkiDn = obj && obj.pkiDn || "";
        this.regionCode = obj && obj.regionCode || "";
        this.serviceCode = obj && obj.serviceCode || "";
        this.userType = obj && obj.userType || "";
    }
}