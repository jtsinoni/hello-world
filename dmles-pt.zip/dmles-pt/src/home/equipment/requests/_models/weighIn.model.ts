import {Comment} from "../../../../_models/comment.model";
import {WeighInUser} from "./weighInUser.model"

export class WeighIn {
    public id:any;
    public comments:Array<Comment>;
    public elementName:string;
    public roleId:any;
    public selectedUserId:string;
    public weighInDisplayName:string;
    public weighInResult:string;
    public weighInStatus:string;
    public weighInUsers:Array<WeighInUser>;

    constructor();
    constructor(obj:WeighIn);
    constructor(obj?:any) {
        this.id = obj && obj.id || "";
        this.comments = obj && obj.comments || [];
        this.elementName = obj && obj.elementName || "";
        this.roleId = obj && obj.roleId || "";
        this.weighInDisplayName = obj && obj.weighInDisplayName || "";
        this.selectedUserId = obj && obj.selectedUserId || "";
        this.weighInResult = obj && obj.weighInResult || "";
        this.weighInStatus = obj && obj.weighInStatus || "";
        this.weighInUsers = obj && obj.weighInUsers || [];
    }
}