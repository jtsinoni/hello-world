import {WorkflowComment} from "./workflowComment.model";
import {WorkFlowDefinition} from "./workflowDefinition.model";
import {WorkflowLevelStatus} from "./workflowLevelStatus.model";
import {WorkflowLevelProcessing} from "./workflowLevelProcessing.model";
import {WorkFlowProcessHistory} from "./workflowProcessHistory.model";

export class WorkFlowProcessing {
    public id:any;
    public comments:Array<WorkflowComment>;
    public currentLevelId:number;
    public currentStatus:string;
    public currentOwnerRole:string;
    public isCompleted:boolean;
    public history:Array<WorkFlowProcessHistory>;
    public requestId:string;
    public wfDefinition:WorkFlowDefinition;
    public levels:Array<WorkflowLevelProcessing>;

    constructor();
    constructor(obj:WorkFlowProcessing);
    constructor(obj?:any) {
        this.id = obj && obj.id || "";
        this.isCompleted = obj && obj.isCompleted || false;
        this.comments = obj && obj.comments || [];
        this.currentLevelId = obj && obj.currentLevelId || null;
        this.currentStatus = obj && obj.currentStatus || "";
        this.currentOwnerRole = obj && obj.currentOwnerRole || "";
        this.history = obj && obj.history || [];
        this.requestId = obj && obj.requestId || "";
        this.wfDefinition = obj && obj.wfDefinition || null;
        this.levels = obj && obj.levels || [];

    }
}