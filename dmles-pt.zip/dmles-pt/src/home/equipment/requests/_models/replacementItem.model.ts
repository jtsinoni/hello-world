export class ReplacementItem {
    public ecn:string;
    public name:string;
    public acquisitionDate:Date;
    public lifeExpectancy:string;
    public condition:string;
    public disposal:string;
    public comment:string;

    constructor();
    constructor(obj:ReplacementItem);
    constructor(obj?:any) {
        this.ecn = obj && obj.ecn || "";
        this.name = obj && obj.name || "";
        this.acquisitionDate = obj && obj.acquisitionDate || null;
        this.lifeExpectancy = obj && obj.lifeExpectancy || "";
        this.condition = obj && obj.condition || "";
        this.disposal = obj && obj.disposal || "";
        this.comment = obj && obj.comment || "";
    };
}