'use strict';

export class NoteItem {
    public noteText:string;
    public section:string;
    public enteredBy:string;
    public dateCreated:Date;

    constructor();
    constructor(obj:NoteItem);
    constructor(obj?:any) {
        this.noteText = obj && obj.noteText || "";
        this.section = obj && obj.section || "";
        this.enteredBy = obj && obj.enteredBy || "";
        this.dateCreated = obj && obj.dateCreated || null;
    };
}