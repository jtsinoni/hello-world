'use strict;'

export class RequestType {
    public code:string;
    public name:string;

    constructor();
    constructor(obj:RequestType);
    constructor(obj?:any) {
        this.code = obj && obj.code || "";
        this.name = obj && obj.name || "";
    };
}