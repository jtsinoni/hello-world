'use strict';
export class LevelCriteria {

    public totalCost: number;
    public totalCostThreshold: number;
    public deviceCostThreshold: boolean;
    public catalogItems: Array<any>;
    public devices: Array<any>;

    constructor();
    constructor(obj:LevelCriteria);
    constructor(obj?:any) {
        this.totalCost = obj && obj.totalCost || null;
        this.totalCostThreshold = obj && obj.totalCostThreshold || null;
        this.deviceCostThreshold = obj && obj.deviceCostThreshold || null;
        this.catalogItems = obj && obj.catalogItems || [];
        this.devices = obj && obj.devices || [];
    }
}