export class EquipmentRequirement {
    public category:string;
    public requirement:string;
    public specification:string;

    constructor();
    constructor(obj:EquipmentRequirement);
    constructor(obj?:any) {
        this.category = obj && obj.category || "";
        this.requirement = obj && obj.requirement || "";
        this.specification = obj && obj.specification || "";
    };
}