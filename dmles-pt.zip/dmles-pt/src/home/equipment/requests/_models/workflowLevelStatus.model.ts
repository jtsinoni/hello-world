'use strict';

export class WorkflowLevelStatus {

    static NEW:string = "New";
    static ACTIVE:string = "Active";
    static APPROVED:string = "Approved";
    static CANCELLED:string = "Cancelled";
    static COMPLETED:string = "Completed";
    static FORCEDUP:string = "ForcedUp";
    static HOLD:string = "Hold";
    static REJECTED:string = "Rejected";
    static REWORK:string = "Rework";
    static RETRACT:string = "Retracted"
    static SKIPPED:string = "Skipped";

    private name:string;

    constructor();
    constructor(obj:WorkflowLevelStatus);
    constructor(obj?:any) {
        this.name = obj && obj.name || null;
    }
}