'use strict;'

export class RequestReason {
    public name:string;
    public code:string;
    public mask:string;

    constructor();
    constructor(obj:RequestReason);
    constructor(obj?:any) {
        this.name = obj && obj.name || "";
        this.code = obj && obj.code || "";
        this.mask = obj && obj.mask || "";
    };
}