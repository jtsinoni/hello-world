'use strict';

export class Literature {
    public type:string;
    public cost:number;
    public quantity:number;
    public totalCost:number;

    constructor();
    constructor(obj:Literature);
    constructor(obj?:any) {
        this.type = obj && obj.type || "";
        this.cost = obj && obj.cost || null;
        this.quantity = obj && obj.quantity || 1;
        this.totalCost = obj && obj.totalCost || null;
    };
}