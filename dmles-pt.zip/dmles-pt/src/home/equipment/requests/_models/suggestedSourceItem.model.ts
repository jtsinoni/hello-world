'use strict';

export class SuggestedSourceItem {
    public sourceName:string;
    public sourceDivision:string;
    public contract:string;
    public contractExpDate:Date;
    public creditCard: boolean;
    public pocEmail:string;
    public pocName:string;
    public pocPhone1:string;
    public pocPhone2:string;
    public pocTitle: string;
    public primarySource: boolean;
    public soleSource: boolean;
    public supplierCatalogDate:Date;
    public supplierCatalogNumber:string;
    public supplierCatalogReference:string;
    public supplierAddress1:string;
    public supplierAddress2:string;
    public supplierCity:string;
    public supplierState:string;
    public supplierZip:string;
    public supplierCountry:string;
    public url:string;
    
    constructor();
    constructor(obj:SuggestedSourceItem);
    constructor(obj?:any) {
        this.sourceName = obj && obj.sourceName || null;
        this.sourceDivision = obj && obj.sourceDivision || null;
        this.contract = obj && obj.contract || "";
        this.contractExpDate =  obj && obj.contractExpDate || null;
        this.pocEmail = obj && obj.pocEmail || "";
        this.pocName = obj && obj.pocName || null;
        this.pocPhone1 = obj && obj.pocPhone1 || "";
        this.pocPhone2 = obj && obj.pocPhone2 || "";
        this.pocTitle = obj && obj.pocTitle || "";
        this.creditCard = obj && obj.creditCard || null;
        this.primarySource = obj && obj.primarySource || false;
        this.soleSource = obj && obj.soleSource || null;
        this.soleSource = obj && obj.soleSource || null;
        this.supplierCatalogDate = obj && obj.supplierCatalogDate || null;
        this.supplierCatalogNumber = obj && obj.supplierCatalogNumber || "";
        this.supplierCatalogReference = obj && obj.supplierCatalogReference || "";
        this.supplierAddress1 = obj && obj.supplierAddress1 || "";
        this.supplierAddress2 = obj && obj.supplierAddress2 || "";
        this.supplierCity = obj && obj.supplierCity || "";
        this.supplierState = obj && obj.supplierState || "";
        this.supplierZip = obj && obj.supplierZip || "";
        this.supplierCountry = obj && obj.supplierCountry || "";
        this.url = obj && obj.url || "";
    };
}