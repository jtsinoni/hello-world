'use strict';

import {NotificationMessages} from './notificationMessages.constant';
import {WeighInResult} from './weighInResult.constant';
import {WeighInStatus} from './weighInStatus.constant';
import {WorkflowCompletionStatus} from './workflowCompletionStatus.constant';

var constantModule = angular.module('Dmles.Equipment.Requests.Constants.Module', []);
constantModule.constant('NotificationMessages', NotificationMessages);
constantModule.constant('WeighInResult', WeighInResult);
constantModule.constant('WeighInStatus', WeighInStatus);
constantModule.constant('WorkflowCompletionStatus', WorkflowCompletionStatus);

export default constantModule;