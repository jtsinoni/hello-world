'use strict';

import {NotificationMessages} from './notificationMessages.constant';
import {ReviewResult} from './reviewResult.constant';
import {ReviewStatus} from './reviewStatus.constant';
import {WorkflowCompletionStatus} from './workflowCompletionStatus.constant';

var constantModule = angular.module('Dmles.Equipment.Requests.Constants.Module', []);
constantModule.constant('NotificationMessages', NotificationMessages);
constantModule.constant('ReviewResult', ReviewResult);
constantModule.constant('ReviewStatus', ReviewStatus);
constantModule.constant('WorkflowCompletionStatus', WorkflowCompletionStatus);

export default constantModule;