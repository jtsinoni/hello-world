'use strict';

export class WeighInResult {

    static APPROVE:string = "Approve";
    static RECOMMEND_APPROVE:string = "Recommend Approve";
    static NEUTRAL:string = "Not Applicable";
    static RECOMMEND_REJECT:string = "Recommend Reject";
    static REJECT:string = "Reject";
    static NOTE_CONCERN:string = "Note Concern";

    constructor(){}
}