'use strict';

export class WeighInResult {

    static APPROVE:string = "Approve";
    static RECOMMEND_APPROVE:string = "Recommend Approve";
    static NEUTRAL:string = "Neutral";
    static RECOMMEND_REJECT:string = "Recommend Reject";
    static REJECT:string = "Reject";

    constructor(){}
}