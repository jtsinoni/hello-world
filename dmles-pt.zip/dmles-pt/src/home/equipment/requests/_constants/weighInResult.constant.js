define(["require", "exports"], function (require, exports) {
    'use strict';
    var WeighInResult = (function () {
        function WeighInResult() {
        }
        WeighInResult.APPROVE = "Approve";
        WeighInResult.RECOMMEND_APPROVE = "Recommend Approve";
        WeighInResult.NEUTRAL = "Not Applicable";
        WeighInResult.RECOMMEND_REJECT = "Recommend Reject";
        WeighInResult.REJECT = "Reject";
        WeighInResult.NOTE_CONCERN = "Note Concern";
        return WeighInResult;
    }());
    exports.WeighInResult = WeighInResult;
});
//# sourceMappingURL=weighInResult.constant.js.map