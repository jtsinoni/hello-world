'use strict';

export class NotificationMessages {

    static REQUEST_INSUFFICIENT_DATA:string = 'Your request is missing required data. Check all the fields and try again.';
    static REQUEST_SAVE_SUCCESS:string = "Request saved.";
    static REQUEST_SUBMIT_ERROR:string = "There was an error submitting your request. Please try again later. If this error persists, contact the system admin."
    static REQUEST_SUBMIT_SUCCESS:string = "Request has been submitted. Now pending approval.";
    static REQUEST_SUBMITED_APPROVE_SUCCESS:string = "Request has been approved.";
    static REQUEST_SUBMITED_FORCEUP_SUCCESS:string = "Request has been pushed up for further approval.";
    static REQUEST_SUBMITED_REJECT_SUCCESS:string = "Request has been rejected.";
    static REQUEST_SUBMITED_CANCEL_SUCCESS:string = "Request has been canceled.";
    static REQUEST_SUBMITED_HOLD_SUCCESS:string = "Request has been put on hold.";
    static REQUEST_SUBMITED_RETRACT_SUCCESS:string = "Request has been pulled back to yur level for modification.";
    static REQUEST_SUBMITED_REWORK_SUCCESS:string = "Request has been sent back for rework.";
    static REQUEST_SUBMITED_RESUME_SUCCESS:string = "Request review has been resumed.";
    static REQUEST_WEIGHIN_SUCCESS:string = "Action completed."
    static REQUEST_WEIGHIN_COMMENT_ADDED:string = "Comment was added."
    constructor(){}
}