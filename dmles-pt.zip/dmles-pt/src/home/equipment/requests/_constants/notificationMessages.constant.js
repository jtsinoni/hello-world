define(["require", "exports"], function (require, exports) {
    'use strict';
    var NotificationMessages = (function () {
        function NotificationMessages() {
        }
        NotificationMessages.REQUEST_INSUFFICIENT_DATA = 'Your request is missing required data. Check all the fields and try again.';
        NotificationMessages.REQUEST_SAVE_SUCCESS = "Request saved.";
        NotificationMessages.REQUEST_SUBMIT_ERROR = "There was an error submitting your request. Please try again later. If this error persists, contact the system admin.";
        NotificationMessages.REQUEST_SUBMIT_SUCCESS = "Request has been submitted. Now pending approval.";
        NotificationMessages.REQUEST_SUBMITED_APPROVE_SUCCESS = "Request has been approved.";
        NotificationMessages.REQUEST_SUBMITED_FORCEUP_SUCCESS = "Request has been pushed up for further approval.";
        NotificationMessages.REQUEST_SUBMITED_REJECT_SUCCESS = "Request has been rejected.";
        NotificationMessages.REQUEST_SUBMITED_CANCEL_SUCCESS = "Request has been canceled.";
        NotificationMessages.REQUEST_SUBMITED_HOLD_SUCCESS = "Request has been put on hold.";
        NotificationMessages.REQUEST_SUBMITED_RETRACT_SUCCESS = "Request has been pulled back to yur level for modification.";
        NotificationMessages.REQUEST_SUBMITED_REWORK_SUCCESS = "Request has been sent back for rework.";
        NotificationMessages.REQUEST_SUBMITED_RESUME_SUCCESS = "Request review has been resumed.";
        NotificationMessages.REQUEST_WEIGHIN_SUCCESS = "Action completed.";
        NotificationMessages.REQUEST_WEIGHIN_COMMENT_ADDED = "Comment was added.";
        return NotificationMessages;
    }());
    exports.NotificationMessages = NotificationMessages;
});
//# sourceMappingURL=notificationMessages.constant.js.map