'use strict';

export class ReviewResult {

    static APPROVE:string = "Approve";
    static RECOMMEND_APPROVE:string = "Recommend Approve";
    static NOT_APPLICABLE:string = "Not Applicable";
    static RECOMMEND_DISAPPROVE:string = "Recommend Disapprove";
    static DISAPPROVE:string = "Disapprove";
    static NOTE_CONCERN:string = "Note Concern";

    constructor(){}
}