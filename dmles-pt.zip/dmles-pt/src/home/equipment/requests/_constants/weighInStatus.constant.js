define(["require", "exports"], function (require, exports) {
    'use strict';
    var WeighInStatus = (function () {
        function WeighInStatus() {
        }
        WeighInStatus.NEW = "New";
        WeighInStatus.PENDING = "Pending";
        WeighInStatus.HOLD = "Hold";
        WeighInStatus.RECALLED = "Recalled";
        WeighInStatus.REWORK = "Rework";
        WeighInStatus.SKIPPED = "Skipped";
        WeighInStatus.SUBMITTED = "Submitted";
        return WeighInStatus;
    }());
    exports.WeighInStatus = WeighInStatus;
});
//# sourceMappingURL=weighInStatus.constant.js.map