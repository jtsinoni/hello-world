define(["require", "exports"], function (require, exports) {
    'use strict';
    var WorkflowCompletionStatus = (function () {
        function WorkflowCompletionStatus() {
        }
        WorkflowCompletionStatus.APPROVED = "Approved";
        WorkflowCompletionStatus.CANCELLED = "Cancelled";
        WorkflowCompletionStatus.COMPLETED = "Completed";
        WorkflowCompletionStatus.REJECTED = "Rejected";
        return WorkflowCompletionStatus;
    }());
    exports.WorkflowCompletionStatus = WorkflowCompletionStatus;
});
//# sourceMappingURL=workflowCompletionStatus.constant.js.map