'use strict';

export class WorkflowCompletionStatus {

    static APPROVED:string = "Approved";
    static CANCELLED:string = "Cancelled";
    static COMPLETED:string = "Completed";
    static REJECTED:string = "Rejected";

    constructor(){}
}