define(["require", "exports", './notificationMessages.constant', './weighInResult.constant', './weighInStatus.constant', './workflowCompletionStatus.constant'], function (require, exports, notificationMessages_constant_1, weighInResult_constant_1, weighInStatus_constant_1, workflowCompletionStatus_constant_1) {
    'use strict';
    var constantModule = angular.module('Dmles.Equipment.Requests.Constants.Module', []);
    constantModule.constant('NotificationMessages', notificationMessages_constant_1.NotificationMessages);
    constantModule.constant('WeighInResult', weighInResult_constant_1.WeighInResult);
    constantModule.constant('WeighInStatus', weighInStatus_constant_1.WeighInStatus);
    constantModule.constant('WorkflowCompletionStatus', workflowCompletionStatus_constant_1.WorkflowCompletionStatus);
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = constantModule;
});
//# sourceMappingURL=module.js.map