'use strict';

export class ReviewStatus {

    static NEW:string = "New";
    static PENDING:string = "Pending";
    static HOLD:string = "Hold";
    static RECALLED:string = "Recalled";
    static REWORK:string = "Rework";
    static SKIPPED:string = "Skipped";
    static SUBMITTED:string = "Submitted";

    constructor(){}
}