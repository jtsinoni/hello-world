'use strict';

import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {RequestItem} from '../_models/requestItem.model';
import {CurrentUserProfile} from '../../../../_models/currentUserProfile.model';

export class MyRequestsController {
    private controllerName:string = "My Requests Controller";
    private currentUser:CurrentUserProfile = new CurrentUserProfile();
    private activePill:string;
    public loadingTable:boolean = true;
    public loadingHistoryTable:boolean = true;
    public activeRequestSearch:String;
    public requestHistorySearch:String;

    // @ngInject
    constructor(private $filter, private $log, private $state, private ContentConstants, private datatableService, private ProcessStages, private NotificationService,
                private RequestApi, private RequestService, private StateConstants, private UserService, private UserTypeConstants,
                private WorkflowCompletionStatus, private WorkflowLevelStatus, private WorkFlowService) {
        this.$log.debug("%s - Start", this.controllerName);
        this.currentUser = this.UserService.currentUser;
        this.$log.debug("this.currentUser: %s", JSON.stringify(this.currentUser));
        this.init();
    }

    public getRequestStatusClass(request){
        var styleClass = "";
        if(request.wfProcessing) {
            if (request.wfProcessing.currentStatus){
                switch(request.wfProcessing.currentStatus) {
                    case this.WorkflowCompletionStatus.COMPLETED :
                        styleClass = 'success'
                        break;
                    case this.WorkflowCompletionStatus.REJECTED :
                        styleClass = 'danger'
                        break;
                    case this.WorkflowLevelStatus.ACTIVE :
                        styleClass = 'info'
                        break;
                    case this.WorkflowLevelStatus.HOLD :
                        styleClass = 'warning'
                        break;
                    default :
                        styleClass = ''
                        break;
                }
            }
        }
        return styleClass;
    }

    public getFilterMyRequests(){
        this.activePill = 'me';
        this.RequestService.createActiveTable(this.RequestService.filterMyActiveRequests(this.RequestService.allEquipmentRequests));
        this.RequestService.createHistoryTable(this.RequestService.filterMyRequestHistory(this.RequestService.allEquipmentRequests));
    }
    //
    //public getFilterOrganizationRequests(){
    //    this.activePill = 'organization';
    //    this.RequestService.createActiveTable(this.RequestService.filterSiteActiveRequests(this.RequestService.allEquipmentRequests));
    //    this.RequestService.createHistoryTable(this.RequestService.filterSiteRequestHistory(this.RequestService.allEquipmentRequests));
    //}
    //
    //public getFilterRegionRequests(){
    //    this.activePill = 'region';
    //    this.RequestService.createActiveTable(this.RequestService.filterRegionActiveRequests(this.RequestService.allEquipmentRequests));
    //    this.RequestService.createHistoryTable(this.RequestService.filterRegionRequestHistory(this.RequestService.allEquipmentRequests));
    //}
    //
    //public getFilterServiceRequests(){
    //    this.activePill = 'service';
    //    this.RequestService.createActiveTable(this.RequestService.filterServiceActiveRequests(this.RequestService.allEquipmentRequests));
    //    this.RequestService.createHistoryTable(this.RequestService.filterServiceRequestHistory(this.RequestService.allEquipmentRequests));
    //}
    //
    public getFilterAllRequests(){
        this.activePill = 'all';
        this.RequestService.createActiveTable(this.RequestService.filterActiveRequests(this.RequestService.allEquipmentRequests));
        this.RequestService.createHistoryTable(this.RequestService.filterCompletedRequests(this.RequestService.allEquipmentRequests));
    }

    //public getFilterMyRequestHistory(){
    //    this.activePillHistory = 'me';
    //    this.RequestService.createHistoryTable(this.RequestService.filterMyRequestHistory(this.RequestService.allEquipmentRequests));
    //}

    //public getFilterOrganizationRequestHistory(){
    //    this.activePillHistory = 'organization';
    //    this.RequestService.createHistoryTable(this.RequestService.filterSiteRequestHistory(this.RequestService.allEquipmentRequests));
    //}

    //public getFilterRegionRequestHistory(){
    //    this.activePillHistory = 'region';
    //    this.RequestService.createHistoryTable(this.RequestService.filterRegionRequestHistory(this.RequestService.allEquipmentRequests));
    //}

    //public getFilterServiceRequestHistory(){
    //    this.activePillHistory = 'service';
    //    this.RequestService.createHistoryTable(this.RequestService.filterServiceRequestHistory(this.RequestService.allEquipmentRequests));
    //}

    public requestsFilter() {
        this.RequestService.activeRequestTable.filter({$: this.activeRequestSearch});
        this.RequestService.activeRequestTable.reload();
    }

    public requestHistoryFilter() {
        this.RequestService.requestHistoryTable.filter({$: this.requestHistorySearch});
        this.RequestService.requestHistoryTable.reload();
    }

    public viewRequestDetails(request) {
        if (request.wfProcessing) {
            var buildWeighIns = this.RequestService.buildWeighIns(request.id);
            buildWeighIns.then((result) => {
                if (result) {
                    var getCriteria = this.WorkFlowService.getLevelsCriteriaNeeded(this.RequestService.request);
                    getCriteria.then((result) => {
                        this.$state.go(this.StateConstants.EQUIP_REQUEST_VIEW);
                    });
                }
            });
        }else{
            this.RequestService.request = request;
            this.$state.go(this.StateConstants.EQUIP_REQUEST_VIEW);
        }
    }

    public showRequestDetailsView(request) {
        this.RequestService.request = request;
        this.$log.debug(this.controllerName + ": ");
        this.$state.go(this.StateConstants.EQUIP_REQUEST_VIEW);
    }

    private init() {
        this.$log.debug("%s - Init requests", this.controllerName);
        this.RequestService.getRequests();
        this.getFilterAllRequests();
    }
}

