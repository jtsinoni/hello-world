'use strict';

import {MyRequestsController} from './myRequests.controller';

var controllersModule = angular.module('Dmles.Home.Equipment.Requests.Views.Module', []);
controllersModule.controller('MyRequestsController', MyRequestsController);

export default controllersModule;