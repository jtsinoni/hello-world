define(["require", "exports"], function (require, exports) {
    'use strict';
    var NotesAttachmentsButtons = (function () {
        function NotesAttachmentsButtons($log, RequestService) {
            this.$log = $log;
            this.RequestService = RequestService;
            this.restrict = 'E'; // E = element, A = attribute, C = class, M = comment
            this.templateUrl = "src/home/equipment/requests/_directives/NotesAttachmentsButtons/notesAttachments.html";
            this.scope = true;
            this.link = function ($scope, $element, $attr) {
                var args = [];
                for (var _i = 3; _i < arguments.length; _i++) {
                    args[_i - 3] = arguments[_i];
                }
                $scope.name = $attr['name'];
            };
            NotesAttachmentsButtons.prototype.link = function (scope, element, attr) {
            };
        }
        NotesAttachmentsButtons.Factory = function () {
            var directive = function ($log, RequestService) { return new NotesAttachmentsButtons($log, RequestService); };
            directive.$inject = ['$log', 'RequestService'];
            return directive;
        };
        return NotesAttachmentsButtons;
    }());
    exports.NotesAttachmentsButtons = NotesAttachmentsButtons;
});
//# sourceMappingURL=notesAttachments.directive.js.map