'use strict';

export class NotesAttachmentsButtons implements ng.IDirective{
    public restrict:string = 'E';  // E = element, A = attribute, C = class, M = comment
    public templateUrl:string = "src/home/equipment/requests/_directives/NotesAttachmentsButtons/notesAttachments.html";
    public scope:boolean = true;

    public link = ($scope, $element, $attr, ...args) => {
        $scope.name = $attr['name'];
    }

    constructor(private $log, private RequestService) {
        NotesAttachmentsButtons.prototype.link = (scope, element, attr) => {
        };
    }

    public static Factory() {
        const directive = ($log, RequestService) => new NotesAttachmentsButtons($log, RequestService);
        directive.$inject = ['$log', 'RequestService'];
        return directive;
    }
}