define(["require", "exports"], function (require, exports) {
    'use strict';
    var WeighInSubmitButtons = (function () {
        function WeighInSubmitButtons($log, PermissionService, WeighInStatus, WorkFlowService) {
            this.$log = $log;
            this.PermissionService = PermissionService;
            this.WeighInStatus = WeighInStatus;
            this.WorkFlowService = WorkFlowService;
            this.restrict = 'E'; // E = element, A = attribute, C = class, M = comment
            this.templateUrl = "src/home/equipment/requests/_directives/WeighInSubmitButtons/WeighInSubmitButtons.html";
            this.scope = true;
            this.link = function ($scope, $element, $attr) {
                var args = [];
                for (var _i = 3; _i < arguments.length; _i++) {
                    args[_i - 3] = arguments[_i];
                }
                $scope.weighInName = $attr['weighIn'];
                $scope.formValid = $attr['formValid'];
                $scope.name = $attr['name'];
            };
            WeighInSubmitButtons.prototype.link = function (scope, element, attr) {
            };
        }
        WeighInSubmitButtons.Factory = function () {
            var directive = function ($log, PermissionService, WeighInStatus, WorkFlowService) { return new WeighInSubmitButtons($log, PermissionService, WeighInStatus, WorkFlowService); };
            directive.$inject = ['$log', 'PermissionService', 'WeighInStatus', 'WorkFlowService'];
            return directive;
        };
        return WeighInSubmitButtons;
    }());
    exports.WeighInSubmitButtons = WeighInSubmitButtons;
});
//# sourceMappingURL=weighinSubmitButtons.directive.js.map