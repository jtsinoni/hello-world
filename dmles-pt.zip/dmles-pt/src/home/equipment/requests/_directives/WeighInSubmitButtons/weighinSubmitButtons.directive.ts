'use strict';

export class WeighInSubmitButtons implements ng.IDirective{
    public restrict:string = 'E';  // E = element, A = attribute, C = class, M = comment
    public templateUrl:string = "src/home/equipment/requests/_directives/WeighInSubmitButtons/WeighInSubmitButtons.html";
    public scope:boolean = true;

    public link = ($scope, $element, $attr, ...args) => {
        $scope.weighInName = $attr['weighIn'];
        $scope.formValid = $attr['formValid'];
        $scope.name = $attr['name'];
    }

    constructor(private $log, private PermissionService, private WeighInStatus, private WorkFlowService) {
        WeighInSubmitButtons.prototype.link = (scope, element, attr) => {
        };
    }

    public static Factory() {
        const directive = ($log, PermissionService, WeighInStatus, WorkFlowService) => new WeighInSubmitButtons($log, PermissionService, WeighInStatus, WorkFlowService);
        directive.$inject = ['$log', 'PermissionService', 'WeighInStatus', 'WorkFlowService'];
        return directive;
    }
}