define(["require", "exports", './EntrySectionHeader/entrySectionHeader.directive', './NotesAttachmentsButtons/notesAttachments.directive', './WeighInSubmitButtons/weighinSubmitButtons.directive'], function (require, exports, entrySectionHeader_directive_1, notesAttachments_directive_1, weighinSubmitButtons_directive_1) {
    'use strict';
    var directivesModule = angular.module('Dmles.Equipment.Requests.Directives.Module', []);
    directivesModule.directive('entrySectionHeader', entrySectionHeader_directive_1.EntrySectionHeader.Factory());
    directivesModule.directive('notesAttachmentsButtons', notesAttachments_directive_1.NotesAttachmentsButtons.Factory());
    directivesModule.directive('weighinSubmitButtons', weighinSubmitButtons_directive_1.WeighInSubmitButtons.Factory());
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = directivesModule;
});
//# sourceMappingURL=module.js.map