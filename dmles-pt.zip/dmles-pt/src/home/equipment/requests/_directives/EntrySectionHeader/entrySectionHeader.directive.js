define(["require", "exports"], function (require, exports) {
    'use strict';
    var EntrySectionHeader = (function () {
        function EntrySectionHeader($log, RequestService) {
            this.$log = $log;
            this.RequestService = RequestService;
            this.restrict = 'E'; // E = element, A = attribute, C = class, M = comment
            this.templateUrl = "src/home/equipment/requests/_directives/EntrySectionHeader/EntrySectionHeader.html";
            this.scope = true;
            this.link = function ($scope, $element, $attr) {
                var args = [];
                for (var _i = 3; _i < arguments.length; _i++) {
                    args[_i - 3] = arguments[_i];
                }
                //$scope.weighInName = $attr['weighIn'];
                $scope.formValid = $attr['formValid'].formValid;
                $scope.formInvalid = $attr['formInvalid'];
                $scope.title = $attr['title'];
                $scope.name = $attr['name'];
                $scope.displayAdd = $attr['displayAdd'];
                $scope.addClick = $attr['addClick'];
            };
            EntrySectionHeader.prototype.link = function (scope, element, attr) {
            };
        }
        EntrySectionHeader.Factory = function () {
            var directive = function ($log, RequestService) { return new EntrySectionHeader($log, RequestService); };
            directive.$inject = ['$log', 'RequestService'];
            return directive;
        };
        return EntrySectionHeader;
    }());
    exports.EntrySectionHeader = EntrySectionHeader;
});
//# sourceMappingURL=entrySectionHeader.directive.js.map