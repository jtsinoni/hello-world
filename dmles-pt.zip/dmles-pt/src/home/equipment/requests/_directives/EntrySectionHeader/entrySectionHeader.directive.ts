'use strict';

export class EntrySectionHeader implements ng.IDirective{
    public restrict:string = 'E';  // E = element, A = attribute, C = class, M = comment
    public templateUrl:string = "src/home/equipment/requests/_directives/EntrySectionHeader/EntrySectionHeader.html";
    public scope:boolean = true;

    public link = ($scope, $element, $attr, ...args) => {
        //$scope.reviewName = $attr['review'];
        $scope.formValid = $attr['formValid'].formValid;
        $scope.formInvalid = $attr['formInvalid'];
        $scope.title = $attr['title'];
        $scope.name = $attr['name'];
        $scope.displayAdd = $attr['displayAdd'];
        $scope.addClick = $attr['addClick'];
    }

    constructor(private $log, private RequestService) {
        EntrySectionHeader.prototype.link = (scope, element, attr) => {
        };
    }

    public static Factory() {
        const directive = ($log, RequestService) => new EntrySectionHeader($log, RequestService);
        directive.$inject = ['$log', 'RequestService'];
        return directive;
    }
}

