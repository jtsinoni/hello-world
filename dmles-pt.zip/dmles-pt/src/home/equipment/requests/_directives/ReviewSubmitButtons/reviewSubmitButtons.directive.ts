'use strict';

export class ReviewSubmitButtons implements ng.IDirective{
    public restrict:string = 'E';  // E = element, A = attribute, C = class, M = comment
    public templateUrl:string = "src/home/equipment/requests/_directives/ReviewSubmitButtons/ReviewSubmitButtons.html";
    public scope:boolean = true;

    public link = ($scope, $element, $attr, ...args) => {
        $scope.reviewName = $attr['review'];
        $scope.formValid = $attr['formValid'];
        $scope.name = $attr['name'];
    }

    constructor(private $log, private PermissionService, private ReviewStatus, private WorkFlowService) {
        ReviewSubmitButtons.prototype.link = (scope, element, attr) => {
        };
    }

    public static Factory() {
        const directive = ($log, PermissionService, ReviewStatus, WorkFlowService) => new ReviewSubmitButtons($log, PermissionService, ReviewStatus, WorkFlowService);
        directive.$inject = ['$log', 'PermissionService', 'ReviewStatus', 'WorkFlowService'];
        return directive;
    }
}