'use strict';

import {EntrySectionHeader} from './EntrySectionHeader/entrySectionHeader.directive';
import {NotesAttachmentsButtons} from './NotesAttachmentsButtons/notesAttachments.directive';
import {ReviewSubmitButtons} from './ReviewSubmitButtons/reviewSubmitButtons.directive';

var directivesModule = angular.module('Dmles.Equipment.Requests.Directives.Module', []);
directivesModule.directive('entrySectionHeader', EntrySectionHeader.Factory());
directivesModule.directive('notesAttachmentsButtons', NotesAttachmentsButtons.Factory());
directivesModule.directive('reviewSubmitButtons', ReviewSubmitButtons.Factory());

export default directivesModule;