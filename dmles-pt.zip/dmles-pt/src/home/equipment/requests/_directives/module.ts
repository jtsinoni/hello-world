'use strict';

import {EntrySectionHeader} from './EntrySectionHeader/entrySectionHeader.directive';
import {NotesAttachmentsButtons} from './NotesAttachmentsButtons/notesAttachments.directive';
import {WeighInSubmitButtons} from './WeighInSubmitButtons/weighinSubmitButtons.directive';

var directivesModule = angular.module('Dmles.Equipment.Requests.Directives.Module', []);
directivesModule.directive('entrySectionHeader', EntrySectionHeader.Factory());
directivesModule.directive('notesAttachmentsButtons', NotesAttachmentsButtons.Factory());
directivesModule.directive('weighinSubmitButtons', WeighInSubmitButtons.Factory());

export default directivesModule;