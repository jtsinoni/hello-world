'use strict';

class Router {
    static instance:any;

    // @ngInject
    constructor($stateProvider, $urlRouterProvider, StateConstants) {

        $stateProvider
            .state(StateConstants.EQUIP_REQUEST_SHELL, {
                url: '/requests',
                templateUrl: '/src/home/equipment/requests/requestsShell.html',
                controller: 'RequestsShellController',
                controllerAs: 'vm',
                abstract: true
            }).state(StateConstants.EQUIP_REQUEST_MY_REQUESTS, {
                url: '/Requests',
                templateUrl: '/src/home/equipment/requests/_views/myRequests.html',
                controller: 'MyRequestsController',
                controllerAs: 'vm',
                data: {
                    displayName: 'Equipment Requests'
                }
            })
            ;
    }

    static factory($stateProvider, $urlRouterProvider, StateConstants) {
        Router.instance = new Router($stateProvider, $urlRouterProvider, StateConstants);
        return Router.instance;
    }
}

Router.factory.$inject = ['$stateProvider', '$urlRouterProvider', 'StateConstants'];

export default Router;