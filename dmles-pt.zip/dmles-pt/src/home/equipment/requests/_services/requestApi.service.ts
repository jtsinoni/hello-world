'use strict';

import {ApiService} from '../../../../_services/api.service';

export interface IRequestApiService {

}

export class RequestApi extends ApiService implements IRequestApiService {

    // @ngInject
    constructor($http, public $log, Authentication, App, $httpParamSerializerJQLike) {
        super($http, $log, Authentication, App, $httpParamSerializerJQLike, "EquipmentManagement");
    }

    public buildWeighIns(requestId){
        return this.get('request/buildWeighins?requestId=' + requestId);
    }

    public getEquipmentRequests() {
        return this.get("getEquipmentRequests");
    }

    public getCriticalityCodes(service) {
        return this.get('getCriticalCodes?serviceAgency=' + service);
    }

    public getDevices(){
        return this.get('getDevices');
    }

    public getEquipmentRequest(id) {
        return this.get("getEquipmentRequest?id=" + id);
    }

    public getEquipmentRequestReasons() {
        return this.get("getEquipmentRequestReasons");
    };

    public getEquipmentRequestTypes() {
        return this.get("getEquipmentRequestTypes");
    };

    public getLiteratureTypes(){
        return this.get('getLiteratureTypes');
    }

    public getManufacturers(){
        return this.get('getEquipmentManufacturers');
    }

    public getMountingTypes(){
        return this.get('getEquipmentMountingTypes');
    }

    public getLevelsCriteriaNeeded(request){
        return this.post("getLevelsCriteriaNeeded", request);
    }

    public getRequestsByCustodianId(userId,active){
        return this.get("getRequestsByCustodianId?userId=" + userId+"&active="+active);
    }

    public getRequestsByRequestStatus(status){
        return this.get("getRequestsByRequestStatus?status=" + status);
    }

    public getTraineeTypes(){
        return this.get("getEquipmentTraineeTypes");
    }

    public getTrainingLocations(){
        return this.get("getTraineeLocationTypes");
    }

    public getWeighInResults(){
        return this.get("request/getWeighInResults");
    }   

    public saveEquipmentRequest(equipmentRequest) {
    return this.post("request/save", equipmentRequest);
}

    public saveFacilities(equipmentRequest) {
        return this.post("request/saveFacilities", equipmentRequest);
    }

    public saveMaintenance(equipmentRequest) {
        return this.post("request/saveMaintenance", equipmentRequest);
    }

    public saveRequestCustomerInfo(equipmentRequest) {
        return this.post("request/saveRequestCustomerInfo", equipmentRequest);
    }

    public saveRequestEquipmentInfo(equipmentRequest) {
        return this.post("request/saveRequestEquipmentInfo", equipmentRequest);
    }

    public saveRequestExtraItems(equipmentRequest) {
        return this.post("request/saveRequestExtraItems", equipmentRequest);
    }

    public saveRequestInfo(equipmentRequest) {
        return this.post("request/saveRequestInfo", equipmentRequest);
    }

    public saveRequestSourceOfSupply(equipmentRequest) {
        return this.post("request/saveRequestSourceOfSupply", equipmentRequest);
    }

    public saveRequestTraining(equipmentRequest) {
        return this.post("request/saveRequestTraining", equipmentRequest);
    }

    public saveSafety(equipmentRequest) {
        return this.post("request/saveSafety", equipmentRequest);
    }

    public saveTechnology(equipmentRequest) {
        return this.post("request/saveTechnology", equipmentRequest);
    }

    public submitForProcessing(request) {
        return this.post("request/submitForProcessing", request);
    }

    /********* Comments **********/

    public addProcessComment(requestId, comment){
        return this.get("request/addProcessComment?requestId=" + requestId + "&comment=" + comment);
    }

    public addWeighInComment(requestId, weighInRole, comment){
        return this.get("request/addWeighInComment?requestId=" + requestId + "&weighInRole=" + weighInRole + "&comment=" + comment);
    }

    public removeProcessComment(requestId, commentId){
        return this.get("request/removeProcessComment?requestId=" + requestId + "&commentId=" + commentId);
    }

    public removeWeighInComment(requestId, weighInRole, commentId){
        return this.get("request/removeWeighInComment?requestId=" + requestId + "&weighInRole=" + weighInRole + "&commentId=" + commentId);
    }

    /********* Level Results **********/

    public approve(requestId){
        return this.get("request/approve?requestId=" + requestId);
    }

    public cancel(requestId){
        return this.get("request/cancel?requestId=" + requestId);
    }

    public forceUp(requestId){
        return this.get("request/forceUp?requestId=" + requestId);
    }

    public hold(requestId){
        return this.get("request/hold?requestId=" + requestId);
    }

    public reactivate(requestId){
        return this.get("request/reactivate?requestId=" + requestId);
    }

    public reject(requestId){
        return this.get("request/reject?requestId=" + requestId);
    }

    public retract(requestId){
        return this.get("request/retract?requestId=" + requestId);
    }

    public rework(requestId){
        return this.get("request/rework?requestId=" + requestId);
    }

    /******* Weigh In Results *******/

    public submitWeighinResult(weighInRole, result, request, weighInDisplayName) {
        return this.post("request/submitWeighinResult?requestId=" + request.id + "&weighInRole=" + weighInRole + "&result=" + result + "&weighInDisplayName=" + weighInDisplayName, request);
    }

    public submitWeighinStatus(request) {
        return this.post("request/submitWeighinStatus", request);
    }

    /******* Workflow Management *******/

    public getWorkflowDefinition(service){
        return this.get("request/workflowDefinition/getDefinition?service=" + service);
    }

    public updateWorkflowDefCostCriteria(serviceName, levelID, totalCost){
        return this.get("request/updateWorkflowDefCostCriteria?serviceName=" + serviceName + "&levelID=" + levelID + "&totalCost=" + totalCost);
    }
}