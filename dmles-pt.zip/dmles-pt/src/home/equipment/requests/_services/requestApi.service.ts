'use strict';

import {ApiService} from '../../../../_services/api.service';

export interface IRequestApiService {

}

export class RequestApi extends ApiService implements IRequestApiService {

    // @ngInject
    constructor($http, public $log, Authentication, $httpParamSerializerJQLike) {
        super($http, $log, Authentication, $httpParamSerializerJQLike, "EquipmentManagement");
    }

    public buildReviews(requestId){
        return this.get('request/buildReviews?requestId=' + requestId);
    }

    public getEquipmentRequests() {
        return this.get("getEquipmentRequests");
    }

    public getCriticalityCodes(service) {
        return this.get('getCriticalCodes?serviceAgency=' + service);
    }

    public getDevices(){
        return this.get('getDevices');
    }

    public getEquipmentRequest(id) {
        return this.get("getEquipmentRequest?id=" + id);
    }

    public getEquipmentRequestReasons() {
        return this.get("getEquipmentRequestReasons");
    };

    public getEquipmentRequestTypes() {
        return this.get("getEquipmentRequestTypes");
    };

    public getLiteratureTypes(){
        return this.get('getLiteratureTypes');
    }

    public getManufacturers(){
        return this.get('getEquipmentManufacturers');
    }

    public getMountingTypes(){
        return this.get('getEquipmentMountingTypes');
    }

    public getLevelsCriteriaNeeded(request){
        return this.post("getLevelsCriteriaNeeded", request);
    }

    public getRequestsByCustodianId(userId,active){
        return this.get("getRequestsByCustodianId?userId=" + userId+"&active="+active);
    }

    public getRequestsByRequestStatus(status){
        return this.get("getRequestsByRequestStatus?status=" + status);
    }

    public getTraineeTypes(){
        return this.get("getEquipmentTraineeTypes");
    }

    public getTrainingLocations(){
        return this.get("getTraineeLocationTypes");
    }

    public getReviewResults(){
        return this.get("request/getReviewResults");
    }   

    public saveEquipmentRequest(equipmentRequest) {
    return this.post("request/save", equipmentRequest);
}

    public saveFacilities(equipmentRequest) {
        return this.post("request/saveFacilities", equipmentRequest);
    }

    public saveMaintenance(equipmentRequest) {
        return this.post("request/saveMaintenance", equipmentRequest);
    }

    public saveRequestCustomerInfo(equipmentRequest) {
        return this.post("request/saveRequestCustomerInfo", equipmentRequest);
    }

    public saveRequestEquipmentInfo(equipmentRequest) {
        return this.post("request/saveRequestEquipmentInfo", equipmentRequest);
    }

    public saveRequestExtraItems(equipmentRequest) {
        return this.post("request/saveRequestExtraItems", equipmentRequest);
    }

    public saveRequestInfo(equipmentRequest) {
        return this.post("request/saveRequestInfo", equipmentRequest);
    }

    public saveRequestSourceOfSupply(equipmentRequest) {
        return this.post("request/saveRequestSourceOfSupply", equipmentRequest);
    }

    public saveRequestTraining(equipmentRequest) {
        return this.post("request/saveRequestTraining", equipmentRequest);
    }

    public saveSafety(equipmentRequest) {
        return this.post("request/saveSafety", equipmentRequest);
    }

    public saveTechnology(equipmentRequest) {
        return this.post("request/saveTechnology", equipmentRequest);
    }

    public submitForProcessing(request) {
        return this.post("request/submitForProcessing", request);
    }

    /********* Comments **********/

    public addProcessComment(requestId, comment){
        return this.get("request/addProcessComment?requestId=" + requestId + "&comment=" + comment);
    }

    public addReviewComment(requestId, reviewRole, comment){
        return this.get("request/addReviewComment?requestId=" + requestId + "&reviewRole=" + reviewRole + "&comment=" + comment);
    }

    public removeProcessComment(requestId, commentId){
        return this.get("request/removeProcessComment?requestId=" + requestId + "&commentId=" + commentId);
    }

    public removeReviewComment(requestId, reviewRole, commentId){
        return this.get("request/removeReviewComment?requestId=" + requestId + "&reviewRole=" + reviewRole + "&commentId=" + commentId);
    }

    /********* Level Results **********/

    public approve(requestId){
        return this.get("request/approve?requestId=" + requestId);
    }

    public cancel(requestId){
        return this.get("request/cancel?requestId=" + requestId);
    }

    public forceUp(requestId){
        return this.get("request/forceUp?requestId=" + requestId);
    }

    public hold(requestId){
        return this.get("request/hold?requestId=" + requestId);
    }

    public reactivate(requestId){
        return this.get("request/reactivate?requestId=" + requestId);
    }

    public reject(requestId){
        return this.get("request/reject?requestId=" + requestId);
    }

    public retract(requestId){
        return this.get("request/retract?requestId=" + requestId);
    }

    public rework(requestId){
        return this.get("request/rework?requestId=" + requestId);
    }

    /******* Weigh In Results *******/

    public submitReviewResult(result, request, reviewDisplayName) {
        this.post("request/save", request);
        return this.post("request/submitReviewResult?requestId=" + request.id + "&result=" + result + "&reviewDisplayName=" + reviewDisplayName, request);
    }

    public submitReviewStatus(request) {
        return this.post("request/submitReviewStatus", request);
    }

    /******* Workflow Management *******/

    public getWorkflowDefinition(service){
        return this.get("request/workflowDefinition/getDefinition?service=" + service);
    }

    public updateWorkflowDefCostCriteria(serviceName, levelID, totalCost){
        return this.get("request/updateWorkflowDefCostCriteria?serviceName=" + serviceName + "&levelID=" + levelID + "&totalCost=" + totalCost);
    }
}