'use strict';

import {RequestService} from './request.service';
import {RequestApi} from './requestApi.service';
import {WorkFlowService} from './workFlow.service';

var servicesModule = angular.module('Dmles.Equipment.Requests.Services.Module', []);
servicesModule.service('RequestService', RequestService);
servicesModule.service('RequestApi', RequestApi);
servicesModule.service('WorkFlowService', WorkFlowService);

export default servicesModule;