import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {NoteItem} from "../_models/noteItem.model";
import {CatalogItem} from "../../../catalog/_models/catalogItem.model";
import {EquipmentRequirement} from "../_models/equipmentRequirement.model";
import {ExtraItem} from "../_models/extraItem.model";
import {RequestItem} from '../_models/requestItem.model';
import {Software} from '../_models/software.model';
import {SuggestedSourceItem} from "../_models/suggestedSourceItem.model";
import {CurrentUserProfile} from '../../../../_models/currentUserProfile.model';
import {InstallRequirement} from "../_models/installRequirement.model";
import {Literature} from "../_models/literature.model";
import {ReplacementItem} from "../_models/replacementItem.model";
import {TrainingItem} from "../_models/trainingItem.model";

export interface IRequestService {
    
}

export class RequestService implements IRequestService {
    private serviceName: string = "Requests Service";

    public activeRequestTable:any;
    public allEquipmentRequests:Array<RequestItem>;
    public isRequestIdentifiersFormCompleted:boolean;
    public isCustomerFormCompleted:boolean;
    public isEquipmentFormCompleted: boolean = false;
    public isFacilitiesCompleted:boolean = false;
    public isRequestFormCompleted:boolean;
    public isCompAccSuppliesFormCompleted:boolean = true;
    public isMaintenanceFormCompleted:boolean = false;
    public isSafetyCompleted:boolean = false;
    public isSoftwareFormCompleted:boolean = true;
    public isSuggestedSourceFormCompleted:boolean = false;
    public isTechnologiesComplete:boolean = false;
    public isThereAPrimarySource:boolean = false;
    public isTrainingFormCompleted:boolean = true;
    public missingRequiredEntryMsg;
    public myActiveRequestTable:any;
    public request:RequestItem = new RequestItem();
    public requestHistoryTable:any;
    public selectedNoteSection:string = "";
    public uploader:any = null;

    /*Temporary until the datamodel gets updated*/
    public attachmentSection:string = "";

    // @ngInject
    constructor(private $filter, private $http, private $log, private $state, private App, private ContentConstants,
                private dataService, private datatableService, private FileUploader, private NotificationMessages,
                private NotificationService, private StateConstants, private RequestApi, private UserService) {
        this.$log.debug("%s - Start", this.serviceName);

        this.uploader = new FileUploader({
           // url: this.App.getBtBaseUrl() + 'EquipmentManagement/Api/saveDocument',
            headers: {'Content-Type': 'multipart/formdata'}
        });

        this.uploader.filters.push({
            name: 'customFilter',
            fn: function(item /*{File|FileLikeObject}*/, options) {
                return this.queue.length < 10;
            }
        });

        this.uploader.onWhenAddingFileFailed = function(item /*{File|FileLikeObject}*/, filter, options) {
            console.info('onWhenAddingFileFailed', item, filter, options);
        };
        this.uploader.onAfterAddingFile = function(fileItem) {
            console.info('onAfterAddingFile', fileItem);
        };
        this.uploader.onAfterAddingAll = function(addedFileItems) {
            console.info('onAfterAddingAll', addedFileItems);
        };
        this.uploader.onBeforeUploadItem = function(item) {
            console.info('onBeforeUploadItem', item);
        };
        this.uploader.onProgressItem = function(fileItem, progress) {
            console.info('onProgressItem', fileItem, progress);
        };
        this.uploader.onProgressAll = function(progress) {
            console.info('onProgressAll', progress);
        };
        this.uploader.onSuccessItem = function(fileItem, response, status, headers) {
            console.info('onSuccessItem', fileItem, response, status, headers);
        };
        this.uploader.onErrorItem = function(fileItem, response, status, headers) {
            console.info('onErrorItem', fileItem, response, status, headers);
        };
        this.uploader.onCancelItem = function(fileItem, response, status, headers) {
            console.info('onCancelItem', fileItem, response, status, headers);
        };
        this.uploader.onCompleteItem = function(fileItem, response, status, headers) {
            console.info('onCompleteItem', fileItem, response, status, headers);
        };
        this.uploader.onCompleteAll = function() {
            console.info('onCompleteAll');
        };
    }

    public addCatalogInfoToRequest(catalogItem){
        this.request.catalogItem = catalogItem;
        this.request.requestInformation.equipment.isFoundInCatalog = true;

        // Populate or overwrite existing field entries
        this.request.requestInformation.equipment.catalogId = catalogItem.itemId;
        this.request.requestInformation.equipment.isFoundInCatalog = true;
        this.request.requestInformation.equipment.manufacturer = catalogItem.manufacturerNm;
        this.request.requestInformation.equipment.model = catalogItem.eqpmtModelNum;
        this.request.requestInformation.equipment.deviceName = catalogItem.deviceText;
        this.request.requestInformation.equipment.deviceCode = catalogItem.deviceCd;
        this.request.requestInformation.equipment.unitCost = catalogItem.burdenedPriceAmt;

        var suggSourceItem = new SuggestedSourceItem();
        suggSourceItem.sourceName = catalogItem.supplierNm;
        this.addSuggestedSource(suggSourceItem);
        //suggSourceItem.primarySource = true;
        //this.request.requestInformation.suggestedSources.push(suggSourceItem);

        this.request.requestInformation.quantityRequested = catalogItem.quantity;
        if(!this.request.requestInformation.quantityRequested || this.request.requestInformation.quantityRequested == 0){
            this.request.requestInformation.quantityRequested = 1;
        }
        this.calculateTotalPrice();
    }

    public buildRequestFromCatalog(catalogItem){
        this.request = new RequestItem();
        this.addCatalogInfoToRequest(catalogItem);
        //this.request.catalogItem = catalogItem;
        //this.request.requestInformation.equipment.isFoundInCatalog = true;
        //
        //// Populate or overwrite existing field entries
        //this.request.requestInformation.equipment.catalogId = catalogItem.itemId;
        //this.request.requestInformation.requestedItemId = catalogItem.itemId;
        //this.request.requestInformation.equipment.isFoundInCatalog = true;
        //this.request.requestInformation.equipment.description = catalogItem.longItemDesc;
        //this.request.requestInformation.equipment.manufacturer = catalogItem.manufacturerNm;
        //this.request.requestInformation.equipment.model = catalogItem.eqpmtModelNum;
        //this.request.requestInformation.equipment.nomenclature = catalogItem.shortItemDesc;
        //this.request.requestInformation.equipment.deviceCode = catalogItem.deviceCd;
        //this.request.requestInformation.equipment.unitCost = catalogItem.burdenedPriceAmt;
        //
        //var suggSourceItem = new SuggestedSourceItem();
        //suggSourceItem.sourceName = catalogItem.supplierNm;
        //suggSourceItem.primarySource = true;
        //this.request.requestInformation.suggestedSources.push(suggSourceItem);
        //
        //this.request.requestInformation.quantityRequested = catalogItem.quantity;
        //
        //this.$log.debug(this.request);

        // TODO: Much more can be pulled from the catalog item and added to the request

        // TODO: Add/Enable catalog tab
    }

    public buildRequestFromHistory(oldRequest){
        this.request = new RequestItem();
        this.request.requestInformation.submitter.userId = this.UserService.currentUser.id;
        this.request.requestInformation.submitter.email = this.UserService.currentUser.email;
        this.request.requestInformation.submitter.nameFirst = this.UserService.currentUser.firstName;
        this.request.requestInformation.submitter.nameLast = this.UserService.currentUser.lastName;
        this.request.requestInformation.submitter.phoneNumber = this.UserService.currentUser.phoneNumbers[0].value;
        this.request.requestInformation.submitter.dodaac = this.UserService.currentUser.dodaac;
        this.request.requestInformation.submitter.regionCode = this.UserService.currentUser.regionCode;
        this.request.requestInformation.submitter.serviceCode = this.UserService.currentUser.serviceCode;
        this.addCatalogInfoToRequest(oldRequest.catalogItem);

        //Set fields from the old request
        this.request.requestInformation.equipment = oldRequest.requestInformation.equipment;
        this.request.requestInformation.replacedItems = oldRequest.requestInformation.replacedItems;
        this.request.requestInformation.suggestedSources = oldRequest.requestInformation.suggestedSources;
        this.request.requestInformation.training = oldRequest.requestInformation.training;
        this.request.requestInformation.equipmentRequirements = oldRequest.requestInformation.equipmentRequirements;
        this.request.requestInformation.extraItems = oldRequest.requestInformation.extraItems;
        this.request.requestInformation.quantityRequested = oldRequest.requestInformation.quantityRequested;
        this.request.totalPrice = oldRequest.totalPrice;
        this.request.requestInformation.totalCompAccSupplies = oldRequest.requestInformation.totalCompAccSupplies;
        this.request.requestInformation.totalTrainingCost = oldRequest.requestInformation.totalTrainingCost;
        this.verifyRequest();
    }

    public addAttachment(section){
        this.attachmentSection = section;
    }

    public addEquipmentRequirement(){
        var requirement = new EquipmentRequirement();
        this.request.requestInformation.equipmentRequirements.push(requirement);
    }

    public addExtraItem(type){
        var extraItem = new ExtraItem();
        extraItem.quantity = 1;
        extraItem.type = type;
        this.request.requestInformation.extraItems.push(extraItem);
        this.verifyCompAccSuppliesForm();
    }

    public addInstallationRequirement() {
        var installReq = new InstallRequirement();
        installReq.cost = 0;
        this.request.maintenanceInformation.installationRequirements.push(installReq);
        this.calculateTotalInstallationCosts();
    }

    public addItemBeingReplaced() {
        var replaceItem = new ReplacementItem();
        this.request.requestInformation.replacedItems.push(replaceItem);
        this.verifyRequestForm();
    }

    public addLiterature() {
        var literature = new Literature();
        this.request.maintenanceInformation.literature.push(literature);
        this.calculateTotalLiteratureCosts();
    }

    public addNote(section:string, text:string){
        this.request.notes.push(new NoteItem({
                                        section:section,
                                        dateCreated:new Date(),
                                        enteredBy:(this.UserService.currentUser.firstName+" "+this.UserService.currentUser.lastName),
                                        noteText:text}));
        //This will save the note to the database if the request has already been saved to the database.
        if(this.request.id){
            this.save();
        }
    }


    public addSoftware() {
        var software = new Software();
        this.request.technologyInformation.software.push(software);
        this.verifySoftwareForm();
    }

    public addSuggestedSource(source:any){
        if(this.request.requestInformation.suggestedSources.length==0){
            var suggSourceItem = new SuggestedSourceItem();
            suggSourceItem.primarySource = true;
            if(source) {
                suggSourceItem.sourceName = source.sourceName;
            }
            this.request.requestInformation.suggestedSources.push(suggSourceItem);
        }
        else {
            this.request.requestInformation.suggestedSources.push(new SuggestedSourceItem(source));
        }

        this.verifyAPrimarySourceBeenSet();
        this.verifySuggestedSourceForm();
    }

    public addTraining(trainee){
        var trainingItem = new TrainingItem();
        trainingItem.trainees = trainee;
        trainingItem.people = 1;
        trainingItem.registrationCost = 0;
        trainingItem.travelCost = 0;
        trainingItem.perDiem = 0;
        trainingItem.days = 1;
        this.request.requestInformation.training.push(trainingItem);
        this.calculateTotalTraining();
        this.verifyTrainingForm();
    }

    public buildWeighIns(requestId){
        return this.RequestApi.buildWeighIns(requestId).then((result) => {
            if(result && result.data){
                this.request = result.data;
                return true;
            }}, (errResponse:IHttpPromiseCallbackArg<any>) => {
            this.$log.error("Error retrieving request");
            this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
            return false;
        });
    }

    public calculateTotalPrice(){
        this.request.totalPrice = this.request.requestInformation.totalTrainingCost +
                                this.request.maintenanceInformation.estimatedAnnualServiceCost +
                                this.request.facilityInformation.facilityModificationCost +
                                this.request.maintenanceInformation.totalInstallationCosts +
                                this.request.maintenanceInformation.totalLiteratureCosts +
                                this.request.requestInformation.totalCompAccSupplies +
                                this.request.requestInformation.equipment.unitCost * this.request.requestInformation.quantityRequested;
    }

    public clearCatalogItem(){
        this.request.catalogItem = null;
        this.save();
    }

    public clearSuggestedSources(){
        this.request.requestInformation.suggestedSources = [];
    }

    public clearRequest(){
        this.request = new RequestItem();
    }

    public createActiveTable(data){
        this.activeRequestTable = this.datatableService.createNgTable(data, 25, { updatedDate: 'desc' });
    }

    public createHistoryTable(data){
        this.requestHistoryTable = this.datatableService.createNgTable(data, 25, { updatedDate: 'desc' });
    }

    public filterActiveRequests(requestList){
        return this.$filter('filter')(requestList, (o) => {
            return o.wfProcessing == null || !o.wfProcessing.isCompleted;
        });
    }


    public filterCompletedRequests(requestList){
        return this.$filter('filter')(requestList, (o) => {
            return o.wfProcessing && o.wfProcessing.isCompleted;
        });
    }
    //
    public filterMyActiveRequests(data){
        return this.$filter('filter')(data, (o) => {
            if(o.wfProcessing == null || !o.wfProcessing.isCompleted){
                var weighInUser = false;
                var levelOwnerRole = false;
                var weighInOwnerRole = false;
                return (o.requestInformation.submitter.userId == this.UserService.currentUser.id ||
                    weighInUser ||
                    levelOwnerRole ||
                    weighInOwnerRole)
            }
            else {return false}
        });
    }

    public filterMyRequestHistory(data){
        return this.$filter('filter')(data, (o) => {
            if(o.wfProcessing){
                var weighInUser = false;
                var levelOwnerRole = false;
                return o.requestInformation.submitter.userId == this.UserService.currentUser.id  ||
                weighInUser ||
                levelOwnerRole &&
                o.wfProcessing.isCompleted;}
            else {return false}
        });
    }

    public getRequests(){
        return this.RequestApi.getEquipmentRequests().then((result) => {
            if(result && result.data){
                this.allEquipmentRequests = result.data;
                this.createActiveTable(this.filterActiveRequests(this.allEquipmentRequests));
                this.createHistoryTable(this.filterCompletedRequests(this.allEquipmentRequests));
                return this.allEquipmentRequests;
            }}, (errResponse:IHttpPromiseCallbackArg<any>) => {
            this.$log.error("Error retrieving request from users id.");
            this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
        });
    }

    public hasNotes(section){
        var found = false;
        angular.forEach(this.request.notes,(note)=>{
            if(note.section === section){
                found = true;
                return;
            }
        });
        return found;
    }

    private isRequestValid() {
        this.missingRequiredEntryMsg = "";
        if (!this.request.requestInformation.requestTitle) {
            this.missingRequiredEntryMsg = "Request Title is required";
            return false;
        } else if (!this.request.requestInformation.requestNumber) {
            this.missingRequiredEntryMsg = "Request Number is required";
            return false;
        } else if (!this.isRequestFormCompleted) {
            this.missingRequiredEntryMsg = "Further request information required";
            return false;
        } else if (!this.request.requestInformation.organization) {
            this.missingRequiredEntryMsg = "Organization is required";
            return false;
        } else if (!this.request.requestInformation.customer) {
            this.missingRequiredEntryMsg = "Customer is required";
            return false;
        } else if (!this.isEquipmentFormCompleted) {
            this.missingRequiredEntryMsg = "Further equipment information required";
            return false;
        } else if (!this.isCompAccSuppliesFormCompleted) {
            this.missingRequiredEntryMsg = "Further component information required";
            return false;
        }  else if (!this.isThereAPrimarySource) {
            this.missingRequiredEntryMsg = "Please select one of your Sources of Supply as the <i class=bold>Primary Source</i>";
            return false;
        } else if (!this.isSuggestedSourceFormCompleted) {
            this.missingRequiredEntryMsg = "Further suggested source information required";
            return false;
        } else if (!this.isTrainingFormCompleted) {
            this.missingRequiredEntryMsg = "Further training information required";
            return false;
        }else{
            return true;
        }
    }

    public openNotes(section){
        this.selectedNoteSection = section;
    }

    public removeExtraItem(itemToRemove){
        this.request.requestInformation.extraItems.splice(this.request.requestInformation.extraItems.indexOf(itemToRemove), 1);
        this.calculateTotalCompAccSupplies();
    }

    public removeEquipmentRequirement(requirement){
        this.request.requestInformation.equipmentRequirements.splice(this.request.requestInformation.equipmentRequirements.indexOf(requirement),1);
    }

    //public removeItemBeingReplaced(item){
    //    this.request.replacedItems.splice(this.request.replacedItems.indexOf(item), 1);
    //}

    public removeInstallationRequirement(req){
        this.request.maintenanceInformation.installationRequirements.splice(this.request.maintenanceInformation.installationRequirements.indexOf(req), 1);
        this.calculateTotalInstallationCosts();
    }

    public removeItemBeingReplaced(item){
        this.request.requestInformation.replacedItems.splice(this.request.requestInformation.replacedItems.indexOf(item), 1);
    }

    public removeLiterature(literature){
        this.request.maintenanceInformation.literature.splice(this.request.maintenanceInformation.literature.indexOf(literature), 1);
        this.calculateTotalLiteratureCosts();
    }

    public removeNote(noteToBeDeleted, id) {
        angular.element(id).addClass("animated fadeOut");
        angular.forEach(this.request.notes, (note) => {
            if (note === noteToBeDeleted) {
                this.request.notes.splice(this.request.notes.indexOf(note), 1);
            }
        });
        if (this.$filter('filter')(this.request.notes, {section: noteToBeDeleted.section}, true).length < 1) {
            angular.element('#noteTable').addClass("animated fadeOut");
        }
        if (this.request.notes.length < 1) {
            angular.element('#summaryNoteTable').addClass("animated fadeOut");
        }
    }

    public removeSoftware(softwareToRemove){
        this.request.technologyInformation.software.splice(this.request.technologyInformation.software.indexOf(softwareToRemove), 1);
    }

    public removeSuggestedSource(sourceToRemove){
        this.request.requestInformation.suggestedSources.splice(this.request.requestInformation.suggestedSources.indexOf(sourceToRemove),1);
        if(this.request.requestInformation.suggestedSources.length > 0){
            if(sourceToRemove.primarySource) {
                this.request.requestInformation.suggestedSources[0].primarySource = true;
            }
        }
        this.verifyAPrimarySourceBeenSet();
        this.verifySuggestedSourceForm();
    }

    public removeTraining(trainingToRemove){
        this.request.requestInformation.training.splice(this.request.requestInformation.training.indexOf(trainingToRemove), 1);
        this.verifyTrainingForm();
        this.calculateTotalTraining();
    }

    public save() {
        if(this.request.requestInformation.requestNumber && this.request.requestInformation.requestTitle){
            this.calculateTotalPrice();
                return this.RequestApi.saveEquipmentRequest(angular.toJson(this.request)).then((response:IHttpPromiseCallbackArg<any>) => {
                if (response.data) {
                    this.request.id = angular.copy(response.data.id);
                    this.request.updatedBy = angular.copy(response.data.updatedBy);
                    this.request.updatedDate = angular.copy(response.data.updatedDate);
                    this.getRequests();
                    this.NotificationService.successMsg(this.NotificationMessages.REQUEST_SAVE_SUCCESS);
                    return true;
                } else {
                    this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
                    return false;
                }
            }, (errResponse:IHttpPromiseCallbackArg<any>) => {
                this.$log.error("%s - Error saving request: %s", JSON.stringify(errResponse));
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
                    return false;
                });
            }
        else
            {
                this.NotificationService.errorMsg("This request needs a <i class='bold'>Title</i> and <i class='bold'>Number</i> before you can save.");
            }

    }

    public saveFacilities() {
        this.calculateTotalPrice();
        this.RequestApi.saveFacilities(angular.toJson(this.request)).then((response:IHttpPromiseCallbackArg<any>) => {
            if(response.data) {
                this.request.id = angular.copy(response.data.id);
                this.request.updatedBy = angular.copy(response.data.updatedBy);
                this.request.updatedDate = angular.copy(response.data.updatedDate);
                if(this.request.wfProcessing){
                    this.request.wfProcessing.history = angular.copy(response.data.wfProcessing.history);
                }
                this.getRequests();
                this.NotificationService.successMsg(this.NotificationMessages.REQUEST_SAVE_SUCCESS);
            }else{
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
            }
        }, (errResponse:IHttpPromiseCallbackArg<any>) => {
            this.$log.error("%s - Error saving request: %s", JSON.stringify(errResponse));
            this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
        });
    }

    public saveMaintenance() {
        this.calculateTotalPrice();
        this.RequestApi.saveMaintenance(angular.toJson(this.request)).then((response:IHttpPromiseCallbackArg<any>) => {
            if(response.data) {
                this.request.id = angular.copy(response.data.id);
                this.request.updatedBy = angular.copy(response.data.updatedBy);
                this.request.updatedDate = angular.copy(response.data.updatedDate);
                if(this.request.wfProcessing){
                    this.request.wfProcessing.history = angular.copy(response.data.wfProcessing.history);
                }
                this.getRequests();
                this.NotificationService.successMsg(this.NotificationMessages.REQUEST_SAVE_SUCCESS);
            }else{
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
            }
        }, (errResponse:IHttpPromiseCallbackArg<any>) => {
            this.$log.error("%s - Error saving request: %s", JSON.stringify(errResponse));
            this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
        });
    }

    public saveNote(section, noteToEdit) {
        var found = false;
        angular.forEach(this.request.notes, (note:any) => {
            //This won't work without the getTime() otherwise it's always false
            if (angular.isDefined(noteToEdit.dateCreated) && note.dateCreated.getTime() == noteToEdit.dateCreated.getTime()) {
                note.dateCreated = new Date();
                note.noteText = noteToEdit.noteText;
                found = true;
                return;
            }
        });
        if (!found) {
            this.addNote(section, noteToEdit.noteText);
        }
        else if(this.request.id){
            this.save();
        }
    }

    public saveRequestCustomerInfo(){
        if (this.request.requestInformation.organization && this.request.requestInformation.customer) {
            return this.RequestApi.saveRequestCustomerInfo(angular.toJson(this.request)).then((response:IHttpPromiseCallbackArg<any>) => {
                if(response.data) {
                    this.request.wfProcessing.history = angular.copy(response.data.wfProcessing.history);
                    this.getRequests();
                    this.NotificationService.successMsg(this.NotificationMessages.REQUEST_SAVE_SUCCESS);
                    return true;
                }else{
                    this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
                    return false;
                }
            }, (errResponse:IHttpPromiseCallbackArg<any>) => {
                this.$log.error("%s - Error saving request: %s", JSON.stringify(errResponse));
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
            });
        }
        else {
            this.NotificationService.errorMsg("This request needs an <i class='bold'>Organization</i> and <i class='bold'>Customer</i> before you can save.");
        }
    }

    public saveRequestEquipmentInfo(){
        if (this.isEquipmentFormCompleted) {
            return this.RequestApi.saveRequestEquipmentInfo(angular.toJson(this.request)).then((response:IHttpPromiseCallbackArg<any>) => {
                if(response.data) {
                    this.request.wfProcessing.history = angular.copy(response.data.wfProcessing.history);
                    this.getRequests();
                    this.NotificationService.successMsg(this.NotificationMessages.REQUEST_SAVE_SUCCESS);
                    return true;
                }else{
                    this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
                    return false;
                }
            }, (errResponse:IHttpPromiseCallbackArg<any>) => {
                this.$log.error("%s - Error saving request: %s", JSON.stringify(errResponse));
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
            });
        }
        else {
            this.NotificationService.errorMsg("Further equipment information required");
        }
    }

    public saveRequestExtraItems(){
        if (this.isCompAccSuppliesFormCompleted) {
            return this.RequestApi.saveRequestExtraItems(angular.toJson(this.request)).then((response:IHttpPromiseCallbackArg<any>) => {
                if(response.data) {
                    this.request.wfProcessing.history = angular.copy(response.data.wfProcessing.history);
                    this.getRequests();
                    this.NotificationService.successMsg(this.NotificationMessages.REQUEST_SAVE_SUCCESS);
                    return true;
                }else{
                    this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
                    return false;
                }
            }, (errResponse:IHttpPromiseCallbackArg<any>) => {
                this.$log.error("%s - Error saving request: %s", JSON.stringify(errResponse));
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
            });
        }
        else {
            this.NotificationService.errorMsg("Further component information required");
        }
    }

    public saveRequestInfo(){
        if (this.isRequestFormCompleted) {
            return this.RequestApi.saveRequestInfo(angular.toJson(this.request)).then((response:IHttpPromiseCallbackArg<any>) => {
                if(response.data) {
                    this.request.wfProcessing.history = angular.copy(response.data.wfProcessing.history);
                    this.getRequests();
                    this.NotificationService.successMsg(this.NotificationMessages.REQUEST_SAVE_SUCCESS);
                    return true;
                }else{
                    this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
                    return false;
                }
            }, (errResponse:IHttpPromiseCallbackArg<any>) => {
                this.$log.error("%s - Error saving request: %s", JSON.stringify(errResponse));
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
                return false;
            })
        }
        else {
            this.NotificationService.errorMsg("Further information is required");
        }
    }

    public saveRequestSourceOfSupply(){
        if (this.isSuggestedSourceFormCompleted) {
            return this.RequestApi.saveRequestSourceOfSupply(angular.toJson(this.request)).then((response:IHttpPromiseCallbackArg<any>) => {
                if(response.data) {
                    this.request.wfProcessing.history = angular.copy(response.data.wfProcessing.history);
                    this.getRequests();
                    this.NotificationService.successMsg(this.NotificationMessages.REQUEST_SAVE_SUCCESS);
                    return true;
                }else{
                    this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
                    return false;
                }
            }, (errResponse:IHttpPromiseCallbackArg<any>) => {
                this.$log.error("%s - Error saving request: %s", JSON.stringify(errResponse));
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
            });
        }
        else {
            this.NotificationService.errorMsg("Further suggested source information required");
        }
    }

    public saveRequestTraining(){
        if (this.isTrainingFormCompleted) {
            return this.RequestApi.saveRequestTraining(angular.toJson(this.request)).then((response:IHttpPromiseCallbackArg<any>) => {
                if(response.data) {
                    this.request.wfProcessing.history = angular.copy(response.data.wfProcessing.history);
                    this.getRequests();
                    this.NotificationService.successMsg(this.NotificationMessages.REQUEST_SAVE_SUCCESS);
                    return true;
                }else{
                    this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
                    return false;
                }
            }, (errResponse:IHttpPromiseCallbackArg<any>) => {
                this.$log.error("%s - Error saving request: %s", JSON.stringify(errResponse));
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
            });
        }
        else {
            this.NotificationService.errorMsg("Further training information required");
        }
    }

    public saveSafety() {
        this.calculateTotalPrice();
        this.RequestApi.saveSafety(angular.toJson(this.request)).then((response:IHttpPromiseCallbackArg<any>) => {
            if(response.data) {
                this.request.id = angular.copy(response.data.id);
                this.request.updatedBy = angular.copy(response.data.updatedBy);
                this.request.updatedDate = angular.copy(response.data.updatedDate);
                if(this.request.wfProcessing){
                    this.request.wfProcessing.history = angular.copy(response.data.wfProcessing.history);
                }
                this.getRequests();
                this.NotificationService.successMsg(this.NotificationMessages.REQUEST_SAVE_SUCCESS);
            }else{
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
            }
        }, (errResponse:IHttpPromiseCallbackArg<any>) => {
            this.$log.error("%s - Error saving request: %s", JSON.stringify(errResponse));
            this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
        });
    }

    public saveTechnology() {
        this.calculateTotalPrice();
        this.RequestApi.saveTechnology(angular.toJson(this.request)).then((response:IHttpPromiseCallbackArg<any>) => {
            if(response.data) {
                this.request.id = angular.copy(response.data.id);
                this.request.updatedBy = angular.copy(response.data.updatedBy);
                this.request.updatedDate = angular.copy(response.data.updatedDate);
                if(this.request.wfProcessing){
                    this.request.wfProcessing.history = angular.copy(response.data.wfProcessing.history);
                }
                this.getRequests();
                this.NotificationService.successMsg(this.NotificationMessages.REQUEST_SAVE_SUCCESS);
            }else{
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
            }
        }, (errResponse:IHttpPromiseCallbackArg<any>) => {
            this.$log.error("%s - Error saving request: %s", JSON.stringify(errResponse));
            this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
        });
    }

    public setPrimarySource(sourceToUpdate){
        angular.forEach(this.request.requestInformation.suggestedSources,(source: any) => {
            if(source != sourceToUpdate) {
                source.primarySource = false;
            }
        });
    }

    public submit(){
        if (this.isRequestValid()) {
            this.calculateTotalPrice();
            this.RequestApi.submitForProcessing(angular.toJson(this.request)).then((result:any) => {
                this.request = result.data;
                //this.buildWeighIns(this.request.id);
                this.getRequests();
                this.$state.go(this.StateConstants.EQUIP_REQUEST_MY_REQUESTS);
                this.NotificationService.successMsg(this.NotificationMessages.REQUEST_SUBMIT_SUCCESS);
                return true;
            }, (errResponse:IHttpPromiseCallbackArg<any>) => {
                this.$log.error("%s - Error submitting request", this.serviceName);
                this.NotificationService.errorMsg(this.NotificationMessages.REQUEST_SUBMIT_ERROR);
                return true;
            });

        }
        else {
            this.$log.debug("submitting valid request error message:" + this.missingRequiredEntryMsg);
            this.NotificationService.errorMsg(this.missingRequiredEntryMsg, 4000);
            return true;
        }
    }

    public verifyCompAccSuppliesForm(){
        var complete = true;
        angular.forEach(this.request.requestInformation.extraItems, (item) => {
            if(item.type == null || item.itemDescription == null){
                complete = false;
                return;
            }
        });
        this.isCompAccSuppliesFormCompleted = complete;
        this.calculateTotalCompAccSupplies();
    }

    public verifyRequest(){
        this.verifyAPrimarySourceBeenSet();
        this.verifyTrainingForm();
        this.verifyRequestForm();
        this.verifyEquipmentCriteria();
        this.verifyCompAccSuppliesForm();
        this.verifySuggestedSourceForm();
        this.verifyMaintenanceForm();
    }

    //The ? makes it optional
    public verifyEquipmentCriteria(requiresOtherSystems?){
        if((this.request.requestInformation.equipment.catalogId&&
            this.request.requestInformation.equipment.isFoundInCatalog) ||
            (this.request.requestInformation.equipment.description &&
            this.request.requestInformation.equipment.manufacturer) &&
            this.request.requestInformation.quantityRequested != null &&
            this.request.requestInformation.equipment.unitCost != null
        ){
            if((requiresOtherSystems &&
                this.request.requestInformation.equipment.otherSystemRequired) ||
                !requiresOtherSystems) {
                this.isEquipmentFormCompleted = true;
            }
            else{
                this.isEquipmentFormCompleted = false;
            }
        } else{
            this.isEquipmentFormCompleted = false;
        }
        this.calculateTotalPrice();
    }

    public verifyMaintenanceForm(acceptanceInspection?,installationRequired?,provideMaintenance?,tmdeRequired?){
        var complete = true;
        if(!this.request.maintenanceInformation.maintenanceActivity ||
            (!this.request.maintenanceInformation.maintenanceByOGA &&
            !this.request.maintenanceInformation.maintenanceByOrg &&
            !this.request.maintenanceInformation.maintenanceByService) ||
            !this.isTrainingFormCompleted){
            complete = false;
        }
        if(provideMaintenance == 'true' &&
            !this.request.maintenanceInformation.maintenanceExplanation) {
            complete = false;
        }
        if(acceptanceInspection &&
            !this.request.maintenanceInformation.acceptanceInspection) {
            complete = false;
        }
        if(tmdeRequired &&
            !this.request.maintenanceInformation.tmdeRequired) {
            complete = false;
        }
        if(installationRequired &&
            !this.request.maintenanceInformation.installationRequired) {
            complete = false;
        }
        angular.forEach(this.request.maintenanceInformation.literature, (lit) => {
            if(!lit.type || !lit.cost || !lit.quantity){
                complete = false;
                return;
            }
        });
        this.isMaintenanceFormCompleted = complete;
    }

    public verifyRequestForm(){
        var complete = true;
        if(!this.request.requestInformation.requestTitle ||
            !this.request.requestInformation.requestNumber ||
            !this.request.requestInformation.criticalCode ||
            !this.request.requestInformation.missionImpact ||
            !this.request.requestInformation.requestType ||
            !this.request.requestInformation.requestReason ||
            (this.request.requestInformation.requestedDeliveryDate &&
            !this.request.requestInformation.requestedDeliveryDateReason)){
            complete = false;
        }
        else{
            angular.forEach(this.request.requestInformation.replacedItems, (item) => {
                if(!item.ecn){
                    complete = false;
                    return;
                }
            });
        }
        this.isRequestFormCompleted = complete;
        this.calculateTotalPrice();
    }

    public verifySoftwareForm(){
        var complete = true;
        angular.forEach(this.request.technologyInformation.software, (soft) => {
            if(!soft.type ||
                !soft.title ||
                !soft.version){
                complete = false;
                return;
            }
        });
        this.isSoftwareFormCompleted = complete;
    }

    public verifySuggestedSourceForm(){
        var complete = true;
        angular.forEach(this.request.requestInformation.suggestedSources, (source) => {
            if(source.creditCard == null ||
                !source.sourceName ||
                !source.sourceDivision ||
                !source.pocName ||
                    //TODO figure out a way to validate email and phone. Shouldn't say the form is good without checking these
                !source.pocEmail ||
                !source.pocPhone1 ||
                !this.isThereAPrimarySource){
                complete = false;
                return;
            }
        });
        if(this.request.requestInformation.suggestedSources.length == 0){
            complete = false;
        }
        this.isSuggestedSourceFormCompleted = complete;
        this.calculateTotalPrice();
    }

    public verifyTrainingForm(){
        var complete = true;
        angular.forEach(this.request.requestInformation.training, (train) => {
            if(!train.trainees || !train.people || !train.location){
                complete = false;
                return;
            }
        });
        this.isTrainingFormCompleted = complete;
        this.calculateTotalTraining();
    }


    private calculateTotalCompAccSupplies(){
        this.request.requestInformation.totalCompAccSupplies = 0;
        angular.forEach(this.request.requestInformation.extraItems,(item) =>{
            this.request.requestInformation.totalCompAccSupplies = this.request.requestInformation.totalCompAccSupplies + (item.unitCost * item.quantity);
        });
        this.calculateTotalPrice();
    }

    private calculateTotalTraining(){
        this.request.requestInformation.totalTrainingCost = 0;
        angular.forEach(this.request.requestInformation.training,(train) =>{
            this.request.requestInformation.totalTrainingCost = this.request.requestInformation.totalTrainingCost + ((train.registrationCost+train.perDiem+train.travelCost)*train.people*train.days);
        });
        this.calculateTotalPrice();
    }

    private calculateTotalInstallationCosts(){
        this.request.maintenanceInformation.totalInstallationCosts = 0;
        angular.forEach(this.request.maintenanceInformation.installationRequirements,(installation) =>{
            this.request.maintenanceInformation.totalInstallationCosts = this.request.maintenanceInformation.totalInstallationCosts + installation.cost;
        });
        this.calculateTotalPrice();
    }

    private calculateTotalLiteratureCosts(){
        this.request.maintenanceInformation.totalLiteratureCosts = 0;
        angular.forEach(this.request.maintenanceInformation.literature,(lit) =>{
            this.request.maintenanceInformation.totalLiteratureCosts = this.request.maintenanceInformation.totalLiteratureCosts + lit.cost * lit.quantity;
        });
        this.verifyMaintenanceForm();
        this.calculateTotalPrice();
    }

    private verifyAPrimarySourceBeenSet(){
        this.isThereAPrimarySource = false;
        angular.forEach(this.request.requestInformation.suggestedSources,(source) => {
            if(source.primarySource){
                this.isThereAPrimarySource = true;
                return;
            }
        });
    }
}