import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {NoteItem} from "../_models/noteItem.model";
import {CatalogItem} from "../../../catalog/_models/catalogItem.model";
import {EquipmentRequirement} from "../_models/equipmentRequirement.model";
import {ExtraItem} from "../_models/extraItem.model";
import {RequestItem} from '../_models/requestItem.model';
import {Software} from '../_models/software.model';
import {SuggestedSourceItem} from "../_models/suggestedSourceItem.model";
import {CurrentUserProfile} from '../../../../_models/currentUserProfile.model';
import {InstallRequirement} from "../_models/installRequirement.model";
import {Literature} from "../_models/literature.model";
import {ReplacementItem} from "../_models/replacementItem.model";
import {TrainingItem} from "../_models/trainingItem.model";

export interface IRequestService {
    
}

export class RequestService implements IRequestService {
    private serviceName: string = "Requests Service";

    public activeRequestTable:any;
    public allEquipmentRequests:Array<RequestItem>;
    public isRequestIdentifiersFormCompleted:boolean;
    public isCustomerFormCompleted:boolean;
    public isEquipmentFormCompleted: boolean = false;
    public isFacilitiesCompleted:boolean = false;
    public isRequestFormCompleted:boolean;
    public isCompAccSuppliesFormCompleted:boolean = true;
    public isMaintenanceFormCompleted:boolean = false;
    public isSafetyCompleted:boolean = false;
    public isSoftwareFormCompleted:boolean = true;
    public isSuggestedSourceFormCompleted:boolean = false;
    public isTechnologiesComplete:boolean = false;
    public isThereAPrimarySource:boolean = false;
    public isTrainingFormCompleted:boolean = true;
    public missingRequiredEntryMsg;
    public myActiveRequestTable:any;
    public request:RequestItem = new RequestItem();
    public requestHistoryTable:any;
    public selectedNoteSection:string = "";
    public selectedOrgObj:any;
    public totalNotIncludedTrainingRegistrationCost:number = 0;
    public uploader:any = null;

    /*Temporary until the datamodel gets updated*/
    public attachmentSection:string = "";

    // @ngInject
    constructor(private $filter, private $http, private $log, private $state, private ContentConstants,
                private dataService, private datatableService, private FileUploader, private NotificationMessages,
                private NotificationService, private StateConstants, private RequestApi, private UserService) {
        this.$log.debug("%s - Start", this.serviceName);

        this.uploader = new FileUploader({
           // url: this.App.getBtBaseUrl() + 'EquipmentManagement/Api/saveDocument',
            headers: {'Content-Type': 'multipart/formdata'}
        });

        this.uploader.filters.push({
            name: 'customFilter',
            fn: function(item /*{File|FileLikeObject}*/, options) {
                return this.queue.length < 10;
            }
        });

        this.uploader.onWhenAddingFileFailed = function(item /*{File|FileLikeObject}*/, filter, options) {
            console.info('onWhenAddingFileFailed', item, filter, options);
        };
        this.uploader.onAfterAddingFile = function(fileItem) {
            console.info('onAfterAddingFile', fileItem);
        };
        this.uploader.onAfterAddingAll = function(addedFileItems) {
            console.info('onAfterAddingAll', addedFileItems);
        };
        this.uploader.onBeforeUploadItem = function(item) {
            console.info('onBeforeUploadItem', item);
        };
        this.uploader.onProgressItem = function(fileItem, progress) {
            console.info('onProgressItem', fileItem, progress);
        };
        this.uploader.onProgressAll = function(progress) {
            console.info('onProgressAll', progress);
        };
        this.uploader.onSuccessItem = function(fileItem, response, status, headers) {
            console.info('onSuccessItem', fileItem, response, status, headers);
        };
        this.uploader.onErrorItem = function(fileItem, response, status, headers) {
            console.info('onErrorItem', fileItem, response, status, headers);
        };
        this.uploader.onCancelItem = function(fileItem, response, status, headers) {
            console.info('onCancelItem', fileItem, response, status, headers);
        };
        this.uploader.onCompleteItem = function(fileItem, response, status, headers) {
            console.info('onCompleteItem', fileItem, response, status, headers);
        };
        this.uploader.onCompleteAll = function() {
            console.info('onCompleteAll');
        };
    }

    public addCatalogInfoToRequest(catalogItem){
        this.request.catalogItem = catalogItem;
        this.request.requestInformation.equipment.isFoundInCatalog = true;

        // Populate or overwrite existing field entries
        this.request.requestInformation.equipment.catalogId = catalogItem.itemId;
        this.request.requestInformation.equipment.isFoundInCatalog = true;
        this.request.requestInformation.equipment.manufacturer = catalogItem.manufacturerNm;
        this.request.requestInformation.equipment.model = catalogItem.eqpmtModelNum;
        this.request.requestInformation.equipment.nomenclature = catalogItem.deviceText;
        this.request.requestInformation.equipment.deviceCode = catalogItem.deviceCd;
        this.request.requestInformation.equipment.unitCost = catalogItem.burdenedPriceAmt;
        if(catalogItem.eiMaintReqrCd == 'Y'){
            this.request.maintenanceInformation.acceptanceInspection = true;
        }
        else{
            this.request.maintenanceInformation.acceptanceInspection = false;
        }
        this.verifyMaintenanceForm();

        var suggSourceItem = new SuggestedSourceItem();
        suggSourceItem.sourceName = catalogItem.supplierNm;
        this.addSuggestedSource(suggSourceItem);
        //suggSourceItem.primarySource = true;
        //this.request.requestInformation.suggestedSources.push(suggSourceItem);

        this.request.requestInformation.quantityRequested = catalogItem.quantity;
        if(!this.request.requestInformation.quantityRequested || this.request.requestInformation.quantityRequested == 0){
            this.request.requestInformation.quantityRequested = 1;
        }
        this.calculateTotalRequisitionCost();
    }

    public buildRequestFromCatalog(catalogItem){
        this.request = new RequestItem();
        this.addCatalogInfoToRequest(catalogItem);
    }

    public buildRequestFromHistory(oldRequest){
        this.request = new RequestItem();
        this.request.requestInformation.submitter.userId = this.UserService.currentUser.id;
        this.request.requestInformation.submitter.email = this.UserService.currentUser.email;
        this.request.requestInformation.submitter.firstName = this.UserService.currentUser.firstName;
        this.request.requestInformation.submitter.lastName = this.UserService.currentUser.lastName;
        this.request.requestInformation.submitter.phoneNumber = this.UserService.currentUser.phoneNumbers[0].value;
        this.request.requestInformation.submitter.dodaac = this.UserService.currentUser.dodaac;
        this.request.requestInformation.submitter.regionCode = this.UserService.currentUser.regionCode;
        this.request.requestInformation.submitter.serviceCode = this.UserService.currentUser.serviceCode;
        this.addCatalogInfoToRequest(oldRequest.catalogItem);

        //Set fields from the old request
        this.request.requestInformation.equipment = oldRequest.requestInformation.equipment;
        this.request.requestInformation.replacedItems = oldRequest.requestInformation.replacedItems;
        this.request.requestInformation.suggestedSources = oldRequest.requestInformation.suggestedSources;
        this.request.requestInformation.training = oldRequest.requestInformation.training;
        this.request.requestInformation.equipmentRequirements = oldRequest.requestInformation.equipmentRequirements;
        this.request.requestInformation.extraItems = oldRequest.requestInformation.extraItems;
        this.request.requestInformation.quantityRequested = oldRequest.requestInformation.quantityRequested;
        this.request.totalRequisitionCost = oldRequest.totalRequisitionCost;
        this.request.requestInformation.totalCompAccSupplies = oldRequest.requestInformation.totalCompAccSupplies;
        this.request.requestInformation.totalIncludedTrainingCost = oldRequest.requestInformation.totalIncludedTrainingCost;
        this.request.requestInformation.totalTDYCost = oldRequest.requestInformation.totalTDYCost;

        //clears the org
        this.selectedOrgObj = null;
        this.verifyRequest();
    }

    public addAttachment(section){
        this.attachmentSection = section;
    }

    public addEquipmentRequirement(){
        var requirement = new EquipmentRequirement();
        this.request.requestInformation.equipmentRequirements.push(requirement);
    }

    public addExtraItem(type){
        var extraItem = new ExtraItem();
        extraItem.type = type;
        this.request.requestInformation.extraItems.push(extraItem);
        this.verifyCompAccSuppliesForm();
    }

    public addInstallationRequirement() {
        var installReq = new InstallRequirement();
        installReq.cost = 0;
        this.request.maintenanceInformation.installationRequirements.push(installReq);
        this.calculateTotalInstallationCosts();
    }

    public addItemBeingReplaced() {
        var replaceItem = new ReplacementItem();
        this.request.requestInformation.replacedItems.push(replaceItem);
        this.verifyRequestForm();
    }

    public addLiterature() {
        var literature = new Literature();
        this.request.maintenanceInformation.literature.push(literature);
        this.calculateTotalLiteratureCosts();
    }

    public addNote(section:string, text:string){
        this.request.notes.push(new NoteItem({
                                        section:section,
                                        dateCreated:new Date(),
                                        firstName:this.UserService.currentUser.firstName,
                                        lastName:this.UserService.currentUser.lastName,
                                        noteText:text}));
        //This will save the note to the database if the request has already been saved to the database.
        if(this.request.id){
            this.save();
        }
    }


    public addSoftware() {
        var software = new Software();
        this.request.technologyInformation.software.push(software);
        this.verifySoftwareForm();
    }

    public addSuggestedSource(source:any){
        if(this.request.requestInformation.suggestedSources.length==0){
            var suggSourceItem = new SuggestedSourceItem();
            suggSourceItem.primarySource = true;
            if(source) {
                suggSourceItem.sourceName = source.sourceName;
            }
            this.request.requestInformation.suggestedSources.push(suggSourceItem);
        }
        else {
            this.request.requestInformation.suggestedSources.push(new SuggestedSourceItem(source));
        }

        this.verifyAPrimarySourceBeenSet();
        this.verifySuggestedSourceForm();
    }

    public addTraining(trainee){
        var trainingItem = new TrainingItem();
        trainingItem.trainees = trainee;
        this.request.requestInformation.training.push(trainingItem);
        this.calculateTotalTraining();
        this.verifyTrainingForm();
    }

    public buildReviews(requestId){
        return this.RequestApi.buildReviews(requestId).then((result) => {
            if(result && result.data){
                this.request = result.data;
                return true;
            }}, (errResponse:IHttpPromiseCallbackArg<any>) => {
            this.$log.error("Error retrieving request");
            this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
            return false;
        });
    }

    public calculateTotalRequisitionCost(){
        //These are the cost included in the requisition cost
        this.request.totalRequisitionCost = this.request.requestInformation.totalIncludedTrainingCost +
                                this.request.maintenanceInformation.estimatedAnnualServiceCost +
                                this.request.maintenanceInformation.totalIncludedInstallationCosts +
                                this.request.maintenanceInformation.totalLiteratureCosts +
                                this.request.requestInformation.totalCompAccSupplies +
                                this.request.requestInformation.equipment.unitCost * this.request.requestInformation.quantityRequested;
        //These are other costs that are not included
        this.request.totalOtherCost = 0;
        if(!this.request.facilityInformation.includedCost){
            this.request.totalOtherCost = this.request.facilityInformation.facilityModificationCost;
        }
        else{
            this.request.totalRequisitionCost = this.request.totalRequisitionCost + this.request.facilityInformation.facilityModificationCost;
        }
        this.request.totalOtherCost =  this.request.totalOtherCost + this.request.maintenanceInformation.totalOtherInstallationCosts;
        this.request.totalOtherCost =  this.request.totalOtherCost + this.request.requestInformation.totalTDYCost;
        this.request.totalOtherCost =  this.request.totalOtherCost + this.totalNotIncludedTrainingRegistrationCost;
    }

    public clearCatalogItem(){
        this.request.catalogItem = null;
        this.request.requestInformation.equipment.manufacturer = "";
        this.request.requestInformation.equipment.nomenclature = "";
        this.request.requestInformation.equipment.deviceCode = "";
        this.request.requestInformation.equipment.model = "";
        this.request.requestInformation.equipment.catalogId = "";
        this.request.requestInformation.equipment.unitCost = null;
        this.request.requestInformation.equipment.isFoundInCatalog = false;
        this.NotificationService.errorMsg("Please update the <i class=bold>Equipment Information</i> of this request");
        this.verifyEquipmentCriteria();
        this.save();
    }

    public clearItemBeingReplaced(){
        this.request.requestInformation.replacedItems = [];
        this.verifyEquipmentCriteria();
    }

    public clearSuggestedSources(){
        this.request.requestInformation.suggestedSources = [];
    }

    public clearRequest(){
        this.request = new RequestItem();
        this.selectedOrgObj = null;
    }

    public createActiveTable(data){
        this.activeRequestTable = this.datatableService.createNgTable(data, 25, { updatedDate: 'desc' });
    }

    public createHistoryTable(data){
        this.requestHistoryTable = this.datatableService.createNgTable(data, 25, { updatedDate: 'desc' });
    }

    public filterActiveRequests(requestList){
        return this.$filter('filter')(requestList, (o) => {
            return o.wfProcessing == null || !o.wfProcessing.isCompleted;
        });
    }


    public filterCompletedRequests(requestList){
        return this.$filter('filter')(requestList, (o) => {
            return o.wfProcessing && o.wfProcessing.isCompleted;
        });
    }
    //
    public filterMyActiveRequests(data){
        return this.$filter('filter')(data, (o) => {
            if(o.wfProcessing == null || !o.wfProcessing.isCompleted){
                var reviewUser = false;
                var levelOwnerRole = false;
                var reviewOwnerRole = false;
                return (o.requestInformation.submitter.userId == this.UserService.currentUser.id ||
                    reviewUser ||
                    levelOwnerRole ||
                    reviewOwnerRole)
            }
            else {return false}
        });
    }

    public filterMyRequestHistory(data){
        return this.$filter('filter')(data, (o) => {
            if(o.wfProcessing){
                var reviewUser = false;
                var levelOwnerRole = false;
                return (o.requestInformation.submitter.userId == this.UserService.currentUser.id  ||
                reviewUser ||
                levelOwnerRole) &&
                o.wfProcessing.isCompleted;}
            else {return false}
        });
    }

    public getRequests(){
        return this.RequestApi.getEquipmentRequests().then((result) => {
            if(result && result.data){
                this.allEquipmentRequests = result.data;
                this.createActiveTable(this.filterActiveRequests(this.allEquipmentRequests));
                this.createHistoryTable(this.filterCompletedRequests(this.allEquipmentRequests));
                return this.allEquipmentRequests;
            }}, (errResponse:IHttpPromiseCallbackArg<any>) => {
            this.$log.error("Error retrieving request from users id.");
            this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
        });
    }

    public hasNotes(section){
        var found = false;
        angular.forEach(this.request.notes,(note)=>{
            if(note.section === section){
                found = true;
                return;
            }
        });
        return found;
    }

    public isRequestValid() {
        this.missingRequiredEntryMsg = "";
        if (!this.request.requestInformation.requestTitle) {
            this.missingRequiredEntryMsg = "Request Title is required";
            return false;
        } else if (!this.isRequestFormCompleted) {
            this.missingRequiredEntryMsg = "Further request information required";
            return false;
        } else if (!this.isCustomerFormCompleted) {
            this.missingRequiredEntryMsg = "Further customer information required";
            return false;
        }  else if(!this.verifyReplacedEquipment()){
            this.missingRequiredEntryMsg = "Please identify the equipment that is being replaced in the <i class=bold>Equipment Information</i> section";
            return false;
        } else if (!this.isEquipmentFormCompleted) {
            this.missingRequiredEntryMsg = "Further equipment information required";
            return false;
        } else if (!this.isCompAccSuppliesFormCompleted) {
            this.missingRequiredEntryMsg = "Further component information required";
            return false;
        }  else if (!this.isThereAPrimarySource) {
            this.missingRequiredEntryMsg = "Please select one of your Sources of Supply as the <i class=bold>Primary Source</i>";
            return false;
        } else if (!this.isSuggestedSourceFormCompleted) {
            this.missingRequiredEntryMsg = "Further suggested source information required";
            return false;
        } else if (!this.isTrainingFormCompleted) {
            this.missingRequiredEntryMsg = "Further training information required";
            return false;
        } else{
            return true;
        }
    }

    public openNotes(section){
        this.selectedNoteSection = section;
    }

    public removeExtraItem(itemToRemove){
        this.request.requestInformation.extraItems.splice(this.request.requestInformation.extraItems.indexOf(itemToRemove), 1);
        this.calculateTotalCompAccSupplies();
    }

    public removeEquipmentRequirement(requirement){
        this.request.requestInformation.equipmentRequirements.splice(this.request.requestInformation.equipmentRequirements.indexOf(requirement),1);
    }

    //public removeItemBeingReplaced(item){
    //    this.request.replacedItems.splice(this.request.replacedItems.indexOf(item), 1);
    //}

    public removeInstallationRequirement(req){
        this.request.maintenanceInformation.installationRequirements.splice(this.request.maintenanceInformation.installationRequirements.indexOf(req), 1);
        this.calculateTotalInstallationCosts();
    }

    public removeItemBeingReplaced(item){
        this.request.requestInformation.replacedItems.splice(this.request.requestInformation.replacedItems.indexOf(item), 1);
    }

    public removeLiterature(literature){
        this.request.maintenanceInformation.literature.splice(this.request.maintenanceInformation.literature.indexOf(literature), 1);
        this.calculateTotalLiteratureCosts();
    }

    public removeNote(noteToBeDeleted, id) {
        angular.element(id).addClass("animated fadeOut");
        angular.forEach(this.request.notes, (note) => {
            if (note === noteToBeDeleted) {
                this.request.notes.splice(this.request.notes.indexOf(note), 1);
            }
        });
        if (this.$filter('filter')(this.request.notes, {section: noteToBeDeleted.section}, true).length < 1) {
            angular.element('#noteTable').addClass("animated fadeOut");
        }
        if (this.request.notes.length < 1) {
            angular.element('#summaryNoteTable').addClass("animated fadeOut");
        }
    }

    public removeSoftware(softwareToRemove){
        this.request.technologyInformation.software.splice(this.request.technologyInformation.software.indexOf(softwareToRemove), 1);
    }

    public removeSuggestedSource(sourceToRemove){
        this.request.requestInformation.suggestedSources.splice(this.request.requestInformation.suggestedSources.indexOf(sourceToRemove),1);
        if(this.request.requestInformation.suggestedSources.length > 0){
            if(sourceToRemove.primarySource) {
                this.request.requestInformation.suggestedSources[0].primarySource = true;
            }
        }
        this.verifyAPrimarySourceBeenSet();
        this.verifySuggestedSourceForm();
    }

    public removeTraining(trainingToRemove){
        this.request.requestInformation.training.splice(this.request.requestInformation.training.indexOf(trainingToRemove), 1);
        this.verifyTrainingForm();
        this.calculateTotalTraining();
    }

    public save() {
        if(this.request.requestInformation.requestTitle){
            this.calculateTotalRequisitionCost();
                return this.RequestApi.saveEquipmentRequest(angular.toJson(this.request)).then((response:IHttpPromiseCallbackArg<any>) => {
                if (response.data) {
                    this.request.id = angular.copy(response.data.id);
                    this.request.updatedBy = angular.copy(response.data.updatedBy);
                    this.request.updatedDate = angular.copy(response.data.updatedDate);
                    this.request.requestInformation.requestNumber = angular.copy(response.data.requestInformation.requestNumber);
                    this.getRequests();
                    this.NotificationService.successMsg(this.NotificationMessages.REQUEST_SAVE_SUCCESS);
                    return true;
                } else {
                    this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
                    return false;
                }
            }, (errResponse:IHttpPromiseCallbackArg<any>) => {
                this.$log.error("%s - Error saving request: %s", JSON.stringify(errResponse));
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
                    return false;
                });
            }
        else
            {
                this.NotificationService.errorMsg("This request needs a <i class='bold'>Title</i> before you can save.");
            }

    }

    public saveFacilities() {
        if(!this.request.wfProcessing){
            this.save();
        }else {
            this.calculateTotalRequisitionCost();
            if (this.isFacilitiesCompleted) {
                this.RequestApi.saveFacilities(angular.toJson(this.request)).then((response:IHttpPromiseCallbackArg<any>) => {
                    if (response.data) {
                        this.request.id = angular.copy(response.data.id);
                        this.request.updatedBy = angular.copy(response.data.updatedBy);
                        this.request.updatedDate = angular.copy(response.data.updatedDate);
                        if (this.request.wfProcessing) {
                            this.request.wfProcessing.history = angular.copy(response.data.wfProcessing.history);
                        }
                        this.getRequests();
                        this.NotificationService.successMsg(this.NotificationMessages.REQUEST_FACILITIES_SAVE_SUCCESS);
                    } else {
                        this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
                    }
                }, (errResponse:IHttpPromiseCallbackArg<any>) => {
                    this.$log.error("%s - Error saving request: %s", JSON.stringify(errResponse));
                    this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
                });
            }
            else{
                this.NotificationService.errorMsg(this.NotificationMessages.REQUEST_INSUFFICIENT_DATA);
            }
        }
    }

    public saveMaintenance() {
        if(!this.request.wfProcessing){
            this.save();
        }else {
            this.calculateTotalRequisitionCost();
            if (this.isMaintenanceFormCompleted) {
                this.RequestApi.saveMaintenance(angular.toJson(this.request)).then((response:IHttpPromiseCallbackArg<any>) => {
                    if (response.data) {
                        this.request.id = angular.copy(response.data.id);
                        this.request.updatedBy = angular.copy(response.data.updatedBy);
                        this.request.updatedDate = angular.copy(response.data.updatedDate);
                        if (this.request.wfProcessing) {
                            this.request.wfProcessing.history = angular.copy(response.data.wfProcessing.history);
                        }
                        this.getRequests();
                        this.NotificationService.successMsg(this.NotificationMessages.REQUEST_MAINTENANCE_SAVE_SUCCESS);
                    } else {
                        this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
                    }
                }, (errResponse:IHttpPromiseCallbackArg<any>) => {
                    this.$log.error("%s - Error saving request: %s", JSON.stringify(errResponse));
                    this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
                });
            }
            else{
                this.NotificationService.errorMsg(this.NotificationMessages.REQUEST_INSUFFICIENT_DATA);
            }
        }
    }

    public saveNote(section, noteToEdit) {
        var found = false;
        angular.forEach(this.request.notes, (note:any) => {
            //This won't work without the getTime() otherwise it's always false
            if (angular.isDefined(noteToEdit.dateCreated) && note.dateCreated.getTime() == noteToEdit.dateCreated.getTime()) {
                note.dateCreated = new Date();
                note.noteText = noteToEdit.noteText;
                found = true;
                return;
            }
        });
        if (!found) {
            this.addNote(section, noteToEdit.noteText);
        }
        else if(this.request.id){
            this.save();
        }
    }

    public saveRequestCustomerInfo(){
        if (this.isCustomerFormCompleted) {
            return this.RequestApi.saveRequestCustomerInfo(angular.toJson(this.request)).then((response:IHttpPromiseCallbackArg<any>) => {
                if(response.data) {
                    this.request.wfProcessing.history = angular.copy(response.data.wfProcessing.history);
                    this.getRequests();
                    this.NotificationService.successMsg(this.NotificationMessages.REQUEST_SAVE_SUCCESS);
                    return true;
                }else{
                    this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
                    return false;
                }
            }, (errResponse:IHttpPromiseCallbackArg<any>) => {
                this.$log.error("%s - Error saving request: %s", JSON.stringify(errResponse));
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
            });
        }
        else {
            this.NotificationService.errorMsg("Further customer information required");
        }
    }

    public saveRequestEquipmentInfo(){
        if (this.isEquipmentFormCompleted) {
            return this.RequestApi.saveRequestEquipmentInfo(angular.toJson(this.request)).then((response:IHttpPromiseCallbackArg<any>) => {
                if(response.data) {
                    this.request.wfProcessing.history = angular.copy(response.data.wfProcessing.history);
                    this.getRequests();
                    this.NotificationService.successMsg(this.NotificationMessages.REQUEST_SAVE_SUCCESS);
                    return true;
                }else{
                    this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
                    return false;
                }
            }, (errResponse:IHttpPromiseCallbackArg<any>) => {
                this.$log.error("%s - Error saving request: %s", JSON.stringify(errResponse));
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
            });
        }
        else {
            this.NotificationService.errorMsg("Further equipment information required");
        }
    }

    public saveRequestExtraItems(){
        if (this.isCompAccSuppliesFormCompleted) {
            return this.RequestApi.saveRequestExtraItems(angular.toJson(this.request)).then((response:IHttpPromiseCallbackArg<any>) => {
                if(response.data) {
                    this.request.wfProcessing.history = angular.copy(response.data.wfProcessing.history);
                    this.getRequests();
                    this.NotificationService.successMsg(this.NotificationMessages.REQUEST_SAVE_SUCCESS);
                    return true;
                }else{
                    this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
                    return false;
                }
            }, (errResponse:IHttpPromiseCallbackArg<any>) => {
                this.$log.error("%s - Error saving request: %s", JSON.stringify(errResponse));
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
            });
        }
        else {
            this.NotificationService.errorMsg("Further component information required");
        }
    }

    public saveRequestInfo(){
        if (this.isRequestFormCompleted) {
            return this.RequestApi.saveRequestInfo(angular.toJson(this.request)).then((response:IHttpPromiseCallbackArg<any>) => {
                if(response.data) {
                    this.request.wfProcessing.history = angular.copy(response.data.wfProcessing.history);
                    this.getRequests();
                    this.NotificationService.successMsg(this.NotificationMessages.REQUEST_SAVE_SUCCESS);
                    return true;
                }else{
                    this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
                    return false;
                }
            }, (errResponse:IHttpPromiseCallbackArg<any>) => {
                this.$log.error("%s - Error saving request: %s", JSON.stringify(errResponse));
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
                return false;
            })
        }
        else {
            this.NotificationService.errorMsg("Further information is required");
        }
    }

    public saveRequestSourceOfSupply(){
        if (this.isSuggestedSourceFormCompleted) {
            return this.RequestApi.saveRequestSourceOfSupply(angular.toJson(this.request)).then((response:IHttpPromiseCallbackArg<any>) => {
                if(response.data) {
                    this.request.wfProcessing.history = angular.copy(response.data.wfProcessing.history);
                    this.getRequests();
                    this.NotificationService.successMsg(this.NotificationMessages.REQUEST_SAVE_SUCCESS);
                    return true;
                }else{
                    this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
                    return false;
                }
            }, (errResponse:IHttpPromiseCallbackArg<any>) => {
                this.$log.error("%s - Error saving request: %s", JSON.stringify(errResponse));
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
            });
        }
        else {
            this.NotificationService.errorMsg("Further suggested source information required");
        }
    }

    public saveRequestTraining(){
        if (this.isTrainingFormCompleted) {
            return this.RequestApi.saveRequestTraining(angular.toJson(this.request)).then((response:IHttpPromiseCallbackArg<any>) => {
                if(response.data) {
                    this.request.wfProcessing.history = angular.copy(response.data.wfProcessing.history);
                    this.getRequests();
                    this.NotificationService.successMsg(this.NotificationMessages.REQUEST_SAVE_SUCCESS);
                    return true;
                }else{
                    this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
                    return false;
                }
            }, (errResponse:IHttpPromiseCallbackArg<any>) => {
                this.$log.error("%s - Error saving request: %s", JSON.stringify(errResponse));
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
            });
        }
        else {
            this.NotificationService.errorMsg("Further training information required");
        }
    }

    public saveSafety() {
        if(!this.request.wfProcessing){
            this.save();
        }else {
            this.calculateTotalRequisitionCost();
            if (this.isSafetyCompleted) {
                this.RequestApi.saveSafety(angular.toJson(this.request)).then((response:IHttpPromiseCallbackArg<any>) => {
                    if (response.data) {
                        this.request.id = angular.copy(response.data.id);
                        this.request.updatedBy = angular.copy(response.data.updatedBy);
                        this.request.updatedDate = angular.copy(response.data.updatedDate);
                        if (this.request.wfProcessing) {
                            this.request.wfProcessing.history = angular.copy(response.data.wfProcessing.history);
                        }
                        this.getRequests();
                        this.NotificationService.successMsg(this.NotificationMessages.REQUEST_SAFETY_SAVE_SUCCESS);
                    } else {
                        this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
                    }
                }, (errResponse:IHttpPromiseCallbackArg<any>) => {
                    this.$log.error("%s - Error saving request: %s", JSON.stringify(errResponse));
                    this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
                });
            }
            else{
                this.NotificationService.errorMsg(this.NotificationMessages.REQUEST_INSUFFICIENT_DATA);
            }
        }
    }

    public saveTechnology() {
        if(!this.request.wfProcessing){
            this.save();
        }else {
            this.calculateTotalRequisitionCost();
            if (this.isTechnologiesComplete) {
                this.RequestApi.saveTechnology(angular.toJson(this.request)).then((response:IHttpPromiseCallbackArg<any>) => {
                    if (response.data) {
                        this.request.id = angular.copy(response.data.id);
                        this.request.updatedBy = angular.copy(response.data.updatedBy);
                        this.request.updatedDate = angular.copy(response.data.updatedDate);
                        if (this.request.wfProcessing) {
                            this.request.wfProcessing.history = angular.copy(response.data.wfProcessing.history);
                        }
                        this.getRequests();
                        this.NotificationService.successMsg(this.NotificationMessages.REQUEST_TECHNOLOGY_SAVE_SUCCESS);
                    } else {
                        this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
                    }
                }, (errResponse:IHttpPromiseCallbackArg<any>) => {
                    this.$log.error("%s - Error saving request: %s", JSON.stringify(errResponse));
                    this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
                });
            }
            else{
                this.NotificationService.errorMsg(this.NotificationMessages.REQUEST_INSUFFICIENT_DATA);
            }
        }
    }

    public setPrimarySource(sourceToUpdate){
        angular.forEach(this.request.requestInformation.suggestedSources,(source: any) => {
            if(source != sourceToUpdate) {
                source.primarySource = false;
            }
        });
    }

    public submit(){
        if (this.isRequestValid()) {
            this.calculateTotalRequisitionCost();
            this.RequestApi.submitForProcessing(angular.toJson(this.request)).then((result:any) => {
                this.request = result.data;
                //this.buildReviews(this.request.id);
                this.getRequests();
                this.$state.go(this.StateConstants.EQUIP_REQUEST_MY_REQUESTS);
                this.NotificationService.successMsg(this.NotificationMessages.REQUEST_SUBMIT_SUCCESS);
                return true;
            }, (errResponse:IHttpPromiseCallbackArg<any>) => {
                this.$log.error("%s - Error submitting request", this.serviceName);
                this.NotificationService.errorMsg(this.NotificationMessages.REQUEST_SUBMIT_ERROR);
                return true;
            });

        }
        else {
            this.$log.debug("submitting valid request error message:" + this.missingRequiredEntryMsg);
            this.NotificationService.errorMsg(this.missingRequiredEntryMsg, 4000);
            return true;
        }
    }

    public verifyCompAccSuppliesForm(){
        var complete = true;
        angular.forEach(this.request.requestInformation.extraItems, (item) => {
            if(item.type == null ||
               item.itemDescription == null ||
               item.quantity == null ||
               item.unitOfPurchase == null ||
               item.unitCost == null ||
               (item.type == 'Repair Part' && item.catalogNumber == null)){
                    complete = false;
                    return;
            }
        });
        this.isCompAccSuppliesFormCompleted = complete;
        this.calculateTotalCompAccSupplies();
    }

    public verifyRequest(){
        this.verifyAPrimarySourceBeenSet();
        this.verifyCustomerForm();
        this.verifyTrainingForm();
        this.verifyRequestForm();
        this.verifyEquipmentCriteria();
        this.verifyCompAccSuppliesForm();
        this.verifySuggestedSourceForm();
        this.verifyMaintenanceForm();
    }

    public verifyCustomerForm(isFormValid?){
        if(this.request.requestInformation.organization == null||
            this.request.requestInformation.customer == null ||
            this.request.requestInformation.requestor.firstName == "" ||
            this.request.requestInformation.requestor.lastName == "" ||
            this.request.requestInformation.requestor.phoneNumber == "" ){
            this.isCustomerFormCompleted = false;
        }
        else if(isFormValid != null && !isFormValid){
                this.isCustomerFormCompleted = false;
            this.$log.debug(isFormValid);
        }
        else{
            this.isCustomerFormCompleted = true;
        }

    }

    //The ? makes it optional
    public verifyEquipmentCriteria(requiresOtherSystems?){
        if(((this.request.requestInformation.equipment.catalogId != "" &&
            this.request.requestInformation.equipment.isFoundInCatalog) ||
            (this.request.requestInformation.equipment.description != "" &&
            this.request.requestInformation.equipment.manufacturer != "")) &&
            ((this.request.requestInformation.equipment.nomenclature != "" &&
            this.request.requestInformation.equipment.deviceCode != "") ||
            (this.request.requestInformation.equipment.nomenclature == "" &&
            this.request.requestInformation.equipment.deviceCode == "")) &&
            this.request.requestInformation.quantityRequested > 0 &&
            this.request.requestInformation.equipment.unitCost != null &&
            this.verifyReplacedEquipment()
        ){
            if(requiresOtherSystems != null &&
                (requiresOtherSystems &&
                this.request.requestInformation.equipment.otherSystemRequired != '') ||
                !requiresOtherSystems) {
                this.isEquipmentFormCompleted = true;
            }
            else{
                this.isEquipmentFormCompleted = false;
            }
        }else{
            this.isEquipmentFormCompleted = false;
        }
        this.calculateTotalRequisitionCost();
    }

    public verifyMaintenanceForm(installationRequired?,provideMaintenance?,tmdeRequired?){
        var complete = true;
        if(!this.isTrainingFormCompleted){
            complete = false;
        }
        if(provideMaintenance == 'true' &&
            !this.request.maintenanceInformation.maintenanceExplanation) {
            complete = false;
        }
        if((this.request.maintenanceInformation.acceptanceInspection == null ||
            (this.request.maintenanceInformation.acceptanceInspection != null &&
            this.request.maintenanceInformation.acceptanceInspection) &&
            (this.request.maintenanceInformation.maintenanceActivity == "" ||
            this.request.maintenanceInformation.maintenanceProvidedBy == ""))) {
            complete = false;
        }
        if(this.request.maintenanceInformation.maintenanceProvidedBy &&
            !this.request.maintenanceInformation.estimatedAnnualServiceCost) {
            complete = false;
        }
        if(tmdeRequired &&
            !this.request.maintenanceInformation.tmdeRequired) {
            complete = false;
        }
        if(installationRequired &&
            !this.request.maintenanceInformation.installationRequired) {
            complete = false;
        }
        angular.forEach(this.request.maintenanceInformation.literature, (lit) => {
            if(!lit.type || !lit.cost || !lit.quantity){
                complete = false;
                return;
            }
        });
        this.isMaintenanceFormCompleted = complete;
    }

    public verifyRequestForm(isFormValid?){
        var complete = true;
        if(!this.request.requestInformation.requestTitle ||
            !this.request.requestInformation.criticalCode ||
            !this.request.requestInformation.missionImpact ||
            !this.request.requestInformation.requestType ||
            !this.request.requestInformation.requestReason ||
            (this.request.requestInformation.requestedDeliveryDate != null &&
            this.request.requestInformation.requestedDeliveryDateReason == null)){
            complete = false;
        }
        if(isFormValid != null){
            if(!isFormValid){
                complete = false;
            }
        }
        this.isRequestFormCompleted = complete;
        this.calculateTotalRequisitionCost();
    }

    private verifyReplacedEquipment(){
        var complete = true;
        angular.forEach(this.request.requestInformation.replacedItems, (item) => {
            if(!item.ecn ||
                !item.name ||
                !item.disposal){
                complete = false;
                return;
            }
        });
        return complete;
    }

    public verifySoftwareForm(){
        var complete = true;
        angular.forEach(this.request.technologyInformation.software, (soft) => {
            if(!soft.type ||
                !soft.title ||
                !soft.version){
                complete = false;
                return;
            }
        });
        this.isSoftwareFormCompleted = complete;
    }

    public verifySuggestedSourceForm(isFormValid?){
        var complete = true;
        angular.forEach(this.request.requestInformation.suggestedSources, (source) => {
            if(source.creditCard == null ||
                !source.sourceName ||
                !this.isThereAPrimarySource){
                complete = false;
                return;
            }
        });
        if(this.request.requestInformation.suggestedSources.length == 0){
            complete = false;
        }
        if(isFormValid != null){
            if(!isFormValid){
                complete = false;
            }
        }
        this.isSuggestedSourceFormCompleted = complete;
        this.calculateTotalRequisitionCost();
    }

    public verifyTrainingForm(){
        var complete = true;
        angular.forEach(this.request.requestInformation.training, (train) => {
            if(!train.trainees ||
                !train.people ||
                !train.location){
                complete = false;
                return;
            }
        });
        this.isTrainingFormCompleted = complete;
        this.calculateTotalTraining();
        this.verifyMaintenanceForm();
    }


    private calculateTotalCompAccSupplies(){
        this.request.requestInformation.totalCompAccSupplies = 0;
        angular.forEach(this.request.requestInformation.extraItems,(item) =>{
            this.request.requestInformation.totalCompAccSupplies = this.request.requestInformation.totalCompAccSupplies + (item.unitCost * item.quantity);
        });
        this.calculateTotalRequisitionCost();
    }

    private calculateTotalTraining(){
        this.request.requestInformation.totalIncludedTrainingCost = 0;
        this.request.requestInformation.totalTDYCost = 0;
        this.totalNotIncludedTrainingRegistrationCost = 0;
        angular.forEach(this.request.requestInformation.training,(train) =>{
            if(train.includedCost) {
                this.request.requestInformation.totalIncludedTrainingCost = this.request.requestInformation.totalIncludedTrainingCost + train.registrationCost * train.people;
            }else{
                this.totalNotIncludedTrainingRegistrationCost = this.totalNotIncludedTrainingRegistrationCost + train.registrationCost * train.people;
            }
            this.request.requestInformation.totalTDYCost = this.request.requestInformation.totalTDYCost + (train.people * train.travelCost + train.people * train.perDiem * train.days);
        });
        this.calculateTotalRequisitionCost();
    }

    private calculateTotalInstallationCosts(){
        this.request.maintenanceInformation.totalIncludedInstallationCosts = 0;
        this.request.maintenanceInformation.totalOtherInstallationCosts = 0;
        angular.forEach(this.request.maintenanceInformation.installationRequirements,(installation) =>{
            if(installation.includedCost) {
                this.request.maintenanceInformation.totalIncludedInstallationCosts = this.request.maintenanceInformation.totalIncludedInstallationCosts + installation.cost;
            }else{
                this.request.maintenanceInformation.totalOtherInstallationCosts = this.request.maintenanceInformation.totalOtherInstallationCosts + installation.cost;
            }
        });
        this.calculateTotalRequisitionCost();
    }

    private calculateTotalLiteratureCosts(){
        this.request.maintenanceInformation.totalLiteratureCosts = 0;
        angular.forEach(this.request.maintenanceInformation.literature,(lit) =>{
            this.request.maintenanceInformation.totalLiteratureCosts = this.request.maintenanceInformation.totalLiteratureCosts + lit.cost * lit.quantity;
        });
        this.verifyMaintenanceForm();
        this.calculateTotalRequisitionCost();
    }

    private verifyAPrimarySourceBeenSet(){
        this.isThereAPrimarySource = false;
        angular.forEach(this.request.requestInformation.suggestedSources,(source) => {
            if(source.primarySource){
                this.isThereAPrimarySource = true;
                return;
            }
        });
    }
}