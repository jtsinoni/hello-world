'use strict';
import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {WorkFlowDefinition} from "../_models/workflowDefinition.model";
import {Review} from "../_models/review.model";
import {WorkflowLevelProcessing} from "../_models/workflowLevelProcessing.model";

export interface IRequestService {

}

export class WorkFlowService implements IRequestService {
    private serviceName:string = "WorkFlow Service";

    public catalogCriteriaMet:boolean;
    public comment:string = "";
    public commentsTable:any;
    public commentToBeAdded:string = "";
    public confirming:boolean;
    public costCriteriaMet:boolean;
    public deviceCriteriaMet:boolean = false;
    public deviceUnitCostCriteriaMet:boolean = false;
    public levelCriteriaName:string;
    //public newChangeStatus:string = '';
    public progressBarElementWidth:any;

    //public requestWorkflowHistoryTable:any;
    public workflowDef:WorkFlowDefinition;
    //This is a flag to so the gui knows, this might only be for now, maybe the gui can just look at the status
    public reviewReview:string = "";
    public reviewSelected:Review = null;
    public validForm:boolean = false;

    constructor(private $log, private $state, private ContentConstants, private datatableService, private NotificationService, private NotificationMessages, private RequestApi,
                private RequestService, private StateConstants, private UserService, private ReviewResult, private ReviewStatus) {
        this.$log.debug("%s - Start", this.serviceName);
    }

    public addComment(comment) {
        if (comment) {
            this.RequestApi.addProcessComment(this.RequestService.request.id, comment).then((response:IHttpPromiseCallbackArg<any>) => {
                if (response.data) {
                    this.RequestService.request = response.data;
                    this.commentToBeAdded = null;
                    this.NotificationService.successMsg(this.NotificationMessages.REQUEST_REVIEW_COMMENT_ADDED);
                } else {
                    this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
                }
            }, (errResponse:IHttpPromiseCallbackArg<any>) => {
                this.$log.error("%s - Error adding comment: %s", JSON.stringify(errResponse));
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
            });
        }
    }

    public addReviewComment(adding) {
        if (adding && this.comment) {
            this.RequestApi.addReviewComment(this.RequestService.request.id, this.reviewSelected.roleId, this.comment).then((response:IHttpPromiseCallbackArg<any>) => {
                if (response.data) {
                    this.RequestService.request = response.data;
                    this.setSelectedReview(this.reviewSelected.elementName);
                    //if (changingStatus) {
                    //    this.setStatusReview(this.reviewSelected, changingStatus);
                    //}
                    //else {
                    //    //this.reviewSelected = null;
                        this.comment = null;
                        this.NotificationService.successMsg(this.NotificationMessages.REQUEST_REVIEW_SUCCESS);
                    //}
                } else {
                    this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
                }
            }, (errResponse:IHttpPromiseCallbackArg<any>) => {
                this.$log.error("%s - Error saving request: %s", JSON.stringify(errResponse));
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
            });
        }
        else {
            //this.reviewSelected = null;
            this.comment = null;
           // this.newChangeStatus = "";
        }
    }

    public addReviewCommentToOverall(comment) {
        this.addComment(comment);
    }

    public confirmSelection(review, validForm?) {
        this.validForm = validForm;
        if(validForm == null){
            this.validForm = true;
        }
        this.reviewSelected = review;
        //this.setSelectedReview(reviewName);
    }

    public getLevelsCriteriaNeeded(request) {
        return this.RequestApi.getLevelsCriteriaNeeded(angular.toJson(request)).then((response:IHttpPromiseCallbackArg<any>) => {
            if (response.data) {
                this.deviceCriteriaMet = false;
                this.deviceUnitCostCriteriaMet = false;
                this.catalogCriteriaMet = false;
                this.costCriteriaMet = false;
                angular.forEach(response.data, (level) => {
                    if (level.deviceCriteriaMet) {
                        this.deviceCriteriaMet = true;
                    }
                    if (level.deviceUnitCostCriteriaMet) {
                        this.deviceUnitCostCriteriaMet = true;
                    }
                    if (level.catalogCriteriaMet) {
                        this.catalogCriteriaMet = true;
                    }
                    if (level.costCriteriaMet) {
                        this.costCriteriaMet = true;
                    }
                });
                if (this.costCriteriaMet ||
                    this.deviceUnitCostCriteriaMet ||
                    this.catalogCriteriaMet ||
                    this.deviceCriteriaMet) {
                    return true;
                }
                return false;
            }
            else {
                this.NotificationService.errorMsg(this.ContentConstants.REQUEST_SUBMIT_ERROR);
            }
        }, (errResponse:IHttpPromiseCallbackArg<any>) => {
            this.$log.error("%s - Error retrieving level criteria: %s", JSON.stringify(errResponse));
            this.NotificationService.errorMsg(this.NotificationMessages.REQUEST_SUBMIT_ERROR);
        });
    }

    //This is used for holding and resuming the review which is done from the tab
    public getReviewSetStatus(reviewName, status) {
        //this.setSelectedReview(reviewName);
        //angular.forEach(this.RequestService.request.wfProcessing.levels[this.RequestService.request.wfProcessing.currentLevelId].reviews, (review:any) => {
        //    if (review.elementName === reviewName) {
        //        this.reviewSelected = review;
        //        //this.newChangeStatus = status;
        //        return;
        //    }
        //});
        this.setStatusReview(this.reviewSelected, status);
    }

    public getReviewStatus(reviewName) {
        var status:string = "";
        if (this.RequestService.request.wfProcessing) {
            angular.forEach(this.RequestService.request.wfProcessing.levels[this.RequestService.request.wfProcessing.currentLevelId].reviews, (review:any) => {
                if (review.elementName === reviewName) {
                    status = review.reviewStatus;
                    return;
                }
            });
        }
        return status;
    }

    public getWorkflowDefinition(service) {
        this.RequestApi.getWorkflowDefinition(service).then((response:IHttpPromiseCallbackArg<any>) => {
            this.workflowDef = response.data;
            //This dynamically sets the width of each part of the progress bar since it could contain a different count of levels
            this.progressBarElementWidth = {"width": 100 / this.workflowDef.levelDefinitions.length + "%"};
        }, (errResponse:IHttpPromiseCallbackArg<any>) => {
            console.log("%s - Error getting workflow");
            this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
        });
    }

    public getReviewComments(reviewName) {
        var reviewFound:Review;
        if (this.RequestService.request.wfProcessing) {
            angular.forEach(this.RequestService.request.wfProcessing.levels[this.RequestService.request.wfProcessing.currentLevelId].reviews, (review) => {
                if (review.elementName == reviewName) {
                    reviewFound = review;
                    return;
                }
            });
        }
        return reviewFound;
    }

    public getUsersWorkflowLevel(){
        var usersLevel: WorkflowLevelProcessing = null;
        for(var i = 0; i < this.RequestService.request.wfProcessing.wfDefinition.levelDefinitions.length; i++){
            if(this.UserService.currentUser.userType == this.RequestService.request.wfProcessing.wfDefinition.levelDefinitions[i].userType){
                usersLevel = this.RequestService.request.wfProcessing.levels[i];
                break;
            }
        }
        return usersLevel
    }

    public isRequestAtUsersLevel(request) {
        if (request.wfProcessing) {
            var currentLevelId = request.wfProcessing.currentLevelId;
            return (request.wfProcessing.wfDefinition.levelDefinitions[currentLevelId].userType == this.UserService.currentUser.userType);
        } else if (request.wfProcessing == null && this.UserService.currentUser.userType == "SITE") {
            return true;
        } else {
            return false;
        }
    }

    public isUserAssignedToReview(currentLevelId, role) {
        var found = false;
        angular.forEach(this.RequestService.request.wfProcessing.levels[currentLevelId].reviews, (review) => {
            if (review.elementName == role && review.selectedUserId == this.UserService.currentUser.id) {
                found = true;
                return;
            }
            else if (review.elementName == role && (review.selectedUserId == null || review.selectedUserId == "")) {
                found = true;
                return;
            }
        });
        return found;
    }

    public isWorkflowCompleted(request){
        var returnVal: boolean = false;
        if (request.wfProcessing && request.wfProcessing.isCompleted) {
            returnVal = true;
        }
        return returnVal;
    }

    public performingReview(reviewRole) {
        var awaitingReview:boolean = false;
        if (this.RequestService.request.wfProcessing) {
            angular.forEach(this.RequestService.request.wfProcessing.levels[this.RequestService.request.wfProcessing.currentLevelId].reviews, (review:any) => {
                if (review.elementName === reviewRole) {
                    //This is true for HOLD because we want to show the resume button
                    if (review.reviewStatus === this.ReviewStatus.PENDING ||
                        review.reviewStatus === this.ReviewStatus.HOLD ||
                        review.reviewStatus === this.ReviewStatus.REWORK) {
                        awaitingReview = true;
                        return;
                    }
                }
            });
        }
        return awaitingReview;
    }

    public removeProcessComment(comment, id) {
        angular.element(id).addClass("fadeOut");
        this.RequestApi.removeProcessComment(this.RequestService.request.id, comment.id).then((response:IHttpPromiseCallbackArg<any>) => {
            if (response.data) {
                this.RequestService.request = response.data;
                if (this.RequestService.request.wfProcessing.comments.length < 1) {
                    angular.element('#LevelCommentTable').addClass("animated fadeOut");
                }
                this.NotificationService.successMsg(this.ContentConstants.COMMENT_SUCCESSFULL_DELETE);
            } else {
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
            }
        }, (errResponse:IHttpPromiseCallbackArg<any>) => {
            this.$log.error("%s - Error saving request: %s", JSON.stringify(errResponse));
            this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
        });
    }

    public removeReviewComment(comment, review) {
        this.RequestApi.removeReviewComment(this.RequestService.request.id, review.roleId, comment.id).then((response:IHttpPromiseCallbackArg<any>) => {
            if (response.data) {
                this.RequestService.request = response.data;
                this.setSelectedReview(review.elementName);
                this.NotificationService.successMsg(this.ContentConstants.COMMENT_SUCCESSFULL_DELETE);
            } else {
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
            }
        }, (errResponse:IHttpPromiseCallbackArg<any>) => {
            this.$log.error("%s - Error saving request: %s", JSON.stringify(errResponse));
            this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
        });
    }

    public setSelectedReview(ReviewName) {
        this.reviewSelected = null;
        if (this.RequestService.request.wfProcessing) {
            angular.forEach(this.RequestService.request.wfProcessing.levels[this.RequestService.request.wfProcessing.currentLevelId].reviews, (review:any) => {
                if (review.elementName == ReviewName) {
                    this.reviewSelected = review;
                    return;
                }
            });
        }
    }

    public setReviewResult() {
        this.RequestApi.submitReviewResult(this.reviewReview, this.RequestService.request, this.reviewSelected.reviewDisplayName).then((response:IHttpPromiseCallbackArg<any>) => {
            if (response.data) {
                this.RequestService.request = response.data;
                this.RequestService.getRequests();
                this.setSelectedReview(this.reviewSelected.elementName);
                this.addReviewComment(true);
                this.reviewReview = "";
                this.NotificationService.successMsg(this.NotificationMessages.REQUEST_REVIEW_SUCCESS);
            } else {
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
            }
        }, (errResponse:IHttpPromiseCallbackArg<any>) => {
            this.$log.error("%s - Error saving request: %s", JSON.stringify(errResponse));
            this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
        });
    }

    public setStatusReview(review, status) {
        if(status) {
            review.reviewStatus = status;
            this.$log.debug(review);
            return this.RequestApi.submitReviewStatus(this.RequestService.request).then((response:IHttpPromiseCallbackArg<any>) => {
                if (response.data) {
                    this.RequestService.request = response.data;
                    this.RequestService.getRequests();
                    this.setSelectedReview(review.elementName);
                    this.comment = null;
                    //this.newChangeStatus = "";
                    this.NotificationService.successMsg(this.NotificationMessages.REQUEST_REVIEW_SUCCESS);
                    return true;
                } else {
                    this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
                    return false;
                }
            }, (errResponse:IHttpPromiseCallbackArg<any>) => {
                this.$log.error("%s - Error saving request: %s", JSON.stringify(errResponse));
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
                return false;
            });
        }
        else{
            this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
        }
    }

    public submitApproval() {
        this.$log.debug("%s - Request To Be Submitted: %s", this.serviceName, this.RequestService.request);
        var currentLevel = this.RequestService.request.wfProcessing.currentLevelId;
        //if ((!this.workflowDef.levelDefinitions[currentLevel].rules.allowReviewBypassOnApprove && !this.reviewsFinished(currentLevel)) ||
        //    (!this.workflowDef.levelDefinitions[currentLevel].rules.allowOwnerOverrideNegativeReviews && !this.allReviewsApprove(currentLevel))) {
        //    this.NotificationService.errorMsg("All the reviews must be completed to approve this request. ");
        //    return;
        //}
        if (this.RequestService.isRequestValid() && this.isTabsComplete()){
            this.RequestApi.approve(this.RequestService.request.id).then((response:IHttpPromiseCallbackArg<any>) => {
                if (response.data) {
                    this.RequestService.request = response.data;
                    this.RequestService.getRequests();
                    this.$state.go(this.StateConstants.EQUIP_REQUEST_MY_REQUESTS);
                    this.NotificationService.successMsg(this.NotificationMessages.REQUEST_SUBMITED_APPROVE_SUCCESS);
                } else {
                    this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
                }
            }, (errResponse:IHttpPromiseCallbackArg<any>) => {
                this.$log.error("%s - Error saving request: %s", JSON.stringify(errResponse));
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
            });
        }
        this.$log.debug(this.RequestService.missingRequiredEntryMsg);
    }

    public submitCancel() {
        this.$log.debug("%s - Request To Be Submitted: %s", this.serviceName, this.RequestService.request);
        this.RequestApi.cancel(this.RequestService.request.id).then((response:IHttpPromiseCallbackArg<any>) => {
            if (response.data) {
                this.RequestService.request = response.data;
                this.RequestService.getRequests();
                this.$state.go(this.StateConstants.EQUIP_REQUEST_MY_REQUESTS);
                this.NotificationService.successMsg(this.NotificationMessages.REQUEST_SUBMITED_CANCEL_SUCCESS);
            } else {
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
            }
        }, (errResponse:IHttpPromiseCallbackArg<any>) => {
            this.$log.error("%s - Error saving request: %s", JSON.stringify(errResponse));
            this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
        });
    }


    public submitHold() {
        this.$log.debug("%s - Request To Be Submitted: %s", this.serviceName, this.RequestService.request);
        this.RequestApi.hold(this.RequestService.request.id).then((response:IHttpPromiseCallbackArg<any>) => {
            if (response.data) {
                this.RequestService.request = response.data;
                this.RequestService.getRequests();
                this.NotificationService.successMsg(this.NotificationMessages.REQUEST_SUBMITED_HOLD_SUCCESS);
            } else {
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
            }
        }, (errResponse:IHttpPromiseCallbackArg<any>) => {
            this.$log.error("%s - Error saving request: %s", JSON.stringify(errResponse));
            this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
        });
    }

    public submitForceUp() {
        this.RequestApi.forceUp(this.RequestService.request.id).then((response:IHttpPromiseCallbackArg<any>) => {
            if (response.data) {
                this.RequestService.request = response.data;
                this.RequestService.getRequests();
                this.$state.go(this.StateConstants.EQUIP_REQUEST_MY_REQUESTS);
                this.NotificationService.successMsg(this.NotificationMessages.REQUEST_SUBMITED_FORCEUP_SUCCESS);
            } else {
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
            }
        }, (errResponse:IHttpPromiseCallbackArg<any>) => {
            this.$log.error("%s - Error saving request: %s", JSON.stringify(errResponse));
            this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
        });
    }

    public submitReactivate() {
        this.$log.debug("%s - Request To Be Submitted: %s", this.serviceName, this.RequestService.request.id);
        this.RequestApi.reactivate(this.RequestService.request.id).then((response:IHttpPromiseCallbackArg<any>) => {
            if (response.data) {
                this.RequestService.request = response.data;
                this.RequestService.getRequests();
                this.NotificationService.successMsg(this.NotificationMessages.REQUEST_SUBMITED_RESUME_SUCCESS);
            } else {
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
            }
        }, (errResponse:IHttpPromiseCallbackArg<any>) => {
            this.$log.error("%s - Error saving request: %s", JSON.stringify(errResponse));
            this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
        });
    }

    public submitReject() {
        this.$log.debug("%s - Request To Be Submitted: %s", this.serviceName, this.RequestService.request);
        this.RequestApi.reject(this.RequestService.request.id).then((response:IHttpPromiseCallbackArg<any>) => {
            if (response.data) {
                this.RequestService.request = response.data;
                this.RequestService.getRequests();
                this.$state.go(this.StateConstants.EQUIP_REQUEST_MY_REQUESTS);
                this.NotificationService.successMsg(this.NotificationMessages.REQUEST_SUBMITED_REJECT_SUCCESS);
            } else {
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
            }
        }, (errResponse:IHttpPromiseCallbackArg<any>) => {
            this.$log.error("%s - Error saving request: %s", JSON.stringify(errResponse));
            this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
        });
    }

    public submitRetract(){
        this.$log.debug("%s - Request To Be Retracted: %s", this.serviceName, this.RequestService.request);
        this.RequestApi.retract(this.RequestService.request.id).then((response:IHttpPromiseCallbackArg<any>) => {
            if (response.data) {
                this.RequestService.request = response.data;
                this.RequestService.getRequests();
                this.NotificationService.successMsg(this.NotificationMessages.REQUEST_SUBMITED_RETRACT_SUCCESS);
            } else {
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
            }
        }, (errResponse:IHttpPromiseCallbackArg<any>) => {
            this.$log.error("%s - Error retracting request: %s", JSON.stringify(errResponse));
            this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
        });
    }

    public submitRework() {
        this.$log.debug("%s - Request To Be Submitted: %s", this.serviceName, this.RequestService.request);
        this.RequestApi.rework(this.RequestService.request.id).then((response:IHttpPromiseCallbackArg<any>) => {
            if (response.data) {
                this.RequestService.request = response.data;
                this.RequestService.getRequests();
                this.$state.go(this.StateConstants.EQUIP_REQUEST_MY_REQUESTS);
                this.NotificationService.successMsg(this.NotificationMessages.REQUEST_SUBMITED_REWORK_SUCCESS);
            } else {
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
            }
        }, (errResponse:IHttpPromiseCallbackArg<any>) => {
            this.$log.error("%s - Error saving request: %s", JSON.stringify(errResponse));
            this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
        });
    }

    private allReviewsApprove(currentLevel) {
        var approved = true;
        angular.forEach(this.RequestService.request.wfProcessing.levels[currentLevel].reviews, (review) => {
            if (review.reviewResult === this.ReviewResult.DISAPPROVE ||
                review.reviewResult === this.ReviewResult.RECOMMEND_DISAPPROVE ||
                review.reviewResult === this.ReviewResult.NOTE_CONCERN) {
                approved = false;
                return;
            }
        });
        return approved;
    }

    private isTabsComplete(){
        if (!this.RequestService.isFacilitiesCompleted) {
            this.NotificationService.errorMsg("Missing required <b>Facilities</b> information.");
            return false;
        }
        else if (!this.RequestService.isMaintenanceFormCompleted) {
            this.NotificationService.errorMsg("Missing required <b>Maintenance</b> information.");
            return false;
        } else if (!this.RequestService.isSafetyCompleted) {
            this.NotificationService.errorMsg("Missing required <b>Safety</b> information.");
            return false;
        } else if (!this.RequestService.isTechnologiesComplete) {
            this.NotificationService.errorMsg("Missing required <b>Techynology</b> information.");
            return false;
        }else{
            return true;
        }
    }

    private reviewsFinished(currentLevel) {
        var finished = true;
        angular.forEach(this.RequestService.request.wfProcessing.levels[currentLevel].reviews, (review) => {
            if (review.reviewResult === null && review.reviewStatus != this.ReviewStatus.SKIPPED) {
                finished = false;
                return;
            }
        });
        return finished;
    }
}
