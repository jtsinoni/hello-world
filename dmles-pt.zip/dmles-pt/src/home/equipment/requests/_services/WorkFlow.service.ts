'use strict';
import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {WorkFlowDefinition} from "../_models/workflowDefinition.model";
import {WeighIn} from "../_models/weighIn.model";
import {WorkflowLevelProcessing} from "../_models/workflowLevelProcessing.model";

export interface IRequestService {

}

export class WorkFlowService implements IRequestService {
    private serviceName:string = "WorkFlow Service";

    public catalogCriteriaMet:boolean;
    public comment:string = "";
    public commentsTable:any;
    public commentToBeAdded:string = "";
    public confirming:boolean;
    public costCriteriaMet:boolean;
    public deviceCriteriaMet:boolean = false;
    public deviceUnitCostCriteriaMet:boolean = false;
    public levelCriteriaName:string;
    //public newChangeStatus:string = '';
    public progressBarElementWidth:any;

    //public requestWorkflowHistoryTable:any;
    public workflowDef:WorkFlowDefinition;
    //This is a flag to so the gui knows, this might only be for now, maybe the gui can just look at the status
    public weighInReview:string = "";
    public weighInSelected:WeighIn = null;
    public validForm:string = "";

    constructor(private $log, private $state, private ContentConstants, private datatableService, private NotificationService, private NotificationMessages, private RequestApi,
                private RequestService, private StateConstants, private UserService, private WeighInResult, private WeighInStatus) {
        this.$log.debug("%s - Start", this.serviceName);
    }

    public addComment(comment) {
        this.RequestApi.addProcessComment(this.RequestService.request.id, comment).then((response:IHttpPromiseCallbackArg<any>) => {
            if (response.data) {
                this.RequestService.request = response.data;
                this.commentToBeAdded = "";
                this.NotificationService.successMsg(this.NotificationMessages.REQUEST_WEIGHIN_COMMENT_ADDED);
            } else {
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
            }
        }, (errResponse:IHttpPromiseCallbackArg<any>) => {
            this.$log.error("%s - Error adding comment: %s", JSON.stringify(errResponse));
            this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
        });
    }

    public addWeighInComment(adding) {
        if (adding && this.comment) {
            this.RequestApi.addWeighInComment(this.RequestService.request.id, this.weighInSelected.roleId, this.comment).then((response:IHttpPromiseCallbackArg<any>) => {
                if (response.data) {
                    this.RequestService.request = response.data;
                    this.setSelectedWeighIn(this.weighInSelected.elementName);
                    //if (changingStatus) {
                    //    this.setStatusWeighIn(this.weighInSelected, changingStatus);
                    //}
                    //else {
                    //    //this.weighInSelected = null;
                        this.comment = null;
                        this.NotificationService.successMsg(this.NotificationMessages.REQUEST_WEIGHIN_SUCCESS);
                    //}
                } else {
                    this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
                }
            }, (errResponse:IHttpPromiseCallbackArg<any>) => {
                this.$log.error("%s - Error saving request: %s", JSON.stringify(errResponse));
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
            });
        }
        else {
            //this.weighInSelected = null;
            this.comment = null;
           // this.newChangeStatus = "";
        }
    }

    public addWeighInCommentToOverall(comment) {
        this.addComment(comment);
    }

    public confirmSelection(weighInName, validForm) {
        this.validForm = validForm;
        //this.setSelectedWeighIn(weighInName);
    }

    public getLevelsCriteriaNeeded(request) {
        return this.RequestApi.getLevelsCriteriaNeeded(angular.toJson(request)).then((response:IHttpPromiseCallbackArg<any>) => {
            if (response.data) {
                this.deviceCriteriaMet = false;
                this.deviceUnitCostCriteriaMet = false;
                this.catalogCriteriaMet = false;
                this.costCriteriaMet = false;
                angular.forEach(response.data, (level) => {
                    if (level.deviceCriteriaMet) {
                        this.deviceCriteriaMet = true;
                    }
                    if (level.deviceUnitCostCriteriaMet) {
                        this.deviceUnitCostCriteriaMet = true;
                    }
                    if (level.catalogCriteriaMet) {
                        this.catalogCriteriaMet = true;
                    }
                    if (level.costCriteriaMet) {
                        this.costCriteriaMet = true;
                    }
                });
                if (this.costCriteriaMet ||
                    this.deviceUnitCostCriteriaMet ||
                    this.catalogCriteriaMet ||
                    this.deviceCriteriaMet) {
                    return true;
                }
                return false;
            }
            else {
                this.NotificationService.errorMsg(this.ContentConstants.REQUEST_SUBMIT_ERROR);
            }
        }, (errResponse:IHttpPromiseCallbackArg<any>) => {
            this.$log.error("%s - Error retrieving level criteria: %s", JSON.stringify(errResponse));
            this.NotificationService.errorMsg(this.NotificationMessages.REQUEST_SUBMIT_ERROR);
        });
    }

    //This is used for holding and resuming the weighIn which is done from the tab
    public getWeighInSetStatus(weighInName, status) {
        angular.forEach(this.RequestService.request.wfProcessing.levels[this.RequestService.request.wfProcessing.currentLevelId].weighIns, (weighIn:any) => {
            if (weighIn.elementName === weighInName) {
                this.weighInSelected = weighIn;
                //this.newChangeStatus = status;
                return;
            }
        });
        this.setStatusWeighIn(this.weighInSelected, status);
    }

    public getWeighInStatus(weighInName) {
        var status:string = "";
        if (this.RequestService.request.wfProcessing) {
            angular.forEach(this.RequestService.request.wfProcessing.levels[this.RequestService.request.wfProcessing.currentLevelId].weighIns, (weighIn:any) => {
                if (weighIn.elementName === weighInName) {
                    status = weighIn.weighInStatus;
                    return;
                }
            });
        }
        return status;
    }

    public getWorkflowDefinition(service) {
        this.RequestApi.getWorkflowDefinition(service).then((response:IHttpPromiseCallbackArg<any>) => {
            this.workflowDef = response.data;
            //This dynamically sets the width of each part of the progress bar since it could contain a different count of levels
            this.progressBarElementWidth = {"width": 100 / this.workflowDef.levelDefinitions.length + "%"};
        }, (errResponse:IHttpPromiseCallbackArg<any>) => {
            console.log("%s - Error getting workflow");
            this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
        });
    }

    public getWeighInComments(weighInName) {
        var weighInFound:WeighIn;
        if (this.RequestService.request.wfProcessing) {
            angular.forEach(this.RequestService.request.wfProcessing.levels[this.RequestService.request.wfProcessing.currentLevelId].weighIns, (weighIn) => {
                if (weighIn.elementName == weighInName) {
                    weighInFound = weighIn;
                    return;
                }
            });
        }
        return weighInFound;
    }

    public getUsersWorkflowLevel(){
        var usersLevel: WorkflowLevelProcessing = null;
        for(var i = 0; i < this.RequestService.request.wfProcessing.wfDefinition.levelDefinitions.length; i++){
            if(this.UserService.currentUser.userType == this.RequestService.request.wfProcessing.wfDefinition.levelDefinitions[i].userType){
                usersLevel = this.RequestService.request.wfProcessing.levels[i];
                break;
            }
        }
        return usersLevel
    }

    public isRequestAtUsersLevel(request) {
        if (request.wfProcessing) {
            var currentLevelId = request.wfProcessing.currentLevelId;
            return (request.wfProcessing.wfDefinition.levelDefinitions[currentLevelId].userType == this.UserService.currentUser.userType);
        } else if (request.wfProcessing == null && this.UserService.currentUser.userType == "SITE") {
            return true;
        } else {
            return false;
        }
    }

    public isUserAssignedToWeighIn(currentLevelId, role) {
        var found = false;
        angular.forEach(this.RequestService.request.wfProcessing.levels[currentLevelId].weighIns, (weighIn) => {
            if (weighIn.elementName == role && weighIn.selectedUserId == this.UserService.currentUser.id) {
                found = true;
                return;
            }
            else if (weighIn.elementName == role && (weighIn.selectedUserId == null || weighIn.selectedUserId == "")) {
                found = true;
                return;
            }
        });
        return found;
    }

    public isWorkflowCompleted(request){
        var returnVal: boolean = false;
        if (request.wfProcessing && request.wfProcessing.isCompleted) {
            returnVal = true;
        }
        return returnVal;
    }

    public performingWeighIn(weighInRole) {
        var awaitingWeighIn:boolean = false;
        if (this.RequestService.request.wfProcessing) {
            angular.forEach(this.RequestService.request.wfProcessing.levels[this.RequestService.request.wfProcessing.currentLevelId].weighIns, (weighIn:any) => {
                if (weighIn.elementName === weighInRole) {
                    //This is true for HOLD because we want to show the resume button
                    if (weighIn.weighInStatus === this.WeighInStatus.PENDING ||
                        weighIn.weighInStatus === this.WeighInStatus.HOLD ||
                        weighIn.weighInStatus === this.WeighInStatus.REWORK) {
                        awaitingWeighIn = true;
                        return;
                    }
                }
            });
        }
        return awaitingWeighIn;
    }

    public removeProcessComment(comment, id) {
        angular.element(id).addClass("fadeOut");
        this.RequestApi.removeProcessComment(this.RequestService.request.id, comment.id).then((response:IHttpPromiseCallbackArg<any>) => {
            if (response.data) {
                this.RequestService.request = response.data;
                if (this.RequestService.request.notes.length < 1) {
                    angular.element('#LevelCommentTable').addClass("animated fadeOut");
                }
                this.NotificationService.successMsg(this.ContentConstants.COMMENT_SUCCESSFULL_DELETE);
            } else {
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
            }
        }, (errResponse:IHttpPromiseCallbackArg<any>) => {
            this.$log.error("%s - Error saving request: %s", JSON.stringify(errResponse));
            this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
        });
    }

    public removeWeighInComment(comment, weighIn) {
        this.RequestApi.removeWeighInComment(this.RequestService.request.id, weighIn.roleId, comment.id).then((response:IHttpPromiseCallbackArg<any>) => {
            if (response.data) {
                this.RequestService.request = response.data;
                this.setSelectedWeighIn(weighIn.elementName);
                this.NotificationService.successMsg(this.ContentConstants.COMMENT_SUCCESSFULL_DELETE);
            } else {
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
            }
        }, (errResponse:IHttpPromiseCallbackArg<any>) => {
            this.$log.error("%s - Error saving request: %s", JSON.stringify(errResponse));
            this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
        });
    }

    public setSelectedWeighIn(weighInName) {
        this.weighInSelected = null;
        if (this.RequestService.request.wfProcessing) {
            angular.forEach(this.RequestService.request.wfProcessing.levels[this.RequestService.request.wfProcessing.currentLevelId].weighIns, (weighIn:any) => {
                if (weighIn.elementName == weighInName) {
                    this.weighInSelected = weighIn;
                    return;
                }
            });
        }
    }

    public setWeighInResult() {
        this.RequestApi.submitWeighinResult(this.weighInSelected.roleId, this.weighInReview, this.RequestService.request, this.weighInSelected.weighInDisplayName).then((response:IHttpPromiseCallbackArg<any>) => {
            if (response.data) {
                this.RequestService.request = response.data;
                this.RequestService.getRequests();
                this.setSelectedWeighIn(this.weighInSelected.elementName);
                this.addWeighInComment(true);
                this.weighInReview = "";
                this.NotificationService.successMsg(this.NotificationMessages.REQUEST_WEIGHIN_SUCCESS);
            } else {
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
            }
        }, (errResponse:IHttpPromiseCallbackArg<any>) => {
            this.$log.error("%s - Error saving request: %s", JSON.stringify(errResponse));
            this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
        });
    }

    public setStatusWeighIn(weighIn, status) {
        if(status) {
            weighIn.weighInStatus = status;
            this.$log.debug(weighIn);
            return this.RequestApi.submitWeighinStatus(this.RequestService.request).then((response:IHttpPromiseCallbackArg<any>) => {
                if (response.data) {
                    this.RequestService.request = response.data;
                    this.RequestService.getRequests();
                    this.setSelectedWeighIn(weighIn.elementName);
                    this.comment = null;
                    //this.newChangeStatus = "";
                    this.NotificationService.successMsg(this.NotificationMessages.REQUEST_WEIGHIN_SUCCESS);
                    return true;
                } else {
                    this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
                    return false;
                }
            }, (errResponse:IHttpPromiseCallbackArg<any>) => {
                this.$log.error("%s - Error saving request: %s", JSON.stringify(errResponse));
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
                return false;
            });
        }
        else{
            this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
        }
    }

    public submitApproval() {
        this.$log.debug("%s - Request To Be Submitted: %s", this.serviceName, this.RequestService.request);
        var currentLevel = this.RequestService.request.wfProcessing.currentLevelId;
        if ((!this.workflowDef.levelDefinitions[currentLevel].rules.allowWeighInBypassOnApprove && !this.weighInsFinished(currentLevel)) ||
            (!this.workflowDef.levelDefinitions[currentLevel].rules.allowOwnerOverrideNegativeWeighIns && !this.allWeighInsApprove(currentLevel))) {
            this.NotificationService.errorMsg("All the weigh-ins must be approved before you can approve this request");
            return;
        }
        if (this.RequestService.isRequestValid() && this.isTabsComplete()){
            this.RequestApi.approve(this.RequestService.request.id).then((response:IHttpPromiseCallbackArg<any>) => {
                if (response.data) {
                    this.RequestService.request = response.data;
                    this.RequestService.getRequests();
                    this.$state.go(this.StateConstants.EQUIP_REQUEST_MY_REQUESTS);
                    this.NotificationService.successMsg(this.NotificationMessages.REQUEST_SUBMITED_APPROVE_SUCCESS);
                } else {
                    this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
                }
            }, (errResponse:IHttpPromiseCallbackArg<any>) => {
                this.$log.error("%s - Error saving request: %s", JSON.stringify(errResponse));
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
            });
        }
    }

    public submitCancel() {
        this.$log.debug("%s - Request To Be Submitted: %s", this.serviceName, this.RequestService.request);
        this.RequestApi.cancel(this.RequestService.request.id).then((response:IHttpPromiseCallbackArg<any>) => {
            if (response.data) {
                this.RequestService.request = response.data;
                this.RequestService.getRequests();
                this.$state.go(this.StateConstants.EQUIP_REQUEST_MY_REQUESTS);
                this.NotificationService.successMsg(this.NotificationMessages.REQUEST_SUBMITED_CANCEL_SUCCESS);
            } else {
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
            }
        }, (errResponse:IHttpPromiseCallbackArg<any>) => {
            this.$log.error("%s - Error saving request: %s", JSON.stringify(errResponse));
            this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
        });
    }


    public submitHold() {
        this.$log.debug("%s - Request To Be Submitted: %s", this.serviceName, this.RequestService.request);
        this.RequestApi.hold(this.RequestService.request.id).then((response:IHttpPromiseCallbackArg<any>) => {
            if (response.data) {
                this.RequestService.request = response.data;
                this.RequestService.getRequests();
                this.NotificationService.successMsg(this.NotificationMessages.REQUEST_SUBMITED_HOLD_SUCCESS);
            } else {
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
            }
        }, (errResponse:IHttpPromiseCallbackArg<any>) => {
            this.$log.error("%s - Error saving request: %s", JSON.stringify(errResponse));
            this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
        });
    }

    public submitForceUp() {
        this.RequestApi.forceUp(this.RequestService.request.id).then((response:IHttpPromiseCallbackArg<any>) => {
            if (response.data) {
                this.RequestService.request = response.data;
                this.RequestService.getRequests();
                this.$state.go(this.StateConstants.EQUIP_REQUEST_MY_REQUESTS);
                this.NotificationService.successMsg(this.NotificationMessages.REQUEST_SUBMITED_FORCEUP_SUCCESS);
            } else {
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
            }
        }, (errResponse:IHttpPromiseCallbackArg<any>) => {
            this.$log.error("%s - Error saving request: %s", JSON.stringify(errResponse));
            this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
        });
    }

    public submitReactivate() {
        this.$log.debug("%s - Request To Be Submitted: %s", this.serviceName, this.RequestService.request.id);
        this.RequestApi.reactivate(this.RequestService.request.id).then((response:IHttpPromiseCallbackArg<any>) => {
            if (response.data) {
                this.RequestService.request = response.data;
                this.RequestService.getRequests();
                this.NotificationService.successMsg(this.NotificationMessages.REQUEST_SUBMITED_RESUME_SUCCESS);
            } else {
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
            }
        }, (errResponse:IHttpPromiseCallbackArg<any>) => {
            this.$log.error("%s - Error saving request: %s", JSON.stringify(errResponse));
            this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
        });
    }

    public submitReject() {
        this.$log.debug("%s - Request To Be Submitted: %s", this.serviceName, this.RequestService.request);
        this.RequestApi.reject(this.RequestService.request.id).then((response:IHttpPromiseCallbackArg<any>) => {
            if (response.data) {
                this.RequestService.request = response.data;
                this.RequestService.getRequests();
                this.$state.go(this.StateConstants.EQUIP_REQUEST_MY_REQUESTS);
                this.NotificationService.successMsg(this.NotificationMessages.REQUEST_SUBMITED_REJECT_SUCCESS);
            } else {
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
            }
        }, (errResponse:IHttpPromiseCallbackArg<any>) => {
            this.$log.error("%s - Error saving request: %s", JSON.stringify(errResponse));
            this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
        });
    }

    public submitRetract(){
        this.$log.debug("%s - Request To Be Retracted: %s", this.serviceName, this.RequestService.request);
        this.RequestApi.retract(this.RequestService.request.id).then((response:IHttpPromiseCallbackArg<any>) => {
            if (response.data) {
                this.RequestService.request = response.data;
                this.RequestService.getRequests();
                this.NotificationService.successMsg(this.NotificationMessages.REQUEST_SUBMITED_RETRACT_SUCCESS);
            } else {
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
            }
        }, (errResponse:IHttpPromiseCallbackArg<any>) => {
            this.$log.error("%s - Error retracting request: %s", JSON.stringify(errResponse));
            this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
        });
    }

    public submitRework() {
        this.$log.debug("%s - Request To Be Submitted: %s", this.serviceName, this.RequestService.request);
        this.RequestApi.rework(this.RequestService.request.id).then((response:IHttpPromiseCallbackArg<any>) => {
            if (response.data) {
                this.RequestService.request = response.data;
                this.RequestService.getRequests();
                this.$state.go(this.StateConstants.EQUIP_REQUEST_MY_REQUESTS);
                this.NotificationService.successMsg(this.NotificationMessages.REQUEST_SUBMITED_REWORK_SUCCESS);
            } else {
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
            }
        }, (errResponse:IHttpPromiseCallbackArg<any>) => {
            this.$log.error("%s - Error saving request: %s", JSON.stringify(errResponse));
            this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
        });
    }

    private allWeighInsApprove(currentLevel) {
        var approved = true;
        angular.forEach(this.RequestService.request.wfProcessing.levels[currentLevel].weighIns, (weighIn) => {
            if (weighIn.weighInResult === this.WeighInResult.RECOMMEND_REJECT ||
                weighIn.weighInResult === this.WeighInResult.REJECT ||
                weighIn.weighInResult === this.WeighInResult.NEUTRAL) {
                approved = false;
                return;
            }
        });
        return approved;
    }

    private isTabsComplete(){
        if (!this.RequestService.isMaintenanceFormCompleted) {
            this.NotificationService.errorMsg("Missing required <b>Maintenance</b> information.");
            return false;
        } else if (!this.RequestService.isFacilitiesCompleted) {
            this.NotificationService.errorMsg("Missing required <b>Facilities</b> information.");
            return false;
        } else if (!this.RequestService.isSafetyCompleted) {
            this.NotificationService.errorMsg("Missing required <b>Safety</b> information.");
            return false;
        } else if (!this.RequestService.isTechnologiesComplete) {
            this.NotificationService.errorMsg("Missing required <b>Techynology</b> information.");
            return false;
        }else{
            return true;
        }
    }

    private weighInsFinished(currentLevel) {
        var finished = true;
        angular.forEach(this.RequestService.request.wfProcessing.levels[currentLevel].weighIns, (weighIn) => {
            if (weighIn.weighInResult === null && weighIn.weighInStatus != this.WeighInStatus.SKIPPED) {
                finished = false;
                return;
            }
        });
        return finished;
    }
}
