import {RequestService} from "../_services/request.service";
import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {RequestItem} from '../_models/requestItem.model';
import {RequestStatus} from "../_models/requestStatus.model";

import {CurrentUserProfile} from '../../../../_models/currentUserProfile.model';
import {WorkflowLevelProcessing} from '../_models/workflowLevelProcessing.model';

export class ViewRequestShellController {
    private controllerName:string = "View Request Controller";
    private currentUser:CurrentUserProfile = new CurrentUserProfile();

    public activeTab:string;
    public errorMsg:string;
    public noteToEdit:any;

    // @ngInject
    constructor(private $log, private $filter, private $rootScope, private $state, private NotificationMessages,
                private NotificationService, private PermissionService, private ProcessStages, private RequestService, private ResourceConstants,
                private SidePanelService, private StateConstants, private UserService, private ReviewStatus, private ReviewResult,
                private WorkflowLevelStatus, private WorkFlowService) {
        this.$log.debug("%s - Start", this.controllerName);

        this.currentUser = this.UserService.currentUser;

        this.init();
    }

    public editNote(note) {
        this.noteToEdit = angular.copy(note);
    }

    public getStatusClass(levelId) {
        if (this.RequestService.request.wfProcessing != null) {
            if (this.RequestService.request.wfProcessing.levels[levelId].status == this.WorkflowLevelStatus.ACTIVE ||
                this.RequestService.request.wfProcessing.levels[levelId].status == this.WorkflowLevelStatus.HOLD) {
                return "active fa fa-map-marker";
            }
            else if (this.RequestService.request.wfProcessing.levels[levelId].status == this.WorkflowLevelStatus.APPROVED ||
                this.RequestService.request.wfProcessing.levels[levelId].status == this.WorkflowLevelStatus.FORCEDUP) {
                return "active fa fa-circle";
            }
            else if (this.RequestService.request.wfProcessing.levels[levelId].status == this.WorkflowLevelStatus.COMPLETED) {
                return "green fa fa-circle";
            }
            else if (this.RequestService.request.wfProcessing.levels[levelId].status == this.WorkflowLevelStatus.REJECTED) {
                return "red fa fa-circle";
            }
            else if (this.RequestService.request.wfProcessing.levels[levelId].status == this.WorkflowLevelStatus.CANCELLED) {
                return "gray fa fa-circle";
            }
            //else if (this.RequestService.request.wfProcessing.levels[levelId].status == this.WorkflowLevelStatus.SKIPPED) {
            //    return "gray fa fa-circle-o";
            //}
            else {
                return "gray fa fa-circle-o";
            }
        }
    }

    public getVisitedStatusClass(levelId) {
        if (this.RequestService.request.wfProcessing != null) {
            if (this.RequestService.request.wfProcessing.levels[levelId].status != null &&
                this.RequestService.request.wfProcessing.levels[levelId].status != this.WorkflowLevelStatus.REWORK) {
                return "active";
            }
        }
    }

    public goBack() {
        if (this.$rootScope.previousState) {
            this.$state.go(this.$rootScope.previousState);
        } else {
            this.$state.go(this.StateConstants.CATALOG_SEARCH);
        }
    }

    public goToBuildRequest() {
        this.RequestService.buildRequestFromHistory(this.RequestService.request);
        this.$state.go(this.StateConstants.EQUIP_REQUEST_VIEW);
        this.activeTab = 'request';
    }

    public isRequestAtUsersLevel(request) {
        return this.WorkFlowService.isRequestAtUsersLevel(request);
    }

    public isUserAssignedToReview(currentLevelId, role) {
        return this.WorkFlowService.isUserAssignedToReview(currentLevelId, role);
    }

    public removeNote(noteToBeDeleted, id) {
        this.RequestService.removeNote(noteToBeDeleted, id);
    }

    public saveNote() {
        this.RequestService.saveNote(this.RequestService.selectedNoteSection, angular.copy(this.noteToEdit));
        this.noteToEdit = null;
    }

    public showReadOnly(permElement) {
        // If the request is completed
        // Then, it is readonly
        if(this.WorkFlowService.isWorkflowCompleted(this.RequestService.request)){
            return true;
        }

        // If the request is not at the user's level
        // Then, it is readonly
        if(!this.isRequestAtUsersLevel(this.RequestService.request)){
            return true;
        }

        //If the level is allowed to modify the request - this is for the request tab
        if(this.RequestService.request.wfProcessing) {
            var currentLevel = this.RequestService.request.wfProcessing.currentLevelId;
            if(permElement == null){
                //If the level is not allowed to modify the request
                if(!this.WorkFlowService.workflowDef.levelDefinitions[currentLevel].rules.allowModify) {
                    return true;
                }
                //If the user is allowed to modify the request
                if(!this.PermissionService.checkElements(this.ResourceConstants.EQUIP_REQUESTS_UPDATE)){
                    return true;
                }
            }
        }

        // The User has permission and it is at their level
        if(permElement && this.PermissionService.checkElements(permElement) &&
            this.isRequestAtUsersLevel(this.RequestService.request)){
            //If it is pending is the user assigned to the review
            if(this.WorkFlowService.performingReview(permElement) &&
                !this.isUserAssignedToReview(this.RequestService.request.wfProcessing.currentLevelId, permElement)){
                return true;
            }
        }

        // If permission is needed to access the tab,
        // And the user does not have this permission,
        // Them it is readonly
        if(permElement && !this.PermissionService.checkElements(permElement)){
            return true;
        }

        return false;
    }

    private init() {
        if (this.RequestService.request.requestInformation.submitter.userId === "") {
            this.RequestService.request.requestInformation.submitter.userId = this.UserService.currentUser.id;
            this.RequestService.request.requestInformation.submitter.email = this.UserService.currentUser.email;
            this.RequestService.request.requestInformation.submitter.firstName = this.UserService.currentUser.firstName;
            this.RequestService.request.requestInformation.submitter.lastName = this.UserService.currentUser.lastName;
            this.RequestService.request.requestInformation.submitter.phoneNumber = this.UserService.currentUser.phoneNumbers[0].value;
            this.RequestService.request.requestInformation.submitter.dodaac = this.UserService.currentUser.dodaac;
            this.RequestService.request.requestInformation.submitter.regionCode = this.UserService.currentUser.regionCode;
            this.RequestService.request.requestInformation.submitter.serviceCode = this.UserService.currentUser.serviceCode;
        }

        // if the user is a manager the active tab will be the manage tab
        // TODO: You can take a user to any tab based on their element, not just manage
        if (this.RequestService.request.wfProcessing &&
            this.PermissionService.checkElements(this.ResourceConstants.EQUIP_REQUESTS_REVIEW) && !this.RequestService.request.wfProcessing.isCompleted) {
            this.activeTab = 'manage';
        } else {
            this.activeTab = 'request';
        }

        if (this.RequestService.request.wfProcessing) {
            this.WorkFlowService.workflowDef = this.RequestService.request.wfProcessing.wfDefinition;
            this.WorkFlowService.progressBarElementWidth = {"width": 100 / this.WorkFlowService.workflowDef.levelDefinitions.length + "%"};
        } else {
            this.WorkFlowService.getWorkflowDefinition(this.UserService.currentUser.serviceCode);
        }

    }

}