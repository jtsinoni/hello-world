'use strict';
import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {Review} from "../../_models/review.model";

export default class TabMaintenanceController {
    public installationRequired:boolean;
    public literatureTypes:Array<any> = [];
    public provideMaintenance:string;
    public tmdeRequired:boolean;
    public trainingLocations:Array<any> = [];
    public errorMsg:string;
    public reviewName:string = "equip-request-maintenance";
    public review:Review;

    private controllerName: string = "Tab Maintenance Controller";

    // @ngInject
    constructor(private $log,private $scope, private ContentConstants, private NotificationService, private PermissionService, private RequestApi,
                private RequestService, private WorkFlowService, private UtilService, private ReviewStatus) {
        this.$log.debug("%s - Start", this.controllerName);

        this.init();

        this.$scope.$watch(() => this.RequestService.request.requestInformation.equipment.isFoundInCatalog,
            (oldValue: boolean, newValue: boolean) => {
                this.setBooleanFlags();
                if(!this.RequestService.request.requestInformation.equipment.isFoundInCatalog){
                    this.RequestService.request.maintenanceInformation.acceptanceInspection = null;
                }
            });
    }

    public removeExtraItem(item, id){
        angular.element(id).addClass("fadeOut");
        this.RequestService.removeExtraItem(item);
        if(this.RequestService.request.requestInformation.extraItems.length<1){
            angular.element('#repairPartsTable').addClass("fadeOut");
        }
    }

    public addComment(){
        this.WorkFlowService.addReviewComment(true, false);
    }

    public removeInstallationRequirement(req, id){
        angular.element(id).addClass("fadeOut");
        this.RequestService.removeInstallationRequirement(req);
        if(this.RequestService.request.maintenanceInformation.installationRequirements.length<1){
            angular.element('#installationRequirementTable').addClass("fadeOut");
        }
    }

    public removeLiterature(literature, id){
        angular.element(id).addClass("fadeOut");
        this.RequestService.removeLiterature(literature);
        if(this.RequestService.request.maintenanceInformation.literature.length<1){
            angular.element('#literature').addClass("fadeOut");
        }
    }

    public removeTraining(training, id){
        angular.element(id).addClass("fadeOut");
        this.RequestService.removeTraining(training);
        if(this.RequestService.request.requestInformation.training.length<1){
            angular.element('#training').addClass("fadeOut");
        }
    }

    public verifyMaintenanceForm(){
        this.RequestService.verifyMaintenanceForm(this.installationRequired,
                                                    this.provideMaintenance,
                                                    this.tmdeRequired);
    }

    private init(){
        this.loadTrainingLocations();
        this.loadLiteratureTypes();
        this.setBooleanFlags();
    }

    private loadLiteratureTypes(){
        this.RequestApi.getLiteratureTypes().then((response:IHttpPromiseCallbackArg<any>) => {
            this.literatureTypes = this.UtilService.sortResults(response.data, "literatureTypeTx", true);
            if (!this.literatureTypes || !this.literatureTypes[0]) {
                console.log("%s - Error getting literature types");
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
            }
        }, (errResponse:IHttpPromiseCallbackArg<any>) => {
            console.log("%s - Error getting literature types");
            this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
        });
    }

    private loadTrainingLocations(){
        this.RequestApi.getTrainingLocations().then((response:IHttpPromiseCallbackArg<any>) => {
            this.trainingLocations = this.UtilService.sortResults(response.data, "trainingLocationTypeTx", true);
            if (!this.trainingLocations || !this.trainingLocations[0]) {
                console.log("%s - Error getting training location");
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
            }
        }, (errResponse:IHttpPromiseCallbackArg<any>) => {
            console.log("%s - Error getting training locations");
            this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
        });
    }

    private setBooleanFlags(){
        if(this.RequestService.request.maintenanceInformation.maintenanceExplanation){
            this.provideMaintenance = 'true';
        }
        else{
            this.provideMaintenance = 'false';
        }
        if (this.RequestService.request.maintenanceInformation.tmdeRequired){
            this.tmdeRequired = true;
        }
        else {
            this.tmdeRequired = false;
        }
        if (this.RequestService.request.maintenanceInformation.installationRequired){
            this.installationRequired = true;
        }
        else{
            this.installationRequired = false;
        }
        if(this.RequestService.request.maintenanceInformation.acceptanceInspection == null &&
            this.RequestService.request.catalogItem != null){
            if(this.RequestService.request.catalogItem.eiMaintReqrCd == 'Y'){
                this.RequestService.request.maintenanceInformation.acceptanceInspection = true;
            }
            else{
                this.RequestService.request.maintenanceInformation.acceptanceInspection = false;
            }
        }
    }
}
