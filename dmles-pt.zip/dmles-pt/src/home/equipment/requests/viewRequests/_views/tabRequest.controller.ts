import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {RequestItem} from '../../_models/requestItem.model';
import {User} from '../../../../../_models/user.model';
import {CurrentUserProfile} from "../../../../../_models/currentUserProfile.model";

export default class TabRequestController {
    private controllerName:string = "Tab Request Controller";
    private currentUser:CurrentUserProfile = new CurrentUserProfile();
    private requestReasons:Array<any>;

    public equipmentReqCols:any = [
        { name: 'Category', modelName: 'category', dataType: 'text' },
        { name: 'Requirement', modelName: 'requirement', dataType: 'text' },
        { name: 'Specification', modelName: 'specification', dataType: 'text' }
    ];

    public extraItemCols:any = [
        { name: 'Type', modelName: 'type', dataType: 'text' },
        { name: 'Description', modelName: 'itemDescription', dataType: 'text' },
        { name: 'Catalog Number', modelName: 'catalogNumber', dataType: 'text' },
        { name: 'Quantity', modelName: 'quantity', dataType: 'number' },
        { name: 'Unit', modelName: 'unitOfPurchase', dataType: 'text' },
        { name: 'Unit Cost', modelName: 'unitCost', dataType: 'currency' }
    ];

    public replacedItemsCols:any = [
        { name: 'ECN', modelName: 'ecn', dataType: 'text' },
        { name: 'Nomenclature', modelName: 'name', dataType: 'text' },
        { name: 'Acquisition Date', modelName: 'acquisitionDate', dataType: 'date' },
        { name: 'Life Expectancy', modelName: 'lifeExpectancy', dataType: 'text' },
        { name: 'Condition', modelName: 'condition', dataType: 'text' },
        { name: 'Recommended Disposition', modelName: 'disposal', dataType: 'text' },
        { name: 'Comments', modelName: 'comment', dataType: 'text' }
    ];

    public trainingCols:any = [
        { name: 'Trainees', modelName: 'trainees', dataType: 'text' },
        { name: 'People', modelName: 'people', dataType: 'text' },
        { name: 'Location', modelName: 'location', dataType: 'text' },
        { name: 'Registration Cost', modelName: 'registrationCost', dataType: 'currency' },
        { name: 'Travel Cost', modelName: 'travelCost', dataType: 'currency' },
        { name: 'Per Diem', modelName: 'perDiem', dataType: 'currency' },
        { name: 'Days', modelName: 'days', dataType: 'text' },
        { name: 'Total', modelName: 'total', dataType: 'currency' },
        { name: 'Comments', modelName: 'comments', dataType: 'text' }
    ];

    public advancedWhyFields:boolean = false;
    public advancedEquipmentFields:boolean = false;
    public advancedExtraItems:boolean = false;
    public additionalRequestFields:boolean = false;
    public advancedSOS:boolean = false;
    public advancedTraining:boolean = false;
    public changeItemIdMessage:string = '';
    public compAccSupInfoDisabled:boolean;
    public customerInfoDisabled:boolean;
    public dateOptions:any;
    public deviceList:Array<any> = [];
    public ecnFound:boolean = false;
    public equipmentInfoDisabled:boolean;
    public equipmentOptionCategories:any;
    public equipmentOptions:Array<any> = [];
    public errorMsg:string;
    public isRequestedDeliveryDateCalendarOpen:boolean;
    public isContractExpDateCalendarOpen:boolean;
    public isSupplierCatalogDateCalendarOpen:boolean;
    public isThereAPrimarySource:boolean;
    public itemIdProvided:string;
    public loadingECN:boolean = false;
    public manufacturerList:string;
    public mountingTypes:string;
    public organizations:Array<any>;
    public filteredRequestReasons:Array<any>;
    public requestInfoDisabled:boolean;
    public requestTypes:Array<any>;
    public requiresOtherSystems:boolean = false;
    public selectedDevice:any;
    public suggestedSourceDisabled:boolean;
    public trainingDisabled:boolean;
    public traineeTypes:Array<any>;
    public trainingLocations:Array<any>;
    public criticalCodes:Array<any>;
    public itemVerificationStatus:boolean = false;

    public submittedOn:Date = null;
    public completedOn:Date = null;

    //public sortDescending = false;

    // @ngInject
    constructor(private $filter, private $log, private $scope, private CatalogService, private ContentConstants, private dataService,
                private EquipmentRecordService, private ProcessStages, private NotificationService, private SiteService,
                private RequestApi, private RequestService, private uibDateParser, private UserService, private UtilService,
                private WorkFlowService) {
        this.$log.debug("%s - Start", this.controllerName);
        this.currentUser = this.UserService.currentUser;
        this.init();

        this.$scope.$watch(() => this.RequestService.request.requestInformation.equipment.isFoundInCatalog,
            (oldValue: boolean, newValue: boolean) => {
                this.setFlagForIdProvided();
                if(this.RequestService.request.wfProcessing){
                    this.equipmentInfoDisabled = false;
                }
            });
    }

    public addEquipmentRequirement(){
        this.RequestService.addEquipmentRequirement();
    }

    public addExtraItem(){
        this.RequestService.addExtraItem();
    }

    public addItemBeingReplaced(){
        this.RequestService.addItemBeingReplaced();
    }

    public addSuggestedSource(source:any){
        this.RequestService.addSuggestedSource(source);
    }

    public addTraining(){
        this.RequestService.addTraining();
    }
    public calcFunding(){
        if(this.RequestService.request.requestInformation.quantityRequested && this.RequestService.request.requestInformation.equipment.unitCost){
            var quantity:any = this.RequestService.request.requestInformation.quantityRequested;
            var price:any = this.RequestService.request.requestInformation.equipment.unitCost;
            var total:number = parseInt(quantity) * parseFloat(price);
            this.RequestService.request.totalRequisitionCost = total;
        }else{
            this.RequestService.request.totalRequisitionCost = null;
        }
    }

    public clearSuggestedSources(){
        this.RequestService.clearSuggestedSources();
    }

    // TODO: Move this logic to BT
    public doECNItemVerification(item){
        this.loadingECN = true;
        if(!this.RequestService.request.requestInformation.customer){
            this.NotificationService.errorMsg("The verification can not be completed until a customer is selected");
            this.loadingECN = false;
            return;
        }
        if(item.ecn) {
            item.ecn = this.formatEcn(angular.copy(item.ecn));
            this.EquipmentRecordService.getSummaryEquipmentRecords(item.ecn, "(deleteInd:N) (custOrgId:\""+ this.RequestService.request.requestInformation.customer.customerID + "\")").then((result1) => {
                this.loadingECN = false;
                var ecnFound = false;
                //This is because of the async rest call
                var ecnPotentialMatch = false;
                var results = this.EquipmentRecordService.parseSummaryEquipmentRecordResults(result1);
                angular.forEach(results, (record) => {
                    if (record.ecn == item.ecn && record.orgId == this.currentUser.dodaac) {
                        ecnPotentialMatch = true;
                        this.EquipmentRecordService.postFindEquipmentRecordDetail(record).then((result2) => {
                            if (result2) {
                                this.EquipmentRecordService.parseDetailEquipmentRecordResults(result2, record);
                                angular.forEach(this.RequestService.request.requestInformation.replacedItems, (i:any) => {
                                    if (i.ecn === item.ecn) {
                                        i.name = record.nomenclature;
                                        i.acquisitionDate = record.acquisitionDate;
                                        i.lifeExpectancy = record.lifeExpectancy;
                                        i.condition = record.condition;
                                        ecnFound = true;
                                        return;
                                    }
                                });
                                if(!ecnFound){
                                    this.NotificationService.errorMsg("<b>" + item.ecn + "</b> is not a valid ECN for " + this.RequestService.request.requestInformation.customer.customerName);
                                }
                            }
                            else{
                                this.NotificationService.errorMsg("This is not a valid ECN.");
                            }
                        });
                        return;
                    }
                });
                if(results.length == 0 || !ecnPotentialMatch){
                    this.NotificationService.errorMsg("<b>" + item.ecn + "</b> is not a valid ECN for " + this.RequestService.request.requestInformation.customer.customerName);
                }
            });
        }else {
            this.NotificationService.errorMsg("Please enter a value for ecn.");
        }
        this.RequestService.verifyRequestForm();
    }

    public getCatItems(itemId){
        //This is serching just on the itemId Field
        return this.CatalogService.getEquipItems(itemId, this.currentUser.dodaac, "").then((result) => {
            var results = this.CatalogService.parseEquipResults(result);
            return results;
        });
    }

    public getRequirements(category){
        var list:Array<string> = [];
        angular.forEach(this.equipmentOptionCategories, (option)=> {
            if (option.name == category) {
                list = option.requirements;
                return;
            }
        });
        return list;
    }
    public isCompAccSupFormDisabled(){
        return this.compAccSupInfoDisabled && this.RequestService.request.wfProcessing != null;
    }


    public isCustomerFormDisabled(){
        return this.customerInfoDisabled && this.RequestService.request.wfProcessing != null;
    }

    public isEquipmentInfoFormDisabled(){
        return this.equipmentInfoDisabled && this.RequestService.request.wfProcessing != null;
    }

    public isRequestInfoFormDisabled(){
        return this.requestInfoDisabled && this.RequestService.request.wfProcessing != null;
    }

    public isSuggestedSourceFormDisabled(){
        return this.suggestedSourceDisabled && this.RequestService.request.wfProcessing != null;
    }

    public isTrainingFormDisabled(){
        return this.trainingDisabled && this.RequestService.request.wfProcessing != null;
    }

    public onSelect($item, $model, $label){
        this.RequestService.addCatalogInfoToRequest($item);
        this.verifyEquipmentCriteria();
    }

    public showEditable(){
        return(this.customerInfoDisabled  &&
        this.equipmentInfoDisabled &&
        this.compAccSupInfoDisabled &&
        this.requestInfoDisabled &&
        this.suggestedSourceDisabled &&
        this.trainingDisabled);
    }

    public removeEquipmentRequirement(requirement, id){
        angular.element(id).addClass("fadeOut");
        this.RequestService.removeEquipmentRequirement(requirement);
        if(this.RequestService.request.requestInformation.equipmentRequirements.length<1){
            angular.element('#equipmentRequirementsTableHeader').addClass("fadeOut");
        }
    }

    public removeExtraItem(item, id){
        angular.element(id).addClass("fadeOut");
        this.RequestService.removeExtraItem(item);
        if(this.RequestService.request.requestInformation.extraItems.length<1){
            angular.element('#extraItemTable').addClass("fadeOut");
        }
    }

    public removeItemBeingReplaced(item, id){
        angular.element(id).addClass("fadeOut");
        this.RequestService.removeItemBeingReplaced(item);
    }

    public removeSource(source, id){
        angular.element(id).addClass("fadeOut");
        this.RequestService.removeSuggestedSource(source);
    }

    public removeTraining(training, id){
        angular.element(id).addClass("fadeOut");
        this.RequestService.removeTraining(training);
        if(this.RequestService.request.requestInformation.training.length<1){
            angular.element('#trainingTable').addClass("fadeOut");
        }
    }

    public saveRequestCustomerInfo(){
        if (this.RequestService.isCustomerFormCompleted) {
            var getLevelsCriteriaNeeded =  this.WorkFlowService.getLevelsCriteriaNeeded(this.RequestService.request);
            getLevelsCriteriaNeeded.then((result) => {
                if(result || !result){
                    var saveRequestCustomerInfo = this.RequestService.saveRequestCustomerInfo();
                    saveRequestCustomerInfo.then((result) => {
                        if(result && this.RequestService.request.wfProcessing != null){
                            this.customerInfoDisabled = true;
                        }
                    });
                }
            });
        }
        else {
            this.NotificationService.errorMsg("This request is missing required information.");
        }
    }

    public saveRequestEquipmentInfo(){
        this.verifyEquipmentCriteria();
        if (this.RequestService.isEquipmentFormCompleted) {
            var getLevelsCriteriaNeeded =  this.WorkFlowService.getLevelsCriteriaNeeded(this.RequestService.request);
            getLevelsCriteriaNeeded.then((result) => {
                if (result || !result) {
                    var saveRequestEquipmentInfo = this.RequestService.saveRequestEquipmentInfo();
                    saveRequestEquipmentInfo.then((result) => {
                        if (result && this.RequestService.request.wfProcessing != null) {
                            this.equipmentInfoDisabled = true;
                            if(!this.RequestService.isSuggestedSourceFormCompleted){
                                this.suggestedSourceDisabled = false;
                                this.NotificationService.errorMsg("Please update the Suggested Sources");
                            }
                        }
                    });
                }
            });
        }else if(!this.RequestService.verifyReplacedEquipment()){
            this.NotificationService.errorMsg("Please identify the equipment that is being replaced in the <i class=bold>Equipment Information</i> section");
        }else {
            this.NotificationService.errorMsg("Further equipment information required");
        }
    }

    public saveRequestExtraItems(){
        this.RequestService.verifyCompAccSuppliesForm();
        if (this.RequestService.isCompAccSuppliesFormCompleted) {
            var getLevelsCriteriaNeeded =  this.WorkFlowService.getLevelsCriteriaNeeded(this.RequestService.request);
            getLevelsCriteriaNeeded.then((result) => {
                if (result || !result) {
                    var saveRequestExtraItems = this.RequestService.saveRequestExtraItems();
                    saveRequestExtraItems.then((result) => {
                        if (result && this.RequestService.request.wfProcessing != null) {
                            this.compAccSupInfoDisabled = true;
                        }
                    });
                }
            });
        }
        else {
            this.NotificationService.errorMsg("Further component information required");
        }
    }

    public saveRequestInfo(){
        this.RequestService.verifyRequestForm();
        if (this.RequestService.isRequestFormCompleted) {
            var getLevelsCriteriaNeeded =  this.WorkFlowService.getLevelsCriteriaNeeded(this.RequestService.request);
            getLevelsCriteriaNeeded.then((result) => {
                if (result || !result) {
                    var saveRequestInfo = this.RequestService.saveRequestInfo();
                    saveRequestInfo.then((result) => {
                        if (result && this.RequestService.request.wfProcessing != null) {
                            this.requestInfoDisabled = true;
                            //This data is dependen upon the request type. If that is changed to a specific
                            // value then this data below must be entered by the user.
                            if(!this.RequestService.verifyReplacedEquipment()){
                                this.NotificationService.errorMsg("Please identify the equipment that is being replaced in the <i class=bold>Equipment Information</i> section");
                                this. equipmentInfoDisabled = false;
                            }
                        }
                    })
                }
            });
        }
        else {
            this.NotificationService.errorMsg("Further information is required");
        }
    }

    public saveRequestSourceOfSupply(){
        this.RequestService.verifySuggestedSourceForm();
        if (this.RequestService.isSuggestedSourceFormCompleted) {var getLevelsCriteriaNeeded =  this.WorkFlowService.getLevelsCriteriaNeeded(this.RequestService.request);
            getLevelsCriteriaNeeded.then((result) => {
                if (result || !result) {
                    var saveRequestSourceOfSupply = this.RequestService.saveRequestSourceOfSupply();
                    saveRequestSourceOfSupply.then((result) => {
                        if (result && this.RequestService.request.wfProcessing != null) {
                            this.suggestedSourceDisabled = true;
                        }
                    });
                }
            });
        }
        else {
            this.NotificationService.errorMsg("Further suggested source information required");
        }
    }

    public saveRequestTraining(){
        this.RequestService.verifyTrainingForm();
        if (this.RequestService.isTrainingFormCompleted) {
            var getLevelsCriteriaNeeded =  this.WorkFlowService.getLevelsCriteriaNeeded(this.RequestService.request);
            getLevelsCriteriaNeeded.then((result) => {
                if (result || !result) {
                    var saveRequestTraining = this.RequestService.saveRequestTraining();
                    saveRequestTraining.then((result) => {
                        if (result && this.RequestService.request.wfProcessing != null) {
                            this.trainingDisabled = true;
                        }
                    });
                }
            });
        }
        else {
            this.NotificationService.errorMsg("Further training information required");
        }
    }

    public setFieldsForIDProvided(){
        if(this.itemIdProvided === 'false'){
            this.RequestService.request.requestInformation.equipment.manufacturer = "";
            this.RequestService.request.requestInformation.equipment.nomenclature = "";
            this.RequestService.request.requestInformation.equipment.deviceCode = "";
            this.RequestService.request.requestInformation.equipment.model = "";
            this.RequestService.request.requestInformation.equipment.catalogId = "";
            this.RequestService.request.requestInformation.equipment.unitCost = null;
            this.RequestService.request.catalogItem = null;
            this.RequestService.request.requestInformation.equipment.isFoundInCatalog = false;
        }
        this.verifyEquipmentCriteria();
    }

    public setOrgforRequest(){
        this.RequestService.request.requestInformation.organization = {organizationID:this.RequestService.selectedOrgObj.organizationID,
                                                    organizationOrgName:this.RequestService.selectedOrgObj.organizationOrgName,
                                                    organizationSerial: this.RequestService.selectedOrgObj.organizationSerial};
        this.RequestService.verifyCustomerForm();
    }

    public setPrimarySource(sourceToUpdate : any){
        angular.forEach(this.RequestService.request.requestInformation.suggestedSources,(source: any) => {
            if(source != sourceToUpdate) {
                source.primarySource = false;
            }
            else {
                source.primarySource = sourceToUpdate.primarySource;
            }
        });
        this.RequestService.isThereAPrimarySource = sourceToUpdate.primarySource;
        this.RequestService.verifySuggestedSourceForm();
    }

    public setRequestReasons(){
        if (this.RequestService.request.requestInformation.requestType && (this.RequestService.request.requestInformation.requestType.code ==='N' ||
            this.RequestService.request.requestInformation.requestType.code === 'A' || this.RequestService.request.requestInformation.requestType.code === 'U')){
                this.additionalRequestFields = true;
            if(this.RequestService.request.requestInformation.replacedItems.length == 0) {
                this.addItemBeingReplaced();
            }
        }
        else{
            this.RequestService.request.requestInformation.replacedItems = [];
            this.additionalRequestFields = false;
            this.RequestService.clearItemBeingReplaced();
        }
        this.filteredRequestReasons = [];
        if(this.RequestService.request.requestInformation.requestType){
            angular.forEach(this.requestReasons, (reason) => {
                if (reason.mask.indexOf(this.RequestService.request.requestInformation.requestType.code) != -1) {
                    this.filteredRequestReasons.push(reason);
                }
            });
        }
        this.RequestService.verifyRequestForm();
    }

    public setSpecification(option){
        angular.forEach(this.RequestService.request.facilityInformation.utilities,(utility:any) =>{
            var text:string = "";
            if(utility.name === 'Structural'){
                angular.forEach(this.RequestService.request.requestInformation.equipmentRequirements,(opt) => {
                    //All of these will show up under 'Structural' on the Facilities tab
                    if (opt.category === "Structural") {
                        text = text + opt.requirement + ': ' + opt.specification + ' ';
                    }
                });
            }
            else if(utility.name === 'Electrical'){
                angular.forEach(this.RequestService.request.requestInformation.equipmentRequirements,(opt) => {
                    //All of these will show up under 'Electrical' on the Facilities tab
                    if (opt.category === "Electrical") {
                        text = text + opt.specification + ' ' + opt.requirement + ' ';
                    }
                });
            }
            else if(utility.name === 'Other'){
                angular.forEach(this.RequestService.request.requestInformation.equipmentRequirements,(opt) => {
                    //All of these will show up under 'Other' on the Facilities tab
                    if (opt.category === "Other") {
                        text = text + opt.specification + ' ';
                    }
                });
            }
            else{
                angular.forEach(this.RequestService.request.requestInformation.equipmentRequirements,(opt) => {
                    if(utility.name === opt.requirement){
                        text = opt.specification;
                        return;
                    }
                });
            }
            utility.specifications = text;
        });
        angular.forEach(this.RequestService.request.technologyInformation.technologyRequirements,(tech:any) =>{
            tech.specifications = "";
            angular.forEach(this.RequestService.request.requestInformation.equipmentRequirements,(opt) => {
                if(tech.name === opt.requirement){
                    tech.specifications = opt.specification;
                    return;
                }
            });
        });
    }

    public verifyECNS(){
        if (this.RequestService.request.requestInformation.replacedItems.length > 0 &&
            this.RequestService.request.requestInformation.replacedItems[0].name){
            angular.forEach(this.RequestService.request.requestInformation.replacedItems, (item:any) => {
                item.name = "";
                item.acquisitionDate = null;
                item.lifeExpectancy = "";
                item.condition = "";
                item.disposal = "";
            });
            this.NotificationService.errorMsg("The Customer changed. You need to verify the equipment you want to replace.");
        }
        this.RequestService.verifyCustomerForm();
    }

    public setDeviceCode($item, $model, $label){
        this.RequestService.request.requestInformation.equipment.deviceCode = $item.deviceCode;
        this.RequestService.verifyEquipmentCriteria(this.requiresOtherSystems);
    }

    public verifyEquipmentCriteria(){
        this.RequestService.verifyEquipmentCriteria(this.requiresOtherSystems);
    }

    private formatEcn(ecn){
        this.$log.debug(ecn);
        if(ecn.length == 6){
            return ecn;
        }
        else{
            return this.formatEcn(0 + angular.copy(ecn));
        }

    }

    /**
     * If the request has not been saved and it is not being populated by the cart
     * then, populate it with as much of the user's data as possible.
     */
    private init() {
        this.initCalander();
        this.setFlagForIdProvided();
        this.setFlagForRequiresOtherSystems();
        this.RequestService.verifyRequest();
        this.loadDevices();
        this.loadOrganizations();
        this.loadRequestReasons();
        this.loadCriticalityCodes();
        this.loadEquipmentOptionCategories();
        this.loadManufacturers();
        this.loadMountingTypes();
        this.loadTraineeTypes();
        this.loadTrainingLocations();
        this.setEditFlags();
        this.determineHistoricalDates();
    }

    private determineHistoricalDates(){
        if(this.RequestService.request.wfProcessing && this.RequestService.request.wfProcessing.history) {
            this.submittedOn = this.RequestService.request.wfProcessing.history[0].when;
            if(this.RequestService.request.wfProcessing.isCompleted){
                var len:number = this.RequestService.request.wfProcessing.history.length;
                if(len > 0){
                    len = len - 1;
                }
                this.completedOn = this.RequestService.request.wfProcessing.history[len].when;
            }
        }
    }

    private initCalander(){
        var today = new Date();

        //These are for the ui-datepickers. They have issues reading the value
        if(this.RequestService.request.requestInformation.requestedDeliveryDate) {
            //noinspection TypeScriptValidateTypes
            this.RequestService.request.requestInformation.requestedDeliveryDate = new Date(this.RequestService.request.requestInformation.requestedDeliveryDate);
        }

        angular.forEach(this.RequestService.request.requestInformation.suggestedSources, (source:any) => {
            if(source.contractExpDate) {
                source.contractExpDate = new Date(source.contractExpDate);
            }
            if(source.supplierCatalogDate) {
                source.supplierCatalogDate = new Date(source.supplierCatalogDate);
            }
        });

        this.isRequestedDeliveryDateCalendarOpen = false;
        this.isContractExpDateCalendarOpen = false;
        this.isSupplierCatalogDateCalendarOpen = false;
        this.dateOptions = {
            formatYear:'yyyy',
            initDate: today,
            minDate: today,
            maxMode:'month',
            startingDay: 0,
            showWeeks: false
        };
    }

    private loadCriticalityCodes() {
        this.RequestApi.getCriticalityCodes(this.currentUser.serviceCode).then((response:IHttpPromiseCallbackArg<any>) => {
            this.criticalCodes = response.data[0].criticalCodes;
            if (!this.criticalCodes || !this.criticalCodes[0]) {
                console.log("%s - Error getting criticality codes");
                this.errorMsg = this.ContentConstants.ERR_MSG;
            }
        }, (errResponse:IHttpPromiseCallbackArg<any>) => {
            console.log("%s - Error getting criticality codes");
            this.errorMsg = this.ContentConstants.ERR_MSG;
        });
    }

    private loadDevices(){
        this.RequestApi.getDevices().then((response:IHttpPromiseCallbackArg<any>) => {
            this.deviceList = this.UtilService.sortResults(response.data, "nomenclature", true);
            if (!this.deviceList || !this.deviceList[0]) {
            console.log("%s - Error getting Devices List");
            this.errorMsg = this.ContentConstants.ERR_MSG;
        }
        }, (errResponse:IHttpPromiseCallbackArg<any>) => {
            console.log("%s - Error getting Devices List");
            this.errorMsg = this.ContentConstants.ERR_MSG;
        });
    }

    // TODO: Move this to the DB
    private loadEquipmentOptionCategories(){
        this.equipmentOptionCategories = [
            {
                name: "Structural",
                requirements: ["Height","Width","Depth","Weight"]},
            {
                name: "Electrical",
                requirements:["Amps", "Hertz","Phase", "Voltage", "Second Power Source"]},
            {
                name: "Utilities",
                requirements: ["Water", "Lighting", "Drain", "Steam", "Gas", "HVAC", "Ventilation"]},
            {
                name: "Technology",
                requirements: ["LAN/Network Connection", "Communication", "IT Accreditation+", "Software Technical Support",
                    "Hardware Technical Support", "Fiberoptic Connection", "Radio-Frequency Identification (RFID)", "Wi-Fi"]},
            {
                name: "Other",
                requirements: ["Airworthy","Color","Operation","Mounting","Other"]}
        ];
    }

    private loadMountingTypes(){
        this.RequestApi.getMountingTypes().then((response:IHttpPromiseCallbackArg<any>) => {
            this.mountingTypes = this.UtilService.sortResults(response.data, "equipMountingTypeTx", true);
            if (!this.mountingTypes || !this.mountingTypes[0]) {
                console.log("%s - Error getting Mounting Types");
                this.errorMsg = this.ContentConstants.ERR_MSG;
            }
        }, (errResponse:IHttpPromiseCallbackArg<any>) => {
            console.log("%s - Error getting Mounting Types");
            this.errorMsg = this.ContentConstants.ERR_MSG;
        });
    }

    private loadManufacturers(){
        this.RequestApi.getManufacturers().then((response:IHttpPromiseCallbackArg<any>) => {
            this.manufacturerList = this.UtilService.sortResults(response.data, "organizationNm", true);
            if (!this.manufacturerList || !this.manufacturerList[0]) {
                console.log("%s - Error getting Manufacturers List");
                this.errorMsg = this.ContentConstants.ERR_MSG;
            }
        }, (errResponse:IHttpPromiseCallbackArg<any>) => {
            console.log("%s - Error getting Manufacturers List");
            this.errorMsg = this.ContentConstants.ERR_MSG;
        });
    }

    private loadOrganizations() {
        if(this.currentUser.dodaac){
            this.SiteService.getSiteOrgsByDodaac(this.currentUser.dodaac).then((response:IHttpPromiseCallbackArg<any>) => {
                // TODO: Can a DoDAAC have multiple orgs or no orgs?
                // This logic assumes its a one-to-one association, could there be more that one returned???
                var siteOrgs:any = response.data[0];

                // Sort if more than one, not sure if this is working properly...
                if (siteOrgs.emAssociatedORGIDS) {
                    this.organizations = this.UtilService.sortResults(siteOrgs.emAssociatedORGIDS, "organizationOrgName", true);
                    if(this.RequestService.request.requestInformation.organization) {
                        //We used selectedOrgObj instead of the request.organization directly because we don't want to attach the
                        //the entire list of all customers with the data. We only want to include the customer selected
                        angular.forEach(this.organizations, (org) => {
                            if(org.organizationID === this.RequestService.request.requestInformation.organization.organizationID){
                                this.RequestService.selectedOrgObj = org;}
                        });

                    }
                }
            }, (errResponse:IHttpPromiseCallbackArg<any>) => {
                this.$log.error("%s - Error loading organizations: %s", this.controllerName, errResponse);

            });
        }else{
            this.$log.warn("%s - User is not associated with a DoDAAC", this.controllerName);
        }
    }

    private loadRequestReasons() {
        this.RequestApi.getEquipmentRequestReasons().then((response:IHttpPromiseCallbackArg<any>) => {
            this.requestReasons = this.UtilService.sortResults(response.data, "name", true);
            //This sets off processes that need the reasons so the types can't be loaded till the reasons are
            this.loadRequestTypes();
            if (!this.requestReasons || !this.requestReasons[0]) {
                console.log("%s - Error getting request reasons");
                this.errorMsg = this.ContentConstants.ERR_MSG;
            }
        }, (errResponse:IHttpPromiseCallbackArg<any>) => {
            console.log("%s - Error getting request reasons");
            this.errorMsg = this.ContentConstants.ERR_MSG;
        });
    }

    private loadRequestTypes() {
        this.RequestApi.getEquipmentRequestTypes().then((response:IHttpPromiseCallbackArg<any>) => {
            this.requestTypes = this.UtilService.sortResults(response.data, "name", true);
            this.setRequestReasons();
        }, (errResponse:IHttpPromiseCallbackArg<any>) => {
            console.log("%s - Error getting equipment request type");
            this.errorMsg = this.ContentConstants.ERR_MSG;
        });
    }

    private loadTraineeTypes(){
        this.RequestApi.getTraineeTypes().then((response:IHttpPromiseCallbackArg<any>) => {
            this.traineeTypes = this.UtilService.sortResults(response.data, "equipTraineeTypeTx", true);
            if (!this.traineeTypes || !this.traineeTypes[0]) {
                console.log("%s - Error getting trainee types");
                this.errorMsg = this.ContentConstants.ERR_MSG;
            }
        }, (errResponse:IHttpPromiseCallbackArg<any>) => {
            console.log("%s - Error getting trainee types");
            this.errorMsg = this.ContentConstants.ERR_MSG;
        });
    }

    private loadTrainingLocations(){
        this.RequestApi.getTrainingLocations().then((response:IHttpPromiseCallbackArg<any>) => {
            this.trainingLocations = this.UtilService.sortResults(response.data, "trainingLocationTypeTx", true);
            if (!this.trainingLocations || !this.trainingLocations[0]) {
                console.log("%s - Error getting training location");
                this.errorMsg = this.ContentConstants.ERR_MSG;
            }
        }, (errResponse:IHttpPromiseCallbackArg<any>) => {
            console.log("%s - Error getting training locations");
            this.errorMsg = this.ContentConstants.ERR_MSG;
        });
    }

    public setEditFlags(){
        this.requestInfoDisabled = this.RequestService.request.wfProcessing != null;
        this.customerInfoDisabled = this.RequestService.request.wfProcessing != null;
        this.equipmentInfoDisabled = this.RequestService.request.wfProcessing != null;
        this.compAccSupInfoDisabled = this.RequestService.request.wfProcessing != null;
        this.suggestedSourceDisabled = this.RequestService.request.wfProcessing != null;
        this.trainingDisabled = this.RequestService.request.wfProcessing != null;
    }

    private setFlagForIdProvided(){
        if(this.RequestService.request.requestInformation.equipment.catalogId){
            this.itemIdProvided = 'true';
        }
        else{
            this.itemIdProvided = 'false';
        }
    }

    private setFlagForRequiresOtherSystems(){
        if(this.RequestService.request.requestInformation.equipment.otherSystemRequired != ""){
            this.requiresOtherSystems = true;
        }
    }
}

