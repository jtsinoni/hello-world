'use strict';

import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {CatalogItem} from '../../../../catalog/_models/catalogItem.model';

export default class TabCatalogItemController {
    private controllerName:string = "Tab Catalog Item Controller";

    // @ngInject
    constructor(private $log, private PermissionService, private RequestService,private UserService,
                private WorkflowLevelStatus, private WorkFlowService) {
        this.$log.debug("%s - Start", this.controllerName);
    }

    public removeCatalogItem(){
        this.RequestService.clearCatalogItem();
    }

    public showButton(){
        //This is if the request hasn't been submitted yet
        if(this.RequestService.request.wfProcessing == null &&
            this.UserService.currentUser.userType == "SITE" &&
            this.WorkFlowService.isRequestAtUsersLevel(this.RequestService.request) &&
            this.UserService.currentUser.id == this.RequestService.request.requestInformation.submitter.userId){
            return true;
        }
        //This is if the request has been submitted only if your the manager can you update
        else if(this.PermissionService.checkElements('equip-update') &&
            this.RequestService.request.wfProcessing &&
            (this.RequestService.request.wfProcessing.currentStatus == this.WorkflowLevelStatus.ACTIVE ||
            this.RequestService.request.wfProcessing.currentStatus == this.WorkflowLevelStatus.HOLD) &&
            this.UserService.currentUser.userType == "SITE" &&
            this.WorkFlowService.isRequestAtUsersLevel(this.RequestService.request) &&
            this.UserService.currentUser.id == this.RequestService.request.requestInformation.submitter.userId){
            return true;
        }
        else{
            return false;
        }
    }
}

