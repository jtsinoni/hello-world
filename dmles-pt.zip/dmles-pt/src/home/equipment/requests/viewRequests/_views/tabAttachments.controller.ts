'use strict';

import {RequestItem} from '../../_models/requestItem.model';
import {UploadFile} from "../../../../../_models/uploadFile.model";
import {UploadFileInformation} from '../../../../../_models/uploadFileInformation.model';

export default class TabAttachmentsController {
    private controllerName: string = "Tab Attachments Controller";

    public filesToBeAdded:any;

  //  public request:RequestItem = new RequestItem();
    public uploader:any = null;
    // @ngInject
    constructor(private $log, private $scope: ng.IScope, private App, private FileExchangeService, private RequestService, private UserService) {
      //  this.$log.debug("%s - Start", this.controllerName);
       // this.request = this.RequestService.request;

    }

    //$scope.fileNameChanged = function(ele) {
    //    this.filesToBeAdded = ele;
    //    console.log(this.filesToBeAdded);
    //}

    public uploadFile(){
        //this.RequestService.request.attachments.push(new UploadFile(file));
       // this.$log.debug(this.RequestService.request.attachments);
    }
}
