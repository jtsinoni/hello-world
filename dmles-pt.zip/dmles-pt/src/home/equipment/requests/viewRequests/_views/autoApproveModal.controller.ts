'use strict';

export default class AutoApproveInstanceController{

    // @ngInject
    constructor(private $log, private $uibModalInstance, private RequestService, private WorkFlowService) {
    }

    //These are the actions of the buttons
    public continue(){
        var save = this.RequestService.save();
        save.then(result => {
            this.$uibModalInstance.dismiss('continue');
        });
    }
    public close(){
        this.RequestService.request.wfProcessing.levels[this.RequestService.request.wfProcessing.currentLevelId].autoApproveAfterReviews = false;
        this.$uibModalInstance.dismiss('cancel');
    }
}