'use strict';
import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {WorkflowLevelProcessing} from "../../_models/workflowLevelProcessing.model";

export default class TabManageController {
    private controllerName:string = "Tab Manage Controller";

    // @ngInject
    constructor(private $log, private $uibModal, private datatableService, private NotificationService,private PermissionService,
                private RequestService, private UserService, private WeighInResult, private WeighInStatus,
                private WorkflowLevelStatus, private WorkFlowService) {
        this.$log.debug("%s - Start", this.controllerName);

    }

    public getBackgroundColor(weighIn){
        if(weighIn.weighInResult == this.WeighInResult.APPROVE ||
            weighIn.weighInResult == this.WeighInResult.RECOMMEND_APPROVE){
            return "text-success";
        }else if(weighIn.weighInResult == this.WeighInResult.REJECT ||
            weighIn.weighInResult == this.WeighInResult.RECOMMEND_REJECT){
            return "text-danger";
        }else{
            return "color-blue";
        }
    }

    public getIcon(weighIn){
        if(weighIn.weighInResult == this.WeighInResult.APPROVE ||
            weighIn.weighInResult == this.WeighInResult.RECOMMEND_APPROVE){
            return "fa-check-circle-o";
        }else if(weighIn.weighInResult == this.WeighInResult.REJECT ||
            weighIn.weighInResult == this.WeighInResult.RECOMMEND_REJECT){
            return "fa-times-circle";
        }else{
            return "fa-circle-o";
        }
    }

    public isRequestAtUsersLevel(){
        return this.WorkFlowService.isRequestAtUsersLevel(this.RequestService.request);
    }

    public openApproval(){
        var currentLevel = this.RequestService.request.wfProcessing.currentLevelId;
        if((!this.WorkFlowService.workflowDef.levelDefinitions[currentLevel].rules.allowWeighInBypassOnApprove &&
            !this.WorkFlowService.weighInsFinished(currentLevel)) ||
            (!this.WorkFlowService.workflowDef.levelDefinitions[currentLevel].rules.allowOwnerOverrideNegativeWeighIns &&
            !this.WorkFlowService.allWeighInsApprove(currentLevel))) {
            this.NotificationService.errorMsg("All the weigh-ins must be approved before you can approve this request");
            return;
        }

        var modalInstance = this.$uibModal.open({
            animation: true,
            ariaLabelledBy: 'modal-title',
            ariaDescribedBy: 'modal-body',
            backdrop: 'static',
            templateUrl: '/src/home/equipment/requests/viewRequests/_views/forceUpModal.html',
            controllerAs: 'vm',
            controller: 'ForceUpModalInstanceController'
        });
    }

    public openAutoApproveModal(){
        if(this.RequestService.request.wfProcessing.levels[this.RequestService.request.wfProcessing.currentLevelId].autoApproveAfterWeighins){
            var modalInstance = this.$uibModal.open({
                animation: true,
                ariaLabelledBy: 'modal-title',
                ariaDescribedBy: 'modal-body',
                backdrop: 'static',
                templateUrl: '/src/home/equipment/requests/viewRequests/_views/autoApproveModal.html',
                controllerAs: 'vm',
                controller: 'AutoApproveInstanceController'
            });
        }
        else{
            this.RequestService.save();
        }

    }

    public setStatus(weighIn, status, loadingWeighInStatus){
        loadingWeighInStatus = true;
        //Could do a WorkFlowService.getWeighInSetStatus, if the status is rework,
        // to open a window to leave a comment
        if(status == this.WeighInStatus.REWORK){
            weighIn.weighInResult = null;
        }
        var setStatus = this.WorkFlowService.setStatusWeighIn(weighIn, status);
        setStatus.then(result => {
            loadingWeighInStatus = false;
        });
    }


    public showApproveButton(){
        if(this.RequestService.request.wfProcessing) {
            var status = this.RequestService.request.wfProcessing.currentStatus;
            var currentLevel = this.RequestService.request.wfProcessing.currentLevelId;
            if (((this.WorkFlowService.workflowDef.levelDefinitions[currentLevel].rules.allowOwnerOverrideNegativeWeighIns ||
                !this.WorkFlowService.allWeighInsApprove(currentLevel)) ||
                this.WorkFlowService.allWeighInsApprove(currentLevel)) &&
                status === this.WorkflowLevelStatus.ACTIVE &&
                this.isRequestAtUsersLevel()) {
                return true;
            } else {
                return false;
            }
        }
        else {
            return false;
        }
    }

    public showAutoApprove(){
        if(this.RequestService.request.wfProcessing) {
            var currentLevel = this.RequestService.request.wfProcessing.currentLevelId;
            if (this.WorkFlowService.workflowDef.levelDefinitions[currentLevel].rules.allowAutoApproveAfterWeighIn &&
                !this.RequestService.request.wfProcessing.isCompleted &&
                this.isRequestAtUsersLevel() &&
                !this.WorkFlowService.weighInsFinished(currentLevel)
            ){
                return true;
            }
            else {
                return false;
            }
        }
        else {
            return false;
        }
    }

    public showForceUp(){
        if(this.RequestService.request.wfProcessing) {
            var currentLevel = this.RequestService.request.wfProcessing.currentLevelId;
            if (this.WorkFlowService.workflowDef.levelDefinitions[currentLevel].rules.allowForceUp &&
                (!this.WorkFlowService.deviceCriteriaMet && !this.WorkFlowService.deviceUnitCostCriteriaMet && !this.WorkFlowService.catalogCriteriaMet && !this.WorkFlowService.costCriteriaMet)) {
                return true;
            }
            else {
                return false;
            }
        }
        else {
            return false;
        }
    }

    public showWeighInSelection(weighIn){
        if(this.RequestService.request.wfProcessing) {
            var currentLevel = this.RequestService.request.wfProcessing.currentLevelId;
            if (this.WorkFlowService.workflowDef.levelDefinitions[currentLevel].rules.allowWeighInSelection &&
                (weighIn.weighInStatus == this.WeighInStatus.NEW ||
                weighIn.weighInStatus == this.WeighInStatus.RECALLED) &&
                this.isRequestAtUsersLevel()) {
                return true;
            } else {
                return false;
            }
        }
        else {
            return false;
        }
    }

    public showCancelButton(){
        if(this.RequestService.request.wfProcessing) {
            var status = this.RequestService.request.wfProcessing.currentStatus;
            var currentLevel = this.RequestService.request.wfProcessing.currentLevelId;
            if(this.RequestService.request.wfProcessing) {
                if (this.WorkFlowService.workflowDef.levelDefinitions[currentLevel].rules.allowCancel &&
                    status === this.WorkflowLevelStatus.ACTIVE &&
                    this.isRequestAtUsersLevel()
                ) {
                    return true;
                } else {
                    return false;
                }
            }
            else {
                return false;
            }
        }
        else {
            return false;
        }
    }

    public showHoldButton(){
        if(this.RequestService.request.wfProcessing) {
            var status = this.RequestService.request.wfProcessing.currentStatus;
            var currentLevel = this.RequestService.request.wfProcessing.currentLevelId;
            if (this.WorkFlowService.workflowDef.levelDefinitions[currentLevel].rules.allowHold &&
                status === this.WorkflowLevelStatus.ACTIVE &&
                this.isRequestAtUsersLevel()
            ) {
                return true;
            } else {
                return false;
            }
        }
        else {
            return false;
        }
    }

    public showOverrideButton(){
        if(this.RequestService.request.wfProcessing) {
            var status = this.RequestService.request.wfProcessing.currentStatus;
            var currentLevel = this.RequestService.request.wfProcessing.currentLevelId;
            if (status === this.WorkflowLevelStatus.ACTIVE &&
                this.isRequestAtUsersLevel()
            ) {
                return true;
            } else {
                return false;
            }
        }
        else {
            return false;
        }
    }

    public showRejectButton(){
        if(this.RequestService.request.wfProcessing) {
            var status = this.RequestService.request.wfProcessing.currentStatus;
            var currentLevel = this.RequestService.request.wfProcessing.currentLevelId;
            if (this.WorkFlowService.workflowDef.levelDefinitions[currentLevel].rules.allowReject &&
                status === this.WorkflowLevelStatus.ACTIVE &&
                this.WorkFlowService.workflowDef.levelDefinitions[currentLevel].userType == this.UserService.currentUser.userType) {
                return true;
            } else {
                return false;
            }
        }
        else {
            return false;
        }
    }

    public showReactivateButton(){
        if(this.RequestService.request.wfProcessing) {
            var status = this.RequestService.request.wfProcessing.currentStatus;
            var currentLevel = this.RequestService.request.wfProcessing.currentLevelId;
            if (status === this.WorkflowLevelStatus.HOLD &&
                this.isRequestAtUsersLevel()
            ) {
                return true;
            } else {
                return false;
            }
        }
        else {
            return false;
        }
    }

    public showRetractButton(){
        if(this.RequestService.request.wfProcessing) {
            var currentLevel = this.RequestService.request.wfProcessing.currentLevelId;
            var usersLevel:WorkflowLevelProcessing = this.WorkFlowService.getUsersWorkflowLevel();
            if (!this.isRequestAtUsersLevel() && usersLevel) {
                if (this.WorkFlowService.workflowDef.levelDefinitions[currentLevel].rules.allowRetract &&
                    (usersLevel.status == this.WorkflowLevelStatus.APPROVED)
                ) {
                    return true;
                } else {
                    return false;
                }
            }
            else {
                return false;
            }
        }
        else{
            return false;
        }
    }

    public showReworkButton(){
        if(this.RequestService.request.wfProcessing) {
            var currentLevel = this.RequestService.request.wfProcessing.currentLevelId;
            if (this.WorkFlowService.workflowDef.levelDefinitions[currentLevel].rules.allowRework &&
                currentLevel != 0 &&
                this.RequestService.request.wfProcessing.currentStatus != this.WorkflowLevelStatus.COMPLETED &&
                this.isRequestAtUsersLevel()
            ) {
                return true;
            } else {
                return false;
            }
        }
        else {
            return false;
        }
    }

    public skip(weighIn, isDisabled, loadingSkipStatus){
        var status:string;
        if(isDisabled){
            status = this.WeighInStatus.SKIPPED;
        }
        else{
            status =  this.WeighInStatus.NEW;
        }

        var setStatus = this.WorkFlowService.setStatusWeighIn(weighIn, status);
        setStatus.then(result => {
            loadingSkipStatus = false;
        });
    }
}