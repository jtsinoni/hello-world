'use strict';

import AutoApproveInstanceController from './autoApproveModal.controller';
import HistoryController from './history.controller';
import ForceUpModalInstanceController from './forceUpModal.controller';
import TabAttachmentsController from './tabAttachments.controller';
import TabMaintenanceController from './tabMaintenance.controller';
import TabManageController from './tabManage.controller';
import TabCatalogItemController from './tabCatalogItem.controller';
import TabFacilitiesController from './tabFacilities.controller';
import TabRequestController from './tabRequest.controller';
import TabSafetyController from './tabSafety.controller';
import TabTechnologiesController from './tabTechnologies.controller';

var controllersModule = angular.module('Dmles.Equipment.Requests.ViewRequests.Views.Module', []);
controllersModule.controller('AutoApproveInstanceController', AutoApproveInstanceController);
controllersModule.controller('HistoryController', HistoryController);
controllersModule.controller('ForceUpModalInstanceController', ForceUpModalInstanceController);
controllersModule.controller('TabAttachmentsController', TabAttachmentsController);
controllersModule.controller('TabMaintenanceController', TabMaintenanceController);
controllersModule.controller('TabManageController', TabManageController);
controllersModule.controller('TabCatalogItemController', TabCatalogItemController);
controllersModule.controller('TabFacilitiesController', TabFacilitiesController);
controllersModule.controller('TabRequestController', TabRequestController);
controllersModule.controller('TabSafetyController', TabSafetyController);
controllersModule.controller('TabTechnologiesController', TabTechnologiesController);

export default controllersModule;