'use strict';

import {RequestItem} from '../../_models/requestItem.model';

export default class TabFacilitiesController {
    private controllerName: string = "Tab Facilities Controller";
    public weighInName:string = "equip-request-facilities";
    public facModRequired:boolean = false;

   // public request:RequestItem = new RequestItem();
    // @ngInject
    constructor(private $log, private PermissionService, private RequestService,
                private UserService, private WeighInResult, private WeighInStatus, private WorkFlowService) {
        this.$log.debug("%s - Start", this.controllerName);
      //  this.request = this.RequestService.request;
        this.init();
    }

    public addComment(){
        this.WorkFlowService.addWeighInComment(true, false);
    }

    public verifyFacilitiesComplete(item) {
        var utilCount:number = 0;
        this.facModRequired = false;
        if(this.RequestService.request.facilityInformation.utilities) {
            for (var u in this.RequestService.request.facilityInformation.utilities) {
                var utilItem:any = this.RequestService.request.facilityInformation.utilities[u];
                //Add to match it with the current checkbox that was changed because for some reason the ng-modal
                //wasn't binding the checkboxes from the ng-repeat to the data.
                if(item && item.name === utilItem.name){
                    utilItem.required = item.required;
                    utilItem.available = item.available;
                    utilItem.na = item.na;
                    utilItem.comments = item.comments;
                }
                if (utilItem.required || utilItem.available || utilItem.na) {
                    if((utilItem.required && utilItem.comments) ||
                        !utilItem.required) {
                        utilCount = utilCount + 1;
                    }
                    if(utilItem.required){
                        this.facModRequired = true;
                    }
                } else {
                    break;
                }
            }
        }

        if (this.RequestService.request.facilityInformation.utilities.length === utilCount &&
            ((this.facModRequired && this.RequestService.request.facilityInformation.facilityModifications) ||
            !this.facModRequired)) {
            this.RequestService.isFacilitiesCompleted = true;
        } else {
            this.RequestService.isFacilitiesCompleted = false;
        }
        this.RequestService.calculateTotalPrice();
    }

    private init() {
        this.verifyFacilitiesComplete(null);
    }
}

