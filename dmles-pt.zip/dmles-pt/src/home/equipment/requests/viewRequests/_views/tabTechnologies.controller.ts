'use strict';

export default class TabTechnologiesController {
    private controllerName: string = "Tab Technology Controller";
    public weighInName:string = "equip-request-technology";
    // public request:RequestItem = new RequestItem();
    // @ngInject
    constructor(private $log, private PermissionService, private RequestService,
                private UserService, private WeighInResult, private WeighInStatus,  private WorkFlowService) {
        this.$log.debug("%s - Start", this.controllerName);
        //  this.request = this.RequestService.request;
        this.init();
    }

    public addComment(){
        this.WorkFlowService.addWeighInComment(true, false);
    }

    public removeSoftware(software, id){
        angular.element(id).addClass("fadeOut");
        this.RequestService.removeSoftware(software);
        if(this.RequestService.request.technologyInformation.software.length<1){
            angular.element('#software').addClass("fadeOut");
        }
    }


    public verifySystemsComplete(item) {
        var techCount:number = 0;
        this.RequestService.verifySoftwareForm();
        if (this.RequestService.request.technologyInformation.technologyRequirements) {
            for (var e in this.RequestService.request.technologyInformation.technologyRequirements) {
                var techItem:any = this.RequestService.request.technologyInformation.technologyRequirements[e];
                //Add to match it with the current checkbox that was changed because for some reason the ng-model
                //wasn't binding the checkboxes from the ng-repeat to the data.
                if(item && item.name === techItem.name){
                    techItem.required = item.required;
                    techItem.available = item.available;
                    techItem.na = item.na;
                    techItem.comments = item.comments;
                }
                if (techItem.required || techItem.available || techItem.na) {
                    if((techItem.required && techItem.comments) ||
                        !techItem.required) {
                        techCount = techCount + 1;
                    }
                } else {
                    break;
                }
            }
        }
        //this.$log.debug(this.RequestService.isTechnologiesComplete);

        if(this.RequestService.request.technologyInformation.technologyRequirements.length === techCount &&
            this.RequestService.isSoftwareFormCompleted) {
            this.RequestService.isTechnologiesComplete = true;
        } else {
            this.RequestService.isTechnologiesComplete = false;
        }
    }

    private init() {
        this.verifySystemsComplete(null);
    }
}

