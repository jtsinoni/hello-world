'use strict';

import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;

export default class HistoryController {
    private controllerName:string = "Tab Details Controller";

    public historyTable:any;
    public requestHistorySearch:string;

    // @ngInject
    constructor(private $log, private datatableService, private RequestService,
                private SidePanelService, private StateConstants) {
        this.$log.debug("%s - Start", this.controllerName);

        this.init();
    }

    public requestsFilter() {
        this.historyTable.filter({$: this.requestHistorySearch});
    }


    private init(){
        if(this.RequestService.request.wfProcessing != null) {
            this.historyTable = this.datatableService.createNgTable(this.RequestService.request.wfProcessing.history, 25, {when: 'asc'});
        }
    }

}