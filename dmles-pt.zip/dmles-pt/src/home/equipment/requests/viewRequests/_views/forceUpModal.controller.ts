'use strict';

export default class ForceUpModalInstanceController{
    public forceUp:boolean = false;

    // @ngInject
    constructor(private $log, private $uibModalInstance, private RequestService, private WorkFlowService) {
    }

    //These are the actions of the buttons
    public continue(){
        if(this.forceUp) {
            this.WorkFlowService.submitForceUp();
        }
        else {
            this.WorkFlowService.submitApproval();
        }
        this.$uibModalInstance.dismiss('continue');
    }
    public close(){
        this.$uibModalInstance.dismiss('cancel');
    }

    //This is extra stuff that controls the html displayed
    public showForceUp(){
        if(this.RequestService.request.wfProcessing) {
            var currentLevel = this.RequestService.request.wfProcessing.currentLevelId;
            if (this.WorkFlowService.workflowDef.levelDefinitions[currentLevel].rules.allowForceUp &&
                (!this.WorkFlowService.deviceCriteriaMet && !this.WorkFlowService.deviceUnitCostCriteriaMet && !this.WorkFlowService.catalogCriteriaMet && !this.WorkFlowService.costCriteriaMet)) {
                return true;
            }
            else {
                return false;
            }
        }
        else {
            return false;
        }
    }
}