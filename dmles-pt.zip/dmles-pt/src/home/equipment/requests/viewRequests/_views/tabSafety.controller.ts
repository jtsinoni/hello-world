'use strict';

export default class TabSafetyController {
    private controllerName:string = "Tab Safety Controller";
    public reviewName:string = "equip-request-safety";

    // public request:RequestItem = new RequestItem();
    // @ngInject
    constructor(private $log, private PermissionService, private RequestService,
                private UserService, private ReviewResult, private ReviewStatus, private WorkFlowService) {
        this.$log.debug("%s - Start", this.controllerName);

        this.init();
    }

    public addComment(){
        this.WorkFlowService.addReviewComment(true, false);
    }

    public verifySafetyComplete(item) {
        var envCount:number = 0;
        if (this.RequestService.request.safetyInformation.environmentalConcerns) {
            for (var e in this.RequestService.request.safetyInformation.environmentalConcerns) {
                var envItem:any = this.RequestService.request.safetyInformation.environmentalConcerns[e];
                //Add to match it with the current checkbox that was changed because for some reason the ng-model
                //wasn't binding the checkboxes from the ng-repeat to the data.
                if(item && item.name === envItem.name){
                    envItem.generates = item.generates;
                    envItem.uses = item.uses;
                    envItem.na = item.na;
                    envItem.comments = item.comments;
                }
                if (envItem.generates || envItem.uses || envItem.na) {
                    if(((envItem.generates || envItem.uses) && envItem.comments) ||
                        (!envItem.generates && !envItem.uses)) {
                        envCount = envCount + 1;
                    }
                } else {
                    break;
                }
            }
        }
        var safetyCount:number = 0;
        if (this.RequestService.request.safetyInformation.safetyConcerns) {
            for (var e in this.RequestService.request.safetyInformation.safetyConcerns) {
                var safeItem:any = this.RequestService.request.safetyInformation.safetyConcerns[e];
                //Add to match it with the current checkbox that was changed because for some reason the ng-model
                //wasn't binding the checkboxes from the ng-repeat to the data.
                if(item && item.name === safeItem.name){
                    safeItem.required = item.required;
                    safeItem.na = item.na;
                    safeItem.comments = item.comments;
                }
                if ((safeItem.required && safeItem.comments) ||
                    safeItem.required != null || safeItem.na) {
                    safetyCount = safetyCount + 1;
                } else {
                    break;
                }
            }
        }

        if (this.RequestService.request.safetyInformation.environmentalConcerns.length === envCount &&
            this.RequestService.request.safetyInformation.safetyConcerns.length === safetyCount) {
            this.RequestService.isSafetyCompleted = true;
        } else {
            this.RequestService.isSafetyCompleted = false;
        }

    }

    private init() {
        this.verifySafetyComplete(null);
    }
}
