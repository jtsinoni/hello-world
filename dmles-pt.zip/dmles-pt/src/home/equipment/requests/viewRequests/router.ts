class Router {
    static instance:any;

    // @ngInject
    constructor($stateProvider, $urlRouterProvider, StateConstants) {
        // For any unmatched url, redirect to /home

        $stateProvider
		.state(StateConstants.EQUIP_REQUEST_VIEW, {
			url: '/request',
			templateUrl: '/src/home/equipment/requests/viewRequests/viewRequestShell.html',
			controller: 'ViewRequestShellController',
			controllerAs: 'vm',
			data: {
				displayName: 'Equipment Request'
			}
		}).state(StateConstants.EQUIP_REQUEST_HISTORY, {
			url: '/history',
			templateUrl: '/src/home/equipment/requests/viewRequests/_views/history.html',
			controller: 'HistoryController',
			controllerAs: 'vm',
			data: {
				displayName: 'History'
			}
		}).state(StateConstants.EQUIP_REQUEST_CRITERIA, {
			url: '/criteria',
			templateUrl: '/src/home/equipment/requests/viewRequests/_views/criteria.html',
			controller: 'CriteriaController',
			controllerAs: 'vm',
			data: {
				displayName: 'Criteria'
			}
		})
		;
    }

    static factory($stateProvider, $urlRouterProvider, StateConstants) {
        Router.instance = new Router($stateProvider, $urlRouterProvider, StateConstants);
        return Router.instance;
    }
}

Router.factory.$inject = ['$stateProvider', '$urlRouterProvider', 'StateConstants'];

export default Router;