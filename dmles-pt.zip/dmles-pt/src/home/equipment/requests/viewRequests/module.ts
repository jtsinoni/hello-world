// features
import controllersModule from './_views/module';
import router from './router';

import {ViewRequestShellController} from './viewRequestShell.controller';

var module = angular.module('Dmles.Equipment.Requests.ViewRequests.Module', [
    controllersModule.name,
]);

module.controller('ViewRequestShellController', ViewRequestShellController);
module.config(router.factory);

export default module;