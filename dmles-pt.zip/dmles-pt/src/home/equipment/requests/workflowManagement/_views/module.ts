'use strict';

import {EditNextLevelCriteriaController} from './editNextLevelCriteria.controller';
import {EditOwnerRoleController} from './editOwnerRole.controller';
import {EditRulesController} from './editRules.controller';

var controllersModule = angular.module('Dmles.Equipment.Requests.WorkflowManagement.Views.Module', []);
controllersModule.controller('EditNextLevelCriteriaController', EditNextLevelCriteriaController);
controllersModule.controller('EditOwnerRoleController', EditOwnerRoleController);
controllersModule.controller('EditRulesController', EditRulesController);

export default controllersModule;