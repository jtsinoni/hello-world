'use strict';

import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {WorkFlowDefinition} from "../../_models/workflowDefinition.model";
import {LevelRules} from "../../_models/LevelRules.model";

export class EditNextLevelCriteriaController {
    public totalCostChanged: boolean = false;

    private controllerName: string = "Workflow Management - Edit Next level Criteria Controller";
    private workflowDefinition: WorkFlowDefinition = null;
    private workflowDefinitionEditLevelId: number = 0;
    private nextLevelCriteria: LevelRules = null;

    // @ngInject
    constructor(private $log, private RequestApi, private WorkflowManagementService) {

        this.$log.debug("%s - Start", this.controllerName);
        this.workflowDefinition = WorkflowManagementService.getWorkflowDefinition();

        if (this.workflowDefinition === null) {
            //no Permission, go back
            this.WorkflowManagementService.goToWorkflowManagementView();
        } else {
            this.workflowDefinitionEditLevelId = WorkflowManagementService.getWorkflowDefinitionEditLevelId();
            this.nextLevelCriteria = this.workflowDefinition.levelDefinitions[this.workflowDefinitionEditLevelId].rules;
            this.$log.debug("this.nextLevelCriteria: %s", JSON.stringify(this.nextLevelCriteria));
        }
    }

    /**
     Updates the permission general information and returns to the Permission View state
     */

    /***
     * These Broke because of the new datamodel changes
     */
    //public onSubmit() {
    //    let workflowDefinitionEditNextLevelCriteria: LevelRules = angular.copy(this.nextLevelCriteria);
    //
    //    this.$log.debug("workflowDefinitionEditNextLevelCriteria.totalCost: %s", JSON.stringify(this.nextLevelCriteria.totalCost));
    //
    //    // Save button on GUI only gets enabled when all required data has values - so no need to check here
    //    this.saveWorkflowDefinitionNextLevelCriteria();
    //    this.WorkflowManagementService.goToWorkflowManagementView();
    //}
    //
    //private saveWorkflowDefinitionNextLevelCriteria() {
    //    this.totalCostChanged = false;
    //
    //    this.$log.debug("saveWorkflowDefinitionNextLevelCriteria()");
    //    this.$log.debug("this.workflowDefinition.service: %s", JSON.stringify(this.workflowDefinition.service));
    //    this.$log.debug("this.workflowDefinitionEditLevelId: %s", JSON.stringify(this.workflowDefinitionEditLevelId));
    //    this.$log.debug("this.nextLevelCriteria.totalCost: %s", JSON.stringify(this.nextLevelCriteria.totalCost));
    //
    //    /**
    //    this.RequestApi.updateWorkflowDefCostCriteria(this.workflowDefinition.service, this.workflowDefinitionEditLevelId,
    //        this.nextLevelCriteria.totalCost).then((response: IHttpPromiseCallbackArg<WorkFlowDefinition>) => {
    //
    //        this.workflowDefinition = response.data;
    //        this.WorkflowManagementService.setWorkflowDefinition(this.workflowDefinition);
    //        this.$log.debug("%s - Saved Workflow Definition Returned: %s", this.controllerName, JSON.stringify(this.workflowDefinition));
    //    }, (errResponse: IHttpPromiseCallbackArg<WorkFlowDefinition>) => {
    //        this.$log.error("Error saving workflow definition - next level criteria - totalCost");
    //    });
    //     **/
    //}
}