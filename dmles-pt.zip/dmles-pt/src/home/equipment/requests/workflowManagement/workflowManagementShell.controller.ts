'use strict';
import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {WorkFlowDefinition} from "../_models/workflowDefinition.model";

export class WorkflowManagementShellController {
    private controllerName: string = "Workflow Management Controller";
    public viewOnly: boolean = true;

    public serviceLabel: string = "Service";
    public serviceName: string = "Air Force";
    public serviceNameOptions: string[] = ["Air Force", "Army", "Navy", "Defense Health Agency", "Veterans Affairs"];
    public serviceOptions: any[] = [
        {serviceCode: "AF", serviceName: "Air Force"},
        {serviceCode: "DA", serviceName: "Army"},
        {serviceCode: "DN", serviceName: "Navy"},
        {serviceCode: "DHA", serviceName: "Defense Health Agency"},
        {serviceCode: "VA", serviceName: "Veterans Affairs"}
    ];
    public serviceOptionSelected: any = null;

    public levelLabel: string = "Level";
    public levelName: string = "Site";
    public levelNameOptions: string[] = ["Site", "Regional", "Service", "DHA"];
    public levelOptions: any[] = [
        {levelId: 0, userType: "SITE", levelName: "Site"},
        {levelId: 1, userType: "SERVICEREGION", levelName: "Regional"},
        {levelId: 2, userType: "SERVICE", levelName: "Service"},
        {levelId: 3, userType: "GLOBAL", levelName: "DHA"}
    ];
    public levelOptionSelected: any = null;
    public levelIdSelected: number = 0;

    public workflowDefinition: WorkFlowDefinition = null;

    // @ngInject
    constructor(private $filter, private $log, private ContentConstants, 
                private NotificationService, private RequestApi, private WorkflowManagementService) {

        this.$log.debug("%s - Start", this.controllerName);

        this.init();
    }

    private init() {
        this.serviceChanged();
        this.levelChanged();
    }

    private serviceChanged() {
        this.serviceOptionSelected = this.$filter('filter')(this.serviceOptions, {"serviceName": this.serviceName}, true)[0];
        this.getWorkflowDefinition(this.serviceOptionSelected.serviceCode);
    }

    private levelChanged() {
        this.levelOptionSelected = this.$filter('filter')(this.levelOptions, {"levelName": this.levelName}, true)[0];
        this.$log.debug("this.levelOptionSelected = %s", JSON.stringify(this.levelOptionSelected));
        this.$log.debug("this.levelOptionSelected.levelId = %s", JSON.stringify(this.levelOptionSelected.levelId));
        if (this.workflowDefinition) {
            this.WorkflowManagementService.setWorkflowDefinitionEditLevelId(this.levelOptionSelected.levelId);
        }
    }

    private getWorkflowDefinition(service) {
        this.RequestApi.getWorkflowDefinition(service).then((response: IHttpPromiseCallbackArg<WorkFlowDefinition>) => {
            this.$log.debug("response.data = %s", JSON.stringify(response.data));
            this.workflowDefinition = response.data;
            this.WorkflowManagementService.setWorkflowDefinition(this.workflowDefinition);
        }, (errResponse: IHttpPromiseCallbackArg<WorkFlowDefinition>) => {
            console.log("%s - Error getting workflow");
            this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
        });
    }   
}