class Router {
    static instance:any;

    // @ngInject
    constructor($stateProvider, $urlRouterProvider, StateConstants) {
        // For any unmatched url, redirect to /home

        $stateProvider
		.state(StateConstants.EQUIP_REQUEST_WORKFLOW_MNG, {
			url: '/workflowManagement',
			templateUrl: '/src/home/equipment/requests/workflowManagement/workflowManagementShell.html',
			controller: 'WorkflowManagementShellController',
			controllerAs: 'vm',
			data: {
				displayName: 'Workflow Management'
			}
		}).state(StateConstants.EQUIP_REQUEST_WORKFLOW_EDIT_NEXT_LEVEL_CRITERIA, {
			url: '/workflowManagement/editNextLevelCriteria',
			templateUrl: '/src/home/equipment/requests/workflowManagement/_views/editNextLevelCriteria.html',
			controller: 'EditNextLevelCriteriaController',
			controllerAs: 'vm',
			data: {
				displayName: 'Edit Next Level Criteria'
			}
		}).state(StateConstants.EQUIP_REQUEST_WORKFLOW_EDIT_OWNER_ROLE, {
			url: '/workflowManagement/editOwnerRole',
			templateUrl: '/src/home/equipment/requests/workflowManagement/_views/editOwnerRole.html',
			controller: 'EditOwnerRoleController',
			controllerAs: 'vm',
			data: {
				displayName: 'Edit Owner Role'
			}
		}).state(StateConstants.EQUIP_REQUEST_WORKFLOW_EDIT_RULES, {
			url: '/workflowManagement/editRules',
			templateUrl: '/src/home/equipment/requests/workflowManagement/_views/editRules.html',
			controller: 'EditRulesController',
			controllerAs: 'vm',
			data: {
				displayName: 'Edit Rules'
			}
		})
		;
    }

    static factory($stateProvider, $urlRouterProvider, StateConstants) {
        Router.instance = new Router($stateProvider, $urlRouterProvider, StateConstants);
        return Router.instance;
    }
}

Router.factory.$inject = ['$stateProvider', '$urlRouterProvider', 'StateConstants'];

export default Router;