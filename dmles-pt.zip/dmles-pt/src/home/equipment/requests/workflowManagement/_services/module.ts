'use strict';

import {WorkflowManagementService} from './workflowManagement.service';

let servicesModule = angular.module('Dmles.Admin.WorkflowManagement.Services.Module', []);
servicesModule.service('WorkflowManagementService', WorkflowManagementService);

export default servicesModule;

