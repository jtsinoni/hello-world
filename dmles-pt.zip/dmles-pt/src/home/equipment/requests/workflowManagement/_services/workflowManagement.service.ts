'use strict';
import {WorkFlowDefinition} from "../../_models/workflowDefinition.model";

export interface IWorkflowManagementService {

}

export class WorkflowManagementService implements IWorkflowManagementService {
    private serviceName: String = "Workflow Management Service";
    private workflowDefinition: WorkFlowDefinition = null;
    private workflowDefinitionEditLevelId: number = 0;

    public rules: any[] = [
        {name: "allowWeighInBypassOnApprove"},
        {name: "allowWeighInSelection"},
        {name: "allowForceUp"},
        {name: "allowAutoApproveAfterWeighIn"},
        {name: "allowModify"},
        {name: "allowReject"},
        {name: "allowHold"},
        {name: "allowRework"},
        {name: "allowRequestCancel"},
        {name: "allowCancel"},
        {name: "allowOwnerOverrideNegativeWeighIns"},
        {name: "allowRetract"},
        {name: "allowNoteConcern"}
    ];

    constructor(private $log, private $state, private StateConstants) {
        this.$log.debug("%s - Start", this.serviceName);
    }

    public getWorkflowDefinition(): WorkFlowDefinition {
        return this.workflowDefinition;
    }

    public setWorkflowDefinition(workflowDefinition: WorkFlowDefinition): void {
        this.workflowDefinition = workflowDefinition;
        this.$log.debug("this.workflowDefinition: %s", JSON.stringify(this.workflowDefinition));
    }

    public getWorkflowDefinitionEditLevelId(): number {
        return this.workflowDefinitionEditLevelId;
    }

    public setWorkflowDefinitionEditLevelId(editLevelId: number): void {
        this.workflowDefinitionEditLevelId = editLevelId;
        this.$log.debug("this.workflowDefinitionEditLevelId: %d", this.workflowDefinitionEditLevelId);
    }

    /**
     Go to Workflow Management view state
     */
    private goToWorkflowManagementView(): void {
        this.$log.debug("%s - Go to Workflow Management View", this.serviceName);
        this.$state.go(this.StateConstants.EQUIP_REQUEST_WORKFLOW_MNG);
    }

    /**
     Go to Edit Next Level Criteria state
     */
    private goToEditNextLevelCriteriaView(): void {
        this.$log.debug("%s - Go to Edit Next Level Criteria View", this.serviceName);
        this.$state.go(this.StateConstants.EQUIP_REQUEST_WORKFLOW_EDIT_NEXT_LEVEL_CRITERIA);
    }

    /**
     Go to Edit Owner Role state
     */
    private goToEditOwnerRoleView(): void {
        this.$log.debug("%s - Go to Edit Owner Role View", this.serviceName);
        this.$state.go(this.StateConstants.EQUIP_REQUEST_WORKFLOW_EDIT_OWNER_ROLE);
    }

    /**
     Go to Edit Rules state
     */
    private goToEditRulesView(): void {
        this.$log.debug("%s - Go to Edit Rules View", this.serviceName);
        this.$state.go(this.StateConstants.EQUIP_REQUEST_WORKFLOW_EDIT_RULES);
    }
}