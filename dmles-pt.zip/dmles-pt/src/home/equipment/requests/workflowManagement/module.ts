// features
import router from './router';

import servicesModule from './_services/module';
import controllersModule from './_views/module';

import {WorkflowManagementShellController} from './workflowManagementShell.controller';

var module = angular.module('Dmles.Equipment.Requests.WorkflowManagement.Module', [
    servicesModule.name,
    controllersModule.name
]);

module.controller('WorkflowManagementShellController', WorkflowManagementShellController);
module.config(router.factory);

export default module;