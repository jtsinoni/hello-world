define(["require", "exports", './_models/module', './records/module', './requests/module'], function (require, exports, module_1, module_2, module_3) {
    'use strict';
    var module = angular.module('Dmles.Equipment.Module', [
        module_1.default.name,
        module_2.default.name,
        module_3.default.name
    ]);
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = module;
});
//# sourceMappingURL=module.js.map