class Router {
    static instance: any;

    // @ngInject
    constructor($stateProvider, $urlRouterProvider, StateConstants) {

        $stateProvider
            .state(StateConstants.EQUIP_RECORD_SEARCH, {
                url: '/record',
                templateUrl: '/src/home/equipment/records/_views/equipmentRecordSearch.html',
                controller: 'EquipmentRecordSearchController',
                controllerAs: 'vm',
                data: {
                    displayName: 'Equipment Record Search'
                }
            }).state(StateConstants.EQUIP_RECORD_DETAILS, {
                url: '/details',
                templateUrl: '/src/home/equipment/records/_views/equipmentRecordDetails.html',
                controller: 'EquipmentRecordDetailsController',
                controllerAs: 'vm',
                data: {
                    displayName: 'Equipment Details'
                }
            }).state(StateConstants.EQUIP_RECORD_DATA_MANAGEMENT, {
                url: '/dataManagement',
                templateUrl: '/src/home/equipment/records/_views/dataManagement.html',
                controller: 'DataManagementController',
                controllerAs: 'vm',
                data: {
                    displayName: 'Data Management'
                }
            })
        ;

    }

    static factory($stateProvider, $urlRouterProvider, StateConstants) {
        Router.instance = new Router($stateProvider, $urlRouterProvider, StateConstants);
        return Router.instance;
    }
}

Router.factory.$inject = ['$stateProvider', '$urlRouterProvider', 'StateConstants'];

export default Router;