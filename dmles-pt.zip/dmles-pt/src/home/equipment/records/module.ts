'use strict';

import controllersModule from './_views/module';
import filtersModule from './_filters/module';
import modelsModule from './_models/module';
import servicesModule from './_services/module';

import router from './router';

let module = angular.module('Dmles.Home.Equipment.Records.RecordsModule', [
    controllersModule.name,
    filtersModule.name,
    modelsModule.name,
    servicesModule.name
]);

module.config(router.factory);

export default module;