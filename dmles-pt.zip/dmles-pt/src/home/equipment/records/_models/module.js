define(["require", "exports", './equipmentRecord.model', './equipmentRecordSummary.model'], function (require, exports, equipmentRecord_model_1, equipmentRecordSummary_model_1) {
    'use strict';
    var modelsModule = angular.module('Dmles.Home.Equip.Record.Models.Module', []);
    modelsModule.value('EquipmentRecord', equipmentRecord_model_1.EquipmentRecord);
    modelsModule.value('EquipmentRecordSummary', equipmentRecordSummary_model_1.EquipmentRecordSummary);
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = modelsModule;
});
//# sourceMappingURL=module.js.map