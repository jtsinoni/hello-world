define(["require", "exports"], function (require, exports) {
    'use strict';
    var EquipmentRecordSummary = (function () {
        function EquipmentRecordSummary(obj) {
            this._id = "";
            // used with orgId to uniquely identify an ER at an MTF
            // not displayed on GUI - used for DB lookup only
            this.meId = "";
            // basic equipment record detail info - located above tabs
            this.orgId = "";
            this.milServiceId = "";
            this.meECNId = "";
            this.itemId = "";
            this.itemDesc = "";
            this.deviceClsText = "";
            this.deviceText = "";
            this.manufOrgName = "";
            this.manufMdlComnId = "";
            // public nameplateModel: String = "";
            this.meMFGSerialId = "";
            this.custOrgId = "";
            this.custOrgNM = "";
            this.custodianName = "";
            this.pltPermntLocTx = "";
            this.eqptOwnershipDesc = "";
            this.assmDescrDetail = "";
            this.assmNumDetail = "";
            this.meAcqCostQty = 0;
            this.meAcqDt = new Date();
            this.maOrgNm = "";
            this.schedTeamName = "";
            this.unschedTeamName = "";
            // public contractor: String = "";
            this.eiAccntblCd = "";
            this.eiMaintReqrCd = "";
            this.deleteInd = "";
            this._id = obj && obj.id || "";
            this.meId = obj && obj.meId || "";
            this.orgId = obj && obj.orgId || "";
            this.milServiceId = obj && obj.milServiceId || "";
            this.meECNId = obj && obj.meECNId || "";
            this.itemId = obj && obj.itemId || "";
            this.itemDesc = obj && obj.itemDesc || "";
            this.deviceClsText = obj && obj.deviceClsText || "";
            this.deviceText = obj && obj.deviceText || "";
            this.manufOrgName = obj && obj.manufOrgName || "";
            this.manufMdlComnId = obj && obj.manufMdlComnId || "";
            this.meMFGSerialId = obj && obj.meMFGSerialId || "";
            this.custOrgId = obj && obj.custOrgId || "";
            this.custOrgNM = obj && obj.custOrgNM || "";
            this.custodianName = obj && obj.custodianName || "";
            this.pltPermntLocTx = obj && obj.pltPermntLocTx || "";
            this.eqptOwnershipDesc = obj && obj.eqptOwnershipDesc || "";
            this.assmDescrDetail = obj && obj.assmDescrDetail || "";
            this.assmNumDetail = obj && obj.assmNumDetail || "";
            this.meAcqCostQty = obj && obj.meAcqCostQty || null;
            this.meAcqDt = obj && obj.meAcqDt || null;
            this.maOrgNm = obj && obj.maOrgNm || "";
            this.schedTeamName = obj && obj.schedTeamName || "";
            this.unschedTeamName = obj && obj.unschedTeamName || "";
            this.eiAccntblCd = obj && obj.eiAccntblCd || "";
            this.eiMaintReqrCd = obj && obj.eiMaintReqrCd || "";
            this.deleteInd = obj && obj.deleteInd || "";
        }
        ;
        return EquipmentRecordSummary;
    }());
    exports.EquipmentRecordSummary = EquipmentRecordSummary;
});
//# sourceMappingURL=equipmentRecordSummary.model.js.map