define(["require", "exports"], function (require, exports) {
    'use strict';
    var EquipmentRecord = (function () {
        function EquipmentRecord(obj) {
            this._id = "";
            // used with orgId to uniquely identify an ER at an MTF
            // not displayed on GUI - used for DB lookup only
            this.meId = "";
            this.selected = false;
            this.detailsRetrieved = false;
            this.detailsFound = false;
            // basic equipment record detail info - located above tabs
            this.shortItemDesc = "";
            this.longItemDesc = "";
            this.equipmentStatus = "";
            this.orgId = "";
            this.ecn = "";
            this.nomenclature = "";
            this.itemId = "";
            this.deviceClass = "";
            // Main Tab
            this.manufacturer = "";
            this.division = "";
            this.nameplateModel = "";
            this.commonModel = "";
            this.manufacturerSerialNumber = "";
            this.acquisitionCost = 0;
            this.lifeExpectancy = "";
            this.assetControlNumber = "";
            this.acquisitionCommodityClass = "";
            this.equipmentType = "";
            this.systemEcn = "";
            this.accountingStatus = "";
            this.isAccountableEquipment = false;
            this.isMaintenanceRequired = false;
            this.ownership = "";
            this.condition = "";
            this.organization = "";
            this.customerName = "";
            this.customerId = "";
            this.custodianName = "";
            this.custodianPhone = "";
            this.subcustodianName = "";
            this.subcustodianPhone = "";
            this.assemblageOrganization = "";
            this.assemblageDescription = "";
            this.assemblageNumber = "";
            // Location & Inventory Tab
            this.isOnLoan = false;
            this.building = "";
            this.floor = "";
            this.room = "";
            this.equipmentLocation = "";
            this.temporaryLocation = "";
            this.locationId = "";
            this.rfidTag = "";
            this.rfLocation = "";
            this.subLocation = "";
            this.inventoryPerformedBy = "";
            this.inventoryLocation = "";
            this.inventoryEntryMethod = "";
            this.inventoryReason = "";
            // Approval/Acquisition Tab
            this.approvalReference = "";
            this.acquisitionSpeciality = "";
            this.replacementRequestNumber = "";
            this.transactionReason = "";
            this.sourceOfSupply = "";
            this.contractNumber = "";
            this.documentNumber = "";
            this.receivedFromDocumentNumber = "";
            this.accumulatedDepreciation = 0.00;
            this.cfoAssetClassification = "";
            this.acquisitionFundCode = "";
            this.iuid = "";
            this.uiiType = "";
            this.uiiStatus = "";
            this.isUiiLabelAffixed = false;
            this.userName = "";
            // Maintenance Data Tab
            this.maintenanceActivity = "";
            this.scheduledTeam = "";
            this.unscheduledTeam = "";
            this.otherGovernmentAgency = "";
            this.contractor = "";
            this.siteId = "";
            this.firmwareNumber = "";
            this.riskLevel = "";
            this.schedulingFactor = "";
            this.equipmentReadinessCode = "";
            this.maintenanceAssessment = "";
            this.operationalStatus = "";
            this.procedureNumber = "";
            this.outstandingWorkOrders = 0;
            this.modifications = 0;
            this.maximumExpenditureLimit = 0;
            this.maximumRepairLimitCumulative = 0;
            this.containsPatientData = false;
            this.clinicalAlarmIndicator = false;
            this.lifeSafety = false;
            this.suspendScheduledWorkOrders = false;
            this.tmde = false;
            this.downStatus = false;
            this.suspendReason = "";
            this.maintenancePlan = [];
            // Maintenance Cost Tab
            this.maintenanceCostHistory = [];
            this.totalSystemAcquisitionCost = 0;
            this.totalMaintenanceCost = 0;
            this.totalDownTime = 0;
            this.totalMaintenanceUnscheduledWorkOrders = 0;
            this.totalOrganizationalCosts = {
                "partsCost": 0,
                "unscheduledTime": 0,
                "unscheduledLaborCost": 0,
                "scheduledTime": 0,
                "scheduledLaborCost": 0,
                "totalCost": 0
            };
            this.totalContractCosts = {
                "partsCost": 0,
                "unscheduledTime": 0,
                "unscheduledLaborCost": 0,
                "scheduledTime": 0,
                "scheduledLaborCost": 0,
                "totalCost": 0
            };
            //Components
            this.components = [];
            //Notes
            this.notes = [];
            // Need for now to just to keep ER demo (using Catalog Search data) working
            this.deviceText = "";
            this.manufacturerNm = "";
            this.supplierNm = "";
            this._id = obj && obj.id || "";
            this.deviceText = obj && obj.deviceText || "";
            this.itemId = obj && obj.itemId || "";
            this.longItemDesc = obj && obj.longItemDesc || "";
            this.manufacturerNm = obj && obj.manufacturerNm || "";
            this.orgId = obj && obj.orgId || "";
            this.shortItemDesc = obj && obj.shortItemDesc || "";
            this.supplierNm = obj && obj.supplierNm || "";
        }
        ;
        return EquipmentRecord;
    }());
    exports.EquipmentRecord = EquipmentRecord;
});
//# sourceMappingURL=equipmentRecord.model.js.map