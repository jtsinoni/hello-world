'use strict';

import {EquipmentRecord} from './equipmentRecord.model';
import {EquipmentRecordSummary} from './equipmentRecordSummary.model';

let modelsModule = angular.module('Dmles.Home.Equip.Record.Models.Module', []);
modelsModule.value('EquipmentRecord', EquipmentRecord);
modelsModule.value('EquipmentRecordSummary', EquipmentRecordSummary);

export default modelsModule;