'use strict';

import {EquipmentRecord} from './equipmentRecord.model';

export class EquipmentRecordSummary {

    public _id:String = "";

    // used with orgId to uniquely identify an ER at an MTF
    // not displayed on GUI - used for DB lookup only
    public meId:String = "";

    // basic equipment record detail info - located above tabs
    public orgId:String = "";
    public milServiceId:String = "";
    public meECNId:String = "";
    public itemId:String = "";
    public itemDesc:String = "";
    public deviceClsText:String = "";
    public deviceText:String = "";
    public manufOrgName:String = "";
    public manufMdlComnId:String = "";
    public nameplateModel: String = "";
    public meMFGSerialId:String = "";
    public custOrgId:String = "";
    public custOrgNM:String = "";
    public custodianName:String = "";
    public pltPermntLocTx:String = "";
    public eqptOwnershipDesc:String = "";
    public assmDescrDetail:String = "";
    public assmNumDetail:String = "";
    public meAcqCostQty:Number = 0;
    public meAcqDt:Date = new Date();
    public maOrgNm:String = "";
    public schedTeamName:String = "";
    public unschedTeamName:String = "";
    public contractor: String = "";
    public eiAccntblCd:String = "";
    public eiMaintReqrCd:String = "";
    public deleteInd:String = "";


    constructor();
    constructor(obj:EquipmentRecord);
    constructor(obj?:any) {
        this._id = obj && obj.id || "";
        this.meId = obj && obj.meId || "";
        this.orgId = obj && obj.orgId || "";
        this.milServiceId = obj && obj.milServiceId || "";
        this.meECNId = obj && obj.meECNId || "";
        this.itemId = obj && obj.itemId || "";
        this.itemDesc = obj && obj.itemDesc || "";
        this.deviceClsText = obj && obj.deviceClsText || "";
        this.deviceText = obj && obj.deviceText || "";
        this.manufOrgName = obj && obj.manufOrgName || "";
        this.manufMdlComnId = obj && obj.manufMdlComnId || "";
        this.meMFGSerialId = obj && obj.meMFGSerialId || "";
        this.custOrgId = obj && obj.custOrgId || "";
        this.custOrgNM = obj && obj.custOrgNM || "";
        this.custodianName = obj && obj.custodianName || "";
        this.pltPermntLocTx = obj && obj.pltPermntLocTx || "";
        this.eqptOwnershipDesc = obj && obj.eqptOwnershipDesc || "";
        this.assmDescrDetail = obj && obj.assmDescrDetail || "";
        this.assmNumDetail = obj && obj.assmNumDetail || "";
        this.meAcqCostQty = obj && obj.meAcqCostQty || null;
        this.meAcqDt = obj && obj.meAcqDt || null;
        this.maOrgNm = obj && obj.maOrgNm || "";
        this.schedTeamName = obj && obj.schedTeamName || "";
        this.unschedTeamName = obj && obj.unschedTeamName || "";
        this.eiAccntblCd = obj && obj.eiAccntblCd || "";
        this.eiMaintReqrCd = obj && obj.eiMaintReqrCd || "";
        this.deleteInd = obj && obj.deleteInd || "";
        this.nameplateModel = obj && obj.nameplateModel || "";
        this.contractor = obj && obj.contractor || "";

    };

}