define(["require", "exports", './_views/module', './_filters/module', './_models/module', './_services/module', './router'], function (require, exports, module_1, module_2, module_3, module_4, router_1) {
    'use strict';
    var module = angular.module('Dmles.Home.Equipment.Records.RecordsModule', [
        module_1.default.name,
        module_2.default.name,
        module_3.default.name,
        module_4.default.name
    ]);
    module.config(router_1.default.factory);
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = module;
});
//# sourceMappingURL=module.js.map