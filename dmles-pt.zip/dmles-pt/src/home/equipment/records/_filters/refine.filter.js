define(["require", "exports"], function (require, exports) {
    'use strict';
    function Refine() {
        return function (input, selections, targetSelection, targetColumn, matchType) {
            var out = [];
            if (!input || input.length == 0 || !selections || selections.length == 0) {
                return input;
            }
            // console.log("selections = %s, targetSelection = %s, targetColumn = %s, matchType = %s", JSON.stringify(selections), targetSelection, targetColumn, matchType);
            angular.forEach(input, function (equipmentRecord) {
                angular.forEach(selections, function (selection) {
                    if (matchType === "ExactMatch") {
                        if (equipmentRecord[targetColumn] === selection[targetSelection]) {
                            out.push(equipmentRecord);
                        }
                    }
                    else if (matchType === "GreaterThanOrEqualTo") {
                        //console.log("GTE equipmentRecord[targetColumn] = %s, selection[targetSelection] = %s", JSON.stringify(equipmentRecord[targetColumn]), JSON.stringify(selection[targetSelection]));
                        if (equipmentRecord[targetColumn] >= selection[targetSelection]) {
                            out.push(equipmentRecord);
                        }
                    }
                    else if (matchType === "LessThanOrEqualTo") {
                        //console.log("LTE equipmentRecord[targetColumn] = %s, selection[targetSelection] = %s", JSON.stringify(equipmentRecord[targetColumn]), JSON.stringify(selection[targetSelection]));
                        if (equipmentRecord[targetColumn] <= selection[targetSelection]) {
                            out.push(equipmentRecord);
                        }
                    }
                    else if (matchType === "Contains") {
                        if (equipmentRecord[targetColumn].indexOf(selection[targetSelection]) != -1) {
                            out.push(equipmentRecord);
                        }
                    }
                    else {
                        if (equipmentRecord[targetColumn].indexOf(selection[targetSelection]) != -1) {
                            out.push(equipmentRecord);
                        }
                    }
                });
            });
            return out;
        };
    }
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = Refine;
});
//# sourceMappingURL=refine.filter.js.map