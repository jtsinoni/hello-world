'use strict';

import {EquipmentRecord} from '../_models/equipmentRecord.model';

export default function Refine() {
    return function (input:Array<EquipmentRecord>, selections:Array<any>, targetSelection:string, targetColumn:string, matchType:string):Array<any> {
        let out = [];
        if (!input || input.length == 0 || !selections || selections.length == 0) {
            return input;
        }
        // console.log("selections = %s, targetSelection = %s, targetColumn = %s, matchType = %s", JSON.stringify(selections), targetSelection, targetColumn, matchType);
        angular.forEach(input, (equipmentRecord) => {
            angular.forEach(selections, (selection) => {
                    if (matchType === "ExactMatch") {
                        if (equipmentRecord[targetColumn] === selection[targetSelection]) {
                            out.push(equipmentRecord);
                        }
                    } else if (matchType === "GreaterThanOrEqualTo") {
                        //console.log("GTE equipmentRecord[targetColumn] = %s, selection[targetSelection] = %s", JSON.stringify(equipmentRecord[targetColumn]), JSON.stringify(selection[targetSelection]));
                        if (equipmentRecord[targetColumn] >= selection[targetSelection]) {
                            out.push(equipmentRecord);
                        }
                    } else if (matchType === "LessThanOrEqualTo") {
                        //console.log("LTE equipmentRecord[targetColumn] = %s, selection[targetSelection] = %s", JSON.stringify(equipmentRecord[targetColumn]), JSON.stringify(selection[targetSelection]));
                        if (equipmentRecord[targetColumn] <= selection[targetSelection]) {
                            out.push(equipmentRecord);
                        }
                    } else if (matchType === "Contains") {
                        if (equipmentRecord[targetColumn].indexOf(selection[targetSelection]) != -1) {
                            out.push(equipmentRecord);
                        }
                    } else {  // default to Contains type search
                        if (equipmentRecord[targetColumn].indexOf(selection[targetSelection]) != -1) {
                            out.push(equipmentRecord);
                        }
                    }
                }
            )
        });

        return out;
    }
}