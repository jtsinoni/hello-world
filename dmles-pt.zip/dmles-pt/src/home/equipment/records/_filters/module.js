define(["require", "exports", './cut.filter', './refine.filter'], function (require, exports, cut_filter_1, refine_filter_1) {
    'use strict';
    var filtersModule = angular.module('Dmles.Home.Equip.Record.Filters.Module', []);
    filtersModule.filter('cut', cut_filter_1.default);
    filtersModule.filter('refine', refine_filter_1.default);
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = filtersModule;
});
//# sourceMappingURL=module.js.map