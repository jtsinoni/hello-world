'use strict';

import {BaseSelectFilterService} from '../../../../_common/_services/baseSelectFilter.service';

export class CustomerNameFilterService extends BaseSelectFilterService {
    public label: string = " Customer Name";

    // @ngInject
    constructor(private MultiSelectService) {
        super();
    }

    public buildList(equipmentRecordAggregations: any) {
        if (this.optionsSelected.length === 0) {
            this.initialize();
        }

        if (equipmentRecordAggregations && equipmentRecordAggregations.customerNames && equipmentRecordAggregations.customerNames.buckets) {
            let values = equipmentRecordAggregations.customerNames.buckets;
            for (let i in values) {
                let value = values[i].key.toUpperCase();
                // let value = values[i].key.toUpperCase() + " (" + values[i].doc_count + ")";
                // this.$log.debug("value: %s", JSON.stringify(value));
                if (this.optionsSelected.length === 0) {
                    this.options.push(this.MultiSelectService.buildSelection("", "", value, false));
                }
            }
        }
    }

    public reset() {
        this.initialize();
    }
}