'use strict';
import {BaseSelectFilterService} from "../../../../_services/baseSelectFilter.service";

export class OrgIdFilterService extends BaseSelectFilterService {
    public label: string = " Org ID";

    // @ngInject
    constructor(private $log, private MultiSelectService) {
        super();
    }

    public buildList(equipmentRecordAggregations: any) {
        if (this.optionsSelected.length === 0) {
            this.initialize();
        }

        if (equipmentRecordAggregations && equipmentRecordAggregations.orgIds && equipmentRecordAggregations.orgIds.buckets) {
            let values = equipmentRecordAggregations.orgIds.buckets;
            for (let i in values) {
                let value = values[i].key.toUpperCase();
                // let value = values[i].key.toUpperCase() + " (" + values[i].doc_count + ")";
                // this.$log.debug("value: %s", JSON.stringify(value));
                if (this.optionsSelected.length === 0) {
                    this.options.push(this.MultiSelectService.buildSelection("", "", value, false));
                }
            }
        }
    }

    public reset() {
        this.initialize();
    }

}