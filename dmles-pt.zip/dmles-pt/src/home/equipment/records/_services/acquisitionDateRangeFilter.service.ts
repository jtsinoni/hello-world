'use strict';

export class AcquisitionDateRangeFilterService {
    public label:string = " Acquisition Date Range";
    public datePicker:any = {};

    public doSearch:boolean = false;

    public options:any = {
        locale: {format: 'MM/DD/YYYY'},
        ranges: {
            'Last 90 Days': [this.moment().subtract(89, 'days'), this.moment()],
            'Last Year': [this.moment().subtract(1, 'year'), this.moment()],
            'Last 5 Years': [this.moment().subtract(5, 'years'), this.moment()]
        },
        eventHandlers: {
            'apply.daterangepicker': (ev, picker) => {
                this.triggerSearch();
            },
            'cancel.daterangepicker': (ev, picker) => {
                this.initialize();
                this.triggerSearch();
            }
        }
    };

    // @ngInject
    constructor(private moment) {
        this.datePicker.date = {
            startDate: null,
            endDate: null
        };
    }

    public buildSearchClause():string {
        let returnValue:string = "";
        if (this.datePicker.date.startDate && this.datePicker.date.endDate) {
            returnValue = "(meAcqDt:>=" + this.datePicker.date.startDate + " && meAcqDt:<=" + this.datePicker.date.endDate + ")";
        }
        return returnValue;
    }

    public initialize() {
        this.datePicker.date = {
            startDate: null,
            endDate: null
        };
    }

    public reset() {
        this.initialize();
    }

    public triggerSearch() {
        this.doSearch = true;
    }
}