'use strict';

export interface IItemIdFilterService {

}

export class ItemIdFilterService implements IItemIdFilterService {
    public label:string = " Item ID";
    public value:string = "";
    public values:string[] = [];

    // @ngInject
    constructor(private $log) {
    }

    public buildSearchClause():string {
        let returnValue:string = "";
        let values:string[] = this.value.split(/[\W_]+/); // split on any non alphanumeric character
        let i:number = 0;
        for (i = 0; i < values.length; i++) {
            if (i > 0) {
                returnValue = returnValue + " OR ";
            }
            if (values[i] !== "") {
                returnValue = returnValue + "(itemId:*" + values[i].toUpperCase() + "*)";
            }
        }
        if (values.length > 1) {
            returnValue = "(" + returnValue + ")";
        }
        //console.log("returnValue: %s", JSON.stringify(returnValue));
        return returnValue;
    }

    public initialize() {
        this.value = "";
        this.values = [];
    }

    public process() {
        this.values = [];  //reinitialize
        let value:string;
        let values:string[] = this.value.split(/[\W_]+/); // split on any non alphanumeric character
        for (value in values) {
            if (values[value] !== "") {
                let selection:any = {selValue: values[value].toUpperCase()};
                this.values.push(selection);
            }
        }
        //console.log("this.itemIdValues: %s", JSON.stringify(this.itemIdValues));
    }

    public reset() {
        this.initialize();
    }
}