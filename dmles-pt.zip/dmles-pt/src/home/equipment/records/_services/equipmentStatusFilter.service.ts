'use strict';

export interface IEquipmentStatusFilterService {

}

export class EquipmentStatusFilterService implements IEquipmentStatusFilterService {
    public label:string = " Equipment Status";
    public options = ["Active", "Inactive"];
    public booleanValue:boolean = true;
    public valueSelected:Array<any> = [{selValue: 'Active'}]; // default to selecting Active

    // @ngInject
    constructor(private $log) {
    }

    public buildSearchClause():string {
        if (this.booleanValue === true) {
            return "(deleteInd:N)";
        } else {
            return "(deleteInd:Y)";
        }
    }

    public initialize() {
        this.booleanValue = true;
        this.valueSelected = [{selValue: 'Active'}]; // default to selecting Active
    }

    public process() {
        //this.$log.debug("this.equipmentStatusBooleanValue: %s", this.equipmentStatusBooleanValue);

        if (this.booleanValue === true) {
            this.valueSelected = [{selValue: 'Active'}];
        } else {
            this.valueSelected = [{selValue: 'Inactive'}];
        }
    }

    public reset() {
        this.initialize();
    }
}