define(["require", "exports", './acquisitionCostFilter.service', './acquisitionDateRangeFilter.service', './commonModelFilter.service', './custodianNameFilter.service', './customerNameFilter.service', './customerOrgIdFilter.service', './detailsPagination.service', './ecnFilter.service', './equipmentRecord.service', './equipmentStatusFilter.service', './itemIdFilter.service', './manufacturerFilter.service', './nomenclatureFilter.service', './orgIdFilter.service', './recordsApi.service'], function (require, exports, acquisitionCostFilter_service_1, acquisitionDateRangeFilter_service_1, commonModelFilter_service_1, custodianNameFilter_service_1, customerNameFilter_service_1, customerOrgIdFilter_service_1, detailsPagination_service_1, ecnFilter_service_1, equipmentRecord_service_1, equipmentStatusFilter_service_1, itemIdFilter_service_1, manufacturerFilter_service_1, nomenclatureFilter_service_1, orgIdFilter_service_1, recordsApi_service_1) {
    'use strict';
    var servicesModule = angular.module('Dmles.Home.Equipment.Records.Services.Module', []);
    servicesModule.service('AcquisitionCostFilterService', acquisitionCostFilter_service_1.AcquisitionCostFilterService);
    servicesModule.service('AcquisitionDateRangeFilterService', acquisitionDateRangeFilter_service_1.AcquisitionDateRangeFilterService);
    servicesModule.service('CommonModelFilterService', commonModelFilter_service_1.CommonModelFilterService);
    servicesModule.service('CustodianNameFilterService', custodianNameFilter_service_1.CustodianNameFilterService);
    servicesModule.service('CustomerNameFilterService', customerNameFilter_service_1.CustomerNameFilterService);
    servicesModule.service('CustomerOrgIdFilterService', customerOrgIdFilter_service_1.CustomerOrgIdFilterService);
    servicesModule.service('DetailsPaginationService', detailsPagination_service_1.DetailsPaginationService);
    servicesModule.service('EcnFilterService', ecnFilter_service_1.EcnFilterService);
    servicesModule.service('EquipmentRecordService', equipmentRecord_service_1.EquipmentRecordService);
    servicesModule.service('EquipmentStatusFilterService', equipmentStatusFilter_service_1.EquipmentStatusFilterService);
    servicesModule.service('ItemIdFilterService', itemIdFilter_service_1.ItemIdFilterService);
    servicesModule.service('ManufacturerFilterService', manufacturerFilter_service_1.ManufacturerFilterService);
    servicesModule.service('NomenclatureFilterService', nomenclatureFilter_service_1.NomenclatureFilterService);
    servicesModule.service('OrgIdFilterService', orgIdFilter_service_1.OrgIdFilterService);
    servicesModule.service('RecordsApi', recordsApi_service_1.RecordsApi);
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = servicesModule;
});
//# sourceMappingURL=module.js.map