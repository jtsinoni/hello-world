var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", '../../../../_services/api.service'], function (require, exports, api_service_1) {
    'use strict';
    var RecordsApi = (function (_super) {
        __extends(RecordsApi, _super);
        // @ngInject
        function RecordsApi($http, $log, Authentication, App, $httpParamSerializerJQLike) {
            _super.call(this, $http, $log, Authentication, App, $httpParamSerializerJQLike, "EquipmentManagement");
            this.$log = $log;
        }
        RecordsApi.prototype.getEquipmentRecord = function (dodaac, meId) {
            var queryString = "getEquipmentRecord?dodaac=" + dodaac + "&meId=" + meId;
            return this.get(queryString);
        };
        ;
        return RecordsApi;
    }(api_service_1.ApiService));
    exports.RecordsApi = RecordsApi;
});
//# sourceMappingURL=recordsApi.service.js.map