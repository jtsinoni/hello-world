var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", '../../../../_common/_services/baseSelectFilter.service'], function (require, exports, baseSelectFilter_service_1) {
    'use strict';
    var CustodianNameFilterService = (function (_super) {
        __extends(CustodianNameFilterService, _super);
        // @ngInject
        function CustodianNameFilterService(MultiSelectService) {
            _super.call(this);
            this.MultiSelectService = MultiSelectService;
            this.label = " Custodian Name";
        }
        CustodianNameFilterService.prototype.buildList = function (equipmentRecordAggregations) {
            if (this.optionsSelected.length === 0) {
                this.initialize();
            }
            if (equipmentRecordAggregations && equipmentRecordAggregations.custodianNames && equipmentRecordAggregations.custodianNames.buckets) {
                var values = equipmentRecordAggregations.custodianNames.buckets;
                for (var i in values) {
                    var value = values[i].key.toUpperCase();
                    // let value = values[i].key.toUpperCase() + " (" + values[i].doc_count + ")";
                    // this.$log.debug("value: %s", JSON.stringify(value));
                    if (this.optionsSelected.length === 0) {
                        this.options.push(this.MultiSelectService.buildSelection("", "", value, false));
                    }
                }
            }
        };
        CustodianNameFilterService.prototype.reset = function () {
            this.initialize();
        };
        return CustodianNameFilterService;
    }(baseSelectFilter_service_1.BaseSelectFilterService));
    exports.CustodianNameFilterService = CustodianNameFilterService;
});
//# sourceMappingURL=custodianNameFilter.service.js.map