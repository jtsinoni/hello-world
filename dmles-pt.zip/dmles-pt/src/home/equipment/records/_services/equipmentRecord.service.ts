'use strict';

import {ApiService} from "../../../../_services/api.service";
import {EquipmentRecord} from '../_models/equipmentRecord.model';
import {EquipmentRecordSummary} from '../_models/equipmentRecordSummary.model';

export interface IEquipmentRecordService {

}

export class EquipmentRecordService extends ApiService implements IEquipmentRecordService {
    private serviceName: string = "EquipmentRecord Service";

    public equipmentRecord: EquipmentRecord = new EquipmentRecord();
    public itemFromCatalog: any = null;

    // @ngInject
    constructor(private $q, $http, $log, Authentication, $httpParamSerializerJQLike, private $filter, private RecordsApi,
                private UtilService) {
        super($http, $log, Authentication, $httpParamSerializerJQLike, "EquipmentManagement");
        this.$log.debug("%s - Start", this.serviceName);

    }

    public getMagicNumber() {
        return 33;
    }

    public getMagicNumberAsync() {
        let deferred = this.$q.defer();

        setTimeout(() => {
            deferred.resolve(44);
        }, 1000);


        return deferred.promise;

    }

    public getSearchStats(result) {
        let retVal = {
            "total": 0,
            "time": 0.00
        };

        if (result && result.data && result.data.hits) {
            if (result.data.hits.total) {
                retVal.total = result.data.hits.total;
            }

            if (result.data.took) {
                retVal.time = result.data.took;
            }
        }
        else {
            this.$log.warn("%s - Warning: No data returned", this.serviceName);
        }
        return retVal;
    }

    public getSummaryEquipmentRecords(searchValue: string, userSpecifiedFilters: string) {
        this.$log.debug("userSpecifiedFilters: %s", JSON.stringify(userSpecifiedFilters));

        //Note: check to see if anything got sent through, otherwise a string 'undefined' will be sent to bt.
        let updatedSearchValue: string = (searchValue) ? searchValue : "";
        let updatedUserSpecifiedFilters: string = (userSpecifiedFilters) ? userSpecifiedFilters : "";

        if (updatedSearchValue === "" || updatedSearchValue === "*") {
            updatedSearchValue = updatedUserSpecifiedFilters;
        } else {
            updatedSearchValue = updatedSearchValue + " " + updatedUserSpecifiedFilters;
        }

        if (updatedSearchValue) {
            // encode URI/URL reserved characters
            updatedSearchValue = encodeURIComponent(updatedSearchValue);

            // pass a generic aggregations request to the BT
            let aggregations: string = '{"aggregations": [' +
                '{"name":"orgIds","field":"orgId","size":"300"},' +
                '{"name":"nomenclatures","field":"deviceText.raw","size":"5000"}' +
                '{"name":"manufacturers","field":"manufOrgName.raw","size":"5500"}' +
                '{"name":"commonModels","field":"manufMdlComnId.raw","size":"5000"}' +
                '{"name":"customerNames","field":"custOrgNM.raw","size":"5000"}' +
                '{"name":"custOrgIds","field":"custOrgId","size":"5000"}' +
                '{"name":"custodianNames","field":"custodianName.raw","size":"5000"}' +
                ']}';
            aggregations = encodeURIComponent(aggregations);

            let action: string = "getEquipmentRecordSearchResults?searchValue=" + updatedSearchValue + "&aggregations=" + aggregations;
            return this.get(action);
        } else {
            return null;
        }
    };

    public parseSummaryEquipmentRecordResults(results) {
        let equipmentRecordList: Array<EquipmentRecord> = [];
        if (results && results.data.hits.hits) {
            let equipmentRecordSearchResults = results.data.hits.hits;
            for (let i = 0; i < equipmentRecordSearchResults.length; i++) {
                this.processEquipmentRecordSearchResult(equipmentRecordSearchResults, i, equipmentRecordList);
            }
        } else {
            console.log('no data returned');
            this.$log.warn("%s - Warning: No data returned", this.serviceName);
        }
        return equipmentRecordList;
    }

    private processEquipmentRecordSearchResult(equipmentRecordSearchResults: any, i: number, equipmentRecordList: Array<EquipmentRecord>) {
        if (equipmentRecordSearchResults[i].hasOwnProperty("fields")) {

            let equipmentRecordSummary: EquipmentRecordSummary = new EquipmentRecordSummary();
            for (let key in equipmentRecordSearchResults[i].fields) {
                let value: Array<any> = equipmentRecordSearchResults[i].fields[key];
                equipmentRecordSummary[key] = value[0];
            }

            // console.log("summary equipmentRecord: %s", JSON.stringify(equipmentRecordSummary));

            // map from equipmentRecordSummary model which uses DMLSS legacy db names
            // to DML-ES friendly names
            let equipmentRecord: EquipmentRecord = new EquipmentRecord();
            equipmentRecord.meId = equipmentRecordSummary.meId;
            equipmentRecord.orgId = equipmentRecordSummary.orgId;
            equipmentRecord.ecn = equipmentRecordSummary.meECNId;
            equipmentRecord.itemId = equipmentRecordSummary.itemId;
            equipmentRecord.shortItemDesc = equipmentRecordSummary.itemDesc;
            equipmentRecord.equipmentStatus = (equipmentRecordSummary.deleteInd === 'N') ? 'Active' : 'Inactive"';
            equipmentRecord.deviceClass = equipmentRecordSummary.deviceClsText;
            equipmentRecord.nomenclature = equipmentRecordSummary.deviceText;
            equipmentRecord.manufacturer = equipmentRecordSummary.manufOrgName;
            equipmentRecord.commonModel = equipmentRecordSummary.manufMdlComnId;
            equipmentRecord.nameplateModel = equipmentRecordSummary.nameplateModel;
            equipmentRecord.manufacturerSerialNumber = equipmentRecordSummary.meMFGSerialId;
            equipmentRecord.customerId = equipmentRecordSummary.custOrgId;
            equipmentRecord.customerName = equipmentRecordSummary.custOrgNM;
            equipmentRecord.custodianName = equipmentRecordSummary.custodianName;
            equipmentRecord.equipmentLocation = equipmentRecordSummary.pltPermntLocTx;
            equipmentRecord.ownership = equipmentRecordSummary.eqptOwnershipDesc;
            equipmentRecord.assemblageDescription = equipmentRecordSummary.assmDescrDetail;
            equipmentRecord.assemblageNumber = equipmentRecordSummary.assmNumDetail;
            equipmentRecord.acquisitionCost = equipmentRecordSummary.meAcqCostQty;

            let acquisitionDate = equipmentRecordSummary.meAcqDt;
            equipmentRecord.acquisitionDate = (acquisitionDate) ? new Date(acquisitionDate.toString()) : null;

            equipmentRecord.maintenanceActivity = equipmentRecordSummary.maOrgNm;
            equipmentRecord.scheduledTeam = equipmentRecordSummary.schedTeamName;
            equipmentRecord.unscheduledTeam = equipmentRecordSummary.unschedTeamName;
            equipmentRecord.contractor = equipmentRecordSummary.contractor;
            equipmentRecord.isAccountableEquipment = (equipmentRecordSummary.eiAccntblCd === "Y");
            equipmentRecord.isMaintenanceRequired = (equipmentRecordSummary.eiMaintReqrCd === "Y");
            equipmentRecordList.push(equipmentRecord);
        }
        return null;
    }

    public createExportableSummaryEquipmentRecordResults(equipmentRecordList: Array<EquipmentRecord>) {
        let exportEquipmentRecordSummarySearchResults: Array<any> = [];
        angular.forEach(equipmentRecordList, (record) => {
            let row: any = {
                "orgId": record.orgId,
                "ecn": record.ecn,
                "itemId": record.itemId,
                "nomenclature": record.nomenclature,
                "manufacturer": record.manufacturer,
                "commonModel": record.commonModel,
                "nameplateModel": record.nameplateModel,
                "manufacturerSerialNumber": record.manufacturerSerialNumber,
                "customerId": record.customerId,
                "customerName": record.customerName,
                "custodianName": record.custodianName,
                "equipmentLocation": record.equipmentLocation,
                "ownership": record.ownership,
                "assemblageDescription": record.assemblageDescription,
                "assemblageNumber": record.assemblageNumber,
                "acquisitionCost": record.acquisitionCost,
                "acquisitionDate": record.acquisitionDate,
                "maintenanceActivity": record.maintenanceActivity,
                "scheduledTeam": record.scheduledTeam,
                "unscheduledTeam": record.unscheduledTeam,
                "contractor": record.contractor
            };
            exportEquipmentRecordSummarySearchResults.push(row);
        });

        return exportEquipmentRecordSummarySearchResults;
    }

    public parseSummaryEquipmentRecordAggregations(results) {
        let equipmentRecordAggregations: any = {};

        if (results && results.data.aggregations) {
            equipmentRecordAggregations = results.data.aggregations;
        } else {
            this.$log.warn("%s - Warning: No aggregations returned", this.serviceName);
        }

        return equipmentRecordAggregations;
    }

    public parseDetailEquipmentRecordResults(result, inputEquipmentRecord) {

        // used for for loops below
        let i: number = 0;

        // map from Mongo DB data to DML-ES friendly names
        let resultData = result.data;
        if (resultData) {

            // check to see if Details were retrieved and set flag accordingly
            // bail if not found
            if (resultData.id) {
                inputEquipmentRecord.detailsFound = true;
            } else {
                inputEquipmentRecord.detailsFound = false;
                console.log("inputEquipmentRecord.detailsFound: %s", JSON.stringify(inputEquipmentRecord.detailsFound));
                return;
            }

            //console.log("inputEquipmentRecord: %s", JSON.stringify(inputEquipmentRecord));
            //console.log("resultData: %s", JSON.stringify(resultData));

            inputEquipmentRecord.meId = resultData.meId;

            inputEquipmentRecord.equipmentStatus = (resultData.deleteInd === 'N') ? 'Active' : 'Inactive"';
            //equipmentRecord.shortItemDesc = resultData.itemDesc;
            inputEquipmentRecord.orgId = resultData.siteDoDDAC;
            inputEquipmentRecord.ecn = resultData.meEcnId;
            inputEquipmentRecord.nomenclature = resultData.deviceText;
            inputEquipmentRecord.itemId = resultData.itemId;
            inputEquipmentRecord.deviceClass = resultData.deviceClsText;

            // Main - Manufacturer Information
            //equipmentRecord.manufacturer = resultData.manufOrgName;
            inputEquipmentRecord.division = resultData.mfrDivSerial;
            inputEquipmentRecord.nameplateModel = resultData.meManufModelId;
            //equipmentRecord.commonModel = resultData.manufMdlComnId;
            //inputEquipmentRecord.manufacturerSerialNumber = resultData.meMfgSerialId;
            //inputEquipmentRecord.acquisitionDate = resultData.meAcqDt;
            //inputEquipmentRecord.acquisitionCost = resultData.meAcqCostQty;
            inputEquipmentRecord.lifeExpectancy = resultData.devclfExpctnQty + " YEARS";
            inputEquipmentRecord.assetControlNumber = resultData.meAcnId;
            inputEquipmentRecord.acquisitionCommodityClass = resultData.acqCommodClsTx;

            // Main - Equipment Information
            let equipmentTypeCode = resultData.systemTypeCd;
            inputEquipmentRecord.equipmentType = this.convertEquipmentTypeCodeToString(equipmentTypeCode);

            inputEquipmentRecord.systemEcn = resultData.meSystemId;

            let accountingStatusCode = resultData.equipAccountingStatusCd;
            inputEquipmentRecord.accountingStatus = this.convertAccountingStatusCodeToString(accountingStatusCode);

            let accountingStatusDate = resultData.meAccountingStatusDt;
            inputEquipmentRecord.accountingStatusDate = (accountingStatusDate) ? new Date(accountingStatusDate) : null;

            let ownershipCode = resultData.eqpmtOwnerTypCd;
            inputEquipmentRecord.ownership = this.convertOwnershipCodeToString(ownershipCode);

            let conditionCode = resultData.supplyCond;
            inputEquipmentRecord.condition = this.convertConditionCodeToString(conditionCode);

            inputEquipmentRecord.isAccountableEquipment = (resultData.eiAccntblCd === "Y");
            inputEquipmentRecord.isMaintenanceRequired = (resultData.eiMaintReqrCd === "Y");

            // Main - Owner/Custodian Information
            inputEquipmentRecord.organization = resultData.mtfOrgNM;
            inputEquipmentRecord.customerName = resultData.custOrgNM;
            inputEquipmentRecord.customerId = resultData.orgID;
            inputEquipmentRecord.custodianName = resultData.custodianName;
            inputEquipmentRecord.custodianPhone = resultData.custodianPhone;
            inputEquipmentRecord.subcustodianName = resultData.subCustodianName;
            inputEquipmentRecord.subcustodianPhone = resultData.subCustodianPH;

            // Main - Assemblage Information
            inputEquipmentRecord.assemblageOrganization = resultData.assemblyOrgNM;
            inputEquipmentRecord.assemblageDescription = resultData.assmDescrDetail;
            inputEquipmentRecord.assemblageNumber = resultData.assmNumDetail;

            // Location & Inventory - Location Information
            inputEquipmentRecord.isOnLoan = (resultData.meOnloanCd === "Y");
            inputEquipmentRecord.building = resultData.locationInventory[0].building;
            inputEquipmentRecord.floor = resultData.locationInventory[0].roomFloorNum;
            inputEquipmentRecord.room = resultData.locationInventory[0].room;
            inputEquipmentRecord.equipmentLocation = resultData.locationInventory[0].pltPermntLocTx;
            inputEquipmentRecord.temporaryLocation = resultData.meTempLocTx;
            inputEquipmentRecord.locationId = resultData.locationInventory[0].locID;

            let onLoanDate = (resultData.locationInventory[0].onlnEquipLoanDt) ? new Date(resultData.locationInventory[0].onlnEquipLoanDt) : null;
            let daysOnLoan = (resultData.locationInventory[0].onlnEquipDayQty) ? parseInt(resultData.locationInventory[0].onlnEquipDayQty) : 0;
            if (onLoanDate) {
                inputEquipmentRecord.loanReturnDate.setDate(onLoanDate.getDate() + daysOnLoan);
            } else {
                inputEquipmentRecord.loanReturnDate = null;
            }

            let equipmentReturnDate = resultData.meReturnDt;
            inputEquipmentRecord.equipmentReturnDate = (equipmentReturnDate) ? new Date(equipmentReturnDate) : null;

            inputEquipmentRecord.rfidTag = resultData.meRfid;
            inputEquipmentRecord.rfLocation = resultData.meRfLocTx;
            inputEquipmentRecord.rfDate = resultData.meRfidAffixedDt;
            inputEquipmentRecord.subLocation = resultData.locationInventory[0].subLocID;

            // Location & Inventory - Inventory Information
            let lastInventoryDate = resultData.meLastInvntryDt;
            inputEquipmentRecord.lastInventoryDate = (lastInventoryDate) ? new Date(lastInventoryDate) : null;

            inputEquipmentRecord.inventoryPerformedBy = resultData.meInvPerfrmNm;
            inputEquipmentRecord.inventoryLocation = resultData.meInvLocationTx;
            inputEquipmentRecord.inventoryEntryMethod = resultData.locationInventory[0].eqpmtInvMthdTx;
            inputEquipmentRecord.inventoryReason = resultData.locationInventory[0].eqptInvReasonTx;

            // Approval/Acquisition - Approval Information
            inputEquipmentRecord.approvalReference = resultData.approval[0].equipBalanceRefTx;
            inputEquipmentRecord.assetControlNumber = resultData.meAcnId;
            inputEquipmentRecord.acquisitionSpeciality = resultData.approval[0].specialty;
            inputEquipmentRecord.replacementRequestNumber = resultData.meEqpmtReqstId;

            // Approval/Acquisition - Purchase Information
            // inputEquipmentRecord.acquisitionDate = resultData.meAcqDt;
            inputEquipmentRecord.transactionReason = resultData.approval[0].transReasTypeTx;
            inputEquipmentRecord.contractNumber = resultData.localContractId;
            inputEquipmentRecord.sourceOfSupply = resultData.approval[0].sos;
            inputEquipmentRecord.documentNumber = resultData.meCreateDocNum;
            inputEquipmentRecord.receivedFromDocumentNumber = resultData.recvdFromDocnum;

            // Approval/Acquisition - Warranty Information
            let installationDate = resultData.meInstallationDt;
            inputEquipmentRecord.installationDate = (installationDate) ? new Date(installationDate) : null;

            let warrantyBeginDate = resultData.meWarntyBegDt;
            inputEquipmentRecord.warrantyBeginDate = (warrantyBeginDate) ? new Date(warrantyBeginDate) : null;

            let warrantyEndDateLabor = resultData.meWarntyLabrEdt;
            inputEquipmentRecord.warrantyEndDateLabor = (warrantyEndDateLabor) ? new Date(warrantyEndDateLabor) : null;

            let warrantyEndDateParts = resultData.meWarntyPartEdt;
            inputEquipmentRecord.warrantyEndDateParts = (warrantyEndDateParts) ? new Date(warrantyEndDateParts) : null;

            // Approval/Acquisition - Assemblage Information
            inputEquipmentRecord.acquisitionCost = resultData.meAcqCostQty;
            inputEquipmentRecord.accumulatedDepreciation = resultData.meAccumDeprtAmt;
            inputEquipmentRecord.cfoAssetClassification = resultData.approval[0].cfoAsstClsTyTx;
            inputEquipmentRecord.acquisitionFundCode = resultData.acqFundCd;

            // Approval/Acquisition - UID Information
            inputEquipmentRecord.iuid = resultData.meIuid;
            inputEquipmentRecord.uiiType = resultData.approval[0].duidTypeDesc;
            inputEquipmentRecord.isUiiLabelAffixed = (resultData.meIuidAffixedInd === "Y");
            inputEquipmentRecord.uiiStatus = resultData.approval[0].duiiStatusDesc;
            inputEquipmentRecord.userName = resultData.meIuidAffixedUserId;

            let uiiStatusDate = resultData.dateDuiiStatus;
            inputEquipmentRecord.uiiStatusDate = (uiiStatusDate) ? new Date(uiiStatusDate) : null;

            let uiiAffixedDate = resultData.meIuidAffixedDt;
            inputEquipmentRecord.uiiAffixedDate = (uiiAffixedDate) ? new Date(uiiAffixedDate) : null;

            // Maintenance Data
            inputEquipmentRecord.maintenanceActivity = resultData.maintenance[0].maintActivityOrgNm;
            inputEquipmentRecord.scheduledTeam = resultData.maintenance[0].schedTeamOrgNm;
            inputEquipmentRecord.unscheduledTeam = resultData.maintenance[0].unschedTeamOrgNm;
            inputEquipmentRecord.otherGovernmentAgency = resultData.maintenance[0].otherGovtMaintSrc;
            inputEquipmentRecord.contractor = resultData.maintenance[0].contractorNm;
            inputEquipmentRecord.siteId = resultData.meVendorSiteId;
            inputEquipmentRecord.firmwareNumber = resultData.meFirmwareVerId;
            inputEquipmentRecord.riskLevel = resultData.maintenance[0].rltDescTx;

            inputEquipmentRecord.schedulingFactor = resultData.maintenance[0].schedFactorTx;
            inputEquipmentRecord.equipmentReadinessCode = resultData.maintenance[0].ertReadinessCdAndText;
            inputEquipmentRecord.procedureNumber = resultData.maintenance[0].mpId;
            inputEquipmentRecord.maintenanceAssessment = resultData.maintenance[0].maintAssmntTyTx;
            inputEquipmentRecord.operationalStatus = resultData.maintenance[0].operationalStatusTx;

            let dateLastServiced = resultData.meLastSvcDt;
            inputEquipmentRecord.dateLastServiced = (dateLastServiced) ? new Date(dateLastServiced) : null;

            inputEquipmentRecord.outstandingWorkOrders = resultData.maintenance[0].workOrderCount;
            inputEquipmentRecord.modifications = resultData.meModificatnCd;
            inputEquipmentRecord.maximumExpenditureLimit = resultData.maintenance[0].mel;
            inputEquipmentRecord.maximumRepairLimitCumulative = resultData.maintenance[0].mrlc;
            inputEquipmentRecord.containsPatientData = (resultData.mePatientDataInd === "Y");
            inputEquipmentRecord.clinicalAlarmIndicator = (resultData.meClinAlarmInd === "Y");
            inputEquipmentRecord.lifeSafety = (resultData.meLifeSafetyInd === "Y");
            inputEquipmentRecord.suspendScheduledWorkOrders = (resultData.meSuspdSchedInd === "Y");
            inputEquipmentRecord.tmde = (resultData.maintenance[0].eiTmdeInd === "Y");
            inputEquipmentRecord.downStatus = (resultData.meDownStatusCd === "Y");
            inputEquipmentRecord.suspendReason = resultData.meSuspdSchedWoReasonTx;

            // create the slots for the steps prior to processing JSON since in JSON they are not guaranteed to be in order (and are often not)
            for (i = 0; i < resultData.maintenanceType.length; i++) {
                inputEquipmentRecord.maintenancePlan[i] = {};
            }
            // process data returned from MongoDB and put into out equipmentRecord model
            for (i = 0; i < resultData.maintenanceType.length; i++) {
                inputEquipmentRecord.maintenancePlan[resultData.maintenanceType[i].miTypeCode - 1].maintenanceType = resultData.maintenanceType[i].miTypeDescText;

                let interval = resultData.maintenanceType[i].miInuseMonthQty;
                inputEquipmentRecord.maintenancePlan[resultData.maintenanceType[i].miTypeCode - 1].interval
                    = (interval) ? interval + " MONTHS" : "";

                let dateDue = resultData.maintenanceType[i].mdDueDt;
                inputEquipmentRecord.maintenancePlan[resultData.maintenanceType[i].miTypeCode - 1].dateDue
                    = (dateDue) ? new Date(dateDue.slice(0, 10)) : null;

                let dateLastServiced = resultData.maintenanceType[i].mdLastSvcDt;
                inputEquipmentRecord.maintenancePlan[resultData.maintenanceType[i].miTypeCode - 1].dateLastServiced
                    = (dateLastServiced) ? new Date(dateLastServiced.slice(0, 10)) : null;
            }
            // console.log("maintenancePlan: %s", JSON.stringify(inputEquipmentRecord.maintenancePlan));

            for (i = 0; i < resultData.maintCost.length; i++) {
                inputEquipmentRecord.maintenanceCostHistory[i] = {};

                let fiscalYearDate = resultData.maintCost[i].mcFiscalYearTm.slice(0, 4);
                inputEquipmentRecord.maintenanceCostHistory[i].fiscalYearDate = "FY " + fiscalYearDate;

                let downTime = resultData.maintCost[i].mcDownTime;
                inputEquipmentRecord.maintenanceCostHistory[i].downTime = downTime;
                inputEquipmentRecord.totalDownTime += downTime;

                let unscheduledWorkOrders = resultData.maintCost[i].mcUnschdWoQty;
                inputEquipmentRecord.maintenanceCostHistory[i].unscheduledWorkOrders = unscheduledWorkOrders;
                inputEquipmentRecord.totalMaintenanceUnscheduledWorkOrders += unscheduledWorkOrders;

                let organizationalPartsCost = resultData.maintCost[i].mcOPartCostAmt;
                inputEquipmentRecord.maintenanceCostHistory[i].organizationalPartsCost = this.$filter('currency')(organizationalPartsCost);
                inputEquipmentRecord.totalOrganizationalCosts.partsCost += organizationalPartsCost;

                let organizationalUnscheduledTime = resultData.maintCost[i].mcOUTimeQty;
                inputEquipmentRecord.maintenanceCostHistory[i].organizationalUnscheduledTime = this.$filter('number')(organizationalUnscheduledTime, 2);
                inputEquipmentRecord.totalOrganizationalCosts.unscheduledTime += organizationalUnscheduledTime;

                let organizationalUnscheduledLaborCost = resultData.maintCost[i].mcOULabCstAmt;
                inputEquipmentRecord.maintenanceCostHistory[i].organizationalUnscheduledLaborCost = this.$filter('currency')(organizationalUnscheduledLaborCost);
                inputEquipmentRecord.totalOrganizationalCosts.unscheduledLaborCost += organizationalUnscheduledLaborCost;

                let organizationalScheduledTime = resultData.maintCost[i].mcOSTimeQty;
                inputEquipmentRecord.maintenanceCostHistory[i].organizationalScheduledTime = this.$filter('number')(organizationalScheduledTime, 2);
                inputEquipmentRecord.totalOrganizationalCosts.scheduledTime += organizationalScheduledTime;

                let organizationalScheduledLaborCost = resultData.maintCost[i].mcOSLabCstAmt;
                inputEquipmentRecord.maintenanceCostHistory[i].organizationalScheduledLaborCost = this.$filter('currency')(organizationalScheduledLaborCost);
                inputEquipmentRecord.totalOrganizationalCosts.scheduledLaborCost += organizationalScheduledLaborCost;

                let totalOrganizationCost = organizationalPartsCost + organizationalUnscheduledLaborCost + organizationalScheduledLaborCost;
                inputEquipmentRecord.maintenanceCostHistory[i].totalOrganizationCost = this.$filter('currency')(totalOrganizationCost);
                inputEquipmentRecord.totalOrganizationalCosts.totalCost += totalOrganizationCost;

                let contractPartsCost = resultData.maintCost[i].mcCPartCostAmt;
                inputEquipmentRecord.maintenanceCostHistory[i].contractPartsCost = this.$filter('currency')(contractPartsCost);
                inputEquipmentRecord.totalContractCosts.partsCost += contractPartsCost;

                let contractUnscheduledTime = resultData.maintCost[i].mcCUTimeQty;
                inputEquipmentRecord.maintenanceCostHistory[i].contractUnscheduledTime = this.$filter('number')(contractUnscheduledTime, 2);
                inputEquipmentRecord.totalContractCosts.unscheduledTime += contractUnscheduledTime;

                let contractUnscheduledLaborCost = resultData.maintCost[i].mcCULabCstAmt;
                inputEquipmentRecord.maintenanceCostHistory[i].contractUnscheduledLaborCost = this.$filter('currency')(contractUnscheduledLaborCost);
                inputEquipmentRecord.totalContractCosts.unscheduledLaborCost += contractUnscheduledLaborCost;

                let contractScheduledTime = resultData.maintCost[i].mcCSTimeQty;
                inputEquipmentRecord.maintenanceCostHistory[i].contractScheduledTime = this.$filter('number')(contractScheduledTime, 2);
                inputEquipmentRecord.totalContractCosts.scheduledTime += contractScheduledTime;

                let contractScheduledLaborCost = resultData.maintCost[i].mcCSLabCstAmt;
                inputEquipmentRecord.maintenanceCostHistory[i].contractScheduledLaborCost = this.$filter('currency')(contractScheduledLaborCost);
                inputEquipmentRecord.totalContractCosts.scheduledLaborCost += contractScheduledLaborCost;

                let totalContractCost = contractPartsCost + contractUnscheduledLaborCost + contractScheduledLaborCost;
                inputEquipmentRecord.maintenanceCostHistory[i].totalContractCost = this.$filter('currency')(totalContractCost);
                inputEquipmentRecord.totalContractCosts.totalCost += totalContractCost;

                let totalMaintenanceCost = totalOrganizationCost + totalContractCost;
                inputEquipmentRecord.maintenanceCostHistory[i].totalMaintenanceCost = this.$filter('currency')(totalMaintenanceCost);
                inputEquipmentRecord.totalMaintenanceCost += totalMaintenanceCost;
            }
            // console.log("maintenanceCostHistory: %s", JSON.stringify(inputEquipmentRecord.maintenanceCostHistory));

            for (i = 0; i < resultData.components.length; i++) {
                inputEquipmentRecord.components[i] = {};
                inputEquipmentRecord.components[i].ecn = resultData.components[i].cMeEcnID;
                inputEquipmentRecord.components[i].itemId = resultData.components[i].cItemID;
                inputEquipmentRecord.components[i].nomenclature = resultData.components[i].cDeviceText;
                inputEquipmentRecord.components[i].manufacturer = resultData.components[i].cOrgName;
                inputEquipmentRecord.components[i].manufacturerSerialNumber = resultData.components[i].cMeMfgSerialID;
                inputEquipmentRecord.components[i].nameplateModel = resultData.components[i].cMeManufModelID;
                inputEquipmentRecord.components[i].commonModel = resultData.components[i].cManufMdlComnID;
                let acquisitionCost = resultData.components[i].cTotalAcqCost;
                inputEquipmentRecord.components[i].acquisitionCost = this.$filter('currency')(acquisitionCost);
                // more fields available - just don't know if we need them
            }
            //console.log("components: %s", JSON.stringify(inputEquipmentRecord.components));

            for (i = 0; i < resultData.notes.length; i++) {
                inputEquipmentRecord.notes[i] = {};

                let noteDate = resultData.notes[i].meNotesDate;
                inputEquipmentRecord.notes[i].date = (noteDate) ? new Date(noteDate.slice(0, 10)) : null;
                inputEquipmentRecord.notes[i].dateDisplayed = (noteDate) ? this.$filter('date')(new Date(noteDate.slice(0, 10)), 'dd MMM yyyy') : null;

                inputEquipmentRecord.notes[i].noteText = resultData.notes[i].meNotesText;
                inputEquipmentRecord.notes[i].enteredBy = resultData.notes[i].meNoteAuthrNm;
            }
            //console.log("notes: %s", JSON.stringify(inputEquipmentRecord.notes));

        }
        // console.log("inputEquipmentRecord: %s", JSON.stringify(inputEquipmentRecord));
    }

    private convertEquipmentTypeCodeToString(equipmentTypeCode: string) {
        let returnString: string = equipmentTypeCode;
        if (equipmentTypeCode === "S") {
            returnString = "SYSTEM";
        } else if (equipmentTypeCode === "C") {
            returnString = "COMPONENT";
        } else if (equipmentTypeCode === "I") {
            returnString = "INDIVIDUAL";
        } else {
            returnString = equipmentTypeCode;
        }
        return returnString;
    }

    private convertAccountingStatusCodeToString(accountingStatusCode: string) {
        let returnString: string = accountingStatusCode;
        if (accountingStatusCode === "R") {
            returnString = "RECEIVED";
        } else if (accountingStatusCode === "A") {
            returnString = "AWAITING ACCEPTANCE";
        } else if (accountingStatusCode === "I") {
            returnString = "AWATING INSTALLATION";
        } else if (accountingStatusCode === "S") {
            returnString = "IN SERVICE";
        } else if (accountingStatusCode === "M") {
            returnString = "REMOVED FROM SERVICE";
        } else if (accountingStatusCode === "D") {
            returnString = "TRANSFERRED TO DRMO";
        } else if (accountingStatusCode === "T") {
            returnString = "TRANSFERRED OUT";
        } else {
            returnString = accountingStatusCode;
        }
        return returnString;
    }

    private convertOwnershipCodeToString(ownershipCode: number) {
        let returnString: string = ownershipCode.toString();
        if (ownershipCode === 1) {
            returnString = "ORGANIZATIONAL";
        } else if (ownershipCode === 2) {
            returnString = "OPERATING LEASED";
        } else if (ownershipCode === 3) {
            returnString = "OTHER GOV. OWNED";
        } else if (ownershipCode === 4) {
            returnString = "NON-GOV. OWNED";
        } else if (ownershipCode === 5) {
            returnString = "CAPITAL LEASED";
        } else {
            returnString = ownershipCode.toString();
        }
        return returnString;
    }

    private convertConditionCodeToString(conditionCode: string) {
        let returnString: string = conditionCode;
        if (conditionCode === "A") {
            returnString = "SERVICEABLE (ISSUABLE WITHOUT QUALIFICATION)";
        } else if (conditionCode === "B") {
            returnString = "SERVICEABLE (ISSUABLE WITH QUALIFICATION)";
        } else if (conditionCode === "C") {
            returnString = "SERVICEABLE (PRIORITY ISSUE)";
        } else if (conditionCode === "D") {
            returnString = "SERVICEABLE (TEST/MODIFICATION)";
        } else if (conditionCode === "E") {
            returnString = "UNSERVICEABLE (LIMITED RESTORATION)";
        } else if (conditionCode === "F") {
            returnString = "UNSERVICEABLE (REPARABLE)";
        } else if (conditionCode === "G") {
            returnString = "UNSERVICEABLE (INCOMPLETE)";
        } else if (conditionCode === "H") {
            returnString = "UNSERVICEABLE (CONDEMNED)";
        } else if (conditionCode === "J") {
            returnString = "SUSPENDED (IN STOCK)";
        } else if (conditionCode === "K") {
            returnString = "SUSPENDED (RETURNS)";
        } else if (conditionCode === "L") {
            returnString = "SUSPENDED (LITIGATION)";
        } else if (conditionCode === "M") {
            returnString = "SUSPENDED (IN WORK)";
        } else if (conditionCode === "N") {
            returnString = "SUSPENDED (AMMUNITION SUITABLE FOR EMERGENCY COMBAT USE ONLY)";
        } else if (conditionCode === "P") {
            returnString = "UNSERVICEABLE (RECLAMATION)";
        } else if (conditionCode === "Q") {
            returnString = "SUSPENDED (QUALITY DEFICIENT EXHIBITS)";
        } else if (conditionCode === "R") {
            returnString = "SUSPENDED (RECLAIMED ITEMS AWAITING CONDITION DETERMINATION)";
        } else if (conditionCode === "S") {
            returnString = "UNSERVICEABLE (SCRAP)";
        } else {
            returnString = conditionCode;
        }
        return returnString;
    }

    // Retrieve One
    private postFindEquipmentRecordDetail(equipmentRecord) {
        return this.RecordsApi.getEquipmentRecord(equipmentRecord.orgId, equipmentRecord.meId);
    }
}