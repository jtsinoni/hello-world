define(["require", "exports"], function (require, exports) {
    'use strict';
    var ItemIdFilterService = (function () {
        // @ngInject
        function ItemIdFilterService($log) {
            this.$log = $log;
            this.label = " Item ID";
            this.value = "";
            this.values = [];
        }
        ItemIdFilterService.prototype.buildSearchClause = function () {
            var returnValue = "";
            var values = this.value.split(/[\W_]+/); // split on any non alphanumeric character
            var i = 0;
            for (i = 0; i < values.length; i++) {
                if (i > 0) {
                    returnValue = returnValue + " OR ";
                }
                if (values[i] !== "") {
                    returnValue = returnValue + "(itemId:*" + values[i].toUpperCase() + "*)";
                }
            }
            if (values.length > 1) {
                returnValue = "(" + returnValue + ")";
            }
            //console.log("returnValue: %s", JSON.stringify(returnValue));
            return returnValue;
        };
        ItemIdFilterService.prototype.initialize = function () {
            this.value = "";
            this.values = [];
        };
        ItemIdFilterService.prototype.process = function () {
            this.values = []; //reinitialize
            var value;
            var values = this.value.split(/[\W_]+/); // split on any non alphanumeric character
            for (value in values) {
                if (values[value] !== "") {
                    var selection = { selValue: values[value].toUpperCase() };
                    this.values.push(selection);
                }
            }
            //console.log("this.itemIdValues: %s", JSON.stringify(this.itemIdValues));
        };
        ItemIdFilterService.prototype.reset = function () {
            this.initialize();
        };
        return ItemIdFilterService;
    }());
    exports.ItemIdFilterService = ItemIdFilterService;
});
//# sourceMappingURL=itemIdFilter.service.js.map