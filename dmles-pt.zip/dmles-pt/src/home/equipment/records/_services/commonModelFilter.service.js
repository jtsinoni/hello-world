var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", '../../../../_common/_services/baseSelectFilter.service'], function (require, exports, baseSelectFilter_service_1) {
    'use strict';
    var CommonModelFilterService = (function (_super) {
        __extends(CommonModelFilterService, _super);
        // @ngInject
        function CommonModelFilterService(MultiSelectService) {
            _super.call(this);
            this.MultiSelectService = MultiSelectService;
            this.label = " Common Model";
        }
        CommonModelFilterService.prototype.buildList = function (equipmentRecordAggregations) {
            if (this.optionsSelected.length === 0) {
                this.initialize();
            }
            if (equipmentRecordAggregations && equipmentRecordAggregations.commonModels && equipmentRecordAggregations.commonModels.buckets) {
                var values = equipmentRecordAggregations.commonModels.buckets;
                for (var i in values) {
                    var value = values[i].key.toUpperCase();
                    // let value = values[i].key.toUpperCase() + " (" + values[i].doc_count + ")";
                    // this.$log.debug("value: %s", JSON.stringify(value));
                    if (this.optionsSelected.length === 0) {
                        this.options.push(this.MultiSelectService.buildSelection("", "", value, false));
                    }
                }
            }
        };
        CommonModelFilterService.prototype.reset = function () {
            this.initialize();
        };
        return CommonModelFilterService;
    }(baseSelectFilter_service_1.BaseSelectFilterService));
    exports.CommonModelFilterService = CommonModelFilterService;
});
//# sourceMappingURL=commonModelFilter.service.js.map