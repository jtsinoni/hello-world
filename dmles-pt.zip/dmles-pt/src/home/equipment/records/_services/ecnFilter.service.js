define(["require", "exports"], function (require, exports) {
    'use strict';
    var EcnFilterService = (function () {
        // @ngInject
        function EcnFilterService($log) {
            this.$log = $log;
            this.label = " ECN";
            this.value = "";
            this.values = [];
        }
        EcnFilterService.prototype.buildSearchClause = function () {
            var returnValue = "";
            var values = this.value.split(/[\W_]+/); // split on any non alphanumeric character
            var i = 0;
            for (i = 0; i < values.length; i++) {
                if (i > 0) {
                    returnValue = returnValue + " OR ";
                }
                if (values[i] !== "") {
                    returnValue = returnValue + "(meECNId:*" + values[i].toUpperCase() + "*)";
                }
            }
            if (values.length > 1) {
                returnValue = "(" + returnValue + ")";
            }
            // this.$log.debug("returnValue: %s", JSON.stringify(returnValue));
            return returnValue;
        };
        EcnFilterService.prototype.initialize = function () {
            this.value = "";
            this.values = [];
        };
        EcnFilterService.prototype.process = function () {
            this.values = []; //reinitialize
            var value;
            var values = this.value.split(/[\W_]+/); // split on any non alphanumeric character
            for (value in values) {
                if (values[value] !== "") {
                    var selection = { selValue: values[value].toUpperCase() };
                    this.values.push(selection);
                }
            }
            //this.$log.debug("this.ecnValues: %s", JSON.stringify(this.ecnValues));
        };
        EcnFilterService.prototype.reset = function () {
            this.initialize();
        };
        return EcnFilterService;
    }());
    exports.EcnFilterService = EcnFilterService;
});
//# sourceMappingURL=ecnFilter.service.js.map