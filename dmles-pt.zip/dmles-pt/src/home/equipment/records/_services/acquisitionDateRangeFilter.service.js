define(["require", "exports"], function (require, exports) {
    'use strict';
    var AcquisitionDateRangeFilterService = (function () {
        // @ngInject
        function AcquisitionDateRangeFilterService(moment) {
            var _this = this;
            this.moment = moment;
            this.label = " Acquisition Date Range";
            this.datePicker = {};
            this.doSearch = false;
            this.options = {
                locale: { format: 'MM/DD/YYYY' },
                ranges: {
                    'Last 90 Days': [this.moment().subtract(89, 'days'), this.moment()],
                    'Last Year': [this.moment().subtract(1, 'year'), this.moment()],
                    'Last 5 Years': [this.moment().subtract(5, 'years'), this.moment()]
                },
                eventHandlers: {
                    'apply.daterangepicker': function (ev, picker) {
                        _this.triggerSearch();
                    },
                    'cancel.daterangepicker': function (ev, picker) {
                        _this.initialize();
                        _this.triggerSearch();
                    }
                }
            };
            this.datePicker.date = {
                startDate: null,
                endDate: null
            };
        }
        AcquisitionDateRangeFilterService.prototype.buildSearchClause = function () {
            var returnValue = "";
            if (this.datePicker.date.startDate && this.datePicker.date.endDate) {
                returnValue = "(meAcqDt:>=" + this.datePicker.date.startDate + " && meAcqDt:<=" + this.datePicker.date.endDate + ")";
            }
            return returnValue;
        };
        AcquisitionDateRangeFilterService.prototype.initialize = function () {
            this.datePicker.date = {
                startDate: null,
                endDate: null
            };
        };
        AcquisitionDateRangeFilterService.prototype.reset = function () {
            this.initialize();
        };
        AcquisitionDateRangeFilterService.prototype.triggerSearch = function () {
            this.doSearch = true;
        };
        return AcquisitionDateRangeFilterService;
    }());
    exports.AcquisitionDateRangeFilterService = AcquisitionDateRangeFilterService;
});
//# sourceMappingURL=acquisitionDateRangeFilter.service.js.map