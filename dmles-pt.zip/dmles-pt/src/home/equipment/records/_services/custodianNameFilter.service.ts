'use strict';

import {BaseSelectFilterService} from '../../../../_common/_services/baseSelectFilter.service';

export class CustodianNameFilterService extends BaseSelectFilterService {
    public label: string = " Custodian Name";

    // @ngInject
    constructor(private MultiSelectService) {
        super();
    }

    public buildList(equipmentRecordAggregations: any) {
        if (this.optionsSelected.length === 0) {
            this.initialize();
        }

        if (equipmentRecordAggregations && equipmentRecordAggregations.custodianNames && equipmentRecordAggregations.custodianNames.buckets) {
            let values = equipmentRecordAggregations.custodianNames.buckets;
            for (let i in values) {
                let value = values[i].key.toUpperCase();
                // let value = values[i].key.toUpperCase() + " (" + values[i].doc_count + ")";
                // this.$log.debug("value: %s", JSON.stringify(value));
                if (this.optionsSelected.length === 0) {
                    this.options.push(this.MultiSelectService.buildSelection("", "", value, false));
                }
            }
        }
    }

    public reset() {
        this.initialize();
    }
}