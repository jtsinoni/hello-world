'use strict';

import {ApiService} from '../../../../_services/api.service';

export interface IRecordsApiService {

}

export class RecordsApi extends ApiService implements IRecordsApiService {

    // @ngInject
    constructor($http, public $log, Authentication, $httpParamSerializerJQLike) {
        super($http, $log, Authentication, $httpParamSerializerJQLike, "EquipmentManagement");
    }


    public getEquipmentRecord(dodaac, meId) {
        let queryString: string = "getEquipmentRecord?dodaac="+dodaac+"&meId=" + meId;
        return this.get(queryString);
    };

}