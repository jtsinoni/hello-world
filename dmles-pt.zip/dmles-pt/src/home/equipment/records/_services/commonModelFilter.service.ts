'use strict';
import {BaseSelectFilterService} from "../../../../_services/baseSelectFilter.service";

export class CommonModelFilterService extends BaseSelectFilterService {
    public label: string = " Common Model";

    // @ngInject
    constructor(private MultiSelectService) {
        super();
    }

    public buildList(equipmentRecordAggregations: any) {
        if (this.optionsSelected.length === 0) {
            this.initialize();
        }

        if (equipmentRecordAggregations && equipmentRecordAggregations.commonModels && equipmentRecordAggregations.commonModels.buckets) {
            let values = equipmentRecordAggregations.commonModels.buckets;
            for (let i in values) {
                let value = values[i].key.toUpperCase();
                // let value = values[i].key.toUpperCase() + " (" + values[i].doc_count + ")";
                // this.$log.debug("value: %s", JSON.stringify(value));
                if (this.optionsSelected.length === 0) {
                    this.options.push(this.MultiSelectService.buildSelection("", "", value, false));
                }
            }
        }
    }

    public reset() {
        this.initialize();
    }
}