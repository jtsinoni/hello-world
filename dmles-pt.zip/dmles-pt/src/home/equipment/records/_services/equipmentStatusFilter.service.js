define(["require", "exports"], function (require, exports) {
    'use strict';
    var EquipmentStatusFilterService = (function () {
        // @ngInject
        function EquipmentStatusFilterService($log) {
            this.$log = $log;
            this.label = " Equipment Status";
            this.options = ["Active", "Inactive"];
            this.booleanValue = true;
            this.valueSelected = [{ selValue: 'Active' }]; // default to selecting Active
        }
        EquipmentStatusFilterService.prototype.buildSearchClause = function () {
            if (this.booleanValue === true) {
                return "(deleteInd:N)";
            }
            else {
                return "(deleteInd:Y)";
            }
        };
        EquipmentStatusFilterService.prototype.initialize = function () {
            this.booleanValue = true;
            this.valueSelected = [{ selValue: 'Active' }]; // default to selecting Active
        };
        EquipmentStatusFilterService.prototype.process = function () {
            //this.$log.debug("this.equipmentStatusBooleanValue: %s", this.equipmentStatusBooleanValue);
            if (this.booleanValue === true) {
                this.valueSelected = [{ selValue: 'Active' }];
            }
            else {
                this.valueSelected = [{ selValue: 'Inactive' }];
            }
        };
        EquipmentStatusFilterService.prototype.reset = function () {
            this.initialize();
        };
        return EquipmentStatusFilterService;
    }());
    exports.EquipmentStatusFilterService = EquipmentStatusFilterService;
});
//# sourceMappingURL=equipmentStatusFilter.service.js.map