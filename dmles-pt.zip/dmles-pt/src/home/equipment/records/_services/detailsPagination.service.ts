'use strict';

import {EquipmentRecord} from '../_models/equipmentRecord.model';

export class DetailsPaginationService {
    private serviceName:string = "Selected Search Results Service";

    public selectedSearchResults:Array<any> = [];

    public currentPage:number = 1;
    public maxSize:number = 3;
    public itemsPerPage:number = 1;

    public detailsNotFoundErrorMsg: string = "The details associated with this record were not found";

    public currentEquipmentRecord:EquipmentRecord = new EquipmentRecord();

    // @ngInject
    constructor(private $log, private NotificationService) {
    }

    public pageChanged() {
        this.currentEquipmentRecord = this.selectedSearchResults[this.currentPage - 1];
        if (this.currentEquipmentRecord.detailsRetrieved === false) {
            this.NotificationService.warningMsg(this.detailsNotFoundErrorMsg);
        }
        // this.$log.debug("pageChanged() - this.currentEquipmentRecord: %s", JSON.stringify(this.currentEquipmentRecord));
    }

    public checkDetailsFound(): boolean {
        return this.currentEquipmentRecord.detailsFound;
    }
}