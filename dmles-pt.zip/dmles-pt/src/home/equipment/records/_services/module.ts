'use strict';

import {AcquisitionCostFilterService} from './acquisitionCostFilter.service';
import {AcquisitionDateRangeFilterService} from './acquisitionDateRangeFilter.service';
import {CommonModelFilterService} from './commonModelFilter.service';
import {CustodianNameFilterService} from './custodianNameFilter.service';
import {CustomerNameFilterService} from './customerNameFilter.service';
import {CustomerOrgIdFilterService} from './customerOrgIdFilter.service';
import {DetailsPaginationService} from './detailsPagination.service';
import {EcnFilterService} from './ecnFilter.service';
import {EquipmentRecordService} from './equipmentRecord.service';
import {EquipmentStatusFilterService} from './equipmentStatusFilter.service';
import {ItemIdFilterService} from './itemIdFilter.service';
import {ManufacturerFilterService} from './manufacturerFilter.service';
import {NomenclatureFilterService} from './nomenclatureFilter.service';
import {OrgIdFilterService} from './orgIdFilter.service';
import {RecordsApi} from './recordsApi.service';

let servicesModule = angular.module('Dmles.Home.Equipment.Records.Services.Module', []);
servicesModule.service('AcquisitionCostFilterService', AcquisitionCostFilterService);
servicesModule.service('AcquisitionDateRangeFilterService', AcquisitionDateRangeFilterService);
servicesModule.service('CommonModelFilterService', CommonModelFilterService);
servicesModule.service('CustodianNameFilterService', CustodianNameFilterService);
servicesModule.service('CustomerNameFilterService', CustomerNameFilterService);
servicesModule.service('CustomerOrgIdFilterService', CustomerOrgIdFilterService);
servicesModule.service('DetailsPaginationService', DetailsPaginationService);
servicesModule.service('EcnFilterService', EcnFilterService);
servicesModule.service('EquipmentRecordService', EquipmentRecordService);
servicesModule.service('EquipmentStatusFilterService', EquipmentStatusFilterService);
servicesModule.service('ItemIdFilterService', ItemIdFilterService);
servicesModule.service('ManufacturerFilterService', ManufacturerFilterService);
servicesModule.service('NomenclatureFilterService', NomenclatureFilterService);
servicesModule.service('OrgIdFilterService', OrgIdFilterService);
servicesModule.service('RecordsApi', RecordsApi);

export default servicesModule;