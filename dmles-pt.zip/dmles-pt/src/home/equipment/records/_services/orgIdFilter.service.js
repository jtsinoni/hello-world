var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", '../../../../_common/_services/baseSelectFilter.service'], function (require, exports, baseSelectFilter_service_1) {
    'use strict';
    var OrgIdFilterService = (function (_super) {
        __extends(OrgIdFilterService, _super);
        // @ngInject
        function OrgIdFilterService($log, MultiSelectService) {
            _super.call(this);
            this.$log = $log;
            this.MultiSelectService = MultiSelectService;
            this.label = " Org ID";
        }
        OrgIdFilterService.prototype.buildList = function (equipmentRecordAggregations) {
            if (this.optionsSelected.length === 0) {
                this.initialize();
            }
            if (equipmentRecordAggregations && equipmentRecordAggregations.orgIds && equipmentRecordAggregations.orgIds.buckets) {
                var values = equipmentRecordAggregations.orgIds.buckets;
                for (var i in values) {
                    var value = values[i].key.toUpperCase();
                    // let value = values[i].key.toUpperCase() + " (" + values[i].doc_count + ")";
                    // this.$log.debug("value: %s", JSON.stringify(value));
                    if (this.optionsSelected.length === 0) {
                        this.options.push(this.MultiSelectService.buildSelection("", "", value, false));
                    }
                }
            }
        };
        OrgIdFilterService.prototype.reset = function () {
            this.initialize();
        };
        return OrgIdFilterService;
    }(baseSelectFilter_service_1.BaseSelectFilterService));
    exports.OrgIdFilterService = OrgIdFilterService;
});
//# sourceMappingURL=orgIdFilter.service.js.map