define(["require", "exports", '../_models/equipmentRecord.model'], function (require, exports, equipmentRecord_model_1) {
    'use strict';
    var DetailsPaginationService = (function () {
        // @ngInject
        function DetailsPaginationService($log, NotificationService) {
            this.$log = $log;
            this.NotificationService = NotificationService;
            this.serviceName = "Selected Search Results Service";
            this.selectedSearchResults = [];
            this.currentPage = 1;
            this.maxSize = 3;
            this.itemsPerPage = 1;
            this.detailsNotFoundErrorMsg = "The details associated with this record were not found";
            this.currentEquipmentRecord = new equipmentRecord_model_1.EquipmentRecord();
        }
        DetailsPaginationService.prototype.pageChanged = function () {
            this.currentEquipmentRecord = this.selectedSearchResults[this.currentPage - 1];
            if (this.currentEquipmentRecord.detailsRetrieved === false) {
                this.NotificationService.warningMsg(this.detailsNotFoundErrorMsg);
            }
            // this.$log.debug("pageChanged() - this.currentEquipmentRecord: %s", JSON.stringify(this.currentEquipmentRecord));
        };
        DetailsPaginationService.prototype.checkDetailsFound = function () {
            return this.currentEquipmentRecord.detailsFound;
        };
        return DetailsPaginationService;
    }());
    exports.DetailsPaginationService = DetailsPaginationService;
});
//# sourceMappingURL=detailsPagination.service.js.map