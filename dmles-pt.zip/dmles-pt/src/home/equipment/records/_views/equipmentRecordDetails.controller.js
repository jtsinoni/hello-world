define(["require", "exports"], function (require, exports) {
    'use strict';
    var EquipmentRecordDetailsController = (function () {
        // @ngInject
        function EquipmentRecordDetailsController(DetailsPaginationService, NotificationService) {
            this.DetailsPaginationService = DetailsPaginationService;
            this.NotificationService = NotificationService;
            this.controllerName = "Equipment Record Details Controller";
            this.detailsNotFoundErrorMsg = "The details associated with this record were not found";
            this.tabPopoverDefaultPlacement = "top";
            this.tabPopoverDefaultTrigger = "mouseenter";
            this.tabPopoverDefaultDelay = 1000;
            //console.log("%s - Start", this.controllerName);
            $(window).scrollTop(0);
            this.DetailsPaginationService.currentPage = 1;
            this.DetailsPaginationService.currentEquipmentRecord = this.DetailsPaginationService.selectedSearchResults[this.DetailsPaginationService.currentPage - 1];
            if (this.DetailsPaginationService.checkDetailsFound() === false) {
                this.NotificationService.warningMsg(this.detailsNotFoundErrorMsg);
            }
        }
        return EquipmentRecordDetailsController;
    }());
    exports.EquipmentRecordDetailsController = EquipmentRecordDetailsController;
});
//# sourceMappingURL=equipmentRecordDetails.controller.js.map