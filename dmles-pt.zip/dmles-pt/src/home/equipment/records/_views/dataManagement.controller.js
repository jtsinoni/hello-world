define(["require", "exports"], function (require, exports) {
    "use strict";
    var DataManagementController = (function () {
        // @ngInject
        function DataManagementController($log, UserProfileService, NotificationService) {
            this.$log = $log;
            this.UserProfileService = UserProfileService;
            this.NotificationService = NotificationService;
            this.controllerName = "DataManagementController";
            this.siteInitialSort = { dodaac: "asc" };
            this.siteCols = [
                { title: 'ID', field: 'id', show: false, sortable: 'id', type: 'text', filter: null, filterData: null },
                { title: 'DODAAC', field: 'dodaac', show: true, sortable: 'dodaac', type: 'text', filter: { 'dodaac': 'text' }, filterData: null },
                { title: 'Name', field: 'name', show: true, sortable: 'name', type: 'text', filter: { 'name': 'text' }, filterData: null },
                { title: 'Description', field: 'description', show: true, sortable: 'description', type: 'text', filter: { 'description': 'text' }, filterData: null },
                //{ title: 'Service', field: 'service.name', show: true, sortable: 'service.name', type: 'text', filter: null,  filterData: null },
                { title: 'Active', field: 'active', show: true, sortable: 'active', type: 'text', filter: { 'active': 'text' }, filterData: null }
            ];
            this.$log.debug('%s - start ', this.controllerName);
            this.init();
        }
        DataManagementController.prototype.init = function () {
            var _this = this;
            this.UserProfileService.getAllSites().then(function (response) {
                _this.siteData = response.data;
                _this.NotificationService.errorMsg("Something bad happened!!");
            }, function (errResponse) {
                _this.$log.error("Error retrieving sites: %s", errResponse);
            });
        };
        DataManagementController.prototype.regRowClick = function (data) {
            this.$log.debug("%s - Site [%s] synced initiated.....", this.controllerName, data.dodaac);
        };
        return DataManagementController;
    }());
    exports.DataManagementController = DataManagementController;
});
//# sourceMappingURL=dataManagement.controller.js.map