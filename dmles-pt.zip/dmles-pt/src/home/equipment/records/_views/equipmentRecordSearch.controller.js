define(["require", "exports", '../../../../_models/user.model'], function (require, exports, user_model_1) {
    'use strict';
    var EquipmentRecordSearchController = (function () {
        // @ngInject
        function EquipmentRecordSearchController($filter, $log, $scope, $state, AcquisitionCostFilterService, AcquisitionDateRangeFilterService, CommonModelFilterService, ContentConstants, CustodianNameFilterService, CustomerNameFilterService, CustomerOrgIdFilterService, datatableService, DetailsPaginationService, EcnFilterService, EquipmentRecordService, EquipmentStatusFilterService, ItemIdFilterService, ManufacturerFilterService, MultiSelectService, NomenclatureFilterService, NotificationService, OrgIdFilterService, SidePanelService, StateConstants, UserService, UtilService) {
            this.$filter = $filter;
            this.$log = $log;
            this.$scope = $scope;
            this.$state = $state;
            this.AcquisitionCostFilterService = AcquisitionCostFilterService;
            this.AcquisitionDateRangeFilterService = AcquisitionDateRangeFilterService;
            this.CommonModelFilterService = CommonModelFilterService;
            this.ContentConstants = ContentConstants;
            this.CustodianNameFilterService = CustodianNameFilterService;
            this.CustomerNameFilterService = CustomerNameFilterService;
            this.CustomerOrgIdFilterService = CustomerOrgIdFilterService;
            this.datatableService = datatableService;
            this.DetailsPaginationService = DetailsPaginationService;
            this.EcnFilterService = EcnFilterService;
            this.EquipmentRecordService = EquipmentRecordService;
            this.EquipmentStatusFilterService = EquipmentStatusFilterService;
            this.ItemIdFilterService = ItemIdFilterService;
            this.ManufacturerFilterService = ManufacturerFilterService;
            this.MultiSelectService = MultiSelectService;
            this.NomenclatureFilterService = NomenclatureFilterService;
            this.NotificationService = NotificationService;
            this.OrgIdFilterService = OrgIdFilterService;
            this.SidePanelService = SidePanelService;
            this.StateConstants = StateConstants;
            this.UserService = UserService;
            this.UtilService = UtilService;
            this.controllerName = "Equipment Record Search Controller";
            this.equipmentRecordSummarySearchResults = [];
            this.equipmentRecordAggregations = {};
            this.searchStats = {};
            this.currentUser = new user_model_1.User();
            this.numberOfRowsToDisplay = 25;
            this.searchInput = "";
            this.userSpecifiedFilters = "";
            // used when clicking on Active/Inactive links from Catalog Item
            this.itemFromCatalog = null;
            this.itemFromCatalogFilters = "";
            this.equipmentRecordSearchStats = "";
            this.isLoadingSearch = false;
            this.ngEquipmentRecordTable = null;
            this.sortOrder = "itemId";
            this.displayOptions = [{ label: 'Table', val: true }, { label: 'Cards', val: false }];
            this.displayAsTable = this.displayOptions[0];
            this.searchPlaceholder = "Equipment Record Search ...";
            this.magicNumber = 0;
            this.asyncMagicNumber = 0;
            this.exportFilename = "equipmentRecordSummarySearchResults.csv";
            this.exportDataHeader = ["Org ID", "ECN", "Item ID", "Nomenclature", "Manufacturer", "Common Model",
                "Nameplate Model", "Manuf Serial Number", "Customer Org ID", "Customer Name", "Custodian Name", "Equipment Location",
                "Ownership", "Assm Desc", "Assm Num", "Acq Cost", "Acq Date", "Maintenance Activity", "Sched Team", "Unsched Team", "Contractor"];
            this.exportEquipmentRecordSummarySearchResults = [];
            //this.$log.debug("%s - Start", this.controllerName);
            $(window).scrollTop(0);
            this.currentUser = this.UserService.currentUser;
            this.searchMaxResultsText = "Over " + this.ContentConstants.SEARCH_MAX + " items has been found, please refine your search";
            this.DetailsPaginationService.selectedSearchResults = [];
            this.init();
            // see if the is a Catalog Item from the ERService ready to process
            // if so, copy it over and then null out the ERService value to reinitialize it
            this.$log.debug("this.EquipmentRecordService.itemFromCatalog: %s", JSON.stringify(this.EquipmentRecordService.itemFromCatalog));
            this.itemFromCatalog = this.EquipmentRecordService.itemFromCatalog;
            this.EquipmentRecordService.itemFromCatalog = null;
            // if a Catalog Item has been passed in, then display those records when you first launch the ER module
            if (this.itemFromCatalog) {
                if (this.itemFromCatalog.isActive === true) {
                    this.itemFromCatalogFilters = "(deleteInd:N) (itemId:" + this.itemFromCatalog.catalogItem.itemId + ") ";
                }
                else {
                    this.itemFromCatalogFilters = "(deleteInd:Y) (itemId:" + this.itemFromCatalog.catalogItem.itemId + ") ";
                }
                this.$log.debug("itemFromCatalogFilters: %s", JSON.stringify(this.itemFromCatalogFilters));
                this.getEquipmentRecords();
            }
            else {
                this.itemFromCatalogFilters = "";
            }
        }
        EquipmentRecordSearchController.prototype.init = function () {
            this.EcnFilterService.initialize();
            this.EquipmentStatusFilterService.initialize();
            this.ItemIdFilterService.initialize();
            this.OrgIdFilterService.initialize();
            this.NomenclatureFilterService.initialize();
            this.ManufacturerFilterService.initialize();
            this.CommonModelFilterService.initialize();
            this.CustomerNameFilterService.initialize();
            this.CustomerOrgIdFilterService.initialize();
            this.CustodianNameFilterService.initialize();
            this.AcquisitionCostFilterService.initialize();
            this.AcquisitionDateRangeFilterService.initialize();
            this.setUpAcquisitionDateRangeFilterWatcher();
        };
        EquipmentRecordSearchController.prototype.setUpAcquisitionDateRangeFilterWatcher = function () {
            var _this = this;
            this.$scope.$watch(function () { return _this.AcquisitionDateRangeFilterService.doSearch; }, function () {
                if (_this.AcquisitionDateRangeFilterService.doSearch === true) {
                    _this.executeSearch();
                    _this.AcquisitionDateRangeFilterService.doSearch = false;
                }
            });
        };
        // used by <search-input> directive
        EquipmentRecordSearchController.prototype.executeSearch = function () {
            var _this = this;
            this.magicNumber = this.EquipmentRecordService.getMagicNumber();
            this.EquipmentRecordService.getMagicNumberAsync().then(function (data) {
                _this.asyncMagicNumber = data;
            });
            this.getEquipmentRecords();
        };
        EquipmentRecordSearchController.prototype.getEquipmentRecords = function () {
            var _this = this;
            this.processUserSpecifiedFilters();
            // console.time("getEquipmentRecords");
            this.isLoadingSearch = true;
            this.equipmentRecordSearchStats = "";
            // escape special characters that might be embedded in the user-input search string(s)
            // not doing this causes issues for elasticsearch
            this.searchInput = this.UtilService.esEscapeSpecialChars(this.searchInput);
            this.EquipmentRecordService.getSummaryEquipmentRecords(this.searchInput, this.userSpecifiedFilters)
                .then(function (response) {
                _this.equipmentRecordSummarySearchResults = _this.EquipmentRecordService.parseSummaryEquipmentRecordResults(response);
                _this.exportEquipmentRecordSummarySearchResults =
                    _this.EquipmentRecordService.createExportableSummaryEquipmentRecordResults(_this.equipmentRecordSummarySearchResults);
                _this.equipmentRecordAggregations = _this.EquipmentRecordService.parseSummaryEquipmentRecordAggregations(response);
                _this.searchStats = _this.EquipmentRecordService.getSearchStats(response);
                _this.processResults();
            }, function (errResponse) {
                _this.$log.debug("%s - Error getting equipment records from elastic", _this.controllerName);
                _this.isLoadingSearch = false;
                _this.NotificationService.errorMsg("An error occurred while retrieving equipment records");
            });
        };
        EquipmentRecordSearchController.prototype.processResults = function () {
            this.showMaxResultsWarning = false;
            this.populateDropDownFiltersPerCurrentResults();
            //this.ngEquipmentRecordTable = this.datatableService.createNgTable(this.equipmentRecordSummarySearchResults, this.numberOfRowsToDisplay, {itemId: 'asc'});
            this.ngEquipmentRecordTable = this.datatableService.createNgTable(this.equipmentRecordSummarySearchResults);
            if (this.ContentConstants.SEARCH_MAX <= this.equipmentRecordSummarySearchResults.length) {
                this.equipmentRecordSearchStats = this.UtilService.esBuildSearchStatsStr(this.searchStats.total, this.searchStats.time);
                this.showMaxResultsWarning = true;
                this.NotificationService.warningMsg(this.searchMaxResultsText);
            }
            else {
                this.equipmentRecordSearchStats = this.UtilService.esBuildSearchStatsStr(this.equipmentRecordSummarySearchResults.length, this.searchStats.time);
            }
            this.isLoadingSearch = false;
        };
        EquipmentRecordSearchController.prototype.populateDropDownFiltersPerCurrentResults = function () {
            this.OrgIdFilterService.buildList(this.equipmentRecordAggregations);
            this.NomenclatureFilterService.buildList(this.equipmentRecordAggregations);
            this.ManufacturerFilterService.buildList(this.equipmentRecordAggregations);
            this.CommonModelFilterService.buildList(this.equipmentRecordAggregations);
            this.CustomerNameFilterService.buildList(this.equipmentRecordAggregations);
            this.CustomerOrgIdFilterService.buildList(this.equipmentRecordAggregations);
            this.CustodianNameFilterService.buildList(this.equipmentRecordAggregations);
        };
        EquipmentRecordSearchController.prototype.processUserSpecifiedFilters = function () {
            /**
             if (!(this.userSpecifiedFilters.indexOf("orgId") != -1)) {
                    this.userSpecifiedFilters += "(orgId: *) ";
                }
    
             if (this.currentUser.defaultDodaac.siteDodaac) {
                    if (!(this.userSpecifiedFilters.indexOf("orgId") != -1)) {
                        this.userSpecifiedFilters += "(orgId:" + this.currentUser.defaultDodaac.siteDodaac + ") ";
                    }
                }
             **/
            this.userSpecifiedFilters = "";
            if (this.searchInput) {
                // if the user has typed in search words then forget about processing items clicked from Catalog
                this.userSpecifiedFilters = this.userSpecifiedFilters + " " + this.EquipmentStatusFilterService.buildSearchClause();
                this.itemFromCatalogFilters = "";
            }
            else {
                // there are no search words typed in - so we either came from Catalog View or clicked on a Search filter
                if (this.itemFromCatalogFilters) {
                    this.userSpecifiedFilters = this.userSpecifiedFilters + " " + this.itemFromCatalogFilters;
                }
                else {
                    this.userSpecifiedFilters = this.userSpecifiedFilters + " " + this.EquipmentStatusFilterService.buildSearchClause();
                }
            }
            this.userSpecifiedFilters = this.userSpecifiedFilters.trim() + " " + this.AcquisitionCostFilterService.buildSearchClause();
            this.userSpecifiedFilters = this.userSpecifiedFilters.trim() + " " + this.AcquisitionDateRangeFilterService.buildSearchClause();
            this.userSpecifiedFilters = this.userSpecifiedFilters.trim() + " " + this.OrgIdFilterService.buildSearchClause("orgId");
            this.userSpecifiedFilters = this.userSpecifiedFilters.trim() + " " + this.NomenclatureFilterService.buildSearchClause("deviceText.raw");
            this.userSpecifiedFilters = this.userSpecifiedFilters.trim() + " " + this.ManufacturerFilterService.buildSearchClause("manufOrgName.raw");
            this.userSpecifiedFilters = this.userSpecifiedFilters.trim() + " " + this.CommonModelFilterService.buildSearchClause("manufMdlComnId.raw");
            this.userSpecifiedFilters = this.userSpecifiedFilters.trim() + " " + this.CustomerNameFilterService.buildSearchClause("custOrgNM.raw");
            this.userSpecifiedFilters = this.userSpecifiedFilters.trim() + " " + this.CustomerOrgIdFilterService.buildSearchClause("custOrgId");
            this.userSpecifiedFilters = this.userSpecifiedFilters.trim() + " " + this.CustodianNameFilterService.buildSearchClause("custodianName.raw");
            this.userSpecifiedFilters = this.userSpecifiedFilters.trim() + " " + this.EcnFilterService.buildSearchClause();
            this.userSpecifiedFilters = this.userSpecifiedFilters.trim() + " " + this.ItemIdFilterService.buildSearchClause();
            this.userSpecifiedFilters = this.userSpecifiedFilters.trim();
        };
        EquipmentRecordSearchController.prototype.resetFilters = function () {
            // this.EquipmentStatusFilterService.reset(); - since this is a search filter - don't include in reset?
            this.EcnFilterService.reset();
            this.ItemIdFilterService.reset();
            this.OrgIdFilterService.reset();
            this.NomenclatureFilterService.reset();
            this.ManufacturerFilterService.reset();
            this.CommonModelFilterService.reset();
            this.CustomerNameFilterService.reset();
            this.CustomerOrgIdFilterService.reset();
            this.CustodianNameFilterService.reset();
            this.AcquisitionCostFilterService.reset();
            this.AcquisitionDateRangeFilterService.reset();
            this.executeSearch();
        };
        EquipmentRecordSearchController.prototype.retrieveDetailsForSelectedRecords = function () {
            var _this = this;
            angular.forEach(this.DetailsPaginationService.selectedSearchResults, function (selectedSearchResult) {
                if (selectedSearchResult.selected) {
                    if (selectedSearchResult.detailsRetrieved === false) {
                        try {
                            _this.EquipmentRecordService.postFindEquipmentRecordDetail(selectedSearchResult).then(function (result) {
                                if (result) {
                                    _this.EquipmentRecordService.parseDetailEquipmentRecordResults(result, selectedSearchResult);
                                    if (selectedSearchResult.detailsFound === true) {
                                        selectedSearchResult.detailsRetrieved = true;
                                    }
                                    _this.$log.debug("detailsRetrieved: %s", JSON.stringify(selectedSearchResult.detailsRetrieved));
                                }
                            });
                        }
                        catch (err) {
                            _this.$log.debug("%s - Error getting equipment detail record: %s", _this.controllerName, err);
                        }
                    }
                }
            });
        };
        EquipmentRecordSearchController.prototype.goToEquipmentRecordDetails = function (equipmentRecord) {
            var _this = this;
            if (equipmentRecord.selected) {
                // record is already in this.DetailsPaginationService.selectedSearchResults
                // no need for further action except to go to change state
                this.$state.go(this.StateConstants.EQUIP_RECORD_DETAILS);
            }
            else {
                // equipmentRecord.isSelected = true;
                this.EquipmentRecordService.equipmentRecord = equipmentRecord;
                this.EquipmentRecordService.postFindEquipmentRecordDetail(equipmentRecord)
                    .then(function (response) {
                    _this.EquipmentRecordService.parseDetailEquipmentRecordResults(response, _this.EquipmentRecordService.equipmentRecord);
                    // this.DetailsPaginationService.selectedSearchResults.push(this.EquipmentRecordService.equipmentRecord);
                    _this.$state.go(_this.StateConstants.EQUIP_RECORD_DETAILS);
                    // this.$log.debug("goToEquipmentRecordDetails 2 - this.selectedSearchResults: %s", JSON.stringify(this.DetailsPaginationService.selectedSearchResults));
                }, function (errResponse) {
                    _this.$log.error("%s - Error getting equipment detail record: %s", _this.controllerName);
                });
            }
        };
        return EquipmentRecordSearchController;
    }());
    exports.EquipmentRecordSearchController = EquipmentRecordSearchController;
});
//# sourceMappingURL=equipmentRecordSearch.controller.js.map