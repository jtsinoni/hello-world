'use strict';

import {DataTableOptions} from '../../../../_common/_directives/dataGrid/dataGrid.class';

export class ComponentsController {
    private controllerName:string = "Equipment Record Details - Components Tab Controller";
    public componentsDataGridOpts:DataTableOptions = null;

    // @ngInject
    constructor(private $log, private $scope, private DetailsPaginationService, private datatableService) {
        // this.$log.debug("%s - Start", this.controllerName);
        this.buildComponentsTable();

        this.$scope.$watch(() => this.DetailsPaginationService.currentPage, () => {
            this.componentsDataGridOpts.loadData(this.DetailsPaginationService.currentEquipmentRecord.components);
        });
    }

    public buildComponentsTable() {
        this.componentsDataGridOpts = new DataTableOptions(this.datatableService);
        this.componentsDataGridOpts.displayName = "Components";
        this.componentsDataGridOpts.noDataMessage = "Equipment Record does not contain components.";
        this.componentsDataGridOpts.showExportBtn = true;
        this.componentsDataGridOpts.numberOfRows = 25;
        this.componentsDataGridOpts.cols = [
            {field: "ecn", title: "Equipment Control Number", show: true, sortable: "ecn"},
            {field: "itemId", title: "Item ID", show: true, sortable: "itemId"},
            {field: "nomenclature", title: "Description", show: true, sortable: "nomenclature"},
            {field: "manufacturer", title: "Manufacturer", show: true, sortable: "manufacturer"},
            {
                field: "manufacturerSerialNumber", title: "Manufacturer Serial Number", show: true,
                sortable: "manufacturerSerialNumber"
            },
            {field: "nameplateModel", title: "Nameplate Model", show: true, sortable: "nameplateModel"},
            {field: "commonModel", title: "Common Model", show: true, sortable: "commonModel"},
            {field: "acquisitionCost", title: "Acquisition Cost", show: true, sortable: "acquisitionCost"}
        ];
        this.componentsDataGridOpts.defaultSort = {ecn: 'desc'};
        this.componentsDataGridOpts.loadData(this.DetailsPaginationService.currentEquipmentRecord.components);
    }
}

