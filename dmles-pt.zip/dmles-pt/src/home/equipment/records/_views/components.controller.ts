export class ComponentsController {
    private controllerName:string = "Equipment Record Details - Components Tab Controller";

    public equipRecComponentsGridData:any = {};
    public equipRecComponentsGridOpts:any = {};

    // @ngInject
    constructor(private $log, private $scope, private DetailsPaginationService, private uiGridConstants) {
        this.$log.debug("%s - Start", this.controllerName);
        this.buildComponentsGrid();
        this.$scope.$watch(() => this.DetailsPaginationService.currentPage, () => {
            this.equipRecComponentsGridData = this.DetailsPaginationService.currentEquipmentRecord.components;
        });
    }

    private buildComponentsGrid(){
        this.equipRecComponentsGridOpts = {
            data: null,
            enableCellEditOnFocus: false,
            enableColumnResizing: true,
            enableFiltering: true,
            enableGridMenu: true,
            enablePaginationControls: false,
            enableRowHeaderSelection: false,
            enableRowSelection: false,
            enableSelectAll: false,
            enableSorting: true,
            exporterCsvFilename: 'components.csv',
            multiSelect: false,
            showColumnFooter: false,
            showGridFooter:true,
            columnDefs: [
                { field: 'ecn', displayName: 'Equipment Control Number', filterCellFiltered:true, sort: { direction: this.uiGridConstants.DESC } },
                { field: 'itemId', displayName: 'Item ID' },
                { field: 'nomenclature', displayName: 'Name' },
                { field: 'manufacturer', displayName: 'Manufacturer' },
                { field: 'manufacturerSerialNumber', displayName: 'Manufacturer Serial Number'  },
                { field: 'nameplateModel', displayName: 'Nameplate Model'  },
                { field: 'commonModel', displayName: 'Common Model'  },
                { field: 'acquisitionCost', displayName: 'Acquisition Cost'  }
            ]
        };
    }

}

