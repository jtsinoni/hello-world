'use strict';

export class MaintenanceCostController {
    private controllerName:string = "Equipment Record Details - Maintenance Cost Tab Controller";
    private $inject = ['$scope', 'DetailsPaginationService'];

    public transposedData:any[] = [];

    // @ngInject
    constructor(private $log, private $scope, private DetailsPaginationService) {

        this.transposedData = [];

        if (this.DetailsPaginationService.currentEquipmentRecord) {
            if (this.DetailsPaginationService.currentEquipmentRecord.maintenanceCostHistory.length > 0) {
                this.initializeTransposedData(this.DetailsPaginationService.currentEquipmentRecord.maintenanceCostHistory);

                // we actually transpose the reversed original data to make it display like legacy DMLSS data
                this.transpose(this.DetailsPaginationService.currentEquipmentRecord.maintenanceCostHistory);
                // this.$log.debug("this.transposedData: %s", JSON.stringify(this.transposedData));
            } else {
                this.transposedData = [];
            }
        }

        this.$scope.$watch(() => this.DetailsPaginationService.currentPage, () => {
            if (this.DetailsPaginationService.currentEquipmentRecord.maintenanceCostHistory.length > 0) {
                this.initializeTransposedData(this.DetailsPaginationService.currentEquipmentRecord.maintenanceCostHistory);
                this.transpose(this.DetailsPaginationService.currentEquipmentRecord.maintenanceCostHistory);
            } else {
                this.transposedData = [];
            }
        });
    }

    private initializeTransposedData(inputData) {
        let j = 0;
        angular.forEach(inputData, (fieldArray, outerIndex) => {
            let i = 0;
            angular.forEach(fieldArray, (field, innerIndex) => {
                // for each column in the original data we will create a row in the transposed data
                this.transposedData[i++] = {};
            });
            j = i;
            // so now we should have an array of N objects where N = the number of columns in the original data
        });
        // add 2 more for Organizational and Contract section rows
        this.transposedData[j++] = {};
        this.transposedData[j++] = {};
    }

    // general comparator function that can be used to sort any array of objects on a specified property (i.e. field)
    private dynamicSort(property) {
        let sortOrder = 1;
        if (property[0] === "-") {
            sortOrder = -1;
            property = property.substr(1);
        }
        return (a, b) => {
            let result = (a[property] < b[property]) ? -1 : (a[property] > b[property]) ? 1 : 0;
            return result * sortOrder;
        }
    }

    private transpose(inputData) {

        // no matter what order the maintenance history array comes in - put it in the prober order
        inputData.sort(this.dynamicSort("fiscalYearDate"));

        let date0:number = 0;
        let date1:number = 0;

        if (inputData[0]) {
            date0 = parseInt(inputData[0].fiscalYearDate.substr(3, 4));
        }
        if (inputData[1]) {
            date1 = parseInt(inputData[1].fiscalYearDate.substr(3, 4));
        }

        if (date0 < date1) {
            inputData = inputData.reverse();
        }

        angular.forEach(inputData, (fieldArray, outerIndex) => {
            let i = 0;
            angular.forEach(fieldArray, (field, innerIndex) => {
                this.transposedData[i++][innerIndex + outerIndex] = field;
                if (innerIndex == "unscheduledWorkOrders") {
                    this.transposedData[i++]["Organizational" + outerIndex] = "-";
                }
                if (innerIndex == "totalOrganizationCost") {
                    this.transposedData[i++]["Contract" + outerIndex] = "-";
                }
            });
        });
    };
}