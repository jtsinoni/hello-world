define(["require", "exports"], function (require, exports) {
    'use strict';
    var MainController = (function () {
        // @ngInject
        function MainController(DetailsPaginationService) {
            this.DetailsPaginationService = DetailsPaginationService;
            this.controllerName = "Equipment Record Details - Main Tab Controller";
        }
        return MainController;
    }());
    exports.MainController = MainController;
});
//# sourceMappingURL=main.controller.js.map