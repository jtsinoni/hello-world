'use strict';

import {ApprovalController} from './approval.controller';
import {ComponentsController} from './components.controller';
import {DataManagementController} from './dataManagement.controller';
import {EquipmentRecordDetailsController} from './equipmentRecordDetails.controller';
import {EquipmentRecordSearchController} from './equipmentRecordSearch.controller';
import {LocationController} from './location.controller';
import {MainController} from './main.controller';
import {MaintenanceCostController} from './maintenanceCost.controller';
import {MaintenanceDataController} from './maintenanceData.controller';
import {NotesController} from './notes.controller';

let controllersModule = angular.module('Dmles.Home.Equipment.Records.Views.Module', []);
controllersModule.controller('ApprovalController', ApprovalController);
controllersModule.controller('ComponentsController', ComponentsController);
controllersModule.controller('DataManagementController', DataManagementController);
controllersModule.controller('EquipmentRecordDetailsController', EquipmentRecordDetailsController);
controllersModule.controller('EquipmentRecordSearchController', EquipmentRecordSearchController);
controllersModule.controller('LocationController', LocationController);
controllersModule.controller('MainController', MainController);
controllersModule.controller('MaintenanceCostController', MaintenanceCostController);
controllersModule.controller('MaintenanceDataController', MaintenanceDataController);
controllersModule.controller('NotesController', NotesController);

export default controllersModule;