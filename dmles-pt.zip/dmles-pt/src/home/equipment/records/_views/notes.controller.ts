'use strict';

import {DataTableOptions} from "../../../../_common/_directives/dataGrid/dataGrid.class";

export class NotesController {
    private controllerName:string = "Equipment Record Details - Notes Tab Controller";
    public notesDataGridOpts:DataTableOptions = null;

    // @ngInject
    constructor(private $scope, private DetailsPaginationService, private EquipmentRecordService, private datatableService, private UserService) {
        this.buildNotesTable();

        this.$scope.$watch(() => this.DetailsPaginationService.currentPage, () => {
            this.notesDataGridOpts.loadData(this.DetailsPaginationService.currentEquipmentRecord.notes);
        });
    }

    private buildNotesTable() {
        this.notesDataGridOpts = new DataTableOptions(this.datatableService);
        this.notesDataGridOpts.displayName = "Notes";
        this.notesDataGridOpts.noDataMessage = "Equipment Record does not contain notes.";
        this.notesDataGridOpts.showExportBtn = true;
        this.notesDataGridOpts.numberOfRows = 25;
        this.notesDataGridOpts.cols = [
            {field: "dateDisplayed", title: "Date", show: true, sortable: "date"},
            {field: "noteText", title: "Note", show: true, sortable: "noteText"},
            {field: "enteredBy", title: "Entered By", show: true, sortable: "enteredBy"}
        ];
        this.notesDataGridOpts.defaultSort = {date: 'desc'};
        this.notesDataGridOpts.loadData(this.DetailsPaginationService.currentEquipmentRecord.notes);
    }
}