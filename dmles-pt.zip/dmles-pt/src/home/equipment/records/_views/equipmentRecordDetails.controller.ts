'use strict';

import {EquipmentRecord} from '../_models/equipmentRecord.model';

export class EquipmentRecordDetailsController {
    private controllerName: string = "Equipment Record Details Controller";

    public detailsNotFoundErrorMsg: string = "The details associated with this record were not found";

    public tabPopoverDefaultPlacement: string = "top";
    public tabPopoverDefaultTrigger: string = "mouseenter";
    public tabPopoverDefaultDelay: number = 1000;

    // @ngInject
    constructor(private DetailsPaginationService, private NotificationService) {
        //console.log("%s - Start", this.controllerName);
        $(window).scrollTop(0);
        this.DetailsPaginationService.currentPage = 1;
        this.DetailsPaginationService.currentEquipmentRecord = this.DetailsPaginationService.selectedSearchResults[this.DetailsPaginationService.currentPage - 1];
        if (this.DetailsPaginationService.checkDetailsFound() === false) {
            this.NotificationService.warningMsg(this.detailsNotFoundErrorMsg);
        }
    }    
}

