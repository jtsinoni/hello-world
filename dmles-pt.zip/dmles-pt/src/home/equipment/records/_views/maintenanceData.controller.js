define(["require", "exports"], function (require, exports) {
    'use strict';
    var MaintenanceDataController = (function () {
        // @ngInject
        function MaintenanceDataController(DetailsPaginationService) {
            this.DetailsPaginationService = DetailsPaginationService;
            this.controllerName = "Equipment Record Details - Maintenance Data Tab Controller";
        }
        return MaintenanceDataController;
    }());
    exports.MaintenanceDataController = MaintenanceDataController;
});
//# sourceMappingURL=maintenanceData.controller.js.map