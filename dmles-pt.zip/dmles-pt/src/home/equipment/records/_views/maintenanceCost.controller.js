define(["require", "exports"], function (require, exports) {
    'use strict';
    var MaintenanceCostController = (function () {
        // @ngInject
        function MaintenanceCostController($log, $scope, DetailsPaginationService) {
            var _this = this;
            this.$log = $log;
            this.$scope = $scope;
            this.DetailsPaginationService = DetailsPaginationService;
            this.controllerName = "Equipment Record Details - Maintenance Cost Tab Controller";
            this.$inject = ['$scope', 'DetailsPaginationService'];
            this.transposedData = [];
            this.transposedData = [];
            if (this.DetailsPaginationService.currentEquipmentRecord) {
                if (this.DetailsPaginationService.currentEquipmentRecord.maintenanceCostHistory.length > 0) {
                    this.initializeTransposedData(this.DetailsPaginationService.currentEquipmentRecord.maintenanceCostHistory);
                    // we actually transpose the reversed original data to make it display like legacy DMLSS data
                    this.transpose(this.DetailsPaginationService.currentEquipmentRecord.maintenanceCostHistory);
                }
                else {
                    this.transposedData = [];
                }
            }
            this.$scope.$watch(function () { return _this.DetailsPaginationService.currentPage; }, function () {
                if (_this.DetailsPaginationService.currentEquipmentRecord.maintenanceCostHistory.length > 0) {
                    _this.initializeTransposedData(_this.DetailsPaginationService.currentEquipmentRecord.maintenanceCostHistory);
                    _this.transpose(_this.DetailsPaginationService.currentEquipmentRecord.maintenanceCostHistory);
                }
                else {
                    _this.transposedData = [];
                }
            });
        }
        MaintenanceCostController.prototype.initializeTransposedData = function (inputData) {
            var _this = this;
            var j = 0;
            angular.forEach(inputData, function (fieldArray, outerIndex) {
                var i = 0;
                angular.forEach(fieldArray, function (field, innerIndex) {
                    // for each column in the original data we will create a row in the transposed data
                    _this.transposedData[i++] = {};
                });
                j = i;
                // so now we should have an array of N objects where N = the number of columns in the original data
            });
            // add 2 more for Organizational and Contract section rows
            this.transposedData[j++] = {};
            this.transposedData[j++] = {};
        };
        // general comparator function that can be used to sort any array of objects on a specified property (i.e. field)
        MaintenanceCostController.prototype.dynamicSort = function (property) {
            var sortOrder = 1;
            if (property[0] === "-") {
                sortOrder = -1;
                property = property.substr(1);
            }
            return function (a, b) {
                var result = (a[property] < b[property]) ? -1 : (a[property] > b[property]) ? 1 : 0;
                return result * sortOrder;
            };
        };
        MaintenanceCostController.prototype.transpose = function (inputData) {
            var _this = this;
            // no matter what order the maintenance history array comes in - put it in the prober order
            inputData.sort(this.dynamicSort("fiscalYearDate"));
            var date0 = 0;
            var date1 = 0;
            if (inputData[0]) {
                date0 = parseInt(inputData[0].fiscalYearDate.substr(3, 4));
            }
            if (inputData[1]) {
                date1 = parseInt(inputData[1].fiscalYearDate.substr(3, 4));
            }
            if (date0 < date1) {
                inputData = inputData.reverse();
            }
            angular.forEach(inputData, function (fieldArray, outerIndex) {
                var i = 0;
                angular.forEach(fieldArray, function (field, innerIndex) {
                    _this.transposedData[i++][innerIndex + outerIndex] = field;
                    if (innerIndex == "unscheduledWorkOrders") {
                        _this.transposedData[i++]["Organizational" + outerIndex] = "-";
                    }
                    if (innerIndex == "totalOrganizationCost") {
                        _this.transposedData[i++]["Contract" + outerIndex] = "-";
                    }
                });
            });
        };
        ;
        return MaintenanceCostController;
    }());
    exports.MaintenanceCostController = MaintenanceCostController;
});
//# sourceMappingURL=maintenanceCost.controller.js.map