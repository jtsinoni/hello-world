define(["require", "exports", '../../../../_common/_directives/dataGrid/dataGrid.class'], function (require, exports, dataGrid_class_1) {
    'use strict';
    var ComponentsController = (function () {
        // @ngInject
        function ComponentsController($log, $scope, DetailsPaginationService, datatableService) {
            var _this = this;
            this.$log = $log;
            this.$scope = $scope;
            this.DetailsPaginationService = DetailsPaginationService;
            this.datatableService = datatableService;
            this.controllerName = "Equipment Record Details - Components Tab Controller";
            this.componentsDataGridOpts = null;
            // this.$log.debug("%s - Start", this.controllerName);
            this.buildComponentsTable();
            this.$scope.$watch(function () { return _this.DetailsPaginationService.currentPage; }, function () {
                _this.componentsDataGridOpts.loadData(_this.DetailsPaginationService.currentEquipmentRecord.components);
            });
        }
        ComponentsController.prototype.buildComponentsTable = function () {
            this.componentsDataGridOpts = new dataGrid_class_1.DataTableOptions(this.datatableService);
            this.componentsDataGridOpts.displayName = "Components";
            this.componentsDataGridOpts.noDataMessage = "Equipment Record does not contain components.";
            this.componentsDataGridOpts.showExportBtn = true;
            this.componentsDataGridOpts.numberOfRows = 25;
            this.componentsDataGridOpts.cols = [
                { field: "ecn", title: "Equipment Control Number", show: true, sortable: "ecn" },
                { field: "itemId", title: "Item ID", show: true, sortable: "itemId" },
                { field: "nomenclature", title: "Description", show: true, sortable: "nomenclature" },
                { field: "manufacturer", title: "Manufacturer", show: true, sortable: "manufacturer" },
                {
                    field: "manufacturerSerialNumber", title: "Manufacturer Serial Number", show: true,
                    sortable: "manufacturerSerialNumber"
                },
                { field: "nameplateModel", title: "Nameplate Model", show: true, sortable: "nameplateModel" },
                { field: "commonModel", title: "Common Model", show: true, sortable: "commonModel" },
                { field: "acquisitionCost", title: "Acquisition Cost", show: true, sortable: "acquisitionCost" }
            ];
            this.componentsDataGridOpts.defaultSort = { ecn: 'desc' };
            this.componentsDataGridOpts.loadData(this.DetailsPaginationService.currentEquipmentRecord.components);
        };
        return ComponentsController;
    }());
    exports.ComponentsController = ComponentsController;
});
//# sourceMappingURL=components.controller.js.map