'use strict';

import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {EquipmentRecord} from '../_models/equipmentRecord.model';
import {User} from '../../../../_models/user.model';

export class EquipmentRecordSearchController {

    private controllerName: string = "Equipment Record Search Controller";
    private equipmentRecordSummarySearchResults: Array<EquipmentRecord> = [];
    private equipmentRecordAggregations: any = {};
    private searchStats: any = {};
    private currentUser: User = new User();
    private numberOfRowsToDisplay: number = 25;
    private searchInput: string = "";
    private userSpecifiedFilters: string = "";

    // used when clicking on Active/Inactive links from Catalog Item
    private itemFromCatalog: any = null;
    private itemFromCatalogFilters: string = "";

    public equipmentRecordSearchStats: string = "";
    public isLoadingSearch: boolean = false;
    public ngEquipmentRecordTable: any = null;
    public sortOrder: string = "itemId";
    public displayOptions: any = [{label: 'Table', val: true}, {label: 'Cards', val: false}];
    public displayAsTable: boolean = this.displayOptions[0];
    public searchPlaceholder: string = "Equipment Record Search ...";
    public searchMaxResultsText: string;
    public showMaxResultsWarning: boolean;
    public magicNumber: number = 0;
    public asyncMagicNumber = 0;

    public exportFilename: string = "equipmentRecordSummarySearchResults.csv";
    public exportDataHeader: string[] = ["Org ID", "ECN", "Item ID", "Nomenclature", "Manufacturer", "Common Model",
        "Nameplate Model", "Manuf Serial Number", "Customer Org ID", "Customer Name", "Custodian Name", "Equipment Location",
        "Ownership", "Assm Desc", "Assm Num", "Acq Cost", "Acq Date", "Maintenance Activity", "Sched Team", "Unsched Team", "Contractor"];
    public exportEquipmentRecordSummarySearchResults: Array<any> = [];

    // @ngInject
    constructor(private $filter, private $log, private $scope, private $state,
                private AcquisitionCostFilterService, private AcquisitionDateRangeFilterService,
                private CommonModelFilterService, private ContentConstants, private CustodianNameFilterService,
                private CustomerNameFilterService, private CustomerOrgIdFilterService,
                private datatableService, private DetailsPaginationService, private EcnFilterService,
                private EquipmentRecordService, private EquipmentStatusFilterService, private ItemIdFilterService,
                private ManufacturerFilterService, private MultiSelectService, private NomenclatureFilterService,
                private NotificationService, private OrgIdFilterService,
                private SidePanelService, private StateConstants, private UserService, private UtilService) {
        //this.$log.debug("%s - Start", this.controllerName);
        $(window).scrollTop(0);

        this.currentUser = this.UserService.currentUser;

        this.searchMaxResultsText = "Over " + this.ContentConstants.SEARCH_MAX + " items have been found, please refine your search";

        this.DetailsPaginationService.selectedSearchResults = [];

        this.init();

        // see if the is a Catalog Item from the ERService ready to process
        // if so, copy it over and then null out the ERService value to reinitialize it
        this.$log.debug("this.EquipmentRecordService.itemFromCatalog: %s", JSON.stringify(this.EquipmentRecordService.itemFromCatalog));
        this.itemFromCatalog = this.EquipmentRecordService.itemFromCatalog;
        this.EquipmentRecordService.itemFromCatalog = null;

        // if a Catalog Item has been passed in, then display those records when you first launch the ER module
        if (this.itemFromCatalog) {
            if (this.itemFromCatalog.isActive === true) {
                this.itemFromCatalogFilters = "(deleteInd:N) (itemId:" + this.itemFromCatalog.catalogItem.itemId + ") ";
            } else {
                this.itemFromCatalogFilters = "(deleteInd:Y) (itemId:" + this.itemFromCatalog.catalogItem.itemId + ") ";
            }
            this.$log.debug("itemFromCatalogFilters: %s", JSON.stringify(this.itemFromCatalogFilters));
            this.getEquipmentRecords();
        } else {
            this.itemFromCatalogFilters = "";
        }
    }

    private init() {
        this.EcnFilterService.initialize();
        this.EquipmentStatusFilterService.initialize();
        this.ItemIdFilterService.initialize();
        this.OrgIdFilterService.initialize();
        this.NomenclatureFilterService.initialize();
        this.ManufacturerFilterService.initialize();
        this.CommonModelFilterService.initialize();
        this.CustomerNameFilterService.initialize();
        this.CustomerOrgIdFilterService.initialize();
        this.CustodianNameFilterService.initialize();
        this.AcquisitionCostFilterService.initialize();
        this.AcquisitionDateRangeFilterService.initialize();

        this.setUpAcquisitionDateRangeFilterWatcher();
    }

    private setUpAcquisitionDateRangeFilterWatcher() {
        this.$scope.$watch(() => this.AcquisitionDateRangeFilterService.doSearch, () => {
            if (this.AcquisitionDateRangeFilterService.doSearch === true) {
                this.executeSearch();
                this.AcquisitionDateRangeFilterService.doSearch = false;
            }
        });
    }

    // used by <search-input> directive
    public executeSearch() {
        if (this.AcquisitionCostFilterService.rangeValue === this.AcquisitionCostFilterService.rangeOptions[4]) {
            this.AcquisitionCostFilterService.processUserSpecifiedValues();
        }
        this.magicNumber = this.EquipmentRecordService.getMagicNumber();

        this.EquipmentRecordService.getMagicNumberAsync().then((data) => {
            this.asyncMagicNumber = data;
        });

        this.getEquipmentRecords();
    }

    private getEquipmentRecords() {

        this.processUserSpecifiedFilters();

        // console.time("getEquipmentRecords");
        this.isLoadingSearch = true;
        this.equipmentRecordSearchStats = "";

        // escape special characters that might be embedded in the user-input search string(s)
        // not doing this causes issues for elasticsearch
        this.searchInput = this.UtilService.esEscapeSpecialChars(this.searchInput);

        this.EquipmentRecordService.getSummaryEquipmentRecords(this.searchInput, this.userSpecifiedFilters)
            .then((response: IHttpPromiseCallbackArg<any>) => {
                this.equipmentRecordSummarySearchResults = this.EquipmentRecordService.parseSummaryEquipmentRecordResults(response);
                this.exportEquipmentRecordSummarySearchResults =
                    this.EquipmentRecordService.createExportableSummaryEquipmentRecordResults(this.equipmentRecordSummarySearchResults);
                this.equipmentRecordAggregations = this.EquipmentRecordService.parseSummaryEquipmentRecordAggregations(response);
                this.searchStats = this.EquipmentRecordService.getSearchStats(response);
                this.processResults();
            }, (errResponse: IHttpPromiseCallbackArg<any>) => {
                this.$log.debug("%s - Error getting equipment records from elastic", this.controllerName);
                this.isLoadingSearch = false;
                this.NotificationService.errorMsg("An error occurred while retrieving equipment records");
            });
    }

    private processResults() {
        this.showMaxResultsWarning = false;
        this.populateDropDownFiltersPerCurrentResults();

        //this.ngEquipmentRecordTable = this.datatableService.createNgTable(this.equipmentRecordSummarySearchResults, this.numberOfRowsToDisplay, {itemId: 'asc'});
        this.ngEquipmentRecordTable = this.datatableService.createNgTable(this.equipmentRecordSummarySearchResults);

        if (this.ContentConstants.SEARCH_MAX <= this.equipmentRecordSummarySearchResults.length) {
            this.equipmentRecordSearchStats = this.UtilService.esBuildSearchStatsStr(this.searchStats.total, this.searchStats.time);
            this.showMaxResultsWarning = true;
            this.NotificationService.warningMsg(this.searchMaxResultsText);
        } else {
            this.equipmentRecordSearchStats = this.UtilService.esBuildSearchStatsStr(this.equipmentRecordSummarySearchResults.length, this.searchStats.time);
        }
        this.isLoadingSearch = false;
    }

    private populateDropDownFiltersPerCurrentResults() {
        this.OrgIdFilterService.buildList(this.equipmentRecordAggregations);
        this.NomenclatureFilterService.buildList(this.equipmentRecordAggregations);
        this.ManufacturerFilterService.buildList(this.equipmentRecordAggregations);
        this.CommonModelFilterService.buildList(this.equipmentRecordAggregations);
        this.CustomerNameFilterService.buildList(this.equipmentRecordAggregations);
        this.CustomerOrgIdFilterService.buildList(this.equipmentRecordAggregations);
        this.CustodianNameFilterService.buildList(this.equipmentRecordAggregations);
    }

    private processUserSpecifiedFilters() {
        /**
         if (!(this.userSpecifiedFilters.indexOf("orgId") != -1)) {
                this.userSpecifiedFilters += "(orgId: *) ";
            }

         if (this.currentUser.defaultDodaac.siteDodaac) {
                if (!(this.userSpecifiedFilters.indexOf("orgId") != -1)) {
                    this.userSpecifiedFilters += "(orgId:" + this.currentUser.defaultDodaac.siteDodaac + ") ";
                }
            }
         **/

        this.userSpecifiedFilters = "";
        if (this.searchInput) {
            // if the user has typed in search words then forget about processing items clicked from Catalog
            this.userSpecifiedFilters = this.userSpecifiedFilters + " " + this.EquipmentStatusFilterService.buildSearchClause();
            this.itemFromCatalogFilters = "";
        } else {
            // there are no search words typed in - so we either came from Catalog View or clicked on a Search filter
            if (this.itemFromCatalogFilters) {
                this.userSpecifiedFilters = this.userSpecifiedFilters + " " + this.itemFromCatalogFilters;
            } else {
                this.userSpecifiedFilters = this.userSpecifiedFilters + " " + this.EquipmentStatusFilterService.buildSearchClause();
            }
        }
        this.userSpecifiedFilters = this.userSpecifiedFilters.trim() + " " + this.AcquisitionCostFilterService.buildSearchClause();
        this.userSpecifiedFilters = this.userSpecifiedFilters.trim() + " " + this.AcquisitionDateRangeFilterService.buildSearchClause();
        this.userSpecifiedFilters = this.userSpecifiedFilters.trim() + " " + this.OrgIdFilterService.buildSearchClause("orgId");
        this.userSpecifiedFilters = this.userSpecifiedFilters.trim() + " " + this.NomenclatureFilterService.buildSearchClause("deviceText.raw");
        this.userSpecifiedFilters = this.userSpecifiedFilters.trim() + " " + this.ManufacturerFilterService.buildSearchClause("manufOrgName.raw");
        this.userSpecifiedFilters = this.userSpecifiedFilters.trim() + " " + this.CommonModelFilterService.buildSearchClause("manufMdlComnId.raw");
        this.userSpecifiedFilters = this.userSpecifiedFilters.trim() + " " + this.CustomerNameFilterService.buildSearchClause("custOrgNM.raw");
        this.userSpecifiedFilters = this.userSpecifiedFilters.trim() + " " + this.CustomerOrgIdFilterService.buildSearchClause("custOrgId");
        this.userSpecifiedFilters = this.userSpecifiedFilters.trim() + " " + this.CustodianNameFilterService.buildSearchClause("custodianName.raw");
        this.userSpecifiedFilters = this.userSpecifiedFilters.trim() + " " + this.EcnFilterService.buildSearchClause();
        this.userSpecifiedFilters = this.userSpecifiedFilters.trim() + " " + this.ItemIdFilterService.buildSearchClause();
        this.userSpecifiedFilters = this.userSpecifiedFilters.trim();
    }

    public resetFilters() {
        // this.EquipmentStatusFilterService.reset(); - since this is a search filter - don't include in reset?
        this.EcnFilterService.reset();
        this.ItemIdFilterService.reset();
        this.OrgIdFilterService.reset();
        this.NomenclatureFilterService.reset();
        this.ManufacturerFilterService.reset();
        this.CommonModelFilterService.reset();
        this.CustomerNameFilterService.reset();
        this.CustomerOrgIdFilterService.reset();
        this.CustodianNameFilterService.reset();
        this.AcquisitionCostFilterService.reset();
        this.AcquisitionDateRangeFilterService.reset();
    }

    public retrieveDetailsForSelectedRecords() {
        angular.forEach(this.DetailsPaginationService.selectedSearchResults, (selectedSearchResult: any) => {
            if (selectedSearchResult.selected) {
                if (selectedSearchResult.detailsRetrieved === false) {
                    try {
                        this.EquipmentRecordService.postFindEquipmentRecordDetail(selectedSearchResult).then((result) => {
                            if (result) {
                                this.EquipmentRecordService.parseDetailEquipmentRecordResults(result, selectedSearchResult);
                                if (selectedSearchResult.detailsFound === true) {
                                    selectedSearchResult.detailsRetrieved = true;
                                }
                                this.$log.debug("detailsRetrieved: %s", JSON.stringify(selectedSearchResult.detailsRetrieved));
                                // this.$log.debug("retrieveDetailsForSelectedRecords() - selectedSearchResult: %s", JSON.stringify(selectedSearchResult));
                            }
                        });
                    } catch (err) {
                        this.$log.debug("%s - Error getting equipment detail record: %s", this.controllerName, err);
                    }
                }
            }
        });
    }

    public goToEquipmentRecordDetails(equipmentRecord) {
        if (equipmentRecord.selected) {
            // record is already in this.DetailsPaginationService.selectedSearchResults
            // no need for further action except to go to change state
            this.$state.go(this.StateConstants.EQUIP_RECORD_DETAILS);
            // this.$log.debug("goToEquipmentRecordDetails - this.selectedSearchResults: %s", JSON.stringify(this.DetailsPaginationService.selectedSearchResults));
        } else {
            // equipmentRecord.isSelected = true;

            this.EquipmentRecordService.equipmentRecord = equipmentRecord;
            this.EquipmentRecordService.postFindEquipmentRecordDetail(equipmentRecord)
                .then((response: IHttpPromiseCallbackArg<any>) => {
                    this.EquipmentRecordService.parseDetailEquipmentRecordResults(response, this.EquipmentRecordService.equipmentRecord);
                    // this.DetailsPaginationService.selectedSearchResults.push(this.EquipmentRecordService.equipmentRecord);
                    this.$state.go(this.StateConstants.EQUIP_RECORD_DETAILS);
                    // this.$log.debug("goToEquipmentRecordDetails 2 - this.selectedSearchResults: %s", JSON.stringify(this.DetailsPaginationService.selectedSearchResults));
                }, (errResponse: IHttpPromiseCallbackArg<any>) => {
                    this.$log.error("%s - Error getting equipment detail record: %s", this.controllerName);
                });
        }
    }
}