'use strict';

export class LocationController {
    private controllerName: string = "Equipment Record Details - Location Tab Controller";

    // @ngInject
    constructor(private DetailsPaginationService) {
    }

}