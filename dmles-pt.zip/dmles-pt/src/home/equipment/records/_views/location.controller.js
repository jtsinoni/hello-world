define(["require", "exports"], function (require, exports) {
    'use strict';
    var LocationController = (function () {
        // @ngInject
        function LocationController(DetailsPaginationService) {
            this.DetailsPaginationService = DetailsPaginationService;
            this.controllerName = "Equipment Record Details - Location Tab Controller";
        }
        return LocationController;
    }());
    exports.LocationController = LocationController;
});
//# sourceMappingURL=location.controller.js.map