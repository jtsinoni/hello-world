'use strict';

export class MainController {
    private controllerName: string = "Equipment Record Details - Main Tab Controller";

    // @ngInject
    constructor(private DetailsPaginationService) {
    }

}