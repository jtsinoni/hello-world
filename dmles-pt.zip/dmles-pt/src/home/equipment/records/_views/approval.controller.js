define(["require", "exports"], function (require, exports) {
    'use strict';
    var ApprovalController = (function () {
        // @ngInject
        function ApprovalController(DetailsPaginationService) {
            this.DetailsPaginationService = DetailsPaginationService;
            this.controllerName = "Equipment Record Details - Approval Tab Controller";
        }
        return ApprovalController;
    }());
    exports.ApprovalController = ApprovalController;
});
//# sourceMappingURL=approval.controller.js.map