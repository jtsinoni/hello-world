define(["require", "exports", './approval.controller', './components.controller', './dataManagement.controller', './equipmentRecordDetails.controller', './equipmentRecordSearch.controller', './location.controller', './main.controller', './maintenanceCost.controller', './maintenanceData.controller', './notes.controller'], function (require, exports, approval_controller_1, components_controller_1, dataManagement_controller_1, equipmentRecordDetails_controller_1, equipmentRecordSearch_controller_1, location_controller_1, main_controller_1, maintenanceCost_controller_1, maintenanceData_controller_1, notes_controller_1) {
    'use strict';
    var controllersModule = angular.module('Dmles.Home.Equipment.Records.Views.Module', []);
    controllersModule.controller('ApprovalController', approval_controller_1.ApprovalController);
    controllersModule.controller('ComponentsController', components_controller_1.ComponentsController);
    controllersModule.controller('DataManagementController', dataManagement_controller_1.DataManagementController);
    controllersModule.controller('EquipmentRecordDetailsController', equipmentRecordDetails_controller_1.EquipmentRecordDetailsController);
    controllersModule.controller('EquipmentRecordSearchController', equipmentRecordSearch_controller_1.EquipmentRecordSearchController);
    controllersModule.controller('LocationController', location_controller_1.LocationController);
    controllersModule.controller('MainController', main_controller_1.MainController);
    controllersModule.controller('MaintenanceCostController', maintenanceCost_controller_1.MaintenanceCostController);
    controllersModule.controller('MaintenanceDataController', maintenanceData_controller_1.MaintenanceDataController);
    controllersModule.controller('NotesController', notes_controller_1.NotesController);
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = controllersModule;
});
//# sourceMappingURL=module.js.map