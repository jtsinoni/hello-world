define(["require", "exports", "../../../../_common/_directives/dataGrid/dataGrid.class"], function (require, exports, dataGrid_class_1) {
    'use strict';
    var NotesController = (function () {
        // @ngInject
        function NotesController($scope, DetailsPaginationService, EquipmentRecordService, datatableService, UserService) {
            var _this = this;
            this.$scope = $scope;
            this.DetailsPaginationService = DetailsPaginationService;
            this.EquipmentRecordService = EquipmentRecordService;
            this.datatableService = datatableService;
            this.UserService = UserService;
            this.controllerName = "Equipment Record Details - Notes Tab Controller";
            this.notesDataGridOpts = null;
            this.buildNotesTable();
            this.$scope.$watch(function () { return _this.DetailsPaginationService.currentPage; }, function () {
                _this.notesDataGridOpts.loadData(_this.DetailsPaginationService.currentEquipmentRecord.notes);
            });
        }
        NotesController.prototype.buildNotesTable = function () {
            this.notesDataGridOpts = new dataGrid_class_1.DataTableOptions(this.datatableService);
            this.notesDataGridOpts.displayName = "Notes";
            this.notesDataGridOpts.noDataMessage = "Equipment Record does not contain notes.";
            this.notesDataGridOpts.showExportBtn = true;
            this.notesDataGridOpts.numberOfRows = 25;
            this.notesDataGridOpts.cols = [
                { field: "dateDisplayed", title: "Date", show: true, sortable: "date" },
                { field: "noteText", title: "Note", show: true, sortable: "noteText" },
                { field: "enteredBy", title: "Entered By", show: true, sortable: "enteredBy" }
            ];
            this.notesDataGridOpts.defaultSort = { date: 'desc' };
            this.notesDataGridOpts.loadData(this.DetailsPaginationService.currentEquipmentRecord.notes);
        };
        return NotesController;
    }());
    exports.NotesController = NotesController;
});
//# sourceMappingURL=notes.controller.js.map