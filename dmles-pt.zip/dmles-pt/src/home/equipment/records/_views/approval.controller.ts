'use strict';

export class ApprovalController {
    private controllerName: string = "Equipment Record Details - Approval Tab Controller";

    // @ngInject
    constructor(private DetailsPaginationService) {
    }

}

