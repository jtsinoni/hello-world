'use strict';

export class MaintenanceDataController {
    private controllerName: string = "Equipment Record Details - Maintenance Data Tab Controller";

    // @ngInject
    constructor(private DetailsPaginationService) {
    }

}