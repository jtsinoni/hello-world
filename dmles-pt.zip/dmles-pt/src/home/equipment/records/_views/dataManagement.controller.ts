export class DataManagementController {
    private controllerName:string = "DataManagementController";

    // @ngInject
    constructor(private $log) {
        this.$log.debug('%s - start ', this.controllerName);
    }

}