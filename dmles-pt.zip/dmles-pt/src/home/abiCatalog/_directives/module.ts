'use strict';

import {BaseCategoryService} from './Category/baseCategory.service';
import {Category} from './Category/category.directive';

import {BaseCategoryBreadcrumbService} from './CategoryBreadcrumb/baseCategoryBreadcrumb.service';
import {CategoryBreadcrumb} from './CategoryBreadcrumb/categoryBreadcrumb.directive';

import {BaseFacetService} from './Facet/baseFacet.service';
import {Facet} from './Facet/facet.directive';

import {BaseSearchWithinResultsService} from './SearchWithinResults/baseSearchWithinResults.service';
import {SearchWithinResults} from './SearchWithinResults/searchWithinResults.directive';

import {BaseSelectedFacetOptionsService} from './SelectedFacetOptionsBreadbox/baseSelectedFacetOptions.service';
import {SelectedFacetOptionsBreadbox} from './SelectedFacetOptionsBreadbox/selectedFacetOptionsBreadbox.directive';

var directivesModule = angular.module('Dmles.Home.AbiCatalog.Directives.Module', []);

directivesModule.service('BaseCategoryService', BaseCategoryService);
directivesModule.directive('category', Category.Factory());

directivesModule.service('BaseCategoryBreadcrumbService', BaseCategoryBreadcrumbService);
directivesModule.directive('categoryBreadcrumb', CategoryBreadcrumb.Factory());

directivesModule.service('BaseFacetService', BaseFacetService);
directivesModule.directive('facet', Facet.Factory());

directivesModule.service('BaseSearchWithinResultsService', BaseSearchWithinResultsService);
directivesModule.directive('searchWithinResults', SearchWithinResults.Factory());

directivesModule.service('BaseSelectedFacetOptionsService', BaseSelectedFacetOptionsService);
directivesModule.directive('selectedFacetOptionsBreadbox', SelectedFacetOptionsBreadbox.Factory());

export default directivesModule;