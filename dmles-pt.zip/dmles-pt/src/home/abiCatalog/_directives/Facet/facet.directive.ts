'use strict';

export class Facet {

    constructor() {
        Facet.prototype.link = (scope, element, attr) => {
        };
    }

    public templateUrl: string = "src/home/abiCatalog/_directives/Facet/facet.html";
    public restrict: string = 'E';  // E = element, A = attribute, C = class, M = comment
    public scope: any = {
        config: '='
    };
    public link: (scope, element, attrs) => void;

    public static Factory() {
        var directive = () => {
            return new Facet();
        };

        return directive;
    }
}