'use strict';

import {FacetOption} from "../../_models/facetOption.model";
import {SearchConstants} from "../../_constants/search.constants";

export class BaseSelectedFacetOptionsService {

    public selectedFacetOptions: Array<FacetOption> = [];

    // this module (for event purposes)
    public eventModule: string = SearchConstants.EVENT_MODULE_BASE;

    // @ngInject
    constructor(private $log, private $rootScope, private SearchUtilService) {
    }

    public getSelectedFacetOptions(): Array<FacetOption> {
        this.SearchUtilService.sortByCriteria(this.selectedFacetOptions, ["type", "value"]);
        return this.selectedFacetOptions;
    }

    public clearAllSelectedFacetOptions() {
        this.clearAllSelectedOptionsFromFacetOptions();

        this.clearSelectedFacetOptions();
    }

    private clearAllSelectedOptionsFromFacetOptions() {
        let selectedFacetOptions: Array<FacetOption> = this.getSelectedFacetOptions();

        // for each selected facet option
        for (let i: number = 0; i < selectedFacetOptions.length; i++) {

            let eventId = this.SearchUtilService.buildEventId(
                this.eventModule,
                selectedFacetOptions[i].type + SearchConstants.EVENT_TARGET_COMPONENT_FACET,
                SearchConstants.EVENT_TARGET_METHOD_CLEAR_SELECTED_FACET_OPTION);

            this.$log.debug("emit " + eventId + " event");
            this.$rootScope.$emit(eventId, selectedFacetOptions[i]);
        }
    }

    public clearSelectedFacetOptions() {
        this.selectedFacetOptions = [];
    }


    private clearSelectedFacetOption(selectedOption) {
        this.clearSelectedOptionFromFacetOptions(selectedOption);
        this.removeSelectedFacetOption(selectedOption);
    }

    private clearSelectedOptionFromFacetOptions(selectedOption) {
        let eventId = this.SearchUtilService.buildEventId(
            this.eventModule,
            selectedOption.type + SearchConstants.EVENT_TARGET_COMPONENT_FACET,
            SearchConstants.EVENT_TARGET_METHOD_CLEAR_SELECTED_FACET_OPTION);

        this.$log.debug("emit " + eventId + " event");
        this.$rootScope.$emit(eventId, selectedOption);
    }

    public init() {        
    }

    public executeSearch() {
        this.SearchUtilService.executeSearch(this.eventModule, null);
    }

    public removeSelectedFacetOption(facetOption: FacetOption) {
        this.$log.debug("removeSelectedFacetOption - facetOption: %s", JSON.stringify(facetOption));
        for (let i: number = 0; i < this.getSelectedFacetOptions().length; i++) {
            if (this.selectedFacetOptions[i].type === facetOption.type
                && this.selectedFacetOptions[i].value === facetOption.value) {
                this.selectedFacetOptions.splice(i, 1);
            }
        }
    }

    public updateSelectedFacetOptions(facetOption: FacetOption) {
        this.$log.debug("updateSelectedFacetOptions - facetOption: %s", JSON.stringify(facetOption));
        if (facetOption.selected) {
            // add facet value to selectedFacetOptions array
            this.selectedFacetOptions.push({
                type: facetOption.type,
                value: facetOption.value,
                count: facetOption.count,
                selected: facetOption.selected
            });
        } else { // FacetOption.selected === false
            this.removeSelectedFacetOption(facetOption);
        }
    }
}