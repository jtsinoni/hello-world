'use strict';
import {AbiCatalogSearchController} from "../../_views/abiCatalogSearch.controller";

export class SelectedFacetOptionsBreadbox {

    public templateUrl: string = "src/home/abiCatalog/_directives/SelectedFacetOptionsBreadbox/selectedFacetOptionsBreadbox.html";
    public restrict: string = 'E';  // E = element, A = attribute, C = class, M = comment    
    public scope: any = {
        config: '='
    };
    public link: (scope, element, attrs) => void;

    // @ngInject
    constructor() {
        SelectedFacetOptionsBreadbox.prototype.link = (scope, element, attr) => {
        };
    }

    public static Factory() {
        var directive = () => {
            return new SelectedFacetOptionsBreadbox();
        };

        return directive;
    }
}