'use strict';

import router from './router';
import {ShellController} from './shell.controller';

// modules
import controllersModule from './_views/module';
import constantsModule from './_constants/module';
import directivesModule from './_directives/module';
import modelsModule from './_models/module';
import servicesModule from './_services/module';

var module = angular.module('Dmles.Home.AbiCatalogModule', [
	controllersModule.name,
	constantsModule.name,
	directivesModule.name,
	modelsModule.name,
    servicesModule.name
]);

module.controller('Dmles.Home.AbiCatalog.ShellController', ShellController);
module.config(router.factory);

export default module;