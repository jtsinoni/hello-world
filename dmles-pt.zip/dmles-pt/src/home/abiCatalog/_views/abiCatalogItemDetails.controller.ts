'use strict';

export class AbiCatalogItemDetailsController {
    private controllerName:string = "Catalog Item Details Controller";
    public previousState:string;

    // @ngInject
    constructor(private $log, private $rootScope, private AbiCatalogService, private StateConstants,
                private UserService, private UserTypeConstants) {
        this.$log.debug("%s - Start", this.controllerName);
        $(window).scrollTop(0);
        this.previousState = this.$rootScope.previousState;
    }
}

