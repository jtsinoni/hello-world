'use strict';

import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {CatalogItem} from '../_models/catalogItem.model';
import {CurrentUserProfile} from "../../../_models/currentUserProfile.model";
import {FacetOption} from "../_models/facetOption.model";
import {SearchConstants} from "../_constants/search.constants";

export class AbiCatalogSearchController {
    private controllerName: string = "ABi Catalog Search Controller";
    private searchStats: any = {};
    private userSpecifiedFilters: string = "";

    public catalogSearchResults: Array<CatalogItem> = [];
    public catalogAggregations: any = {};
    public catalogSearchStats: string;
    public currentUserProfile: CurrentUserProfile = new CurrentUserProfile();
    public isLoadingSearch: boolean;

    public ngCatalogTable: any = null;
    public searchInput: string;
    public searchMaxResultsText: string;
    public searchPlaceholder: string = "What are you looking for? Try searching our catalog ...";
    public showMaxResultsWarning: boolean;
    public sortOrder: string = "shortItemDesc";

    public lastFacetOptionUpdated: FacetOption = null;

    // @ngInject
    constructor(private $log, private $rootScope, private $state,
                private AbiCatalogService, private CategoriesService, private CategoryBreadcrumbsService,
                private ContentConstants, private datatableService, private FacetsService,
                private ItemComparisonService, private NotificationService, private SearchWithinResultsService,
                private SearchUtilService, private SelectedFacetOptionsBreadboxService,
                private SidePanelService, private StateConstants, private UserService, private UtilService) {

        this.$log.debug("%s - Start", this.controllerName);
        $(window).scrollTop(0);
        this.currentUserProfile = this.UserService.currentUser;
        this.searchMaxResultsText = "Over " + this.ContentConstants.SEARCH_MAX + " items have been found, please refine your search";

        let executeSearchEventId = this.SearchUtilService.buildEventId(
            SearchConstants.EVENT_MODULE_ABI_CATALOG,
            SearchConstants.EVENT_TARGET_COMPONENT_SEARCH,
            SearchConstants.EVENT_TARGET_METHOD_EXECUTE_SEARCH);

        let executeSearchEventHandler = this.$rootScope.$on(executeSearchEventId, (event: ng.IAngularEvent, data: FacetOption) => {
            this.$log.debug("caught " + executeSearchEventId + " event");
            this.lastFacetOptionUpdated = data;
            this.executeSearch();
        });
        this.$rootScope.$on('$destroy', function () {
            executeSearchEventHandler();
        });

        this.init();
    }

    public executeSearch() {
        this.$log.debug("%s - executeSearch: %s", this.controllerName, this.searchInput);
        this.getCatalogItems();
    }

    private getCatalogItems() {
        this.isLoadingSearch = true;
        this.catalogSearchStats = "";
        this.processUserSpecifiedFilters();

        this.$log.debug("this.searchInput: %s", JSON.stringify(this.searchInput));
        this.$log.debug("this.userSpecifiedFilters: %s", JSON.stringify(this.userSpecifiedFilters));
        this.$log.debug("this.buildAggregationsRequest(): %s", JSON.stringify(this.buildAggregationsRequest()));

        this.AbiCatalogService.getSummaryEquipmentRecords(this.searchInput, this.userSpecifiedFilters, this.buildAggregationsRequest()).then((response: IHttpPromiseCallbackArg<any>) => {            
            //this.$log.debug("response: %s", JSON.stringify(response));

            this.catalogSearchResults = this.AbiCatalogService.parseSummaryEquipmentRecordResults(response);
            //this.$log.debug("this.catalogSearchResults: %s", JSON.stringify(this.catalogSearchResults));

            this.catalogAggregations = this.AbiCatalogService.parseSummaryEquipmentRecordAggregations(response);
            // this.$log.debug("this.catalogAggregations: %s", JSON.stringify(this.catalogAggregations));

            this.searchStats = this.AbiCatalogService.getSearchStats(response);

            this.populateFiltersAndResultsTable();

        }, (errResponse: IHttpPromiseCallbackArg<boolean>) => {
            this.isLoadingSearch = false;
            this.$log.debug("%s - Error getting catalog items from elastic.", this.controllerName);
            this.NotificationService.errorMsg("An error occurred while retrieving catalog items");
        });
    }

    private populateFiltersAndResultsTable() {
        this.showMaxResultsWarning = false;
        this.populateCategoriesPerCurrentResults();
        this.populateFacetsPerCurrentResults();

        this.ngCatalogTable = this.datatableService.createNgTable(this.catalogSearchResults);

        if (this.ContentConstants.SEARCH_MAX <= this.catalogSearchResults.length) {
            this.catalogSearchStats = this.UtilService.esBuildSearchStatsStr(this.searchStats.total, this.searchStats.time);
            this.showMaxResultsWarning = true;
            this.NotificationService.warningMsg("The maximum search results were reached, please refine your search.");
        } else {
            this.catalogSearchStats = this.UtilService.esBuildSearchStatsStr(this.catalogSearchResults.length, this.searchStats.time);
        }
        this.isLoadingSearch = false;
    }

    //
    // functions that reference the individual Filter-related services
    //

    private init() {
        angular.forEach(this.CategoriesService.getCategories(), (category) => {
            category.initialize();
        });

        angular.forEach(this.FacetsService.getFacets(), (facet) => {
            facet.initialize();
        });

        // initialize the Selected Facet Option Breadbox to empty
        this.SelectedFacetOptionsBreadboxService.clearSelectedFacetOptions();
    }

    private processUserSpecifiedFilters() {
        this.userSpecifiedFilters = "";

        angular.forEach(this.SearchWithinResultsService.getSearchWithinResultsKeywords(), (keyword) => {
            this.userSpecifiedFilters = this.userSpecifiedFilters.trim() + " " + keyword;
        });

        angular.forEach(this.CategoriesService.getCategories(), (category) => {
            this.userSpecifiedFilters = this.userSpecifiedFilters.trim()
                + " " + category.buildSearchClause(category.categoryConfiguration.elasticSearchFieldNames);
        });

        angular.forEach(this.FacetsService.getFacets(), (facet) => {
            this.userSpecifiedFilters = this.userSpecifiedFilters.trim()
                + " " + facet.buildSearchClause(facet.facetConfiguration.elasticSearchFieldName);
        });

        this.userSpecifiedFilters = this.userSpecifiedFilters.trim();
    }

    private buildAggregationsRequest(): string {
        let aggregationsRequest: string = '{"aggregations": [';
        angular.forEach(this.FacetsService.getFacets(), (facet) => {
            aggregationsRequest = aggregationsRequest + '{"name":"' + facet.facetConfiguration.aggregationIdentifier
                + '","field":"' + facet.facetConfiguration.elasticSearchFieldName + '.raw","size":"5000"}';
        });
        aggregationsRequest = aggregationsRequest + ']}';

        return aggregationsRequest;
    }

    private ifOnlyCurrentFacetHasOptionsSelected(currentFacet): boolean {
        let returnValue: boolean = true;
        angular.forEach(this.FacetsService.getFacets(), (facet) => {
            // if we ate dealing with a facet that is NOT the current facet
            if (facet.facetConfiguration.displayLabel !== currentFacet.facetConfiguration.displayLabel) {
                // if an option is selected, return false from this function
                if (facet.isAnOptionSelected()) {
                    returnValue = false;
                }
            }
        });
        return returnValue;
    }

    private populateCategoriesPerCurrentResults() {
        let catalogAggregations = {
            "UNSPSC Commodity": {
                "doc_count_error_upper_bound": 0,
                "sum_other_doc_count": 0,
                "buckets": [{"key": "commodity10"}, {"key": "commodity11"}, {"key": "commodity12"}, {"key": "commodity13"}]
            },
            "UNSPSC Class": {
                "doc_count_error_upper_bound": 0,
                "sum_other_doc_count": 0,
                "buckets": [{"key": "class20"}, {"key": "class21"}, {"key": "class22"}, {"key": "class23"}]
            },
            "UNSPSC Family": {
                "doc_count_error_upper_bound": 0,
                "sum_other_doc_count": 0,
                "buckets": [{"key": "family30"}, {"key": "family31"}, {"key": "family32"}, {"key": "family33"}]
            },
            "UNSPSC Segment": {
                "doc_count_error_upper_bound": 0,
                "sum_other_doc_count": 0,
                "buckets": [{"key": "segment40"}, {"key": "segment41"}, {"key": "segment42"}, {"key": "segment43"}]
            }
        };

        angular.forEach(this.CategoriesService.getCategories(), (category) => {
            category.populate(category, catalogAggregations);
        });
    }

    private populateFacetsPerCurrentResults() {
        angular.forEach(this.FacetsService.getFacets(), (facet) => {

            // if THIS facet has any facet options selected
            if (facet.isAnOptionSelected()) {

                // if the last user facet-effecting action was one that updated a specific facet option
                if (this.lastFacetOptionUpdated) {

                    // if the last facet option that was updated belongs to THIS facet
                    if (this.lastFacetOptionUpdated.type === facet.facetConfiguration.displayLabel) {

                        // this.$log.debug("populateFacetsPerCurrentResults() - this.lastFacetOptionUpdated = %s: " + JSON.stringify(this.lastFacetOptionUpdated));

                        // if THIS facet has ever had the counts associated with its facet options updated
                        if (facet.haveFacetOptionCountsBeenUpdated) {

                            // since we've already updated this facet's option counts once (probably due the fact
                            // that another facet was interacted with), go ahead and update them again
                            facet.updateExistingFacetOptionCounts(this.catalogAggregations);
                        } else {

                            // leave the facet options and counts as is - usually you are here when only one facet has
                            // been interacted with so far, leave as is so the user sees the original facet options and
                            // counts that were generated just using the user input search string
                        }

                        // the last facet option that was updated belongs to a different facet
                    } else {

                        // update THIS facet's existing facet options with new counts
                        facet.updateExistingFacetOptionCounts(this.catalogAggregations);
                    }

                    // the last user facet-effecting action was a Clear All or something that didn't effect a specific facet
                } else {

                    // update THIS facet's existing facet options with new counts
                    facet.updateExistingFacetOptionCounts(this.catalogAggregations);
                }

                // THIS facet has no facet options currently selected
            } else {

                // reinitialize THIS facet's options and counts with the latest aggregation results
                facet.populate(this.catalogAggregations);
            }
        });
    }

    public resetFacets() {
        angular.forEach(this.FacetsService.getFacets(), (facet) => {
            facet.reset();
        });

        this.executeSearch();
    }

    public goToDetails(abiCatalogItem) {
        this.$log.debug("goToDetails - abiCatalogItem: %s", JSON.stringify(abiCatalogItem));
        this.AbiCatalogService.setAbiCatalogItem(abiCatalogItem);
        this.$log.debug("goToDetails - this.AbiCatalogService.abiCatalogItem: %s", JSON.stringify(this.AbiCatalogService.abiCatalogItem));
        this.$state.go(this.StateConstants.ABI_CATALOG_ITEM_DETAILS);
    }

    public goToItemComparison() {
        this.$state.go(this.StateConstants.ABI_CATALOG_ITEM_COMPARISON);
    }
}