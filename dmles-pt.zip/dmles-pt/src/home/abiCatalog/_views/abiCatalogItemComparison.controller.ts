'use strict';

export class AbiCatalogItemComparisonController {
    
    private controllerName: string = "ABi Catalog Item Comparison Controller";
    public previousState:string;

    // @ngInject
    constructor(private $log, private $rootScope, private $state, private ItemComparisonService, private StateConstants) {
        this.$log.debug("%s - Start", this.controllerName);
        $(window).scrollTop(0);
        this.previousState = this.$rootScope.previousState;
    }

    public goToPreviousState() {
        if (this.$rootScope.previousState) {
            this.$state.go(this.$rootScope.previousState);
        } else {
            this.$state.go(this.StateConstants.ABI_CATALOG_SEARCH);
        }
    }
}