'use strict';

import {AbiCatalogItemComparisonController} from './abiCatalogItemComparison.controller';
import {AbiCatalogItemDetailsController} from './abiCatalogItemDetails.controller';
import {AbiCatalogSearchController} from './abiCatalogSearch.controller';

var controllersModule = angular.module('Dmles.Home.AbiCatalog.Views.Module', []);
controllersModule.controller('Dmles.Home.AbiCatalog.Views.AbiCatalogItemComparisonController', AbiCatalogItemComparisonController);
controllersModule.controller('Dmles.Home.AbiCatalog.Views.AbiCatalogItemDetailsController', AbiCatalogItemDetailsController);
controllersModule.controller('Dmles.Home.AbiCatalog.Views.AbiCatalogSearchController', AbiCatalogSearchController);

export default controllersModule;