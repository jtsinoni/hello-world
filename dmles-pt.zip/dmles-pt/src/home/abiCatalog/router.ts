'use strict';

class Router {
    static instance:any;

    // @ngInject
    constructor($stateProvider, $urlRouterProvider, StateConstants) {

        $stateProvider
            .state(StateConstants.ABI_CATALOG_SHELL, {
                url: '/abiCatalog',
                templateUrl: '/src/home/abiCatalog/shell.html',
                controller: 'Dmles.Home.AbiCatalog.ShellController',
                controllerAs: 'vm',
                abstract: true
            }).state(StateConstants.ABI_CATALOG_FAVS, {
                url: '/abiCatalogFavorites',
                templateUrl: '/src/home/abiCatalog/_views/abiCatalogFavorites.html',
                controller: 'Dmles.Home.AbiCatalog.Views.AbiCatalogFavoritesController',
                controllerAs: 'vm',
                data: {
                    displayName: 'ABi Catalog Favorites'
                }
            }).state(StateConstants.ABI_CATALOG_SEARCH, {
                url: '/abiCatalogSearch',
                templateUrl: '/src/home/abiCatalog/_views/abiCatalogSearch.html',
                controller: 'Dmles.Home.AbiCatalog.Views.AbiCatalogSearchController',
                controllerAs: 'vm',
                data: {
                    displayName: 'ABi Catalog Search'
                }
            }).state(StateConstants.ABI_CATALOG_ITEM_DETAILS, {
                url: '/abiCatalogItemDetails',
                templateUrl: '/src/home/abiCatalog/_views/abiCatalogItemDetails.html',
                controller: 'Dmles.Home.AbiCatalog.Views.AbiCatalogItemDetailsController',
                controllerAs: 'vm',
                data: {
                    displayName: 'ABi Catalog Item Details'
                }
            }).state(StateConstants.ABI_CATALOG_ITEM_COMPARISON, {
                url: '/abiCatalogItemComparison',
                templateUrl: '/src/home/abiCatalog/_views/abiCatalogItemComparison.html',
                controller: 'Dmles.Home.AbiCatalog.Views.AbiCatalogItemComparisonController',
                controllerAs: 'vm',
                data: {
                    displayName: 'ABi Catalog Item Comparison'
                }
        });
    }

    static factory($stateProvider, $urlRouterProvider, StateConstants) {
        Router.instance = new Router($stateProvider, $urlRouterProvider, StateConstants);
        return Router.instance;
    }
}

Router.factory.$inject = ['$stateProvider', '$urlRouterProvider', 'StateConstants'];

export default Router;