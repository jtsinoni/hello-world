'use strict';

import {SearchConstants} from './search.constants';

var constantModule = angular.module('Dmles.Home.AbiCatalog.Constants.Module', []);
constantModule.constant('SearchConstants', SearchConstants);

export default constantModule;