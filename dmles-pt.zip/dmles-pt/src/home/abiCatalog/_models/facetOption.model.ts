'use strict';

export class FacetOption {
    public type: string = "";
    public value: string = "";
    public count: number = 0;
    public selected: Boolean = false;

    constructor();
    constructor(obj: FacetOption);
    constructor(obj?: any) {
        this.type = obj && obj.type || "";
        this.value = obj && obj.value || "";
        this.count = obj && obj.value || 0;
        this.selected = obj && obj.selected || false;
    };
}