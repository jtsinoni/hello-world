'use strict';

import {ItemIdentifier} from "./itemIdentifier.model";
import {BarcodeIdentifier} from "./barcodeIdentifier.model";

export class Package {
    public enterprisePackageIdentifier: string = "";
    public gtin: string = "";   // Global Trade Item Number
    public niin: string = "";   // National Item Identification Number
    public nsn: string = "";   // National Stock Number
    public otherPackageIdentifiers: Array<ItemIdentifier> = [];
    public packageUnit: string = "";
    public packageQuantity: Number = 0;
    public gudidIdentifierType: string = "";
    public barcodeData: Array<BarcodeIdentifier> = [];

    constructor();
    constructor(obj: Package);
    constructor(obj?: any) {
        this.enterprisePackageIdentifier = obj && obj.enterprisePackageIdentifier || "";
        this.gtin = obj && obj.gtin || "";
        this.niin = obj && obj.niin || "";
        this.nsn = obj && obj.nsn || "";
        this.otherPackageIdentifiers = obj && obj.otherPackageIdentifiers || [];
        this.packageUnit = obj && obj.packageUnit || "";
        this.packageQuantity = obj && obj.packageQuantity || 0;
        this.gudidIdentifierType = obj && obj.gudidIdentifierType || "";
        this.barcodeData = obj && obj.barcodeData || [];
    };
}
