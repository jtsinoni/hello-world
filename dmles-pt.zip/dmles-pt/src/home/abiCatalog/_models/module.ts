'use strict';

import {CatalogItem} from './catalogItem.model';
import {CategoryConfiguration} from './categoryConfiguration.model';
import {CategoryOption} from './categoryOption.model';
import {FacetConfiguration} from './facetConfiguration.model';
import {FacetOption} from './facetOption.model';
import {VirtualItemMaster} from './virtualItemMaster.model';

var modelsModule = angular.module('Dmles.Home.AbiCatalog.Models.Module', []);
modelsModule.value('CatalogItem', CatalogItem);
modelsModule.value('CategoryConfiguration', CategoryConfiguration);
modelsModule.value('CategoryOption', CategoryOption);
modelsModule.value('FacetConfiguration', FacetConfiguration);
modelsModule.value('FacetOption', FacetOption);
modelsModule.value('VirtualItemMaster', VirtualItemMaster);

export default modelsModule;