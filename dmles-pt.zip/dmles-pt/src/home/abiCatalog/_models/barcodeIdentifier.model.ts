'use strict';

export class BarcodeIdentifier {
    public barcode: string = "";
    public barcodeType: string = "";   

    constructor();
    constructor(obj: BarcodeIdentifier);
    constructor(obj?: any) {
        this.barcode = obj && obj.barcode || "";
        this.barcodeType = obj && obj.barcodeType || "";        
    };
}
