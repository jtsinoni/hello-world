'use strict';

export class ItemIdentifier {
    public identifier: string = "";
    public identifierType: string = "";   

    constructor();
    constructor(obj: ItemIdentifier);
    constructor(obj?: any) {
        this.identifier = obj && obj.identifier || "";
        this.identifierType = obj && obj.identifierType || "";        
    };
}
