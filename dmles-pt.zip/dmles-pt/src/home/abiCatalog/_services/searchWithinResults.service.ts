'use strict';

import {BaseSearchWithinResultsService} from "../_directives/SearchWithinResults/baseSearchWithinResults.service";
import {SearchConstants} from "../_constants/search.constants";

export class SearchWithinResultsService extends BaseSearchWithinResultsService {

    // this module (for event purposes)
    public eventModule: string = SearchConstants.EVENT_MODULE_ABI_CATALOG;

    // @ngInject
    constructor($log, $rootScope, SearchUtilService, SelectedFacetOptionsBreadboxService) {
        super($log, $rootScope, SearchUtilService, SelectedFacetOptionsBreadboxService);

        this.init();
    }
}