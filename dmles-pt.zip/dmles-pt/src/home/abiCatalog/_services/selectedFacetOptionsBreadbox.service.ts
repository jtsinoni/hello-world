'use strict';

import {BaseSelectedFacetOptionsService} from "../_directives/SelectedFacetOptionsBreadbox/baseSelectedFacetOptions.service";
import {SearchConstants} from "../_constants/search.constants";

export class SelectedFacetOptionsBreadboxService extends BaseSelectedFacetOptionsService {    

    // this module (for event purposes)
    public eventModule: string = SearchConstants.EVENT_MODULE_ABI_CATALOG;

    // @ngInject
    constructor($log, $rootScope, SearchUtilService) {
        super($log, $rootScope, SearchUtilService);        

        this.init();
    }
}
