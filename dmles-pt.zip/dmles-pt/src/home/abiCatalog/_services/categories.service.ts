'use strict';

import {CategoryOption} from "../_models/categoryOption.model";
import {CategoryConfiguration} from "../_models/categoryConfiguration.model";
import {Category} from "./category.service";

export class CategoriesService {

    public categories: Array<any> = [];

    // @ngInject
    constructor(private $log, private $rootScope, private SearchUtilService, private AbiCatalogService) {

        let unspscCategoryConfiguration: CategoryConfiguration = {
            displayLabel: "UNSPSC Taxonomy",
            aggregationIdentifiers: ["UNSPSC Segment", "UNSPSC Family", "UNSPSC Class", "UNSPSC Commodity"],
            elasticSearchFieldNames: ["unspscSegment", "unspscFamily", "unspscClass", "unspscCommodity"],
            initializeAsCollapsed: false,
            topLevelInitialCategoryOptions: this.AbiCatalogService.getUnspscSegments()
        };
        this.categories.push(new Category($log, $rootScope, unspscCategoryConfiguration, SearchUtilService));
    }

    public getCategories(): Array<CategoryOption> {
        return this.categories;
    }
}