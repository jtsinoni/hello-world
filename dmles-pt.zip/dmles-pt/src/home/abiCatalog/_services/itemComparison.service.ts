'use strict';

import {VirtualItemMaster} from "../_models/virtualItemMaster.model";

export class ItemComparisonService {

    public itemComparisonList: Array<VirtualItemMaster> = [];
    public itemComparisonListMaxSize: number = 3;

    public itemComparisonNgTable: any = null;

    // @ngInject
    constructor(private $log, private datatableService, private NotificationService) {
    }

    public getItemComparisonList(): Array<VirtualItemMaster> {
        return this.itemComparisonList;
    }

    public clearItemComparisonList() {
        this.itemComparisonList = [];
    }

    public loadItemComparisonNgTable() {
        this.itemComparisonNgTable = this.datatableService.createNgTable(this.itemComparisonList, 25, {meId: 'asc'});
    }

    public updateItemComparisonList(item: VirtualItemMaster) {
        // this.$log.debug("updateItemComparisonList - item: %s", JSON.stringify(item));

        // if we want to ADD this item to the item comparison list
        if (item.compareSelected === true) {
            // if we are already full, need to display error and do nothing
            if (this.itemComparisonList.length === this.itemComparisonListMaxSize) {
                item.compareSelected = false;
                this.$log.debug("You can compare only three products, please unselect a product before proceeding.");
                this.NotificationService.errorMsg("You can compare only three products, please unselect a product before proceeding.");
            } else {
                // insert item in the first empty slot in the itemComparisonList
                for (let i = 0; i < this.itemComparisonListMaxSize; i++) {
                    if (!this.itemComparisonList[i]) {
                        this.itemComparisonList[i] = item;
                        break;
                    }
                }
            }
        } else {
            // we want to DELETE this item from the item comparison list
            // look for item and if found remove it
            for (let i = 0; i < this.itemComparisonList.length; i++) {
                // for now use meId to compare - will be id for real VIM
                if (this.itemComparisonList[i].meId === item.meId) {
                    this.itemComparisonList.splice(i, 1);
                    break;
                }
            }
        }

        this.loadItemComparisonNgTable();

        // this.$log.debug("this.itemComparisonList: %s", JSON.stringify(this.itemComparisonList));
        // this.$log.debug("this.itemComparisonList.length = %d", this.itemComparisonList.length);
        
    }
}