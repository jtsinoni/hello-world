'use strict';

import {SearchConstants} from "../_constants/search.constants";
import {FacetOption} from "../_models/facetOption.model";

export class SearchUtilService {

    constructor(private $log, private $rootScope) {
    }

    public buildEventId(module: string, component: string, action: string): string {
        return module + ":" + component + ":" + action;
    }

    public executeSearch(eventModule: string, data: any) {
        let eventId = this.buildEventId(
            eventModule,
            SearchConstants.EVENT_TARGET_COMPONENT_SEARCH,
            SearchConstants.EVENT_TARGET_METHOD_EXECUTE_SEARCH);

        this.$log.debug("emit: %s", JSON.stringify(eventId));
        this.$rootScope.$emit(eventId, data);
    }

    public sortByCriteria(data, criteria) {
        return data.sort(function (a, b) {

            var i, iLen, aChain, bChain;

            i = 0;
            iLen = criteria.length;
            for (i; i < iLen; i++) {
                aChain += a[criteria[i]];
                bChain += b[criteria[i]];
            }

            return aChain.localeCompare(bChain);
        });
    }
}