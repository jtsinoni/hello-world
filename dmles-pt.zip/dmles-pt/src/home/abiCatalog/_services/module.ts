'use strict';

import {AbiCatalogService} from './abiCatalog.service';
import {CategoriesService} from './categories.service';
import {Category} from './category.service';
import {CategoryBreadcrumb} from './categoryBreadcrumb.service';
import {CategoryBreadcrumbsService} from './categoryBreadcrumbs.service';
import {FacetsService} from './facets.service';
import {Facet} from './facet.service';
import {ItemComparisonService} from './itemComparison.service';
import {SearchUtilService} from './searchUtil.service';
import {SearchWithinResultsService} from './searchWithinResults.service';
import {SelectedFacetOptionsBreadboxService} from './selectedFacetOptionsBreadbox.service';

var servicesModule = angular.module('Dmles.Home.AbiCatalog.Services.Module', []);
servicesModule.service('AbiCatalogService', AbiCatalogService);
servicesModule.service('CategoriesService', CategoriesService);
servicesModule.factory('Category', Category);
servicesModule.factory('CategoryBreadcrumb', CategoryBreadcrumb);
servicesModule.service('CategoryBreadcrumbsService', CategoryBreadcrumbsService);
servicesModule.factory('Facet', Facet);
servicesModule.service('FacetsService', FacetsService);
servicesModule.service('ItemComparisonService', ItemComparisonService);
servicesModule.service('SearchUtilService', SearchUtilService);
servicesModule.service('SearchWithinResultsService', SearchWithinResultsService);
servicesModule.service('SelectedFacetOptionsBreadboxService', SelectedFacetOptionsBreadboxService);

export default servicesModule;