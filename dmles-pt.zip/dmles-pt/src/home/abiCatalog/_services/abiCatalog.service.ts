'use strict';

import {ApiService} from '../../../_services/api.service';
import {EquipmentRecordSummary} from "../../equipment/records/_models/equipmentRecordSummary.model";
import {EquipmentRecord} from "../../equipment/records/_models/equipmentRecord.model";
import {VirtualItemMaster} from "../_models/virtualItemMaster.model";
import {CategoryOption} from "../_models/categoryOption.model";
import {ItemIdentifier} from "../_models/itemIdentifier.model";
import {Package} from "../_models/package.model";
import {BarcodeIdentifier} from "../_models/barcodeIdentifier.model";

export interface IAbiCatalogService {

}

export class AbiCatalogService extends ApiService implements IAbiCatalogService {
    private abiCatalogItem: VirtualItemMaster = new VirtualItemMaster();
    private serviceName: string = "ABi Catalog Service";
    public activeRequestTable: any;

    // @ngInject
    constructor($http, $httpParamSerializerJQLike, private $filter, $log, private $state,
                Authentication, private datatableService, private NotificationService, private RequestService,
                private StateConstants, private UtilService, private WorkFlowService) {
        super($http, $log, Authentication, $httpParamSerializerJQLike, "EquipmentManagement");
        this.$log.debug("%s - Start", this.serviceName);
    }

    public clearAbiCatalogItem() {
        this.abiCatalogItem = null;
    }

    public createActiveRequestTable(data) {
        this.activeRequestTable = this.datatableService.createNgTable(data, 25, {updatedDate: 'desc'});
    }

    public filterActiveRequests(requestList) {
        return this.$filter('filter')(requestList, (o) => {
            return o.wfProcessing && this.WorkFlowService.isRequestAtUsersLevel(o);
        });
    }

    public getAbiCatalogItem() {
        if (this.abiCatalogItem) {
            return this.abiCatalogItem;
        }
        return null;
    }

    public getEquipItems(searchValue: string, dodaac: string, userSpecifiedFilters: string) {
        this.$log.debug("%s - getEquipItems: searchValue=%s", this.serviceName, searchValue);
        this.$log.debug("%s - getEquipItems: dodaac=%s", this.serviceName, dodaac);
        this.$log.debug("%s - getEquipItems: userSpecifiedFilters=%s", this.serviceName, userSpecifiedFilters);

        //Note: check to see if anything got sent through, otherwise a string 'undefined' will be sent to bt.
        var dodaacStr: string = (dodaac) ? dodaac : "";
        // var dodaacStr: string = "";
        var searchValue: string = (searchValue) ? searchValue : "";
        var userSpecifiedFilters: string = (userSpecifiedFilters) ? userSpecifiedFilters : "";

        // escape special characters
        searchValue = this.UtilService.esEscapeSpecialChars(searchValue);

        if (searchValue === "" || searchValue === "*") {
            searchValue = userSpecifiedFilters;
        } else {
            searchValue = searchValue + " " + userSpecifiedFilters;
        }

        // encode URI/URL reserved characters
        searchValue = encodeURIComponent(searchValue);

        return this.get("getCatalogSearchResults?searchValue=" + searchValue + "&?dodaac=" + dodaacStr);
    }

    public getSearchStats(result) {
        var retVal = {
            "total": 0,
            "time": 0.00
        };

        if (result && result.data && result.data.hits) {
            if (result.data.hits.total) {
                retVal.total = result.data.hits.total;
            }

            if (result.data.took) {
                retVal.time = result.data.took;
            }
        }
        else {
            this.$log.debug("%s - Warning: No data returned", this.serviceName);
        }
        return retVal;
    }

    public parseAbiCatalogResults(results) {
        var vimList: Array<VirtualItemMaster> = [];
        if (results && results.data.hits.hits) {
            var abiCatalogResults = results.data.hits.hits;

            // TODO: This iteration may not be needed once dmles-gui pulls from the Java EndPoint for
            // ES equipment search results.  Currently dmles-gui is hitting ES directly, which nests the
            // equipment search results under data.hits.hits.fields.
            for (var i in abiCatalogResults) {
                var resultItem = abiCatalogResults[i];
                if (resultItem.hasOwnProperty("fields")) {
                    let vim: VirtualItemMaster = new VirtualItemMaster();
                    for (var key in resultItem.fields) {
                        var value: Array<any> = resultItem.fields[key];
                        vim[key] = value[0];
                    }
                    vimList.push(vim);
                }
            }

        } else {
            this.$log.debug("%s - Warning: No data returned", this.serviceName);
        }

        return vimList;
    }

    public setAbiCatalogItem(item) {
        // this.abiCatalogItem = new VirtualItemMaster(angular.copy(item));
        this.abiCatalogItem = new VirtualItemMaster();
        this.abiCatalogItem.enterpriseProductIdentifier = "enterpriseProductIdentifier";
        this.abiCatalogItem.clinicalDescription = "clinicalDescription";
        this.abiCatalogItem.shortItemDescription = item.shortItemDesc;
        this.abiCatalogItem.longItemDescription = "longItemDescription";
        this.abiCatalogItem.fullDescription = "fullDescription";
        this.abiCatalogItem.manufacturer = item.manufacturer;
        this.abiCatalogItem.manufacturerCatalogNumber = item.manufacturerSerialNumber;
        this.abiCatalogItem.ndc = "ndc";
        this.abiCatalogItem.ghxProductIdentifier = 0;
        this.abiCatalogItem.mmcProductIdentifier = 0;
        this.abiCatalogItem.commodityType = "commodityType";
        this.abiCatalogItem.productStatus = "productStatus";
        this.abiCatalogItem.recordStatus = "recordStatus";
        this.abiCatalogItem.unitOfUsePackageUnit = "unitOfUsePackageUnit";
        this.abiCatalogItem.unitOfUseUnit = "unitOfUseUnit";
        this.abiCatalogItem.unitOfUseQuantity = 0;
        this.abiCatalogItem.publishedDate = "publishedDate";
        this.abiCatalogItem.updatedDate = "updatedDate";

        let productIdentifier1: ItemIdentifier = {identifier: "id1", identifierType: "idType1"};
        let productIdentifier2: ItemIdentifier = {identifier: "id2", identifierType: "idType2"};
        let productIdentifier3: ItemIdentifier = {identifier: "id3", identifierType: "idType3"};
        let secondaryProductIdentifiers: Array<ItemIdentifier> = [productIdentifier1, productIdentifier2, productIdentifier3];
        this.abiCatalogItem.secondaryProductIdentifiers = secondaryProductIdentifiers;

        let otherPackageIdentifier1: ItemIdentifier = {identifier: "id1", identifierType: "idType1"};
        let otherPackageIdentifier2: ItemIdentifier = {identifier: "id2", identifierType: "idType2"};
        let otherPackageIdentifier3: ItemIdentifier = {identifier: "id3", identifierType: "idType3"};
        let otherPackageIdentifiers: Array<ItemIdentifier> = [otherPackageIdentifier1, otherPackageIdentifier2, otherPackageIdentifier3];

        let barcode1: BarcodeIdentifier = {barcode: "bc1", barcodeType: "bcType1"};
        let barcode2: BarcodeIdentifier = {barcode: "bc2", barcodeType: "bcType2"};
        let barcode3: BarcodeIdentifier = {barcode: "bc3", barcodeType: "bcType3"};
        let barcodes: Array<BarcodeIdentifier> = [barcode1, barcode2, barcode3];
        let package1: Package = {
                enterprisePackageIdentifier: "enterprisePackageIdentifier1",
                gtin: "gtin1",   // Global Trade Item Number
                niin: "niin1",   // National Item Identification Number
                nsn: "nsn1",   // National Stock Number
                otherPackageIdentifiers: otherPackageIdentifiers,
                packageUnit: "packageUnit1",
                packageQuantity: 1,
                gudidIdentifierType: "gudidIdentifierType1",
                barcodeData: barcodes
            };
        let package2: Package = {
            enterprisePackageIdentifier: "enterprisePackageIdentifier2",
            gtin: "gtin2",   // Global Trade Item Number
            niin: "niin2",   // National Item Identification Number
            nsn: "nsn2",   // National Stock Number
            otherPackageIdentifiers: otherPackageIdentifiers,
            packageUnit: "packageUnit2",
            packageQuantity: 2,
            gudidIdentifierType: "gudidIdentifierType2",
            barcodeData: barcodes
        };
        this.abiCatalogItem.packaging = [package1, package2];

        this.abiCatalogItem.unspscCode = 0;
        this.abiCatalogItem.unspscSegment = "unspscSegment";
        this.abiCatalogItem.unspscFamily = "unspscFamily";
        this.abiCatalogItem.unspscClass = "unspscClass";
        this.abiCatalogItem.unspscCommodity = "unspscCommodity";
        this.abiCatalogItem.hcpcsCode = "hcpcsCode";
        this.abiCatalogItem.hcpcsDescription = "hcpcsDescription";
        this.abiCatalogItem.hcpcsStatus = "hcpcsStatus";
        this.abiCatalogItem.productNoun = "productNoun";
        this.abiCatalogItem.productType = "productType";
        this.abiCatalogItem.age = "age";
        this.abiCatalogItem.gender = "gender";
        this.abiCatalogItem.sizeShape = "sizeShape";
        this.abiCatalogItem.color = "color";
        this.abiCatalogItem.flavor = "flavor";
        this.abiCatalogItem.fragrance = "fragrance";
        this.abiCatalogItem.sterileNonsterile = "sterileNonsterile";
        this.abiCatalogItem.hazardCode = "hazardCode";
        this.abiCatalogItem.latexCode = "latexCode";
        this.abiCatalogItem.disposableReusable = "disposableReusable";
        this.abiCatalogItem.productUrl = "productUrl";
        this.abiCatalogItem.preferredProductIdentifier = "preferredProductIdentifier";
        this.abiCatalogItem.diameter = "diameter";
        this.abiCatalogItem.volume = "volume";
        this.abiCatalogItem.weight = "weight";
        this.abiCatalogItem.lengthWidthHeight = "lengthWidthHeight";
        this.abiCatalogItem.lengthWidthHeight2 = "lengthWidthHeight2";
        this.abiCatalogItem.productComposition = ["productComposition1", "productComposition2"];
        this.abiCatalogItem.productProperties = ["productProperties1", "productProperties2"];
        this.abiCatalogItem.locations = ["locations1", "locations2"];
        this.abiCatalogItem.miscellaneous = ["miscellaneous1", "miscellaneous2"];
        this.abiCatalogItem.productImages = ["productImageUrl1", "productImageUrl2"];
        this.abiCatalogItem.trademarkBrandnames = ["trademarkBrandname1", "trademarkBrandname2"];
        this.abiCatalogItem.otherManufacturerNames = ["otherManufacturerName1", "otherManufacturerName2"];
        this.abiCatalogItem.brandGeneric = "brandGeneric";
        this.abiCatalogItem.deaCode = "deaCode";
        this.abiCatalogItem.dosageForm = "dosageForm";
        this.abiCatalogItem.drugCategory = "drugCategory";
        this.abiCatalogItem.drugStorageType = "drugStorageType";
        this.abiCatalogItem.drugStrength = "drugStrength";
        this.abiCatalogItem.drugUnit = "drugUnit";
        this.abiCatalogItem.genericId = 0;
        this.abiCatalogItem.genericName = "genericName";
        this.abiCatalogItem.offMarket = "offMarket";
        this.abiCatalogItem.spDrugCode = "spDrugCode";
        this.abiCatalogItem.ecriDeviceCode = "ecriDeviceCode";
        this.abiCatalogItem.ecriStandardizedProduct = "ecriStandardizedProduct";
        this.abiCatalogItem.ecriStandardizedCatalogNumber = "ecriStandardizedCatalogNumber";
        this.abiCatalogItem.ecriStandardizedManufacturer = "ecriStandardizedManufacturer";
        this.abiCatalogItem.ghxManufacturer = "ghxManufacturer";
        this.abiCatalogItem.scriptproManufacturer = "scriptproManufacturer";
    }

    public getSummaryEquipmentRecords(searchValue: string, userSpecifiedFilters: string, aggregationsRequest: string) {
        this.$log.debug("userSpecifiedFilters: %s", JSON.stringify(userSpecifiedFilters));
        this.$log.debug("aggregationsRequest: %s", JSON.stringify(aggregationsRequest));

        //Note: check to see if anything got sent through, otherwise a string 'undefined' will be sent to bt.
        let updatedSearchValue: string = (searchValue) ? searchValue : "";
        let updatedUserSpecifiedFilters: string = (userSpecifiedFilters) ? userSpecifiedFilters : "";

        if (updatedSearchValue === "" || updatedSearchValue === "*") {
            if (updatedUserSpecifiedFilters) {
                updatedSearchValue = updatedUserSpecifiedFilters;
            } else {
                updatedSearchValue = "(deleteInd:N) meAcqCostQty:[* TO 500]";
            }
        } else {
            updatedSearchValue = updatedSearchValue + " " + updatedUserSpecifiedFilters;
        }

        if (updatedSearchValue) {
            // encode URI/URL reserved characters
            updatedSearchValue = encodeURIComponent(updatedSearchValue);

            // pass a generic aggregations request to the BT
            let aggregations: string = encodeURIComponent(aggregationsRequest);

            let action: string = "getEquipmentRecordSearchResults?searchValue=" + updatedSearchValue + "&aggregations=" + aggregations;
            return this.get(action);
        } else {
            return null;
        }
    };

    public parseSummaryEquipmentRecordResults(results) {
        let equipmentRecordList: Array<EquipmentRecord> = [];
        if (results && results.data.hits.hits) {
            let equipmentRecordSearchResults = results.data.hits.hits;
            for (let i = 0; i < equipmentRecordSearchResults.length; i++) {
                this.processEquipmentRecordSearchResult(equipmentRecordSearchResults, i, equipmentRecordList);
            }
        } else {
            console.log('no data returned');
            this.$log.warn("%s - Warning: No data returned", this.serviceName);
        }
        return equipmentRecordList;
    }

    private processEquipmentRecordSearchResult(equipmentRecordSearchResults: any, i: number, equipmentRecordList: Array<EquipmentRecord>) {
        if (equipmentRecordSearchResults[i].hasOwnProperty("fields")) {

            let equipmentRecordSummary: EquipmentRecordSummary = new EquipmentRecordSummary();
            for (let key in equipmentRecordSearchResults[i].fields) {
                let value: Array<any> = equipmentRecordSearchResults[i].fields[key];
                equipmentRecordSummary[key] = value[0];
            }

            // console.log("summary equipmentRecord: %s", JSON.stringify(equipmentRecordSummary));

            // map from equipmentRecordSummary model which uses DMLSS legacy db names
            // to DML-ES friendly names
            let equipmentRecord: EquipmentRecord = new EquipmentRecord();
            equipmentRecord.meId = equipmentRecordSummary.meId;
            equipmentRecord.orgId = equipmentRecordSummary.orgId;
            equipmentRecord.ecn = equipmentRecordSummary.meECNId;
            equipmentRecord.itemId = equipmentRecordSummary.itemId;
            equipmentRecord.shortItemDesc = equipmentRecordSummary.itemDesc;
            equipmentRecord.equipmentStatus = (equipmentRecordSummary.deleteInd === 'N') ? 'Active' : 'Inactive"';
            equipmentRecord.deviceClass = equipmentRecordSummary.deviceClsText;
            equipmentRecord.nomenclature = equipmentRecordSummary.deviceText;
            equipmentRecord.manufacturer = equipmentRecordSummary.manufOrgName;
            equipmentRecord.commonModel = equipmentRecordSummary.manufMdlComnId;
            //equipmentRecord.nameplateModel = equipmentRecordSummary.tbd;
            equipmentRecord.manufacturerSerialNumber = equipmentRecordSummary.meMFGSerialId;
            equipmentRecord.customerId = equipmentRecordSummary.custOrgId;
            equipmentRecord.customerName = equipmentRecordSummary.custOrgNM;
            equipmentRecord.custodianName = equipmentRecordSummary.custodianName;
            equipmentRecord.equipmentLocation = "/src/content/images/imageNotAvailable.jpg";
            equipmentRecord.ownership = equipmentRecordSummary.eqptOwnershipDesc;
            equipmentRecord.assemblageDescription = equipmentRecordSummary.assmDescrDetail;
            equipmentRecord.assemblageNumber = equipmentRecordSummary.assmNumDetail;
            equipmentRecord.acquisitionCost = equipmentRecordSummary.meAcqCostQty;

            let acquisitionDate = equipmentRecordSummary.meAcqDt;
            equipmentRecord.acquisitionDate = (acquisitionDate) ? new Date(acquisitionDate.toString()) : null;

            equipmentRecord.maintenanceActivity = equipmentRecordSummary.maOrgNm;
            equipmentRecord.scheduledTeam = equipmentRecordSummary.schedTeamName;
            equipmentRecord.unscheduledTeam = equipmentRecordSummary.unschedTeamName;
            //equipmentRecord.contractor = equipmentRecordSummary.tbd;
            equipmentRecord.isAccountableEquipment = (equipmentRecordSummary.eiAccntblCd === "Y");
            equipmentRecord.isMaintenanceRequired = (equipmentRecordSummary.eiMaintReqrCd === "Y");
            equipmentRecordList.push(equipmentRecord);
        }
        return null;
    }

    public parseSummaryEquipmentRecordAggregations(results) {
        let equipmentRecordAggregations: any = {};

        if (results && results.data.aggregations) {
            equipmentRecordAggregations = results.data.aggregations;
        } else {
            this.$log.warn("%s - Warning: No aggregations returned", this.serviceName);
        }

        return equipmentRecordAggregations;
    }

    // this will actually be a call that uses API service to retrieve all UNSPSC Segments from BT
    // prior to doing any searches and uses that info to build proper optionValue array
    //
    public getUnspscSegments(): Array<CategoryOption> {
        return [
            {optionValue: "segment1", isSelected: false, level: 0},
            {optionValue: "segment2", isSelected: false, level: 0},
            {optionValue: "segment3", isSelected: false, level: 0}
        ];
    }
}