'use strict';

import {BaseFacetService} from "../_directives/Facet/baseFacet.service";
import {FacetConfiguration} from "../_models/facetConfiguration.model";
import {SearchConstants} from "../_constants/search.constants";

export class Facet extends BaseFacetService {

    // this module (for event purposes)
    public eventModule: string = SearchConstants.EVENT_MODULE_ABI_CATALOG;

    // @ngInject
    constructor($log, $rootScope, facetConfiguration: FacetConfiguration, SearchUtilService, SelectedFacetOptionsBreadboxService) {
        super($log, $rootScope, facetConfiguration, SearchUtilService, SelectedFacetOptionsBreadboxService);

        this.init();
    }

}