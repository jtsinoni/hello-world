'use strict';

import {BaseCategoryService} from "../_directives/Category/baseCategory.service";
import {CategoryConfiguration} from "../_models/categoryConfiguration.model";
import {SearchConstants} from "../_constants/search.constants";

export class Category extends BaseCategoryService {

    // this module (for event purposes)
    public eventModule: string = SearchConstants.EVENT_MODULE_ABI_CATALOG;

    // @ngInject
    constructor($log, $rootScope, categoryConfiguration: CategoryConfiguration, SearchUtilService) {
        super($log, $rootScope, categoryConfiguration, SearchUtilService);

        this.init();
    }
}