'use strict';

import {Facet} from "./facet.service";
import {FacetConfiguration} from "../_models/facetConfiguration.model";

export class FacetsService {

    public facets: Array<any> = [];

    // @ngInject
    constructor($log, $rootScope, private SearchUtilService, private SelectedFacetOptionsBreadboxService) {
        // new Facet(displayLabel, aggregationIdentifier, elasticSearchFieldName)
        let manufacturerFacetConfiguration: FacetConfiguration = {
            displayLabel: "Manufacturer",
            aggregationIdentifier: "manufacturers",
            elasticSearchFieldName: "manufOrgName",
            initializeAsCollapsed: false
        };
        this.facets.push(new Facet($log, $rootScope, manufacturerFacetConfiguration, SearchUtilService, SelectedFacetOptionsBreadboxService));

        let nomenclatureFacetConfiguration: FacetConfiguration = {
            displayLabel: "Nomenclature",
            aggregationIdentifier: "nomenclatures",
            elasticSearchFieldName: "deviceText",
            initializeAsCollapsed: false
        };
        this.facets.push(new Facet($log, $rootScope, nomenclatureFacetConfiguration, SearchUtilService, SelectedFacetOptionsBreadboxService));

        let commonModelFacetConfiguration: FacetConfiguration = {
            displayLabel: "Common Model",
            aggregationIdentifier: "commonModels",
            elasticSearchFieldName: "manufMdlComnId",
            initializeAsCollapsed: true
        };
        this.facets.push(new Facet($log, $rootScope, commonModelFacetConfiguration, SearchUtilService, SelectedFacetOptionsBreadboxService));
    }

    public getFacets(): Array<any> {
        return this.facets;
    }
}