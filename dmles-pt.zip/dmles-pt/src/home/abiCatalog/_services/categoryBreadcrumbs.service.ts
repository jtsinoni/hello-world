'use strict';

import {CategoryOption} from "../_models/categoryOption.model";
import {CategoryBreadcrumb} from "./categoryBreadcrumb.service";

export class CategoryBreadcrumbsService {

    public categoryBreadcrumbs: Array<any> = [];

    // @ngInject
    constructor(private $log, private $rootScope, private SearchUtilService) {

        let displayLabel: string = "UNSPSC Taxonomy";       
        this.categoryBreadcrumbs.push(new CategoryBreadcrumb($log, $rootScope, displayLabel, SearchUtilService));
    }

    public getCategoryBreadcrumbs(): Array<CategoryOption> {
        return this.categoryBreadcrumbs;
    }
}