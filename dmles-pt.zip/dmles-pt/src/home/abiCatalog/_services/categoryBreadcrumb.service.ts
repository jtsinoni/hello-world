'use strict';

import {CategoryConfiguration} from "../_models/categoryConfiguration.model";
import {SearchConstants} from "../_constants/search.constants";
import {BaseCategoryBreadcrumbService} from "../_directives/CategoryBreadcrumb/baseCategoryBreadcrumb.service";

export class CategoryBreadcrumb extends BaseCategoryBreadcrumbService {

    // this module (for event purposes)
    public eventModule: string = SearchConstants.EVENT_MODULE_ABI_CATALOG;

    // @ngInject
    constructor($log, $rootScope, displayLabel: string, SearchUtilService) {
        super($log, $rootScope, displayLabel, SearchUtilService);

        this.init();
    }
}