'use strict';

export class DashboardShellController {
    viewName: string;

    // @ngInject
    constructor() {
        this.init();
    }

    init(){
        this.viewName = 'DashboardShellController View';
    }
}