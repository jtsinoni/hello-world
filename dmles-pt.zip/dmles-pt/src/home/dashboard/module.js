define(["require", "exports", './router', './dashboardShell.controller', './_services/module', './_views/module'], function (require, exports, router_1, dashboardShell_controller_1, module_1, module_2) {
    'use strict';
    var module = angular.module('Dmles.Home.DashboardModule', [
        module_2.default.name,
        module_1.default.name,
    ]);
    module.controller('Dmles.Home.Dashboard.DashboardShellController', dashboardShell_controller_1.DashboardShellController);
    module.config(router_1.default.factory);
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = module;
});
//# sourceMappingURL=module.js.map