'use strict';

class Router {
    static instance:any;

    // @ngInject
    constructor($stateProvider, $urlRouterProvider, StateConstants) {

        $stateProvider
        .state(StateConstants.MY_DASHBOARD, {
            url: '/myDashboard',
            templateUrl: '/src/home/dashboard/_views/myDashboard.html',
            controller: 'MyDashboardController',
            controllerAs: 'vm',
            data: {
                displayName: 'My Dashboard'
            }
        });

    }

    static factory($stateProvider, $urlRouterProvider, StateConstants) {
        Router.instance = new Router($stateProvider, $urlRouterProvider, StateConstants);
        return Router.instance;
    }
}

Router.factory.$inject = ['$stateProvider', '$urlRouterProvider', 'StateConstants'];

export default Router;