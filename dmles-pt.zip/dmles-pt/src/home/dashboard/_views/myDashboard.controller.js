define(["require", "exports"], function (require, exports) {
    'use strict';
    var MyDashboardController = (function () {
        // @ngInject
        function MyDashboardController(DashboardService, PermissionService, ResourceConstants, StateConstants) {
            this.DashboardService = DashboardService;
            this.PermissionService = PermissionService;
            this.ResourceConstants = ResourceConstants;
            this.StateConstants = StateConstants;
            this.init();
        }
        MyDashboardController.prototype.init = function () {
            if (this.PermissionService.checkElements(this.ResourceConstants.USER_PROFILE_MANAGEMENT)) {
                this.DashboardService.getPendingUsers();
            }
        };
        return MyDashboardController;
    }());
    exports.MyDashboardController = MyDashboardController;
});
//# sourceMappingURL=myDashboard.controller.js.map