define(["require", "exports", './myDashboard.controller'], function (require, exports, myDashboard_controller_1) {
    'use strict';
    var controllersModule = angular.module('Dmles.Home.Dashboard.Views.Module', []);
    controllersModule.controller('MyDashboardController', myDashboard_controller_1.MyDashboardController);
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = controllersModule;
});
//# sourceMappingURL=module.js.map