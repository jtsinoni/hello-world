'use strict';

export class MyDashboardController {

    // @ngInject
    constructor(private DashboardService, private PermissionService, private ResourceConstants, private StateConstants) {
        this.init();
    }

    private init(){
        if(this.PermissionService.checkElements(this.ResourceConstants.USER_PROFILE_MANAGEMENT)){
            this.DashboardService.getPendingUsers();
        }
    }

}