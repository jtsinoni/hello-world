export class MyDashboardController {
    private controllerName:String = "Dashboard Controller";

    // @ngInject
    constructor(private $log, private DashboardService, private PermissionService, private ResourceConstants, public StateConstants) {
        this.$log.info("%s - Started", this.controllerName);
        this.init();
    }

    private init(){
        if(this.PermissionService.checkElements(this.ResourceConstants.USER_PROFILE_MANAGEMENT)){
            this.DashboardService.getUserDashboardStats();
        }

        if(this.PermissionService.checkElements(this.ResourceConstants.EQUIP_REQUESTS_MY_REQUESTS)){
            this.DashboardService.getEquipmentRequestCounts();
        }
    }

}