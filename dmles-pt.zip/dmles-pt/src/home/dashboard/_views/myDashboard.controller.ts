import {DmlesTreeData} from "../../../_directives/tree/dmlesTreeData.model";

export class MyDashboardController {

    public dataList:Array<DmlesTreeData> = [];

    public treeData:any;
    public selectedNode:DmlesTreeData = new DmlesTreeData();
    public preLookup:string;

    //public treeType:string = "tree-logical";
    //public treeType:string = "tree-boot";
    //public treeType:string = "tree-classic";

    // @ngInject
    constructor(private $log, private DashboardService, private PermissionService, private ResourceConstants, public StateConstants) {
        this.init();
    }

    private init(){
        if(this.PermissionService.checkElements(this.ResourceConstants.USER_PROFILE_MANAGEMENT)){
            this.DashboardService.getUserDashboardStats();
        }
        if(this.PermissionService.checkElements(this.ResourceConstants.EQUIP_REQUESTS_MY_REQUESTS)){
            this.DashboardService.getEquipmentRequestCounts();
        }

        this.buildTree();
    }

    private buildTree(){

        this.treeData =
            [
                { "id" : "10000", "value" : "DoD", "description" : "Department of Defense", "type" : "", "children" : [
                    { "id" : "10003", "value" : "Air Force", "description" : "Test", type: "", "children" : [] },
                    { "id" : "10001", "value" : "Army", "description" : "", "type" : "", "children" : [
                        { "id" : "10016", "value" : "USAMRMC - Army Med Research & Materiel Com", "description" : "", "type" : "", "children" : [
                            { "id" : "W560HT", "value" : "W560HT - USAMRIID, Ft Detrick, MD", "description" : "", "type" : "home", "children" : [] },
                            { "id" : "W560HV", "value" : "W560HV - Medical Materiel Development Activity", "description" : "", "type" : "", "children" : [] }
                        ]}
                    ]},
                    { "id" : "10002", "value" : "Navy", "description" : "", type: "", "children" : [] },
                    { "id" : "10006", "value" : "DHA", "description" : "Defense Health Agency", "type" : "", "children" : [] }
                ]},
                { "id" : "11111", "value" : "VA", "description" : "Veteran Affairs", "type" : "", "children" : [] }
            ];

        this.selectedNode = angular.copy(this.treeData[0].children[1].children[0].children[0]);

        this.preLookup = this.selectedNode.value;
    }

    public showSelected(node){
        this.$log.info(node);
        this.selectedNode = node;
    }

}