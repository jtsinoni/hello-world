'use strict';

import {MyDashboardController} from './myDashboard.controller';

var controllersModule = angular.module('Dmles.Home.Dashboard.Views.Module', []);
controllersModule.controller('MyDashboardController', MyDashboardController);

export default controllersModule;