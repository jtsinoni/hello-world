'use strict';

import router from './router';
import {DashboardShellController} from './dashboardShell.controller';

// modules
//import modelsModule from './_models/module';
import servicesModule from './_services/module';
import controllersModule from './_views/module';

var module = angular.module('Dmles.Home.DashboardModule', [
	controllersModule.name,
	servicesModule.name,
]);

module.controller('Dmles.Home.Dashboard.DashboardShellController', DashboardShellController);
module.config(router.factory);

export default module;