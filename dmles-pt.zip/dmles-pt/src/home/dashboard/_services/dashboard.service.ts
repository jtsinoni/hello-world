import {ApiService} from "../../../_services/api.service";

export class DashboardService extends ApiService {
    private serviceName:string = "Dashboard Service";

    public pendingUsers:number = 0;
    public activeUsers:number = 0;
    public inactiveUsers:number = 0;
    public lockedUsers:number = 0;
    public suspendedUsers:number = 0;
    public retiredUsers:number = 0;
    public activeEquipmentRequests:number = 0;
    public newEquipmentRequests:number = 0;
    public pendingEquipmentRequests:number = 0;

    // @ngInject
    constructor($http, $log, Authentication, $httpParamSerializerJQLike, private NotificationService) {
        super($http, $log, Authentication, $httpParamSerializerJQLike, "User");
        this.$log.debug("%s - Start", this.serviceName);
    }

    public getPendingUsers() {
        return this.get("getNumberOfPendingUserProfiles").then((response: any) => {
            this.pendingUsers = response.data;
        }, (errResponse: any) => {
            this.$log.error("Error retrieving number of pending users");
            this.NotificationService.errorMsg("Unable to retrieve number of pending users");
        });
    }

    public getUserDashboardStats() {
        return this.get("getUserDashboardStats").then((response: any) => {
            this.pendingUsers = response.data.pendingUsers;
            this.activeUsers = response.data.activeUsers;
            this.inactiveUsers = response.data.inactiveUsers;
            this.lockedUsers = response.data.lockedUsers;
            this.suspendedUsers = response.data.suspendedUsers;
            this.retiredUsers = response.data.retiredUsers;
        }, (errResponse: any) => {
            this.$log.error("Error retrieving user dashboard statistics");
            this.NotificationService.errorMsg("Unable to retrieve user dashboard statistics");
        });
    }

    public getEquipmentRequestCounts() {
        return this.get("getEquipmentRequestDashBoard", "EquipmentManagement").then((response: any) => {
            this.activeEquipmentRequests = response.data.activeRequests;
            this.newEquipmentRequests = response.data.newRequests;
            this.pendingEquipmentRequests = response.data.pendingActions;
        }, (errResponse: any) => {
            this.$log.error("Error retrieving number of active, new, pending equipment requests");
            this.NotificationService.errorMsg("Unable to retrieve equipment request statistics");
        });
    }

}