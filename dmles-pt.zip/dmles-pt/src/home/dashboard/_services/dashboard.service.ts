import {ApiService} from "../../../_services/api.service";

export class DashboardService extends ApiService {
    private serviceName:string = "Dashboard Service";

    public pendingUsers:number = 0;

    // @ngInject
    constructor($http, $log, Authentication, App, $httpParamSerializerJQLike, private NotificationService) {
        super($http, $log, Authentication, App, $httpParamSerializerJQLike, "User");
        this.$log.debug("%s - Start", this.serviceName);
    }

    public getPendingUsers() {
        return this.get("getNumberOfPendingUserProfiles").then((response: any) => {
            this.pendingUsers = response.data;
        }, (errResponse: any) => {
            this.$log.error("Error retrieving number of pending users");
            this.NotificationService.errorMsg("Unable to retrieve number of pending users");
        });
    }

}