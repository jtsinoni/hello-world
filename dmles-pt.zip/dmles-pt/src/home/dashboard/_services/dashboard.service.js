var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", "../../../_services/api.service"], function (require, exports, api_service_1) {
    "use strict";
    var DashboardService = (function (_super) {
        __extends(DashboardService, _super);
        // @ngInject
        function DashboardService($http, $log, Authentication, App, $httpParamSerializerJQLike, NotificationService) {
            _super.call(this, $http, $log, Authentication, App, $httpParamSerializerJQLike, "User");
            this.NotificationService = NotificationService;
            this.serviceName = "Dashboard Service";
            this.pendingUsers = 0;
            this.$log.debug("%s - Start", this.serviceName);
        }
        DashboardService.prototype.getPendingUsers = function () {
            var _this = this;
            return this.get("getNumberOfPendingUserProfiles").then(function (response) {
                _this.pendingUsers = response.data;
            }, function (errResponse) {
                _this.$log.error("Error retrieving number of pending users");
                _this.NotificationService.errorMsg("Unable to retrieve number of pending users");
            });
        };
        return DashboardService;
    }(api_service_1.ApiService));
    exports.DashboardService = DashboardService;
});
//# sourceMappingURL=dashboard.service.js.map