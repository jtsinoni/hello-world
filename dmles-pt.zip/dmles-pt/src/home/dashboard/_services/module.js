define(["require", "exports", './dashboard.service'], function (require, exports, dashboard_service_1) {
    'use strict';
    var modelsModule = angular.module('Dmles.Home.Dashboard.Module', []);
    modelsModule.service('DashboardService', dashboard_service_1.DashboardService);
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = modelsModule;
});
//# sourceMappingURL=module.js.map