'use strict';

import {DashboardService} from './dashboard.service';

var modelsModule = angular.module('Dmles.Home.Dashboard.Module', []);
modelsModule.service('DashboardService', DashboardService);

export default modelsModule;