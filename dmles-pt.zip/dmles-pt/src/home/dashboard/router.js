define(["require", "exports"], function (require, exports) {
    'use strict';
    var Router = (function () {
        // @ngInject
        function Router($stateProvider, $urlRouterProvider, StateConstants) {
            $stateProvider
                .state(StateConstants.MY_DASHBOARD, {
                url: '/myDashboard',
                templateUrl: '/src/home/dashboard/_views/myDashboard.html',
                controller: 'MyDashboardController',
                controllerAs: 'vm',
                data: {
                    displayName: 'My Dashboard'
                }
            });
        }
        Router.factory = function ($stateProvider, $urlRouterProvider, StateConstants) {
            Router.instance = new Router($stateProvider, $urlRouterProvider, StateConstants);
            return Router.instance;
        };
        return Router;
    }());
    Router.factory.$inject = ['$stateProvider', '$urlRouterProvider', 'StateConstants'];
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = Router;
});
//# sourceMappingURL=router.js.map