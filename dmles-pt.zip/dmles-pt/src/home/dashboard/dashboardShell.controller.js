define(["require", "exports"], function (require, exports) {
    'use strict';
    var DashboardShellController = (function () {
        // @ngInject
        function DashboardShellController() {
            this.init();
        }
        DashboardShellController.prototype.init = function () {
            this.viewName = 'DashboardShellController View';
        };
        return DashboardShellController;
    }());
    exports.DashboardShellController = DashboardShellController;
});
//# sourceMappingURL=dashboardShell.controller.js.map