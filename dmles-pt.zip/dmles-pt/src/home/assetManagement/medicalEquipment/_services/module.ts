import {MedicalEquipmentService} from './medicalEquipment.service';

var module = angular.module('Dmles.Home.AssetManagement.MedicalEquipment.Services.Module', []);
module.service('MedicalEquipmentService', MedicalEquipmentService);

export default module;