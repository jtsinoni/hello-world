import modelsModule from './_models/module';
import servicesModule from './_services/module';
import viewsModule from './_views/module'

var module = angular.module('Dmles.Home.AssetManagement.MedicalEquipment.Module', [
    modelsModule.name,
    servicesModule.name,
    viewsModule.name
]);

export default module;