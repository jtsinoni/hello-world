class Router {
    static instance:any;

    // @ngInject
    constructor($stateProvider, $urlRouterProvider, StateConstants) {

        $stateProvider
            .state(StateConstants.ASSET_MANAGEMENT_MEDICAL_EQUIPMENT, {
                url: '/medicalEquipment',
                templateUrl: '/src/home/assetManagement/medicalEquipment/_views/medicalEquipment.html',
                controller: 'MedicalEquipmentController',
                controllerAs: 'vm',
                data: {
                    displayName: 'Medical Equipments'
                }
            });
    }

    static factory($stateProvider, $urlRouterProvider, StateConstants) {
        Router.instance = new Router($stateProvider, $urlRouterProvider, StateConstants);
        return Router.instance;
    }
}

Router.factory.$inject = ['$stateProvider', '$urlRouterProvider', 'StateConstants'];

export default Router;