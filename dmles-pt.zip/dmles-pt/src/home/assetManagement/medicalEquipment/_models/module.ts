import {Example} from './example.model';

var modelsModule = angular.module('Dmles.Home.AssetManagement.MedicalEquipment.Models.Module', []);
modelsModule.value('Example', Example);

export default modelsModule;