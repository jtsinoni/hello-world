import {MedicalEquipmentController} from './medicalEquipment.controller';

var module = angular.module('Dmles.Home.AssetManagement.MedicalEquipment.Views.Module', []);
module.controller('MedicalEquipmentController', MedicalEquipmentController);

export default module;