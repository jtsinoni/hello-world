export class AssetManagementShellController {
    private controllerName:string = "Asset Shell Controller";

    // @ngInject
    constructor(private $log) {
        this.$log.debug('%s - Start', this.controllerName);
    }

}
