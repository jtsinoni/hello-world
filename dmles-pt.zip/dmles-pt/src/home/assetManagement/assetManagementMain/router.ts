class Router {
    static instance:any;

    // @ngInject
    constructor($stateProvider, $urlRouterProvider, StateConstants) {

        $stateProvider
            .state(StateConstants.ASSET_MANAGEMENT_MAIN, {
                url: '/assetManagementMain',
                templateUrl: '/src/home/assetManagement/assetManagementMain/_views/assetManagement.html',
                controller: 'AssetManagementController',
                controllerAs: 'vm',
                data: {
                    displayName: 'Asset Management'
                }
            });
    }

    static factory($stateProvider, $urlRouterProvider, StateConstants) {
        Router.instance = new Router($stateProvider, $urlRouterProvider, StateConstants);
        return Router.instance;
    }
}

Router.factory.$inject = ['$stateProvider', '$urlRouterProvider', 'StateConstants'];

export default Router;