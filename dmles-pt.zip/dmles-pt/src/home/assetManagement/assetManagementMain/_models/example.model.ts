export class Example {
    public barcode: string = "";

    constructor();
    constructor(obj: Example);
    constructor(obj?: any) {
        this.barcode = obj && obj.barcode || "";
    };
}