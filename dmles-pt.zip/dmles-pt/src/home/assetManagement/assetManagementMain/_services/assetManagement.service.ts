export class AssetManagementService {
    private serviceName = 'Asset Management Service';

    constructor(private $log) {
        this.$log.info("%s - Started", this.serviceName);
    }

    private stubA(x : string): string {
        return null;
    }

    public stubB(): void {
        // stub
    }

}