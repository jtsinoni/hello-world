import {AssetManagementService} from './assetManagement.service';

var module = angular.module('Dmles.Home.AssetManagement.AssetManagementMain.Services.Module', []);
module.service('AssetManagementService', AssetManagementService);

export default module;