import {AssetManagementController} from './assetManagement.controller';

var module = angular.module('Dmles.Home.AssetManagement.AssetManagementMain.Views.Module', []);
module.controller('AssetManagementController', AssetManagementController);

export default module;