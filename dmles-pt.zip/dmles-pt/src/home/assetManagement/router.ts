class Router {
    static instance:any;

    // @ngInject
    constructor($stateProvider, $urlRouterProvider, StateConstants) {

        $stateProvider
            .state(StateConstants.ASSET_MANAGEMENT_SHELL, {
                url: '/assetManagement',
                templateUrl: '/src/home/assetManagement/assetManagementShell.html',
                controller: 'AssetManagementShellController',
                controllerAs: 'vm',
                abstract: true
            });

    }

    static factory($stateProvider, $urlRouterProvider, StateConstants) {
        Router.instance = new Router($stateProvider, $urlRouterProvider, StateConstants);
        return Router.instance;
    }
}

Router.factory.$inject = ['$stateProvider', '$urlRouterProvider', 'StateConstants'];

export default Router;