import assetManagementRouter from './router';
import assetManagementMainRouter from './assetManagementMain/router';
import medicalEquipmentRouter from './medicalEquipment/router';
import realPropertyInstalledRouter from './realPropertyInstalled/router';

import assetManagementMainModule from './assetManagementMain/module';
import medicalEquipmentModule from './medicalEquipment/module';
import realPropertyInstalledModule from './realPropertyInstalled/module';

import {AssetManagementShellController} from './assetManagementShell.controller';

var module = angular.module('Dmles.Home.AssetManagement.Module', [
    assetManagementMainModule.name,
    medicalEquipmentModule.name,
    realPropertyInstalledModule.name
]);

module.controller('AssetManagementShellController', AssetManagementShellController);
module.config(assetManagementRouter.factory);
module.config(assetManagementMainRouter.factory);
module.config(medicalEquipmentRouter.factory);
module.config(realPropertyInstalledRouter.factory);

export default module;
