class Router {
    static instance:any;

    // @ngInject
    constructor($stateProvider, $urlRouterProvider, StateConstants) {

        $stateProvider
            .state(StateConstants.ASSET_MANAGEMENT_REAL_PROPERTY_INSTALLED, {
                url: '/realPropertyInstalled',
                templateUrl: '/src/home/assetManagement/realPropertyInstalled/_views/realPropertyInstalled.html',
                controller: 'RealPropertyInstalledController',
                controllerAs: 'vm',
                data: {
                    displayName: 'Real Property Installed Equipments'
                }
            });
    }

    static factory($stateProvider, $urlRouterProvider, StateConstants) {
        Router.instance = new Router($stateProvider, $urlRouterProvider, StateConstants);
        return Router.instance;
    }
}

Router.factory.$inject = ['$stateProvider', '$urlRouterProvider', 'StateConstants'];

export default Router;