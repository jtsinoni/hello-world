import {RealPropertyInstalledService} from './realPropertyInstalled.service';

var module = angular.module('Dmles.Home.AssetManagement.RealPropertyInstalled.Services.Module', []);
module.service('RealPropertyInstalledService', RealPropertyInstalledService);

export default module;