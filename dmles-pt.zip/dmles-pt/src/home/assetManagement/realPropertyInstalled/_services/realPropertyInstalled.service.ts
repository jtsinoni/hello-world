export class RealPropertyInstalledService {
    private serviceName = 'Real Property Installed Service';

    constructor(private $log) {
        this.$log.info("%s - Started", this.serviceName);
    }

    private stubA(x : string): string {
        return null;
    }

    public stubB(): void {
        // stub
    }

}