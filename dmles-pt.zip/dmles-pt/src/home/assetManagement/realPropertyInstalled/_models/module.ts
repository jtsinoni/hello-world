import {Example} from './example.model';

var modelsModule = angular.module('Dmles.Home.AssetManagement.RealPropertyInstalled.Models.Module', []);
modelsModule.value('Example', Example);

export default modelsModule;