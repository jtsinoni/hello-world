import {RealPropertyInstalledController} from './realPropertyInstalled.controller';

var module = angular.module('Dmles.Home.AssetManagement.RealPropertyInstalled.Views.Module', []);
module.controller('RealPropertyInstalledController', RealPropertyInstalledController);

export default module;