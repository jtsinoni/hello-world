export class RealPropertyInstalledController {
    private controllerName = ' Real Property Installed Controller';

    // @ngInject
    constructor(private $log) {
        this.$log.info("%s - Started", this.controllerName);
        this.init();
    }

    private init(){
        // Stub
    }

    private stubA(x : string): string {
        // Stub
        return null;
    }

    public stubB(): void {
        // stub
    }
}