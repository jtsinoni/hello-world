'use strict';

import router from './router';
import servicesModule from './_services/module';
import {JmarShellController} from './jmarShell.controller';

var module = angular.module('Dmles.JmarModule', [
    servicesModule.name
]);

module.controller('Dmles.Home.Jmar.JmarShellController', JmarShellController);
module.config(router.factory);

export default module;