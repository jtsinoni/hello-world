'use strict;'

import {ApiService} from "../../../_services/api.service";

export interface IJmarSiteCatalogService {

}

export class JmarSiteCatalogService extends ApiService implements IJmarSiteCatalogService {
    private serviceName = "JmarSiteCatalogService";
    public itemFromCatalog:any = null;


    // @ngInject
    constructor($http, $log, Authentication, App, $httpParamSerializerJQLike, private UtilService) {
        super($http, $log, Authentication, App, $httpParamSerializerJQLike, "EquipmentManagement");
        this.$log.debug("%s - Start", this.serviceName);
    }

    public getJmarSiteCatalogItems(searchData:string, userSpecifiedFilters:string) {
        this.$log.debug("%s - userSpecifiedFilters: %s", this.serviceName, JSON.stringify(userSpecifiedFilters));
        var searchValue:string = "";

        if (!searchData || searchData === "*") {
            searchValue = userSpecifiedFilters;
        } else {
            searchValue = searchData + " " + userSpecifiedFilters;
        }

        // escape special characters
        searchValue = this.UtilService.esEscapeSpecialChars(searchValue);
        // encode URI/URL reserved characters
        searchValue = encodeURIComponent(searchValue);
        return this.get("getJmarSearchResults?searchValue=" + searchValue);

    };

    public getSearchStats(result) {
        var retVal = {
            "total": 0,
            "time": 0.00
        };

        if (result && result.data && result.data.hits) {
            if (result.data.hits.total) {
                retVal.total = result.data.hits.total;
            }

            if (result.data.took) {
                retVal.time = result.data.took;
            }
        }
        else {
            this.$log.warn("%s - Warning: No data returned", this.serviceName);
        }
        return retVal;
    }


    public parseJmarSiteCatalogResults(results) {
        //this.$log.debug("results: %s", JSON.stringify(results));
        var jmarSiteCatalogList:Array<any> = [];
        if (results && results.data.hits.hits) {
            var jmarSiteCatalogSearchResults = results.data.hits.hits;
            for (var i in jmarSiteCatalogSearchResults) {
                var resultItem = jmarSiteCatalogSearchResults[i];
                if (resultItem.hasOwnProperty("fields")) {
                    var jmarSiteCatalogItem:any = {};
                    for (var key in resultItem.fields) {
                        var value:Array<any> = resultItem.fields[key];
                        jmarSiteCatalogItem[key] = value[0];
                    }
                    // this.$log.debug("jmarSiteCatalogItem: %s", JSON.stringify(jmarSiteCatalogItem));
                    jmarSiteCatalogList.push(jmarSiteCatalogItem);
                }
            }
        } else {
            this.$log.warn("%s - Warning: No data returned", this.serviceName);
        }

        //this.$log.debug("jmarSiteCatalogList: %s", JSON.stringify(jmarSiteCatalogList));
        return jmarSiteCatalogList;
    }
}