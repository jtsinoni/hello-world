'use strict';

import {JmarSiteCatalogService} from './jmarSiteCatalogService.service';

var servicesModule = angular.module('Dmles.Jmar.Services.Module', []);
servicesModule.service('JmarSiteCatalogService', JmarSiteCatalogService);


export default servicesModule;

