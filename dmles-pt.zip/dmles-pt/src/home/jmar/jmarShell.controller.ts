'use strict';

import {User} from '../../_models/user.model';

export class JmarShellController {
    private controllerName:string = "Jmar Shell Controller";
    private errorMsg:string = null;
    private jmarSiteCatalogSearchResults:Array<any> = [];
    private searchStats:any = {};
    private jmarSiteCatalogSearchStats:string = "";
    private currentUser:User = new User();
    private isLoadingSearch:boolean = false;
    private ngJmarSiteCatalogTable:any = null;
    private numberOfRowsToDisplay:number = 25;
    private sortOrder:string = "mainOrgId";
    private displayOptions:any = [{label: 'Table', val: true}, {label: 'Cards', val: false}];
    private displayAsTable:boolean = this.displayOptions[0];

    // search directive
    private searchInput:string = "";
    private searchPlaceholder:string = "JMAR Site Catalog Search ...";
    private userSpecifiedFilters:string = "";

    public searchMaxResultsText:string;
    public showMaxResultsWarning:boolean;

    // @ngInject
    constructor(private $log, private ContentConstants, private datatableService, private JmarSiteCatalogService,
                private UserService, private UtilService) {
        this.$log.debug("%s - Start", this.controllerName);

        this.currentUser = this.UserService.currentUser;
        this.searchMaxResultsText = "Over " + this.ContentConstants.SEARCH_MAX + " items has been found, please refine your search";
    }

    private getJmarSiteCatalogItems() {
        this.isLoadingSearch = true;
        this.jmarSiteCatalogSearchStats = "";
        this.errorMsg = null; //reset errorMsg

        if(this.searchInput || this.userSpecifiedFilters){
            // Some search criteria has been given, proceed with search
            this.JmarSiteCatalogService.getJmarSiteCatalogItems(this.searchInput, this.userSpecifiedFilters).then((response) => {
                this.jmarSiteCatalogSearchResults = this.JmarSiteCatalogService.parseJmarSiteCatalogResults(response);
                this.searchStats = this.JmarSiteCatalogService.getSearchStats(response);

                this.ngJmarSiteCatalogTable = this.datatableService.createNgTable(this.jmarSiteCatalogSearchResults, this.numberOfRowsToDisplay, {mainOrgId: 'asc'});

                this.jmarSiteCatalogSearchStats = this.UtilService.esBuildSearchStatsStr(this.searchStats.total, this.searchStats.time);
                if (this.ContentConstants.SEARCH_MAX <= this.searchStats.total) {
                    this.showMaxResultsWarning = true;
                }

                this.isLoadingSearch = false;
            }, (errResponse) => {
                this.isLoadingSearch = false;
                this.errorMsg = "Something went wrong. Please try again later.";
                this.$log.debug("%s - Error getting equipment records from elastic: %s", this.controllerName);
            });
        } else {
            // We do not want to search all of JMAR when there is no search criteria
            this.isLoadingSearch = false;
            this.errorMsg = "Please enter search criteria...";
        }
    }

    // used by <search-input> directive
    public executeSearch() {
        this.$log.debug("%s - executeSearch: %s", this.controllerName, this.searchInput);
        this.getJmarSiteCatalogItems();
    }
}