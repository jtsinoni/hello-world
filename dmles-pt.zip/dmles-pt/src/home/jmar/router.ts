'use strict;'

class Router {
    static instance:any;

    // @ngInject
    constructor($stateProvider, $urlRouterProvider, StateConstants) {
        // For any unmatched url, redirect to /home
        $stateProvider
            .state(StateConstants.JMAR_SHELL, {
                url: '/jmar',
                templateUrl: '/src/home/jmar/jmarShell.html',
                controller: 'Dmles.Home.Jmar.JmarShellController',
                controllerAs: 'vm',
                data: {
                    displayName: 'JMAR Site Catalog Search'
                }
            });

    }

    static factory($stateProvider, $urlRouterProvider, StateConstants) {
        Router.instance = new Router($stateProvider, $urlRouterProvider, StateConstants);
        return Router.instance;
    }
}

Router.factory.$inject = ['$stateProvider', '$urlRouterProvider', 'StateConstants'];

export default Router;