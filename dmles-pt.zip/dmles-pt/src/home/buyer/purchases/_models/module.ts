import {Example} from './example.model';
import {ItemCart} from './itemcart.model';

var modelsModule = angular.module('Dmles.Home.Buyer.Purchases.Models.Module', []);
modelsModule.value('Example', Example);
modelsModule.value('ItemCart', ItemCart);

export default modelsModule;