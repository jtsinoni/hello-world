export class ItemCart {

    public id:String ="";
    public siteDodaac:String ="";
    public buyerId:String ="";
    public buyerName:String ="";
    public itemId:String ="";
    public itemName:String ="";
    public itemDescription:String ="";
    public controlledItemInd:String ="";
    public sellerId:String ="";
    public sellerName:String ="";
    public sellerTypeCode:String ="";
    public cartQuantity:Number ;
    public cartPrice:Number ;
    public cartPackCode:String ="";
    public cartStatus:String ="";
    public cartCompleteDate:Date ;
    public cartDateCreated:Date ;
    public cartUserId:String ="";

    constructor();
    constructor(obj:ItemCart);
    constructor(obj?:any) {
        this.id = obj && obj.id || "";
        this.siteDodaac = obj && obj.siteDodaac || null;
        this.buyerId = obj && obj.buyerId || null;
        this.buyerName = obj && obj.buyerName || null;
        this.itemId = obj && obj.itemId || null;
        this.itemName = obj && obj.itemName || null;
        this.itemDescription = obj && obj.itemDescription || null;
        this.controlledItemInd = obj && obj.controlledItemInd || null;
        this.sellerId = obj && obj.sellerId || null;
        this.sellerName = obj && obj.sellerName || null;
        this.sellerTypeCode = obj && obj.sellerTypeCode || null;
        this.cartQuantity = obj && obj.cartQuantity || null;
        this.cartPrice = obj && obj.cartPrice || null;
        this.cartPackCode = obj && obj.cartPackCode || null;
        this.cartStatus = obj && obj.cartStatus || null;
        this.cartCompleteDate = obj && obj.cartCompleteDate || null;
        this.cartDateCreated = obj && obj.cartDateCreated || null;
        this.cartUserId = obj && obj.cartUserId || null;

    }

}
