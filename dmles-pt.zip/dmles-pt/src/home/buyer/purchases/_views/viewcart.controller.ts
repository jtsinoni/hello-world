'use strict';

//import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {CurrentUserProfile} from '../../../../_models/currentUserProfile.model';
import {ItemCart} from "../_models/itemcart.model";

import {DmlesPanelTableColumns} from "../../../../_models/dmlesPanelTableColumns.model";

export class ViewCartController {

    private controllerName = 'View Cart Controller';
    private currentUser:CurrentUserProfile = new CurrentUserProfile();
    public itemCartList:ItemCart = null;
    public cartInitialSort:any = {itemId:"asc"};
    public cartCols:DmlesPanelTableColumns[] = [
        { title: 'Buyer', field: 'buyerName',show: true, sortable: 'buyerName',type:'text',filter: {'buyerName':'text'}, filterData: null },
        { title: 'ItemName', field: 'itemName',show: true, sortable: 'itemName',type:'text',filter: {'itemName':'text'}, filterData: null },
        { title: 'ItemDescription', field: 'itemDescription',show: true, sortable: 'itemDescription',type:'text',filter: {'itemDescription':'text'}, filterData: null },
        { title: 'CII', field: 'controlledItemInd',show: true, sortable: 'controlledItemInd',type:'text',filter: {'controlledItemInd':'text'}, filterData: null },
        { title: 'Seller', field: 'sellerName',show: true, sortable: 'sellerName',type:'text',filter: {'sellerName':'text'}, filterData: null },
        { title: 'SellerType', field: 'sellerTypeCode',show: true, sortable: 'sellerTypeCode',type:'text',filter: {'sellerTypeCode':'text'}, filterData: null },
        { title: 'Quantity', field: 'cartQuantity',show: true, sortable: 'cartQuantity',type:'text',filter: {'cartQuantity':'text'}, filterData: null  },
        { title: 'Price', field: 'cartPrice',show: true, sortable: 'cartPrice',type:'text',filter: {'cartPrice':'text'}, filterData: null },
        { title: 'PackCode', field: 'cartPackCode',show: true, sortable: 'cartPackCode',type:'text',filter: {'cartPackCode':'text'}, filterData: null },
        { title: 'Status', field: 'cartStatus',show: true, sortable: 'cartStatus',type:'text',filter: {'cartStatus':'text'}, filterData: null },
        { title: 'CreatedOn', field: 'cartDateCreated',show: true, sortable: 'cartDateCreated',type:'Date',filter: {'cartDateCreated':'Date'}, filterData: null },
        { title: 'CreatedBy', field: 'cartUserId',show: true, sortable: 'cartUserId',type:'text',filter: {'cartUserId':'text'}, filterData: null }
    ];

    // @ngInject
    constructor(private $log, public SidePanelService, private $state, private StateConstants, private UserService,public ItemCartService ) {
        this.$log.debug("%s - Start", this.controllerName);
        this.currentUser = this.UserService.currentUser;
        this.$log.debug("this.currentUser: %s", JSON.stringify(this.currentUser));
        this.init();
    }
    private init() {
        this.$log.debug("%s - Init requests", this.controllerName);
        this.ItemCartService.getItemCart();
    }

}