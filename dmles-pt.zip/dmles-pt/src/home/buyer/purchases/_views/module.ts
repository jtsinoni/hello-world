import {ViewCartController} from './viewcart.controller';
import {PurchasesController} from './purchases.controller';

var module = angular.module('Dmles.Home.Buyer.Purchases.Views.Module', []);

module.controller('PurchasesController', PurchasesController);
module.controller('ViewCartController', ViewCartController);

export default module;