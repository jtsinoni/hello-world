class Router {
    static instance:any;

    // @ngInject
    constructor($stateProvider, $urlRouterProvider, StateConstants) {

        $stateProvider
            .state(StateConstants.BUYER_PURCHASES, {
                url: '/purchases',
                templateUrl: '/src/home/buyer/purchases/_views/purchases.html',
                controller: 'PurchasesController',
                // templateUrl: '/src/home/buyer/purchases/_views/viewcart.html',
                // controller: 'ViewCartController',
                controllerAs: 'vm',
                data: {
                    displayName: 'Purchases'
                    //displayName:'Review Cart'
                }
        });
    }

    static factory($stateProvider, $urlRouterProvider, StateConstants) {
        Router.instance = new Router($stateProvider, $urlRouterProvider, StateConstants);
        return Router.instance;
    }
}

Router.factory.$inject = ['$stateProvider', '$urlRouterProvider', 'StateConstants'];

export default Router;