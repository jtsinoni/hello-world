'use strict';
import {ApiService} from '../../../../_services/api.service';
import {ItemCart} from "../_models/itemcart.model";

export interface IItemCartService {

}

export class ItemCartService extends ApiService implements IItemCartService {
    private serviceName = 'ViewCartService';
    public itemCart : ItemCart[];
    public cartRecord: ItemCart = null;
    public cartTable: any;

    // @ngInject
    constructor($http, public $log, Authentication, $httpParamSerializerJQLike, private datatableService) {
        super($http, $log, Authentication, $httpParamSerializerJQLike, "Order");
        this.$log.debug("$s - Start", this.serviceName);
    }

    public getItemCart() {
        //this.get("getItemCart","Order").then( (response: any ) => {
        this.get("getItemCart").then( (response: any ) => {
                this.itemCart = response.data;
            },(errRespone:any) => {
                this.$log.error("Error fetching the Cart details !....");
            }
        )
    }

    private initCartTable() {
        this.cartTable = this.datatableService.createNgTable(this.itemCart,20);
    }

    public buildCart() {
        this.$log.debug("Build Cart Button clicked...");
        // logic is to get all the elements from the view cart and create a build cart screen for the buyer
        return true;
    }
    public submitCart() {
        this.$log.debug("Submit Cart Button clicked...");
        // logic is to create order record by grouping the like elements and splitting the unlike elements.
        return true;
    }
}