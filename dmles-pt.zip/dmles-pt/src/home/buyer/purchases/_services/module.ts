import {PurchasesService} from './purchases.service';
import {ItemCartService} from './itemcart.service';

var module = angular.module('Dmles.Home.Buyer.Purchases.Services.Module', []);
module.service('PurchasesService', PurchasesService);
module.service('ItemCartService', ItemCartService);

export default module;