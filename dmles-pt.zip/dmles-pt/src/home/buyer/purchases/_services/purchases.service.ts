'use strict';


export class PurchasesService {
    private serviceName = 'Purchases Service';

    constructor(private $log, private RequestApi) {
        this.$log.info("%s - Started", this.serviceName);
    }
    private stubA(x : string): string {
        return null;
    }

    public stubB(): void {
        // stub
    }

    public  InitializeCart() {

        // get the Buyer Details

        // get the Item catalog details

        //
    }

}