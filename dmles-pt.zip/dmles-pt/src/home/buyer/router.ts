'use strict';

class Router {
    static instance:any;

    // @ngInject
    constructor($stateProvider, $urlRouterProvider, StateConstants) {

        $stateProvider
            .state(StateConstants.BUYER_SHELL, {
                url: '/buyer',
                templateUrl: '/src/home/buyer/buyerShell.html',
                controller: 'BuyerShellController',
                controllerAs: 'vm',
                abstract: true
            })/*.state(StateConstants.BUYER_DETAIL_SHELL, {
            url: '/main',
            templateUrl: '/src/home/buyer/main/_views/buyerMain.html',
            controller: 'BuyerMainController',
            controllerAs: 'vm',
            data: {
                displayName: 'Buyer Detail Screen'
                }
            })*/.state(StateConstants.BUYER_LOOKUP_VIEW, {
                url: '/lookup',
                templateUrl: '/src/home/buyer/lookup/_views/buyerLookup.html',
                controller: 'BuyerLookupController',
                controllerAs: 'vm',
                data: {
                    displayName: 'Buyer Lookup Details'
                    }
            });
    }

    static factory($stateProvider, $urlRouterProvider, StateConstants) {
        Router.instance = new Router($stateProvider, $urlRouterProvider, StateConstants);
        return Router.instance;
    }
}

Router.factory.$inject = ['$stateProvider', '$urlRouterProvider', 'StateConstants'];

export default Router;