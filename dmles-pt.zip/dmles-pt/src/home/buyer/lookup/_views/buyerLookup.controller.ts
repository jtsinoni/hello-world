'use strict';

import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {CurrentUserProfile} from '../../../../_models/currentUserProfile.model';

import {Advice} from './_models/advice.model';
import {DmlesPanelTableColumns} from "../../../../_models/dmlesPanelTableColumns.model";

export class BuyerLookupController {
    private controllerName:string = "Buyer Lookup Controller";
    private currentUser:CurrentUserProfile = new CurrentUserProfile();
    public adviceList:Advice = null;

    public adviceInitialSort:any = {code:"asc"};
    public adviceCols:DmlesPanelTableColumns[] = [
        { title: 'Code', field: 'code', show: true, sortable: 'code',type: 'text',filter: {'code':'text'},filterData:null },
        { title: 'Description', field: 'description',show: true, sortable: 'description',type:'text',filter: {'description':'text'}, filterData: null }
    ];

    // @ngInject
    constructor(private $log, private $state, private StateConstants, private UserService,public BuyerLookupService ) {
        this.$log.debug("%s - Start", this.controllerName);
        this.currentUser = this.UserService.currentUser;
        this.$log.debug("this.currentUser: %s", JSON.stringify(this.currentUser));
        this.init();
    }

    private init() {
        this.$log.debug("%s - Init requests", this.controllerName);

        this.BuyerLookupService.getAdviceCode();
    }

    public viewAdviceCodes(record:Advice) {
        this.$log.info("%s - view Advice Code Record: %s", this.controllerName);
        this.BuyerLookupService.setAdviceRecord(record);
    }
}

