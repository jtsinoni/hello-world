'use strict';

import {BuyerLookupController} from './buyerLookup.controller';

var controllersModule = angular.module('Dmles.Buyer.Lookup.Views.Module', []);
controllersModule.controller('BuyerLookupController', BuyerLookupController);

export default controllersModule;
