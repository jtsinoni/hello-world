'use strict';

import {ApiService} from '../../../../_services/api.service';
import {Advice} from "../_models/advice.model";

export interface IBuyerLookupService {
}

export class BuyerLookupService extends ApiService implements IBuyerLookupService {
    public serviceName: string = "BuyerLookupService";
    public adviceCodes: Advice[];
    public adviceRecord: Advice = null;
    public adviceTable:any;

    // @ngInject
    constructor($http, public $log, Authentication, $httpParamSerializerJQLike, private datatableService) {
        super($http, $log, Authentication, $httpParamSerializerJQLike, "BuyerAdmin");
        this.$log.debug("$s - Start", this.serviceName);
    }

    public getAdviceCode() {
        this.get("getAdviceCode").then( (response: any) => {
            this.adviceCodes = response.data;
            }, (errResponse:any) => {
                this.$log.error("Error retrieving Advice Code from users id." + errResponse.data);
            }
        )
    };
    private initAdviceTable() {
        this.adviceTable = this.datatableService.createNgTable(this.adviceCodes, 10);
    }

}