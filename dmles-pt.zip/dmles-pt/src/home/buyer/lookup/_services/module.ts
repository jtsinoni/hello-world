'use strict';

import {BuyerLookupService} from './buyerLookup.service';

var servicesModule = angular.module('Dmles.Buyer.Services.Module', []);

servicesModule.service('BuyerLookupService', BuyerLookupService);

export default servicesModule;