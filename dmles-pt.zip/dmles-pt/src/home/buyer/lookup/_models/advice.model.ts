
// Advice code table
export class Advice {
    public id:String ="";
    public code:String ="";
    public description:String ="";

    constructor();
    constructor(obj:Advice);
    constructor(obj?:any) {
        this.id = obj && obj.id || "";
        this.code = obj && obj.code;
        this.description = obj && obj.name;
    }

}