'use strict';

import {Advice} from './advice.model';

var lookupModule = angular.module('Dmles.Home.Buyer.Lookup.Models.Module', []);

lookupModule.value('Advice',Advice);

export default  lookupModule;

