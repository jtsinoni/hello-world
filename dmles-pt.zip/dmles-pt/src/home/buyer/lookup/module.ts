'use strict';

// modules
import modelsModule from './_models/module';
import servicesModule from './_services/module';
import controllersModule from './_views/module';

var module = angular.module('Dmles.Home.Buyer.Lookup.Module', [
    modelsModule.name,
    servicesModule.name,
    controllersModule.name
]);

export default module;