import buyerRouter from './router';
import buyerMainRouter from './buyerMain/router';
import orderStatusRouter from './orderStatus/router';
import purchasesRouter from './purchases/router';
import receiptsRouter from './receipts/router';
import requisitionRouter from './requisition/router';

import buyerMainModule from './buyerMain/module';
import orderStatusModule from './orderStatus/module';
import purchasesModule from './purchases/module';
import receiptsModule from './receipts/module';
import requisitionModule from './requisition/module';

import {BuyerShellController} from './buyerShell.controller';

var module = angular.module('Dmles.Home.Buyer.Module', [
    buyerMainModule.name,
    orderStatusModule.name,
    purchasesModule.name,
    receiptsModule.name,
    requisitionModule.name
]);

module.controller('BuyerShellController', BuyerShellController);
module.config(buyerRouter.factory);
module.config(buyerMainRouter.factory);
module.config(orderStatusRouter.factory);
module.config(purchasesRouter.factory);
module.config(receiptsRouter.factory);
module.config(requisitionRouter.factory);


export default module;