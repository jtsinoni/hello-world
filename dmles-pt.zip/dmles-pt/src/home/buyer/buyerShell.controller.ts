'use strict';

export class BuyerShellController {
    viewName: string;

    // @ngInject
    constructor() {
        this.init();
    }

    init(){
        this.viewName = 'Buyer Shell View';
    }

}