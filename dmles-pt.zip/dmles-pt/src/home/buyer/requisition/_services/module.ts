import {RequisitionService} from './requisition.service';

var module = angular.module('Dmles.Home.Buyer.Requisition.Services.Module', []);
module.service('RequisitionService', RequisitionService);

export default module;