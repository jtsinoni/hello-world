class Router {
    static instance:any;

    // @ngInject
    constructor($stateProvider, $urlRouterProvider, StateConstants) {

        $stateProvider
            .state(StateConstants.BUYER_REQUISITION, {
                url: '/requisition',
                templateUrl: '/src/home/buyer/requisition/_views/requisition.html',
                controller: 'RequisitionController',
                controllerAs: 'vm',
                data: {
                    displayName: 'Requisition'
                }
        });
    }

    static factory($stateProvider, $urlRouterProvider, StateConstants) {
        Router.instance = new Router($stateProvider, $urlRouterProvider, StateConstants);
        return Router.instance;
    }
}

Router.factory.$inject = ['$stateProvider', '$urlRouterProvider', 'StateConstants'];

export default Router;