import {Example} from './example.model';

var modelsModule = angular.module('Dmles.Home.Buyer.Requisition.Models.Module', []);
modelsModule.value('Example', Example);

export default modelsModule;