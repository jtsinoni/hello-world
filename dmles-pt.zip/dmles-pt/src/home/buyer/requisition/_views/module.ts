import {RequisitionController} from './requisition.controller';

var module = angular.module('Dmles.Home.Buyer.Requisition.Views.Module', []);
module.controller('RequisitionController', RequisitionController);

export default module;