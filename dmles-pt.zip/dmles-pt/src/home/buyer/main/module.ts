'use strict';

import {BuyerMainController} from './_views/buyerMain.controller';

//Modules
import modelModule from './_models/module';
import viewsModule from './_views/module';

var module = angular.module('Dmles.Home.Buyer.Main.Module',[
    modelModule.name,
    viewsModule.name
]);

module.controller('BuyerMainController',BuyerMainController);

export default module ;
