
'use strict';

import {Buyer} from './buyer.model';

var modelsModule = angular.module('Dmles.Home.Buyer.Models.Module', []);
modelsModule.value('Buyer', Buyer);

export default modelsModule;