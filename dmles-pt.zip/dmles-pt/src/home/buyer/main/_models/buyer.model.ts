'use strict';

export class Buyer {

    // Once the BT structure is ready then we can modify this class to display information

    public name:string;

    constructor();
    constructor(obj?:any) {
        this.name = obj && obj.name || "";
    };

}