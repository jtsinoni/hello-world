'use strict';

import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {CurrentUserProfile} from '../../../../_models/currentUserProfile.model';

export class BuyerMainController {
    private controllerName:string = "Buyer Main Controller";
    private currentUser:CurrentUserProfile = new CurrentUserProfile();

    // @ngInject
    constructor(private $filter, private $log, private $state, private ContentConstants, private datatableService, private ProcessStages, private NotificationService,
                private RequestApi, private RequestService, private StateConstants, private UserService, private UserTypeConstants,
                private WorkflowCompletionStatus, private WorkflowLevelStatus, private WorkFlowService) {
        this.$log.debug("%s - Start", this.controllerName);
        this.currentUser = this.UserService.currentUser;
        this.$log.debug("this.currentUser: %s", JSON.stringify(this.currentUser));
        this.init();
    }

    private init() {
        this.$log.debug("%s - Init requests", this.controllerName);
    }
}

