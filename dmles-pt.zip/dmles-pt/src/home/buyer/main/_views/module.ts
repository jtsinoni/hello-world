'use strict';

import {BuyerMainController} from './buyerMain.controller';

let controllersModule = angular.module('Dmles.Home.Buyer.Main.Views.Module', []);
controllersModule.controller('BuyerMainController', BuyerMainController);

export default controllersModule;