import {ReceiptsController} from './receipts.controller';

var module = angular.module('Dmles.Home.Buyer.Receipts.Views.Module', []);
module.controller('ReceiptsController', ReceiptsController);

export default module;