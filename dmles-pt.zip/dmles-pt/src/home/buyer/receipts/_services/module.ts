import {ReceiptsService} from './receipts.service';

var module = angular.module('Dmles.Home.Buyer.Receipts.Services.Module', []);
module.service('ReceiptsService', ReceiptsService);

export default module;