class Router {
    static instance:any;

    // @ngInject
    constructor($stateProvider, $urlRouterProvider, StateConstants) {

        $stateProvider
            .state(StateConstants.BUYER_RECEIPTS, {
                url: '/receipts',
                templateUrl: '/src/home/buyer/receipts/_views/receipts.html',
                controller: 'ReceiptsController',
                controllerAs: 'vm',
                data: {
                    displayName: 'Receipts'
                }
        });
    }

    static factory($stateProvider, $urlRouterProvider, StateConstants) {
        Router.instance = new Router($stateProvider, $urlRouterProvider, StateConstants);
        return Router.instance;
    }
}

Router.factory.$inject = ['$stateProvider', '$urlRouterProvider', 'StateConstants'];

export default Router;