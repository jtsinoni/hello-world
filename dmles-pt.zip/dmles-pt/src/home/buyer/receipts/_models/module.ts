import {Example} from './example.model';

var modelsModule = angular.module('Dmles.Home.Buyer.Receipts.Models.Module', []);
modelsModule.value('Example', Example);

export default modelsModule;