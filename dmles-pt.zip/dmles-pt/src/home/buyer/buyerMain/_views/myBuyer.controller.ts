'use strict';

import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {Buyer} from '../_models/buyer.model';
import {BuyerService} from '../_services/buyer.service';
import {CurrentUserProfile} from '../../../../_models/currentUserProfile.model';
import {DmlesPanelTableColumns} from "../../../../_models/dmlesPanelTableColumns.model";

export class MyBuyerController {
    private controllerName:string = "My Buyers Controller";
    private currentUser:CurrentUserProfile = new CurrentUserProfile();
    private activePill:string;
    public loadingTable:boolean = true;

    public initialSort:any = [{ buyerName: "asc" }];
    //public initialSort:any = [];
    public trueFalseSelections:Array<any> = [{ id: '', title: "Any"}, { id: 'true', title: "True"}, { id: 'false', title: "False"}];
    public buyerSummaryCols:DmlesPanelTableColumns[] =  [
        { title: 'Buyer ID', field: 'buyerId', show: true, sortable: 'buyerId', type: 'text', filter: null,  filterData: null },
        { title: 'Buyer Name', field: 'buyerName', show: true, sortable: 'code', type: 'text', filter: null,  filterData: null },
        { title: 'Delivery Location', field: 'deliveryLocation', show: true, sortable: 'code', type: 'text', filter: null,  filterData: null },
        //{ title: 'Address1', field: 'address.address1', show: true, sortable: 'code', type: 'titlecase', filter: null,  filterData: null },
        { title: 'POC First Name', field: 'pocFirstName', show: true, sortable: 'code', type: 'text', filter: null,  filterData: null },
        { title: 'POC Last Name', field: 'pocLastName', show: true, sortable: 'code', type: 'text', filter: null,  filterData: null },
        { title: 'Verify Order', field: 'verifyOrder', show: true, sortable: 'code', type: 'text', filter: null,  filterData: null },
        { title: 'Verify Receipt', field: 'verifyReceipt', show: true, sortable: 'code', type: 'text', filter: null,  filterData: null },
        { title: 'Transportation Needed', field: 'transportationNeeded', show: true, sortable: 'code', type: 'titleCase', filter: { 'transportationNeeded': 'select' }, filterData: this.trueFalseSelections }
    ];

    // @ngInject
    constructor(private $filter, private $log, private $state, private ContentConstants, private datatableService, private NotificationService,
                private StateConstants, private UserService,
                private BuyerService) {
        this.$log.debug("%s - Start", this.controllerName);
        this.currentUser = this.UserService.currentUser;
        this.$log.debug("this.currentUser: %s", JSON.stringify(this.currentUser));
        this.init();
    }

    private init() {
        this.$log.debug("%s - Init Buyers", this.controllerName);
        this.BuyerService.getBuyers();
    }


}

