//import {BuyerController} from './buyer.controller';
import {MyBuyerController} from "./myBuyer.controller";

var module = angular.module('Dmles.Home.Buyer.BuyerMain.Views.Module', []);
module.controller('MyBuyerController', MyBuyerController);

export default module;