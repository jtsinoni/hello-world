class Router {
    static instance:any;

    // @ngInject
    constructor($stateProvider, $urlRouterProvider, StateConstants) {

        $stateProvider
            .state(StateConstants.BUYER_MAIN, {
                url: '/buyerMain',
                templateUrl: '/src/home/buyer/buyerMain/_views/myBuyer.html',
                controller: 'MyBuyerController',
                controllerAs: 'vm',
                data: {
                    displayName: 'Customer'
                }
            });
    }

    static factory($stateProvider, $urlRouterProvider, StateConstants) {
        Router.instance = new Router($stateProvider, $urlRouterProvider, StateConstants);
        return Router.instance;
    }
}

Router.factory.$inject = ['$stateProvider', '$urlRouterProvider', 'StateConstants'];

export default Router;