
'use strict';

import {ApiService} from '../../../../_services/api.service';

export interface IBuyerApiService {

}

export class BuyerApi extends ApiService implements IBuyerApiService {

    // @ngInject
    constructor($http, public $log, Authentication, $httpParamSerializerJQLike) {
        super($http, $log, Authentication, $httpParamSerializerJQLike, "Buyer");
    }

    public getMyBuyers() {
        return this.get("getMyBuyers");
    }



}