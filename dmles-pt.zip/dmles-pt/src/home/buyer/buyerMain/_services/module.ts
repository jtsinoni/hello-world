import {BuyerService} from './buyer.service';
import {BuyerApi} from './buyerApi.service'
var module = angular.module('Dmles.Home.Buyer.BuyerMain.Services.Module', []);
module.service('BuyerService', BuyerService);
module.service('BuyerApi', BuyerApi);
export default module;