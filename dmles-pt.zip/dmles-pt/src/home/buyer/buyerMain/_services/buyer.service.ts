import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {Buyer} from "../_models/buyer.model";


export interface IBuyerService {

}

export class BuyerService implements IBuyerService {


   // public selectedBuyer:Buyer;
    public buyers:any;
    //public buyerSimple:any;
    private serviceName :string = 'BuyerService';
    // @ngInject
    constructor(private $log, private ContentConstants,
                private NotificationService, private StateConstants, private BuyerApi, private UserService) {
        this.$log.debug("%s - Start", this.serviceName);
        console.log("inside constructor of buyer service");

    }


    public getBuyers(){

        this.$log.debug("Getting buyers");

        this.BuyerApi.getMyBuyers().then((result:IHttpPromiseCallbackArg<Buyer[]>) => {
                this.$log.debug("making call for buyers");
                this.buyers = result.data;
                //this.buyerSimple = [];

                this.$log.debug("result %s", result.data);
            }, (errResponse:IHttpPromiseCallbackArg<Buyer[]>) => {
                this.$log.error("Error retrieving buyers from users id." + errResponse.data);
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
            }
        );
    }


    // public getSelectedBuyer() {
    //     return this.selectedBuyer;
    // }
    //
    // public setSelectedBuyer(rowData:Buyer) {
    //     this.selectedBuyer = rowData;
    //
    // }


}