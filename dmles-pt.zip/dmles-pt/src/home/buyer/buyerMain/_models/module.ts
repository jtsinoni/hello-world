
import {Buyer} from "./buyer.model";
import {Address} from "./address.model";
import {DeaData} from "./deaData.model";

var modelsModule = angular.module('Dmles.Home.Buyer.BuyerMain.Models.Module', []);
modelsModule.value('Buyer', Buyer);
modelsModule.value('Address', Address);
modelsModule.value('DeaData', DeaData);
export default modelsModule;