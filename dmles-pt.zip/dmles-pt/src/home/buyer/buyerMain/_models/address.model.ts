export class Address{

    public address1:String ;
    public address2:String ;
    public city:String ;
    public state:String ;
    public zip:String ;
    public country:String ;
}
