
export  class DeaData{
    public registrationNumber:String ;
    public startDate:Date ;
    public endDate:Date ;

}
