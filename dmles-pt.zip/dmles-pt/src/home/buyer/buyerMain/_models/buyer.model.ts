 import {Address} from "./address.model";
 import {DeaData} from "./deaData.model";
export class Buyer {

    public _id:String;
    public buyerID:String;
    public buyerName:String;
    private address:Address;
    public stateService:String;
    public materielCurrencyType:String    ;
    public materielConversionFactor:number;
    public serviceCurrencyType:String;
    public serviceConversionFactor:number;
    public fieldOperatingAgency:String ;
    public deaData :DeaData;
    public deliveryLocation:String    ;
    public issueDocument:String;
    public transportationNeeded:boolean;
    public pocId:String;
    public pocFirstName:String;
    public  pocLastName:String;
    public shipTo:Address;
    public verifyReceipt:String;
    public verifyOrder:String;
    public autoDueout:String ;
    public pvpDirect:String ;
    public pvmDirect:String;
}