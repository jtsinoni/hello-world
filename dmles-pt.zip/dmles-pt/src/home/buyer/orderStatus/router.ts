class Router {
    static instance:any;

    // @ngInject
    constructor($stateProvider, $urlRouterProvider, StateConstants) {

        $stateProvider
            .state(StateConstants.BUYER_ORDER_STATUS, {
                url: '/orderStatus',
                templateUrl: '/src/home/buyer/orderStatus/_views/orderStatus.html',
                controller: 'OrderStatusController',
                controllerAs: 'vm',
                data: {
                    displayName: 'Order Status'
                }
        });
    }

    static factory($stateProvider, $urlRouterProvider, StateConstants) {
        Router.instance = new Router($stateProvider, $urlRouterProvider, StateConstants);
        return Router.instance;
    }
}

Router.factory.$inject = ['$stateProvider', '$urlRouterProvider', 'StateConstants'];

export default Router;