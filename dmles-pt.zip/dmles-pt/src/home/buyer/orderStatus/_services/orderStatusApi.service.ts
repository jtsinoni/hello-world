'use strict';

import {ApiService} from '../../../../_services/api.service';

export class OrderStatusApi extends ApiService {

    // @ngInject
    constructor($http, public $log, Authentication, $httpParamSerializerJQLike) {
        super($http, $log, Authentication, $httpParamSerializerJQLike, "OrderStatus");
    }

    public getAllOpenOrders() {
        return this.get("getAllDueIns");
    }

    public getDueInByOrderID (orderID) {
        return this.get("getDueInsByOrderID");
    }

}