import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;

import {OrderStatus} from "../_models/orderStatus.model";



export class OrderStatusService {
    private serviceName = 'OrderStatusService';
    public activeOrdersTable:any;
    public orderStatus:any;


    public allOpenOrders:Array<any> = [];
    public allOpenDueIns:Array<OrderStatus> = [];

    constructor(private $filter, private $http, private $log, private $state, private ContentConstants,
                private dataService,  private FileUploader, private NotificationMessages, private datatableService,
                private NotificationService, private StateConstants,  private UserService, private OrderStatusApi) {
        this.$log.debug("%s - Start", this.serviceName);

    }


    public getAllOpenOrders(){
        this.OrderStatusApi.getAllOpenOrders().then((result) => {
            if(result && result.data){
                this.allOpenDueIns = result.data;
                this.createActiveOrders();
           }}, (errResponse:IHttpPromiseCallbackArg<any>) => {
            this.$log.error("Error retrieving all Open Orders.");
            this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
        });
    }



    // public createActiveTable(data){
    //     this.activeOrdersTable = this.datatableService.createNgTable(data, 25, { updatedDate: 'desc' });
    // }


    private createActiveOrders(){
        this.allOpenOrders = [];

        // TODO: This needs to be moved to the BT in either logic or from the morphia query
        for(var i = 0;i<this.allOpenDueIns.length;i++){
            var orderGroup = this.$filter('filter')(this.allOpenDueIns, { "orderID": this.allOpenDueIns[i].orderID }, true);
            if (this.$filter('filter')(this.allOpenOrders, { "orderID": this.allOpenDueIns[i].orderID }, true).length == 0){
                var dueInList:Array<any> = [];
                for(var j = 0;j<orderGroup.length;j++){
                    dueInList.push(orderGroup[j]);
                }

                this.allOpenOrders.push( {orderID:this.allOpenDueIns[i].orderID, sellerName:this.allOpenDueIns[i].sellerName, dueIns:dueInList } );
            }
        }
        var test = "junk";
    }




}