import {OrderStatusService} from './orderStatus.service';
import {OrderStatusApi} from './orderStatusApi.service';

var module = angular.module('Dmles.Home.Buyer.OrderStatus.Services.Module', []);
module.service('OrderStatusService', OrderStatusService);
module.service('OrderStatusApi', OrderStatusApi);

export default module;