import {OrderStatusController} from './orderStatus.controller';

var module = angular.module('Dmles.Home.Buyer.OrderStatus.Views.Module', []);
module.controller('OrderStatusController', OrderStatusController);

export default module;