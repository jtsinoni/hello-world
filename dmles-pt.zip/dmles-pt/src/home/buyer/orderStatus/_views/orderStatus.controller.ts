import {DmlesPanelTableColumns} from "../../../../_models/dmlesPanelTableColumns.model";

export class OrderStatusController {
    private controllerName = 'OrderStatusController';

    public activeOrdersSearch:String;
    public dueInInitialSort:any = { itemDescription: "asc" };
    public searchText:string = "";


    public dueInCols:DmlesPanelTableColumns[] = [
        { title: 'Item Description', field: 'itemDescription', show: true, sortable: 'itemDescription', type: 'text', filter: null,  filterData: null },
        { title: 'Item Price', field: 'itemPrice', show: true, sortable: 'itemPrice', type: 'currency', filter: null,  filterData: null },
        { title: 'Buyer', field: 'buyerName', show: true, sortable: 'buyerName', type: 'text', filter: null,  filterData: null },
        { title: 'Buyer Id', field: 'buyerID', show: true, sortable: 'buyerID', type: 'text', filter: null,  filterData: null },
        { title: 'Quantity', field: 'orderQuantity', show: true, sortable: 'orderQuantity', type: 'number', filter: null,  filterData: null },
        { title: 'Balance Due', field: 'balanceDueQuantity', show: true, sortable: 'balanceDueQuantity', type: 'currency', filter: null,  filterData: null },
        { title: 'Last Update', field: 'lastUpdateDate', show: true, sortable: 'lastUpdateDate', type: 'date', filter: null,  filterData: null }
    ];

    // @ngInject
    constructor(private $log, private $state,  private StateConstants, private OrderStatusService) {
        this.$log.info("%s - Started", this.controllerName);
        this.init();
    }

    private getOrders(){
        this.OrderStatusService.getAllOpenOrders();
    }

    private init() {
        this.$log.debug("%s - Init Open Orders", this.controllerName);
        this.getOrders();
    }

    public ordersFilter() {
        this.OrderStatusService.activeOrdersTable.filter({$: this.activeOrdersSearch});
        this.OrderStatusService.activeOrdersTable.reload();
    }

    public refreshClick(){
        this.$log.debug("%s - Refreshing order data", this.controllerName);
        this.getOrders();
    }

    public rowClick(rowData:any){
        this.$log.debug("Row clicked: %s", JSON.stringify(rowData));
        // TODO: Go to details page....
    }

}