import {OrderStatus} from './orderStatus.model';

var modelsModule = angular.module('Dmles.Home.Buyer.OrderStatus.Models.Module', []);
modelsModule.value('OrderStatus', OrderStatus);

export default modelsModule;