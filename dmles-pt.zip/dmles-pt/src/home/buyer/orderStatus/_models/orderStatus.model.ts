export class OrderStatus{
    //public barcode: string = "";

    public id:string = "";
    public orderId:string = "";
    public buyerId:string = "";
    public buyerName:string = "";
    public sellerId:string = "";
    public sellerName:string = "";
    public itemID:string = "";
    public orderID:string = "";
    public itemDescription:string = "";
    public vendorItemNumber:string = "";
    public orderCallNum:string = "";
    public documentNumber:string = "";
    public orderQty:number = 0;
    public balanceDueQuantity:number = 0;
    public itemPrice:number = 0;
    public lastUpdateDate:Date;
    public CreateDate:Date;



    constructor();
    constructor(obj:OrderStatus);
    constructor(obj?:any) {
        this.id = obj && obj.id || "";
        this.orderID = obj && obj.orderID || "";
        this.itemID = obj && obj.ItemID || "";
        this.vendorItemNumber = obj && obj.vendorItemNumber || "";
        this.itemDescription = obj && obj.itemDescription || "";
        this.documentNumber = obj && obj.documentNumber || "";
        this.orderCallNum = obj && obj.orderCallNum || "";
        this.sellerId = obj && obj.sellerID || "";
        this.sellerName = obj && obj.sellerName || "";
        this.buyerId = obj && obj.buyerID || "";
        this.buyerName = obj && obj.buyerName || "";
        this.orderQty = obj && obj.orderQuantity || "";
        this.balanceDueQuantity= obj && obj.balanceDueQuantity || "";
        this.CreateDate= obj && obj.createDate || "";

    };




}
