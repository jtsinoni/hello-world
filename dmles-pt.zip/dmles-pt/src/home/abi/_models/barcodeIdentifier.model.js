define(["require", "exports"], function (require, exports) {
    'use strict';
    var BarcodeIdentifier = (function () {
        function BarcodeIdentifier(obj) {
            this.barcode = "";
            this.barcodeType = "";
            this.barcode = obj && obj.barcode || "";
            this.barcodeType = obj && obj.barcodeType || "";
        }
        ;
        return BarcodeIdentifier;
    }());
    exports.BarcodeIdentifier = BarcodeIdentifier;
});
//# sourceMappingURL=barcodeIdentifier.model.js.map