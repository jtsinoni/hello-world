'use strict';

import {ItemIdentifier} from "./itemIdentifier.model";
import {BarcodeIdentifier} from "./barcodeIdentifier.model";

export class Package {
    public enterprisePackageIdentifier: string = "";
    public gtin: string = "";   // Global Trade Item Number
    public packageUnit: string = "";
    public packageQuantity: Number = 0;
    public packageUnitText: string = "";
    public packageUnitDescription: string = "";
    public doseOrUseCount: Number = 0;
    public innerPackMultiple: Number = 0;
    public gudidIdentifierType: string = "";
    public nsn: Array<string> = [];   // National Stock Number
    public barcodes: Array<string> = [];
    public otherPackageIdentifiers: Array<string> = [];

    constructor();
    constructor(obj: Package);
    constructor(obj?: any) {
        this.enterprisePackageIdentifier = obj && obj.enterprisePackageIdentifier || "";
        this.gtin = obj && obj.gtin || "";
        this.packageUnit = obj && obj.packageUnit || "";
        this.packageQuantity = obj && obj.packageQuantity || 0;
        this.packageUnitText = obj && obj.packageUnitText || "";
        this.packageUnitDescription = obj && obj.packageUnitDescription || "";
        this.doseOrUseCount = obj && obj.doseOrUseCount || 0;
        this.innerPackMultiple = obj && obj.innerPackMultiple || 0;
        this.gudidIdentifierType = obj && obj.gudidIdentifierType || "";
        this.nsn = obj && obj.nsn || [];
        this.barcodes = obj && obj.barcodes || [];
        this.otherPackageIdentifiers = obj && obj.otherPackageIdentifiers || [];
    };
}
