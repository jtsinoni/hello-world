define(["require", "exports"], function (require, exports) {
    'use strict';
    var Package = (function () {
        function Package(obj) {
            this.enterprisePackageIdentifier = "";
            this.gtin = ""; // Global Trade Item Number
            this.niin = ""; // National Item Identification Number
            this.nsn = ""; // National Stock Number
            this.otherPackageIdentifiers = [];
            this.packageUnit = "";
            this.packageQuantity = 0;
            this.gudidIdentifierType = "";
            this.barcodeData = [];
            this.enterprisePackageIdentifier = obj && obj.enterprisePackageIdentifier || "";
            this.gtin = obj && obj.gtin || "";
            this.niin = obj && obj.niin || "";
            this.nsn = obj && obj.nsn || "";
            this.otherPackageIdentifiers = obj && obj.otherPackageIdentifiers || [];
            this.packageUnit = obj && obj.packageUnit || "";
            this.packageQuantity = obj && obj.packageQuantity || 0;
            this.gudidIdentifierType = obj && obj.gudidIdentifierType || "";
            this.barcodeData = obj && obj.barcodeData || [];
        }
        ;
        return Package;
    }());
    exports.Package = Package;
});
//# sourceMappingURL=package.model.js.map