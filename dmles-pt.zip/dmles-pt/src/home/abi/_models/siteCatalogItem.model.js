define(["require", "exports"], function (require, exports) {
    'use strict';
    var SiteCatalogItem = (function () {
        function SiteCatalogItem(obj) {
            this.siteDodaac = "";
            this.itemId = "";
            this.manufacturerNm = "";
            this.manufCatNum = "";
            this.ndc = "";
            this.longItemDesc = "";
            this.sources = [];
            this.orderCost = 0;
            this.orderCount = 0;
            this.siteDodaac = obj && obj.siteDodaac || "";
            this.itemId = obj && obj.itemId || "";
            this.manufacturerNm = obj && obj.manufacturerNm || "";
            this.manufCatNum = obj && obj.manufCatNum || "";
            this.ndc = obj && obj.ndc || "";
            this.longItemDesc = obj && obj.longItemDesc || "";
            this.sources = obj && obj.sources || [];
            this.orderCost = obj && obj.orderCost || 0;
            this.orderCount = obj && obj.orderCount || 0;
        }
        ;
        return SiteCatalogItem;
    }());
    exports.SiteCatalogItem = SiteCatalogItem;
});
//# sourceMappingURL=siteCatalogItem.model.js.map