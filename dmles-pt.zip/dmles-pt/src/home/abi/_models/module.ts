'use strict';

import {AbiProduct} from './abiProduct.model';
import {SiteCatalogItem} from './siteCatalogItem.model';

let modelsModule = angular.module('Dmles.Home.Abi.Models.Module', []);

modelsModule.value('AbiProduct', AbiProduct);
modelsModule.value('SiteCatalogItem', SiteCatalogItem);

export default modelsModule;