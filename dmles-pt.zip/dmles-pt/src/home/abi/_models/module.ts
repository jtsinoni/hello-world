'use strict';

import {AbiProduct} from './abiProduct.model';
import {CategoryConfiguration} from './categoryConfiguration.model';
import {CategoryOption} from './categoryOption.model';
import {FacetConfiguration} from './facetConfiguration.model';
import {FacetOption} from './facetOption.model';
import {SiteCatalogItem} from './siteCatalogItem.model';

let modelsModule = angular.module('Dmles.Home.Abi.Models.Module', []);
modelsModule.value('AbiProduct', AbiProduct);
modelsModule.value('CategoryConfiguration', CategoryConfiguration);
modelsModule.value('CategoryOption', CategoryOption);
modelsModule.value('FacetConfiguration', FacetConfiguration);
modelsModule.value('FacetOption', FacetOption);
modelsModule.value('SiteCatalogItem', SiteCatalogItem);

export default modelsModule;