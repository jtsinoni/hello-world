define(["require", "exports", './abiProduct.model', './siteCatalogItem.model'], function (require, exports, abiProduct_model_1, siteCatalogItem_model_1) {
    'use strict';
    var modelsModule = angular.module('Dmles.Home.Abi.Models.Module', []);
    modelsModule.value('AbiProduct', abiProduct_model_1.AbiProduct);
    modelsModule.value('SiteCatalogItem', siteCatalogItem_model_1.SiteCatalogItem);
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = modelsModule;
});
//# sourceMappingURL=module.js.map