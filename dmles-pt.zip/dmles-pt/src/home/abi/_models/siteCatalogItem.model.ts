'use strict';

export class SiteCatalogItem {    
    public siteDodaac: string = "";
    public itemId: string = "";
    public manufacturerNm: string = "";
    public manufCatNum: string = "";
    public ndc: string = "";
    public longItemDesc: string = "";
    public sources: Array<any> = [];
    public orderCost: number = 0;
    public orderCount: number = 0;
    
    constructor();
    constructor(obj: SiteCatalogItem);
    constructor(obj?: any) {       
        this.siteDodaac = obj && obj.siteDodaac || "";
        this.itemId = obj && obj.itemId || "";
        this.manufacturerNm = obj && obj.manufacturerNm || "";
        this.manufCatNum = obj && obj.manufCatNum || "";
        this.ndc = obj && obj.ndc || "";
        this.longItemDesc = obj && obj.longItemDesc || "";
        this.sources = obj && obj.sources || [];       
        this.orderCost = obj && obj.orderCost || 0;        
        this.orderCount = obj && obj.orderCount || 0;        
    };
}
