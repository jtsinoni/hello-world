define(["require", "exports"], function (require, exports) {
    'use strict';
    var ItemIdentifier = (function () {
        function ItemIdentifier(obj) {
            this.identifier = "";
            this.identifierType = "";
            this.identifier = obj && obj.identifier || "";
            this.identifierType = obj && obj.identifierType || "";
        }
        ;
        return ItemIdentifier;
    }());
    exports.ItemIdentifier = ItemIdentifier;
});
//# sourceMappingURL=itemIdentifier.model.js.map