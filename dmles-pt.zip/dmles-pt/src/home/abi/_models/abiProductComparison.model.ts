'use strict';

export class AbiProductComparison {
    public productImages: Array<string> = [];
    public longItemDescription: string = "";
    public enterpriseProductIdentifier: string = "";
    public manufacturer: string = "";
    public manufacturerCatalogNumber: string = "";
    public ndc: string = "";
    public productNoun: string = "";
    public productType: string = "";
    public productComposition: Array<string> = [];
    public trademarkBrandnames: Array<string> = [];
    public brandGeneric: string = "";
    public deaCode: string = "";
    public drugCategory: string = "";
    public drugStorageType: string = "";
    public sizeShape: string = "";
    public productProperties: Array<string> = [];
    public locations: Array<string> = [];
    public miscellaneous: Array<string> = [];
    public age: string = "";
    public gender: string = "";
    public color: string = "";
    public flavor: string = "";
    public fragrance: string = "";
    public disposableReusable: string = "";
    public diameter: string = "";
    public volume: string = "";
    public weight: string = "";
    public lengthWidthHeight: string = "";
    public lengthWidthHeight2: string = "";
    public sterileNonsterile: string = "";
    public hazardCode: string = "";
    public latexCode: string = "";

    public productCompareSelected: boolean = false;
    public isPreferredProduct: boolean = false;

    constructor();
    constructor(obj: AbiProductComparison);
    constructor(obj?: any) {
        this.enterpriseProductIdentifier = obj && obj.enterpriseProductIdentifier || "";
        this.longItemDescription = obj && obj.longItemDescription || "";
        this.manufacturer = obj && obj.manufacturer || "";
        this.manufacturerCatalogNumber = obj && obj.manufacturerCatalogNumber || "";
        this.ndc = obj && obj.ndc || "";
        this.productNoun = obj && obj.productNoun || "";
        this.productType = obj && obj.productType || "";
        this.age = obj && obj.age || "";
        this.gender = obj && obj.gender || "";
        this.sizeShape = obj && obj.sizeShape || "";
        this.color = obj && obj.color || "";
        this.flavor = obj && obj.flavor || "";
        this.fragrance = obj && obj.fragrance || "";
        this.sterileNonsterile = obj && obj.sterileNonsterile || "";
        this.hazardCode = obj && obj.hazardCode || "";
        this.latexCode = obj && obj.latexCode || "";
        this.disposableReusable = obj && obj.disposableReusable || "";
        this.diameter = obj && obj.diameter || "";
        this.volume = obj && obj.volume || "";
        this.weight = obj && obj.weight || "";
        this.lengthWidthHeight = obj && obj.lengthWidthHeight || "";
        this.lengthWidthHeight2 = obj && obj.lengthWidthHeight2 || "";
        this.productComposition = obj && obj.productComposition || [];
        this.productProperties = obj && obj.productProperties || [];
        this.locations = obj && obj.locations || [];
        this.miscellaneous = obj && obj.miscellaneous || [];
        this.productImages = obj && obj.productImages || [];
        this.trademarkBrandnames = obj && obj.trademarkBrandnames || [];
        this.brandGeneric = obj && obj.brandGeneric || "";
        this.deaCode = obj && obj.deaCode || "";
        this.drugCategory = obj && obj.drugCategory || "";
        this.drugStorageType = obj && obj.drugStorageType || "";

        this.productCompareSelected = obj && obj.productCompareSelected || false;
        this.isPreferredProduct = obj && obj.isPreferredProduct || false;
    };
}
