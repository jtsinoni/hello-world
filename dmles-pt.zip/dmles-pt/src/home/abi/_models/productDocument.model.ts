'use strict';

export class ProductDocument {    
    public documentType: string = "";
    public documentName: string = "";
    public fileName: string = "";
    public documentUrl: string = "";

    constructor();
    constructor(obj: ProductDocument);
    constructor(obj?: any) {        
        this.documentType = obj && obj.documentType || "";
        this.documentName = obj && obj.documentName || "";
        this.fileName = obj && obj.fileName || "";
        this.documentUrl = obj && obj.documentUrl || "";
    };
}
