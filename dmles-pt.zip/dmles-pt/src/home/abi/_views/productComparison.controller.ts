'use strict';

export class ProductComparisonController {

    private controllerName: string = "Product Comparison Controller";
    public previousState: string;

    // @ngInject
    constructor(private $log, private $rootScope, private $state,
                private ProductComparisonService, private SearchUtilService, private StateConstants) {

        this.$log.debug("%s - Start", this.controllerName);
        $(window).scrollTop(0);
        this.previousState = this.$rootScope.previousState;

        // there will always be 2 products to compare
        this.SearchUtilService.setProductImageSrcs("product1", this.ProductComparisonService.productComparisonPrimaryImageList[0]);
        this.SearchUtilService.setProductImageSrcs("product2", this.ProductComparisonService.productComparisonPrimaryImageList[1]);

        // but not necessarily a third product
        if (this.ProductComparisonService.productComparisonPrimaryImageList[2]) {
            this.SearchUtilService.setProductImageSrcs("product3", this.ProductComparisonService.productComparisonPrimaryImageList[2]);
        }
    }

    public switchProductImageSrc(productIndex: number, thumbnailIndex: number) {
        this.SearchUtilService.switchProductImageSrc(
            'product' + productIndex,
            thumbnailIndex,
            this.ProductComparisonService.productComparisonPrimaryImageList[productIndex - 1]);
    }

    public goToPreviousState() {
        if (this.$rootScope.previousState) {
            this.$state.go(this.$rootScope.previousState);
        } else {
            this.$state.go(this.StateConstants.ABI_SEARCH);
        }
    }
}