'use strict';

import {ProductComparisonController} from './productComparison.controller';
import {ProductDetailsController} from './productDetails.controller';
import {ProductsSiteCatalogItemsController} from './productsSiteCatalogItems.controller';
import {PreferredProductController} from './preferredProduct.controller';
import {ProductsInSameProductGroupController} from './productsInSameProductGroup.controller';
import {AbiSearchController} from './abiSearch.controller';
import {AbiSearchHelpController} from './abiSearchHelp.controller';

let controllersModule = angular.module('Dmles.Home.Abi.Views.Module', []);

controllersModule.controller('Dmles.Home.Abi.Views.ProductComparisonController', ProductComparisonController);
controllersModule.controller('Dmles.Home.Abi.Views.ProductDetailsController', ProductDetailsController);
controllersModule.controller('Dmles.Home.Abi.Views.ProductsSiteCatalogItemsController', ProductsSiteCatalogItemsController);
controllersModule.controller('Dmles.Home.Abi.Views.PreferredProductController', PreferredProductController);
controllersModule.controller('Dmles.Home.Abi.Views.ProductsInSameProductGroupController', ProductsInSameProductGroupController);
controllersModule.controller('Dmles.Home.Abi.Views.AbiSearchController', AbiSearchController);
controllersModule.controller('Dmles.Home.Abi.Views.AbiSearchHelpController', AbiSearchHelpController);

export default controllersModule;