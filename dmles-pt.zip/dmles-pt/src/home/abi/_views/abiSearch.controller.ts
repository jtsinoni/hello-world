'use strict';

import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {FacetOption} from "../../../_models/facetOption.model";
import {SearchConstants} from "../../../_constants/search.constants";

export class AbiSearchController {
    private controllerName: string = "ABi Search Controller";

    public abiSearchGridOpts: any = {};


    // @ngInject
    constructor(private $log, private $rootScope, private AbiService,
                private AbiCategoryBreadcrumbsService, private AbiCategoriesService, private AbiFacetsService,
                private AbiSearchWithinResultsService, private AbiSelectedFacetOptionsBreadboxService,
                private PreferredProductService, private ProductComparisonService,
                private SameProductGroupService, private SearchUtilService,
                private SidePanelService, private SiteCatalogService,
                private SubstituteProductGroupService, private uiGridConstants) {

        // this.$log.debug("%s - Start", this.controllerName);
        $(window).scrollTop(0);

        let executeSearchEventId = this.SearchUtilService.buildEventId(
            SearchConstants.EVENT_MODULE_ABI,
            SearchConstants.EVENT_TARGET_COMPONENT_SEARCH,
            SearchConstants.EVENT_TARGET_METHOD_EXECUTE_SEARCH);

        let executeSearchEventHandler = this.$rootScope.$on(executeSearchEventId, (event: ng.IAngularEvent, data: FacetOption) => {
            //this.$log.debug("caught " + executeSearchEventId + " event");
            this.AbiService.lastFacetOptionUpdated = data;
            this.AbiService.executeSearch();
        });
        this.$rootScope.$on('$destroy', function () {
            executeSearchEventHandler();
        });

        this.buildAbiSearchGridOpts();

        this.AbiService.init();
    }

    private buildAbiSearchGridOpts() {
        this.abiSearchGridOpts = {
            appScopeProvider: this,
            data: null,
            enableCellEditOnFocus: false,
            enableColumnResizing: true,
            enableFiltering: true,
            enableGridMenu: true,
            enablePaginationControls: true,
            enableRowHeaderSelection: false,
            enableRowSelection: false,
            enableSelectAll: false,
            enableSorting: true,
            excessRows: 25,
            exporterCsvFilename: 'abiSearchSummaryResults.csv',
            minRowsToShow: 20,
            multiSelect: false,
            rowHeight: 25,
            showColumnFooter: true,
            showGridFooter: true,
            virtualizationThreshold: 20,
            columnDefs: [
                {
                    name: 'productCompareSelected',
                    field: 'productCompareSelected',
                    displayName: 'Compare Products',
                    headerTooltip: true,
                    width: "5%",
                    enableFiltering: false,
                    cellTemplate: '<div class="abi-ui-grid-row-height">' +
                    '<input type="checkbox" ng-change="grid.appScope.ProductComparisonService.updateItemComparisonList(row.entity)" ng-model="row.entity.productCompareSelected">' +
                    '&nbsp;' +
                    '<a ng-class="{disabled: grid.appScope.ProductComparisonService.getItemComparisonList().length < 2}" ng-if="row.entity.productCompareSelected && grid.appScope.ProductComparisonService.getItemComparisonList().length > 0" ng-click="grid.appScope.ProductComparisonService.goToItemComparison()" title="Click here to view product comparison">View</a>' +
                    '</div>'
                },
                {
                    name: 'longItemDescription',
                    field: 'longItemDescription',
                    displayName: 'Long Item Description',
                    cellTooltip: true,
                    headerTooltip: true,
                    width: "40%"
                },
                {
                    name: 'enterpriseProductIdentifier',
                    field: 'enterpriseProductIdentifier',
                    displayName: 'Enterprise Product Identifier',
                    cellTooltip: true,
                    headerTooltip: true,
                    width: "6%",
                    cellTemplate: '<div class="text-center abi-ui-grid-row-height"><a ng-click="grid.appScope.AbiService.goToDetails(row.entity)" title="Click to view this product\'s details">{{row.entity.enterpriseProductIdentifier}}</a></div>'
                },
                {
                    name: 'manufacturer',
                    field: 'manufacturer',
                    displayName: 'Manufacturer',
                    cellTooltip: true,
                    headerTooltip: true,
                    width: "10%"
                },
                {
                    name: 'manufacturerCatalogNumber',
                    field: 'manufacturerCatalogNumber',
                    displayName: 'Manufacturer Catalog Number',
                    cellTooltip: true,
                    headerTooltip: true,
                    width: "10%"
                },
                {
                    name: 'ndc',
                    field: 'ndc',
                    displayName: 'National Drug Code (NDC)',
                    cellTooltip: true,
                    headerTooltip: true,
                    width: "5%"
                },
                {
                    name: 'productStatus',
                    field: 'productStatus',
                    displayName: 'Product Status',
                    cellTooltip: true,
                    headerTooltip: true,
                    width: "5%"
                },
                {
                    name: 'siteCount',
                    field: 'siteCount',
                    displayName: 'Site Catalog Records',
                    headerTooltip: true,
                    width: "5%",
                    enableFiltering: false,
                    cellTemplate: '<div class="abi-ui-grid-row-height"><a ng-click="grid.appScope.SiteCatalogService.displaySiteCatalogItems(row.entity)" ng-if="row.entity.mmcProductIdentifier && row.entity.siteCount > 0" title="Click to view this product\'s Site Catalog records">View <span class="badge">{{row.entity.siteCount}}</span></a></div>'
                },
                {
                    name: 'sameGroup',
                    displayName: 'Products in Same Group',
                    headerTooltip: true,
                    width: "5%",
                    enableFiltering: false,
                    cellTemplate: '<div class="text-center abi-ui-grid-row-height"><a ng-click="grid.appScope.SameProductGroupService.displayProductsInSameProductGroup(row.entity)" ng-if="row.entity.productGroup" title="Click to view products in the same product group">View</a></div>'
                },
                {
                    name: 'substituteGroup',
                    displayName: 'Products in Substitute Group',
                    headerTooltip: true,
                    width: "5%",
                    enableFiltering: false,
                    cellTemplate: '<div class="text-center abi-ui-grid-row-height"><a ng-click="grid.appScope.SubstituteProductGroupService.displayProductsInSubstituteProductGroup(row.entity)" ng-if="row.entity.productSubstituteGroup" title="Click to view products in the substitute product group">View</a></div>'
                },
                {
                    name: 'isPreferredProduct',
                    field: 'isPreferredProduct',
                    displayName: 'Preferred Product',
                    headerTooltip: true,
                    width: "4%",
                    enableFiltering: false,
                    cellTemplate: '<div class="text-center abi-ui-grid-row-height"><span class="fa-stack" ng-if="row.entity.isPreferredProduct"><i class="fa fa-circle fa-stack-2x"></i><i class="fa fa-thumbs-up fa-stack-1x fa-inverse"></i></span><a ng-click="grid.appScope.PreferredProductService.displayPreferredProduct(row.entity)" ng-if="row.entity.mmcPreferredProductIdentifier && !row.entity.isPreferredProduct" title="Click to view preferred product information">View</a></div>'
                },
            ]
        };
    }

    public refreshClick(): any {
        this.$log.debug("%s - refresh clicked", this.controllerName);
        return this.AbiService.abiSearchResults;
    }
}