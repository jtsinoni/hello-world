'use strict';

import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {FacetOption} from "../_models/facetOption.model";
import {SearchConstants} from "../_constants/search.constants";

export class AbiSearchController {
    private controllerName: string = "ABi Search Controller";

    // @ngInject
    constructor(private $log, private $rootScope, private AbiService,
                private CategoryBreadcrumbsService, private CategoriesService,
                private FacetsService, private PreferredProductService, private ProductComparisonService,
                private SameProductGroupService, private SearchWithinResultsService,
                private SearchUtilService, private SelectedFacetOptionsBreadboxService,
                private SidePanelService, private SiteCatalogService) {

        // this.$log.debug("%s - Start", this.controllerName);
        $(window).scrollTop(0);

        let executeSearchEventId = this.SearchUtilService.buildEventId(
            SearchConstants.EVENT_MODULE_ABI,
            SearchConstants.EVENT_TARGET_COMPONENT_SEARCH,
            SearchConstants.EVENT_TARGET_METHOD_EXECUTE_SEARCH);

        let executeSearchEventHandler = this.$rootScope.$on(executeSearchEventId, (event: ng.IAngularEvent, data: FacetOption) => {
            //this.$log.debug("caught " + executeSearchEventId + " event");
            this.AbiService.lastFacetOptionUpdated = data;
            this.AbiService.executeSearch();
        });
        this.$rootScope.$on('$destroy', function () {
            executeSearchEventHandler();
        });

        this.AbiService.init();
    }
}