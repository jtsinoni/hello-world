'use strict';

import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;

export class PreferredProductController {
    private controllerName: string = "Preferred Product Controller";
    public previousState: string;

    // @ngInject
    constructor(private $log, private $rootScope, private $state,
                private PreferredProductService, private SearchUtilService,
                private SiteCatalogService, private StateConstants) {

        this.$log.debug("%s - Start", this.controllerName);
        $(window).scrollTop(0);
        this.previousState = this.$rootScope.previousState;
        this.SearchUtilService.setProductImageSrcs("selectedProduct", this.PreferredProductService.selectedProduct.productImages);
        this.SearchUtilService.setProductImageSrcs("preferredProduct", this.PreferredProductService.preferredProduct.productImages);
    }

    public switchPreferredProductImageSrc(thumbnailIndex: number) {
        this.SearchUtilService.switchProductImageSrc('preferredProduct', thumbnailIndex, this.PreferredProductService.preferredProduct.productImages)
    }

    public switchSelectedProductImageSrc(thumbnailIndex: number) {
        this.SearchUtilService.switchProductImageSrc('selectedProduct', thumbnailIndex, this.PreferredProductService.selectedProduct.productImages)
    }

    public goToPreviousState() {
        if (this.$rootScope.previousState) {
            this.$state.go(this.$rootScope.previousState);
        } else {
            this.$state.go(this.StateConstants.ABI_SEARCH);
        }
    }
}

