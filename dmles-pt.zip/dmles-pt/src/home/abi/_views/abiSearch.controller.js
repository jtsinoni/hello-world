define(["require", "exports", "../../../_constants/search.constants"], function (require, exports, search_constants_1) {
    'use strict';
    var AbiSearchController = (function () {
        // @ngInject
        function AbiSearchController($log, $rootScope, AbiService, CategoryBreadcrumbsService, CategoriesService, FacetsService, PreferredProductService, ProductComparisonService, SameProductGroupService, SearchWithinResultsService, SearchUtilService, SelectedFacetOptionsBreadboxService, SidePanelService, SiteCatalogService, uiGridConstants) {
            var _this = this;
            this.$log = $log;
            this.$rootScope = $rootScope;
            this.AbiService = AbiService;
            this.CategoryBreadcrumbsService = CategoryBreadcrumbsService;
            this.CategoriesService = CategoriesService;
            this.FacetsService = FacetsService;
            this.PreferredProductService = PreferredProductService;
            this.ProductComparisonService = ProductComparisonService;
            this.SameProductGroupService = SameProductGroupService;
            this.SearchWithinResultsService = SearchWithinResultsService;
            this.SearchUtilService = SearchUtilService;
            this.SelectedFacetOptionsBreadboxService = SelectedFacetOptionsBreadboxService;
            this.SidePanelService = SidePanelService;
            this.SiteCatalogService = SiteCatalogService;
            this.uiGridConstants = uiGridConstants;
            this.controllerName = "ABi Search Controller";
            this.abiSearchGridOpts = {};
            // this.$log.debug("%s - Start", this.controllerName);
            $(window).scrollTop(0);
            var executeSearchEventId = this.SearchUtilService.buildEventId(search_constants_1.SearchConstants.EVENT_MODULE_ABI, search_constants_1.SearchConstants.EVENT_TARGET_COMPONENT_SEARCH, search_constants_1.SearchConstants.EVENT_TARGET_METHOD_EXECUTE_SEARCH);
            var executeSearchEventHandler = this.$rootScope.$on(executeSearchEventId, function (event, data) {
                //this.$log.debug("caught " + executeSearchEventId + " event");
                _this.AbiService.lastFacetOptionUpdated = data;
                _this.AbiService.executeSearch();
            });
            this.$rootScope.$on('$destroy', function () {
                executeSearchEventHandler();
            });
            this.buildAbiSearchGridOpts();
            this.AbiService.init();
        }
        AbiSearchController.prototype.buildAbiSearchGridOpts = function () {
            this.abiSearchGridOpts = {
                appScopeProvider: this,
                data: null,
                enableCellEditOnFocus: false,
                enableColumnResizing: true,
                enableFiltering: true,
                enableGridMenu: true,
                enablePaginationControls: true,
                enableRowHeaderSelection: false,
                enableRowSelection: false,
                enableSelectAll: false,
                enableSorting: true,
                excessRows: 25,
                exporterCsvFilename: 'abiSearchSummaryResults.csv',
                minRowsToShow: 20,
                multiSelect: false,
                rowHeight: 25,
                showColumnFooter: true,
                showGridFooter: true,
                virtualizationThreshold: 20,
                columnDefs: [
                    {
                        name: 'productCompareSelected',
                        field: 'productCompareSelected',
                        displayName: 'Compare Products',
                        headerTooltip: true,
                        width: "5%",
                        enableFiltering: false,
                        cellTemplate: '<div class="abi-ui-grid-row-height">' +
                            '<input type="checkbox" ng-change="grid.appScope.ProductComparisonService.updateItemComparisonList(row.entity)" ng-model="row.entity.productCompareSelected">' +
                            '&nbsp;' +
                            '<a ng-class="{disabled: grid.appScope.ProductComparisonService.getItemComparisonList().length < 2}" ng-if="row.entity.productCompareSelected && grid.appScope.ProductComparisonService.getItemComparisonList().length > 0" ng-click="grid.appScope.ProductComparisonService.goToItemComparison()" title="Click here to view product comparison">View</a>' +
                            '</div>'
                    },
                    {
                        name: 'longItemDescription',
                        field: 'longItemDescription',
                        displayName: 'Long Item Description',
                        cellTooltip: true,
                        headerTooltip: true,
                        width: "46%"
                    },
                    {
                        name: 'enterpriseProductIdentifier',
                        field: 'enterpriseProductIdentifier',
                        displayName: 'Enterprise Product Identifier',
                        cellTooltip: true,
                        headerTooltip: true,
                        width: "6%",
                        cellTemplate: '<div class="text-center abi-ui-grid-row-height"><a ng-click="grid.appScope.AbiService.goToDetails(row.entity)" title="Click to view this product\'s details">{{row.entity.enterpriseProductIdentifier}}</a></div>'
                    },
                    {
                        name: 'manufacturer',
                        field: 'manufacturer',
                        displayName: 'Manufacturer',
                        cellTooltip: true,
                        headerTooltip: true,
                        width: "10%"
                    },
                    {
                        name: 'manufacturerCatalogNumber',
                        field: 'manufacturerCatalogNumber',
                        displayName: 'Manufacturer Catalog Number',
                        cellTooltip: true,
                        headerTooltip: true,
                        width: "10%"
                    },
                    {
                        name: 'ndc',
                        field: 'ndc',
                        displayName: 'National Drug Code (NDC)',
                        cellTooltip: true,
                        headerTooltip: true,
                        width: "5%"
                    },
                    {
                        name: 'productStatus',
                        field: 'productStatus',
                        displayName: 'Product Status',
                        cellTooltip: true,
                        headerTooltip: true,
                        width: "5%"
                    },
                    {
                        name: 'numberOfSitesUsingThisAbiProduct',
                        field: 'numberOfSitesUsingThisAbiProduct',
                        displayName: 'Site Catalog Records',
                        headerTooltip: true,
                        width: "5%",
                        enableFiltering: false,
                        cellTemplate: '<div class="abi-ui-grid-row-height"><a ng-click="grid.appScope.SiteCatalogService.displaySiteCatalogItems(row.entity)" ng-if="row.entity.mmcProductIdentifier && row.entity.numberOfSitesUsingThisAbiProduct > 0" title="Click to view this product\'s Site Catalog records">View <span class="badge">{{row.entity.numberOfSitesUsingThisAbiProduct}}</span></a></div>'
                    },
                    {
                        name: 'otherProducts',
                        displayName: 'Other Products',
                        headerTooltip: true,
                        width: "4%",
                        enableFiltering: false,
                        cellTemplate: '<div class="text-center abi-ui-grid-row-height"><a ng-click="grid.appScope.SameProductGroupService.displayProductsInSameProductGroup(row.entity)" ng-if="row.entity.spDrugCode" title="Click to view other products in the same product group">View</a></div>'
                    },
                    {
                        name: 'isPreferredProduct',
                        field: 'isPreferredProduct',
                        displayName: 'Preferred Product',
                        headerTooltip: true,
                        width: "4%",
                        enableFiltering: false,
                        cellTemplate: '<div class="text-center abi-ui-grid-row-height"><span class="fa-stack" ng-if="row.entity.isPreferredProduct"><i class="fa fa-circle fa-stack-2x"></i><i class="fa fa-thumbs-up fa-stack-1x fa-inverse"></i></span><a ng-click="grid.appScope.PreferredProductService.displayPreferredProduct(row.entity)" ng-if="row.entity.mmcPreferredProductIdentifier && !row.entity.isPreferredProduct" title="Click to view preferred product information">View</a></div>'
                    },
                ]
            };
        };
        AbiSearchController.prototype.refreshClick = function () {
            this.$log.debug("%s - refresh clicked", this.controllerName);
            return this.AbiService.abiSearchResults;
        };
        return AbiSearchController;
    }());
    exports.AbiSearchController = AbiSearchController;
});
//# sourceMappingURL=abiSearch.controller.js.map