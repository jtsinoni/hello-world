'use strict';

import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;

export class ProductDetailsController {
    private controllerName: string = "Product Details Controller";
    public previousState: string;

    // @ngInject
    constructor(private $log, private $rootScope, private $state,
                private AbiService, private datatableService,
                private NotificationService, private PreferredProductService,
                private SameProductGroupService, private SearchUtilService,
                private SiteCatalogService, private StateConstants) {

        this.$log.debug("%s - Start", this.controllerName);
        $(window).scrollTop(0);
        this.previousState = this.$rootScope.previousState;
        this.SearchUtilService.setProductImageSrcs("primaryProduct", this.AbiService.abiProduct.productImages);
    }

    public switchProductImageSrc(thumbnailIndex: number) {
        this.SearchUtilService.switchProductImageSrc('primaryProduct', thumbnailIndex, this.AbiService.abiProduct.productImages)
    }


    public goToAbiCatalogSearch() {
        this.$state.go(this.StateConstants.ABI_SEARCH);
    }
}

