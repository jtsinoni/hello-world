'use strict';

export class ProductsInSameProductGroupController {
    private controllerName:string = "Products In Same Product Group Controller";
    public previousState:string;

    // @ngInject
    constructor(private $log, private $rootScope, private $state, 
                private AbiService, private SameProductGroupService, 
                private SelectedProductService, private StateConstants) {

        this.$log.debug("%s - Start", this.controllerName);
        $(window).scrollTop(0);
        this.previousState = this.$rootScope.previousState;
    }

    public goToPreviousState() {
        if (this.$rootScope.previousState) {
            this.$state.go(this.$rootScope.previousState);
        } else {
            this.$state.go(this.StateConstants.ABI_PRODUCT_DETAILS);
        }
    }
}

