'use strict';

export class AbiSearchHelpController {
    
    private controllerName: string = "ABi Search Help Controller";
    public previousState:string;

    // @ngInject
    constructor(private $log, private $rootScope, private $state, private StateConstants) {
        this.$log.debug("%s - Start", this.controllerName);
        $(window).scrollTop(0);
        this.previousState = this.$rootScope.previousState;
    }

    public goToPreviousState() {
        if (this.$rootScope.previousState) {
            this.$state.go(this.$rootScope.previousState);
        } else {
            this.$state.go(this.StateConstants.ABI_SEARCH);
        }
    }
}