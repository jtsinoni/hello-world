'use strict';
import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;

export class ProductsSiteCatalogItemsController {
    private controllerName: string = "Product's Site Catalog Items Controller";
    public previousState: string;


    // @ngInject
    constructor(private $log, private $rootScope, private $state,
                private SelectedProductService, private SiteCatalogService,
                private StateConstants, private SystemService) {

        this.$log.debug("%s - Start", this.controllerName);
        $(window).scrollTop(0);
        this.previousState = this.$rootScope.previousState;        
    }   

    public goToPreviousState() {
        if (this.$rootScope.previousState) {
            this.$state.go(this.$rootScope.previousState);
        } else {
            this.$state.go(this.StateConstants.ABI_SEARCH);
        }
    }
}

