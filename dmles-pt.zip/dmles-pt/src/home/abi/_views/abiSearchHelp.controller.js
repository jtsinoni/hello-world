define(["require", "exports"], function (require, exports) {
    'use strict';
    var AbiSearchHelpController = (function () {
        // @ngInject
        function AbiSearchHelpController($log, $rootScope, $state, StateConstants) {
            this.$log = $log;
            this.$rootScope = $rootScope;
            this.$state = $state;
            this.StateConstants = StateConstants;
            this.controllerName = "ABi Search Help Controller";
            this.$log.debug("%s - Start", this.controllerName);
            $(window).scrollTop(0);
            this.previousState = this.$rootScope.previousState;
        }
        AbiSearchHelpController.prototype.goToPreviousState = function () {
            if (this.$rootScope.previousState) {
                this.$state.go(this.$rootScope.previousState);
            }
            else {
                this.$state.go(this.StateConstants.ABI_SEARCH);
            }
        };
        return AbiSearchHelpController;
    }());
    exports.AbiSearchHelpController = AbiSearchHelpController;
});
//# sourceMappingURL=abiSearchHelp.controller.js.map