'use strict';

export class ShellController {
    private viewName: string;    

    // @ngInject
    constructor() {
        this.init();
    }
    
    init(){
        this.viewName = 'Shell View';
    }
}