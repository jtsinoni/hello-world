'use strict';

import {SearchConstants} from './search.constants';

let constantModule = angular.module('Dmles.Home.Abi.Constants.Module', []);
constantModule.constant('SearchConstants', SearchConstants);

export default constantModule;