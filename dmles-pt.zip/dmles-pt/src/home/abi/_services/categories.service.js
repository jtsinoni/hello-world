define(["require", "exports", "./category.service"], function (require, exports, category_service_1) {
    'use strict';
    var CategoriesService = (function () {
        // @ngInject
        function CategoriesService($log, $rootScope, SearchUtilService, TaxonomyService) {
            this.$log = $log;
            this.$rootScope = $rootScope;
            this.SearchUtilService = SearchUtilService;
            this.TaxonomyService = TaxonomyService;
            this.categories = [];
            var unspscCategoryConfiguration = {
                displayLabel: "Product Category",
                aggregationIdentifiers: ["unspscSegments", "unspscFamilies", "unspscClasses", "unspscCommodities"],
                elasticSearchFieldNames: ["unspscSegment", "unspscFamily", "unspscClass", "unspscCommodity"],
                initializeAsCollapsed: false,
                topLevelInitialCategoryOptions: this.TaxonomyService.retrieveUnspscSegments()
            };
            this.categories.push(new category_service_1.Category($log, $rootScope, unspscCategoryConfiguration, SearchUtilService));
            var productCategoryConfiguration = {
                displayLabel: "Product Type",
                aggregationIdentifiers: ["productNouns", "productTypes"],
                elasticSearchFieldNames: ["productNoun", "productType"],
                initializeAsCollapsed: false,
                topLevelInitialCategoryOptions: this.TaxonomyService.retrieveProductNouns()
            };
            this.categories.push(new category_service_1.Category($log, $rootScope, productCategoryConfiguration, SearchUtilService));
        }
        CategoriesService.prototype.getCategories = function () {
            return this.categories;
        };
        return CategoriesService;
    }());
    exports.CategoriesService = CategoriesService;
});
//# sourceMappingURL=categories.service.js.map