'use strict';

import {CategoryOption} from "../_models/categoryOption.model";
import {CategoryConfiguration} from "../_models/categoryConfiguration.model";
import {Category} from "./category.service";

export class CategoriesService {

    public categories: Array<any> = [];

    // @ngInject
    constructor(private $log, private $rootScope, private SearchUtilService, private TaxonomyService) {

        let unspscCategoryConfiguration: CategoryConfiguration = {
            displayLabel: "Product Category",
            aggregationIdentifiers: ["unspscSegments", "unspscFamilies", "unspscClasses", "unspscCommodities"],
            elasticSearchFieldNames: ["unspscSegment", "unspscFamily", "unspscClass", "unspscCommodity"],
            initializeAsCollapsed: false,
            topLevelInitialCategoryOptions: this.TaxonomyService.retrieveUnspscSegments()
        };
        this.categories.push(new Category($log, $rootScope, unspscCategoryConfiguration, SearchUtilService));

        let productCategoryConfiguration: CategoryConfiguration = {
            displayLabel: "Product Type",
            aggregationIdentifiers: ["productNouns", "productTypes"],
            elasticSearchFieldNames: ["productNoun", "productType"],
            initializeAsCollapsed: false,
            topLevelInitialCategoryOptions: this.TaxonomyService.retrieveProductNouns()
        };
        this.categories.push(new Category($log, $rootScope, productCategoryConfiguration, SearchUtilService));
    }

    public getCategories(): Array<CategoryOption> {
        return this.categories;
    }
}