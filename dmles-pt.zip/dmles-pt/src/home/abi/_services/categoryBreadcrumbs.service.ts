'use strict';

import {CategoryOption} from "../_models/categoryOption.model";
import {CategoryBreadcrumb} from "./categoryBreadcrumb.service";

export class CategoryBreadcrumbsService {

    public categoryBreadcrumbs: Array<any> = [];

    // @ngInject
    constructor(private $log, private $rootScope, private SearchUtilService) {

        let displayLabel: string = "";

        displayLabel = "Product Category";
        this.categoryBreadcrumbs.push(new CategoryBreadcrumb($log, $rootScope, displayLabel, SearchUtilService));

        displayLabel = "Product Type";
        this.categoryBreadcrumbs.push(new CategoryBreadcrumb($log, $rootScope, displayLabel, SearchUtilService));
    }

    public getCategoryBreadcrumbs(): Array<CategoryOption> {
        return this.categoryBreadcrumbs;
    }


    public areCategoryOptionsSelected(): boolean {
        let returnValue: boolean = false;

        for (let i: number = 0; i < this.categoryBreadcrumbs.length; i++) {
            let categoryBreadcrumb = this.categoryBreadcrumbs[i];
            if (categoryBreadcrumb.getSelectedCategoryOptions().length > 0) {
                returnValue = true;
            }
        }
        return returnValue;
    }

    public clearAllBreadcrumbs() {
        for (let i: number = 0; i < this.categoryBreadcrumbs.length; i++) {
            let categoryBreadcrumb = this.categoryBreadcrumbs[i];
            categoryBreadcrumb.clearSelectedCategoryOptions();

            // don't executeSearch here - the calling method handles it
            let executeSearch: boolean = false;
            categoryBreadcrumb.clearAllCategoryOptionSelections(executeSearch);
        }
    }
}