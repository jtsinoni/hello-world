define(["require", "exports", "../_models/abiProduct.model"], function (require, exports, abiProduct_model_1) {
    'use strict';
    var SelectedProductService = (function () {
        // @ngInject
        function SelectedProductService($log) {
            this.$log = $log;
            this.serviceName = "Selected Product Service";
            this.selectedProduct = null;
        }
        SelectedProductService.prototype.setSelectedProduct = function (abiProduct) {
            this.selectedProduct = new abiProduct_model_1.AbiProduct();
            this.selectedProduct = abiProduct;
            this.$log.debug("setSelectedProduct - this.selectedProduct %s", JSON.stringify(this.selectedProduct));
        };
        return SelectedProductService;
    }());
    exports.SelectedProductService = SelectedProductService;
});
//# sourceMappingURL=selectedProduct.service.js.map