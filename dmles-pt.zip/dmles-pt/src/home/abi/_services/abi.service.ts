'use strict';

import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {ApiService} from '../../../_services/api.service';
import {AbiProduct} from "../_models/abiProduct.model";
import {FacetOption} from "../../../_models/facetOption.model";

export interface IAbiService {

}

export class AbiService extends ApiService implements IAbiService {
    private abiProduct: AbiProduct = new AbiProduct();
    private serviceName: string = "ABi Service";

    public showFullUnspsc: boolean = false;

    public searchInput: string = "";
    public previousSearchInput: string = "";
    private userSpecifiedFilters: string = "";

    public searchMaxResultsText: string;
    public searchPlaceholder: string = "What are you looking for? Try searching with ABi ...";
    private searchStats: any = {};
    public abiSearchStats: string;
    public isLoadingSearch: boolean;
    public showMaxResultsWarning: boolean;
    public MAX_RESULTS_TO_ATTEMPT_FACET_BUILDING: number = 2500;

    public abiSearchResults: Array<AbiProduct> = [];
    public abiAggregations: any = {};

    public lastFacetOptionUpdated: FacetOption = null;

    // @ngInject
    constructor($http, $httpParamSerializerJQLike, $log, Authentication,
                private $state, private AbiGridStateService, private AbiCategoryBreadcrumbsService,
                private AbiCategoriesService, private AbiFacetsService,
                private AbiSearchWithinResultsService, private AbiSelectedFacetOptionsBreadboxService,
                private ContentConstants, private DmlesGridService,
                private NotificationService, private ProductComparisonService,
                private StateConstants, private UtilService) {

        super($http, $log, Authentication, $httpParamSerializerJQLike, "ABiProductionManagement");
        this.$log.debug("%s - Start", this.serviceName);

        this.searchMaxResultsText = "Over " + this.ContentConstants.SEARCH_MAX + " items have been found, please refine your search";
    }

    public clearAbiProduct() {
        this.abiProduct = null;
    }

    public getAbiProduct() {
        if (this.abiProduct) {
            return this.abiProduct;
        }
        return null;
    }

    public setAbiProduct(item): void {
        this.abiProduct = new AbiProduct(angular.copy(item));
    }

    public buildAggregationsRequest(): string {

        // check to see if category option has been selected
        let isCategoryOptionSelected: boolean = false;
        angular.forEach(this.AbiCategoriesService.getCategories(), (category) => {
            if (category.selectedCategoryOptions.length > 0) {
                isCategoryOptionSelected = true;
            }
        });

        let aggregationsRequest: string = "";

        //this.$log.debug("buildAggregationsRequest() - this.searchInput: (%s)", JSON.stringify(this.searchInput));
        //this.$log.debug("buildAggregationsRequest() - this.userSpecifiedFilters: (%s)", JSON.stringify(this.userSpecifiedFilters));
        //this.$log.debug("buildAggregationsRequest() - isCategoryOptionSelected: (%d)", isCategoryOptionSelected);

        if (this.searchInput || this.userSpecifiedFilters || isCategoryOptionSelected) {
            angular.forEach(this.AbiFacetsService.getFacets(), (facet) => {
                aggregationsRequest += facet.facetConfiguration.aggregationIdentifier + ' as '
                    + facet.facetConfiguration.elasticSearchFieldName + '.keyword size 5000, ';
            });
        } else {
            // when we are just getting started and the user hasn't entered any search term or selected any category
            // we want to minimize the aggregations we build to just those associated with building up category levels
            angular.forEach(this.AbiFacetsService.getCategoryFacets(), (facet) => {
                aggregationsRequest += facet.facetConfiguration.aggregationIdentifier + ' as '
                    + facet.facetConfiguration.elasticSearchFieldName + '.keyword size 5000, ';
            });
        }

        // strip off final comma and space characters
        //this.$log.debug("buildAggregationsRequest() before - aggregationsRequest: (%s)", JSON.stringify(aggregationsRequest));
        aggregationsRequest = aggregationsRequest.substr(0, aggregationsRequest.length - 2);
        //this.$log.debug("buildAggregationsRequest() after - aggregationsRequest: (%s)", JSON.stringify(aggregationsRequest));

        this.$log.debug("buildAggregationsRequest() - aggregationsRequest: (%s)", JSON.stringify(aggregationsRequest));
        return aggregationsRequest;
    }

    public buildUserSpecifiedFilters() {
        this.userSpecifiedFilters = "";

        angular.forEach(this.AbiSearchWithinResultsService.getSearchWithinResultsKeywords(), (keyword) => {
            this.userSpecifiedFilters = this.userSpecifiedFilters.trim() + " AND " + keyword;
        });

        angular.forEach(this.AbiCategoriesService.getCategories(), (category) => {
            this.userSpecifiedFilters = this.userSpecifiedFilters.trim()
                + " " + category.buildSearchClause(category.categoryConfiguration.elasticSearchFieldNames);
        });

        angular.forEach(this.AbiFacetsService.getFacets(), (facet) => {
            this.userSpecifiedFilters = this.userSpecifiedFilters.trim()
                + " " + facet.buildSearchClause(facet.facetConfiguration.elasticSearchFieldName);
        });

        this.userSpecifiedFilters = this.userSpecifiedFilters.trim();
    }

    public cleanUpFacetsAndCategories() {
        // clean up the facets by sending an event to the breadbox component and telling it to clear all facets
        this.AbiSelectedFacetOptionsBreadboxService.clearAllSelectedFacetOptions();

        // reinitialize 
        this.lastFacetOptionUpdated = null;

        // clear the categories by sending each category component telling it to reinitialize 
        // which also handles clearing the associated category breadcrumb        
        angular.forEach(this.AbiCategoriesService.getCategories(), (category) => {
            category.clearAllCategoryOptionSelections(false);
        });
    }

    public cleanUpForNewSearch() {
        // if searchInput changes, clear out all facet-related stuff
        if ((this.searchInput != null) && this.searchInput !== this.previousSearchInput) {
            this.previousSearchInput = this.searchInput;
            this.cleanUpFacetsAndCategories();
        }

        // every time we do a search - reset the product comparison array
        this.ProductComparisonService.clearItemComparisonList();
        this.ProductComparisonService.clearItemComparisonPrimaryImageList();

        // clear the ABi Search Summary Results grid state
        this.AbiGridStateService.clearSearchSummaryResultsGridState();

        // this seems to be the best way to definitely get the grid back to its original state
        this.DmlesGridService.restoreProvidedGridState(this.AbiGridStateService.originalSearchSummaryResultsGridState);

        this.isLoadingSearch = true;
        this.abiSearchStats = "";
    }

    public displaySecondaryAbiSearchSummaryResults(fields: Array<string>, abiProduct: AbiProduct) {
        this.previousSearchInput = "reset";
        this.searchInput = "";

        for (let i = 0; i < fields.length; i++) {
            if (i > 0) {
                this.searchInput += " AND ";
            }
            this.searchInput += fields[i] + ".keyword EQ '" + abiProduct[fields[i]].replace(/[!@#$%^&()+=\-[\]\\';,./{}|":<>?~_]/g, "\\$&") + "'";
        }
        this.searchInput = "(" + this.searchInput + ")";

        this.userSpecifiedFilters = "";
        this.cleanUpForNewSearch();
        this.getCatalogItems();
        this.goToAbiCatalogSearch();
    }

    public executeSearch() {
        //this.$log.debug("executeSearch() - this.searchInput: %s", this.searchInput);
        //this.$log.debug("executeSearch() - this.previousSearchInput: %s", this.previousSearchInput);
        //this.$log.debug("executeSearch() - this.userSpecifiedFilters: %s", JSON.stringify(this.userSpecifiedFilters));

        this.cleanUpForNewSearch();
        this.buildUserSpecifiedFilters();
        this.getCatalogItems();
    }

    public getCatalogItems() {
        this.$log.debug("getCatalogItems() - this.searchInput: %s", JSON.stringify(this.searchInput));
        this.$log.debug("getCatalogItems() - this.userSpecifiedFilters: %s", JSON.stringify(this.userSpecifiedFilters));

        this.getSummaryAbiProducts(
            this.searchInput,
            this.userSpecifiedFilters,
            this.buildAggregationsRequest()).then((response: IHttpPromiseCallbackArg<any>) => {

            if (response) {
                //this.$log.debug("getCatalogItems() - response: %s", JSON.stringify(response));

                this.abiAggregations = this.parseSummaryAbiProductAggregations(response);
                //this.$log.debug("this.abiAggregations: %s", JSON.stringify(this.abiAggregations));

                this.abiSearchResults = this.parseAbiProductSummaryResults(response);
                //this.$log.debug("this.abiSearchResults: %s", JSON.stringify(this.abiSearchResults));

                this.sortByIsPreferredProduct(this.abiSearchResults);
                // this.$log.debug("this.abiSearchResults: %s", JSON.stringify(this.abiSearchResults));

                // this.exportAbiSummarySearchResults = this.createExportableAbiSummaryResults(this.abiSearchResults);

                this.searchStats = this.getSearchStats(response);

                this.populateFiltersAndResultsTable();

                if (this.abiSearchResults.length === 0) {
                    if (this.searchInput === "" && this.userSpecifiedFilters === "") {
                        // no error message displayed
                    } else {
                        if (this.searchInput === "") {
                            this.$log.debug('%s - No results were found.', this.serviceName);
                            this.NotificationService.warningMsg('No results were found.');
                        } else {
                            this.$log.debug('%s - We found 0 results for "%s".  Try using different search terms and/or use the filters on the side panel to narrow in on your results.', this.serviceName, this.searchInput);
                            this.NotificationService.warningMsg('We found 0 results for "' + this.searchInput + '".  Try using different search terms and/or use the filters on the side panel to narrow in on your results.');
                        }
                    }
                }
            } else {
                this.$log.debug("no response yet");
            }

        }, (errResponse: IHttpPromiseCallbackArg<boolean>) => {
            this.isLoadingSearch = false;
            this.$log.debug("errResponse.toString() = %s", errResponse.toString());
            if (errResponse.toString().indexOf("SyntaxError: JSON.parse: unexpected character at line 1 column 1 of the JSON data") == 0) {
                this.$log.debug("%s - Error getting ABi product summary results from elastic.  Error message received from BT", this.serviceName);
                this.NotificationService.errorMsg("A Business Tier error occurred while retrieving ABi product summary results");
            } else {
                this.$log.debug("%s - Error getting ABi product summary results from elastic.", this.serviceName);
                this.NotificationService.errorMsg("An error occurred while retrieving ABi product summary results");
            }
        });
    }

    public getSearchStats(result) {
        let retVal = {
            "total": 0,
            "time": 0.00
        };

        if (result && result.data && result.data.total) {
            if (result.data.total) {
                retVal.total = result.data.total;
            }

            if (result.data.took) {
                retVal.time = result.data.took;
            }
        }
        else {
            this.$log.debug("%s - Warning: No data returned", this.serviceName);
        }
        return retVal;
    }

    public getSummaryAbiProducts(searchValue: string, userSpecifiedFilters: string, aggregationsRequest: string) {
        this.$log.debug("getSummaryAbiProducts() - searchValue: %s", JSON.stringify(searchValue));
        this.$log.debug("getSummaryAbiProducts() - userSpecifiedFilters: %s", JSON.stringify(userSpecifiedFilters));

        //Note: check to see if anything got sent through, otherwise a string 'undefined' will be sent to bt.
        let updatedSearchValue: string = (searchValue) ? searchValue : "";
        let updatedUserSpecifiedFilters: string = (userSpecifiedFilters) ? userSpecifiedFilters : "";

        if (updatedSearchValue === "" || updatedSearchValue.length < 3) {
            if (updatedUserSpecifiedFilters) {
                // if updateSearchValue is invalid and updatedUserSpecifiedFilters are valid, then use updatedUserSpecifiedFilters
                updatedSearchValue = updatedUserSpecifiedFilters;
            } else {
                // if updateSearchValue and updatedUserSpecifiedFilters are invalid, then set searchValue to value that
                // results in a response of no results
                updatedSearchValue = "(noResultsSearch EQ 'Y')";
            }
        } else {
            // per consensus of BAs and dev leads, make free text searches partial word searches by adding an
            // asterisk to the beginning and each of each word

            // Also, OR the partial word searches - for now - I'm not convinced this is really what we want to do

            // need to deal with possibility of words being enclosed in double quotes - where we would do an exact search as opposed to a partial word search

            // need to deal with user entering multiple words - need to add the asterisks to each word
            this.$log.debug("updatedSearchValue: %s", JSON.stringify(updatedSearchValue));

            // don't add the free text asterisks if we are doing a secondary search for unspscCommodity or productType
            if ((updatedSearchValue.lastIndexOf("unspscCommodity") >= 0) || (updatedSearchValue.lastIndexOf("productType") >= 0)) {
                // do not add asterisks since we are doing a secondary search
            } else {
                let updatedSearchValueArray: Array<string> = updatedSearchValue.split(" ");
                updatedSearchValue = "";
                for (let i = 0; i < updatedSearchValueArray.length; i++) {
                    if (i === updatedSearchValueArray.length - 1) {
                        updatedSearchValue += '*' + updatedSearchValueArray[i] + '* ';
                    } else {
                        updatedSearchValue += '*' + updatedSearchValueArray[i] + '* AND ';
                    }
                }
                updatedSearchValue = updatedSearchValue.trim();
                this.$log.debug("updatedSearchValue: %s", JSON.stringify(updatedSearchValue));
            }

            if (updatedUserSpecifiedFilters) {
                // if updateSearchValue and updatedUserSpecifiedFilters are valid,
                // then set searchValue to updatedSearchValue + updatedUserSpecifiedFilters
                updatedSearchValue = updatedSearchValue + " " + updatedUserSpecifiedFilters;
            } else {
                // if updateSearchValue is valid and updatedUserSpecifiedFilters are invalid, then use updatedSearchValue
                updatedSearchValue = updatedSearchValue;
            }
        }

        if (updatedSearchValue) {
            this.$log.debug("getSummaryAbiProducts() - updatedSearchValue - before: %s", JSON.stringify(updatedSearchValue));
            // if updatedSearchValue begins with "AND " - strip it off
            if (updatedSearchValue.indexOf("AND ") === 0) {
                updatedSearchValue = updatedSearchValue.substr("AND ".length);
            }

            this.$log.debug("getSummaryAbiProducts() - updatedSearchValue - after: %s", JSON.stringify(updatedSearchValue));
            this.$log.debug("getSummaryAbiProducts() - aggregationsRequest: %s", JSON.stringify(aggregationsRequest));

            let searchInput = {
                "queryString": updatedSearchValue,
                "aggregations": aggregationsRequest
            };

            let action: string = "getABiCatalogRecordESResults";
            return this.post(action, searchInput);

        } else {
            return null;
        }
    };

    public goToAbiCatalogSearch() {
        this.$state.go(this.StateConstants.ABI_SEARCH);
    }

    public goToDetails(abiProduct) {
        //this.$log.debug("goToDetails - abiProduct: %s", JSON.stringify(abiProduct));
        this.setAbiProduct(abiProduct);
        this.$log.debug("goToDetails - this.abiProduct: %s", JSON.stringify(this.abiProduct));
        this.AbiGridStateService.searchSummaryResultsGridState = this.DmlesGridService.retrieveGridState();
        this.$log.debug("goToDetails - this.searchSummaryResultsGridState: %s", JSON.stringify(this.AbiGridStateService.searchSummaryResultsGridState));
        this.$state.go(this.StateConstants.ABI_PRODUCT_DETAILS);
    }

    public goToSearchHelp() {
        this.AbiGridStateService.searchSummaryResultsGridState = this.DmlesGridService.retrieveGridState();
        this.$state.go(this.StateConstants.ABI_SEARCH_HELP);
    }

    //
    // functions that reference the individual Filter-related services
    //
    public init() {

        angular.forEach(this.AbiCategoriesService.getCategories(), (category) => {
            category.initialize();
        });

        angular.forEach(this.AbiCategoryBreadcrumbsService.getCategoryBreadcrumbs(), (categoryBreadcrumb) => {
            categoryBreadcrumb.clearSelectedCategoryOptions();
        });

        angular.forEach(this.AbiFacetsService.getFacets(), (facet) => {
            facet.initialize();
        });

        // initialize the Selected Facet Option Breadbox to empty
        this.AbiSelectedFacetOptionsBreadboxService.clearSelectedFacetOptions();

        this.searchInput = "";
        this.executeSearch();
    }

    public parseAbiProductSummaryResults(results): Array<AbiProduct> {
        // this.$log.debug("results: %s", JSON.stringify(results));
        let arrayAbiProduct: Array<AbiProduct> = [];

        if (results && results.data.hits.fields) {
            let abiProductSearchResults = results.data.hits.fields;
            // this.$log.debug("abiProductSearchResults: %s", JSON.stringify(abiProductSearchResults));
            for (let i = 0; i < abiProductSearchResults.length; i++) {
                let abiProductSearchResult = abiProductSearchResults[i];
                // this.$log.debug("abiProductSearchResult: %s", JSON.stringify(abiProductSearchResult));
                this.processAbiProductSearchResult(abiProductSearchResult, arrayAbiProduct, i);
            }
        } else {
            this.$log.warn("%s - Warning: No ES data returned", this.serviceName);
        }
        return arrayAbiProduct;
    }

    public parseSummaryAbiProductAggregations(results) {
        let abiProductAggregations: any = {};

        if (results && results.data.aggregations) {
            abiProductAggregations = results.data.aggregations;
        } else {
            this.$log.warn("%s - Warning: No aggregations returned", this.serviceName);
        }

        return abiProductAggregations;
    }

    private populateFiltersAndResultsTable() {
        this.showMaxResultsWarning = false;
        this.populateCategoriesPerCurrentResults();

        this.$log.debug("this.searchStats.total: %d", this.searchStats.total);
        // only build facets if number of search results are less than 5000
        if (this.searchStats.total < this.MAX_RESULTS_TO_ATTEMPT_FACET_BUILDING) {
            this.populateFacetsPerCurrentResults();
        }

        // this.ngAbiSummaryResultsTable = this.datatableService.createNgTable(this.abiSearchResults);

        if (this.ContentConstants.SEARCH_MAX <= this.abiSearchResults.length) {
            this.abiSearchStats = this.UtilService.esBuildSearchStatsStr(this.searchStats.total, this.searchStats.time);
            this.showMaxResultsWarning = true;
            this.NotificationService.warningMsg("The maximum search results were reached, please refine your search.");
        } else {
            this.abiSearchStats = this.UtilService.esBuildSearchStatsStr(this.abiSearchResults.length, this.searchStats.time);
        }
        this.isLoadingSearch = false;
    }

    private processAbiProductSearchResult(abiProductSearchResult: any, arrayAbiProduct: Array<AbiProduct>, i: number): void {

        let abiProduct: AbiProduct = new AbiProduct();
        for (let key in abiProductSearchResult) {
            let value: any = abiProductSearchResult[key];
            abiProduct[key] = value;
        }

        // set isPreferredProduct (boolean - easier to work with) based on preferredProductIndicator
        if (abiProduct.preferredProductIndicator === 'Y') {
            abiProduct.isPreferredProduct = true;
        }

        // if no productImages came in via database - set to imageNotAvailable
        if (abiProduct.productImages.length === 0) {
            abiProduct.productImages = ["/src/content/images/imageNotAvailable.jpg"];
        }

        // this.$log.debug("abiProduct: %s", JSON.stringify(abiProduct));
        arrayAbiProduct.push(abiProduct);
    }

    public populateCategoriesPerCurrentResults() {

        // determine the number of categories that have options selected within it
        let numberOfCategoriesWithOptionsSelected: number = 0;
        angular.forEach(this.AbiCategoriesService.getCategories(), (category) => {
            if (category.selectedCategoryOptions.length > 0) {
                numberOfCategoriesWithOptionsSelected++;
            }
        });
        this.$log.debug("populateCategoriesPerCurrentResults() - numberOfCategoriesWithOptionsSelected = " + numberOfCategoriesWithOptionsSelected);

        angular.forEach(this.AbiCategoriesService.getCategories(), (category) => {
            category.populate(category, numberOfCategoriesWithOptionsSelected, this.abiAggregations, this.abiSearchResults.length);
        });
    }

    private populateFacetsPerCurrentResults() {
        angular.forEach(this.AbiFacetsService.getFacets(), (facet) => {

            // if THIS facet has any facet options selected
            if (facet.isAnOptionSelected()) {

                // if the last user facet-effecting action was one that updated a specific facet option
                if (this.lastFacetOptionUpdated) {

                    // if the last facet option that was updated belongs to THIS facet
                    if (this.lastFacetOptionUpdated.type === facet.facetConfiguration.displayLabel) {

                        // this.$log.debug("populateFacetsPerCurrentResults() - this.lastFacetOptionUpdated = %s: " + JSON.stringify(this.lastFacetOptionUpdated));

                        // if THIS facet has ever had the counts associated with its facet options updated
                        if (facet.haveFacetOptionCountsBeenUpdated) {

                            // since we've already updated this facet's option counts once (probably due the fact
                            // that another facet was interacted with), go ahead and update them again
                            facet.updateExistingFacetOptionCounts(this.abiAggregations);
                        } else {

                            // leave the facet options and counts as is - usually you are here when only one facet has
                            // been interacted with so far, leave as is so the user sees the original facet options and
                            // counts that were generated just using the user input search string
                        }

                        // the last facet option that was updated belongs to a different facet
                    } else {

                        // update THIS facet's existing facet options with new counts
                        facet.updateExistingFacetOptionCounts(this.abiAggregations);
                    }

                    // the last user facet-effecting action was a Clear All or something that didn't effect a specific facet
                } else {

                    // update THIS facet's existing facet options with new counts
                    facet.updateExistingFacetOptionCounts(this.abiAggregations);
                }

                // THIS facet has no facet options currently selected
            } else {

                // reinitialize THIS facet's options and counts with the latest aggregation results
                facet.populate(this.abiAggregations);
            }
        });
    }

    private sortByIsPreferredProduct(data) {
        return data.sort(function (a, b) {
            return b.isPreferredProduct - a.isPreferredProduct;
        });
    }

    public toggleShowFullUnspsc() {
        if (this.showFullUnspsc === true) {
            this.showFullUnspsc = false;
        } else {
            this.showFullUnspsc = true;
        }
    }
}