'use strict';

import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {ApiService} from '../../../_services/api.service';
import {AbiProduct} from "../_models/abiProduct.model";
import {FacetOption} from "../_models/facetOption.model";

export interface IAbiService {

}

export class AbiService extends ApiService implements IAbiService {
    private abiProduct: AbiProduct = new AbiProduct();
    private serviceName: string = "ABi Service";

    public contentType: string;
    public downloadFileInfo: any = null;

    public showFullUnspsc: boolean = false;

    public searchInput: string = "";
    public previousSearchInput: string = "";
    private userSpecifiedFilters: string = "";

    public searchMaxResultsText: string;
    public searchPlaceholder: string = "What are you looking for? Try searching with ABi ...";
    public sortOrder: string = "longItemDescription";
    private searchStats: any = {};
    public abiSearchStats: string;
    public isLoadingSearch: boolean;
    public showMaxResultsWarning: boolean;
    public MAX_RESULTS_TO_ATTEMPT_FACET_BUILDING: number = 2500;

    public abiSearchResults: Array<AbiProduct> = [];
    public abiAggregations: any = {};

    public abiSummarySearchResultsTableTitle: string = "ABi Summary Search Results";
    public canFilterGlobal: boolean = false;
    public canRefresh: boolean = false;
    public canExport: boolean = true;
    public ngAbiSummaryResultsTable: any = null;

    public lastFacetOptionUpdated: FacetOption = null;

    public exportFilename: string = "abiSummarySearchResults.csv";
    public exportDataHeader: string[] = ["Short Item Description", "Enterprise Identifier", "Manufacturer", "Manufacturer Catalog Number"];
    public exportAbiSummarySearchResults: Array<any> = [];

    // @ngInject
    constructor($http, $httpParamSerializerJQLike, $log, Authentication,
                private $document, private $state, private CategoryBreadcrumbsService,
                private CategoriesService, private ContentConstants,
                private datatableService, private FacetsService, private FileManagerService,
                private NotificationService, private ProductComparisonService,
                private SearchWithinResultsService, private SearchUtilService, private SelectedFacetOptionsBreadboxService,
                private SiteCatalogService, private StateConstants, private UtilService) {

        super($http, $log, Authentication, $httpParamSerializerJQLike, "ABiProductionManagement");
        this.$log.debug("%s - Start", this.serviceName);

        this.searchMaxResultsText = "Over " + this.ContentConstants.SEARCH_MAX + " items have been found, please refine your search";
    }

    public clearAbiProduct() {
        this.abiProduct = null;
    }

    public getAbiProduct() {
        if (this.abiProduct) {
            return this.abiProduct;
        }
        return null;
    }

    public setAbiProduct(item): void {
        this.abiProduct = new AbiProduct(angular.copy(item));
    }

    public buildAggregationsRequest(): string {

        // check to see if category option has been selected
        let isCategoryOptionSelected: boolean = false;
        angular.forEach(this.CategoriesService.getCategories(), (category) => {
            if (category.selectedCategoryOptions.length > 0) {
                isCategoryOptionSelected = true;
            }
        });

        let aggregationsRequest: string = '{"aggregations": [';

        this.$log.debug("buildAggregationsRequest() - this.searchInput: (%s)", JSON.stringify(this.searchInput));
        this.$log.debug("buildAggregationsRequest() - this.userSpecifiedFilters: (%s)", JSON.stringify(this.userSpecifiedFilters));
        this.$log.debug("buildAggregationsRequest() - isCategoryOptionSelected: (%d)", isCategoryOptionSelected);

        if (this.searchInput || this.userSpecifiedFilters || isCategoryOptionSelected) {
            angular.forEach(this.FacetsService.getFacets(), (facet) => {
                aggregationsRequest = aggregationsRequest + '{"name":"' + facet.facetConfiguration.aggregationIdentifier
                    + '","field":"' + facet.facetConfiguration.elasticSearchFieldName + '.keyword","size":"5000"}';
            });
        } else {
            angular.forEach(this.FacetsService.getCategoryFacets(), (facet) => {
                aggregationsRequest = aggregationsRequest + '{"name":"' + facet.facetConfiguration.aggregationIdentifier
                    + '","field":"' + facet.facetConfiguration.elasticSearchFieldName + '.keyword","size":"5000"}';
            });
        }
        aggregationsRequest = aggregationsRequest + ']}';

        this.$log.debug("buildAggregationsRequest() - aggregationsRequest: (%s)", JSON.stringify(aggregationsRequest));

        return aggregationsRequest;
    }

    public buildUserSpecifiedFilters() {
        this.userSpecifiedFilters = "";

        angular.forEach(this.SearchWithinResultsService.getSearchWithinResultsKeywords(), (keyword) => {
            this.userSpecifiedFilters = this.userSpecifiedFilters.trim() + " " + keyword;
        });

        angular.forEach(this.CategoriesService.getCategories(), (category) => {
            this.userSpecifiedFilters = this.userSpecifiedFilters.trim()
                + " " + category.buildSearchClause(category.categoryConfiguration.elasticSearchFieldNames);
        });

        angular.forEach(this.FacetsService.getFacets(), (facet) => {
            this.userSpecifiedFilters = this.userSpecifiedFilters.trim()
                + " " + facet.buildSearchClause(facet.facetConfiguration.elasticSearchFieldName);
        });

        this.userSpecifiedFilters = this.userSpecifiedFilters.trim();
    }

    public createExportableAbiSummaryResults(arrayAbiProduct: Array<AbiProduct>) {
        let exportAbiSummarySearchResults: Array<any> = [];
        angular.forEach(arrayAbiProduct, (record) => {
            let row: any = {
                "shortItemDescription": record.shortItemDescription,
                "enterpriseProductIdentifier": record.enterpriseProductIdentifier,
                "manufacturer": record.manufacturer,
                "manufacturerCatalogNumber": record.manufacturerCatalogNumber,
            };
            exportAbiSummarySearchResults.push(row);
        });

        return exportAbiSummarySearchResults;
    }

    public cleanUpFacetsAndCategories() {
        this.SelectedFacetOptionsBreadboxService.clearAllSelectedFacetOptions();
        this.lastFacetOptionUpdated = null;

        angular.forEach(this.CategoriesService.getCategories(), (category) => {
            category.clearAllCategoryOptionSelections(false);
        });
    }

    public cleanUpForNewSearch() {
        // if searchInput changes, clear out all facet-related stuff
        if ((this.searchInput != null) && this.searchInput !== this.previousSearchInput) {
            this.previousSearchInput = this.searchInput;
            this.cleanUpFacetsAndCategories();
        }

        // every time we do a search - reset the product comparison array
        this.ProductComparisonService.clearItemComparisonList();
        this.ProductComparisonService.clearItemComparisonPrimaryImageList();

        this.isLoadingSearch = true;
        this.abiSearchStats = "";
    }

    public displaySecondaryAbiSearchSummaryResults(fields: Array<string>, abiProduct: AbiProduct) {
        this.previousSearchInput = "reset";
        this.searchInput = "";
        for (let i = 0; i < fields.length; i++) {
            if (i > 0) {
                this.searchInput += " AND ";
            }
            this.searchInput += "(" + fields[i] + ":" + abiProduct[fields[i]].replace(/[!@#$%^&()+=\-[\]\\';,./{}|":<>?~_]/g, "\\$&") + ")";
        }
        if (fields.length > 1) {
            this.searchInput = "(" + this.searchInput + ")";
        }
        this.userSpecifiedFilters = "";
        this.cleanUpForNewSearch();
        this.getCatalogItems();
        this.goToAbiCatalogSearch();
    }

    public executeSearch() {
        this.$log.debug("executeSearch() - this.searchInput: %s", this.searchInput);
        this.$log.debug("executeSearch() - this.previousSearchInput: %s", this.previousSearchInput);
        this.$log.debug("executeSearch() - this.userSpecifiedFilters: %s", JSON.stringify(this.userSpecifiedFilters));

        this.cleanUpForNewSearch();
        this.buildUserSpecifiedFilters();
        this.getCatalogItems();
    }

    public getCatalogItems() {
        this.$log.debug("getCatalogItems() - this.searchInput: %s", JSON.stringify(this.searchInput));
        this.$log.debug("getCatalogItems() - this.userSpecifiedFilters: %s", JSON.stringify(this.userSpecifiedFilters));

        this.getSummaryAbiProducts(
            this.searchInput,
            this.userSpecifiedFilters,
            this.buildAggregationsRequest()).then((response: IHttpPromiseCallbackArg<any>) => {

            if (response) {
                // this.$log.debug("response: %s", JSON.stringify(response));

                this.abiAggregations = this.parseSummaryAbiProductAggregations(response);
                //this.$log.debug("this.abiAggregations: %s", JSON.stringify(this.abiAggregations));

                this.abiSearchResults = this.parseAbiProductSummaryResults(response);
                //this.$log.debug("this.abiSearchResults: %s", JSON.stringify(this.abiSearchResults));

                this.sortByIsPreferredProduct(this.abiSearchResults);
                // this.$log.debug("this.abiSearchResults: %s", JSON.stringify(this.abiSearchResults));

                this.exportAbiSummarySearchResults =
                    this.createExportableAbiSummaryResults(this.abiSearchResults);

                this.searchStats = this.getSearchStats(response);

                this.populateFiltersAndResultsTable();
            } else {
                this.$log.debug("no response yet");
            }

        }, (errResponse: IHttpPromiseCallbackArg<boolean>) => {
            this.isLoadingSearch = false;
            this.$log.debug("%s - Error getting ABi product summary results from elastic.", this.serviceName);
            this.NotificationService.errorMsg("An error occurred while retrieving ABi product summary results");
        });
    }

    public getSearchStats(result) {
        let retVal = {
            "total": 0,
            "time": 0.00
        };

        if (result && result.data && result.data.hits) {
            if (result.data.hits.total) {
                retVal.total = result.data.hits.total;
            }

            if (result.data.took) {
                retVal.time = result.data.took;
            }
        }
        else {
            this.$log.debug("%s - Warning: No data returned", this.serviceName);
        }
        return retVal;
    }

    public getSummaryAbiProducts(searchValue: string, userSpecifiedFilters: string, aggregationsRequest: string) {
        this.$log.debug("getSummaryAbiProducts() - searchValue: %s", JSON.stringify(searchValue));
        this.$log.debug("getSummaryAbiProducts() - userSpecifiedFilters: %s", JSON.stringify(userSpecifiedFilters));

        //Note: check to see if anything got sent through, otherwise a string 'undefined' will be sent to bt.
        let updatedSearchValue: string = (searchValue) ? searchValue : "";
        let updatedUserSpecifiedFilters: string = (userSpecifiedFilters) ? userSpecifiedFilters : "";

        if (updatedSearchValue === "" || updatedSearchValue.length < 3) {
            if (updatedUserSpecifiedFilters) {
                // if updateSearchValue is invalid and updatedUserSpecifiedFilters are valid, then use updatedUserSpecifiedFilters
                updatedSearchValue = updatedUserSpecifiedFilters;
            } else {
                // if updateSearchValue and updatedUserSpecifiedFilters are invalid, then set searchValue to value that
                // results in a response of no results
                updatedSearchValue = "(noResultsSearch:Y)";
            }
        } else {
            // per consensus of BAs and dev leads, make free text searches partial word searches by adding an
            // asterisk to the beginning and each of each word

            // Also, OR the partial word searches - for now - I'm not convinced this is really what we want to do

            // need to deal with possibility of words being enclosed in double quotes - where we would do an exact search as opposed to a partial word search

            // need to deal with user entering multiple words - need to add the asterisks to each word
            this.$log.debug("updatedSearchValue: %s", JSON.stringify(updatedSearchValue));

            // don't add the free text asterisks if we are doing a secondary search for unspscCommodity or productType
            if ((updatedSearchValue.lastIndexOf("unspscCommodity") >= 0) || (updatedSearchValue.lastIndexOf("productType") >= 0)) {
                // do not add asterisks since we are doing a secondary search
            } else {
                let updatedSearchValueArray: Array<string> = updatedSearchValue.split(" ");
                updatedSearchValue = "";
                for (let i = 0; i < updatedSearchValueArray.length; i++) {
                    if (i === updatedSearchValueArray.length-1) {
                        updatedSearchValue += '*' + updatedSearchValueArray[i] + '* ';
                    } else {
                        updatedSearchValue += '*' + updatedSearchValueArray[i] + '* AND ';
                    }
                }
                updatedSearchValue = updatedSearchValue.trim();
                this.$log.debug("updatedSearchValue: %s", JSON.stringify(updatedSearchValue));
            }

            if (updatedUserSpecifiedFilters) {
                // if updateSearchValue and updatedUserSpecifiedFilters are valid,
                // then set searchValue to updatedSearchValue + updatedUserSpecifiedFilters
                updatedSearchValue = updatedSearchValue + " " + updatedUserSpecifiedFilters;
            } else {
                // if updateSearchValue is valid and updatedUserSpecifiedFilters are invalid, then use updatedSearchValue
                updatedSearchValue = updatedSearchValue;
            }
        }

        if (updatedSearchValue) {
            this.$log.debug("getSummaryAbiProducts() - updatedSearchValue: %s", JSON.stringify(updatedSearchValue));
            this.$log.debug("getSummaryAbiProducts() - aggregationsRequest: %s", JSON.stringify(aggregationsRequest));

            // encode URI/URL reserved characters
            updatedSearchValue = encodeURIComponent(updatedSearchValue);

            // pass a generic aggregations request to the BT
            let aggregations: string = encodeURIComponent(aggregationsRequest);

            let action: string = "getABiCatalogRecordSearchResults?searchValue=" + updatedSearchValue + "&aggregations=" + aggregations;
            return this.get(action);
        } else {
            return null;
        }
    };

    public goToAbiCatalogSearch() {
        this.$state.go(this.StateConstants.ABI_SEARCH);
    }

    public goToDetails(abiProduct) {
        //this.$log.debug("goToDetails - abiProduct: %s", JSON.stringify(abiProduct));
        this.setAbiProduct(abiProduct);
        this.$log.debug("goToDetails - this.abiProduct: %s", JSON.stringify(this.abiProduct));
        this.$state.go(this.StateConstants.ABI_PRODUCT_DETAILS);
    }

    public goToSearchHelp() {
        this.$state.go(this.StateConstants.ABI_SEARCH_HELP);
    }

    private ifOnlyCurrentFacetHasOptionsSelected(currentFacet): boolean {
        let returnValue: boolean = true;
        angular.forEach(this.FacetsService.getFacets(), (facet) => {
            // if we ate dealing with a facet that is NOT the current facet
            if (facet.facetConfiguration.displayLabel !== currentFacet.facetConfiguration.displayLabel) {
                // if an option is selected, return false from this function
                if (facet.isAnOptionSelected()) {
                    returnValue = false;
                }
            }
        });
        return returnValue;
    }

    //
    // functions that reference the individual Filter-related services
    //
    public init() {

        angular.forEach(this.CategoriesService.getCategories(), (category) => {
            category.initialize();
        });

        angular.forEach(this.CategoryBreadcrumbsService.getCategoryBreadcrumbs(), (categoryBreadcrumb) => {
            categoryBreadcrumb.clearSelectedCategoryOptions();
        });

        angular.forEach(this.FacetsService.getFacets(), (facet) => {
            facet.initialize();
        });

        // initialize the Selected Facet Option Breadbox to empty
        this.SelectedFacetOptionsBreadboxService.clearSelectedFacetOptions();

        this.searchInput = "";
        this.executeSearch();
    }

    public parseAbiProductSummaryResults(results): Array<AbiProduct> {
        //this.$log.debug("results: %s", JSON.stringify(results));
        let arrayAbiProduct: Array<AbiProduct> = [];
        if (results && results.data.hits.hits) {
            let abiProductSearchResults = results.data.hits.hits;
            //this.$log.debug("abiProductSearchResults: %s", JSON.stringify(abiProductSearchResults));
            for (let i = 0; i < abiProductSearchResults.length; i++) {
                let abiProductSearchResult = abiProductSearchResults[i];
                //this.$log.debug("abiProductSearchResult: %s", JSON.stringify(abiProductSearchResult));
                this.processAbiProductSearchResult(abiProductSearchResult, arrayAbiProduct, i);
            }
        } else {
            this.$log.warn("%s - Warning: No data returned", this.serviceName);
        }
        return arrayAbiProduct;
    }

    public parseSummaryAbiProductAggregations(results) {
        let abiProductAggregations: any = {};

        if (results && results.data.aggregations) {
            abiProductAggregations = results.data.aggregations;
        } else {
            this.$log.warn("%s - Warning: No aggregations returned", this.serviceName);
        }

        return abiProductAggregations;
    }

    private populateFiltersAndResultsTable() {
        this.showMaxResultsWarning = false;
        this.populateCategoriesPerCurrentResults();

        this.$log.debug("this.searchStats.total: %d", this.searchStats.total);
        // only build facets if number of search results are less than 5000
        if (this.searchStats.total < this.MAX_RESULTS_TO_ATTEMPT_FACET_BUILDING) {
            this.populateFacetsPerCurrentResults();
        }

        this.ngAbiSummaryResultsTable = this.datatableService.createNgTable(this.abiSearchResults);

        if (this.ContentConstants.SEARCH_MAX <= this.abiSearchResults.length) {
            this.abiSearchStats = this.UtilService.esBuildSearchStatsStr(this.searchStats.total, this.searchStats.time);
            this.showMaxResultsWarning = true;
            this.NotificationService.warningMsg("The maximum search results were reached, please refine your search.");
        } else {
            this.abiSearchStats = this.UtilService.esBuildSearchStatsStr(this.abiSearchResults.length, this.searchStats.time);
        }
        this.isLoadingSearch = false;
    }

    private processAbiProductSearchResult(abiProductSearchResult: any, arrayAbiProduct: Array<AbiProduct>, i: number): void {
        if (abiProductSearchResult.hasOwnProperty("_source")) {
            let abiProduct: AbiProduct = new AbiProduct();
            for (let key in abiProductSearchResult._source) {
                let value: any = abiProductSearchResult._source[key];
                abiProduct[key] = value;
            }

            // set isPreferredProduct (while waiting for it to show in dara)
            if (abiProduct.mmcProductIdentifier === abiProduct.mmcPreferredProductIdentifier) {
                abiProduct.isPreferredProduct = true;
            }

            // if no productImages came in via database - set to imageNotAvailable
            if (abiProduct.productImages.length === 0) {
                abiProduct.productImages = ["/src/content/images/imageNotAvailable.jpg"];
            }

            // set abiProduct.numberOfSitesUsingThisAbiProduct
            if (abiProduct.mmcProductIdentifier) {
                abiProduct.numberOfSitesUsingThisAbiProduct = this.SiteCatalogService.getNumberOfSitesUsingThisAbiProduct();

                /***
                 this.SiteCatalogService.getSiteCatalogRecordCount("product", abiProduct.mmcProductIdentifier).then((response: any) => {
                    if (response.data) {
                        // this.$log.debug("response.data: %s", JSON.stringify(response.data));
                        abiProduct.numberOfSitesUsingThisAbiProduct = response.data;
                    }
                }, (errResponse: any) => {
                    this.$log.debug("abiProductSearchResult: %s", JSON.stringify(abiProductSearchResult));
                    this.$log.error("Error retrieving Site Catalog Records: %s", errResponse);
                });
                 ***/
            }

            // this.$log.debug("abiProduct: %s", JSON.stringify(abiProduct));
            arrayAbiProduct.push(abiProduct);
        }
    }

    public populateCategoriesPerCurrentResults() {

        // determine the number of categories that have options selected within it
        let numberOfCategoriesWithOptionsSelected: number = 0;
        angular.forEach(this.CategoriesService.getCategories(), (category) => {
            if (category.selectedCategoryOptions.length > 0) {
                numberOfCategoriesWithOptionsSelected++;
            }
        });
        this.$log.debug("populateCategoriesPerCurrentResults() - numberOfCategoriesWithOptionsSelected = " + numberOfCategoriesWithOptionsSelected);

        angular.forEach(this.CategoriesService.getCategories(), (category) => {
            category.populate(category, numberOfCategoriesWithOptionsSelected, this.abiAggregations, this.abiSearchResults.length);
        });
    }

    private populateFacetsPerCurrentResults() {
        angular.forEach(this.FacetsService.getFacets(), (facet) => {

            // if THIS facet has any facet options selected
            if (facet.isAnOptionSelected()) {

                // if the last user facet-effecting action was one that updated a specific facet option
                if (this.lastFacetOptionUpdated) {

                    // if the last facet option that was updated belongs to THIS facet
                    if (this.lastFacetOptionUpdated.type === facet.facetConfiguration.displayLabel) {

                        // this.$log.debug("populateFacetsPerCurrentResults() - this.lastFacetOptionUpdated = %s: " + JSON.stringify(this.lastFacetOptionUpdated));

                        // if THIS facet has ever had the counts associated with its facet options updated
                        if (facet.haveFacetOptionCountsBeenUpdated) {

                            // since we've already updated this facet's option counts once (probably due the fact
                            // that another facet was interacted with), go ahead and update them again
                            facet.updateExistingFacetOptionCounts(this.abiAggregations);
                        } else {

                            // leave the facet options and counts as is - usually you are here when only one facet has
                            // been interacted with so far, leave as is so the user sees the original facet options and
                            // counts that were generated just using the user input search string
                        }

                        // the last facet option that was updated belongs to a different facet
                    } else {

                        // update THIS facet's existing facet options with new counts
                        facet.updateExistingFacetOptionCounts(this.abiAggregations);
                    }

                    // the last user facet-effecting action was a Clear All or something that didn't effect a specific facet
                } else {

                    // update THIS facet's existing facet options with new counts
                    facet.updateExistingFacetOptionCounts(this.abiAggregations);
                }

                // THIS facet has no facet options currently selected
            } else {

                // reinitialize THIS facet's options and counts with the latest aggregation results
                facet.populate(this.abiAggregations);
            }
        });
    }

    public resetFacets() {
        angular.forEach(this.FacetsService.getFacets(), (facet) => {
            facet.reset();
        });

        this.executeSearch();
    }

    private sortByIsPreferredProduct(data) {
        return data.sort(function (a, b) {
            return b.isPreferredProduct - a.isPreferredProduct;
        });
    }

    public toggleShowFullUnspsc() {
        if (this.showFullUnspsc === true) {
            this.showFullUnspsc = false;
        } else {
            this.showFullUnspsc = true;
        }
    }
}