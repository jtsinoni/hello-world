var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", "../../../_directives/searchComponents/categoryBreadcrumb/baseCategoryBreadcrumb.service", "../../../_constants/search.constants"], function (require, exports, baseCategoryBreadcrumb_service_1, search_constants_1) {
    'use strict';
    var CategoryBreadcrumb = (function (_super) {
        __extends(CategoryBreadcrumb, _super);
        // @ngInject
        function CategoryBreadcrumb($log, $rootScope, displayLabel, SearchUtilService) {
            _super.call(this, $log, $rootScope, displayLabel, SearchUtilService);
            // this module (for event purposes)
            this.eventModule = search_constants_1.SearchConstants.EVENT_MODULE_ABI;
            this.init();
        }
        return CategoryBreadcrumb;
    }(baseCategoryBreadcrumb_service_1.BaseCategoryBreadcrumbService));
    exports.CategoryBreadcrumb = CategoryBreadcrumb;
});
//# sourceMappingURL=categoryBreadcrumb.service.js.map