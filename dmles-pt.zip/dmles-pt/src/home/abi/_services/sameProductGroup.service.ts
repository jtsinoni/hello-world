'use strict';

import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {AbiProduct} from "../_models/abiProduct.model";

export class SameProductGroupService {
    private serviceName: string = "Same Product Group Service";

    public productsInSameProductGroup: Array<AbiProduct> = [];

    // @ngInject
    constructor(private $log, private $state, private AbiService, private AbiGridStateService, private DmlesGridService,
                private NotificationService, private SelectedProductService, private StateConstants) {
    }

    public getProductsInSameProductGroup() {
        return this.productsInSameProductGroup;
    }

    public displayProductsInSameProductGroup(productGroup) {
        // this.$log.debug("displayProductsInSameProductGroup - productGroup %s", JSON.stringify(productGroup));
        this.loadProductsInSameProductGroup(productGroup);
    }

    private loadProductsInSameProductGroup(abiProduct) {
        if (abiProduct.productGroup) {
            this.SelectedProductService.setSelectedProduct(abiProduct);

            let userSpecifiedFilters: string = "";
            userSpecifiedFilters = "(productGroup EQ '" + abiProduct.productGroup.replace(/[!@#$%^&()+=\-[\]\\';,./{}|":<>?~_]/g, "\\$&") + "')";

            this.AbiService.getSummaryAbiProducts("", userSpecifiedFilters, "{}").then((response: IHttpPromiseCallbackArg<any>) => {
                //this.$log.debug("response: %s", JSON.stringify(response));
                this.productsInSameProductGroup = this.AbiService.parseAbiProductSummaryResults(response);
                //this.$log.debug("this.productsInSameProductGroup.length: %d", JSON.stringify(this.productsInSameProductGroup.length));
                //this.$log.debug("this.productsInSameProductGroup: %s", JSON.stringify(this.productsInSameProductGroup));
                this.goToViewProductsInSameProductGroup();
            }, (errResponse: IHttpPromiseCallbackArg<boolean>) => {
                // this.isLoadingSearch = false;
                this.$log.error("%s - Error getting products with same productGroup from elastic.", this.serviceName);
                this.NotificationService.errorMsg("An error occurred while retrieving products with same productGroup");
            });
        }
    }

    public goToViewProductsInSameProductGroup() {
        //this.$log.debug("goToViewProductsInSameProductGroup");
        this.AbiGridStateService.searchSummaryResultsGridState = this.DmlesGridService.retrieveGridState();
        this.$state.go(this.StateConstants.ABI_PRODUCTS_IN_SAME_PRODUCT_GROUP);
    }
}