'use strict';

import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {AbiProduct} from "../_models/abiProduct.model";

export class SameProductGroupService {
    private serviceName: string = "Same Product Group Service";

    public productsInSameProductGroup: Array<AbiProduct> = [];
    public ngProductsInSameProductGroupTable: any = null;
    public productsInSameProductGroupTableFilterString: String = "";
    
    public sortOrder: string = "longItemDescription";

    // @ngInject
    constructor(private $log, private $state, private AbiService,
                private datatableService, private NotificationService,
                private SearchUtilService, private SelectedProductService, private StateConstants) {
    }

    public displayProductsInSameProductGroup(spDrugCode) {
        this.$log.debug("displayProductsInSameProductGroup - spDrugCode %s", JSON.stringify(spDrugCode));
        this.productsInSameProductGroupTableFilterString = "";
        this.loadProductsInSameProductGroup(spDrugCode);
    }

    private loadProductsInSameProductGroup(abiProduct) {
        if (abiProduct.spDrugCode) {
            this.SelectedProductService.setSelectedProduct(abiProduct);
            
            let userSpecifiedFilters = "(spDrugCode:" + abiProduct.spDrugCode.replace(/[!@#$%^&()+=\-[\]\\';,./{}|":<>?~_]/g, "\\$&") + ")";

            this.AbiService.getSummaryAbiProducts("", userSpecifiedFilters, "{}").then((response: IHttpPromiseCallbackArg<any>) => {
                //this.$log.debug("response: %s", JSON.stringify(response));
                this.productsInSameProductGroup = this.AbiService.parseAbiProductSummaryResults(response);
                this.SearchUtilService.sortByCriteria(this.productsInSameProductGroup, [this.sortOrder]);
                this.ngProductsInSameProductGroupTable = this.datatableService.createNgTable(this.productsInSameProductGroup);
                this.$log.debug("this.productsInSameProductGroup.length: %d", JSON.stringify(this.productsInSameProductGroup.length));
                this.$log.debug("this.productsInSameProductGroup: %s", JSON.stringify(this.productsInSameProductGroup));
                this.goToViewProductsWithSameSpDrugCode();
            }, (errResponse: IHttpPromiseCallbackArg<boolean>) => {
                // this.isLoadingSearch = false;
                this.$log.debug("%s - Error getting products with same spDrugCode from elastic.", this.serviceName);
                this.NotificationService.errorMsg("An error occurred while retrieving products with same spDrugCode");
            });
        }
    }

    public productsInSameProductGroupTableFilter() {
        this.ngProductsInSameProductGroupTable.filter({$: this.productsInSameProductGroupTableFilterString});
        this.ngProductsInSameProductGroupTable.reload();
    }

    public goToViewProductsWithSameSpDrugCode() {
        //this.$log.debug("goToViewProductsWithSameSpDrugCode");
        this.$state.go(this.StateConstants.ABI_PRODUCTS_IN_SAME_PRODUCT_GROUP);
    }
}