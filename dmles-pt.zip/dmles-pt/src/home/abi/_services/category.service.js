var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", "../../../_directives/searchComponents/category/baseCategory.service", "../../../_constants/search.constants"], function (require, exports, baseCategory_service_1, search_constants_1) {
    'use strict';
    var Category = (function (_super) {
        __extends(Category, _super);
        // @ngInject
        function Category($log, $rootScope, categoryConfiguration, SearchUtilService) {
            _super.call(this, $log, $rootScope, categoryConfiguration, SearchUtilService);
            // this module (for event purposes)
            this.eventModule = search_constants_1.SearchConstants.EVENT_MODULE_ABI;
            this.init();
        }
        return Category;
    }(baseCategory_service_1.BaseCategoryService));
    exports.Category = Category;
});
//# sourceMappingURL=category.service.js.map