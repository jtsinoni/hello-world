'use strict';

import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {AbiProduct} from "../_models/abiProduct.model";

export class SelectedProductService {
    private serviceName: string = "Selected Product Service";
    
    public selectedProduct: AbiProduct = null;   

    // @ngInject
    constructor(private $log) {
    }

    public setSelectedProduct(abiProduct) {
        this.selectedProduct = new AbiProduct();
        this.selectedProduct = abiProduct;

        this.$log.debug("setSelectedProduct - this.selectedProduct %s", JSON.stringify(this.selectedProduct));
    }    
}