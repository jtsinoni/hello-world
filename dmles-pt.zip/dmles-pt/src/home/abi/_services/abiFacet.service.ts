'use strict';

import {BaseFacetService} from "../../../_directives/searchComponents/facet/baseFacet.service";
import {FacetConfiguration} from "../../../_models/facetConfiguration.model";
import {SearchConstants} from "../../../_constants/search.constants";

export class AbiFacet extends BaseFacetService {

    // this module (for event purposes)
    public eventModule: string = SearchConstants.EVENT_MODULE_ABI;

    // @ngInject
    constructor($log, $rootScope, facetConfiguration: FacetConfiguration, SearchUtilService) {
        super($log, $rootScope, facetConfiguration, SearchUtilService);

        this.init();
    }

}