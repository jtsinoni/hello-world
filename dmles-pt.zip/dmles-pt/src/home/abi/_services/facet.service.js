var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", "../../../_directives/searchComponents/facet/baseFacet.service", "../../../_constants/search.constants"], function (require, exports, baseFacet_service_1, search_constants_1) {
    'use strict';
    var Facet = (function (_super) {
        __extends(Facet, _super);
        // @ngInject
        function Facet($log, $rootScope, facetConfiguration, SearchUtilService) {
            _super.call(this, $log, $rootScope, facetConfiguration, SearchUtilService);
            // this module (for event purposes)
            this.eventModule = search_constants_1.SearchConstants.EVENT_MODULE_ABI;
            this.init();
        }
        return Facet;
    }(baseFacet_service_1.BaseFacetService));
    exports.Facet = Facet;
});
//# sourceMappingURL=facet.service.js.map