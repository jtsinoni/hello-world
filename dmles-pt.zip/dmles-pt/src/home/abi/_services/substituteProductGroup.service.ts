'use strict';

import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {AbiProduct} from "../_models/abiProduct.model";

export class SubstituteProductGroupService {
    private serviceName: string = "Substitute Product Group Service";

    public productsInSubstituteProductGroup: Array<AbiProduct> = [];

    // @ngInject
    constructor(private $log, private $state, private AbiService, private AbiGridStateService, private DmlesGridService,
                private NotificationService, private SelectedProductService, private StateConstants) {
    }

    public getProductsInSubstituteProductGroup() {
        return this.productsInSubstituteProductGroup;
    }

    public displayProductsInSubstituteProductGroup(productGroup) {
        // this.$log.debug("displayProductsInSubstituteProductGroup - productGroup %s", JSON.stringify(productGroup));
        this.loadProductsInSubstituteProductGroup(productGroup);
    }

    private loadProductsInSubstituteProductGroup(abiProduct) {
        if (abiProduct.productGroup) {
            this.SelectedProductService.setSelectedProduct(abiProduct);

            let userSpecifiedFilters: string = "";
            userSpecifiedFilters = "(productSubstituteGroup EQ '" + abiProduct.productSubstituteGroup.replace(/[!@#$%^&()+=\-[\]\\';,./{}|":<>?~_]/g, "\\$&") + "')";

            this.AbiService.getSummaryAbiProducts("", userSpecifiedFilters, "{}").then((response: IHttpPromiseCallbackArg<any>) => {
                //this.$log.debug("response: %s", JSON.stringify(response));
                this.productsInSubstituteProductGroup = this.AbiService.parseAbiProductSummaryResults(response);
                //this.$log.debug("this.productsInSubstituteProductGroup.length: %d", JSON.stringify(this.productsInSubstituteProductGroup.length));
                //this.$log.debug("this.productsInSubstituteProductGroup: %s", JSON.stringify(this.productsInSubstituteProductGroup));
                this.goToViewProductsInSubstituteProductGroup();
            }, (errResponse: IHttpPromiseCallbackArg<boolean>) => {
                // this.isLoadingSearch = false;
                this.$log.error("%s - Error getting products with same productGroup from elastic.", this.serviceName);
                this.NotificationService.errorMsg("An error occurred while retrieving products with same productGroup");
            });
        }
    }

    public goToViewProductsInSubstituteProductGroup() {
        //this.$log.debug("goToViewProductsInSubstituteProductGroup");
        this.AbiGridStateService.searchSummaryResultsGridState = this.DmlesGridService.retrieveGridState();
        this.$state.go(this.StateConstants.ABI_PRODUCTS_IN_SUBSTITUTE_PRODUCT_GROUP);
    }
}