define(["require", "exports"], function (require, exports) {
    'use strict';
    var AbiGridStateService = (function () {
        function AbiGridStateService($log, DmlesGridService) {
            this.$log = $log;
            this.DmlesGridService = DmlesGridService;
            this.searchSummaryResultsGridState = {};
        }
        AbiGridStateService.prototype.clearSearchSummaryResultsGridState = function () {
            this.searchSummaryResultsGridState = {};
            this.$log.debug("clear - this.searchSummaryResultsGridState: %s", JSON.stringify(this.searchSummaryResultsGridState));
        };
        AbiGridStateService.prototype.getSearchSummaryResultsGridState = function () {
            return this.searchSummaryResultsGridState;
        };
        AbiGridStateService.prototype.setSearchSummaryResultsGridState = function (gridState) {
            this.searchSummaryResultsGridState = gridState;
            this.$log.debug("set - this.searchSummaryResultsGridState: %s", JSON.stringify(this.searchSummaryResultsGridState));
        };
        return AbiGridStateService;
    }());
    exports.AbiGridStateService = AbiGridStateService;
});
//# sourceMappingURL=abiGridState.service.js.map