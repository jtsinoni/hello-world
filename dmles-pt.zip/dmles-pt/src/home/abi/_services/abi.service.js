var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", '../../../_services/api.service', "../_models/abiProduct.model"], function (require, exports, api_service_1, abiProduct_model_1) {
    'use strict';
    var AbiService = (function (_super) {
        __extends(AbiService, _super);
        // @ngInject
        function AbiService($http, $httpParamSerializerJQLike, $log, Authentication, $document, $state, AbiGridStateService, CategoryBreadcrumbsService, CategoriesService, ContentConstants, DmlesGridService, datatableService, FacetsService, FileManagerService, NotificationService, ProductComparisonService, SearchWithinResultsService, SearchUtilService, SelectedFacetOptionsBreadboxService, SiteCatalogService, StateConstants, UtilService) {
            _super.call(this, $http, $log, Authentication, $httpParamSerializerJQLike, "ABiProductionManagement");
            this.$document = $document;
            this.$state = $state;
            this.AbiGridStateService = AbiGridStateService;
            this.CategoryBreadcrumbsService = CategoryBreadcrumbsService;
            this.CategoriesService = CategoriesService;
            this.ContentConstants = ContentConstants;
            this.DmlesGridService = DmlesGridService;
            this.datatableService = datatableService;
            this.FacetsService = FacetsService;
            this.FileManagerService = FileManagerService;
            this.NotificationService = NotificationService;
            this.ProductComparisonService = ProductComparisonService;
            this.SearchWithinResultsService = SearchWithinResultsService;
            this.SearchUtilService = SearchUtilService;
            this.SelectedFacetOptionsBreadboxService = SelectedFacetOptionsBreadboxService;
            this.SiteCatalogService = SiteCatalogService;
            this.StateConstants = StateConstants;
            this.UtilService = UtilService;
            this.abiProduct = new abiProduct_model_1.AbiProduct();
            this.serviceName = "ABi Service";
            this.downloadFileInfo = null;
            this.showFullUnspsc = false;
            this.searchInput = "";
            this.previousSearchInput = "";
            this.userSpecifiedFilters = "";
            this.searchPlaceholder = "What are you looking for? Try searching with ABi ...";
            this.sortOrder = "longItemDescription";
            this.searchStats = {};
            this.MAX_RESULTS_TO_ATTEMPT_FACET_BUILDING = 2500;
            this.abiSearchResults = [];
            this.abiAggregations = {};
            this.abiSummarySearchResultsTableTitle = "ABi Summary Search Results";
            this.canFilterGlobal = false;
            this.canRefresh = false;
            this.canExport = true;
            this.ngAbiSummaryResultsTable = null;
            this.lastFacetOptionUpdated = null;
            this.exportFilename = "abiSummarySearchResults.csv";
            this.exportDataHeader = ["Short Item Description", "Enterprise Identifier", "Manufacturer", "Manufacturer Catalog Number"];
            this.exportAbiSummarySearchResults = [];
            this.$log.debug("%s - Start", this.serviceName);
            this.searchMaxResultsText = "Over " + this.ContentConstants.SEARCH_MAX + " items have been found, please refine your search";
        }
        AbiService.prototype.clearAbiProduct = function () {
            this.abiProduct = null;
        };
        AbiService.prototype.getAbiProduct = function () {
            if (this.abiProduct) {
                return this.abiProduct;
            }
            return null;
        };
        AbiService.prototype.setAbiProduct = function (item) {
            this.abiProduct = new abiProduct_model_1.AbiProduct(angular.copy(item));
        };
        AbiService.prototype.buildAggregationsRequest = function () {
            // check to see if category option has been selected
            var isCategoryOptionSelected = false;
            angular.forEach(this.CategoriesService.getCategories(), function (category) {
                if (category.selectedCategoryOptions.length > 0) {
                    isCategoryOptionSelected = true;
                }
            });
            var aggregationsRequest = "";
            //this.$log.debug("buildAggregationsRequest() - this.searchInput: (%s)", JSON.stringify(this.searchInput));
            //this.$log.debug("buildAggregationsRequest() - this.userSpecifiedFilters: (%s)", JSON.stringify(this.userSpecifiedFilters));
            //this.$log.debug("buildAggregationsRequest() - isCategoryOptionSelected: (%d)", isCategoryOptionSelected);
            if (this.searchInput || this.userSpecifiedFilters || isCategoryOptionSelected) {
                angular.forEach(this.FacetsService.getFacets(), function (facet) {
                    aggregationsRequest += facet.facetConfiguration.aggregationIdentifier + ' as '
                        + facet.facetConfiguration.elasticSearchFieldName + '.keyword size 5000, ';
                });
            }
            else {
                angular.forEach(this.FacetsService.getCategoryFacets(), function (facet) {
                    aggregationsRequest += facet.facetConfiguration.aggregationIdentifier + ' as '
                        + facet.facetConfiguration.elasticSearchFieldName + '.keyword size 5000, ';
                });
            }
            // strip off final comma and space characters
            //this.$log.debug("buildAggregationsRequest() before - aggregationsRequest: (%s)", JSON.stringify(aggregationsRequest));
            aggregationsRequest = aggregationsRequest.substr(0, aggregationsRequest.length - 2);
            //this.$log.debug("buildAggregationsRequest() after - aggregationsRequest: (%s)", JSON.stringify(aggregationsRequest));
            this.$log.debug("buildAggregationsRequest() - aggregationsRequest: (%s)", JSON.stringify(aggregationsRequest));
            return aggregationsRequest;
        };
        AbiService.prototype.buildUserSpecifiedFilters = function () {
            var _this = this;
            this.userSpecifiedFilters = "";
            angular.forEach(this.SearchWithinResultsService.getSearchWithinResultsKeywords(), function (keyword) {
                _this.userSpecifiedFilters = _this.userSpecifiedFilters.trim() + " AND " + keyword;
            });
            angular.forEach(this.CategoriesService.getCategories(), function (category) {
                _this.userSpecifiedFilters = _this.userSpecifiedFilters.trim()
                    + " " + category.buildSearchClause(category.categoryConfiguration.elasticSearchFieldNames);
            });
            angular.forEach(this.FacetsService.getFacets(), function (facet) {
                _this.userSpecifiedFilters = _this.userSpecifiedFilters.trim()
                    + " " + facet.buildSearchClause(facet.facetConfiguration.elasticSearchFieldName);
            });
            this.userSpecifiedFilters = this.userSpecifiedFilters.trim();
        };
        AbiService.prototype.createExportableAbiSummaryResults = function (arrayAbiProduct) {
            var exportAbiSummarySearchResults = [];
            angular.forEach(arrayAbiProduct, function (record) {
                var row = {
                    "shortItemDescription": record.shortItemDescription,
                    "enterpriseProductIdentifier": record.enterpriseProductIdentifier,
                    "manufacturer": record.manufacturer,
                    "manufacturerCatalogNumber": record.manufacturerCatalogNumber,
                };
                exportAbiSummarySearchResults.push(row);
            });
            return exportAbiSummarySearchResults;
        };
        AbiService.prototype.cleanUpFacetsAndCategories = function () {
            this.SelectedFacetOptionsBreadboxService.clearAllSelectedFacetOptions();
            this.lastFacetOptionUpdated = null;
            angular.forEach(this.CategoriesService.getCategories(), function (category) {
                category.clearAllCategoryOptionSelections(false);
            });
        };
        AbiService.prototype.cleanUpForNewSearch = function () {
            // if searchInput changes, clear out all facet-related stuff
            if ((this.searchInput != null) && this.searchInput !== this.previousSearchInput) {
                this.previousSearchInput = this.searchInput;
                this.cleanUpFacetsAndCategories();
            }
            // every time we do a search - reset the product comparison array
            this.ProductComparisonService.clearItemComparisonList();
            this.ProductComparisonService.clearItemComparisonPrimaryImageList();
            // clear the ABi Search Summary Results grid state
            this.AbiGridStateService.clearSearchSummaryResultsGridState();
            this.DmlesGridService.clearAllFilters();
            this.isLoadingSearch = true;
            this.abiSearchStats = "";
        };
        AbiService.prototype.displaySecondaryAbiSearchSummaryResults = function (fields, abiProduct) {
            this.previousSearchInput = "reset";
            this.searchInput = "";
            for (var i = 0; i < fields.length; i++) {
                if (i > 0) {
                    this.searchInput += " AND ";
                }
                this.searchInput += fields[i] + ".keyword EQ '" + abiProduct[fields[i]].replace(/[!@#$%^&()+=\-[\]\\';,./{}|":<>?~_]/g, "\\$&") + "'";
            }
            this.searchInput = "(" + this.searchInput + ")";
            this.userSpecifiedFilters = "";
            this.cleanUpForNewSearch();
            this.getCatalogItems();
            this.goToAbiCatalogSearch();
        };
        AbiService.prototype.executeSearch = function () {
            //this.$log.debug("executeSearch() - this.searchInput: %s", this.searchInput);
            //this.$log.debug("executeSearch() - this.previousSearchInput: %s", this.previousSearchInput);
            //this.$log.debug("executeSearch() - this.userSpecifiedFilters: %s", JSON.stringify(this.userSpecifiedFilters));
            this.cleanUpForNewSearch();
            this.buildUserSpecifiedFilters();
            this.getCatalogItems();
        };
        AbiService.prototype.getCatalogItems = function () {
            var _this = this;
            this.$log.debug("getCatalogItems() - this.searchInput: %s", JSON.stringify(this.searchInput));
            this.$log.debug("getCatalogItems() - this.userSpecifiedFilters: %s", JSON.stringify(this.userSpecifiedFilters));
            this.getSummaryAbiProducts(this.searchInput, this.userSpecifiedFilters, this.buildAggregationsRequest()).then(function (response) {
                if (response) {
                    //this.$log.debug("getCatalogItems() - response: %s", response);
                    _this.abiAggregations = _this.parseSummaryAbiProductAggregations(response);
                    //this.$log.debug("this.abiAggregations: %s", JSON.stringify(this.abiAggregations));
                    _this.abiSearchResults = _this.parseAbiProductSummaryResults(response);
                    //this.$log.debug("this.abiSearchResults: %s", JSON.stringify(this.abiSearchResults));
                    _this.sortByIsPreferredProduct(_this.abiSearchResults);
                    // this.$log.debug("this.abiSearchResults: %s", JSON.stringify(this.abiSearchResults));
                    _this.exportAbiSummarySearchResults =
                        _this.createExportableAbiSummaryResults(_this.abiSearchResults);
                    _this.searchStats = _this.getSearchStats(response);
                    _this.populateFiltersAndResultsTable();
                    if (_this.abiSearchResults.length === 0) {
                        if (_this.searchInput === "" && _this.userSpecifiedFilters === "") {
                        }
                        else {
                            _this.$log.debug('%s - We found 0 results for "%s".  Try using fewer search terms and use the filters on the side panel to narrow in on your results.', _this.serviceName, _this.searchInput);
                            _this.NotificationService.warningMsg('We found 0 results for "' + _this.searchInput + '".  Try using fewer search terms and use the filters on the side panel to narrow in on your results.');
                        }
                    }
                }
                else {
                    _this.$log.debug("no response yet");
                }
            }, function (errResponse) {
                _this.isLoadingSearch = false;
                _this.$log.debug("errResponse.toString() = %s", errResponse.toString());
                if (errResponse.toString().indexOf("SyntaxError: JSON.parse: unexpected character at line 1 column 1 of the JSON data") == 0) {
                    _this.$log.debug("%s - Error getting ABi product summary results from elastic.  Error message received from BT", _this.serviceName);
                    _this.NotificationService.errorMsg("A Business Tier error occurred while retrieving ABi product summary results");
                }
                else {
                    _this.$log.debug("%s - Error getting ABi product summary results from elastic.", _this.serviceName);
                    _this.NotificationService.errorMsg("An error occurred while retrieving ABi product summary results");
                }
            });
        };
        AbiService.prototype.getSearchStats = function (result) {
            var retVal = {
                "total": 0,
                "time": 0.00
            };
            if (result && result.data && result.data.total) {
                if (result.data.total) {
                    retVal.total = result.data.total;
                }
                if (result.data.took) {
                    retVal.time = result.data.took;
                }
            }
            else {
                this.$log.debug("%s - Warning: No data returned", this.serviceName);
            }
            return retVal;
        };
        AbiService.prototype.getSummaryAbiProducts = function (searchValue, userSpecifiedFilters, aggregationsRequest) {
            this.$log.debug("getSummaryAbiProducts() - searchValue: %s", JSON.stringify(searchValue));
            this.$log.debug("getSummaryAbiProducts() - userSpecifiedFilters: %s", JSON.stringify(userSpecifiedFilters));
            //Note: check to see if anything got sent through, otherwise a string 'undefined' will be sent to bt.
            var updatedSearchValue = (searchValue) ? searchValue : "";
            var updatedUserSpecifiedFilters = (userSpecifiedFilters) ? userSpecifiedFilters : "";
            if (updatedSearchValue === "" || updatedSearchValue.length < 3) {
                if (updatedUserSpecifiedFilters) {
                    // if updateSearchValue is invalid and updatedUserSpecifiedFilters are valid, then use updatedUserSpecifiedFilters
                    updatedSearchValue = updatedUserSpecifiedFilters;
                }
                else {
                    // if updateSearchValue and updatedUserSpecifiedFilters are invalid, then set searchValue to value that
                    // results in a response of no results
                    updatedSearchValue = "(noResultsSearch EQ 'Y')";
                }
            }
            else {
                // per consensus of BAs and dev leads, make free text searches partial word searches by adding an
                // asterisk to the beginning and each of each word
                // Also, OR the partial word searches - for now - I'm not convinced this is really what we want to do
                // need to deal with possibility of words being enclosed in double quotes - where we would do an exact search as opposed to a partial word search
                // need to deal with user entering multiple words - need to add the asterisks to each word
                this.$log.debug("updatedSearchValue: %s", JSON.stringify(updatedSearchValue));
                // don't add the free text asterisks if we are doing a secondary search for unspscCommodity or productType
                if ((updatedSearchValue.lastIndexOf("unspscCommodity") >= 0) || (updatedSearchValue.lastIndexOf("productType") >= 0)) {
                }
                else {
                    var updatedSearchValueArray = updatedSearchValue.split(" ");
                    updatedSearchValue = "";
                    for (var i = 0; i < updatedSearchValueArray.length; i++) {
                        if (i === updatedSearchValueArray.length - 1) {
                            updatedSearchValue += '*' + updatedSearchValueArray[i] + '* ';
                        }
                        else {
                            updatedSearchValue += '*' + updatedSearchValueArray[i] + '* AND ';
                        }
                    }
                    updatedSearchValue = updatedSearchValue.trim();
                    this.$log.debug("updatedSearchValue: %s", JSON.stringify(updatedSearchValue));
                }
                if (updatedUserSpecifiedFilters) {
                    // if updateSearchValue and updatedUserSpecifiedFilters are valid,
                    // then set searchValue to updatedSearchValue + updatedUserSpecifiedFilters
                    updatedSearchValue = updatedSearchValue + " " + updatedUserSpecifiedFilters;
                }
                else {
                    // if updateSearchValue is valid and updatedUserSpecifiedFilters are invalid, then use updatedSearchValue
                    updatedSearchValue = updatedSearchValue;
                }
            }
            if (updatedSearchValue) {
                this.$log.debug("getSummaryAbiProducts() - updatedSearchValue - before: %s", JSON.stringify(updatedSearchValue));
                // if updatedSearchValue begins with "AND " - strip it off
                if (updatedSearchValue.indexOf("AND ") === 0) {
                    updatedSearchValue = updatedSearchValue.substr("AND ".length);
                }
                this.$log.debug("getSummaryAbiProducts() - updatedSearchValue - after: %s", JSON.stringify(updatedSearchValue));
                this.$log.debug("getSummaryAbiProducts() - aggregationsRequest: %s", JSON.stringify(aggregationsRequest));
                // encode URI/URL reserved characters
                updatedSearchValue = encodeURIComponent(updatedSearchValue);
                // pass a generic aggregations request to the BT
                var aggregations = encodeURIComponent(aggregationsRequest);
                var action = "getABiCatalogRecordESResults?queryString=" + updatedSearchValue + "&aggregations=" + aggregations;
                return this.get(action);
            }
            else {
                return null;
            }
        };
        ;
        AbiService.prototype.goToAbiCatalogSearch = function () {
            this.$state.go(this.StateConstants.ABI_SEARCH);
        };
        AbiService.prototype.goToDetails = function (abiProduct) {
            //this.$log.debug("goToDetails - abiProduct: %s", JSON.stringify(abiProduct));
            this.setAbiProduct(abiProduct);
            this.$log.debug("goToDetails - this.abiProduct: %s", JSON.stringify(this.abiProduct));
            this.AbiGridStateService.searchSummaryResultsGridState = this.DmlesGridService.retrieveGridState();
            this.$log.debug("goToDetails - this.searchSummaryResultsGridState: %s", JSON.stringify(this.AbiGridStateService.searchSummaryResultsGridState));
            this.$state.go(this.StateConstants.ABI_PRODUCT_DETAILS);
        };
        AbiService.prototype.goToSearchHelp = function () {
            this.AbiGridStateService.searchSummaryResultsGridState = this.DmlesGridService.retrieveGridState();
            this.$state.go(this.StateConstants.ABI_SEARCH_HELP);
        };
        AbiService.prototype.ifOnlyCurrentFacetHasOptionsSelected = function (currentFacet) {
            var returnValue = true;
            angular.forEach(this.FacetsService.getFacets(), function (facet) {
                // if we ate dealing with a facet that is NOT the current facet
                if (facet.facetConfiguration.displayLabel !== currentFacet.facetConfiguration.displayLabel) {
                    // if an option is selected, return false from this function
                    if (facet.isAnOptionSelected()) {
                        returnValue = false;
                    }
                }
            });
            return returnValue;
        };
        //
        // functions that reference the individual Filter-related services
        //
        AbiService.prototype.init = function () {
            angular.forEach(this.CategoriesService.getCategories(), function (category) {
                category.initialize();
            });
            angular.forEach(this.CategoryBreadcrumbsService.getCategoryBreadcrumbs(), function (categoryBreadcrumb) {
                categoryBreadcrumb.clearSelectedCategoryOptions();
            });
            angular.forEach(this.FacetsService.getFacets(), function (facet) {
                facet.initialize();
            });
            // initialize the Selected Facet Option Breadbox to empty
            this.SelectedFacetOptionsBreadboxService.clearSelectedFacetOptions();
            this.searchInput = "";
            this.executeSearch();
        };
        AbiService.prototype.parseAbiProductSummaryResults = function (results) {
            // this.$log.debug("results: %s", JSON.stringify(results));
            var arrayAbiProduct = [];
            if (results && results.data.hits.fields) {
                var abiProductSearchResults = results.data.hits.fields;
                // this.$log.debug("abiProductSearchResults: %s", JSON.stringify(abiProductSearchResults));
                for (var i = 0; i < abiProductSearchResults.length; i++) {
                    var abiProductSearchResult = abiProductSearchResults[i];
                    // this.$log.debug("abiProductSearchResult: %s", JSON.stringify(abiProductSearchResult));
                    this.processAbiProductSearchResult(abiProductSearchResult, arrayAbiProduct, i);
                }
            }
            else {
                this.$log.warn("%s - Warning: No ES data returned", this.serviceName);
            }
            return arrayAbiProduct;
        };
        AbiService.prototype.parseSummaryAbiProductAggregations = function (results) {
            var abiProductAggregations = {};
            if (results && results.data.aggregations) {
                abiProductAggregations = results.data.aggregations;
            }
            else {
                this.$log.warn("%s - Warning: No aggregations returned", this.serviceName);
            }
            return abiProductAggregations;
        };
        AbiService.prototype.populateFiltersAndResultsTable = function () {
            this.showMaxResultsWarning = false;
            this.populateCategoriesPerCurrentResults();
            this.$log.debug("this.searchStats.total: %d", this.searchStats.total);
            // only build facets if number of search results are less than 5000
            if (this.searchStats.total < this.MAX_RESULTS_TO_ATTEMPT_FACET_BUILDING) {
                this.populateFacetsPerCurrentResults();
            }
            this.ngAbiSummaryResultsTable = this.datatableService.createNgTable(this.abiSearchResults);
            if (this.ContentConstants.SEARCH_MAX <= this.abiSearchResults.length) {
                this.abiSearchStats = this.UtilService.esBuildSearchStatsStr(this.searchStats.total, this.searchStats.time);
                this.showMaxResultsWarning = true;
                this.NotificationService.warningMsg("The maximum search results were reached, please refine your search.");
            }
            else {
                this.abiSearchStats = this.UtilService.esBuildSearchStatsStr(this.abiSearchResults.length, this.searchStats.time);
            }
            this.isLoadingSearch = false;
        };
        AbiService.prototype.processAbiProductSearchResult = function (abiProductSearchResult, arrayAbiProduct, i) {
            var abiProduct = new abiProduct_model_1.AbiProduct();
            for (var key in abiProductSearchResult) {
                var value = abiProductSearchResult[key];
                abiProduct[key] = value;
            }
            // set isPreferredProduct (while waiting for it to show in dara)
            if (abiProduct.mmcProductIdentifier === abiProduct.mmcPreferredProductIdentifier) {
                abiProduct.isPreferredProduct = true;
            }
            // if no productImages came in via database - set to imageNotAvailable
            if (abiProduct.productImages.length === 0) {
                abiProduct.productImages = ["/src/content/images/imageNotAvailable.jpg"];
            }
            // set abiProduct.numberOfSitesUsingThisAbiProduct
            if (abiProduct.mmcProductIdentifier) {
                abiProduct.numberOfSitesUsingThisAbiProduct = this.SiteCatalogService.getNumberOfSitesUsingThisAbiProduct();
            }
            // this.$log.debug("abiProduct: %s", JSON.stringify(abiProduct));
            arrayAbiProduct.push(abiProduct);
        };
        AbiService.prototype.populateCategoriesPerCurrentResults = function () {
            var _this = this;
            // determine the number of categories that have options selected within it
            var numberOfCategoriesWithOptionsSelected = 0;
            angular.forEach(this.CategoriesService.getCategories(), function (category) {
                if (category.selectedCategoryOptions.length > 0) {
                    numberOfCategoriesWithOptionsSelected++;
                }
            });
            this.$log.debug("populateCategoriesPerCurrentResults() - numberOfCategoriesWithOptionsSelected = " + numberOfCategoriesWithOptionsSelected);
            angular.forEach(this.CategoriesService.getCategories(), function (category) {
                category.populate(category, numberOfCategoriesWithOptionsSelected, _this.abiAggregations, _this.abiSearchResults.length);
            });
        };
        AbiService.prototype.populateFacetsPerCurrentResults = function () {
            var _this = this;
            angular.forEach(this.FacetsService.getFacets(), function (facet) {
                // if THIS facet has any facet options selected
                if (facet.isAnOptionSelected()) {
                    // if the last user facet-effecting action was one that updated a specific facet option
                    if (_this.lastFacetOptionUpdated) {
                        // if the last facet option that was updated belongs to THIS facet
                        if (_this.lastFacetOptionUpdated.type === facet.facetConfiguration.displayLabel) {
                            // this.$log.debug("populateFacetsPerCurrentResults() - this.lastFacetOptionUpdated = %s: " + JSON.stringify(this.lastFacetOptionUpdated));
                            // if THIS facet has ever had the counts associated with its facet options updated
                            if (facet.haveFacetOptionCountsBeenUpdated) {
                                // since we've already updated this facet's option counts once (probably due the fact
                                // that another facet was interacted with), go ahead and update them again
                                facet.updateExistingFacetOptionCounts(_this.abiAggregations);
                            }
                            else {
                            }
                        }
                        else {
                            // update THIS facet's existing facet options with new counts
                            facet.updateExistingFacetOptionCounts(_this.abiAggregations);
                        }
                    }
                    else {
                        // update THIS facet's existing facet options with new counts
                        facet.updateExistingFacetOptionCounts(_this.abiAggregations);
                    }
                }
                else {
                    // reinitialize THIS facet's options and counts with the latest aggregation results
                    facet.populate(_this.abiAggregations);
                }
            });
        };
        AbiService.prototype.resetFacets = function () {
            angular.forEach(this.FacetsService.getFacets(), function (facet) {
                facet.reset();
            });
            this.executeSearch();
        };
        AbiService.prototype.sortByIsPreferredProduct = function (data) {
            return data.sort(function (a, b) {
                return b.isPreferredProduct - a.isPreferredProduct;
            });
        };
        AbiService.prototype.toggleShowFullUnspsc = function () {
            if (this.showFullUnspsc === true) {
                this.showFullUnspsc = false;
            }
            else {
                this.showFullUnspsc = true;
            }
        };
        return AbiService;
    }(api_service_1.ApiService));
    exports.AbiService = AbiService;
});
//# sourceMappingURL=abi.service.js.map