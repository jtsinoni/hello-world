'use strict';

import {ApiService} from '../../../_services/api.service';
import {SiteCatalogItem} from "../_models/siteCatalogItem.model";

export interface ISiteCatalogService {
}

export class SiteCatalogService extends ApiService implements ISiteCatalogService {
    private siteCatalogItem: SiteCatalogItem = new SiteCatalogItem();
    private serviceName: string = "Site Catalog Service";

    public siteCatalogItems: Array<SiteCatalogItem> = [];

    public sortOrder: string = "siteDodaac";

    // @ngInject
    constructor($http, $httpParamSerializerJQLike, $log, Authentication,
                private $state, private AbiGridStateService, private DmlesGridService,
                private SelectedProductService, private StateConstants) {

        super($http, $log, Authentication, $httpParamSerializerJQLike, "ABiSiteCatalog");
        this.$log.debug("%s - Start", this.serviceName);
    }

    public clearSiteCatalogItem() {
        this.siteCatalogItem = null;
    }

    public getSiteCatalogItem() {
        if (this.siteCatalogItem) {
            return this.siteCatalogItem;
        }
        return null;
    }

    public setSiteCatalogItem(item): void {
        this.siteCatalogItem = new SiteCatalogItem();
        this.siteCatalogItem.siteDodaac = item.siteDodaac;
        this.siteCatalogItem.itemId = item.itemId;
        this.siteCatalogItem.manufacturerNm = item.manufacturerNm;
        this.siteCatalogItem.manufCatNum = item.manufCatNum;
        this.siteCatalogItem.ndc = item.ndc;
        this.siteCatalogItem.longItemDesc = item.longItemDesc;
        this.siteCatalogItem.sources = item.sources;
        this.siteCatalogItem.orderCost = item.orderCost;
        this.siteCatalogItem.orderCount = item.orderCount;
    }

    public getSiteCatalogItems() {
        if (this.siteCatalogItems) {
            return this.siteCatalogItems;
        }
        return null;
    }

    public retrieveSiteCatalogItems(identifierType: string, identifier: string) {
        //this.$log.debug("identifierType: %s", JSON.stringify(identifierType));
        //this.$log.debug("identifier: %s", JSON.stringify(identifier));

        if (identifierType === "enterprise") {
            let action: string = "getSiteCatalogByEnterpriseId?enterpriseProductIdentifier=" + identifier;
            return this.get(action);
        } else if (identifierType === "product") {
            let action: string = "getSiteCatalogByProductId?productSeqId=" + identifier;
            return this.get(action);
        } else {
            return null;
        }
    };

    public getNumberOfSitesUsingThisAbiProduct(): number {
        // generate a random imteger between 1 and 20
        let min: number = 0;
        let max: number = 20;
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }

    public loadSiteCatalogItems(abiProduct) {
        if (abiProduct.mmcProductIdentifier) {
            this.SelectedProductService.setSelectedProduct(abiProduct);

            this.retrieveSiteCatalogItems("product", abiProduct.mmcProductIdentifier).then((response: any) => {
                this.siteCatalogItems = response.data;
                // this.$log.debug("this.siteCatalogItems: %s", JSON.stringify(this.siteCatalogItems));                
                this.goToViewSiteCatalogItems();
            }, (errResponse: any) => {
                this.$log.error("Error retrieving Site Catalog Records: %s", errResponse);
            });
        }
    };

    public displaySiteCatalogItems(abiProduct) {
        this.$log.debug("displaySiteCatalogItems - abiProduct.mmcProductIdentifier %s", JSON.stringify(abiProduct.mmcProductIdentifier));
        this.loadSiteCatalogItems(abiProduct);
    }


    public goToViewSiteCatalogItems() {
        // this.$log.debug("goToViewSiteCatalogItems");
        this.AbiGridStateService.searchSummaryResultsGridState = this.DmlesGridService.retrieveGridState();
        this.$state.go(this.StateConstants.ABI_PRODUCTS_SITE_CATALOG_ITEMS);
    }
}