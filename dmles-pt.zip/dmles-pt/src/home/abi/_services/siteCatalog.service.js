var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", '../../../_services/api.service', "../_models/siteCatalogItem.model"], function (require, exports, api_service_1, siteCatalogItem_model_1) {
    'use strict';
    var SiteCatalogService = (function (_super) {
        __extends(SiteCatalogService, _super);
        // @ngInject
        function SiteCatalogService($http, $httpParamSerializerJQLike, $log, Authentication, $state, datatableService, AbiGridStateService, DmlesGridService, SearchUtilService, SelectedProductService, StateConstants) {
            _super.call(this, $http, $log, Authentication, $httpParamSerializerJQLike, "ABiSiteCatalog");
            this.$state = $state;
            this.datatableService = datatableService;
            this.AbiGridStateService = AbiGridStateService;
            this.DmlesGridService = DmlesGridService;
            this.SearchUtilService = SearchUtilService;
            this.SelectedProductService = SelectedProductService;
            this.StateConstants = StateConstants;
            this.siteCatalogItem = new siteCatalogItem_model_1.SiteCatalogItem();
            this.serviceName = "Site Catalog Service";
            this.siteCatalogItems = [];
            // can delete if we get rid of ng-table
            this.ngSiteCatalogItemsTable = null;
            this.siteCatalogItemsTableFilterString = "";
            this.sortOrder = "siteDodaac";
            this.$log.debug("%s - Start", this.serviceName);
        }
        SiteCatalogService.prototype.clearSiteCatalogItem = function () {
            this.siteCatalogItem = null;
        };
        SiteCatalogService.prototype.getSiteCatalogItem = function () {
            if (this.siteCatalogItem) {
                return this.siteCatalogItem;
            }
            return null;
        };
        SiteCatalogService.prototype.setSiteCatalogItem = function (item) {
            this.siteCatalogItem = new siteCatalogItem_model_1.SiteCatalogItem();
            this.siteCatalogItem.siteDodaac = item.siteDodaac;
            this.siteCatalogItem.itemId = item.itemId;
            this.siteCatalogItem.manufacturerNm = item.manufacturerNm;
            this.siteCatalogItem.manufCatNum = item.manufCatNum;
            this.siteCatalogItem.ndc = item.ndc;
            this.siteCatalogItem.longItemDesc = item.longItemDesc;
            this.siteCatalogItem.sources = item.sources;
            this.siteCatalogItem.orderCost = item.orderCost;
            this.siteCatalogItem.orderCount = item.orderCount;
        };
        SiteCatalogService.prototype.getSiteCatalogItems = function () {
            if (this.siteCatalogItems) {
                return this.siteCatalogItems;
            }
            return null;
        };
        SiteCatalogService.prototype.retrieveSiteCatalogItems = function (identifierType, identifier) {
            //this.$log.debug("identifierType: %s", JSON.stringify(identifierType));
            //this.$log.debug("identifier: %s", JSON.stringify(identifier));
            if (identifierType === "enterprise") {
                var action = "getSiteCatalogByEnterpriseId?enterpriseProductIdentifier=" + identifier;
                return this.get(action);
            }
            else if (identifierType === "product") {
                var action = "getSiteCatalogByProductId?productSeqId=" + identifier;
                return this.get(action);
            }
            else {
                return null;
            }
        };
        ;
        SiteCatalogService.prototype.getSiteCatalogRecordCount = function (identifierType, identifier) {
            //this.$log.debug("identifierType: %s", JSON.stringify(identifierType));
            //this.$log.debug("identifier: %s", JSON.stringify(identifier));
            if (identifierType === "enterprise") {
                var action = "getSiteCatalogCountByEnterpriseId?enterpriseProductIdentifier=" + identifier;
                return this.get(action);
            }
            else if (identifierType === "product") {
                var action = "getSiteCatalogCountByProductId?productSeqId=" + identifier;
                return this.get(action);
            }
            else {
                return null;
            }
        };
        ;
        SiteCatalogService.prototype.getNumberOfSitesUsingThisAbiProduct = function () {
            // generate a random imteger between 1 and 20
            var min = 0;
            var max = 20;
            return Math.floor(Math.random() * (max - min + 1)) + min;
        };
        SiteCatalogService.prototype.loadSiteCatalogItems = function (abiProduct) {
            var _this = this;
            if (abiProduct.mmcProductIdentifier) {
                this.SelectedProductService.setSelectedProduct(abiProduct);
                this.retrieveSiteCatalogItems("product", abiProduct.mmcProductIdentifier).then(function (response) {
                    _this.siteCatalogItems = response.data;
                    _this.SearchUtilService.sortByCriteria(_this.siteCatalogItems, [_this.sortOrder]);
                    // this.$log.debug("this.siteCatalogItems: %s", JSON.stringify(this.siteCatalogItems));
                    _this.ngSiteCatalogItemsTable = _this.datatableService.createNgTable(_this.siteCatalogItems);
                    _this.goToViewSiteCatalogItems();
                }, function (errResponse) {
                    _this.$log.error("Error retrieving Site Catalog Records: %s", errResponse);
                });
            }
        };
        ;
        SiteCatalogService.prototype.displaySiteCatalogItems = function (abiProduct) {
            this.$log.debug("displaySiteCatalogItems - abiProduct.mmcProductIdentifier %s", JSON.stringify(abiProduct.mmcProductIdentifier));
            this.siteCatalogItemsTableFilterString = "";
            this.loadSiteCatalogItems(abiProduct);
        };
        SiteCatalogService.prototype.siteCatalogProductsTableFilter = function () {
            this.ngSiteCatalogItemsTable.filter({ $: this.siteCatalogItemsTableFilterString });
            this.ngSiteCatalogItemsTable.reload();
        };
        SiteCatalogService.prototype.goToViewSiteCatalogItems = function () {
            // this.$log.debug("goToViewSiteCatalogItems");
            this.AbiGridStateService.searchSummaryResultsGridState = this.DmlesGridService.retrieveGridState();
            this.$state.go(this.StateConstants.ABI_PRODUCTS_SITE_CATALOG_ITEMS);
        };
        return SiteCatalogService;
    }(api_service_1.ApiService));
    exports.SiteCatalogService = SiteCatalogService;
});
//# sourceMappingURL=siteCatalog.service.js.map