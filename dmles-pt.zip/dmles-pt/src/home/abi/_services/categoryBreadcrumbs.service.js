define(["require", "exports", "./categoryBreadcrumb.service"], function (require, exports, categoryBreadcrumb_service_1) {
    'use strict';
    var CategoryBreadcrumbsService = (function () {
        // @ngInject
        function CategoryBreadcrumbsService($log, $rootScope, SearchUtilService) {
            this.$log = $log;
            this.$rootScope = $rootScope;
            this.SearchUtilService = SearchUtilService;
            this.categoryBreadcrumbs = [];
            var displayLabel = "";
            displayLabel = "Product Category";
            this.categoryBreadcrumbs.push(new categoryBreadcrumb_service_1.CategoryBreadcrumb($log, $rootScope, displayLabel, SearchUtilService));
            displayLabel = "Product Type";
            this.categoryBreadcrumbs.push(new categoryBreadcrumb_service_1.CategoryBreadcrumb($log, $rootScope, displayLabel, SearchUtilService));
        }
        CategoryBreadcrumbsService.prototype.getCategoryBreadcrumbs = function () {
            return this.categoryBreadcrumbs;
        };
        CategoryBreadcrumbsService.prototype.areCategoryOptionsSelected = function () {
            var returnValue = false;
            for (var i = 0; i < this.categoryBreadcrumbs.length; i++) {
                var categoryBreadcrumb = this.categoryBreadcrumbs[i];
                if (categoryBreadcrumb.getSelectedCategoryOptions().length > 0) {
                    returnValue = true;
                }
            }
            return returnValue;
        };
        CategoryBreadcrumbsService.prototype.clearAllBreadcrumbs = function () {
            for (var i = 0; i < this.categoryBreadcrumbs.length; i++) {
                var categoryBreadcrumb = this.categoryBreadcrumbs[i];
                categoryBreadcrumb.clearSelectedCategoryOptions();
                // don't executeSearch here - the calling method handles it
                var executeSearch = false;
                categoryBreadcrumb.clearAllCategoryOptionSelections(executeSearch);
            }
        };
        return CategoryBreadcrumbsService;
    }());
    exports.CategoryBreadcrumbsService = CategoryBreadcrumbsService;
});
//# sourceMappingURL=categoryBreadcrumbs.service.js.map