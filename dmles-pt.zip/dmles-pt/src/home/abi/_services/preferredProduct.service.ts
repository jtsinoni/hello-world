'use strict';

import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {AbiProduct} from "../_models/abiProduct.model";

export class PreferredProductService {
    private serviceName: string = "Preferred Product Service";
    public preferredProduct: AbiProduct = null;
    public selectedProduct: AbiProduct = null;

    // @ngInject
    constructor(private $log, private $state, private AbiService,
                private NotificationService, private StateConstants) {
    }

    public displayPreferredProduct(abiProduct) {
        this.selectedProduct = abiProduct;

        this.$log.debug("displayPreferredProduct - abiProduct.mmcPreferredProductIdentifier %s", JSON.stringify(abiProduct.mmcPreferredProductIdentifier));
        this.loadPreferredProduct(abiProduct);
    }

    private loadPreferredProduct(abiProduct) {

        let userSpecifiedFilters = "(mmcProductIdentifier:" + abiProduct.mmcPreferredProductIdentifier + ")";

        this.AbiService.getSummaryAbiProducts("", userSpecifiedFilters, "{}").then((response: IHttpPromiseCallbackArg<any>) => {
            this.$log.debug("response: %s", JSON.stringify(response));

            let resultsArray: Array<AbiProduct> = [];
            resultsArray = this.AbiService.parseAbiProductSummaryResults(response);
            this.preferredProduct = resultsArray[0];
            this.$log.debug("this.preferredProduct: %s", JSON.stringify(this.preferredProduct));

            // if the preferredProduct's info was not successfully retrieved, show error message
            if (!this.preferredProduct) {
                this.$log.debug("%s - the preferred product info was not successfully retrieved using mmcPreferredProductIdentifier: %s",
                    this.serviceName, abiProduct.mmcPreferredProductIdentifier);
                this.NotificationService.errorMsg("The preferred product's info was not found");
            } else {
                // the preferredProduct's info was successfully retrieved, go to preferred product view
                this.goToViewPreferredProduct();
            }
        }, (errResponse: IHttpPromiseCallbackArg<boolean>) => {
            //this.isLoadingSearch = false;
            this.$log.debug("%s - Error getting preferred product from elastic.", this.serviceName);
            this.NotificationService.errorMsg("An error occurred while retrieving preferred product");
        });
    }

    public goToViewPreferredProduct() {
        this.$state.go(this.StateConstants.ABI_PREFERRED_PRODUCT);
    }
}