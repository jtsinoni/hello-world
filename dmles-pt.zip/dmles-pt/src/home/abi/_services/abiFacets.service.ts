'use strict';

import {AbiFacet} from "./abiFacet.service";
import {FacetConfiguration} from "../../../_models/facetConfiguration.model";

export class AbiFacetsService {

    public facets: Array<any> = [];

    // @ngInject
    constructor($log, $rootScope, private SearchUtilService) {
        // new AbiFacet(displayLabel, aggregationIdentifier, elasticSearchFieldName)
        let manufacturerFacetConfiguration: FacetConfiguration = {
            displayLabel: "Manufacturer",
            aggregationIdentifier: "manufacturers",
            elasticSearchFieldName: "manufacturer",
            initializeAsCollapsed: false,
            isDisplayed: true
        };
        this.facets.push(new AbiFacet($log, $rootScope, manufacturerFacetConfiguration, SearchUtilService));

        let productCompositionFacetConfiguration: FacetConfiguration = {
            displayLabel: "Product Composition",
            aggregationIdentifier: "productCompositions",
            elasticSearchFieldName: "productComposition",
            initializeAsCollapsed: true,
            isDisplayed: true
        };
        this.facets.push(new AbiFacet($log, $rootScope, productCompositionFacetConfiguration, SearchUtilService));

        let trademarkBrandnamesFacetConfiguration: FacetConfiguration = {
            displayLabel: "Trademark/Brandname",
            aggregationIdentifier: "trademarkBrandnamess",
            elasticSearchFieldName: "trademarkBrandnames",
            initializeAsCollapsed: true,
            isDisplayed: true
        };
        this.facets.push(new AbiFacet($log, $rootScope, trademarkBrandnamesFacetConfiguration, SearchUtilService));

        let ageFacetConfiguration: FacetConfiguration = {
            displayLabel: "Age",
            aggregationIdentifier: "ages",
            elasticSearchFieldName: "age",
            initializeAsCollapsed: true,
            isDisplayed: true
        };
        this.facets.push(new AbiFacet($log, $rootScope, ageFacetConfiguration, SearchUtilService));

        let genderFacetConfiguration: FacetConfiguration = {
            displayLabel: "Gender",
            aggregationIdentifier: "genders",
            elasticSearchFieldName: "gender",
            initializeAsCollapsed: true,
            isDisplayed: true
        };
        this.facets.push(new AbiFacet($log, $rootScope, genderFacetConfiguration, SearchUtilService));

        let sizeShapeFacetConfiguration: FacetConfiguration = {
            displayLabel: "Size/Shape",
            aggregationIdentifier: "sizeShapes",
            elasticSearchFieldName: "sizeShape",
            initializeAsCollapsed: true,
            isDisplayed: true
        };
        this.facets.push(new AbiFacet($log, $rootScope, sizeShapeFacetConfiguration, SearchUtilService));

        let colorFacetConfiguration: FacetConfiguration = {
            displayLabel: "Color",
            aggregationIdentifier: "colors",
            elasticSearchFieldName: "color",
            initializeAsCollapsed: true,
            isDisplayed: true
        };
        this.facets.push(new AbiFacet($log, $rootScope, colorFacetConfiguration, SearchUtilService));

        let flavorFacetConfiguration: FacetConfiguration = {
            displayLabel: "Flavor",
            aggregationIdentifier: "flavors",
            elasticSearchFieldName: "flavor",
            initializeAsCollapsed: true,
            isDisplayed: true
        };
        this.facets.push(new AbiFacet($log, $rootScope, flavorFacetConfiguration, SearchUtilService));

        let fragranceFacetConfiguration: FacetConfiguration = {
            displayLabel: "Fragrance",
            aggregationIdentifier: "fragrances",
            elasticSearchFieldName: "fragrance",
            initializeAsCollapsed: true,
            isDisplayed: true
        };
        this.facets.push(new AbiFacet($log, $rootScope, fragranceFacetConfiguration, SearchUtilService));

        let sterileNonsterileFacetConfiguration: FacetConfiguration = {
            displayLabel: "Sterile/Nonsterile",
            aggregationIdentifier: "sterileNonsteriles",
            elasticSearchFieldName: "sterileNonsterile",
            initializeAsCollapsed: true,
            isDisplayed: true
        };
        this.facets.push(new AbiFacet($log, $rootScope, sterileNonsterileFacetConfiguration, SearchUtilService));

        let latexCodeFacetConfiguration: FacetConfiguration = {
            displayLabel: "Latex Code",
            aggregationIdentifier: "latexCodes",
            elasticSearchFieldName: "latexCode",
            initializeAsCollapsed: true,
            isDisplayed: true
        };
        this.facets.push(new AbiFacet($log, $rootScope, latexCodeFacetConfiguration, SearchUtilService));

        let disposibleReuseableFacetConfiguration: FacetConfiguration = {
            displayLabel: "Disposeable/Reuseable",
            aggregationIdentifier: "disposibleReuseables",
            elasticSearchFieldName: "disposibleReuseable",
            initializeAsCollapsed: true,
            isDisplayed: true
        };
        this.facets.push(new AbiFacet($log, $rootScope, disposibleReuseableFacetConfiguration, SearchUtilService));

        let diameterFacetConfiguration: FacetConfiguration = {
            displayLabel: "Diameter",
            aggregationIdentifier: "diameters",
            elasticSearchFieldName: "diameter",
            initializeAsCollapsed: true,
            isDisplayed: true
        };
        this.facets.push(new AbiFacet($log, $rootScope, diameterFacetConfiguration, SearchUtilService));

        let volumeFacetConfiguration: FacetConfiguration = {
            displayLabel: "Volume",
            aggregationIdentifier: "volumes",
            elasticSearchFieldName: "volume",
            initializeAsCollapsed: true,
            isDisplayed: true
        };
        this.facets.push(new AbiFacet($log, $rootScope, volumeFacetConfiguration, SearchUtilService));

        let weightFacetConfiguration: FacetConfiguration = {
            displayLabel: "Weight",
            aggregationIdentifier: "weights",
            elasticSearchFieldName: "weight",
            initializeAsCollapsed: true,
            isDisplayed: true
        };
        this.facets.push(new AbiFacet($log, $rootScope, weightFacetConfiguration, SearchUtilService));

        let lengthWidthHeightFacetConfiguration: FacetConfiguration = {
            displayLabel: "Length/Width/Height",
            aggregationIdentifier: "lengthWidthHeights",
            elasticSearchFieldName: "lengthWidthHeight",
            initializeAsCollapsed: true,
            isDisplayed: true
        };
        this.facets.push(new AbiFacet($log, $rootScope, lengthWidthHeightFacetConfiguration, SearchUtilService));

        let lengthWidthHeight2FacetConfiguration: FacetConfiguration = {
            displayLabel: "Length/Width/Height2",
            aggregationIdentifier: "lengthWidthHeight2s",
            elasticSearchFieldName: "lengthWidthHeight2",
            initializeAsCollapsed: true,
            isDisplayed: true
        };
        this.facets.push(new AbiFacet($log, $rootScope, lengthWidthHeight2FacetConfiguration, SearchUtilService));

        let productPropertiesFacetConfiguration: FacetConfiguration = {
            displayLabel: "Product Properties",
            aggregationIdentifier: "productPropertiess",
            elasticSearchFieldName: "productProperties",
            initializeAsCollapsed: true,
            isDisplayed: true
        };
        this.facets.push(new AbiFacet($log, $rootScope, productPropertiesFacetConfiguration, SearchUtilService));

        let locationsFacetConfiguration: FacetConfiguration = {
            displayLabel: "Locations",
            aggregationIdentifier: "locationss",
            elasticSearchFieldName: "locations",
            initializeAsCollapsed: true,
            isDisplayed: true
        };
        this.facets.push(new AbiFacet($log, $rootScope, locationsFacetConfiguration, SearchUtilService));

        let miscellaneousFacetConfiguration: FacetConfiguration = {
            displayLabel: "Miscellaneous",
            aggregationIdentifier: "miscellaneouses",
            elasticSearchFieldName: "miscellaneous",
            initializeAsCollapsed: true,
            isDisplayed: true
        };
        this.facets.push(new AbiFacet($log, $rootScope, miscellaneousFacetConfiguration, SearchUtilService));

        let unspscSegmentFacetConfiguration: FacetConfiguration = {
            displayLabel: "UNSPSC Segment",
            aggregationIdentifier: "unspscSegments",
            elasticSearchFieldName: "unspscSegment",
            initializeAsCollapsed: true,
            isDisplayed: false
        };
        this.facets.push(new AbiFacet($log, $rootScope, unspscSegmentFacetConfiguration, SearchUtilService));

        let unspscFamilyFacetConfiguration: FacetConfiguration = {
            displayLabel: "UNSPSC Family",
            aggregationIdentifier: "unspscFamilies",
            elasticSearchFieldName: "unspscFamily",
            initializeAsCollapsed: true,
            isDisplayed: false
        };
        this.facets.push(new AbiFacet($log, $rootScope, unspscFamilyFacetConfiguration, SearchUtilService));

        let unspscClassFacetConfiguration: FacetConfiguration = {
            displayLabel: "UNSPSC Class",
            aggregationIdentifier: "unspscClasses",
            elasticSearchFieldName: "unspscClass",
            initializeAsCollapsed: true,
            isDisplayed: false
        };
        this.facets.push(new AbiFacet($log, $rootScope, unspscClassFacetConfiguration, SearchUtilService));

        let unspscCommodityFacetConfiguration: FacetConfiguration = {
            displayLabel: "UNSPSC Commodity",
            aggregationIdentifier: "unspscCommodities",
            elasticSearchFieldName: "unspscCommodity",
            initializeAsCollapsed: true,
            isDisplayed: false
        };
        this.facets.push(new AbiFacet($log, $rootScope, unspscCommodityFacetConfiguration, SearchUtilService));

        let productNounFacetConfiguration: FacetConfiguration = {
            displayLabel: "Product Noun",
            aggregationIdentifier: "productNouns",
            elasticSearchFieldName: "productNoun",
            initializeAsCollapsed: true,
            isDisplayed: false
        };
        this.facets.push(new AbiFacet($log, $rootScope, productNounFacetConfiguration, SearchUtilService));

        let productTypeFacetConfiguration: FacetConfiguration = {
            displayLabel: "Product Type",
            aggregationIdentifier: "productTypes",
            elasticSearchFieldName: "productType",
            initializeAsCollapsed: true,
            isDisplayed: false
        };
        this.facets.push(new AbiFacet($log, $rootScope, productTypeFacetConfiguration, SearchUtilService));

        let commodityTypeFacetConfiguration: FacetConfiguration = {
            displayLabel: "Commodity Type",
            aggregationIdentifier: "commodityTypes",
            elasticSearchFieldName: "commodityType",
            initializeAsCollapsed: true,
            isDisplayed: false
        };
        this.facets.push(new AbiFacet($log, $rootScope, commodityTypeFacetConfiguration, SearchUtilService));

    }

    public getFacets(): Array<any> {
        return this.facets;
    }

    public getCategoryFacets(): Array<any> {
        let categoryFacets: Array<any> = [];
        angular.forEach(this.facets, (facet) => {
            if (facet.facetConfiguration.displayLabel === "UNSPSC Segment" ||
                facet.facetConfiguration.displayLabel === "UNSPSC Family" ||
                facet.facetConfiguration.displayLabel === "UNSPSC Class" ||
                facet.facetConfiguration.displayLabel === "UNSPSC Commodity" ||
                facet.facetConfiguration.displayLabel === "Product Noun" ||
                facet.facetConfiguration.displayLabel === "Product Type" ||
                facet.facetConfiguration.displayLabel === "Commodity Type") {

                categoryFacets.push(facet);
            }
        });
        return categoryFacets;
    }
}