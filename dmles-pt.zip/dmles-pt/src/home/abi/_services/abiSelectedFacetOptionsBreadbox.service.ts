'use strict';

import {BaseSelectedFacetOptionsService} from "../../../_directives/searchComponents/selectedFacetOptionsBreadbox/baseSelectedFacetOptions.service";
import {SearchConstants} from "../../../_constants/search.constants";

export class AbiSelectedFacetOptionsBreadboxService extends BaseSelectedFacetOptionsService {

    // this module (for event purposes)
    public eventModule: string = SearchConstants.EVENT_MODULE_ABI;

    // @ngInject
    constructor($log, $state, $rootScope, AbiCategoryBreadcrumbsService, AbiFacetsService, SearchUtilService, StateConstants) {
        super($log, $state, $rootScope, AbiCategoryBreadcrumbsService, AbiFacetsService, SearchUtilService, StateConstants);

        this.init();
    }
}