define(["require", "exports", "../../../_constants/search.constants"], function (require, exports, search_constants_1) {
    'use strict';
    var SearchUtilService = (function () {
        function SearchUtilService($document, $log, $rootScope, FileManagerService) {
            this.$document = $document;
            this.$log = $log;
            this.$rootScope = $rootScope;
            this.FileManagerService = FileManagerService;
            this.downloadFileInfo = null;
        }
        SearchUtilService.prototype.buildEventId = function (module, component, action) {
            return module + ":" + component + ":" + action;
        };
        SearchUtilService.prototype.executeSearch = function (eventModule, data) {
            var eventId = this.buildEventId(eventModule, search_constants_1.SearchConstants.EVENT_TARGET_COMPONENT_SEARCH, search_constants_1.SearchConstants.EVENT_TARGET_METHOD_EXECUTE_SEARCH);
            this.$log.debug("emit: %s", JSON.stringify(eventId));
            this.$rootScope.$emit(eventId, data);
        };
        SearchUtilService.prototype.updateSelectedFacetOptions = function (eventModule, facetOption) {
            var eventId = this.buildEventId(eventModule, search_constants_1.SearchConstants.EVENT_TARGET_COMPONENT_SELECTED_FACET_OPTIONS_BREADBOX, search_constants_1.SearchConstants.EVENT_TARGET_METHOD_UPDATE_SELECTED_FACET_OPTIONS);
            this.$rootScope.$emit(eventId, facetOption);
        };
        SearchUtilService.prototype.sortByCriteria = function (data, criteria) {
            return data.sort(function (a, b) {
                var i, iLen, aChain, bChain;
                i = 0;
                iLen = criteria.length;
                for (i; i < iLen; i++) {
                    aChain += a[criteria[i]];
                    bChain += b[criteria[i]];
                }
                return aChain.localeCompare(bChain);
            });
        };
        SearchUtilService.prototype.getFileIdFromUrl = function (url) {
            var fileId = "";
            var fileIdPos = url.lastIndexOf("fileId=");
            if (fileIdPos >= 0) {
                fileId = url.substring(fileIdPos + 7);
            }
            return fileId;
        };
        SearchUtilService.prototype.setProductImageSrcs = function (target, images) {
            var _this = this;
            // set up the default to use when an image hasn't been uploaded or found when we try to retrieve it
            var doc = this.$document[0];
            var primaryImage = doc.getElementById(target + "Image");
            primaryImage.src = "/src/content/images/imageNotAvailable.jpg";
            var _loop_1 = function(i) {
                var thumbRoot = target + "Thumb";
                this_1[thumbRoot + i] = doc.getElementById(thumbRoot + i);
                this_1[thumbRoot + i].src = "/src/content/images/imageNotAvailable.jpg";
                if (images[i] && images[i] !== "/src/content/images/imageNotAvailable.jpg") {
                    // If productImages was passed in via the ES response, set img src to it
                    this_1.$log.debug("images[%d]: %s", i, JSON.stringify(images[i]));
                    var fileId = this_1.getFileIdFromUrl(images[i]);
                    this_1.FileManagerService.base64download(fileId).then(function (downloadResponse) {
                        var responseHeaders = downloadResponse.headers();
                        _this.contentType = responseHeaders["content-type"];
                        var data = downloadResponse.data;
                        if (i === 0) {
                            primaryImage.src = "data:" + _this.contentType + ";base64," + data;
                            _this[thumbRoot + i].src = primaryImage.src;
                        }
                        else if (i > 0) {
                            // limited to 10 product images for now
                            if (i < 10) {
                                _this[thumbRoot + i].src = "data:" + _this.contentType + ";base64," + data;
                            }
                        }
                    }, function (errResponse) {
                        _this.$log.error("Error retrieving Product Images: %s", errResponse);
                    });
                }
            };
            var this_1 = this;
            for (var i = 0; i < images.length; i++) {
                _loop_1(i);
            }
        };
        SearchUtilService.prototype.switchProductImageSrc = function (target, imageNumber, images) {
            var doc = this.$document[0];
            var primaryImage = doc.getElementById(target + "Image");
            var thumbRoot = target + "Thumb";
            for (var i = 0; i < images.length; i++) {
                this[thumbRoot + i] = doc.getElementById(thumbRoot + i);
            }
            primaryImage.src = this[thumbRoot + imageNumber].src;
        };
        return SearchUtilService;
    }());
    exports.SearchUtilService = SearchUtilService;
});
//# sourceMappingURL=searchUtil.service.js.map