define(["require", "exports", "./facet.service"], function (require, exports, facet_service_1) {
    'use strict';
    var FacetsService = (function () {
        // @ngInject
        function FacetsService($log, $rootScope, SearchUtilService) {
            this.SearchUtilService = SearchUtilService;
            this.facets = [];
            // new Facet(displayLabel, aggregationIdentifier, elasticSearchFieldName)
            var manufacturerFacetConfiguration = {
                displayLabel: "Manufacturer",
                aggregationIdentifier: "manufacturers",
                elasticSearchFieldName: "manufacturer",
                initializeAsCollapsed: false,
                isDisplayed: true
            };
            this.facets.push(new facet_service_1.Facet($log, $rootScope, manufacturerFacetConfiguration, SearchUtilService));
            var productCompositionFacetConfiguration = {
                displayLabel: "Product Composition",
                aggregationIdentifier: "productCompositions",
                elasticSearchFieldName: "productComposition",
                initializeAsCollapsed: true,
                isDisplayed: true
            };
            this.facets.push(new facet_service_1.Facet($log, $rootScope, productCompositionFacetConfiguration, SearchUtilService));
            var trademarkBrandnamesFacetConfiguration = {
                displayLabel: "Trademark/Brandname",
                aggregationIdentifier: "trademarkBrandnamess",
                elasticSearchFieldName: "trademarkBrandnames",
                initializeAsCollapsed: true,
                isDisplayed: true
            };
            this.facets.push(new facet_service_1.Facet($log, $rootScope, trademarkBrandnamesFacetConfiguration, SearchUtilService));
            var ageFacetConfiguration = {
                displayLabel: "Age",
                aggregationIdentifier: "ages",
                elasticSearchFieldName: "age",
                initializeAsCollapsed: true,
                isDisplayed: true
            };
            this.facets.push(new facet_service_1.Facet($log, $rootScope, ageFacetConfiguration, SearchUtilService));
            var genderFacetConfiguration = {
                displayLabel: "Gender",
                aggregationIdentifier: "genders",
                elasticSearchFieldName: "gender",
                initializeAsCollapsed: true,
                isDisplayed: true
            };
            this.facets.push(new facet_service_1.Facet($log, $rootScope, genderFacetConfiguration, SearchUtilService));
            var sizeShapeFacetConfiguration = {
                displayLabel: "Size/Shape",
                aggregationIdentifier: "sizeShapes",
                elasticSearchFieldName: "sizeShape",
                initializeAsCollapsed: true,
                isDisplayed: true
            };
            this.facets.push(new facet_service_1.Facet($log, $rootScope, sizeShapeFacetConfiguration, SearchUtilService));
            var colorFacetConfiguration = {
                displayLabel: "Color",
                aggregationIdentifier: "colors",
                elasticSearchFieldName: "color",
                initializeAsCollapsed: true,
                isDisplayed: true
            };
            this.facets.push(new facet_service_1.Facet($log, $rootScope, colorFacetConfiguration, SearchUtilService));
            var flavorFacetConfiguration = {
                displayLabel: "Flavor",
                aggregationIdentifier: "flavors",
                elasticSearchFieldName: "flavor",
                initializeAsCollapsed: true,
                isDisplayed: true
            };
            this.facets.push(new facet_service_1.Facet($log, $rootScope, flavorFacetConfiguration, SearchUtilService));
            var fragranceFacetConfiguration = {
                displayLabel: "Fragrance",
                aggregationIdentifier: "fragrances",
                elasticSearchFieldName: "fragrance",
                initializeAsCollapsed: true,
                isDisplayed: true
            };
            this.facets.push(new facet_service_1.Facet($log, $rootScope, fragranceFacetConfiguration, SearchUtilService));
            var sterileNonsterileFacetConfiguration = {
                displayLabel: "Sterile/Nonsterile",
                aggregationIdentifier: "sterileNonsteriles",
                elasticSearchFieldName: "sterileNonsterile",
                initializeAsCollapsed: true,
                isDisplayed: true
            };
            this.facets.push(new facet_service_1.Facet($log, $rootScope, sterileNonsterileFacetConfiguration, SearchUtilService));
            var latexCodeFacetConfiguration = {
                displayLabel: "Latex Code",
                aggregationIdentifier: "latexCodes",
                elasticSearchFieldName: "latexCode",
                initializeAsCollapsed: true,
                isDisplayed: true
            };
            this.facets.push(new facet_service_1.Facet($log, $rootScope, latexCodeFacetConfiguration, SearchUtilService));
            var disposibleReuseableFacetConfiguration = {
                displayLabel: "Disposeable/Reuseable",
                aggregationIdentifier: "disposibleReuseables",
                elasticSearchFieldName: "disposibleReuseable",
                initializeAsCollapsed: true,
                isDisplayed: true
            };
            this.facets.push(new facet_service_1.Facet($log, $rootScope, disposibleReuseableFacetConfiguration, SearchUtilService));
            var diameterFacetConfiguration = {
                displayLabel: "Diameter",
                aggregationIdentifier: "diameters",
                elasticSearchFieldName: "diameter",
                initializeAsCollapsed: true,
                isDisplayed: true
            };
            this.facets.push(new facet_service_1.Facet($log, $rootScope, diameterFacetConfiguration, SearchUtilService));
            var volumeFacetConfiguration = {
                displayLabel: "Volume",
                aggregationIdentifier: "volumes",
                elasticSearchFieldName: "volume",
                initializeAsCollapsed: true,
                isDisplayed: true
            };
            this.facets.push(new facet_service_1.Facet($log, $rootScope, volumeFacetConfiguration, SearchUtilService));
            var weightFacetConfiguration = {
                displayLabel: "Weight",
                aggregationIdentifier: "weights",
                elasticSearchFieldName: "weight",
                initializeAsCollapsed: true,
                isDisplayed: true
            };
            this.facets.push(new facet_service_1.Facet($log, $rootScope, weightFacetConfiguration, SearchUtilService));
            var lengthWidthHeightFacetConfiguration = {
                displayLabel: "Length/Width/Height",
                aggregationIdentifier: "lengthWidthHeights",
                elasticSearchFieldName: "lengthWidthHeight",
                initializeAsCollapsed: true,
                isDisplayed: true
            };
            this.facets.push(new facet_service_1.Facet($log, $rootScope, lengthWidthHeightFacetConfiguration, SearchUtilService));
            var lengthWidthHeight2FacetConfiguration = {
                displayLabel: "Length/Width/Height2",
                aggregationIdentifier: "lengthWidthHeight2s",
                elasticSearchFieldName: "lengthWidthHeight2",
                initializeAsCollapsed: true,
                isDisplayed: true
            };
            this.facets.push(new facet_service_1.Facet($log, $rootScope, lengthWidthHeight2FacetConfiguration, SearchUtilService));
            var productPropertiesFacetConfiguration = {
                displayLabel: "Product Properties",
                aggregationIdentifier: "productPropertiess",
                elasticSearchFieldName: "productProperties",
                initializeAsCollapsed: true,
                isDisplayed: true
            };
            this.facets.push(new facet_service_1.Facet($log, $rootScope, productPropertiesFacetConfiguration, SearchUtilService));
            var locationsFacetConfiguration = {
                displayLabel: "Locations",
                aggregationIdentifier: "locationss",
                elasticSearchFieldName: "locations",
                initializeAsCollapsed: true,
                isDisplayed: true
            };
            this.facets.push(new facet_service_1.Facet($log, $rootScope, locationsFacetConfiguration, SearchUtilService));
            var miscellaneousFacetConfiguration = {
                displayLabel: "Miscellaneous",
                aggregationIdentifier: "miscellaneouses",
                elasticSearchFieldName: "miscellaneous",
                initializeAsCollapsed: true,
                isDisplayed: true
            };
            this.facets.push(new facet_service_1.Facet($log, $rootScope, miscellaneousFacetConfiguration, SearchUtilService));
            var unspscSegmentFacetConfiguration = {
                displayLabel: "UNSPSC Segment",
                aggregationIdentifier: "unspscSegments",
                elasticSearchFieldName: "unspscSegment",
                initializeAsCollapsed: true,
                isDisplayed: false
            };
            this.facets.push(new facet_service_1.Facet($log, $rootScope, unspscSegmentFacetConfiguration, SearchUtilService));
            var unspscFamilyFacetConfiguration = {
                displayLabel: "UNSPSC Family",
                aggregationIdentifier: "unspscFamilies",
                elasticSearchFieldName: "unspscFamily",
                initializeAsCollapsed: true,
                isDisplayed: false
            };
            this.facets.push(new facet_service_1.Facet($log, $rootScope, unspscFamilyFacetConfiguration, SearchUtilService));
            var unspscClassFacetConfiguration = {
                displayLabel: "UNSPSC Class",
                aggregationIdentifier: "unspscClasses",
                elasticSearchFieldName: "unspscClass",
                initializeAsCollapsed: true,
                isDisplayed: false
            };
            this.facets.push(new facet_service_1.Facet($log, $rootScope, unspscClassFacetConfiguration, SearchUtilService));
            var unspscCommodityFacetConfiguration = {
                displayLabel: "UNSPSC Commodity",
                aggregationIdentifier: "unspscCommodities",
                elasticSearchFieldName: "unspscCommodity",
                initializeAsCollapsed: true,
                isDisplayed: false
            };
            this.facets.push(new facet_service_1.Facet($log, $rootScope, unspscCommodityFacetConfiguration, SearchUtilService));
            var productNounFacetConfiguration = {
                displayLabel: "Product Noun",
                aggregationIdentifier: "productNouns",
                elasticSearchFieldName: "productNoun",
                initializeAsCollapsed: true,
                isDisplayed: false
            };
            this.facets.push(new facet_service_1.Facet($log, $rootScope, productNounFacetConfiguration, SearchUtilService));
            var productTypeFacetConfiguration = {
                displayLabel: "Product Type",
                aggregationIdentifier: "productTypes",
                elasticSearchFieldName: "productType",
                initializeAsCollapsed: true,
                isDisplayed: false
            };
            this.facets.push(new facet_service_1.Facet($log, $rootScope, productTypeFacetConfiguration, SearchUtilService));
        }
        FacetsService.prototype.getFacets = function () {
            return this.facets;
        };
        FacetsService.prototype.getCategoryFacets = function () {
            var categoryFacets = [];
            angular.forEach(this.facets, function (facet) {
                if (facet.facetConfiguration.displayLabel === "UNSPSC Segment" ||
                    facet.facetConfiguration.displayLabel === "UNSPSC Family" ||
                    facet.facetConfiguration.displayLabel === "UNSPSC Class" ||
                    facet.facetConfiguration.displayLabel === "UNSPSC Commodity" ||
                    facet.facetConfiguration.displayLabel === "Product Noun" ||
                    facet.facetConfiguration.displayLabel === "Product Type") {
                    categoryFacets.push(facet);
                }
            });
            return categoryFacets;
        };
        return FacetsService;
    }());
    exports.FacetsService = FacetsService;
});
//# sourceMappingURL=facets.service.js.map