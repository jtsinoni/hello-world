'use strict';

import {FacetOption} from "../../../_models/facetOption.model";
import {SearchConstants} from "../../../_constants/search.constants";

export class SearchUtilService {

    public contentType: string;
    public downloadFileInfo: any = null;

    constructor(private $log, private $rootScope, private $sce, private FileManagerService) {
    }

    public buildEventId(module: string, component: string, action: string): string {
        return module + ":" + component + ":" + action;
    }

    public executeSearch(eventModule: string, data: any) {
        let eventId = this.buildEventId(
            eventModule,
            SearchConstants.EVENT_TARGET_COMPONENT_SEARCH,
            SearchConstants.EVENT_TARGET_METHOD_EXECUTE_SEARCH);

        this.$log.debug("emit: %s", JSON.stringify(eventId));
        this.$rootScope.$emit(eventId, data);
    }

    public updateSelectedFacetOptions(eventModule: string, facetOption: FacetOption) {
        let eventId = this.buildEventId(
            eventModule,
            SearchConstants.EVENT_TARGET_COMPONENT_SELECTED_FACET_OPTIONS_BREADBOX,
            SearchConstants.EVENT_TARGET_METHOD_UPDATE_SELECTED_FACET_OPTIONS);

        this.$rootScope.$emit(eventId, facetOption);
    }

    public sortByCriteria(data, criteria) {
        return data.sort(function (a, b) {

            let i, iLen, aChain, bChain;

            i = 0;
            iLen = criteria.length;
            for (i; i < iLen; i++) {
                aChain += a[criteria[i]];
                bChain += b[criteria[i]];
            }

            return aChain.localeCompare(bChain);
        });
    }

    public getFileIdFromUrl(url: string): string {
        let fileId = "";
        let fileIdPos = url.lastIndexOf("fileId=");
        if (fileIdPos >= 0) {
            fileId = url.substring(fileIdPos + 7);
        }
        return fileId;
    }

    public setProductImages(images: Array<string>, imageObj: any): void {

        imageObj.primaryImage = null;
        if (images[0] && images[0] === "/src/content/images/imageNotAvailable.jpg") {
            imageObj.primaryImage = "/src/content/images/imageNotAvailable.jpg";
        }

        imageObj.thumbnailImages = [];

        for (let i = 0; i < images.length; i++) {

            if (images[i] && images[i] !== "/src/content/images/imageNotAvailable.jpg") {

                // If productImages was passed in via the ES response, set img src to it
                this.$log.debug("images[%d]: %s", i, JSON.stringify(images[i]));

                let fileId = this.getFileIdFromUrl(images[i]);

                this.FileManagerService.download(fileId)
                    .success((data, status, headers, config) => {
                        let file = new Blob([data], {type: 'Aplication/pdf'});
                        let fileURL = URL.createObjectURL(file);
                        this.FileManagerService.embedContentToDisplay = this.$sce.trustAsResourceUrl(fileURL);

                        if (i === 0) {
                            imageObj.primaryImage = this.FileManagerService.embedContentToDisplay;
                        }
                        imageObj.thumbnailImages[i] = this.FileManagerService.embedContentToDisplay;

                    }).error((data, status, headers, config) => {
                        this.$log.debug('%s - Error retrieving product images', status);
                    }
                );
            }
        }
    }

    public switchProductPrimaryImage(imageIndex: number, imageObj: any): void {
        imageObj.primaryImage = imageObj.thumbnailImages[imageIndex];
    }
}