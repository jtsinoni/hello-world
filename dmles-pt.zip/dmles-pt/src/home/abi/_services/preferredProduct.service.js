define(["require", "exports"], function (require, exports) {
    'use strict';
    var PreferredProductService = (function () {
        // @ngInject
        function PreferredProductService($log, $state, AbiService, AbiGridStateService, DmlesGridService, NotificationService, SearchUtilService, StateConstants) {
            this.$log = $log;
            this.$state = $state;
            this.AbiService = AbiService;
            this.AbiGridStateService = AbiGridStateService;
            this.DmlesGridService = DmlesGridService;
            this.NotificationService = NotificationService;
            this.SearchUtilService = SearchUtilService;
            this.StateConstants = StateConstants;
            this.serviceName = "Preferred Product Service";
            this.preferredProduct = null;
            this.selectedProduct = null;
        }
        PreferredProductService.prototype.displayPreferredProduct = function (abiProduct) {
            this.selectedProduct = abiProduct;
            this.$log.debug("displayPreferredProduct - abiProduct.mmcPreferredProductIdentifier %s", JSON.stringify(abiProduct.mmcPreferredProductIdentifier));
            this.loadPreferredProduct(abiProduct);
        };
        PreferredProductService.prototype.loadPreferredProduct = function (abiProduct) {
            var _this = this;
            var userSpecifiedFilters = "";
            userSpecifiedFilters = "(mmcProductIdentifier EQ '" + abiProduct.mmcPreferredProductIdentifier + "')";
            this.AbiService.getSummaryAbiProducts("", userSpecifiedFilters, "{}").then(function (response) {
                _this.$log.debug("response: %s", JSON.stringify(response));
                var resultsArray = [];
                resultsArray = _this.AbiService.parseAbiProductSummaryResults(response);
                _this.preferredProduct = resultsArray[0];
                _this.$log.debug("this.preferredProduct: %s", JSON.stringify(_this.preferredProduct));
                // if the preferredProduct's info was not successfully retrieved, show error message
                if (!_this.preferredProduct) {
                    _this.$log.debug("%s - the preferred product info was not successfully retrieved using mmcPreferredProductIdentifier: %s", _this.serviceName, abiProduct.mmcPreferredProductIdentifier);
                    _this.NotificationService.errorMsg("The preferred product's info was not found");
                }
                else {
                    // the preferredProduct's info was successfully retrieved, go to preferred product view
                    _this.goToViewPreferredProduct();
                }
            }, function (errResponse) {
                //this.isLoadingSearch = false;
                _this.$log.debug("%s - Error getting preferred product from elastic.", _this.serviceName);
                _this.NotificationService.errorMsg("An error occurred while retrieving preferred product");
            });
        };
        PreferredProductService.prototype.goToViewPreferredProduct = function () {
            this.AbiGridStateService.searchSummaryResultsGridState = this.DmlesGridService.retrieveGridState();
            this.$state.go(this.StateConstants.ABI_PREFERRED_PRODUCT);
        };
        return PreferredProductService;
    }());
    exports.PreferredProductService = PreferredProductService;
});
//# sourceMappingURL=preferredProduct.service.js.map