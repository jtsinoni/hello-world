'use strict';

import {BaseSelectedFacetOptionsService} from "../_directives/selectedFacetOptionsBreadbox/baseSelectedFacetOptions.service";
import {SearchConstants} from "../_constants/search.constants";

export class SelectedFacetOptionsBreadboxService extends BaseSelectedFacetOptionsService {

    // this module (for event purposes)
    public eventModule: string = SearchConstants.EVENT_MODULE_ABI;

    // @ngInject
    constructor($log, $state, $rootScope, CategoryBreadcrumbsService, FacetsService, SearchUtilService, StateConstants) {
        super($log, $state, $rootScope, CategoryBreadcrumbsService, FacetsService, SearchUtilService, StateConstants);

        this.init();
    }
}