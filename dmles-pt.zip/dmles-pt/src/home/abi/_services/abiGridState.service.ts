'use strict';

export class AbiGridStateService {

    public searchSummaryResultsGridState: any = {};

    public originalSearchSummaryResultsGridState: any = {
        "columns": [{
            "name": "productCompareSelected",
            "visible": true,
            "width": "5%",
            "sort": {},
            "filters": [{}],
            "pinned": ""
        }, {
            "name": "longItemDescription",
            "visible": true,
            "width": "40%",
            "sort": {},
            "filters": [{}],
            "pinned": ""
        }, {
            "name": "enterpriseProductIdentifier",
            "visible": true,
            "width": "6%",
            "sort": {},
            "filters": [{}],
            "pinned": ""
        }, {
            "name": "manufacturer",
            "visible": true,
            "width": "10%",
            "sort": {},
            "filters": [{}],
            "pinned": ""
        }, {
            "name": "manufacturerCatalogNumber",
            "visible": true,
            "width": "10%",
            "sort": {},
            "filters": [{}],
            "pinned": ""
        }, {
            "name": "ndc",
            "visible": true,
            "width": "5%",
            "sort": {},
            "filters": [{}],
            "pinned": ""
        }, {
            "name": "productStatus",
            "visible": true,
            "width": "5%",
            "sort": {},
            "filters": [{}],
            "pinned": ""
        }, {
            "name": "siteCount",
            "visible": true,
            "width": "5%",
            "sort": {},
            "filters": [{}],
            "pinned": ""
        }, {
            "name": "sameGroup",
            "visible": true,
            "width": "5%",
            "sort": {},
            "filters": [{}],
            "pinned": ""
        }, {
            "name": "substituteGroup",
            "visible": true,
            "width": "5%",
            "sort": {},
            "filters": [{}],
            "pinned": ""
        }, {
            "name": "isPreferredProduct",
            "visible": true,
            "width": "4%",
            "sort": {},
            "filters": [{}],
            "pinned": ""
        }],
        "scrollFocus": {},
        "selection": [],
        "grouping": {},
        "treeView": {},
        "pagination": {"paginationCurrentPage": 1, "paginationPageSize": 25}
    };

    constructor(private $log, private DmlesGridService) {
    }

    public clearSearchSummaryResultsGridState() {
        this.searchSummaryResultsGridState = {};
        this.$log.debug("clear - this.searchSummaryResultsGridState: %s", JSON.stringify(this.searchSummaryResultsGridState));
    }

    public getSearchSummaryResultsGridState() {
        return this.searchSummaryResultsGridState;
    }

    public setSearchSummaryResultsGridState(gridState) {
        this.searchSummaryResultsGridState = gridState;
        this.$log.debug("set - this.searchSummaryResultsGridState: %s", JSON.stringify(this.searchSummaryResultsGridState));
    }
}