'use strict';

import {AbiProductComparison} from "../_models/abiProductComparison.model";
import {AbiProduct} from "../_models/abiProduct.model";

export class ProductComparisonService {

    public productComparisonList: Array<AbiProductComparison> = [];
    public productComparisonPrimaryImageList: Array<Array<string>> = [[], [], []];
    public contentType: string;
    public downloadFileInfo: any = null;

    public conversions: { old: string, new: string }[] = [
        {"old": "longItemDescription", "new": "Item Description"},
        {"old": "enterpriseProductIdentifier", "new": "Enterprise Product Identifier"},
        {"old": "manufacturer", "new": "Manufacturer"},
        {"old": "manufacturerCatalogNumber", "new": "Catalog Number"},
        {"old": "ndc", "new": "NDC"},
        {"old": "productNoun", "new": "Product"},
        {"old": "productType", "new": "Product Type"},
        {"old": "productComposition", "new": "Product Composition"},
        {"old": "trademarkBrandnames", "new": "Trademark/Brand Names"},
        {"old": "brandGeneric", "new": "Brand Type"},
        {"old": "deaCode", "new": "DEA Code"},
        {"old": "drugCategory", "new": "Label Type"},
        {"old": "drugStorageType", "new": "Storage Type"},
        {"old": "sizeShape", "new": "Size/Shape"},
        {"old": "productProperties", "new": "Properties"},
        {"old": "locations", "new": "Locations"},
        {"old": "miscellaneous", "new": "Additional Information"},
        {"old": "age", "new": "Age"},
        {"old": "gender", "new": "Gender"},
        {"old": "color", "new": "Color"},
        {"old": "flavor", "new": "Flavor"},
        {"old": "fragrance", "new": "Fragrance"},
        {"old": "disposableReusable", "new": "Disposable"},
        {"old": "diameter", "new": "Diameter"},
        {"old": "volume", "new": "Volume"},
        {"old": "weight", "new": "Weight"},
        {"old": "lengthWidthHeight", "new": "Dimensions"},
        {"old": "lengthWidthHeight2", "new": "Secondary Dimensions"},
        {"old": "sterileNonsterile", "new": "Sterility"},
        {"old": "hazardCode", "new": "Hazard"},
        {"old": "latexCode", "new": "Latex"}
    ];

    public productComparisonListMaxSize: number = 3;

    // @ngInject
    constructor(private $log, private $state, private AbiGridStateService, private DmlesGridService,
                private NotificationService, private StateConstants) {

        this.productComparisonList = [];
        this.productComparisonPrimaryImageList = [[], [], []];
    }

    public getItemComparisonList(): Array<AbiProductComparison> {
        return this.productComparisonList;
    }

    public clearItemComparisonList() {
        this.productComparisonList = [];
    }

    public clearItemComparisonPrimaryImageList() {
        this.productComparisonPrimaryImageList = [[], [], []];
    }

    public updateItemComparisonList(item: AbiProduct) {
        // this.$log.debug("updateItemComparisonList - item: %s", JSON.stringify(item));

        // if we want to ADD this item to the item comparison list
        if (item.productCompareSelected === true) {
            // if we are already full, need to display warning and do nothing
            if (this.productComparisonList.length === this.productComparisonListMaxSize) {
                item.productCompareSelected = false;
                this.NotificationService.warningMsg("You can compare only three products, please un-select a product before proceeding.");
            } else {
                // insert item in the first empty slot in the productComparisonList
                for (let i = 0; i < this.productComparisonListMaxSize; i++) {
                    if (!this.productComparisonList[i]) {
                        this.productComparisonList[i] = new AbiProductComparison();
                        this.productComparisonList[i].productCompareSelected = item.productCompareSelected;
                        this.productComparisonList[i].isPreferredProduct = item.isPreferredProduct;
                        this.productComparisonList[i].enterpriseProductIdentifier = item.enterpriseProductIdentifier;
                        this.productComparisonList[i].longItemDescription = item.longItemDescription;
                        this.productComparisonList[i].manufacturer = item.manufacturer;
                        this.productComparisonList[i].manufacturerCatalogNumber = item.manufacturerCatalogNumber;
                        this.productComparisonList[i].ndc = item.ndc;
                        this.productComparisonList[i].productNoun = item.productNoun;
                        this.productComparisonList[i].productType = item.productType;
                        this.productComparisonList[i].age = item.age;
                        this.productComparisonList[i].gender = item.gender;
                        this.productComparisonList[i].sizeShape = item.sizeShape;
                        this.productComparisonList[i].color = item.color;
                        this.productComparisonList[i].flavor = item.flavor;
                        this.productComparisonList[i].fragrance = item.fragrance;
                        this.productComparisonList[i].sterileNonsterile = item.sterileNonsterile;
                        this.productComparisonList[i].hazardCode = item.hazardCode;
                        this.productComparisonList[i].latexCode = item.latexCode;
                        this.productComparisonList[i].disposableReusable = item.disposableReusable;
                        this.productComparisonList[i].diameter = item.diameter;
                        this.productComparisonList[i].volume = item.volume;
                        this.productComparisonList[i].weight = item.weight;
                        this.productComparisonList[i].lengthWidthHeight = item.lengthWidthHeight;
                        this.productComparisonList[i].lengthWidthHeight2 = item.lengthWidthHeight2;
                        this.productComparisonList[i].productComposition = item.productComposition;
                        this.productComparisonList[i].productProperties = item.productProperties;
                        this.productComparisonList[i].locations = item.locations;
                        this.productComparisonList[i].miscellaneous = item.miscellaneous;
                        // this.productComparisonList[i].productImages = item.productImages;
                        this.productComparisonList[i].trademarkBrandnames = item.trademarkBrandnames;
                        this.productComparisonList[i].brandGeneric = item.brandGeneric;
                        this.productComparisonList[i].deaCode = item.deaCode;
                        this.productComparisonList[i].drugCategory = item.drugCategory;
                        this.productComparisonList[i].drugStorageType = item.drugStorageType;

                        // save primary product images to separate List
                        this.productComparisonPrimaryImageList[i] = item.productImages;
                        break;
                    }
                }
            }
        } else {
            // we want to DELETE this item from the item comparison list
            // look for item and if found remove it
            for (let i = 0; i < this.productComparisonList.length; i++) {
                // for now use enterpriseProductIdentifier to compare - will be id for real VIM
                if (this.productComparisonList[i].enterpriseProductIdentifier === item.enterpriseProductIdentifier) {
                    this.productComparisonList.splice(i, 1);
                    this.productComparisonPrimaryImageList.splice(i, 1);
                    break;
                }
            }
        }

        // this.$log.debug("this.productComparisonPrimaryImageList: %s", JSON.stringify(this.productComparisonPrimaryImageList));
        // this.$log.debug("this.productComparisonPrimaryImageList.length = %d", this.productComparisonPrimaryImageList.length);
        // this.$log.debug("this.productComparisonList: %s", JSON.stringify(this.productComparisonList));
        // this.$log.debug("this.productComparisonList.length = %d", this.productComparisonList.length);

    }

    public removeEmptyRowsFromProductComparisonsTable() {
        // this.$log.debug("removeEmptyRowsFromProductComparionsTable enter - this.productComparisonList: %s", JSON.stringify(this.productComparisonList));
        if (this.productComparisonList.length > 1) {
            for (let key in this.productComparisonList[0]) {
                if (this.productComparisonList.length === 2) {
                    if ((this.productComparisonList[0][key] == false) && (this.productComparisonList[1][key] == false)) {
                        // remove the empty element from both rows of array
                        delete this.productComparisonList[0][key];
                        delete this.productComparisonList[1][key];
                    }
                } else if (this.productComparisonList.length === 3) {
                    if ((this.productComparisonList[0][key] == false) && (this.productComparisonList[1][key] == false) && (this.productComparisonList[2][key] == false)) {
                        // remove the empty element from both rows of array
                        delete this.productComparisonList[0][key];
                        delete this.productComparisonList[1][key];
                        delete this.productComparisonList[2][key];
                    }
                }
            }
        }
        // this.$log.debug("removeEmptyRowsFromProductComparionsTable exit - this.productComparisonList: %s", JSON.stringify(this.productComparisonList));
    }

    public convertKeyToLabel(key: string): string {
        let returnString = "";
        for (let i = 0; i < this.conversions.length; i++) {
            if (key === this.conversions[i].old) {
                returnString = this.conversions[i].new;
                break;
            }
        }
        return returnString;
    }

    public beautifyValue(value: any): any {
        let returnString: any = "";
        if (typeof value === "string") {
            returnString = value;
        } else if (typeof value === "number") {
            returnString = value;
        } else if (value instanceof Array) {
            // we only deal with arrays of string
            returnString = value.toString();
        }
        return returnString;
    }

    public showThumbnailsForThisProduct(productIndex: number): boolean {
        if (this.productComparisonPrimaryImageList[productIndex][0] && this.productComparisonPrimaryImageList[productIndex][0] !== "/src/content/images/imageNotAvailable.jpg") {
            return true;
        } else {
            return false;
        }
    }

    public showThirdProductColumn(): boolean {
        if (this.productComparisonPrimaryImageList.length === 3 && this.productComparisonPrimaryImageList[2].length > 0) {
            return true;
        } else {
            return false;
        }
    }

    public goToItemComparison() {        
        if (this.productComparisonList.length > 1) {
            this.AbiGridStateService.searchSummaryResultsGridState = this.DmlesGridService.retrieveGridState();
            this.removeEmptyRowsFromProductComparisonsTable();
            this.$state.go(this.StateConstants.ABI_PRODUCT_COMPARISON);
        } else {
            this.NotificationService.warningMsg("You must choose at least two products to compare.");
        }
    }
}