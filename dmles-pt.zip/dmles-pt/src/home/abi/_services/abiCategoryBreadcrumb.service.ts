'use strict';

import {BaseCategoryBreadcrumbService} from "../../../_directives/searchComponents/categoryBreadcrumb/baseCategoryBreadcrumb.service";
import {SearchConstants} from "../../../_constants/search.constants";

export class AbiCategoryBreadcrumb extends BaseCategoryBreadcrumbService {

    // this module (for event purposes)
    public eventModule: string = SearchConstants.EVENT_MODULE_ABI;

    // @ngInject
    constructor($log, $rootScope, displayLabel: string, SearchUtilService) {
        super($log, $rootScope, displayLabel, SearchUtilService);

        this.init();
    }
}