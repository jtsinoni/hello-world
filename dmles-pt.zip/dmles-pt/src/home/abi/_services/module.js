define(["require", "exports", './abi.service', './abiGridState.service', './categories.service', './category.service', './categoryBreadcrumb.service', './categoryBreadcrumbs.service', './facets.service', './facet.service', './preferredProduct.service', './productComparison.service', './sameProductGroup.service', './searchUtil.service', './searchWithinResults.service', './selectedFacetOptionsBreadbox.service', './selectedProduct.service', './siteCatalog.service', './taxonomy.service'], function (require, exports, abi_service_1, abiGridState_service_1, categories_service_1, category_service_1, categoryBreadcrumb_service_1, categoryBreadcrumbs_service_1, facets_service_1, facet_service_1, preferredProduct_service_1, productComparison_service_1, sameProductGroup_service_1, searchUtil_service_1, searchWithinResults_service_1, selectedFacetOptionsBreadbox_service_1, selectedProduct_service_1, siteCatalog_service_1, taxonomy_service_1) {
    'use strict';
    var servicesModule = angular.module('Dmles.Home.Abi.Services.Module', []);
    servicesModule.service('AbiService', abi_service_1.AbiService);
    servicesModule.service('AbiGridStateService', abiGridState_service_1.AbiGridStateService);
    servicesModule.service('CategoriesService', categories_service_1.CategoriesService);
    servicesModule.factory('Category', category_service_1.Category);
    servicesModule.factory('CategoryBreadcrumb', categoryBreadcrumb_service_1.CategoryBreadcrumb);
    servicesModule.service('CategoryBreadcrumbsService', categoryBreadcrumbs_service_1.CategoryBreadcrumbsService);
    servicesModule.factory('Facet', facet_service_1.Facet);
    servicesModule.service('FacetsService', facets_service_1.FacetsService);
    servicesModule.service('PreferredProductService', preferredProduct_service_1.PreferredProductService);
    servicesModule.service('ProductComparisonService', productComparison_service_1.ProductComparisonService);
    servicesModule.service('SameProductGroupService', sameProductGroup_service_1.SameProductGroupService);
    servicesModule.service('SearchUtilService', searchUtil_service_1.SearchUtilService);
    servicesModule.service('SearchWithinResultsService', searchWithinResults_service_1.SearchWithinResultsService);
    servicesModule.service('SelectedFacetOptionsBreadboxService', selectedFacetOptionsBreadbox_service_1.SelectedFacetOptionsBreadboxService);
    servicesModule.service('SelectedProductService', selectedProduct_service_1.SelectedProductService);
    servicesModule.service('SiteCatalogService', siteCatalog_service_1.SiteCatalogService);
    servicesModule.service('TaxonomyService', taxonomy_service_1.TaxonomyService);
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = servicesModule;
});
//# sourceMappingURL=module.js.map