define(["require", "exports"], function (require, exports) {
    'use strict';
    var SameProductGroupService = (function () {
        // @ngInject
        function SameProductGroupService($log, $state, AbiService, AbiGridStateService, DmlesGridService, datatableService, NotificationService, SearchUtilService, SelectedProductService, StateConstants) {
            this.$log = $log;
            this.$state = $state;
            this.AbiService = AbiService;
            this.AbiGridStateService = AbiGridStateService;
            this.DmlesGridService = DmlesGridService;
            this.datatableService = datatableService;
            this.NotificationService = NotificationService;
            this.SearchUtilService = SearchUtilService;
            this.SelectedProductService = SelectedProductService;
            this.StateConstants = StateConstants;
            this.serviceName = "Same Product Group Service";
            this.productsInSameProductGroup = [];
            // can delete if we delete ng-table
            this.ngProductsInSameProductGroupTable = null;
            this.productsInSameProductGroupTableFilterString = "";
            this.sortOrder = "longItemDescription";
        }
        SameProductGroupService.prototype.getProductsInSameProductGroup = function () {
            return this.productsInSameProductGroup;
        };
        SameProductGroupService.prototype.displayProductsInSameProductGroup = function (spDrugCode) {
            this.$log.debug("displayProductsInSameProductGroup - spDrugCode %s", JSON.stringify(spDrugCode));
            this.productsInSameProductGroupTableFilterString = "";
            this.loadProductsInSameProductGroup(spDrugCode);
        };
        SameProductGroupService.prototype.loadProductsInSameProductGroup = function (abiProduct) {
            var _this = this;
            if (abiProduct.spDrugCode) {
                this.SelectedProductService.setSelectedProduct(abiProduct);
                var userSpecifiedFilters = "";
                userSpecifiedFilters = "(spDrugCode EQ '" + abiProduct.spDrugCode.replace(/[!@#$%^&()+=\-[\]\\';,./{}|":<>?~_]/g, "\\$&") + "')";
                this.AbiService.getSummaryAbiProducts("", userSpecifiedFilters, "{}").then(function (response) {
                    //this.$log.debug("response: %s", JSON.stringify(response));
                    _this.productsInSameProductGroup = _this.AbiService.parseAbiProductSummaryResults(response);
                    _this.SearchUtilService.sortByCriteria(_this.productsInSameProductGroup, [_this.sortOrder]);
                    _this.ngProductsInSameProductGroupTable = _this.datatableService.createNgTable(_this.productsInSameProductGroup);
                    _this.$log.debug("this.productsInSameProductGroup.length: %d", JSON.stringify(_this.productsInSameProductGroup.length));
                    _this.$log.debug("this.productsInSameProductGroup: %s", JSON.stringify(_this.productsInSameProductGroup));
                    _this.goToViewProductsWithSameSpDrugCode();
                }, function (errResponse) {
                    // this.isLoadingSearch = false;
                    _this.$log.debug("%s - Error getting products with same spDrugCode from elastic.", _this.serviceName);
                    _this.NotificationService.errorMsg("An error occurred while retrieving products with same spDrugCode");
                });
            }
        };
        SameProductGroupService.prototype.productsInSameProductGroupTableFilter = function () {
            this.ngProductsInSameProductGroupTable.filter({ $: this.productsInSameProductGroupTableFilterString });
            this.ngProductsInSameProductGroupTable.reload();
        };
        SameProductGroupService.prototype.goToViewProductsWithSameSpDrugCode = function () {
            //this.$log.debug("goToViewProductsWithSameSpDrugCode");
            this.AbiGridStateService.searchSummaryResultsGridState = this.DmlesGridService.retrieveGridState();
            this.$state.go(this.StateConstants.ABI_PRODUCTS_IN_SAME_PRODUCT_GROUP);
        };
        return SameProductGroupService;
    }());
    exports.SameProductGroupService = SameProductGroupService;
});
//# sourceMappingURL=sameProductGroup.service.js.map