var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", "../../../_directives/searchComponents/searchWithinResults/baseSearchWithinResults.service", "../../../_constants/search.constants"], function (require, exports, baseSearchWithinResults_service_1, search_constants_1) {
    'use strict';
    var SearchWithinResultsService = (function (_super) {
        __extends(SearchWithinResultsService, _super);
        // @ngInject
        function SearchWithinResultsService($log, $rootScope, SearchUtilService, SelectedFacetOptionsBreadboxService) {
            _super.call(this, $log, $rootScope, SearchUtilService, SelectedFacetOptionsBreadboxService);
            // this module (for event purposes)
            this.eventModule = search_constants_1.SearchConstants.EVENT_MODULE_ABI;
            this.init();
        }
        return SearchWithinResultsService;
    }(baseSearchWithinResults_service_1.BaseSearchWithinResultsService));
    exports.SearchWithinResultsService = SearchWithinResultsService;
});
//# sourceMappingURL=searchWithinResults.service.js.map