'use strict';

import {ApiService} from '../../../_services/api.service';
import {CategoryOption} from "../_models/categoryOption.model";

export interface ITaxonomyService {
}

export class TaxonomyService extends ApiService implements ITaxonomyService {
    private serviceName: string = "Taxonomy Service";

    public unspscSegments: Array<CategoryOption> = [];
    public productNouns: Array<CategoryOption> = [];

    // @ngInject
    constructor($http, $httpParamSerializerJQLike, $log, Authentication, private SearchUtilService) {

        super($http, $log, Authentication, $httpParamSerializerJQLike, "ABiTaxonomyManagement");
        this.$log.debug("%s - Start", this.serviceName);
    }

    public clearProductNouns() {
        this.productNouns = null;
    }

    public getProductNouns() {
        if (this.productNouns) {
            return this.productNouns;
        }
        return null;
    }

    public retrieveProductNouns() {
        let productNouns: Array<string> =
            [
                "MESH",
                "BURR",
                "SCREW",
                "BRUSH",
                "GLOVE",
                "SENSOR",
                "RESTRAINT",
                "PLATE",
                "GUIDEWIRE",
                "DISK",
                "TUBE",
                "SUTURE",
                "PLUG",
                "BOTTLE",
                "CANNULA",
                "DECANTER",
                "SPHYGMOMANOMETER",
                "HOOK",
                "ELEVATOR",
                "GUIDE",
                "STABILIZER",
                "BAG",
                "ELECTRODE",
                "CAP",
                "COVER",
                "DILATOR",
                "PROTECTOR",
                "BANDAGE",
                "POUCH",
                "KIT",
                "CUFF",
                "CANE",
                "CLEANER",
                "BLADE",
                "CUP",
                "CANISTER",
                "TRAY",
                "BRACE",
                "BALL",
                "WARMER",
                "REAMER",
                "CONTAINER",
                "CAPSULE",
                "INTRODUCER",
                "RESUSCITATOR",
                "DRAPE",
                "SHOE",
                "BATTERY",
                "SPONGE",
                "COUNTER",
                "RONGEUR",
                "WRAP",
                "TAPE",
                "CATHETER",
                "SET",
                "CONTROL",
                "REAGENT",
                "MEDIA",
                "FORCEPS",
                "EQUIPMENT",
                "SYRINGE",
                "SHEATH",
                "TRAP",
                "PIN",
                "BUTTON",
                "SYSTEM",
                "TROLLEY",
                "HEMOSTAT",
                "CLAMP",
                "TUBING",
                "SPLINT",
                "BALLOON",
                "APPLICATOR",
                "STENT",
                "DOPPLER",
                "IMMOBILIZER",
                "MARKER",
                "PACK",
                "SLING",
                "ROLL",
                "VEST",
                "CURETTE",
                "EXTRACTOR",
                "TROCAR",
                "CONNECTOR",
                "RETRACTOR",
                "NEEDLE",
                "LOOP",
                "SUPPORT",
                "MANNEQUIN",
                "DRAIN",
                "ANTIBODY",
                "STAIN",
                "LIGATOR",
                "NEBULIZER",
                "GOWN",
                "STOPCOCK",
                "PROP",
                "WIPE",
                "ABUTMENT",
                "UNIT",
                "PAPER",
                "SOLUTION",
                "RELOAD",
                "LABEL",
                "GOGGLES",
                "WASHCLOTH",
                "SIGN",
                "STOCKING",
                "BRIEF",
                "SANITIZER",
                "STRAP",
                "HOSE",
                "COUPLER",
                "FILE",
                "BELT",
                "DRIVER",
                "BOOTIE",
                "BUCKET",
                "PUNCH",
                "RETAINER",
                "FILTER",
                "BIT",
                "KNIFE",
                "FLASK",
                "MASK",
                "SLEEVE",
                "ABSORBENT",
                "DEVICE",
                "TRANSILLUMINATOR",
                "BOLT",
                "PEN",
                "BRIDGE",
                "APPLIER",
                "WASHER",
                "CUSHION",
                "LINER",
                "GRASPER",
                "DRESSING",
                "COMPOUND",
                "DETECTOR",
                "NAIL",
                "HOLDER",
                "WAX",
                "UNDERPAD",
                "MOUTHPIECE",
                "CASE",
                "CIRCUIT",
                "STAPLER",
                "DISPENSER",
                "CLIP",
                "CABLE",
                "BAND",
                "INDICATOR",
                "SCISSORS",
                "TIP",
                "EXERCISER",
                "BULB",
                "FLOWMETER",
                "THERMOMETER",
                "SHUNT",
                "TOWEL",
                "SPHINCTEROTOME",
                "PROBE",
                "CARTRIDGE",
                "TOP",
                "TOOTHBRUSH",
                "MATERIAL",
                "INSOLE",
                "TAP",
                "CYLINDER",
                "ARMBOARD",
                "SPEAR",
                "PILLOW",
                "WIRE",
                "LYSATE",
                "ADAPTER",
                "SOCKET",
                "ENVELOPE",
                "ROD",
                "PATCH",
                "GONIOMETER",
                "WRISTBAND",
                "SHAFT",
                "TOOL",
                "DISC",
                "TOURNIQUET",
                "TABLE",
                "COMPOSITE",
                "SCALER",
                "WAND",
                "IRRIGATOR",
                "VALVE",
                "FOOTWEAR",
                "CAUTERY",
                "PASSER",
                "LARYNGOSCOPE",
                "DISINFECTANT",
                "LEADWIRE",
                "COT",
                "PIPETTE",
                "WRENCH",
                "AIRWAY",
                "REGULATOR",
                "SEAL",
                "CASSETTE",
                "TEMPLATE",
                "PLIERS",
                "SIZER",
                "PANTS",
                "CABINET",
                "ASSEMBLY",
                "SNARE",
                "GRAFT",
                "PAD",
                "DEVELOPER",
                "BIN",
                "MITT",
                "RESERVOIR",
                "LID",
                "REMOVER",
                "PROSTHESIS",
                "DISSECTOR",
                "EVACUATOR",
                "COAT",
                "FOOTSTOOL",
                "COIL",
                "TIMER",
                "GUIDE PIN",
                "BOARD",
                "COVERSLIP",
                "CUTTER",
                "IRON",
                "STRIP",
                "MODULE",
                "GAS",
                "APPROXIMATOR",
                "STYLET",
                "SPECULUM",
                "COLLAR",
                "HANDLE",
                "CROWN",
                "DRILL",
                "DETERGENT",
                "BLANKET",
                "CAST",
                "LAMP",
                "AGENT",
                "SPIKE",
                "PADDING",
                "RESIN",
                "GAUGE",
                "PIPETTER",
                "NIPPER",
                "PLEDGET",
                "BINDER",
                "SPLITTER",
                "FIBER",
                "CHUCK",
                "PUSHER",
                "FILM",
                "STICK",
                "COLLECTOR",
                "ELASTIC",
                "PILLOWCASE",
                "BOUGIE",
                "SPACER",
                "MATTRESS",
                "SLIDE",
                "BASKET",
                "STAND",
                "OBTURATOR",
                "HEAD",
                "CARD",
                "PROCESSOR",
                "IMPLANT",
                "STOCKINETTE",
                "POSITIONER",
                "STANDARD",
                "PACKING",
                "AID",
                "PELLET",
                "SHORTS",
                "VACUUM",
                "PARTICLES",
                "CREAM",
                "MIXER",
                "BRACKET",
                "BUFFER",
                "SCREWDRIVER",
                "SHIRT",
                "SWAB",
                "TRIMMER",
                "MAT",
                "HOOD",
                "CRUTCH",
                "LUBRICANT",
                "DEODORANT",
                "CALIBRATOR",
                "CART",
                "CARRIER",
                "BURNISHER",
                "SUCTION",
                "STETHOSCOPE",
                "BARRIER",
                "PORT",
                "DESICCANT",
                "EARPIECE",
                "SOAP",
                "STRAW",
                "SPREADER",
                "VIAL",
                "POINT",
                "PADDLE",
                "SCALE",
                "JAR",
                "TAG",
                "PUTTY",
                "SEALANT",
                "FELT",
                "INSERT",
                "INSTRUMENT",
                "SPATULA",
                "HARNESS",
                "STRAINER",
                "SLIPPERS",
                "HANDBOOK",
                "SPRAY",
                "LIGHT",
                "HANDPIECE",
                "LANCET",
                "DATACARD",
                "TUNNELER",
                "LID PLATE",
                "DISTRACTOR",
                "LOTION",
                "FOOTPRINTER",
                "BRA",
                "FASTENER",
                "TRANSDUCER",
                "SEPARATOR",
                "LINE",
                "LIFT",
                "CHAMBER",
                "CAPE",
                "PERCUSSOR",
                "SHIELD",
                "DUSTER",
                "PLATFORM",
                "RING",
                "FUNNEL",
                "ASPIRATOR",
                "SHUTTLE",
                "DYE",
                "BLOCKER",
                "SIGMOIDOSCOPE",
                "CORD",
                "BACKPAD",
                "CHARGER",
                "STONE",
                "LUNG",
                "NOSECLIP",
                "ORTHOSIS",
                "CEMENT",
                "ANOSCOPE",
                "WATER",
                "DEFLECTOR",
                "TRIAL",
                "ADHESIVE",
                "BENDER",
                "DONUT",
                "REDUCER",
                "OIL",
                "SCALPEL",
                "WALKER",
                "RASP",
                "GLASSES",
                "GLASS",
                "LINING",
                "CHART",
                "DRILL BIT",
                "BLOCK",
                "NOTCHER",
                "DIRECTOR",
                "GAUZE",
                "PICK",
                "GEL",
                "DISH",
                "PANEL",
                "OVERWRAP",
                "IMPRESSION TRAY",
                "RETRACTOR/ELEVATOR",
                "PULLEY",
                "TANK",
                "GLIDE",
                "INHALANT",
                "SPRING",
                "ATTACHMENT",
                "SITE",
                "STOOL",
                "CLEANSER",
                "SPHERE",
                "MANIPULATOR",
                "SAMPLER",
                "TISSUE",
                "GRID",
                "PENLIGHT",
                "HEADREST",
                "PLUGGER",
                "WICK",
                "BEDPAN",
                "STRINGER",
                "PENCIL",
                "GASKET",
                "GUARD",
                "MANIFOLD",
                "SHEET",
                "TEST",
                "SUPPORTER",
                "DEODORIZER",
                "LENS",
                "BOWL",
                "BOOT",
                "CARAFE",
                "HEMOCONCENTRATOR",
                "SWABSTICK",
                "SOLIDIFIER",
                "FRAME",
                "SHELL",
                "LEAD",
                "DROPPER",
                "MOLD",
                "RETRIEVER",
                "CLIPPER",
                "EXCAVATOR",
                "COMPRESSOR",
                "CHOPPER",
                "ASSORTMENT",
                "MIRROR",
                "EXCHANGER",
                "GRINDER",
                "MEMBRANE",
                "TRAINER",
                "FIXATIVE",
                "FORMULA",
                "POWDER",
                "COLLIMATOR",
                "FOLLOWER",
                "METER",
                "TOWELETTE",
                "OINTMENT",
                "CELLULOSE",
                "HAMMER",
                "PIERCER",
                "PUMP",
                "ANALYZER",
                "BASIN",
                "TENSIONER",
                "KEY",
                "COLLET",
                "SAW",
                "DEPRESSOR",
                "VIBRATOR",
                "HANDSWITCH",
                "NIPPLE",
                "MODEL",
                "VARNISH",
                "REFILL",
                "DIVIDER",
                "ANCHOR",
                "BUFF",
                "SOURCE",
                "EXPANDER",
                "CAPILLARY",
                "REINFORCEMENT",
                "CHAIR",
                "PASTE",
                "INLET",
                "FORK",
                "BRONCHOSCOPE",
                "RACK",
                "FOOTSWITCH",
                "INSERTER",
                "MORCELLATOR",
                "PERFORATOR",
                "VESSEL",
                "EARPHONE",
                "CYSTOTOME",
                "MICROPLATE",
                "TAMPON",
                "SHAMPOO",
                "ARMBAND",
                "CHISEL",
                "GARMENT",
                "HELMET",
                "EJECTOR",
                "POLE",
                "SOUND",
                "CRUSHER",
                "SHEARS",
                "PROGRAMMER",
                "TUB",
                "LAPAROSCOPE",
                "PACEMAKER",
                "LOCKBOX",
                "SEALER",
                "BIB",
                "TUNIC",
                "RECEPTACLE",
                "MONITOR",
                "MOUNT",
                "MATRIX",
                "FORM",
                "LOCK",
                "BLOTTER",
                "MICROCUVETTE",
                "CERAMIC",
                "MOUTHWASH",
                "AWL",
                "FOOTPEDAL",
                "SHELF",
                "BOX",
                "TAMP",
                "ILLUMINATOR",
                "BOOK",
                "RELEASER",
                "SEALER/DIVIDER",
                "GLIDEWIRE",
                "STAPLE",
                "SPOON",
                "LOG BOOK",
                "ROLLER",
                "CABLE/SLEEVE",
                "COUNTERSINK",
                "IDENTIFIER",
                "SHADE",
                "HARVESTER",
                "MATRICE",
                "STIMULATOR",
                "APPARATUS",
                "WAFER",
                "PAN",
                "PITCHER",
                "MASSAGER",
                "EYEWEAR",
                "SUBSTITUTE",
                "FILLER",
                "POST",
                "LIGHTGUIDE",
                "CUVETTE",
                "OTOSCOPE",
                "JELLY",
                "TRANSFORMER",
                "BAR",
                "CURTAIN",
                "WELL",
                "NOZZLE",
                "DESCALER",
                "ARTHROSCOPE",
                "PRINTER",
                "ENDOSCOPE",
                "MALLET",
                "INCUBATOR",
                "OSTEOTOME",
                "SUPPLY",
                "MANUAL",
                "VIDEO",
                "WORKBOOK",
                "COURSE",
                "RAZOR",
                "MILL",
                "NEUTRALIZER",
                "FLOSS",
                "COUPLING",
                "WEDGE",
                "URINAL",
                "BATH",
                "DEFIBRILLATOR",
                "BELL",
                "BEAD",
                "FILAMENT",
                "CHESTPIECE",
                "COMPONENT",
                "PUMP TUBING",
                "DAM",
                "PACKER",
                "RULER",
                "DVD",
                "SOCK",
                "CALIPER",
                "CLASP",
                "TONOMETER",
                "BONNET",
                "NEUROSTIMULATOR",
                "TESTER",
                "PISTON",
                "MAILER",
                "PARAFFIN",
                "EXPLORER",
                "ELEMENT",
                "ATOMIZER",
                "FILIFORM",
                "SCRUB",
                "INLAY",
                "TOGA",
                "BROCHURE",
                "ENZYME",
                "STRUT",
                "CREST",
                "MICROPHONE",
                "WHEEL",
                "LATCH",
                "BOOKLET",
                "HYSTEROSCOPE",
                "REACHER",
                "COPING",
                "CYSTOSCOPE",
                "FEEDER",
                "BEAKER",
                "GUN",
                "ARRAY",
                "DIALYZER",
                "THICKENER",
                "CAPTURE",
                "PRONG",
                "READER",
                "SMOOTHER",
                "EARPLUG",
                "HOUSING",
                "PEGBOARD",
                "PEG",
                "OPHTHALMOSCOPE",
                "ALLOY",
                "WHEELCHAIR",
                "DRAWSTATION",
                "GENERATOR",
                "RECHARGER",
                "SHIPPER",
                "ABSORBER",
                "APRON",
                "COLORIMETER",
                "JACKET",
                "COVERALLS",
                "LEGGINGS",
                "COMPRESS",
                "WIPER",
                "TACK",
                "TIE",
                "CHAIN",
                "ELASTOMERIC",
                "BASE",
                "SEEKER",
                "O RING",
                "ADHERENT",
                "RECORD",
                "OXIMETER",
                "DIAPER",
                "CHEMICAL",
                "REST",
                "EXTENSION",
                "STOP",
                "BROACH",
                "OCCLUDER",
                "ARM",
                "NUT",
                "STEM",
                "STERILIZER",
                "SEARCHER",
                "BALLOON DISSECTOR",
                "CARVER",
                "HUMIDIFIER",
                "HYGROMETER",
                "STRETCHER",
                "RESPIRATOR",
                "TAB",
                "BEVERAGE",
                "ANALGESIC",
                "ARTICULATOR",
                "HOOKUP",
                "TENACULUM",
                "STRIPPER",
                "IMPACTOR",
                "SIMULATOR",
                "CLOTH",
                "COAGULATOR",
                "STATION",
                "CARBOY",
                "DEHUMIDIFIER",
                "POINTER",
                "VISE",
                "DRAWER",
                "FERRULE",
                "MOISTURIZER",
                "OVERLAY",
                "BROOM",
                "TWISTER",
                "RECORDER",
                "INFLATOR",
                "FLASHLIGHT",
                "PACKAGE",
                "ROTOR",
                "CASTER",
                "BLISTER",
                "CASE CART",
                "SOFTWARE",
                "HEADGEAR",
                "CONCENTRATE",
                "POSTER",
                "REPLICA",
                "EARMOLD",
                "GRIP",
                "POTENTIOMETER",
                "CRADLE",
                "ARROW",
                "STIRRUP",
                "SHEETING",
                "ENHANCER",
                "TRACKER",
                "RESECTOR",
                "REFLECTOR",
                "INCLINOMETER",
                "GAG",
                "GATE",
                "TACHOMETER",
                "LASER",
                "LOCATOR",
                "INFUSOR",
                "PREFILTER",
                "SPIROMETER",
                "CLOSURE",
                "DERMATOSCOPE",
                "BALM",
                "INSUFFLATOR",
                "CRYOPLATE",
                "VERIFIER",
                "PRISM",
                "PNEUMOTACH",
                "SUNGLASSES",
                "HEADLIGHT",
                "TRACTOR",
                "ACCESSORY",
                "ORGANIZER",
                "OVERTUBE",
                "EYESHIELD",
                "COVERSLIPPER",
                "REMINDER",
                "CAN",
                "AIMER",
                "RIBBON",
                "ENDPLATE",
                "PACIFIER",
                "BRACELET",
                "SWEATBAND",
                "WING",
                "TABLET",
                "SMOCK",
                "JOINT",
                "FOIL",
                "BOAT",
                "MOTOR",
                "VALVULOTOME",
                "POLISHER",
                "CAGE",
                "ANALOG",
                "SHAKER",
                "MANOMETER",
                "INOCULATOR",
                "NET",
                "RESECTOSCOPE",
                "DERMATOME",
                "WASH",
                "SPRAYER",
                "EVALUATOR",
                "SOLVENT",
                "BRIGHTENER",
                "INJECTOR",
                "MANDREL",
                "CONDOM",
                "EARMUFF",
                "GOUGE",
                "HANDGRIP",
                "OXYGENATOR",
                "KNOB",
                "DART",
                "PERIOSTEOTOME",
                "DIAPHRAGM",
                "COMMODE",
                "PHOTOMETER",
                "SLAB",
                "CONSERVER",
                "MAGNIFIER",
                "CAMERA",
                "GUIDE ROD",
                "FLAG",
                "POLYMER",
                "ALARM",
                "THREAD",
                "STADIOMETER",
                "TENT"
            ];

        angular.forEach(productNouns, (productNoun) => {
            let row: CategoryOption = new CategoryOption();
            row.optionValue = productNoun;
            row.isSelected = false;
            row.level = 0;
            this.productNouns.push(row);
        });
        // this.$log.debug("this.productNouns: %s", JSON.stringify(this.productNouns));

        this.SearchUtilService.sortByCriteria(this.productNouns, ["optionValue"]);
        return this.productNouns;
    }

    public clearUnspscSegments() {
        this.unspscSegments = null;
    }

    public getUnspscSegments() {
        if (this.unspscSegments) {
            return this.unspscSegments;
        }
        return null;
    }

    public retrieveUnspscSegments() {
        let unspscSegments: Array<any> = [
            /***
             {
                 "segmentTitle": "Live Plant and Animal Material and Accessories and Supplies",
                 "segment": "10000000"
             },
             ***/
            {
                "segmentTitle": "Mineral and Textile and Inedible Plant and Animal Materials",
                "segment": "11000000"
            }, {
                "segmentTitle": "Chemicals including Bio Chemicals and Gas Materials",
                "segment": "12000000"
            },
            /***
             {
                 "segmentTitle": "Resin and Rosin and Rubber and Foam and Film and Elastomeric Materials",
                 "segment": "13000000"
             },
             ***/
            {
                "segmentTitle": "Paper Materials and Products",
                "segment": "14000000"
            }, {
                "segmentTitle": "Fuels and Fuel Additives and Lubricants and Anti corrosive Materials",
                "segment": "15000000"
            },
            /***
             {
             "segmentTitle": "Mining and Well Drilling Machinery and Accessories",
             "segment": "20000000"
         }, {
            "segmentTitle": "Farming and Fishing and Forestry and Wildlife Machinery and Accessories",
            "segment": "21000000"
        }, {
            "segmentTitle": "Building and Construction Machinery and Accessories",
            "segment": "22000000"
        },
             ***/
            {
                "segmentTitle": "Industrial Manufacturing and Processing Machinery and Accessories",
                "segment": "23000000"
            }, {
                "segmentTitle": "Material Handling and Conditioning and Storage Machinery and their Accessories and Supplies",
                "segment": "24000000"
            },
            /***
             {
                 "segmentTitle": "Commercial and Military and Private Vehicles and their Accessories and Components",
                 "segment": "25000000"
             },
             ***/
            {
                "segmentTitle": "Power Generation and Distribution Machinery and Accessories",
                "segment": "26000000"
            }, {
                "segmentTitle": "Tools and General Machinery",
                "segment": "27000000"
            }, {
                "segmentTitle": "Structures and Building and Construction and Manufacturing Components and Supplies",
                "segment": "30000000"
            }, {
                "segmentTitle": "Manufacturing Components and Supplies",
                "segment": "31000000"
            },
            /***
             {
                 "segmentTitle": "Electronic Components and Supplies",
                 "segment": "32000000"
             },
             ***/
            {
                "segmentTitle": "Electrical Systems and Lighting and Components and Accessories and Supplies",
                "segment": "39000000"
            }, {
                "segmentTitle": "Distribution and Conditioning Systems and Equipment and Components",
                "segment": "40000000"
            }, {
                "segmentTitle": "Laboratory and Measuring and Observing and Testing Equipment",
                "segment": "41000000"
            }, {
                "segmentTitle": "Medical Equipment and Accessories and Supplies",
                "segment": "42000000"
            }, {
                "segmentTitle": "Information Technology Broadcasting and Telecommunications",
                "segment": "43000000"
            }, {
                "segmentTitle": "Office Equipment and Accessories and Supplies",
                "segment": "44000000"
            }, {
                "segmentTitle": "Printing and Photographic and Audio and Visual Equipment and Supplies",
                "segment": "45000000"
            }, {
                "segmentTitle": "Defense and Law Enforcement and Security and Safety Equipment and Supplies",
                "segment": "46000000"
            }, {
                "segmentTitle": "Cleaning Equipment and Supplies",
                "segment": "47000000"
            }, {
                "segmentTitle": "Service Industry Machinery and Equipment and Supplies",
                "segment": "48000000"
            }, {
                "segmentTitle": "Sports and Recreational Equipment and Supplies and Accessories",
                "segment": "49000000"
            },
            /***
             {
                 "segmentTitle": "Food Beverage and Tobacco Products",
                 "segment": "50000000"
             },
             ***/
            {
                "segmentTitle": "Drugs and Pharmaceutical Products",
                "segment": "51000000"
            }, {
                "segmentTitle": "Domestic Appliances and Supplies and Consumer Electronic Products",
                "segment": "52000000"
            }, {
                "segmentTitle": "Apparel and Luggage and Personal Care Products",
                "segment": "53000000"
            },
            /***
             {
                 "segmentTitle": "Timepieces and Jewelry and Gemstone Products",
                 "segment": "54000000"
             },
             ***/
            {"segmentTitle": "Published Products", "segment": "55000000"}, {
                "segmentTitle": "Furniture and Furnishings",
                "segment": "56000000"
            }, {
                "segmentTitle": "Musical Instruments and Games and Toys and Arts and Crafts and Educational Equipment and Materials and Accessories and Supplies",
                "segment": "60000000"
            },
            /***
             {
                 "segmentTitle": "Financial Instruments, Products, Contracts and Agreements",
                 "segment": "64000000"
             }, {
            "segmentTitle": "Farming and Fishing and Forestry and Wildlife Contracting Services",
            "segment": "70000000"
        }, {
            "segmentTitle": "Mining and oil and gas services",
            "segment": "71000000"
        }, {
            "segmentTitle": "Building and Facility Construction and Maintenance Services",
            "segment": "72000000"
        }, {
            "segmentTitle": "Industrial Production and Manufacturing Services",
            "segment": "73000000"
        }, {
            "segmentTitle": "Industrial Cleaning Services",
            "segment": "76000000"
        }, {
            "segmentTitle": "Environmental Services",
            "segment": "77000000"
        }, {
            "segmentTitle": "Transportation and Storage and Mail Services",
            "segment": "78000000"
        }, {
            "segmentTitle": "Management and Business Professionals and Administrative Services",
            "segment": "80000000"
        }, {
            "segmentTitle": "Engineering and Research and Technology Based Services",
            "segment": "81000000"
        }, {
            "segmentTitle": "Editorial and Design and Graphic and Fine Art Services",
            "segment": "82000000"
        }, {
            "segmentTitle": "Public Utilities and Public Sector Related Services",
            "segment": "83000000"
        }, {
            "segmentTitle": "Financial and Insurance Services",
            "segment": "84000000"
        }, {
            "segmentTitle": "Healthcare Services",
            "segment": "85000000"
        }, {
            "segmentTitle": "Education and Training Services",
            "segment": "86000000"
        }, {
            "segmentTitle": "Travel and Food and Lodging and Entertainment Services",
            "segment": "90000000"
        }, {
            "segmentTitle": "Personal and Domestic Services",
            "segment": "91000000"
        }, {
            "segmentTitle": "National Defense and Public Order and Security and Safety Services",
            "segment": "92000000"
        }, {
            "segmentTitle": "Politics and Civic Affairs Services",
            "segment": "93000000"
        }, {
            "segmentTitle": "Organizations and Clubs",
            "segment": "94000000"
        }, {"segmentTitle": "Land and Buildings and Structures and Thoroughfares", "segment": "95000000"}
             ***/
        ];

        angular.forEach(unspscSegments, (unspscSegment) => {
            let row: CategoryOption = new CategoryOption();
            row.optionValue = unspscSegment.segmentTitle;
            row.isSelected = false;
            row.level = 0;
            this.unspscSegments.push(row);
        });
        // this.$log.debug("this.unspscSegments: %s", JSON.stringify(this.unspscSegments));

        this.SearchUtilService.sortByCriteria(this.unspscSegments, ["optionValue"]);
        return this.unspscSegments;

        /***
         this.getSegments().then((response: any) => {
            angular.forEach(response.data, (unspscSegment) => {
                let row: CategoryOption = new CategoryOption();
                row.optionValue = unspscSegment.segmentTitle;
                this.unspscSegments.push(row);
            });
            this.$log.debug("this.unspscSegments: %s", JSON.stringify(this.unspscSegments));
        }, (errResponse: any) => {
            this.$log.error("Error retrieving UNSPSC Segments: %s", errResponse);
        });
         ***/
    };

    public getSegments() {
        let action: string = "getSegments";
        return this.get(action);
    };
}