'use strict';

import {AbiService} from './abi.service';
import {CategoriesService} from './categories.service';
import {Category} from './category.service';
import {CategoryBreadcrumb} from './categoryBreadcrumb.service';
import {CategoryBreadcrumbsService} from './categoryBreadcrumbs.service';
import {FacetsService} from './facets.service';
import {Facet} from './facet.service';
import {PreferredProductService} from './preferredProduct.service';
import {ProductComparisonService} from './productComparison.service';
import {SameProductGroupService} from './sameProductGroup.service';
import {SearchUtilService} from './searchUtil.service';
import {SearchWithinResultsService} from './searchWithinResults.service';
import {SelectedFacetOptionsBreadboxService} from './selectedFacetOptionsBreadbox.service';
import {SelectedProductService} from './selectedProduct.service';
import {SiteCatalogService} from './siteCatalog.service';
import {TaxonomyService} from './taxonomy.service';

let servicesModule = angular.module('Dmles.Home.Abi.Services.Module', []);
servicesModule.service('AbiService', AbiService);
servicesModule.service('CategoriesService', CategoriesService);
servicesModule.factory('Category', Category);
servicesModule.factory('CategoryBreadcrumb', CategoryBreadcrumb);
servicesModule.service('CategoryBreadcrumbsService', CategoryBreadcrumbsService);
servicesModule.factory('Facet', Facet);
servicesModule.service('FacetsService', FacetsService);
servicesModule.service('PreferredProductService', PreferredProductService);
servicesModule.service('ProductComparisonService', ProductComparisonService);
servicesModule.service('SameProductGroupService', SameProductGroupService);
servicesModule.service('SearchUtilService', SearchUtilService);
servicesModule.service('SearchWithinResultsService', SearchWithinResultsService);
servicesModule.service('SelectedFacetOptionsBreadboxService', SelectedFacetOptionsBreadboxService);
servicesModule.service('SelectedProductService', SelectedProductService);
servicesModule.service('SiteCatalogService', SiteCatalogService);
servicesModule.service('TaxonomyService', TaxonomyService);

export default servicesModule;