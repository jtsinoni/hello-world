'use strict';

import {BaseSearchWithinResultsService} from "../../../_directives/searchComponents/searchWithinResults/baseSearchWithinResults.service";
import {SearchConstants} from "../../../_constants/search.constants";

export class AbiSearchWithinResultsService extends BaseSearchWithinResultsService {

    // this module (for event purposes)
    public eventModule: string = SearchConstants.EVENT_MODULE_ABI;

    // @ngInject
    constructor($log, $rootScope, SearchUtilService, AbiSelectedFacetOptionsBreadboxService) {
        super($log, $rootScope, SearchUtilService, AbiSelectedFacetOptionsBreadboxService);

        this.init();
    }
}