'use strict';

class Router {
    static instance:any;

    // @ngInject
    constructor($stateProvider, $urlRouterProvider, StateConstants) {

        $stateProvider
            .state(StateConstants.ABI_SHELL, {
                url: '/abi',
                templateUrl: '/src/home/abi/shell.html',
                controller: 'Dmles.Home.Abi.ShellController',
                controllerAs: 'vm',
                abstract: true
            }).state(StateConstants.ABI_SEARCH, {
                url: '/abiSearch',
                templateUrl: '/src/home/abi/_views/abiSearch.html',
                controller: 'Dmles.Home.Abi.Views.AbiSearchController',
                controllerAs: 'vm',
                data: {
                    displayName: 'ABi Search'
                }
            }).state(StateConstants.ABI_SEARCH_HELP, {
                url: '/abiSearchHelp',
                templateUrl: '/src/home/abi/_views/abiSearchHelp.html',
                controller: 'Dmles.Home.Abi.Views.AbiSearchHelpController',
                controllerAs: 'vm',
                data: {
                    displayName: 'ABi Search Help'
                }
            }).state(StateConstants.ABI_PRODUCT_DETAILS, {
                url: '/productDetails',
                templateUrl: '/src/home/abi/_views/productDetails.html',
                controller: 'Dmles.Home.Abi.Views.ProductDetailsController',
                controllerAs: 'vm',
                data: {
                    displayName: 'Product Details'
                }
            }).state(StateConstants.ABI_PRODUCT_COMPARISON, {
                url: '/productComparison',
                templateUrl: '/src/home/abi/_views/productComparison.html',
                controller: 'Dmles.Home.Abi.Views.ProductComparisonController',
                controllerAs: 'vm',
                data: {
                    displayName: 'Product Comparison'
                }
            }).state(StateConstants.ABI_PRODUCTS_IN_SAME_PRODUCT_GROUP, {
                url: '/productsInSameProductGroup',
                templateUrl: '/src/home/abi/_views/productsInSameProductGroup.html',
                controller: 'Dmles.Home.Abi.Views.ProductsInSameProductGroupController',
                controllerAs: 'vm',
                data: {
                    displayName: 'Products In Same Product Group'
                }
            }).state(StateConstants.ABI_PREFERRED_PRODUCT, {
                url: '/preferredProduct',
                templateUrl: '/src/home/abi/_views/preferredProduct.html',
                controller: 'Dmles.Home.Abi.Views.PreferredProductController',
                controllerAs: 'vm',
                data: {
                    displayName: "Preferred Product"
                }
            }).state(StateConstants.ABI_PRODUCTS_SITE_CATALOG_ITEMS, {
                url: '/siteCatalogRecords',
                templateUrl: '/src/home/abi/_views/productsSiteCatalogItems.html',
                controller: 'Dmles.Home.Abi.Views.ProductsSiteCatalogItemsController',
                controllerAs: 'vm',
                data: {
                    displayName: "Site Catalog Records"
                }
        });
    }

    static factory($stateProvider, $urlRouterProvider, StateConstants) {
        Router.instance = new Router($stateProvider, $urlRouterProvider, StateConstants);
        return Router.instance;
    }
}

Router.factory.$inject = ['$stateProvider', '$urlRouterProvider', 'StateConstants'];

export default Router;