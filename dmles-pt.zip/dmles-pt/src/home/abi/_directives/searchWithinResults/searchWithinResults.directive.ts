'use strict';

export class SearchWithinResults {

    public templateUrl: string = "src/home/abi/_directives/searchWithinResults/searchWithinResults.html";
    public restrict: string = 'E';  // E = element, A = attribute, C = class, M = comment    
    public scope: any = {
        config: '='
    };
    public link: (scope, element, attrs) => void;

    // @ngInject
    constructor() {
        SearchWithinResults.prototype.link = (scope, element, attr) => {
        };
    }

    public static Factory() {
        let directive = () => {
            return new SearchWithinResults();
        };

        return directive;
    }
}