'use strict';

export class SelectedFacetOptionsBreadbox {

    public templateUrl: string = "src/home/abi/_directives/selectedFacetOptionsBreadbox/selectedFacetOptionsBreadbox.html";
    public restrict: string = 'E';  // E = element, A = attribute, C = class, M = comment    
    public scope: any = {
        breadboxSrv: '=',
        breadcrumbsSrv: '='        
    };
    public link: (scope, element, attrs) => void;

    // @ngInject
    constructor() {
        SelectedFacetOptionsBreadbox.prototype.link = (scope, element, attr) => {
        };
    }

    public static Factory() {
        let directive = () => {
            return new SelectedFacetOptionsBreadbox();
        };

        return directive;
    }
}