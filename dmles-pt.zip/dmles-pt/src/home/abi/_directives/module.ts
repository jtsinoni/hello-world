'use strict';

import {BaseCategoryService} from './category/baseCategory.service';
import {Category} from './category/category.directive';

import {BaseCategoryBreadcrumbService} from './categoryBreadcrumb/baseCategoryBreadcrumb.service';
import {CategoryBreadcrumb} from './categoryBreadcrumb/categoryBreadcrumb.directive';

import {BaseFacetService} from './facet/baseFacet.service';
import {Facet} from './facet/facet.directive';

import {BaseSearchWithinResultsService} from './searchWithinResults/baseSearchWithinResults.service';
import {SearchWithinResults} from './searchWithinResults/searchWithinResults.directive';

import {BaseSelectedFacetOptionsService} from './selectedFacetOptionsBreadbox/baseSelectedFacetOptions.service';
import {SelectedFacetOptionsBreadbox} from './selectedFacetOptionsBreadbox/selectedFacetOptionsBreadbox.directive';

let directivesModule = angular.module('Dmles.Home.Abi.Directives.Module', []);

directivesModule.service('BaseCategoryService', BaseCategoryService);
directivesModule.directive('category', Category.Factory());

directivesModule.service('BaseCategoryBreadcrumbService', BaseCategoryBreadcrumbService);
directivesModule.directive('categoryBreadcrumb', CategoryBreadcrumb.Factory());

directivesModule.service('BaseFacetService', BaseFacetService);
directivesModule.directive('facet', Facet.Factory());

directivesModule.service('BaseSearchWithinResultsService', BaseSearchWithinResultsService);
directivesModule.directive('searchWithinResults', SearchWithinResults.Factory());

directivesModule.service('BaseSelectedFacetOptionsService', BaseSelectedFacetOptionsService);
directivesModule.directive('selectedFacetOptionsBreadbox', SelectedFacetOptionsBreadbox.Factory());

export default directivesModule;