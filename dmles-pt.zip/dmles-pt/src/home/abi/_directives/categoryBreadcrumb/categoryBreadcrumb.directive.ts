'use strict';

export class CategoryBreadcrumb {

    public templateUrl: string = "src/home/abi/_directives/categoryBreadcrumb/categoryBreadcrumb.html";
    public restrict: string = 'E';  // E = element, A = attribute, C = class, M = comment    
    public scope: any = {
        config: '='
    };
    public link: (scope, element, attrs) => void;

    // @ngInject
    constructor() {
        CategoryBreadcrumb.prototype.link = (scope, element, attr) => {
        };
    }

    public static Factory() {
        let directive = () => {
            return new CategoryBreadcrumb();
        };

        return directive;
    }
}