'use strict';

import {SearchConstants} from "../../_constants/search.constants";
import {CategoryOption} from "../../_models/categoryOption.model";

export class BaseCategoryBreadcrumbService {

    // used for category breadcrumb - stores one selected category option per level
    public selectedCategoryOptions: Array<CategoryOption> = [];

    public displayLabel: string = "";

    // this module (for event purposes)    
    public eventModule: string = SearchConstants.EVENT_MODULE_BASE;

    // @ngInject
    constructor(private $log, private $rootScope, displayLabel: string, private SearchUtilService) {
        this.displayLabel = displayLabel;
    }

    public clearAllCategoryOptionSelections(executeSearch: boolean) {
        // emit event
        let eventId = this.SearchUtilService.buildEventId(
            this.eventModule,
            this.displayLabel + SearchConstants.EVENT_TARGET_COMPONENT_CATEGORY,
            SearchConstants.EVENT_TARGET_METHOD_CLEAR_ALL_CATEGORY_OPTION_SELECTIONS);

        this.$log.debug("emit: %s", JSON.stringify(eventId));
        this.$rootScope.$emit(eventId, executeSearch);
    }

    public clearBreadcrumb() {
        let executeSearch: boolean = true;
        this.clearAllCategoryOptionSelections(executeSearch);
        this.clearSelectedCategoryOptions();
    }

    public clearSelectedCategoryOptions() {
        this.selectedCategoryOptions = [];
    }

    public getSelectedCategoryOptions(): Array<CategoryOption> {
        // this.$log.debug("getSelectedCategoryOptions() - this.selectedCategoryOptions: %s", JSON.stringify(this.selectedCategoryOptions));
        return this.selectedCategoryOptions;
    }

    public init() {
        // listening here for an event targeted specifically to this Breadcrumb instance       
        let updateBreadcrumbPerCategoryOptionSelectionEventId: string = this.SearchUtilService.buildEventId(
            this.eventModule,
            this.displayLabel + SearchConstants.EVENT_TARGET_COMPONENT_CATEGORY_BREADCRUMB,
            SearchConstants.EVENT_TARGET_METHOD_UPDATE_BREADCRUMB_PER_CATEGORY_OPTION_SELECTION);

        let updateBreadcrumbPerCategoryOptionSelectionEventHandler =
            this.$rootScope.$on(updateBreadcrumbPerCategoryOptionSelectionEventId, (event: ng.IAngularEvent, data: Array<CategoryOption>) => {
                this.$log.debug("caught " + updateBreadcrumbPerCategoryOptionSelectionEventId + " event");
                this.updateBreadcrumbPerCategoryOptionSelection(data);
            });
        this.$rootScope.$on('$destroy', function () {
            updateBreadcrumbPerCategoryOptionSelectionEventHandler();
        });
    }

    public updateCategoryOptionSelectionPerBreadcrumbClick(categoryOption: CategoryOption) {
        this.$log.debug("categoryOption: %s", JSON.stringify(categoryOption));

        // emit event
        let eventId = this.SearchUtilService.buildEventId(
            this.eventModule,
            this.displayLabel + SearchConstants.EVENT_TARGET_COMPONENT_CATEGORY,
            SearchConstants.EVENT_TARGET_METHOD_UPDATE_CATEGORY_OPTION_SELECTIONS_PER_BREADCRUMB_CLICK);

        this.$log.debug("emit: %s", JSON.stringify(eventId));
        this.$rootScope.$emit(eventId, categoryOption);
    }

    public updateBreadcrumbPerCategoryOptionSelection(selectedCategoryOptions: Array<CategoryOption>) {
        // update the set of category options that are selected - based on data passed with
        // the new category option selection
        this.selectedCategoryOptions = selectedCategoryOptions;
        // this.$log.debug("updateBreadcrumbPerCategoryOptionSelection() - this.selectedCategoryOptions: %s", JSON.stringify(this.selectedCategoryOptions));
    }
}