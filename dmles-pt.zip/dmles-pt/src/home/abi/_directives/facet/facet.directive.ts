'use strict';

export class Facet {

    constructor() {
        Facet.prototype.link = (scope, element, attr) => {
        };
    }

    public templateUrl: string = "src/home/abi/_directives/facet/facet.html";
    public restrict: string = 'E';  // E = element, A = attribute, C = class, M = comment
    public scope: any = {
        config: '='
    };
    public link: (scope, element, attrs) => void;

    public static Factory() {
        let directive = () => {
            return new Facet();
        };

        return directive;
    }
}