'use strict';

import {CategoryConfiguration} from "../../_models/categoryConfiguration.model";
import {CategoryOption} from "../../_models/categoryOption.model";
import {SearchConstants} from "../../_constants/search.constants";

export class BaseCategoryService {
    public categoryConfiguration: CategoryConfiguration;

    // for now, handle a category with up to 10 levels
    public categoryLevels: Array<Array<CategoryOption>> = [[], [], [], [], [], [], [], [], [], []];

    // stores one selected category option per level
    // sent to breadcrumb component as event data each time a new category option is selected
    public selectedCategoryOptions: Array<CategoryOption> = [];

    // used to filter the displayed category options to only those that match (contain) the text string
    public matchText: string = "";

    // the current state of whether the category is expanded or collapsed
    public collapseCategory: boolean = false;

    // used to calculate the current height of the category
    public heightPerCategoryOptionDisplayed: number = 17.4;
    public maxCategoryOptionsDisplayed: number = 12;
    public minCategoryOptionsDisplayed: number = 0;
    public categoryOptionsDisplayed: number = this.maxCategoryOptionsDisplayed;
    public height: any = {
        "height": (this.maxCategoryOptionsDisplayed * this.heightPerCategoryOptionDisplayed) + "px"
    };

    // this module (for event purposes)    
    public eventModule: string = SearchConstants.EVENT_MODULE_BASE;

    // @ngInject
    constructor(private $log, private $rootScope, categoryConfiguration: CategoryConfiguration, private SearchUtilService) {
        this.categoryConfiguration = categoryConfiguration;
    }

    private buildSelectedCategoryOptions() {
        let categoryLevels: Array<Array<CategoryOption>> = this.categoryLevels;

        let foundSelectedCategoryOptionForThisLevel: boolean = false;

        // reinitialize
        this.selectedCategoryOptions = [];

        for (let i = 0; i < categoryLevels.length; i++) {
            let n: string;
            for (n in categoryLevels[i]) {
                if (categoryLevels[i][n].isSelected === true) {
                    foundSelectedCategoryOptionForThisLevel = true;
                    break;
                }
            }
            if (foundSelectedCategoryOptionForThisLevel) {
                this.selectedCategoryOptions[i] = categoryLevels[i][n];
                foundSelectedCategoryOptionForThisLevel = false;
            }
        }
    }

    public buildSearchClause(elasticSearchFieldNames: Array<string>): string {
        let returnValue: string = "";

        let selectedCategoryOptions: Array<CategoryOption> = [];

        // this.$log.debug("buildSearchClause() - this.categoryLevels: %s", JSON.stringify(this.categoryLevels));

        // Look through category levels for a selected category option
        for (let i = 0; i < elasticSearchFieldNames.length; i++) {
            let n: string;
            for (n in this.categoryLevels[i]) {
                if (this.categoryLevels[i][n].isSelected === true) {
                    selectedCategoryOptions.push(this.categoryLevels[i][n]);
                }
            }
        }

        // this.$log.debug("buildSearchClause() - selectedCategoryOptions: %s", JSON.stringify(selectedCategoryOptions));

        for (let i = 0; i < selectedCategoryOptions.length; i++) {
            if (i > 0) {
                returnValue = returnValue + " AND ";
            }
            if (selectedCategoryOptions[i].optionValue !== "") {
                // escape special characters that might be embedded in DMLSS/DML-ES data
                // not doing this causes issues for elasticsearch
                returnValue = returnValue + "(" + elasticSearchFieldNames[selectedCategoryOptions[i].level] + ":'"
                    + selectedCategoryOptions[i].optionValue.replace(/[!@#$%^&()+=\-[\]\\';,./{}|":<>?~_]/g, "\\$&")
                    + "')";
            }
        }
        if (selectedCategoryOptions.length > 1) {
            returnValue = "(" + returnValue + ")";
        }

        if (returnValue) {
            returnValue = "AND " + returnValue;
        }
        this.$log.debug("buildSearchClause() - returnValue: %s", JSON.stringify(returnValue));
        return returnValue;
    }

    public calculateHeight(): any {

        // calculate height
        if (this.collapseCategory === true) {
            // the category is CLOSED
            this.categoryOptionsDisplayed = this.minCategoryOptionsDisplayed;
        } else {
            let numberOfCategoryLevelsSelected = this.selectedCategoryOptions.length;
            if (numberOfCategoryLevelsSelected === 0) {
                if (this.categoryLevels[0].length >= this.maxCategoryOptionsDisplayed) {
                    this.categoryOptionsDisplayed = this.maxCategoryOptionsDisplayed;
                } else {
                    this.categoryOptionsDisplayed = this.categoryLevels[0].length;
                }
            } else if (numberOfCategoryLevelsSelected === 1) {
                if ((this.categoryLevels[0].length + this.categoryLevels[1].length) >= this.maxCategoryOptionsDisplayed) {
                    this.categoryOptionsDisplayed = this.maxCategoryOptionsDisplayed;
                } else {
                    this.categoryOptionsDisplayed = this.categoryLevels[0].length + this.categoryLevels[1].length;
                }
            } else if (numberOfCategoryLevelsSelected === 2) {
                if ((this.categoryLevels[0].length + this.categoryLevels[1].length + this.categoryLevels[2].length) >= this.maxCategoryOptionsDisplayed) {
                    this.categoryOptionsDisplayed = this.maxCategoryOptionsDisplayed;
                } else {
                    this.categoryOptionsDisplayed = this.categoryLevels[0].length + this.categoryLevels[1].length + this.categoryLevels[2].length;
                }
            } else if (numberOfCategoryLevelsSelected === 3) {
                if ((this.categoryLevels[0].length + this.categoryLevels[1].length + this.categoryLevels[2].length + this.categoryLevels[3].length) >= this.maxCategoryOptionsDisplayed) {
                    this.categoryOptionsDisplayed = this.maxCategoryOptionsDisplayed;
                } else {
                    this.categoryOptionsDisplayed = this.categoryLevels[0].length + this.categoryLevels[1].length + this.categoryLevels[2].length + this.categoryLevels[3].length;
                }
            } else if (numberOfCategoryLevelsSelected === 4) {
                if ((this.categoryLevels[0].length + this.categoryLevels[1].length + this.categoryLevels[2].length + this.categoryLevels[3].length + this.categoryLevels[4].length) >= this.maxCategoryOptionsDisplayed) {
                    this.categoryOptionsDisplayed = this.maxCategoryOptionsDisplayed;
                } else {
                    this.categoryOptionsDisplayed = this.categoryLevels[0].length + this.categoryLevels[1].length + this.categoryLevels[2].length + this.categoryLevels[3].length + this.categoryLevels[4].length;
                }
            } else {
                this.categoryOptionsDisplayed = this.maxCategoryOptionsDisplayed;
            }
        }
        this.height = {
            "height": (this.categoryOptionsDisplayed * this.heightPerCategoryOptionDisplayed) + "px"
        };

        //this.$log.debug("categoryOptionsWithNonZeroCounts: %s", JSON.stringify(categoryOptionsWithNonZeroCounts));
        //this.$log.debug("this.height: %s", JSON.stringify(this.height));
        return this.height;
    }

    public determineIndentation(level: number): string {
        let returnValue: string = "";

        let fourSpaces: string = "\u00A0\u00A0\u00A0\u00A0";
        for (let i = 0; i < level; i++) {
            returnValue += fourSpaces;
        }
        return returnValue;
    }

    public init() {
        // listening here for an event targeted specifically to a Category instance (i.e. to the UNSPSC Taxonomy)
        let updateCategoryOptionSelectionsPerBreadcrumbClickEventId: string = this.SearchUtilService.buildEventId(
            this.eventModule,
            this.categoryConfiguration.displayLabel + SearchConstants.EVENT_TARGET_COMPONENT_CATEGORY,
            SearchConstants.EVENT_TARGET_METHOD_UPDATE_CATEGORY_OPTION_SELECTIONS_PER_BREADCRUMB_CLICK);

        let updateCategoryOptionSelectionsPerBreadcrumbClickEventHandler =
            this.$rootScope.$on(updateCategoryOptionSelectionsPerBreadcrumbClickEventId, (event: ng.IAngularEvent, data: CategoryOption) => {
                this.$log.debug("caught " + updateCategoryOptionSelectionsPerBreadcrumbClickEventId + " event");
                this.updateCategoryOptionSelectionsPerBreadcrumbClick(data);
            });
        this.$rootScope.$on('$destroy', function () {
            updateCategoryOptionSelectionsPerBreadcrumbClickEventHandler();
        });

        // listening here for an event targeted specifically to a Category instance (i.e. to the UNSPSC Taxonomy)
        let clearAllCategoryOptionSelectionsEventId: string = this.SearchUtilService.buildEventId(
            this.eventModule,
            this.categoryConfiguration.displayLabel + SearchConstants.EVENT_TARGET_COMPONENT_CATEGORY,
            SearchConstants.EVENT_TARGET_METHOD_CLEAR_ALL_CATEGORY_OPTION_SELECTIONS);

        let clearAllCategoryOptionSelectionsEventHandler =
            this.$rootScope.$on(clearAllCategoryOptionSelectionsEventId, (event: ng.IAngularEvent, data: boolean) => {
                this.$log.debug("caught " + clearAllCategoryOptionSelectionsEventId + " event");
                this.clearAllCategoryOptionSelections(data);
            });
        this.$rootScope.$on('$destroy', function () {
            clearAllCategoryOptionSelectionsEventHandler();
        });
    }

    public initialize() {
        this.selectedCategoryOptions = [];
        this.categoryLevels = [[], [], [], [], [], [], [], [], [], []];
        // this.$log.debug("initialize() - this.categoryLevels: %s", JSON.stringify(this.categoryLevels));
        this.categoryLevels[0] = this.categoryConfiguration.topLevelInitialCategoryOptions;
        angular.forEach(this.categoryLevels[0], (categoryOption) => {
            categoryOption.isSelected = false;
        });
        this.matchText = "";
        // this.$log.debug("initialize() - this.categoryLevels[0]: %s", JSON.stringify(this.categoryLevels[0]));
    }

    public populate(category: BaseCategoryService, numberOfCategoriesWithOptionsSelected: number, abiAggregations: any, numberOfSearchResults: number) {
        let categoryLevels: Array<Array<CategoryOption>> = this.categoryLevels;

        let foundSelectedCategoryOption: boolean = false;

        this.$log.debug("BaseCategoryService populate() - this.selectedCategoryOptions: %s", JSON.stringify(this.selectedCategoryOptions));

        // Working from the one sub-level lower than the level with a selection - up the hierarchy
        for (let i = this.selectedCategoryOptions.length; i >= 0; i--) {
            let n: string;
            for (n in categoryLevels[i]) {
                if (categoryLevels[i][n].isSelected === true) {
                    foundSelectedCategoryOption = true;
                    break;
                }
            }

            // On a given level, if no category options are selected then we need to update them
            // with the appropriate aggregation from the latest search result
            if (!foundSelectedCategoryOption) {

                // if we are handling a UNSPSC Segment and there are no search results, need to reinitialize
                if (i === 0 && numberOfSearchResults === 0) {
                    this.$log.debug("Reinitializing the level 0 values");
                    this.initialize();
                } else {
                    // initialize the level's categoryLevels that we are going to update
                    categoryLevels[i] = [];

                    // this.$log.debug("abiAggregations: %s", JSON.stringify(abiAggregations));

                    if (abiAggregations && abiAggregations[category.categoryConfiguration.aggregationIdentifiers[i]] && abiAggregations[category.categoryConfiguration.aggregationIdentifiers[i]].buckets) {
                        let values = abiAggregations[category.categoryConfiguration.aggregationIdentifiers[i]].buckets;
                        // this.$log.debug("values: %s", JSON.stringify(values));
                        for (let j in values) {
                            let option: CategoryOption = new CategoryOption();
                            option.optionValue = values[j].key;
                            option.isSelected = false;
                            option.level = i;
                            categoryLevels[i].push(option);
                        }
                    }
                    this.categoryLevels[i] = categoryLevels[i];
                    // this.$log.debug("this.categoryLevels[i] = %s, i = %d", JSON.stringify(this.categoryLevels[i]), i);
                }
            } else {
                // there is a selection on this level
                if (numberOfCategoriesWithOptionsSelected > 1) {
                    // update the category option values on this level where there is a selection

                    // initialize the level's categoryLevels that we are going to update
                    categoryLevels[i] = [];

                    // this.$log.debug("abiAggregations: %s", JSON.stringify(abiAggregations));

                    if (abiAggregations && abiAggregations[category.categoryConfiguration.aggregationIdentifiers[i]] && abiAggregations[category.categoryConfiguration.aggregationIdentifiers[i]].buckets) {
                        let values = abiAggregations[category.categoryConfiguration.aggregationIdentifiers[i]].buckets;
                        // this.$log.debug("values: %s", JSON.stringify(values));
                        for (let j in values) {
                            let option: CategoryOption = new CategoryOption();
                            option.optionValue = values[j].key;
                            if (option.optionValue === this.selectedCategoryOptions[i].optionValue) {
                                option.isSelected = true;
                            } else {
                                option.isSelected = false;
                            }
                            option.level = i;
                            categoryLevels[i].push(option);
                        }
                    }
                    this.categoryLevels[i] = categoryLevels[i];
                    this.$log.debug("BaseCategoryService populate() - this.categoryLevels[i] = %s, i = %d", JSON.stringify(this.categoryLevels[i]), i);
                }
            }
        }
    }

    private setGivenCategoryOptionsToNotSelected(categoryOptions: Array<CategoryOption>) {
        for (let i = 0; i < categoryOptions.length; i++) {
            categoryOptions[i].isSelected = false;
        }
    }

    // there can only be one category option selected for a given level
    private setOptionValueAsOnlyOneSelectedInGivenCategoryOptions(categoryOptions: Array<CategoryOption>, optionValue: string) {
        for (let i = 0; i < categoryOptions.length; i++) {
            if (optionValue === categoryOptions[i].optionValue) {
                // toggle the current isSelected setting associated with optionValue
                if (categoryOptions[i].isSelected === true) {
                    categoryOptions[i].isSelected = false;
                } else {
                    categoryOptions[i].isSelected = true;
                }
            } else {
                categoryOptions[i].isSelected = false;
            }
        }
    }

    // there can only be one category option selected for a given level
    // also reset all sub-category options to not selected
    private setSelectedCategoryOptionForGivenLevel(level: number, optionValue: string, executeSearch: boolean) {

        this.setOptionValueAsOnlyOneSelectedInGivenCategoryOptions(this.categoryLevels[level], optionValue);
        for (let i = level + 1; i < this.categoryConfiguration.aggregationIdentifiers.length; i++) {
            if (this.categoryLevels[i] !== []) {
                this.setGivenCategoryOptionsToNotSelected(this.categoryLevels[i]);
            }
        }

        // update selected Category Options
        this.buildSelectedCategoryOptions();

        // emit event to the associated category breadcrumb component 
        // to tell it to update itself with the latest selectedCategoryOptions
        this.updateBreadcrumb();

        if (executeSearch) {
            // emit event to the search component to tell it to execute a search
            this.SearchUtilService.executeSearch(this.eventModule, null);
        }
    }

    public togglePanel() {
        this.collapseCategory = !this.collapseCategory;
    }

    private updateBreadcrumb() {
        let eventId = this.SearchUtilService.buildEventId(
            this.eventModule,
            this.categoryConfiguration.displayLabel + SearchConstants.EVENT_TARGET_COMPONENT_CATEGORY_BREADCRUMB,
            SearchConstants.EVENT_TARGET_METHOD_UPDATE_BREADCRUMB_PER_CATEGORY_OPTION_SELECTION);

        this.$log.debug("emit: %s", JSON.stringify(eventId));
        this.$rootScope.$emit(eventId, this.selectedCategoryOptions);
    }

    private updateCategoryOptionSelectionsPerBreadcrumbClick(categoryOption: CategoryOption) {

        // we want the breadcrumb category option that was clicked to now be the lowest level category option selected
        // so we need to find the selected category option for the next level down and act like we clicked on it
        if (this.selectedCategoryOptions[categoryOption.level + 1]) {
            let relevantCategoryOption = this.selectedCategoryOptions[categoryOption.level + 1];

            // call function to unselect the relevantCategoryOption and all lower level options
            this.setSelectedCategoryOptionForGivenLevel(relevantCategoryOption.level, relevantCategoryOption.optionValue, true);
        }
    }

    private clearAllCategoryOptionSelections(executeSearch: boolean) {
        // reinitialize
        this.initialize();

        // emit event to the associated category breadcrumb component
        // to tell it to update itself with the latest selectedCategoryOptions
        this.updateBreadcrumb();

        // emit event to the search component to tell it to execute a search       
        if (executeSearch) {
            // emit event to the search component to tell it to execute a search
            this.SearchUtilService.executeSearch(this.eventModule, null);
        }
    }
}