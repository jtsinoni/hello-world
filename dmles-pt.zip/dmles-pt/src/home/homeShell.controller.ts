import {User} from '../_models/user.model';

export class HomeShellController {
    private controllerName:string = "Home Shell Controller";
    public currentUser:User = null;
    public isLoggedIn:boolean;

    // @ngInject
    constructor(private $log, private $scope, private $state, private Authentication,  private ContentConstants, private dataService, private MainNavService,
                private UserService, private StateConstants) {
        this.$log.debug('%s - Start', this.controllerName);
        this.isLoggedIn = Authentication.isLoggedIn();
        this.init();
    }

    private init() {
        this.$scope.$on(this.ContentConstants.EVENT_USER_UPDATE, (event, data) => {
            if (data) {
                this.currentUser = data.user;
            }
        });
    }

    public logout() {
        this.MainNavService.clearCurrentService();
        this.dataService.clearCache();
        this.Authentication.logout();
        this.$state.go(this.StateConstants.LOGIN);
    }
}