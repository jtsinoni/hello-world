'use strict';

import {User} from '../../_models/user.model';

export class AdminShellController {
    private controllerName:string = "Admin Shell Controller";
    private currUser:User;

    // @ngInject
    constructor(private $log, private $state, private StateConstants, private UserService) {
        this.currUser = this.UserService.currentUser;

    }

    /**
     Go to the user management page
     */
    public goToUserManagement() {
        this.$log.debug("%s - Go to User Management", this.controllerName);
        this.$state.go(this.StateConstants.ADMIN_USER_MNG);
    }

    /**
     Go to the user profile management page
     */
    public goToUserProfileManagement() {
        this.$log.debug("%s - Go to User Profile Management", this.controllerName);
        this.$state.go(this.StateConstants.ADMIN_USER_PROFILE_MNG);
    }

    /**
     Go to the role management page
     */
    public goToRoleManagement() {
        this.$log.debug("%s - Go to Role Management", this.controllerName);
        this.$state.go(this.StateConstants.ADMIN_ROLE_MNG);
    }

    /**
     Go to the permission management page
     */
    public goToPermManagement() {
        this.$log.debug("%s - Go to Permission Management", this.controllerName);
        this.$state.go(this.StateConstants.ADMIN_PERMISSION_MNG); 
    }
}