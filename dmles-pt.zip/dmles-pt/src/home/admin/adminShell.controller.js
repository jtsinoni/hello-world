define(["require", "exports"], function (require, exports) {
    'use strict';
    var AdminShellController = (function () {
        // @ngInject
        function AdminShellController($log, $state, StateConstants, UserService) {
            this.$log = $log;
            this.$state = $state;
            this.StateConstants = StateConstants;
            this.UserService = UserService;
            this.controllerName = "Admin Shell Controller";
            this.currUser = this.UserService.currentUser;
        }
        /**
         Go to the user management page
         */
        AdminShellController.prototype.goToUserManagement = function () {
            this.$log.debug("%s - Go to User Management", this.controllerName);
            this.$state.go(this.StateConstants.ADMIN_USER_MNG);
        };
        /**
         Go to the user profile management page
         */
        AdminShellController.prototype.goToUserProfileManagement = function () {
            this.$log.debug("%s - Go to User Profile Management", this.controllerName);
            this.$state.go(this.StateConstants.ADMIN_USER_PROFILE_MNG);
        };
        /**
         Go to the role management page
         */
        AdminShellController.prototype.goToRoleManagement = function () {
            this.$log.debug("%s - Go to Role Management", this.controllerName);
            this.$state.go(this.StateConstants.ADMIN_ROLE_MNG);
        };
        /**
         Go to the permission management page
         */
        AdminShellController.prototype.goToPermManagement = function () {
            this.$log.debug("%s - Go to Permission Management", this.controllerName);
            this.$state.go(this.StateConstants.ADMIN_PERMISSION_MNG);
        };
        return AdminShellController;
    }());
    exports.AdminShellController = AdminShellController;
});
//# sourceMappingURL=adminShell.controller.js.map