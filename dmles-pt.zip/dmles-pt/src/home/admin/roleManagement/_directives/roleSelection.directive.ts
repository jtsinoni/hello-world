'use strict';

export class RoleSelectionDirective {

    constructor() {
        RoleSelectionDirective.prototype.link = (scope, element, attr) => {
        };
    }

    public templateUrl: string = "./src/home/admin/roleManagement/_directives/roleSelection.html";
    public restrict: string = "EA";
    public link: (scope, element, attrs) => void;
    public scope: any = {
        collection: '=',
        controller: '=',
        viewOnly: '='
    };

    public static Factory() {
        let directive = () => {
            return new RoleSelectionDirective();
        };

        return directive;
    }
}