define(["require", "exports", './permSelection.directive'], function (require, exports, permSelection_directive_1) {
    'use strict';
    var directivesModule = angular.module('Dmles.UserAdmin.RoleManagement.DirectivesModule', []);
    directivesModule.directive('dmlesPermSelection', permSelection_directive_1.PermSelectionDirective.Factory());
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = directivesModule;
});
//# sourceMappingURL=module.js.map