'use strict';

export class PermSelectionDirective {

    constructor() {
        PermSelectionDirective.prototype.link = (scope, element, attr) => {
        };
    }

    public templateUrl: string = "./src/home/admin/roleManagement/_directives/PermSelection.html";
    public restrict: string = "EA";
    public link: (scope, element, attrs) => void;
    public scope: any = {
        collection: '=',
        controller: '=',
        viewOnly: '='
    };

    public static Factory() {
        let directive = () => {
            return new PermSelectionDirective();
        };

        return directive;
    }
}