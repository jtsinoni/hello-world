'use strict';

import {PermSelectionDirective} from './permSelection.directive';


let directivesModule = angular.module('Dmles.UserAdmin.RoleManagement.DirectivesModule', []);
directivesModule.directive('dmlesPermSelection', PermSelectionDirective.Factory());

export default directivesModule;

