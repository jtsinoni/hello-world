'use strict';

import {PermSelectionDirective} from './permSelection.directive';
import {RoleSelectionDirective} from './roleSelection.directive';


let directivesModule = angular.module('Dmles.UserAdmin.RoleManagement.DirectivesModule', []);
directivesModule.directive('dmlesPermSelection', PermSelectionDirective.Factory());
directivesModule.directive('dmlesRoleSelection', RoleSelectionDirective.Factory());

export default directivesModule;

