define(["require", "exports"], function (require, exports) {
    'use strict';
    var PermSelectionDirective = (function () {
        function PermSelectionDirective() {
            this.templateUrl = "./src/home/admin/roleManagement/_directives/PermSelection.html";
            this.restrict = "EA";
            this.scope = {
                collection: '=',
                controller: '=',
                viewOnly: '='
            };
            PermSelectionDirective.prototype.link = function (scope, element, attr) {
            };
        }
        PermSelectionDirective.Factory = function () {
            var directive = function () {
                return new PermSelectionDirective();
            };
            return directive;
        };
        return PermSelectionDirective;
    }());
    exports.PermSelectionDirective = PermSelectionDirective;
});
//# sourceMappingURL=permSelection.directive.js.map