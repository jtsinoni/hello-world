define(["require", "exports"], function (require, exports) {
    'use strict;';
    var Router = (function () {
        // @ngInject
        function Router($stateProvider, $urlRouterProvider, StateConstants) {
            // For any unmatched url, redirect to /home
            $stateProvider
                .state(StateConstants.ADMIN_ROLE_MNG, {
                url: '/roleManagement',
                templateUrl: '/src/home/admin/roleManagement/_views/roleManagement.html',
                controller: 'Dmles.Admin.RoleManagement.Views.RoleManagementController',
                controllerAs: 'vm',
                data: {
                    displayName: 'Role Management'
                }
            }).state(StateConstants.ADMIN_ROLE_CREATE, {
                url: '/roleCreate',
                templateUrl: '/src/home/admin/roleManagement/_views/roleCreate.html',
                controller: 'Dmles.Admin.RoleManagement.Views.RoleCreateController',
                controllerAs: 'vm',
                data: {
                    displayName: 'Create Role'
                }
            }).state(StateConstants.ADMIN_ROLE_EDIT_GEN_INFO, {
                url: '/roleEditGenInfo',
                templateUrl: '/src/home/admin/roleManagement/_views/roleEditGenInfo.html',
                controller: 'Dmles.Admin.RoleManagement.Views.RoleEditGenInfoController',
                controllerAs: 'vm',
                data: {
                    displayName: 'Edit Role General Information'
                }
            }).state(StateConstants.ADMIN_ROLE_EDIT_PERMS, {
                url: '/roleEditPerms',
                templateUrl: '/src/home/admin/roleManagement/_views/roleEditPerms.html',
                controller: 'Dmles.Admin.RoleManagement.Views.RoleEditPermsController',
                controllerAs: 'vm',
                data: {
                    displayName: 'Edit Role Permissions'
                }
            }).state(StateConstants.ADMIN_ROLE_VIEW, {
                url: '/roleView',
                templateUrl: '/src/home/admin/roleManagement/_views/roleView.html',
                controller: 'Dmles.Admin.RoleManagement.Views.RoleViewController',
                controllerAs: 'vm',
                data: {
                    displayName: 'View Role'
                }
            });
        }
        Router.factory = function ($stateProvider, $urlRouterProvider, StateConstants) {
            Router.instance = new Router($stateProvider, $urlRouterProvider, StateConstants);
            return Router.instance;
        };
        return Router;
    }());
    Router.factory.$inject = ['$stateProvider', '$urlRouterProvider', 'StateConstants'];
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = Router;
});
//# sourceMappingURL=router.js.map