define(["require", "exports"], function (require, exports) {
    "use strict";
    'use strict';
    var RoleManagementController = (function () {
        // @ngInject
        function RoleManagementController($log, $state, RoleService, RoleManagementService, StateConstants) {
            this.$log = $log;
            this.$state = $state;
            this.RoleService = RoleService;
            this.RoleManagementService = RoleManagementService;
            this.StateConstants = StateConstants;
            this.controllerName = "Role Management Controller";
            this.roleFilter = "";
            this.selectedRole = null;
            this.roleToDelete = null;
            this.roleDetailsShowUpdate = false;
            this.$log.debug("%s - Start", this.controllerName);
            this.init();
        }
        RoleManagementController.prototype.init = function () {
            this.RoleManagementService.loadRoleTable();
        };
        RoleManagementController.prototype.roleManagementFilter = function () {
            this.RoleManagementService.rolesNgTable.filter({ $: this.roleFilter });
            this.RoleManagementService.rolesNgTable.reload();
        };
        RoleManagementController.prototype.goToRoleManagement = function () {
            //this.$log.debug("%s - Go to Role Management", this.controllerName);
            this.$state.go(this.StateConstants.ADMIN_ROLE_MNG);
        };
        RoleManagementController.prototype.goToRoleView = function (role) {
            this.RoleManagementService.setRole(angular.copy(role));
            //this.$log.debug("%s - Go to Role View", this.controllerName);
            this.$state.go(this.StateConstants.ADMIN_ROLE_VIEW);
        };
        RoleManagementController.prototype.goToRoleCreate = function () {
            this.RoleManagementService.clearRole();
            //this.$log.debug("%s - Go to Role Create", this.controllerName);
            this.$state.go(this.StateConstants.ADMIN_ROLE_CREATE);
        };
        RoleManagementController.prototype.setRoleToBeDeleted = function (role) {
            this.$log.debug("setRoleToBeDeleted: %s", JSON.stringify(role));
            this.roleToDelete = angular.copy(role);
        };
        RoleManagementController.prototype.deleteRole = function () {
            // this.$log.debug("Deleting role: %s", JSON.stringify(this.roleToDelete));
            var _this = this;
            this.RoleService.deleteRole(this.roleToDelete.id).then(function (response) {
                // this.$log.debug("%s - Delete Role Returned: %s", this.controllerName, JSON.stringify(response.data));
                _this.init();
            }, function (errResponse) {
                _this.$log.error("Error deleting role");
            });
        };
        return RoleManagementController;
    }());
    exports.RoleManagementController = RoleManagementController;
});
//# sourceMappingURL=roleManagement.controller.js.map