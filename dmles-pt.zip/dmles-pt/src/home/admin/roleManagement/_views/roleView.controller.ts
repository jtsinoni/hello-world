'use strict';

import {Role} from '../../../../_models/role.model';
import {AssignedPermission} from "../../../../_models/assignedPermission.model";

export class RoleViewController {
    private controllerName: string = "Role View Controller";
    private role: Role = null;    

    // @ngInject
    constructor(private $log, private $state, private RoleManagementService, private StateConstants) {
        this.$log.debug("%s - Start", this.controllerName);
        this.role = RoleManagementService.getRole();

        if (this.role === null) {
            //no Role, go back
            this.goToRoleManagement();
        } else {
            this.$log.debug("Selected Role: %s", JSON.stringify(this.role));
            this.initializePermissions();
        }
    }

    /**
     Initialize the permissions
     */
    private initializePermissions(): void {
        
        // Loop through the role's assignedPermissions and create updatedAssignedPermissions that
        // include both allowed and denied Booleans - for internal use in GUI
        let updatedAssignedPermissions: any[] = [];
        angular.forEach(this.role.assignedPermissions, (perm) => {
            let opt: any = {
                "id": perm.id,
                "name": perm.name,
                "description": perm.permission.description,
                "functionalArea": perm.permission.functionalArea,
                "allowed": perm.allowed,
                "denied": !perm.allowed,
                "permission": perm.permission
            };
            updatedAssignedPermissions.push(opt);
        });             
        // this.$log.debug("updatedAssignedPermissions: %s", JSON.stringify(updatedAssignedPermissions));

        this.buildDisplayedPermissionCollections("VIEW", updatedAssignedPermissions);
    }

    private buildDisplayedPermissionCollections(typeOfDisplay: string, updatedAssignedPermissions: Array<AssignedPermission>): void {
        this.RoleManagementService.populatePermissionGroups(typeOfDisplay, updatedAssignedPermissions);
    }

    /**
     Return to role management state
     */
    private goToRoleManagement(): void {
        // this.$log.debug("%s - Go to Role Management", this.controllerName);
        this.$state.go(this.StateConstants.ADMIN_ROLE_MNG);
    }

    /**
     Go to Edit Role General Information page - called from html
     */
    public goToEditRoleGeneralInfo(): void {
        // this.$log.debug("%s - Go to Edit Role General Information", this.controllerName);
        this.$state.go(this.StateConstants.ADMIN_ROLE_EDIT_GEN_INFO);
    }

    /**
     Go to Edit Role Permissions page - called from html
     */
    public goToEditRolePermissions(): void {
        // this.$log.debug("%s - Go to Edit Role Permissions", this.controllerName);
        this.$state.go(this.StateConstants.ADMIN_ROLE_EDIT_PERMS);
    }
}