define(["require", "exports"], function (require, exports) {
    'use strict';
    var RoleEditGenInfoController = (function () {
        // @ngInject
        function RoleEditGenInfoController($log, RoleService, RoleManagementService) {
            this.$log = $log;
            this.RoleService = RoleService;
            this.RoleManagementService = RoleManagementService;
            this.roleGeneralInfoChanged = false;
            this.controllerName = "Role Edit General Information Controller";
            this.role = null;
            this.$log.debug("%s - Start", this.controllerName);
            this.role = RoleManagementService.getRole();
            //this.$log.debug(this.role);
            if (this.role === null) {
                //no Role, go back
                this.RoleManagementService.goToRoleView();
            }
            else {
                this.$log.debug("Selected Role: %s", JSON.stringify(this.role));
            }
        }
        /**
         Updates the role general information and returns to the Role View state
         */
        RoleEditGenInfoController.prototype.onSubmit = function () {
            var roleEditGenInfo = angular.copy(this.role);
            // this.$log.debug("this.role.name: %s", JSON.stringify(this.role.name));
            // this.$log.debug("this.role.description: %s", JSON.stringify(this.role.description));
            // this.$log.debug("this.role.functionalArea: %s", JSON.stringify(this.role.functionalArea));
            // Save button on GUI only gets enabled when all required data has values - so no need to check here
            this.saveRoleGeneralInfo();
            this.RoleManagementService.goToRoleView();
        };
        RoleEditGenInfoController.prototype.saveRoleGeneralInfo = function () {
            var _this = this;
            this.roleGeneralInfoChanged = false;
            // this.$log.debug("Saving this.role: %s", JSON.stringify(this.role));
            this.RoleService.saveRoleData(this.role).then(function (response) {
                _this.role = response.data;
                // this.$log.debug("%s - Saved Role Returned: %s", this.controllerName, JSON.stringify(this.role));
                _this.RoleManagementService.setRole(_this.role);
                _this.RoleManagementService.loadRoleTable();
            }, function (errResponse) {
                _this.$log.error("Error saving role general information");
            });
        };
        return RoleEditGenInfoController;
    }());
    exports.RoleEditGenInfoController = RoleEditGenInfoController;
});
//# sourceMappingURL=roleEditGenInfo.controller.js.map