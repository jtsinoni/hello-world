'use strict';

import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {Permission} from '../../../../_models/permission.model';
import {Role} from '../../../../_models/role.model';
import {PermCollection} from "../_services/roleManagement.service";

export class RoleCreateController {
    private controllerName: string = "Role Create Controller";
    private role: Role = null;

    public allPermissions: Array<Permission> = [];

    // @ngInject
    constructor(private $log, private $state, private RoleService, public RoleManagementService, private StateConstants) {
        this.$log.debug("%s - Start", this.controllerName);
        this.role = RoleManagementService.getRole();
        //this.$log.debug(this.role);

        if (this.role === null) {
            //no Role, go back
            this.goToRoleManagement();
        } else {
            this.$log.debug("new Role: %s", JSON.stringify(this.role));
            this.init();
        }
        this.RoleManagementService.getRoleFunctionalAreaConfig();
    }

    private init(): void {
        this.getAllPermissionsAndBuildPermissionCollections();
    }

    private getAllPermissionsAndBuildPermissionCollections() {
        this.RoleService.getAllPermissions().then((response: IHttpPromiseCallbackArg<Permission[]>) => {
            // this.$log.debug("%s - Permissions Returned: %s", this.controllerName, JSON.stringify(response.data));

            // permissions come in using hierarchical structure (per TS)
            // we actually want them sans the hierarchical structure - so convert
            angular.forEach(response.data, (element: any) => {
                angular.forEach(element.permissions, (permission) => {
                    this.allPermissions.push(permission);
                });
            });
            // this.$log.debug("this.allPermissions: %s", JSON.stringify(this.allPermissions));

            this.buildDisplayedPermissionCollections("CREATE", this.allPermissions);

        }, (errResponse: IHttpPromiseCallbackArg<Role[]>) => {
            this.$log.error("Error retrieving All Permissions");
        });
    }

    private buildDisplayedPermissionCollections(typeOfDisplay: string, allPermissions: Array<Permission>): void {
        this.RoleManagementService.populatePermissionGroups(typeOfDisplay, allPermissions);
    }

    public allowSave() {
        return (this.role.name &&
            this.role.description &&
            this.role.functionalArea &&
            this.isPermSelected());
    }

    private isPermSelected() {
        let list:PermCollection[] = this.RoleManagementService.getPermissionCollections();
        let found = false;
        let iCollection = 0;
        while (!found && iCollection < list.length) {
            let coll = list[iCollection];
            let opts = coll.allPermOpts;
            let iOpts = 0;
            while (!found && iOpts < opts.length) {
                let opt = opts[iOpts];
                if (opt.allowed) {
                    found = true;
                }
                iOpts ++;
            }
            iCollection ++;
        }
        return found;
    }
    private getSelectedPerms() {
        let list:PermCollection[] = this.RoleManagementService.getPermissionCollections();
        let selected:any[] = [];
        let iCollection = 0;
        while (iCollection < list.length) {
            let coll = list[iCollection];
            let opts = coll.allPermOpts;
            let iOpts = 0;
            while (iOpts < opts.length) {
                let opt = opts[iOpts];
                if (opt.allowed) {
                    selected.push(opt);
                }
                iOpts ++;
            }
            iCollection ++;
        }
        return selected;
    }
    /**
     Creates the role, if it is valid, and returns to the RoleManagement state
     */
    private onSubmit() {
        let roleCreate: any = angular.copy(this.role);

        if (!roleCreate.name || !roleCreate.description || !roleCreate.functionalArea || !this.isPermSelected()) {
            this.$log.debug("roleCreate - missing a required field");
        } else {

            let selected:any[] = this.getSelectedPerms();

            let assignedPermissions: any[] = [];
            angular.forEach(selected, (perm) => {
                let assignedPermission: any = {
                    name: perm.name,
                    allowed: perm.allowed,
                    permission: this.retrievePermissionFromAllPermissions(perm.id)
                };
                assignedPermissions.push(assignedPermission);
            });
            // this.$log.debug("assignedPermissions: %s", JSON.stringify(assignedPermissions));

            // this.$log.debug("roleCreate.assignedPermissions: %s", JSON.stringify(roleCreate.assignedPermissions));
            roleCreate.assignedPermissions = assignedPermissions;
            // this.$log.debug("roleCreate.assignedPermissions: %s", JSON.stringify(roleCreate.assignedPermissions));

            roleCreate.id = null;
            // this.$log.debug("roleCreate: %s", JSON.stringify(roleCreate));

            this.createRole(roleCreate);
        }
    }

    private retrievePermissionFromAllPermissions(permId: string): any {

        let returnValue = {};
        angular.forEach(this.allPermissions, (perm) => {
            if (permId === perm.id) {
                returnValue = perm;
            }
        });
        return returnValue;
    }

    public createRole(roleCreate) {
        // this.$log.debug("Creating roleCreate: %s", JSON.stringify(roleCreate));

        this.RoleService.createRole(roleCreate).then((response: IHttpPromiseCallbackArg<Role>) => {
            // this.$log.debug("%s - Create Role Returned: %s", this.controllerName, JSON.stringify(response.data));
            this.goToRoleManagement();
        }, (errResponse: IHttpPromiseCallbackArg<Role[]>) => {
            this.$log.error("Error creating role");
        });
    }

    /**
     Return to role management state
     */
    private goToRoleManagement(): void {
        // this.$log.debug("%s - Go to Role Management", this.controllerName);
        this.RoleManagementService.loadRoleTable();
        this.$state.go(this.StateConstants.ADMIN_ROLE_MNG);
    }
}