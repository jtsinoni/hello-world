'use strict';

import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {Permission} from '../../../../_models/permission.model';
import {Role} from '../../../../_models/role.model';
import {PermCollection} from "../_services/roleManagement.service";

export class RoleCreateController {
    private controllerName: string = "Role Create Controller";
    private role: Role = null;

    public allPermissions: Array<Permission> = [];

    // @ngInject
    constructor(private $log, private $state, private RoleService, private RoleManagementService, private StateConstants) {
        this.$log.debug("%s - Start", this.controllerName);
        this.role = RoleManagementService.getRole();
        //this.$log.debug(this.role);

        if (this.role === null) {
            //no Role, go back
            this.goToRoleManagement();
        } else {
            this.$log.debug("new Role: %s", JSON.stringify(this.role));
            this.init();
        }
    }

    private init(): void {
        this.getAllPermissionsAndBuildPermissionCollections();
    }

    private getAllPermissionsAndBuildPermissionCollections() {
        this.RoleService.getAllPermissions().then((response: IHttpPromiseCallbackArg<Permission[]>) => {
            // this.$log.debug("%s - Permissions Returned: %s", this.controllerName, JSON.stringify(response.data));

            // permissions come in using hierarchical structure (per TS)
            // we actually want them sans the hierarchical structure - so convert
            angular.forEach(response.data, (element: any) => {
                angular.forEach(element.permissions, (permission) => {
                    this.allPermissions.push(permission);
                });
            });
            // this.$log.debug("this.allPermissions: %s", JSON.stringify(this.allPermissions));

            this.buildDisplayedPermissionCollections("CREATE", this.allPermissions);

        }, (errResponse: IHttpPromiseCallbackArg<Role[]>) => {
            this.$log.error("Error retrieving All Permissions");
        });
    }

    private buildDisplayedPermissionCollections(typeOfDisplay: string, allPermissions: Array<Permission>): void {
        this.RoleManagementService.populatePermissionGroups(typeOfDisplay, allPermissions);
    }

    /**
     Creates the role, if it is valid, and returns to the RoleManagement state
     */
    private onSubmit() {
        let roleCreate: any = angular.copy(this.role);

        // this.$log.debug("roleCreate.name: %s", JSON.stringify(roleCreate.name));
        // this.$log.debug("roleCreate.description: %s", JSON.stringify(roleCreate.description));
        // this.$log.debug("roleCreate.functionalArea: %s", JSON.stringify(roleCreate.functionalArea));
        // this.$log.debug("roleCreate isPermSelected(): %s", this.isPermSelected());


        if (!roleCreate.name || !roleCreate.description || !roleCreate.functionalArea || !this.isPermSelected()) {
            this.$log.debug("roleCreate - missing a required field");
        } else {

            // build Role's assignedPermissions to include any with either Allowed or Denied checked and set the correct allowed setting
            let selectedPermissions = this.getSelectedPerms();
            // this.$log.debug("selectedPermissions: %s", JSON.stringify(selectedPermissions));

            let assignedPermissions: any[] = [];
            angular.forEach(selectedPermissions, (perm) => {
                let assignedPermission: any = {
                    name: perm.name,
                    allowed: perm.allowed,
                    permission: this.retrievePermissionFromAllPermissions(perm.id)
                };
                assignedPermissions.push(assignedPermission);
            });
            // this.$log.debug("assignedPermissions: %s", JSON.stringify(assignedPermissions));

            // this.$log.debug("roleCreate.assignedPermissions: %s", JSON.stringify(roleCreate.assignedPermissions));
            roleCreate.assignedPermissions = assignedPermissions;
            // this.$log.debug("roleCreate.assignedPermissions: %s", JSON.stringify(roleCreate.assignedPermissions));

            roleCreate.id = null;
            // this.$log.debug("roleCreate: %s", JSON.stringify(roleCreate));

            this.createRole(roleCreate);
        }
    }

    /**
     Checks to see if a perm has been selected - either Allowed or Denied
     @returns true if a perm has been selected, else false
     */
    private isPermSelected(): boolean {
        //NOTE: can't break out of and angular.forEach()...

        let permCollections: PermCollection[] = [
            this.RoleManagementService.getAdminPermCollection(),
            this.RoleManagementService.getEquipmentPermCollection(),
            this.RoleManagementService.getOtherPermCollection()];

        for (let i = 0; i < permCollections.length; i++) {
            let permCollection: PermCollection = permCollections[i];

            let allPermOpts = permCollection.allPermOpts;
            for (let j = 0; j < allPermOpts.length; j++) {
                let permOpt = allPermOpts[j];
                if (permOpt.allowed || permOpt.denied) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     Checks each PermCollection in the given array of PermCollections to determine what permissions
     have been selected
     @returns - an array of ids for the selected permissions
     */
    private getSelectedPerms(): any[] {

        let permCollections: PermCollection[] = [
            this.RoleManagementService.getAdminPermCollection(),
            this.RoleManagementService.getEquipmentPermCollection(),
            this.RoleManagementService.getOtherPermCollection()];

        let selPerms: any[] = [];
        angular.forEach(permCollections, (permCollection: PermCollection) => {
            angular.forEach(permCollection.allPermOpts, (permOpt) => {
                if (permOpt.allowed || permOpt.denied) {
                    selPerms.push(permOpt);
                }
            });
        });

        return selPerms;
    }

    private retrievePermissionFromAllPermissions(permId: string): any {

        let returnValue = {};
        angular.forEach(this.allPermissions, (perm) => {
            if (permId === perm.id) {
                returnValue = perm;
            }
        });
        return returnValue;
    }

    public createRole(roleCreate) {
        // this.$log.debug("Creating roleCreate: %s", JSON.stringify(roleCreate));

        this.RoleService.createRole(roleCreate).then((response: IHttpPromiseCallbackArg<Role>) => {
            // this.$log.debug("%s - Create Role Returned: %s", this.controllerName, JSON.stringify(response.data));
            this.goToRoleManagement();
        }, (errResponse: IHttpPromiseCallbackArg<Role[]>) => {
            this.$log.error("Error creating role");
        });
    }

    /**
     Return to role management state
     */
    private goToRoleManagement(): void {
        // this.$log.debug("%s - Go to Role Management", this.controllerName);
        this.RoleManagementService.loadRoleTable();
        this.$state.go(this.StateConstants.ADMIN_ROLE_MNG);
    }
}