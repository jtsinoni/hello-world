'use strict';

import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {Role} from '../../../../_models/role.model';

export class RoleEditGenInfoController {
    public roleGeneralInfoChanged: boolean = false;

    private controllerName: string = "Role Edit General Information Controller";
    private role: Role = null;

    // @ngInject
    constructor(private $log, private RoleService, private RoleManagementService) {
        this.$log.debug("%s - Start", this.controllerName);
        this.role = RoleManagementService.getRole();
        //this.$log.debug(this.role);

        if (this.role === null) {
            //no Role, go back
            this.RoleManagementService.goToRoleView();
        } else {
            this.$log.debug("Selected Role: %s", JSON.stringify(this.role));
        }
    } 

    /**
     Updates the role general information and returns to the Role View state
     */
    public onSubmit() {
        let roleEditGenInfo: any = angular.copy(this.role);

        // this.$log.debug("this.role.name: %s", JSON.stringify(this.role.name));
        // this.$log.debug("this.role.description: %s", JSON.stringify(this.role.description));
        // this.$log.debug("this.role.functionalArea: %s", JSON.stringify(this.role.functionalArea));

        // Save button on GUI only gets enabled when all required data has values - so no need to check here
        this.saveRoleGeneralInfo();
        this.RoleManagementService.goToRoleView();
    }

    private saveRoleGeneralInfo() {
        this.roleGeneralInfoChanged = false;

        // this.$log.debug("Saving this.role: %s", JSON.stringify(this.role));

        this.RoleService.saveRoleData(this.role).then((response: IHttpPromiseCallbackArg<Role>) => {
            this.role = response.data;
            // this.$log.debug("%s - Saved Role Returned: %s", this.controllerName, JSON.stringify(this.role));
            this.RoleManagementService.setRole(this.role);
            this.RoleManagementService.loadRoleTable();            
        }, (errResponse: IHttpPromiseCallbackArg<Role[]>) => {
            this.$log.error("Error saving role general information");            
        });
    }    
}