define(["require", "exports", './roleManagement.controller', "./roleCreate.controller", "./roleView.controller", "./roleEditGenInfo.controller", "./roleEditPerms.controller"], function (require, exports, roleManagement_controller_1, roleCreate_controller_1, roleView_controller_1, roleEditGenInfo_controller_1, roleEditPerms_controller_1) {
    'use strict';
    var controllersModule = angular.module('Dmles.Admin.RoleManagement.Views.Module', []);
    controllersModule.controller('Dmles.Admin.RoleManagement.Views.RoleManagementController', roleManagement_controller_1.RoleManagementController);
    controllersModule.controller('Dmles.Admin.RoleManagement.Views.RoleCreateController', roleCreate_controller_1.RoleCreateController);
    controllersModule.controller('Dmles.Admin.RoleManagement.Views.RoleEditGenInfoController', roleEditGenInfo_controller_1.RoleEditGenInfoController);
    controllersModule.controller('Dmles.Admin.RoleManagement.Views.RoleEditPermsController', roleEditPerms_controller_1.RoleEditPermsController);
    controllersModule.controller('Dmles.Admin.RoleManagement.Views.RoleViewController', roleView_controller_1.RoleViewController);
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = controllersModule;
});
//# sourceMappingURL=module.js.map