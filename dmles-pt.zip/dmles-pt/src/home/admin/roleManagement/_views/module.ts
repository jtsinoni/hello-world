'use strict';


import {RoleManagementController} from './roleManagement.controller';
import {RoleCreateController} from "./roleCreate.controller";
import {RoleViewController} from "./roleView.controller";
import {RoleEditGenInfoController} from "./roleEditGenInfo.controller";
import {RoleEditPermsController} from "./roleEditPerms.controller";

let controllersModule = angular.module('Dmles.Admin.RoleManagement.Views.Module', []);
controllersModule.controller('Dmles.Admin.RoleManagement.Views.RoleManagementController', RoleManagementController);
controllersModule.controller('Dmles.Admin.RoleManagement.Views.RoleCreateController', RoleCreateController);
controllersModule.controller('Dmles.Admin.RoleManagement.Views.RoleEditGenInfoController', RoleEditGenInfoController);
controllersModule.controller('Dmles.Admin.RoleManagement.Views.RoleEditPermsController', RoleEditPermsController);
controllersModule.controller('Dmles.Admin.RoleManagement.Views.RoleViewController', RoleViewController);

export default controllersModule;

