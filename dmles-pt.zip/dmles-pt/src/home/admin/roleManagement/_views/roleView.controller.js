define(["require", "exports"], function (require, exports) {
    'use strict';
    var RoleViewController = (function () {
        // @ngInject
        function RoleViewController($log, $state, RoleManagementService, StateConstants) {
            this.$log = $log;
            this.$state = $state;
            this.RoleManagementService = RoleManagementService;
            this.StateConstants = StateConstants;
            this.controllerName = "Role View Controller";
            this.role = null;
            this.$log.debug("%s - Start", this.controllerName);
            this.role = RoleManagementService.getRole();
            if (this.role === null) {
                //no Role, go back
                this.goToRoleManagement();
            }
            else {
                this.$log.debug("Selected Role: %s", JSON.stringify(this.role));
                this.initializePermissions();
            }
        }
        /**
         Initialize the permissions
         */
        RoleViewController.prototype.initializePermissions = function () {
            // Loop through the role's assignedPermissions and create updatedAssignedPermissions that
            // include both allowed and denied Booleans - for internal use in GUI
            var updatedAssignedPermissions = [];
            angular.forEach(this.role.assignedPermissions, function (perm) {
                var opt = {
                    "id": perm.id,
                    "name": perm.name,
                    "description": perm.permission.description,
                    "functionalArea": perm.permission.functionalArea,
                    "allowed": perm.allowed,
                    "denied": !perm.allowed,
                    "permission": perm.permission
                };
                updatedAssignedPermissions.push(opt);
            });
            // this.$log.debug("updatedAssignedPermissions: %s", JSON.stringify(updatedAssignedPermissions));
            this.buildDisplayedPermissionCollections("VIEW", updatedAssignedPermissions);
        };
        RoleViewController.prototype.buildDisplayedPermissionCollections = function (typeOfDisplay, updatedAssignedPermissions) {
            this.RoleManagementService.populatePermissionGroups(typeOfDisplay, updatedAssignedPermissions);
        };
        /**
         Return to role management state
         */
        RoleViewController.prototype.goToRoleManagement = function () {
            // this.$log.debug("%s - Go to Role Management", this.controllerName);
            this.$state.go(this.StateConstants.ADMIN_ROLE_MNG);
        };
        /**
         Go to Edit Role General Information page - called from html
         */
        RoleViewController.prototype.goToEditRoleGeneralInfo = function () {
            // this.$log.debug("%s - Go to Edit Role General Information", this.controllerName);
            this.$state.go(this.StateConstants.ADMIN_ROLE_EDIT_GEN_INFO);
        };
        /**
         Go to Edit Role Permissions page - called from html
         */
        RoleViewController.prototype.goToEditRolePermissions = function () {
            // this.$log.debug("%s - Go to Edit Role Permissions", this.controllerName);
            this.$state.go(this.StateConstants.ADMIN_ROLE_EDIT_PERMS);
        };
        return RoleViewController;
    }());
    exports.RoleViewController = RoleViewController;
});
//# sourceMappingURL=roleView.controller.js.map