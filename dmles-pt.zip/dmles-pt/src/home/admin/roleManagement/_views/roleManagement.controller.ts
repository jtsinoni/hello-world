import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
'use strict';

import {Role} from '../../../../_models/role.model';

export class RoleManagementController {
    private controllerName: string = "Role Management Controller";

    public roleFilter: String = "";
    public selectedRole: Role = null;
    public roleToUpdate: Role = null;
    public roleDetailsShowUpdate: Boolean = false;
    public isModalOpen:boolean = false;

    // @ngInject
    constructor(private $log, private $state, private RoleService, private RoleManagementService,
                private StateConstants, private NotificationService) {
        this.$log.debug("%s - Start", this.controllerName);
        this.init();
    }

    private init() {
        this.RoleManagementService.loadRoleTable();
    }

    public roleManagementFilter() {
        this.RoleManagementService.rolesNgTable.filter({$: this.roleFilter});
        this.RoleManagementService.rolesNgTable.reload();
    }

    public goToRoleManagement() {
        //this.$log.debug("%s - Go to Role Management", this.controllerName);
        this.$state.go(this.StateConstants.ADMIN_ROLE_MNG);
    }

    public goToRoleView(role) {
        this.RoleManagementService.setRole(angular.copy(role));

        //this.$log.debug("%s - Go to Role View", this.controllerName);
        this.$state.go(this.StateConstants.ADMIN_ROLE_VIEW);
    }

    public goToRoleCreate() {
        this.RoleManagementService.clearRole();

        //this.$log.debug("%s - Go to Role Create", this.controllerName);
        this.$state.go(this.StateConstants.ADMIN_ROLE_CREATE);
    }

    public getModalContent1() {
        if (this.roleToUpdate) {
            return "Please confirm that you want to disable: " + this.roleToUpdate.name + ".";
        } else {
            return "";
        }
    }

    public setAllowed(role) {
        this.$log.debug("setAllowed: %s", JSON.stringify(role));
        this.roleToUpdate = angular.copy(role);
        this.isModalOpen = true;
    }

    public updateRole() {
        return this.RoleService.toggleRoleEnabled(this.roleToUpdate.id).then((response: IHttpPromiseCallbackArg<Role>) => {
            this.isModalOpen = false;
            this.init();
            return true;
        }, (errResponse: IHttpPromiseCallbackArg<Role[]>) => {
            this.isModalOpen = false;
            let msg = "Error disabling role " + this.roleToUpdate.name;
            this.$log.error(msg);
            this.NotificationService.errorMsg(this.roleToUpdate.name);
            return false;
        })
    }
}

