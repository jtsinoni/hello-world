import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
'use strict';

import {Role} from '../../../../_models/role.model';

export class RoleManagementController {
    private controllerName: string = "Role Management Controller";

    public roleFilter: String = "";
    public selectedRole: Role = null;
    public roleToDelete: Role = null;
    public roleDetailsShowUpdate: Boolean = false;

    // @ngInject
    constructor(private $log, private $state, private RoleService, private RoleManagementService, private StateConstants) {
        this.$log.debug("%s - Start", this.controllerName);
        this.init();
    }

    private init() {
        this.RoleManagementService.loadRoleTable();
    }

    public roleManagementFilter() {
        this.RoleManagementService.rolesNgTable.filter({$: this.roleFilter});
        this.RoleManagementService.rolesNgTable.reload();
    }

    public goToRoleManagement() {
        //this.$log.debug("%s - Go to Role Management", this.controllerName);
        this.$state.go(this.StateConstants.ADMIN_ROLE_MNG);
    }

    public goToRoleView(role) {
        this.RoleManagementService.setRole(angular.copy(role));

        //this.$log.debug("%s - Go to Role View", this.controllerName);
        this.$state.go(this.StateConstants.ADMIN_ROLE_VIEW);
    }

    public goToRoleCreate() {
        this.RoleManagementService.clearRole();

        //this.$log.debug("%s - Go to Role Create", this.controllerName);
        this.$state.go(this.StateConstants.ADMIN_ROLE_CREATE);
    }

    public setRoleToBeDeleted(role) {
        this.$log.debug("setRoleToBeDeleted: %s", JSON.stringify(role));
        this.roleToDelete = angular.copy(role);
    }

    public deleteRole() {
        // this.$log.debug("Deleting role: %s", JSON.stringify(this.roleToDelete));

        this.RoleService.deleteRole(this.roleToDelete.id).then((response: IHttpPromiseCallbackArg<Role>) => {
            // this.$log.debug("%s - Delete Role Returned: %s", this.controllerName, JSON.stringify(response.data));
            this.init();
        }, (errResponse: IHttpPromiseCallbackArg<Role[]>) => {
            this.$log.error("Error deleting role");
        });
    }
}

