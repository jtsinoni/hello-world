'use strict';

import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {AssignedPermission} from "../../../../_models/assignedPermission.model";
import {PermCollection} from "../_services/roleManagement.service";
import {Role} from "../../../../_models/role.model";
import {Permission} from "../../../../_models/permission.model";

export class RoleEditPermsController {
    private controllerName: string = "Role Edit Permissions Controller";
    private role: Role = null;

    private allPermissions: Permission[] = [];
    private updatedAllPermissions: Permission[] = [];
    private updatedAssignedPermissions: AssignedPermission[] = [];

    // @ngInject
    constructor(private $log, private RoleService, private RoleManagementService) {
        this.$log.debug("%s - Start", this.controllerName);
        this.role = RoleManagementService.getRole();

        if (this.role === null) {
            //no Role, go back
            this.RoleManagementService.goToRoleView();
        } else {
            this.$log.debug("Selected Role: %s", JSON.stringify(this.role));
            this.initializePermissions();
        }
    }
   
    private initializePermissions(): void {

        // The database just keeps allowed status for an assigned permission - this.role.assignedPermissions
        // The GUI code will contain and track allowed and denied both - this.updatedAssignedPermissions        
        // By definition a Role's "assigned permission" must be either allowed or denied - never neither or both
        angular.forEach(this.role.assignedPermissions, (perm) => {
            let opt: any = {
                "id": perm.id,
                "name": perm.name,
                "allowed": perm.allowed,
                "denied": !perm.allowed
            };
            this.updatedAssignedPermissions.push(opt);
        });
        // this.$log.debug("this.updatedAssignedPermissions: %s", JSON.stringify(this.updatedAssignedPermissions));

        this.getAllPermissionsAndBuildPermissionCollections();
    }

    private getAllPermissionsAndBuildPermissionCollections() {
        this.RoleService.getAllPermissions().then((response: IHttpPromiseCallbackArg<Permission[]>) => {
            // this.$log.debug("%s - Permissions Returned: %s", this.controllerName, JSON.stringify(response.data));

            // permissions come in using hierarchical structure (per TS)
            // we actually want them sans the hierarchical structure - so convert - resulting in this.allPermissions
            angular.forEach(response.data, (element: any) => {
                angular.forEach(element.permissions, (permission) => {
                    this.allPermissions.push(permission);
                });
            });
            // this.$log.debug("this.allPermissions: %s", JSON.stringify(this.allPermissions));

            // update the retrieved list of all permissions with the correct
            // allowed and denied settings - updatedAllPermissions - for display on Edit Permissions page
            angular.forEach(this.allPermissions, (perm) => {
                let opt: any = {
                    "id": perm.id,
                    "name": perm.name,
                    "description": perm.description,
                    "functionalArea": perm.functionalArea,
                    "allowed": this.retrieveFieldValueFromAssignedPermissions(perm.name, "allowed"),
                    "denied": this.retrieveFieldValueFromAssignedPermissions(perm.name, "denied"),
                    "active": perm.active
                };
                this.updatedAllPermissions.push(opt);
            });

            // List of all permissions with the correct allowed and denied settings for the selected Role
            // this.$log.debug("this.updatedAllPermissions: %s", JSON.stringify(this.updatedAllPermissions));

            this.buildDisplayedPermissionCollections("EDIT", this.updatedAllPermissions);

        }, (errResponse: IHttpPromiseCallbackArg<Permission[]>) => {
            this.$log.error("Error retrieving All Permissions");
        });
    }

    private buildDisplayedPermissionCollections(typeOfDisplay: string, updatedAllPermissions: Array<Permission>): void {
        this.RoleManagementService.populatePermissionGroups(typeOfDisplay, updatedAllPermissions);
    }

    private retrieveFieldValueFromAssignedPermissions(field: string, fieldValue: string): boolean {

        let returnValue = false;
        angular.forEach(this.updatedAssignedPermissions, (perm) => {
            if (field === perm.name) {
                returnValue = perm[fieldValue];
            }
        });
        return returnValue;
    }

    /**
     Updates the role, if it is valid, and returns to the RoleManagement state
     */
    private onSubmit() {
        // this.$log.debug("this.RoleManagementService.getAdminPermCollection(): %s", JSON.stringify(this.RoleManagementService.getAdminPermCollection()));
        // this.$log.debug("this.RoleManagementService.getEquipmentPermCollection(): %s", JSON.stringify(this.RoleManagementService.getEquipmentPermCollection()));
        // this.$log.debug("this.RoleManagementService.getOtherPermCollection(): %s", JSON.stringify(this.RoleManagementService.getOtherPermCollection()));

        // build Role's assignedPermissions to include any with either Allowed or Denied checked and set the correct allowed setting
        let selectedPermissions = this.getSelectedPerms();
        // this.$log.debug("selectedPermissions: %s", JSON.stringify(selectedPermissions));

        let assignedPermissions: any[] = [];
        angular.forEach(selectedPermissions, (perm) => {
            let assignedPermission: any = {
                name: perm.name,
                allowed: perm.allowed, // if Allowed checked - true; if Deny checked - false
                permission: this.retrievePermissionFromAllPermissions(perm.id)
            };
            assignedPermissions.push(assignedPermission);
        });
        // this.$log.debug("assignedPermissions: %s", JSON.stringify(assignedPermissions));

        // this.$log.debug("this.role.assignedPermissions: %s", JSON.stringify(this.role.assignedPermissions));
        this.role.assignedPermissions = assignedPermissions;
        // this.$log.debug("this.role.assignedPermissions: %s", JSON.stringify(this.role.assignedPermissions));

        this.saveRolePermissions();
        this.RoleManagementService.goToRoleView();
    }

    /**
     Checks each PermCollection in the given array of PermCollections to determine what permissions
     have been selected
     @returns - an array of ids for the selected permissions
     */
    private getSelectedPerms(): any[] {

        let permCollections: PermCollection[] = this.RoleManagementService.getPermissionCollections();

        let selPerms: any[] = [];
        angular.forEach(permCollections, (permCollection: PermCollection) => {
            angular.forEach(permCollection.allPermOpts, (permOpt) => {
                if (permOpt.allowed || permOpt.denied) {
                    selPerms.push(permOpt);
                }
            });
        });

        return selPerms;
    }

    private retrievePermissionFromAllPermissions(permId: string): any {
        let returnValue = {};
        angular.forEach(this.allPermissions, (perm) => {
            if (permId === perm.id) {
                returnValue = perm;
            }
        });
        return returnValue;
    }

    public saveRolePermissions() {
        // this.$log.debug("Saving this.role: %s", JSON.stringify(this.role));

        this.RoleService.saveRolePermissions(this.role).then((response: IHttpPromiseCallbackArg<Role>) => {
            // this.$log.debug("%s - Saved Role Returned: %s", this.controllerName, JSON.stringify(response.data));
            this.RoleManagementService.setRole(response.data);
            this.RoleManagementService.loadRoleTable();            
        }, (errResponse: IHttpPromiseCallbackArg<Role[]>) => {
            this.$log.error("Error saving role permissions");
        });
    }
}