define(["require", "exports"], function (require, exports) {
    'use strict';
    var RoleCreateController = (function () {
        // @ngInject
        function RoleCreateController($log, $state, RoleService, RoleManagementService, StateConstants) {
            this.$log = $log;
            this.$state = $state;
            this.RoleService = RoleService;
            this.RoleManagementService = RoleManagementService;
            this.StateConstants = StateConstants;
            this.controllerName = "Role Create Controller";
            this.role = null;
            this.allPermissions = [];
            this.$log.debug("%s - Start", this.controllerName);
            this.role = RoleManagementService.getRole();
            //this.$log.debug(this.role);
            if (this.role === null) {
                //no Role, go back
                this.goToRoleManagement();
            }
            else {
                this.$log.debug("new Role: %s", JSON.stringify(this.role));
                this.init();
            }
        }
        RoleCreateController.prototype.init = function () {
            this.getAllPermissionsAndBuildPermissionCollections();
        };
        RoleCreateController.prototype.getAllPermissionsAndBuildPermissionCollections = function () {
            var _this = this;
            this.RoleService.getAllPermissions().then(function (response) {
                // this.$log.debug("%s - Permissions Returned: %s", this.controllerName, JSON.stringify(response.data));
                // permissions come in using hierarchical structure (per TS)
                // we actually want them sans the hierarchical structure - so convert
                angular.forEach(response.data, function (element) {
                    angular.forEach(element.permissions, function (permission) {
                        _this.allPermissions.push(permission);
                    });
                });
                // this.$log.debug("this.allPermissions: %s", JSON.stringify(this.allPermissions));
                _this.buildDisplayedPermissionCollections("CREATE", _this.allPermissions);
            }, function (errResponse) {
                _this.$log.error("Error retrieving All Permissions");
            });
        };
        RoleCreateController.prototype.buildDisplayedPermissionCollections = function (typeOfDisplay, allPermissions) {
            this.RoleManagementService.populatePermissionGroups(typeOfDisplay, allPermissions);
        };
        /**
         Creates the role, if it is valid, and returns to the RoleManagement state
         */
        RoleCreateController.prototype.onSubmit = function () {
            var _this = this;
            var roleCreate = angular.copy(this.role);
            // this.$log.debug("roleCreate.name: %s", JSON.stringify(roleCreate.name));
            // this.$log.debug("roleCreate.description: %s", JSON.stringify(roleCreate.description));
            // this.$log.debug("roleCreate.functionalArea: %s", JSON.stringify(roleCreate.functionalArea));
            // this.$log.debug("roleCreate isPermSelected(): %s", this.isPermSelected());
            if (!roleCreate.name || !roleCreate.description || !roleCreate.functionalArea || !this.isPermSelected()) {
                this.$log.debug("roleCreate - missing a required field");
            }
            else {
                // build Role's assignedPermissions to include any with either Allowed or Denied checked and set the correct allowed setting
                var selectedPermissions = this.getSelectedPerms();
                // this.$log.debug("selectedPermissions: %s", JSON.stringify(selectedPermissions));
                var assignedPermissions_1 = [];
                angular.forEach(selectedPermissions, function (perm) {
                    var assignedPermission = {
                        name: perm.name,
                        allowed: perm.allowed,
                        permission: _this.retrievePermissionFromAllPermissions(perm.id)
                    };
                    assignedPermissions_1.push(assignedPermission);
                });
                // this.$log.debug("assignedPermissions: %s", JSON.stringify(assignedPermissions));
                // this.$log.debug("roleCreate.assignedPermissions: %s", JSON.stringify(roleCreate.assignedPermissions));
                roleCreate.assignedPermissions = assignedPermissions_1;
                // this.$log.debug("roleCreate.assignedPermissions: %s", JSON.stringify(roleCreate.assignedPermissions));
                roleCreate.id = null;
                // this.$log.debug("roleCreate: %s", JSON.stringify(roleCreate));
                this.createRole(roleCreate);
            }
        };
        /**
         Checks to see if a perm has been selected - either Allowed or Denied
         @returns true if a perm has been selected, else false
         */
        RoleCreateController.prototype.isPermSelected = function () {
            //NOTE: can't break out of and angular.forEach()...
            var permCollections = [
                this.RoleManagementService.getAdminPermCollection(),
                this.RoleManagementService.getEquipmentPermCollection(),
                this.RoleManagementService.getOtherPermCollection()];
            for (var i = 0; i < permCollections.length; i++) {
                var permCollection = permCollections[i];
                var allPermOpts = permCollection.allPermOpts;
                for (var j = 0; j < allPermOpts.length; j++) {
                    var permOpt = allPermOpts[j];
                    if (permOpt.allowed || permOpt.denied) {
                        return true;
                    }
                }
            }
            return false;
        };
        /**
         Checks each PermCollection in the given array of PermCollections to determine what permissions
         have been selected
         @returns - an array of ids for the selected permissions
         */
        RoleCreateController.prototype.getSelectedPerms = function () {
            var permCollections = [
                this.RoleManagementService.getAdminPermCollection(),
                this.RoleManagementService.getEquipmentPermCollection(),
                this.RoleManagementService.getOtherPermCollection()];
            var selPerms = [];
            angular.forEach(permCollections, function (permCollection) {
                angular.forEach(permCollection.allPermOpts, function (permOpt) {
                    if (permOpt.allowed || permOpt.denied) {
                        selPerms.push(permOpt);
                    }
                });
            });
            return selPerms;
        };
        RoleCreateController.prototype.retrievePermissionFromAllPermissions = function (permId) {
            var returnValue = {};
            angular.forEach(this.allPermissions, function (perm) {
                if (permId === perm.id) {
                    returnValue = perm;
                }
            });
            return returnValue;
        };
        RoleCreateController.prototype.createRole = function (roleCreate) {
            // this.$log.debug("Creating roleCreate: %s", JSON.stringify(roleCreate));
            var _this = this;
            this.RoleService.createRole(roleCreate).then(function (response) {
                // this.$log.debug("%s - Create Role Returned: %s", this.controllerName, JSON.stringify(response.data));
                _this.goToRoleManagement();
            }, function (errResponse) {
                _this.$log.error("Error creating role");
            });
        };
        /**
         Return to role management state
         */
        RoleCreateController.prototype.goToRoleManagement = function () {
            // this.$log.debug("%s - Go to Role Management", this.controllerName);
            this.RoleManagementService.loadRoleTable();
            this.$state.go(this.StateConstants.ADMIN_ROLE_MNG);
        };
        return RoleCreateController;
    }());
    exports.RoleCreateController = RoleCreateController;
});
//# sourceMappingURL=roleCreate.controller.js.map