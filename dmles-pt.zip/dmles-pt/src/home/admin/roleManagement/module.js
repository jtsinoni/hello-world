define(["require", "exports", './router', './_directives/module', './_services/module', './_views/module'], function (require, exports, router_1, module_1, module_2, module_3) {
    'use strict';
    var module = angular.module('Dmles.Admin.RoleManagementModule', [
        module_1.default.name,
        module_2.default.name,
        module_3.default.name
    ]);
    module.config(router_1.default.factory);
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = module;
});
//# sourceMappingURL=module.js.map