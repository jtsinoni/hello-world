'use strict';

import router from './router';

import directivesModule from './_directives/module';
import servicesModule from './_services/module';
import controllersModule from './_views/module';

let module = angular.module('Dmles.Admin.RoleManagementModule', [
    directivesModule.name,
    servicesModule.name,
    controllersModule.name
]);

module.config(router.factory);

export default module;