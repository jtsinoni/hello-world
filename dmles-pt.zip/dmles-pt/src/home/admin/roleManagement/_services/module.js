define(["require", "exports", './roleManagement.service'], function (require, exports, roleManagement_service_1) {
    'use strict';
    var servicesModule = angular.module('Dmles.UserAdmin.RoleManagement.Services.Module', []);
    servicesModule.service('RoleManagementService', roleManagement_service_1.RoleManagementService);
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = servicesModule;
});
//# sourceMappingURL=module.js.map