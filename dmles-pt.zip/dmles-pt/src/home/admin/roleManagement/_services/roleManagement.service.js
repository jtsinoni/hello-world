define(["require", "exports", '../../../../_models/role.model'], function (require, exports, role_model_1) {
    'use strict';
    var RoleManagementService = (function () {
        // @ngInject
        function RoleManagementService($filter, $log, $state, datatableService, RoleService, StateConstants) {
            this.$filter = $filter;
            this.$log = $log;
            this.$state = $state;
            this.datatableService = datatableService;
            this.RoleService = RoleService;
            this.StateConstants = StateConstants;
            this.role = null;
            this.serviceName = "RoleManagement Service";
            this.roles = [];
            this.rolesNgTable = null;
            this.roleFunctionalAreaOptions = ["Administration", "Equipment_Request", "Other"];
            this.roleFunctionalAreaDisplayNameOptions = ["Admin", "Equipment", "Other"];
            this.permissionCollections = [];
            this.adminPermCollection = null;
            this.equipmentPermCollection = null;
            this.otherPermCollection = null;
            this.adminPermissionListCollapsed = true;
            this.equipmentPermissionListCollapsed = true;
            this.otherPermissionListCollapsed = true;
            this.$log.debug("%s - Start", this.serviceName);
        }
        RoleManagementService.prototype.getRole = function () {
            return this.role;
        };
        RoleManagementService.prototype.setRole = function (role) {
            this.role = role;
        };
        RoleManagementService.prototype.clearRole = function () {
            this.role = new role_model_1.Role();
        };
        RoleManagementService.prototype.loadRoleTable = function () {
            var _this = this;
            this.RoleService.getAllRoles().then(function (response) {
                _this.roles = response.data;
                // this.$log.debug("%s - Roles Returned: %s", this.controllerName, JSON.stringify(this.roles));
                _this.rolesNgTable = _this.datatableService.createNgTable(_this.roles, 25, { name: 'asc' });
                _this.rolesNgTable.reload();
            }, function (errResponse) {
                _this.$log.error("Error retrieving All Roles");
            });
        };
        RoleManagementService.prototype.goToRoleView = function () {
            // this.$log.debug("%s - Go to Role View", this.controllerName);
            this.$state.go(this.StateConstants.ADMIN_ROLE_VIEW);
        };
        RoleManagementService.prototype.getPermissionCollection = function (index) {
            return this.permissionCollections[index];
        };
        RoleManagementService.prototype.setPermissionCollection = function (permissionCollection, index) {
            this.permissionCollections[index] = permissionCollection;
        };
        RoleManagementService.prototype.getAdminPermCollection = function () {
            return this.adminPermCollection;
        };
        RoleManagementService.prototype.setAdminPermCollection = function (adminPermCollection) {
            this.adminPermCollection = adminPermCollection;
        };
        RoleManagementService.prototype.getEquipmentPermCollection = function () {
            return this.equipmentPermCollection;
        };
        RoleManagementService.prototype.setEquipmentPermCollection = function (equipmentPermCollection) {
            this.equipmentPermCollection = equipmentPermCollection;
        };
        RoleManagementService.prototype.getOtherPermCollection = function () {
            return this.otherPermCollection;
        };
        RoleManagementService.prototype.setOtherPermCollection = function (otherPermCollection) {
            this.otherPermCollection = otherPermCollection;
        };
        RoleManagementService.prototype.collapseAllPermissionLists = function () {
            this.adminPermissionListCollapsed = true;
            this.equipmentPermissionListCollapsed = true;
            this.otherPermissionListCollapsed = true;
        };
        RoleManagementService.prototype.expandAllPermissionLists = function () {
            this.adminPermissionListCollapsed = false;
            this.equipmentPermissionListCollapsed = false;
            this.otherPermissionListCollapsed = false;
        };
        RoleManagementService.prototype.clearPermissionGroups = function () {
            this.adminPermCollection = null;
            this.equipmentPermCollection = null;
            this.otherPermCollection = null;
        };
        /**
         Creates the PermCollection objects to be used in selection Role Permissions.
         */
        RoleManagementService.prototype.populatePermissionGroups = function (typeOfDisplay, allPermissions) {
            /*
             decide if we want to populate functionalAreas like this, or manually...
             Problem currently is setting the 'display name'...see below
    
             this.$log.debug("allPermissions: %s", JSON.stringify(allPermissions));
             let uniqueGroups = this.determineUniqueGroups(allPermissions);
             this.$log.debug("uniqueGroups: %s", JSON.stringify(uniqueGroups));
             angular.forEach(uniqueGroups, (functionalArea) => {
             let perms = this.$filter('filter')(allPermissions, {"functionalArea": functionalArea}, true);
             perms = this.$filter('orderBy')(perms, "name");
             this.$log.debug("perms: %s", JSON.stringify(perms));
             // could have functionalArea naming convention and determine display on that CAPS & Underscores
             // this.adminPermCollection = new DmlesUserAdmin.RoleManagement.Views.PermCollection(functionalArea, perms);
             });
             */
            var adminPerms = this.$filter('filter')(allPermissions, { "functionalArea": this.roleFunctionalAreaOptions[0] }, true);
            adminPerms = this.$filter('orderBy')(adminPerms, "name");
            var adminPermOpts = this.createDisplayedPermissionsForAGivenCollection(adminPerms, typeOfDisplay);
            this.setAdminPermCollection(new PermCollection(this.roleFunctionalAreaDisplayNameOptions[0], adminPermOpts));
            // this.$log.debug("this.getAdminPermCollection(): %s", JSON.stringify(this.getAdminPermCollection()));
            var equipPerms = this.$filter('filter')(allPermissions, { "functionalArea": this.roleFunctionalAreaOptions[1] }, true);
            equipPerms = this.$filter('orderBy')(equipPerms, "name");
            var equipPermOpts = this.createDisplayedPermissionsForAGivenCollection(equipPerms, typeOfDisplay);
            this.setEquipmentPermCollection(new PermCollection(this.roleFunctionalAreaDisplayNameOptions[1], equipPermOpts));
            // this.$log.debug("this.getEquipmentPermCollection(): %s", JSON.stringify(this.getEquipmentPermCollection()));
            var otherPerms = this.$filter('filter')(allPermissions, { "functionalArea": this.roleFunctionalAreaOptions[2] }, true);
            otherPerms = this.$filter('orderBy')(otherPerms, "name");
            var otherPermOpts = this.createDisplayedPermissionsForAGivenCollection(otherPerms, typeOfDisplay);
            this.setOtherPermCollection(new PermCollection(this.roleFunctionalAreaDisplayNameOptions[2], otherPermOpts));
            // this.$log.debug("this.getOtherPermCollection(): %s", JSON.stringify(this.getOtherPermCollection()));
        };
        /**
         decide to keep or remove, see comment in populatePermissionGroups()
         Determines the unique groups in a given array of Permission objects
         @returns - an array containing the unique groups
         */
        RoleManagementService.prototype.determineUniqueGroups = function (allPerms) {
            var retval = [];
            var allFunctionalAreas = allPerms.map(function (perm) {
                return perm.functionalArea;
            });
            allFunctionalAreas.sort();
            angular.forEach(allFunctionalAreas, function (functionalArea) {
                if (retval.indexOf(functionalArea) === -1) {
                    retval.push(functionalArea);
                }
            });
            return retval;
        };
        /**
         Creates an array of displayed Permissions from the given array of a collection's permissions.
         Displayed permissions will include the following three fields, suitable for use as a checkbox input:
         -- id
         -- name
         -- allowed
         -- denied
         @returns the created array of permissions to display for a given Permission Collection
         */
        RoleManagementService.prototype.createDisplayedPermissionsForAGivenCollection = function (filteredPermissionsBelongingToACollection, typeOfDisplay) {
            var displayedPermissionsForAGivenCollection = [];
            if (typeOfDisplay === "CREATE") {
                angular.forEach(filteredPermissionsBelongingToACollection, function (perm) {
                    var opt = {
                        "id": perm.id,
                        "name": perm.name,
                        "allowed": false,
                        "denied": false,
                        "active": perm.active,
                        "description": perm.description,
                        "functionalArea": perm.functionalArea,
                    };
                    displayedPermissionsForAGivenCollection.push(opt);
                });
            }
            else if (typeOfDisplay === "VIEW") {
                angular.forEach(filteredPermissionsBelongingToACollection, function (perm) {
                    var opt = {
                        "id": perm.id,
                        "name": perm.name,
                        "allowed": perm.allowed,
                        "denied": !perm.allowed,
                        "active": perm.active,
                        "description": perm.description,
                        "functionalArea": perm.functionalArea,
                    };
                    displayedPermissionsForAGivenCollection.push(opt);
                });
            }
            else if (typeOfDisplay === "EDIT") {
                angular.forEach(filteredPermissionsBelongingToACollection, function (perm) {
                    var opt = {
                        "id": perm.id,
                        "name": perm.name,
                        "allowed": perm.allowed,
                        "denied": perm.denied,
                        "active": perm.active,
                        "description": perm.description,
                        "functionalArea": perm.functionalArea,
                    };
                    displayedPermissionsForAGivenCollection.push(opt);
                });
            }
            return displayedPermissionsForAGivenCollection;
        };
        // used by HTML
        RoleManagementService.prototype.selectOnlyAllowOrDeny = function (perm, typeOfSelection) {
            // this.$log.debug("perm: %s", JSON.stringify(perm));
            // this.$log.debug("typeOfSelection: %s", JSON.stringify(typeOfSelection));
            if (typeOfSelection === "allowed") {
                if (perm.denied) {
                    perm.denied = false;
                }
            }
            else if (typeOfSelection === "denied") {
                if (perm.allowed) {
                    perm.allowed = false;
                }
            }
        };
        return RoleManagementService;
    }());
    exports.RoleManagementService = RoleManagementService;
    /**
     A class for creating Permission Collections to be used with the dmlesPermSelection directive.
     */
    var PermCollection = (function () {
        /**
         @param displayName the display name of the functionalArea to show
         @param allPermOpts an array of objects to be used to create the checkboxes
         */
        function PermCollection(displayName, allPermOpts) {
            this.allPermOpts = [];
            this.displayName = null;
            this.displayName = displayName;
            this.allPermOpts = allPermOpts;
            // Split permissions into functionalAreas
            // this.splitPermOpts(angular.copy(allPermOpts));
        }
        ;
        return PermCollection;
    }());
    exports.PermCollection = PermCollection;
});
//# sourceMappingURL=roleManagement.service.js.map