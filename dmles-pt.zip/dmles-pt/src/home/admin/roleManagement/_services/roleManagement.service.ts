'use strict';

import {Role} from '../../../../_models/role.model';
import {RoleFunctionalAreaConfig} from '../../../../_models/roleFunctionalAreaConfig.model';
import {AssignedPermission} from "../../../../_models/assignedPermission.model";
import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;

export interface IRoleManagementService {

}

export class RoleManagementService implements IRoleManagementService {
    private role: Role = null;
    private serviceName: String = "RoleManagement Service";

    public roles: Array<Role> = [];
    public rolesNgTable: any = null;

    private roleFunctionalAreas:Array<RoleFunctionalAreaConfig> = null;
    private roleFunctionalAreaNames:Array<string> = null;

    private permissionCollections: PermCollection[] = [];

    public adminPermissionListCollapsed: boolean = true;
    public equipmentPermissionListCollapsed: boolean = true;
    public otherPermissionListCollapsed: boolean = true;

    // @ngInject
    constructor(private $filter, private $log, private $state, private datatableService, private RoleService, private StateConstants) {
        this.$log.debug("%s - Start", this.serviceName);
        this.getRoleFunctionalAreaConfig();
        this.getRoleFunctionalAreaConfigsDisplayNames();
    }

    public getRole(): Role {
        return this.role;
    }

    public setRole(role: Role): void {
        this.role = role;
    }

    public clearRole() {
        this.role = new Role();
    }

    public getPermissionCollections() {
        return this.permissionCollections;
    }

    public getRoleFunctionalAreaConfigsDisplayNames() {
        if (!this.roleFunctionalAreaNames) {
            this.RoleService.getRoleFunctionalAreaConfigNames().then((response: IHttpPromiseCallbackArg<string[]>) => {
                this.roleFunctionalAreaNames = response.data;
            }, (errResponse: IHttpPromiseCallbackArg<RoleFunctionalAreaConfig[]>) => {
                this.$log.error("Error retrieving All RoleFunctionalAreaConfig");
            });
        }
    }

    public getRoleFunctionalAreaConfig() {
        if (!this.roleFunctionalAreas) {
            this.RoleService.getRoleFunctionalAreaConfig().then((response: IHttpPromiseCallbackArg<RoleFunctionalAreaConfig[]>) => {
                this.roleFunctionalAreas = response.data;
            }, (errResponse: IHttpPromiseCallbackArg<RoleFunctionalAreaConfig[]>) => {
                this.$log.error("Error retrieving All RoleFunctionalAreaConfig");
            });
        }
    }

    public loadRoleTable() {
        this.RoleService.getAllRoles().then((response: IHttpPromiseCallbackArg<Role[]>) => {
            this.roles = response.data;
            // this.$log.debug("%s - Roles Returned: %s", this.controllerName, JSON.stringify(this.roles));
            this.rolesNgTable = this.datatableService.createNgTable(this.roles, 25, {name: 'asc'});
            this.rolesNgTable.reload();
        }, (errResponse: IHttpPromiseCallbackArg<Role[]>) => {
            this.$log.error("Error retrieving All Roles");
        });
    }

    public goToRoleView(): void {
        // this.$log.debug("%s - Go to Role View", this.controllerName);
        this.$state.go(this.StateConstants.ADMIN_ROLE_VIEW);
    }

    public getPermissionCollection(index: number): PermCollection {
        return this.permissionCollections[index];
    }

    public setPermissionCollection(permissionCollection: PermCollection, index: number): void {
        this.permissionCollections[index] = permissionCollection;
    }

    public collapseAllPermissionLists(): void {
        this.adminPermissionListCollapsed = true;
        this.equipmentPermissionListCollapsed = true;
        this.otherPermissionListCollapsed = true;
    }

    public expandAllPermissionLists(): void {
        this.adminPermissionListCollapsed = false;
        this.equipmentPermissionListCollapsed = false;
        this.otherPermissionListCollapsed = false;
    }

    private clearPermissionGroups() {
        this.permissionCollections = [];
    }

    /**
     Creates the PermCollection objects to be used in selection Role Permissions.
     */
    private populatePermissionGroups(type:string, allPermissions: Array<AssignedPermission>) {

        this.clearPermissionGroups();
        angular.forEach(this.roleFunctionalAreas, (funcArea) => {
            let perms = this.$filter('filter')(allPermissions, {"functionalArea": funcArea.option}, true);
         perms = this.$filter('orderBy')(perms, "name");
            let opts = this.createDisplayedPermissionsForAGivenCollection(perms, type);
            let permc = new PermCollection(funcArea.displayName, opts);
            this.permissionCollections.push(permc);
        })
    }


    /**
     decide to keep or remove, see comment in populatePermissionGroups()
     Determines the unique groups in a given array of Permission objects
     @returns - an array containing the unique groups
     */
    private determineUniqueGroups(allPerms: any[]): any[] {
        let retval: any[] = [];
        let allFunctionalAreas: any[] = allPerms.map((perm) => {
            return perm.functionalArea;
        });

        allFunctionalAreas.sort();
        angular.forEach(allFunctionalAreas, (functionalArea) => {
            if (retval.indexOf(functionalArea) === -1) {
                retval.push(functionalArea);
            }
        });

        return retval;
    }


    /**
     Creates an array of displayed Permissions from the given array of a collection's permissions.
     Displayed permissions will include the following three fields, suitable for use as a checkbox input:
     -- id
     -- name
     -- allowed
     -- denied
     @returns the created array of permissions to display for a given Permission Collection
     */
    private createDisplayedPermissionsForAGivenCollection(filteredPermissionsBelongingToACollection: any[],
                                                          typeOfDisplay: string): any[] {

        let displayedPermissionsForAGivenCollection: any[] = [];

        if (typeOfDisplay === "CREATE") {
            angular.forEach(filteredPermissionsBelongingToACollection, (perm) => {
                let opt: any = {
                    "id": perm.id,
                    "name": perm.name,
                    "allowed": false,
                    "denied": false,
                    "active": perm.active,
                    "description": perm.description,
                    "functionalArea": perm.functionalArea,
                };

                displayedPermissionsForAGivenCollection.push(opt);
            });
        } else if (typeOfDisplay === "VIEW") {
            angular.forEach(filteredPermissionsBelongingToACollection, (perm) => {
                let opt: any = {
                    "id": perm.id,
                    "name": perm.name,
                    "allowed": perm.allowed,
                    "denied": !perm.allowed,
                    "active": perm.active,
                    "description": perm.description,
                    "functionalArea": perm.functionalArea,
                };

                displayedPermissionsForAGivenCollection.push(opt);
            });
        } else if (typeOfDisplay === "EDIT") {
            angular.forEach(filteredPermissionsBelongingToACollection, (perm) => {
                let opt: any = {
                    "id": perm.id,
                    "name": perm.name,
                    "allowed": perm.allowed,
                    "denied": perm.denied,
                    "active": perm.active,
                    "description": perm.description,
                    "functionalArea": perm.functionalArea,
                };

                displayedPermissionsForAGivenCollection.push(opt);
            });
        }

        return displayedPermissionsForAGivenCollection;
    }

    // used by HTML
    public selectOnlyAllowOrDeny(perm, typeOfSelection) {
        // this.$log.debug("perm: %s", JSON.stringify(perm));
        // this.$log.debug("typeOfSelection: %s", JSON.stringify(typeOfSelection));

        if (typeOfSelection === "allowed") {
            if (perm.denied) {
                perm.denied = false;
            }
        } else if (typeOfSelection === "denied") {
            if (perm.allowed) {
                perm.allowed = false;
            }
        }
    }
}

/**
 A class for creating Permission Collections to be used with the dmlesPermSelection directive.
 */
export class PermCollection {
    public allPermOpts: any[] = [];
    public displayName: string = null;

    /**
     @param displayName the display name of the functionalArea to show
     @param allPermOpts an array of objects to be used to create the checkboxes
     */
    constructor(displayName: string, allPermOpts: any[]) {
        this.displayName = displayName;
        this.allPermOpts = allPermOpts;

        // Split permissions into functionalAreas
        // this.splitPermOpts(angular.copy(allPermOpts));
    };
}