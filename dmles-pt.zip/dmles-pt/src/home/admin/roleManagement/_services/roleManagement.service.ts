'use strict';

import {Role} from '../../../../_models/role.model';
import {AssignedPermission} from "../../../../_models/assignedPermission.model";
import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;

export interface IRoleManagementService {

}

export class RoleManagementService implements IRoleManagementService {
    private role: Role = null;
    private serviceName: String = "RoleManagement Service";

    public roles: Array<Role> = [];
    public rolesNgTable: any = null;

    public roleFunctionalAreaOptions = ["Administration", "Equipment_Request", "Other"];
    public roleFunctionalAreaDisplayNameOptions = ["Admin", "Equipment", "Other"];

    private permissionCollections: PermCollection[] = [];

    private adminPermCollection: PermCollection = null;
    private equipmentPermCollection: PermCollection = null;
    private otherPermCollection: PermCollection = null;

    public adminPermissionListCollapsed: boolean = true;
    public equipmentPermissionListCollapsed: boolean = true;
    public otherPermissionListCollapsed: boolean = true;  

    // @ngInject
    constructor(private $filter, private $log, private $state, private datatableService, private RoleService, private StateConstants) {
        this.$log.debug("%s - Start", this.serviceName);
    }

    public getRole(): Role {
        return this.role;
    }

    public setRole(role: Role): void {
        this.role = role;
    }

    public clearRole() {
        this.role = new Role();
    }

    public loadRoleTable() {
        this.RoleService.getAllRoles().then((response: IHttpPromiseCallbackArg<Role[]>) => {
            this.roles = response.data;
            // this.$log.debug("%s - Roles Returned: %s", this.controllerName, JSON.stringify(this.roles));
            this.rolesNgTable = this.datatableService.createNgTable(this.roles, 25, {name: 'asc'});
            this.rolesNgTable.reload();
        }, (errResponse: IHttpPromiseCallbackArg<Role[]>) => {
            this.$log.error("Error retrieving All Roles");
        });
    }
    
    public goToRoleView(): void {
        // this.$log.debug("%s - Go to Role View", this.controllerName);
        this.$state.go(this.StateConstants.ADMIN_ROLE_VIEW);
    }

    public getPermissionCollection(index: number): PermCollection {
        return this.permissionCollections[index];
    }

    public setPermissionCollection(permissionCollection: PermCollection, index: number): void {
        this.permissionCollections[index] = permissionCollection;
    }
    
    public getAdminPermCollection(): PermCollection {
        return this.adminPermCollection;
    }

    public setAdminPermCollection(adminPermCollection: PermCollection): void {
        this.adminPermCollection = adminPermCollection;
    }

    public getEquipmentPermCollection(): PermCollection {
        return this.equipmentPermCollection;
    }

    public setEquipmentPermCollection(equipmentPermCollection: PermCollection): void {
        this.equipmentPermCollection = equipmentPermCollection;
    }

    public getOtherPermCollection(): PermCollection {
        return this.otherPermCollection;
    }

    public setOtherPermCollection(otherPermCollection: PermCollection): void {
        this.otherPermCollection = otherPermCollection;
    }

    public collapseAllPermissionLists(): void {
        this.adminPermissionListCollapsed = true;
        this.equipmentPermissionListCollapsed = true;
        this.otherPermissionListCollapsed = true;
    }

    public expandAllPermissionLists(): void {
        this.adminPermissionListCollapsed = false;
        this.equipmentPermissionListCollapsed = false;
        this.otherPermissionListCollapsed = false;
    }

    private clearPermissionGroups() {
        this.adminPermCollection = null;
        this.equipmentPermCollection = null;
        this.otherPermCollection = null;
    }

    /**
     Creates the PermCollection objects to be used in selection Role Permissions.
     */
    private populatePermissionGroups(typeOfDisplay: string, allPermissions: Array<AssignedPermission>) {
        /*
         decide if we want to populate functionalAreas like this, or manually...
         Problem currently is setting the 'display name'...see below

         this.$log.debug("allPermissions: %s", JSON.stringify(allPermissions));
         let uniqueGroups = this.determineUniqueGroups(allPermissions);
         this.$log.debug("uniqueGroups: %s", JSON.stringify(uniqueGroups));
         angular.forEach(uniqueGroups, (functionalArea) => {
         let perms = this.$filter('filter')(allPermissions, {"functionalArea": functionalArea}, true);
         perms = this.$filter('orderBy')(perms, "name");
         this.$log.debug("perms: %s", JSON.stringify(perms));
         // could have functionalArea naming convention and determine display on that CAPS & Underscores
         // this.adminPermCollection = new DmlesUserAdmin.RoleManagement.Views.PermCollection(functionalArea, perms);
         });
         */

        let adminPerms = this.$filter('filter')(allPermissions, {"functionalArea": this.roleFunctionalAreaOptions[0]}, true);
        adminPerms = this.$filter('orderBy')(adminPerms, "name");
        let adminPermOpts = this.createDisplayedPermissionsForAGivenCollection(adminPerms, typeOfDisplay);
        this.setAdminPermCollection(new PermCollection(this.roleFunctionalAreaDisplayNameOptions[0], adminPermOpts));
        // this.$log.debug("this.getAdminPermCollection(): %s", JSON.stringify(this.getAdminPermCollection()));

        let equipPerms = this.$filter('filter')(allPermissions, {"functionalArea": this.roleFunctionalAreaOptions[1]}, true);
        equipPerms = this.$filter('orderBy')(equipPerms, "name");
        let equipPermOpts = this.createDisplayedPermissionsForAGivenCollection(equipPerms, typeOfDisplay);
        this.setEquipmentPermCollection(new PermCollection(this.roleFunctionalAreaDisplayNameOptions[1], equipPermOpts));
        // this.$log.debug("this.getEquipmentPermCollection(): %s", JSON.stringify(this.getEquipmentPermCollection()));

        let otherPerms = this.$filter('filter')(allPermissions, {"functionalArea": this.roleFunctionalAreaOptions[2]}, true);
        otherPerms = this.$filter('orderBy')(otherPerms, "name");
        let otherPermOpts = this.createDisplayedPermissionsForAGivenCollection(otherPerms, typeOfDisplay);
        this.setOtherPermCollection(new PermCollection(this.roleFunctionalAreaDisplayNameOptions[2], otherPermOpts));
        // this.$log.debug("this.getOtherPermCollection(): %s", JSON.stringify(this.getOtherPermCollection()));
    }


    /**
     decide to keep or remove, see comment in populatePermissionGroups()
     Determines the unique groups in a given array of Permission objects
     @returns - an array containing the unique groups
     */
    private determineUniqueGroups(allPerms: any[]): any[] {
        let retval: any[] = [];
        let allFunctionalAreas: any[] = allPerms.map((perm) => {
            return perm.functionalArea;
        });

        allFunctionalAreas.sort();
        angular.forEach(allFunctionalAreas, (functionalArea) => {
            if (retval.indexOf(functionalArea) === -1) {
                retval.push(functionalArea);
            }
        });

        return retval;
    }


    /**
     Creates an array of displayed Permissions from the given array of a collection's permissions.
     Displayed permissions will include the following three fields, suitable for use as a checkbox input:
     -- id
     -- name
     -- allowed
     -- denied
     @returns the created array of permissions to display for a given Permission Collection
     */
    private createDisplayedPermissionsForAGivenCollection(filteredPermissionsBelongingToACollection: any[],
                                                          typeOfDisplay: string): any[] {

        let displayedPermissionsForAGivenCollection: any[] = [];

        if (typeOfDisplay === "CREATE") {
            angular.forEach(filteredPermissionsBelongingToACollection, (perm) => {
                let opt: any = {
                    "id": perm.id,
                    "name": perm.name,
                    "allowed": false,
                    "denied": false,
                    "active": perm.active,
                    "description": perm.description,
                    "functionalArea": perm.functionalArea,
                };

                displayedPermissionsForAGivenCollection.push(opt);
            });
        } else if (typeOfDisplay === "VIEW") {
            angular.forEach(filteredPermissionsBelongingToACollection, (perm) => {
                let opt: any = {
                    "id": perm.id,
                    "name": perm.name,
                    "allowed": perm.allowed,
                    "denied": !perm.allowed,
                    "active": perm.active,
                    "description": perm.description,
                    "functionalArea": perm.functionalArea,
                };

                displayedPermissionsForAGivenCollection.push(opt);
            });
        } else if (typeOfDisplay === "EDIT") {
            angular.forEach(filteredPermissionsBelongingToACollection, (perm) => {
                let opt: any = {
                    "id": perm.id,
                    "name": perm.name,
                    "allowed": perm.allowed,
                    "denied": perm.denied,
                    "active": perm.active,
                    "description": perm.description,
                    "functionalArea": perm.functionalArea,
                };

                displayedPermissionsForAGivenCollection.push(opt);
            });
        }

        return displayedPermissionsForAGivenCollection;
    }

    // used by HTML
    public selectOnlyAllowOrDeny(perm, typeOfSelection) {
        // this.$log.debug("perm: %s", JSON.stringify(perm));
        // this.$log.debug("typeOfSelection: %s", JSON.stringify(typeOfSelection));

        if (typeOfSelection === "allowed") {
            if (perm.denied) {
                perm.denied = false;
            }
        } else if (typeOfSelection === "denied") {
            if (perm.allowed) {
                perm.allowed = false;
            }
        }
    }
}

/**
 A class for creating Permission Collections to be used with the dmlesPermSelection directive.
 */
export class PermCollection {
    public allPermOpts: any[] = [];
    public displayName: string = null;

    /**
     @param displayName the display name of the functionalArea to show
     @param allPermOpts an array of objects to be used to create the checkboxes
     */
    constructor(displayName: string, allPermOpts: any[]) {
        this.displayName = displayName;
        this.allPermOpts = allPermOpts;

        // Split permissions into functionalAreas
        // this.splitPermOpts(angular.copy(allPermOpts));
    };
}