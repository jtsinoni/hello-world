'use strict';

import {RoleManagementService} from './roleManagement.service';


let servicesModule = angular.module('Dmles.UserAdmin.RoleManagement.Services.Module', []);
servicesModule.service('RoleManagementService', RoleManagementService);


export default servicesModule;

