'use strict';

import {AdminShellController} from './adminShell.controller';
import router from './router';

import permissionManagementModule from './permissionManagement/module';
import roleManagementModule from './roleManagement/module';
import userProfileManagementModule from './userProfileManagement/module';

let module = angular.module('Dmles.AdminModule', [
    permissionManagementModule.name,
    roleManagementModule.name,   
    userProfileManagementModule.name    
]);

module.controller('Dmles.Admin.AdminShellController', AdminShellController);

module.config(router.factory);

export default module;