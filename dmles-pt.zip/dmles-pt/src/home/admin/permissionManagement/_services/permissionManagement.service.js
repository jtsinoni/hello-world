define(["require", "exports", "../../../../_models/permissionDetailed.model"], function (require, exports, permissionDetailed_model_1) {
    'use strict';
    var PermissionManagementService = (function () {
        // @ngInject
        function PermissionManagementService($log, $state, datatableService, RoleService, StateConstants, UtilService) {
            this.$log = $log;
            this.$state = $state;
            this.datatableService = datatableService;
            this.RoleService = RoleService;
            this.StateConstants = StateConstants;
            this.UtilService = UtilService;
            this.permission = null;
            this.serviceName = "Permission Management Service";
            this.permissionsNgTable = null;
            this.permissionFunctionalAreaOptions = ["Administration", "Equipment_Request", "Other"];
            this.allElements = [];
            this.elementOpts = [];
            this.elementOptsGroup1 = [];
            this.elementOptsGroup2 = [];
            this.elementOptsGroup3 = [];
            this.allStates = [];
            this.stateOpts = [];
            this.stateOptsGroup1 = [];
            this.stateOptsGroup2 = [];
            this.stateOptsGroup3 = [];
            this.allEndpoints = [];
            this.endpointOpts = [];
            this.endpointOptsGroup1 = [];
            this.endpointOptsGroup2 = [];
            this.endpointOptsGroup3 = [];
            // this.$log.debug("%s - Start", this.serviceName);
        }
        PermissionManagementService.prototype.getPermission = function () {
            return this.permission;
        };
        PermissionManagementService.prototype.setPermission = function (permission) {
            this.permission = permission;
        };
        PermissionManagementService.prototype.clearPermission = function () {
            this.permission = new permissionDetailed_model_1.PermissionDetailed();
        };
        PermissionManagementService.prototype.loadPermissionsTable = function () {
            var _this = this;
            this.RoleService.getAllPermissionsDetailed().then(function (response) {
                // this.$log.debug("%s - PermissionsDetailed Returned: %s", this.serviceName, JSON.stringify(response.data));
                _this.permissionsNgTable = _this.datatableService.createNgTable(response.data, 25, { name: 'asc' });
                _this.permissionsNgTable.reload();
            }, function (errResponse) {
                _this.$log.error("Error retrieving AllPermissionsDetailed");
                //TODO show some sort of message to the user.
            });
        };
        PermissionManagementService.prototype.getAllElements = function () {
            var _this = this;
            this.initializeElementArrays();
            this.RoleService.getAllElements().then(function (response) {
                // this.$log.debug("%s - Elements Returned: %s", this.serviceName, JSON.stringify(response.data));
                _this.allElements = response.data;
                _this.UtilService.sortResults(_this.allElements, "name", true);
                // this.$log.debug("this.allElements: %s", JSON.stringify(this.allElements));
                // this.$log.debug("this.permission.elements: %s", JSON.stringify(this.permission.elements));
                //populate checkbox
                for (var i in _this.allElements) {
                    var element = _this.allElements[i];
                    var selected = false;
                    //pre-select Permission elements
                    for (var j in _this.permission.elements) {
                        var permissionElement = _this.permission.elements[j];
                        if (element.id === permissionElement.id) {
                            selected = true;
                        }
                    }
                    _this.elementOpts.push({
                        "id": element.id,
                        "name": element.name,
                        "selected": selected
                    });
                }
                // this.$log.debug("this.elementOpts: %s", JSON.stringify(this.elementOpts));
                _this.splitElementOpts(_this.elementOpts);
            }, function (errResponse) {
                _this.$log.error("Error retrieving permission elements");
                //TODO show some sort of message to the user.
            });
        };
        PermissionManagementService.prototype.initializeElementArrays = function () {
            this.allElements = [];
            this.elementOpts = [];
            this.elementOptsGroup1 = [];
            this.elementOptsGroup2 = [];
            this.elementOptsGroup3 = [];
        };
        /**
         Splits the given array into three arrays to be displayed in three columns in the html.
    
         Note: If the array is cleanly divisable by three, then the array is split into 3 equal groups,
         if it is not then the array is split into 3 groups where 2 are the same size and the
         third has less, this is so it will display nicely in columns.
         */
        PermissionManagementService.prototype.splitElementOpts = function (allElementOpts) {
            var divNum = allElementOpts.length / 3;
            var modNum = allElementOpts.length % 3;
            if (modNum === 0) {
                this.elementOptsGroup1 = allElementOpts.splice(0, divNum);
                this.elementOptsGroup2 = allElementOpts.splice(0, divNum);
                this.elementOptsGroup3 = allElementOpts;
            }
            else {
                this.elementOptsGroup1 = allElementOpts.splice(0, divNum + 1);
                this.elementOptsGroup2 = allElementOpts.splice(0, divNum + 1);
                this.elementOptsGroup3 = allElementOpts;
            }
        };
        PermissionManagementService.prototype.savePermissionElements = function () {
            var _this = this;
            var permissionUpdate = angular.copy(this.permission);
            // this.$log.debug("permissionUpdate: %s", JSON.stringify(permissionUpdate));
            this.addElementsToPermission(permissionUpdate);
            // this.$log.debug("%s - Submitting Permission:", this.serviceName, permissionUpdate);
            this.RoleService.savePermissionElements(permissionUpdate).then(function (response) {
                // this.$log.debug("%s - Saved Permission Returned: %s", this.serviceName, JSON.stringify(response.data));
                _this.setPermission(response.data);
                _this.goToPermissionView();
                _this.loadPermissionsTable();
            }, function (errResponse) {
                _this.$log.error("Error updating permission elements");
                //TODO show some sort of message to the permission.
            });
        };
        PermissionManagementService.prototype.addElementsToPermission = function (permission) {
            // Add elements
            permission.elements = [];
            for (var r in this.elementOptsGroup1) {
                var elementOpt = this.elementOptsGroup1[r];
                if (elementOpt.selected === true) {
                    // Add element id to permission element array
                    permission.elements.push(this.retrieveElementFromAllElements(elementOpt.id));
                }
            }
            for (var r in this.elementOptsGroup2) {
                var elementOpt = this.elementOptsGroup2[r];
                if (elementOpt.selected === true) {
                    // Add element id to permission element array
                    permission.elements.push(this.retrieveElementFromAllElements(elementOpt.id));
                }
            }
            for (var r in this.elementOptsGroup3) {
                var elementOpt = this.elementOptsGroup3[r];
                if (elementOpt.selected === true) {
                    // Add element id to permission element array
                    permission.elements.push(this.retrieveElementFromAllElements(elementOpt.id));
                }
            }
        };
        PermissionManagementService.prototype.retrieveElementFromAllElements = function (elementId) {
            var returnValue = {};
            angular.forEach(this.allElements, function (element) {
                if (elementId === element.id) {
                    returnValue = element;
                }
            });
            return returnValue;
        };
        PermissionManagementService.prototype.getAllStates = function () {
            var _this = this;
            this.initializeStateArrays();
            this.RoleService.getAllStates().then(function (response) {
                // this.$log.debug("%s - States Returned: %s", this.serviceName, JSON.stringify(response.data));
                _this.allStates = response.data;
                _this.UtilService.sortResults(_this.allStates, "name", true);
                // this.$log.debug("this.allStates: %s", JSON.stringify(this.allStates));
                // this.$log.debug("this.permission.states: %s", JSON.stringify(this.permission.states));
                //populate checkbox
                for (var i in _this.allStates) {
                    var state = _this.allStates[i];
                    var selected = false;
                    //pre-select Permission states
                    for (var j in _this.permission.states) {
                        var permissionState = _this.permission.states[j];
                        if (state.id === permissionState.id) {
                            selected = true;
                        }
                    }
                    _this.stateOpts.push({
                        "id": state.id,
                        "name": state.name,
                        "selected": selected
                    });
                }
                // this.$log.debug("this.stateOpts: %s", JSON.stringify(this.stateOpts));
                _this.splitStateOpts(_this.stateOpts);
            }, function (errResponse) {
                _this.$log.error("Error retrieving permission states");
                //TODO show some sort of message to the user.
            });
        };
        PermissionManagementService.prototype.initializeStateArrays = function () {
            this.allStates = [];
            this.stateOpts = [];
            this.stateOptsGroup1 = [];
            this.stateOptsGroup2 = [];
            this.stateOptsGroup3 = [];
        };
        PermissionManagementService.prototype.splitStateOpts = function (allStateOpts) {
            var divNum = allStateOpts.length / 3;
            var modNum = allStateOpts.length % 3;
            if (modNum === 0) {
                this.stateOptsGroup1 = allStateOpts.splice(0, divNum);
                this.stateOptsGroup2 = allStateOpts.splice(0, divNum);
                this.stateOptsGroup3 = allStateOpts;
            }
            else {
                this.stateOptsGroup1 = allStateOpts.splice(0, divNum + 1);
                this.stateOptsGroup2 = allStateOpts.splice(0, divNum + 1);
                this.stateOptsGroup3 = allStateOpts;
            }
        };
        PermissionManagementService.prototype.savePermissionStates = function () {
            var _this = this;
            var permissionUpdate = angular.copy(this.permission);
            // this.$log.debug("permissionUpdate: %s", JSON.stringify(permissionUpdate));
            this.addStatesToPermission(permissionUpdate);
            // this.$log.debug("%s - Submitting Permission:", this.serviceName, permissionUpdate);
            this.RoleService.savePermissionStates(permissionUpdate).then(function (response) {
                // this.$log.debug("%s - Saved Permission Returned: %s", this.serviceName, JSON.stringify(response.data));
                _this.setPermission(response.data);
                _this.goToPermissionView();
                _this.loadPermissionsTable();
            }, function (errResponse) {
                _this.$log.error("Error updating permission states");
                //TODO show some sort of message to the permission.
            });
        };
        PermissionManagementService.prototype.addStatesToPermission = function (permission) {
            // Add states
            permission.states = [];
            for (var r in this.stateOptsGroup1) {
                var stateOpt = this.stateOptsGroup1[r];
                if (stateOpt.selected === true) {
                    // Add state id to permission state array
                    permission.states.push(this.retrieveStateFromAllStates(stateOpt.id));
                }
            }
            for (var r in this.stateOptsGroup2) {
                var stateOpt = this.stateOptsGroup2[r];
                if (stateOpt.selected === true) {
                    // Add state id to permission state array
                    permission.states.push(this.retrieveStateFromAllStates(stateOpt.id));
                }
            }
            for (var r in this.stateOptsGroup3) {
                var stateOpt = this.stateOptsGroup3[r];
                if (stateOpt.selected === true) {
                    // Add state id to permission state array
                    permission.states.push(this.retrieveStateFromAllStates(stateOpt.id));
                }
            }
        };
        PermissionManagementService.prototype.retrieveStateFromAllStates = function (stateId) {
            var returnValue = {};
            angular.forEach(this.allStates, function (state) {
                if (stateId === state.id) {
                    returnValue = state;
                }
            });
            return returnValue;
        };
        PermissionManagementService.prototype.getAllEndpoints = function () {
            var _this = this;
            this.initializeEndpointArrays();
            this.RoleService.getAllEndpoints().then(function (response) {
                // this.$log.debug("%s - Endpoints Returned: %s", this.serviceName, JSON.stringify(response.data));
                _this.allEndpoints = response.data;
                _this.UtilService.sortResults(_this.allEndpoints, "businessMethod", true);
                // this.$log.debug("this.allEndpoints: %s", JSON.stringify(this.allEndpoints));
                // this.$log.debug("this.permission.endpoints: %s", JSON.stringify(this.permission.endpoints));
                //populate checkbox
                for (var i in _this.allEndpoints) {
                    var endpoint = _this.allEndpoints[i];
                    var selected = false;
                    //pre-select Permission endpoints
                    for (var j in _this.permission.endpoints) {
                        var permissionEndpoint = _this.permission.endpoints[j];
                        if (endpoint.id === permissionEndpoint.id) {
                            selected = true;
                        }
                    }
                    _this.endpointOpts.push({
                        "id": endpoint.id,
                        "businessMethod": endpoint.businessMethod,
                        "selected": selected
                    });
                }
                // this.$log.debug("this.endpointOpts: %s", JSON.stringify(this.endpointOpts));
                _this.splitEndpointOpts(_this.endpointOpts);
            }, function (errResponse) {
                _this.$log.error("Error retrieving permission endpoints");
                //TODO show some sort of message to the user.
            });
        };
        PermissionManagementService.prototype.initializeEndpointArrays = function () {
            this.allEndpoints = [];
            this.endpointOpts = [];
            this.endpointOptsGroup1 = [];
            this.endpointOptsGroup2 = [];
            this.endpointOptsGroup3 = [];
        };
        PermissionManagementService.prototype.splitEndpointOpts = function (allEndpointOpts) {
            var divNum = allEndpointOpts.length / 3;
            var modNum = allEndpointOpts.length % 3;
            if (modNum === 0) {
                this.endpointOptsGroup1 = allEndpointOpts.splice(0, divNum);
                this.endpointOptsGroup2 = allEndpointOpts.splice(0, divNum);
                this.endpointOptsGroup3 = allEndpointOpts;
            }
            else {
                this.endpointOptsGroup1 = allEndpointOpts.splice(0, divNum + 1);
                this.endpointOptsGroup2 = allEndpointOpts.splice(0, divNum + 1);
                this.endpointOptsGroup3 = allEndpointOpts;
            }
        };
        PermissionManagementService.prototype.savePermissionEndpoints = function () {
            var _this = this;
            var permissionUpdate = angular.copy(this.permission);
            // this.$log.debug("permissionUpdate: %s", JSON.stringify(permissionUpdate));
            this.addEndpointsToPermission(permissionUpdate);
            // this.$log.debug("%s - Submitting Permission:", this.serviceName, permissionUpdate);
            this.RoleService.savePermissionEndpoints(permissionUpdate).then(function (response) {
                // this.$log.debug("%s - Saved Permission Returned: %s", this.serviceName, JSON.stringify(response.data));
                _this.setPermission(response.data);
                _this.goToPermissionView();
                _this.loadPermissionsTable();
            }, function (errResponse) {
                _this.$log.error("Error updating permission endpoints");
                //TODO show some sort of message to the permission.
            });
        };
        PermissionManagementService.prototype.addEndpointsToPermission = function (permission) {
            // Add endpoints
            permission.endpoints = [];
            for (var r in this.endpointOptsGroup1) {
                var endpointOpt = this.endpointOptsGroup1[r];
                if (endpointOpt.selected === true) {
                    // Add endpoint id to permission endpoint array
                    permission.endpoints.push(this.retrieveEndpointFromAllEndpoints(endpointOpt.id));
                }
            }
            for (var r in this.endpointOptsGroup2) {
                var endpointOpt = this.endpointOptsGroup2[r];
                if (endpointOpt.selected === true) {
                    // Add endpoint id to permission endpoint array
                    permission.endpoints.push(this.retrieveEndpointFromAllEndpoints(endpointOpt.id));
                }
            }
            for (var r in this.endpointOptsGroup3) {
                var endpointOpt = this.endpointOptsGroup3[r];
                if (endpointOpt.selected === true) {
                    // Add endpoint id to permission endpoint array
                    permission.endpoints.push(this.retrieveEndpointFromAllEndpoints(endpointOpt.id));
                }
            }
        };
        PermissionManagementService.prototype.retrieveEndpointFromAllEndpoints = function (endpointId) {
            var returnValue = {};
            angular.forEach(this.allEndpoints, function (endpoint) {
                if (endpointId === endpoint.id) {
                    returnValue = endpoint;
                }
            });
            return returnValue;
        };
        /**
         Go to to permission view state
         */
        PermissionManagementService.prototype.goToPermissionView = function () {
            // this.$log.debug("%s - Go to Permission View", this.serviceName);
            this.$state.go(this.StateConstants.ADMIN_PERMISSION_VIEW);
        };
        return PermissionManagementService;
    }());
    exports.PermissionManagementService = PermissionManagementService;
});
//# sourceMappingURL=permissionManagement.service.js.map