define(["require", "exports", './permissionManagement.service'], function (require, exports, permissionManagement_service_1) {
    'use strict';
    var servicesModule = angular.module('Dmles.UserAdmin.PermissionManagement.Services.Module', []);
    servicesModule.service('PermissionManagementService', permissionManagement_service_1.PermissionManagementService);
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = servicesModule;
});
//# sourceMappingURL=module.js.map