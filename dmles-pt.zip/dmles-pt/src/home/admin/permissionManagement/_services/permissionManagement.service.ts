'use strict';

import {PermissionDetailed} from "../../../../_models/permissionDetailed.model";
import {PermElement} from "../../../../_models/permElement.model";
import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {PermState} from "../../../../_models/permState.model";
import {PermEndpoint} from "../../../../_models/permEndpoint.model";

export interface IPermissionManagementService {

}

export class PermissionManagementService implements IPermissionManagementService {
    private permission: PermissionDetailed = null;
    private serviceName: String = "Permission Management Service";

    public permissionsNgTable: any = null;

    public permissionFunctionalAreaOptions = ["Administration", "Equipment_Request", "Other"];

    public allElements: Array<PermElement> = [];
    public elementOpts: any[] = [];
    public elementOptsGroup1: any[] = [];
    public elementOptsGroup2: any[] = [];
    public elementOptsGroup3: any[] = [];

    public allStates: Array<PermState> = [];
    public stateOpts: any[] = [];
    public stateOptsGroup1: any[] = [];
    public stateOptsGroup2: any[] = [];
    public stateOptsGroup3: any[] = [];

    public allEndpoints: Array<PermEndpoint> = [];
    public endpointOpts: any[] = [];
    public endpointOptsGroup1: any[] = [];
    public endpointOptsGroup2: any[] = [];
    public endpointOptsGroup3: any[] = [];

    // @ngInject
    constructor(private $log, private $state, private datatableService, private RoleService, private StateConstants, private UtilService) {
        // this.$log.debug("%s - Start", this.serviceName);
    }

    public getPermission(): PermissionDetailed {
        return this.permission;
    }

    public setPermission(permission: PermissionDetailed): void {
        this.permission = permission;
    }

    public clearPermission() {
        this.permission = new PermissionDetailed();
    }

    public loadPermissionsTable() {
        this.RoleService.getAllPermissionsDetailed().then((response: IHttpPromiseCallbackArg<PermissionDetailed[]>) => {
            // this.$log.debug("%s - PermissionsDetailed Returned: %s", this.serviceName, JSON.stringify(response.data));

            this.permissionsNgTable = this.datatableService.createNgTable(response.data, 25, {name: 'asc'});
            this.permissionsNgTable.reload();
        }, (errResponse: IHttpPromiseCallbackArg<PermissionDetailed[]>) => {
            this.$log.error("Error retrieving AllPermissionsDetailed");
            //TODO show some sort of message to the user.
        });
    }

    public getAllElements() {
        this.initializeElementArrays();

        this.RoleService.getAllElements().then((response: IHttpPromiseCallbackArg<PermElement[]>) => {
            // this.$log.debug("%s - Elements Returned: %s", this.serviceName, JSON.stringify(response.data));
            this.allElements = response.data;
            this.UtilService.sortResults(this.allElements, "name", true);

            // this.$log.debug("this.allElements: %s", JSON.stringify(this.allElements));
            // this.$log.debug("this.permission.elements: %s", JSON.stringify(this.permission.elements));

            //populate checkbox
            for (let i in this.allElements) {
                let element: PermElement = this.allElements[i];
                let selected: boolean = false;

                //pre-select Permission elements
                for (let j in this.permission.elements) {
                    let permissionElement: PermElement = this.permission.elements[j];
                    if (element.id === permissionElement.id) {
                        selected = true;
                    }
                }

                this.elementOpts.push({
                    "id": element.id,
                    "name": element.name,
                    "selected": selected
                });
            }
            // this.$log.debug("this.elementOpts: %s", JSON.stringify(this.elementOpts));
            this.splitElementOpts(this.elementOpts);

        }, (errResponse: IHttpPromiseCallbackArg<PermElement[]>) => {
            this.$log.error("Error retrieving permission elements");
            //TODO show some sort of message to the user.
        });
    }

    private initializeElementArrays() {
        this.allElements = [];
        this.elementOpts = [];
        this.elementOptsGroup1 = [];
        this.elementOptsGroup2 = [];
        this.elementOptsGroup3 = [];
    }

    /**
     Splits the given array into three arrays to be displayed in three columns in the html.

     Note: If the array is cleanly divisable by three, then the array is split into 3 equal groups,
     if it is not then the array is split into 3 groups where 2 are the same size and the
     third has less, this is so it will display nicely in columns.
     */
    public splitElementOpts(allElementOpts: any[]): void {
        let divNum = allElementOpts.length / 3;
        let modNum = allElementOpts.length % 3;
        if (modNum === 0) {
            this.elementOptsGroup1 = allElementOpts.splice(0, divNum);
            this.elementOptsGroup2 = allElementOpts.splice(0, divNum);
            this.elementOptsGroup3 = allElementOpts;
        } else {
            this.elementOptsGroup1 = allElementOpts.splice(0, divNum + 1);
            this.elementOptsGroup2 = allElementOpts.splice(0, divNum + 1);
            this.elementOptsGroup3 = allElementOpts;
        }
    }

    public savePermissionElements() {
        let permissionUpdate: PermissionDetailed = angular.copy(this.permission);
        // this.$log.debug("permissionUpdate: %s", JSON.stringify(permissionUpdate));

        this.addElementsToPermission(permissionUpdate);

        // this.$log.debug("%s - Submitting Permission:", this.serviceName, permissionUpdate);
        this.RoleService.savePermissionElements(permissionUpdate).then((response: IHttpPromiseCallbackArg<PermissionDetailed>) => {
            // this.$log.debug("%s - Saved Permission Returned: %s", this.serviceName, JSON.stringify(response.data));
            this.setPermission(response.data);
            this.goToPermissionView();
            this.loadPermissionsTable();
        }, (errResponse: IHttpPromiseCallbackArg<PermissionDetailed>) => {
            this.$log.error("Error updating permission elements");
            //TODO show some sort of message to the permission.
        });
    }

    private addElementsToPermission(permission: PermissionDetailed) {
        // Add elements
        permission.elements = [];
        for (let r in this.elementOptsGroup1) {
            let elementOpt: any = this.elementOptsGroup1[r];
            if (elementOpt.selected === true) {
                // Add element id to permission element array
                permission.elements.push(this.retrieveElementFromAllElements(elementOpt.id));
            }
        }
        for (let r in this.elementOptsGroup2) {
            let elementOpt: any = this.elementOptsGroup2[r];
            if (elementOpt.selected === true) {
                // Add element id to permission element array
                permission.elements.push(this.retrieveElementFromAllElements(elementOpt.id));
            }
        }
        for (let r in this.elementOptsGroup3) {
            let elementOpt: any = this.elementOptsGroup3[r];
            if (elementOpt.selected === true) {
                // Add element id to permission element array
                permission.elements.push(this.retrieveElementFromAllElements(elementOpt.id));
            }
        }
    }

    private retrieveElementFromAllElements(elementId: string): any {
        let returnValue = {};
        angular.forEach(this.allElements, (element) => {
            if (elementId === element.id) {
                returnValue = element;
            }
        });
        return returnValue;
    }

    public getAllStates() {
        this.initializeStateArrays();

        this.RoleService.getAllStates().then((response: IHttpPromiseCallbackArg<PermState[]>) => {
            // this.$log.debug("%s - States Returned: %s", this.serviceName, JSON.stringify(response.data));
            this.allStates = response.data;
            this.UtilService.sortResults(this.allStates, "name", true);

            // this.$log.debug("this.allStates: %s", JSON.stringify(this.allStates));
            // this.$log.debug("this.permission.states: %s", JSON.stringify(this.permission.states));

            //populate checkbox
            for (let i in this.allStates) {
                let state: PermState = this.allStates[i];
                let selected: boolean = false;

                //pre-select Permission states
                for (let j in this.permission.states) {
                    let permissionState: PermState = this.permission.states[j];
                    if (state.id === permissionState.id) {
                        selected = true;
                    }
                }

                this.stateOpts.push({
                    "id": state.id,
                    "name": state.name,
                    "selected": selected
                });
            }
            // this.$log.debug("this.stateOpts: %s", JSON.stringify(this.stateOpts));
            this.splitStateOpts(this.stateOpts);

        }, (errResponse: IHttpPromiseCallbackArg<PermState[]>) => {
            this.$log.error("Error retrieving permission states");
            //TODO show some sort of message to the user.
        });
    }

    private initializeStateArrays() {
        this.allStates = [];
        this.stateOpts = [];
        this.stateOptsGroup1 = [];
        this.stateOptsGroup2 = [];
        this.stateOptsGroup3 = [];
    }

    private splitStateOpts(allStateOpts: any[]): void {
        let divNum = allStateOpts.length / 3;
        let modNum = allStateOpts.length % 3;
        if (modNum === 0) {
            this.stateOptsGroup1 = allStateOpts.splice(0, divNum);
            this.stateOptsGroup2 = allStateOpts.splice(0, divNum);
            this.stateOptsGroup3 = allStateOpts;
        } else {
            this.stateOptsGroup1 = allStateOpts.splice(0, divNum + 1);
            this.stateOptsGroup2 = allStateOpts.splice(0, divNum + 1);
            this.stateOptsGroup3 = allStateOpts;
        }
    }

    public savePermissionStates() {
        let permissionUpdate: PermissionDetailed = angular.copy(this.permission);
        // this.$log.debug("permissionUpdate: %s", JSON.stringify(permissionUpdate));

        this.addStatesToPermission(permissionUpdate);

        // this.$log.debug("%s - Submitting Permission:", this.serviceName, permissionUpdate);
        this.RoleService.savePermissionStates(permissionUpdate).then((response: IHttpPromiseCallbackArg<PermissionDetailed>) => {
            // this.$log.debug("%s - Saved Permission Returned: %s", this.serviceName, JSON.stringify(response.data));
            this.setPermission(response.data);
            this.goToPermissionView();
            this.loadPermissionsTable();
        }, (errResponse: IHttpPromiseCallbackArg<PermissionDetailed>) => {
            this.$log.error("Error updating permission states");
            //TODO show some sort of message to the permission.
        });
    }

    private addStatesToPermission(permission: PermissionDetailed) {
        // Add states
        permission.states = [];
        for (let r in this.stateOptsGroup1) {
            let stateOpt: any = this.stateOptsGroup1[r];
            if (stateOpt.selected === true) {
                // Add state id to permission state array
                permission.states.push(this.retrieveStateFromAllStates(stateOpt.id));
            }
        }
        for (let r in this.stateOptsGroup2) {
            let stateOpt: any = this.stateOptsGroup2[r];
            if (stateOpt.selected === true) {
                // Add state id to permission state array
                permission.states.push(this.retrieveStateFromAllStates(stateOpt.id));
            }
        }
        for (let r in this.stateOptsGroup3) {
            let stateOpt: any = this.stateOptsGroup3[r];
            if (stateOpt.selected === true) {
                // Add state id to permission state array
                permission.states.push(this.retrieveStateFromAllStates(stateOpt.id));
            }
        }
    }

    private retrieveStateFromAllStates(stateId: string): any {
        let returnValue = {};
        angular.forEach(this.allStates, (state) => {
            if (stateId === state.id) {
                returnValue = state;
            }
        });
        return returnValue;
    }

    public getAllEndpoints() {
        this.initializeEndpointArrays();

        this.RoleService.getAllEndpoints().then((response: IHttpPromiseCallbackArg<PermEndpoint[]>) => {
            // this.$log.debug("%s - Endpoints Returned: %s", this.serviceName, JSON.stringify(response.data));
            this.allEndpoints = response.data;
            this.UtilService.sortResults(this.allEndpoints, "businessMethod", true);

            // this.$log.debug("this.allEndpoints: %s", JSON.stringify(this.allEndpoints));
            // this.$log.debug("this.permission.endpoints: %s", JSON.stringify(this.permission.endpoints));

            //populate checkbox
            for (let i in this.allEndpoints) {
                let endpoint: PermEndpoint = this.allEndpoints[i];
                let selected: boolean = false;

                //pre-select Permission endpoints
                for (let j in this.permission.endpoints) {
                    let permissionEndpoint: PermEndpoint = this.permission.endpoints[j];
                    if (endpoint.id === permissionEndpoint.id) {
                        selected = true;
                    }
                }

                this.endpointOpts.push({
                    "id": endpoint.id,
                    "businessMethod": endpoint.businessMethod,
                    "selected": selected
                });
            }
            // this.$log.debug("this.endpointOpts: %s", JSON.stringify(this.endpointOpts));
            this.splitEndpointOpts(this.endpointOpts);

        }, (errResponse: IHttpPromiseCallbackArg<PermEndpoint[]>) => {
            this.$log.error("Error retrieving permission endpoints");
            //TODO show some sort of message to the user.
        });
    }

    private initializeEndpointArrays() {
        this.allEndpoints = [];
        this.endpointOpts = [];
        this.endpointOptsGroup1 = [];
        this.endpointOptsGroup2 = [];
        this.endpointOptsGroup3 = [];
    }

    private splitEndpointOpts(allEndpointOpts: any[]): void {
        let divNum = allEndpointOpts.length / 3;
        let modNum = allEndpointOpts.length % 3;
        if (modNum === 0) {
            this.endpointOptsGroup1 = allEndpointOpts.splice(0, divNum);
            this.endpointOptsGroup2 = allEndpointOpts.splice(0, divNum);
            this.endpointOptsGroup3 = allEndpointOpts;
        } else {
            this.endpointOptsGroup1 = allEndpointOpts.splice(0, divNum + 1);
            this.endpointOptsGroup2 = allEndpointOpts.splice(0, divNum + 1);
            this.endpointOptsGroup3 = allEndpointOpts;
        }
    }

    public savePermissionEndpoints() {
        let permissionUpdate: PermissionDetailed = angular.copy(this.permission);
        // this.$log.debug("permissionUpdate: %s", JSON.stringify(permissionUpdate));

        this.addEndpointsToPermission(permissionUpdate);

        // this.$log.debug("%s - Submitting Permission:", this.serviceName, permissionUpdate);
        this.RoleService.savePermissionEndpoints(permissionUpdate).then((response: IHttpPromiseCallbackArg<PermissionDetailed>) => {
            // this.$log.debug("%s - Saved Permission Returned: %s", this.serviceName, JSON.stringify(response.data));
            this.setPermission(response.data);
            this.goToPermissionView();
            this.loadPermissionsTable();
        }, (errResponse: IHttpPromiseCallbackArg<PermissionDetailed>) => {
            this.$log.error("Error updating permission endpoints");
            //TODO show some sort of message to the permission.
        });
    }

    private addEndpointsToPermission(permission: PermissionDetailed) {
        // Add endpoints
        permission.endpoints = [];
        for (let r in this.endpointOptsGroup1) {
            let endpointOpt: any = this.endpointOptsGroup1[r];
            if (endpointOpt.selected === true) {
                // Add endpoint id to permission endpoint array
                permission.endpoints.push(this.retrieveEndpointFromAllEndpoints(endpointOpt.id));
            }
        }
        for (let r in this.endpointOptsGroup2) {
            let endpointOpt: any = this.endpointOptsGroup2[r];
            if (endpointOpt.selected === true) {
                // Add endpoint id to permission endpoint array
                permission.endpoints.push(this.retrieveEndpointFromAllEndpoints(endpointOpt.id));
            }
        }
        for (let r in this.endpointOptsGroup3) {
            let endpointOpt: any = this.endpointOptsGroup3[r];
            if (endpointOpt.selected === true) {
                // Add endpoint id to permission endpoint array
                permission.endpoints.push(this.retrieveEndpointFromAllEndpoints(endpointOpt.id));
            }
        }
    }

    private retrieveEndpointFromAllEndpoints(endpointId: string): any {
        let returnValue = {};
        angular.forEach(this.allEndpoints, (endpoint) => {
            if (endpointId === endpoint.id) {
                returnValue = endpoint;
            }
        });
        return returnValue;
    }

    /**
     Go to to permission view state
     */
    public goToPermissionView(): void {
        // this.$log.debug("%s - Go to Permission View", this.serviceName);
        this.$state.go(this.StateConstants.ADMIN_PERMISSION_VIEW);
    }
}