'use strict';

import {PermissionManagementService} from './permissionManagement.service';

let servicesModule = angular.module('Dmles.UserAdmin.PermissionManagement.Services.Module', []);
servicesModule.service('PermissionManagementService', PermissionManagementService);

export default servicesModule;

