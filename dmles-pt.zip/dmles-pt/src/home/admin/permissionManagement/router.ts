'use strict;'

class Router {
    static instance: any;

    // @ngInject
    constructor($stateProvider, $urlRouterProvider, StateConstants) {
        // For any unmatched url, redirect to /home


        $stateProvider
            .state(StateConstants.ADMIN_PERMISSION_MNG, {
                url: '/permissionManagement',
                templateUrl: '/src/home/admin/permissionManagement/_views/permissionManagement.html',
                controller: 'Dmles.Admin.PermissionManagement.Views.PermissionManagementController',
                controllerAs: 'vm',
                data: {
                    displayName: 'Permission Management'
                }
            }).state(StateConstants.ADMIN_PERMISSION_CREATE, {
                url: '/permissionCreate',
                templateUrl: '/src/home/admin/permissionManagement/_views/permissionCreate.html',
                controller: 'Dmles.Admin.PermissionManagement.Views.PermissionCreateController',
                controllerAs: 'vm',
                data: {
                    displayName: 'Create Permission'
                }
            }).state(StateConstants.ADMIN_PERMISSION_EDIT_GEN_INFO, {
                url: '/permissionEditGenInfo',
                templateUrl: '/src/home/admin/permissionManagement/_views/permissionEditGenInfo.html',
                controller: 'Dmles.Admin.PermissionManagement.Views.PermissionEditGenInfoController',
                controllerAs: 'vm',
                data: {
                    displayName: 'Edit Permission General Information'
                }
            }).state(StateConstants.ADMIN_PERMISSION_EDIT_ELEMENTS, {
                url: '/permissionEditElements',
                templateUrl: '/src/home/admin/permissionManagement/_views/permissionEditElements.html',
                controller: 'Dmles.Admin.PermissionManagement.Views.PermissionEditElementsController',
                controllerAs: 'vm',
                data: {
                    displayName: 'Edit Permission Elements'
                }
            }).state(StateConstants.ADMIN_PERMISSION_EDIT_STATES, {
                url: '/permissionEditStates',
                templateUrl: '/src/home/admin/permissionManagement/_views/permissionEditStates.html',
                controller: 'Dmles.Admin.PermissionManagement.Views.PermissionEditStatesController',
                controllerAs: 'vm',
                data: {
                    displayName: 'Edit Permission States'
                }
            }).state(StateConstants.ADMIN_PERMISSION_EDIT_ENDPOINTS, {
                url: '/permissionEditEndpoints',
                templateUrl: '/src/home/admin/permissionManagement/_views/permissionEditEndpoints.html',
                controller: 'Dmles.Admin.PermissionManagement.Views.PermissionEditEndpointsController',
                controllerAs: 'vm',
                data: {
                    displayName: 'Edit Permission Endpoints'
                }
            }).state(StateConstants.ADMIN_PERMISSION_VIEW, {
                url: '/permissionView',
                templateUrl: '/src/home/admin/permissionManagement/_views/permissionView.html',
                controller: 'Dmles.Admin.PermissionManagement.Views.PermissionViewController',
                controllerAs: 'vm',
                data: {
                    displayName: 'View Permission'
                }
            })
            ;

    }

    static factory($stateProvider, $urlRouterProvider, StateConstants) {
        Router.instance = new Router($stateProvider, $urlRouterProvider, StateConstants);
        return Router.instance;
    }
}

Router.factory.$inject = ['$stateProvider', '$urlRouterProvider', 'StateConstants'];

export default Router;