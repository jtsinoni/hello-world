define(["require", "exports", './router', './_services/module', './_views/module'], function (require, exports, router_1, module_1, module_2) {
    'use strict';
    var module = angular.module('Dmles.Admin.PermissionManagementModule', [
        module_1.default.name,
        module_2.default.name
    ]);
    console.log('ready to call config(router) in dmles.admin.permissionManagement module');
    module.config(router_1.default.factory);
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = module;
});
//# sourceMappingURL=module.js.map