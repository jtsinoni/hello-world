'use strict';

import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {PermissionDetailed} from "../../../../_models/permissionDetailed.model";

export class PermissionViewController {
    private controllerName: string = "Permission View Controller";
    private permission: PermissionDetailed = null;

    // @ngInject
    constructor(private $log, private $state, private StateConstants, private PermissionManagementService, private UtilService) {
        this.init();
    }

    /**
     Initializes the page
     */
    private init() {
        // this.$log.debug("%s - Start", this.controllerName);

        this.permission = this.PermissionManagementService.getPermission();

        if (this.permission === null) {
            // no permission, return to permission admin
            this.goToPermissionAdmin();
        } else {
            // this.$log.debug("this.permission", JSON.stringify(this.permission));
        }

        this.UtilService.sortResults(this.permission.elements, "name", true);
        this.UtilService.sortResults(this.permission.states, "name", true);
        this.UtilService.sortResults(this.permission.endpoints, "businessMethod", true);
    }   
   
    /**
     Return to Permission Admin page
     */
    private goToPermissionAdmin() {
        // this.$log.debug("%s - Go back to permissionAdmin", this.controllerName);
        this.PermissionManagementService.loadPermissionsTable();
        this.$state.go(this.StateConstants.ADMIN_PERMISSION_MNG);
    }

    /**
     Go to Permission Edit General Information page
     */
    private goToEditPermissionGeneralInfo() {
        // this.$log.debug("%s - Go to Permission Edit General Information page", this.controllerName);
        this.$state.go(this.StateConstants.ADMIN_PERMISSION_EDIT_GEN_INFO);
    }

    /**
     Go to Permission Edit Elements page
     */
    private goToEditPermissionElements() {
        // this.$log.debug("%s - Go to Permission Edit Elements page", this.controllerName);
        this.$state.go(this.StateConstants.ADMIN_PERMISSION_EDIT_ELEMENTS);
    }

    /**
     Go to Permission Edit Endpoints page
     */
    private goToEditPermissionEndpoints() {
        // this.$log.debug("%s - Go to Permission Edit Endpoints page", this.controllerName);
        this.$state.go(this.StateConstants.ADMIN_PERMISSION_EDIT_ENDPOINTS);
    }

    /**
     Go to Permission Edit States page
     */
    private goToEditPermissionStates() {
        // this.$log.debug("%s - Go to Permission Edit States page", this.controllerName);
        this.$state.go(this.StateConstants.ADMIN_PERMISSION_EDIT_STATES);
    }
}