define(["require", "exports"], function (require, exports) {
    'use strict';
    var PermissionEditGenInfoController = (function () {
        // @ngInject
        function PermissionEditGenInfoController($log, $state, PermissionManagementService, RoleService, StateConstants) {
            this.$log = $log;
            this.$state = $state;
            this.PermissionManagementService = PermissionManagementService;
            this.RoleService = RoleService;
            this.StateConstants = StateConstants;
            this.permissionGeneralInfoChanged = false;
            this.controllerName = "Permission Edit General Information Controller";
            this.permission = null;
            // this.$log.debug("%s - Start", this.controllerName);
            this.permission = PermissionManagementService.getPermission();
            //this.$log.debug(this.permission);
            if (this.permission === null) {
                //no Permission, go back
                this.PermissionManagementService.goToPermissionView();
            }
            else {
            }
        }
        /**
         Updates the permission general information and returns to the Permission View state
         */
        PermissionEditGenInfoController.prototype.onSubmit = function () {
            var permissionEditGenInfo = angular.copy(this.permission);
            // this.$log.debug("this.permission.name: %s", JSON.stringify(this.permission.name));
            // this.$log.debug("this.permission.description: %s", JSON.stringify(this.permission.description));
            // this.$log.debug("this.permission.functionalArea: %s", JSON.stringify(this.permission.functionalArea));
            // Save button on GUI only gets enabled when all required data has values - so no need to check here
            this.savePermissionGeneralInfo();
            this.PermissionManagementService.goToPermissionView();
        };
        PermissionEditGenInfoController.prototype.savePermissionGeneralInfo = function () {
            var _this = this;
            this.permissionGeneralInfoChanged = false;
            // this.$log.debug("Saving this.permission: %s", JSON.stringify(this.permission));
            this.RoleService.savePermissionData(this.permission).then(function (response) {
                _this.permission = response.data;
                _this.PermissionManagementService.setPermission(_this.permission);
                _this.PermissionManagementService.loadPermissionsTable();
                // this.$log.debug("%s - Saved Permission Returned: %s", this.controllerName, JSON.stringify(this.permission));
            }, function (errResponse) {
                _this.$log.error("Error saving permission general info");
                //TODO show some sort of message to the user.
            });
        };
        return PermissionEditGenInfoController;
    }());
    exports.PermissionEditGenInfoController = PermissionEditGenInfoController;
});
//# sourceMappingURL=permissionEditGenInfo.controller.js.map