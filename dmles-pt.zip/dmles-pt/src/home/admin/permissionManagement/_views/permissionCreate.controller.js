define(["require", "exports"], function (require, exports) {
    'use strict';
    var PermissionCreateController = (function () {
        // @ngInject
        function PermissionCreateController($log, $state, PermissionManagementService, RoleService, StateConstants) {
            this.$log = $log;
            this.$state = $state;
            this.PermissionManagementService = PermissionManagementService;
            this.RoleService = RoleService;
            this.StateConstants = StateConstants;
            this.controllerName = "Permission Create Controller";
            this.permission = null;
            // this.$log.debug("%s - Start", this.controllerName);
            this.permission = PermissionManagementService.getPermission();
            //this.$log.debug(this.permission);
            if (this.permission === null) {
                //no Permission, go back            
                this.goToPermissionManagement();
            }
            else {
                // this.$log.debug("Init Created Permission: %s", JSON.stringify(this.permission));
                this.init();
            }
        }
        PermissionCreateController.prototype.init = function () {
            this.PermissionManagementService.getAllElements();
            this.PermissionManagementService.getAllStates();
            this.PermissionManagementService.getAllEndpoints();
        };
        /**
         Creates the permission, if it is valid, and returns to the PermissionManagement state
         */
        PermissionCreateController.prototype.onSubmit = function () {
            var permissionCreate = angular.copy(this.permission);
            this.PermissionManagementService.addElementsToPermission(permissionCreate);
            this.PermissionManagementService.addStatesToPermission(permissionCreate);
            this.PermissionManagementService.addEndpointsToPermission(permissionCreate);
            // this.$log.debug("permissionCreate: %s", JSON.stringify(permissionCreate));
            if (!permissionCreate.name || !permissionCreate.description || !permissionCreate.functionalArea) {
                this.$log.debug("permissionCreate - missing a required field");
            }
            else {
                permissionCreate.id = null;
                // this.$log.debug("permissionCreate: %s", JSON.stringify(permissionCreate));
                this.createPermission(permissionCreate);
            }
        };
        PermissionCreateController.prototype.createPermission = function (permissionCreate) {
            // this.$log.debug("Creating permissionCreate: %s", JSON.stringify(permissionCreate));
            var _this = this;
            this.RoleService.createPermissionDetailed(permissionCreate).then(function (response) {
                // this.permission = response.data;
                // this.$log.debug("%s - Create Permission Returned: %s", this.controllerName, JSON.stringify(response.data));
                _this.goToPermissionManagement();
            }, function (errResponse) {
                _this.$log.error("Error creating permission");
                //TODO show some sort of message to the user.
            });
        };
        /**
         Return to permission management state
         */
        PermissionCreateController.prototype.goToPermissionManagement = function () {
            // this.$log.debug("%s - Go to Permission Management", this.controllerName);
            this.PermissionManagementService.loadPermissionsTable();
            this.$state.go(this.StateConstants.ADMIN_PERMISSION_MNG);
        };
        return PermissionCreateController;
    }());
    exports.PermissionCreateController = PermissionCreateController;
});
//# sourceMappingURL=permissionCreate.controller.js.map