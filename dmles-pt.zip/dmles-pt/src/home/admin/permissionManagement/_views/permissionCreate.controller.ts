'use strict';

import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {PermissionDetailed} from "../../../../_models/permissionDetailed.model";

export class PermissionCreateController {
    private controllerName: string = "Permission Create Controller";
    private permission: PermissionDetailed = null;

    // @ngInject
    constructor(private $log, private $state, private PermissionManagementService,
                private RoleService, private StateConstants) {

        // this.$log.debug("%s - Start", this.controllerName);
        this.permission = PermissionManagementService.getPermission();
        //this.$log.debug(this.permission);

        if (this.permission === null) {
            //no Permission, go back            
            this.goToPermissionManagement();
        } else {
            // this.$log.debug("Init Created Permission: %s", JSON.stringify(this.permission));
            this.init();
        }
    }

    private init(): void {
        this.PermissionManagementService.getAllElements();
        this.PermissionManagementService.getAllStates();
        this.PermissionManagementService.getAllEndpoints();
    }

    /**
     Creates the permission, if it is valid, and returns to the PermissionManagement state
     */
    private onSubmit() {
        let permissionCreate: any = angular.copy(this.permission);

        this.PermissionManagementService.addElementsToPermission(permissionCreate);
        this.PermissionManagementService.addStatesToPermission(permissionCreate);
        this.PermissionManagementService.addEndpointsToPermission(permissionCreate);

        // this.$log.debug("permissionCreate: %s", JSON.stringify(permissionCreate));

        if (!permissionCreate.name || !permissionCreate.description || !permissionCreate.functionalArea) {
            this.$log.debug("permissionCreate - missing a required field");
        } else {
            permissionCreate.id = null;
            // this.$log.debug("permissionCreate: %s", JSON.stringify(permissionCreate));

            this.createPermission(permissionCreate);
        }
    }

    public createPermission(permissionCreate: PermissionDetailed) {
        // this.$log.debug("Creating permissionCreate: %s", JSON.stringify(permissionCreate));

        this.RoleService.createPermissionDetailed(permissionCreate).then((response: IHttpPromiseCallbackArg<PermissionDetailed>) => {
            // this.permission = response.data;
            // this.$log.debug("%s - Create Permission Returned: %s", this.controllerName, JSON.stringify(response.data));
            this.goToPermissionManagement();
        }, (errResponse: IHttpPromiseCallbackArg<PermissionDetailed[]>) => {
            this.$log.error("Error creating permission");
            //TODO show some sort of message to the user.
        });
    }

    /**
     Return to permission management state
     */
    private goToPermissionManagement(): void {
        // this.$log.debug("%s - Go to Permission Management", this.controllerName);
        this.PermissionManagementService.loadPermissionsTable();
        this.$state.go(this.StateConstants.ADMIN_PERMISSION_MNG);
    }
}