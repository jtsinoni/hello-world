define(["require", "exports"], function (require, exports) {
    'use strict';
    var PermissionEditEndpointsController = (function () {
        // @ngInject
        function PermissionEditEndpointsController($log, PermissionManagementService) {
            this.$log = $log;
            this.PermissionManagementService = PermissionManagementService;
            this.controllerName = "Permission Edit Endpoints Controller";
            this.permission = null;
            this.init();
        }
        /**
         Initializes the page
         */
        PermissionEditEndpointsController.prototype.init = function () {
            // this.$log.debug("%s - Start", this.controllerName);
            this.permission = this.PermissionManagementService.getPermission();
            if (this.permission === null) {
                //no permission, go back
                this.PermissionManagementService.goToPermissionView();
            }
            else {
            }
            this.PermissionManagementService.getAllEndpoints();
        };
        PermissionEditEndpointsController.prototype.onSubmit = function () {
            this.PermissionManagementService.savePermissionEndpoints();
        };
        return PermissionEditEndpointsController;
    }());
    exports.PermissionEditEndpointsController = PermissionEditEndpointsController;
});
//# sourceMappingURL=permissionEditEndpoints.controller.js.map