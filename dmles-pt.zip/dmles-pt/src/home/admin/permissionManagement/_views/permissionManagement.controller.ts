import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
'use strict';

import {PermissionDetailed} from "../../../../_models/permissionDetailed.model";

export class PermissionManagementController {
    private controllerName: string = "Permission Management Controller";    
    public permissionFilter: String = "";
    public selectedPermission: PermissionDetailed = null;
    public permissionToDelete: PermissionDetailed = null;
    public permissionDetailsShowUpdate: Boolean = false;

    // @ngInject
    constructor(private $log, private $state, private PermissionManagementService,
                private StateConstants, private RoleService) {
        // this.$log.debug("%s - Start", this.controllerName);
        this.init();
    }

    private init() {
        this.PermissionManagementService.loadPermissionsTable();
    }     

    public permissionManagementFilter() {
        this.PermissionManagementService.permissionsNgTable.filter({$: this.permissionFilter});
        this.PermissionManagementService.permissionsNgTable.reload();
    }

    public goToPermissionManagement() {
        // this.$log.debug("%s - Go to Permission Management", this.controllerName);
        this.$state.go(this.StateConstants.ADMIN_PERMISSION_MNG);
    }

    public goToPermissionView(permission) {
        this.PermissionManagementService.setPermission(angular.copy(permission));

        // this.$log.debug("%s - Go to Permission View", this.controllerName);
        this.$state.go(this.StateConstants.ADMIN_PERMISSION_VIEW);
    }

    public goToPermissionCreate() {
        this.PermissionManagementService.clearPermission();

        // this.$log.debug("%s - Go to Permission Create", this.controllerName);
        this.$state.go(this.StateConstants.ADMIN_PERMISSION_CREATE);
    }

    public setPermissionToBeDeleted(permission) {
        // this.$log.debug("setPermissionToBeDeleted: %s", JSON.stringify(permission));
        this.permissionToDelete = angular.copy(permission);
    }

    public deletePermission() {
        // this.$log.debug("Deleting permission: %s", JSON.stringify(this.permissionToDelete));

        this.RoleService.deletePermissionDetailed(this.permissionToDelete).then((response: IHttpPromiseCallbackArg<PermissionDetailed>) => {
            // this.permission = response.data;
            // this.$log.debug("%s - Delete Permission Returned: %s", this.controllerName, JSON.stringify(response.data));
            this.init();
        }, (errResponse: IHttpPromiseCallbackArg<PermissionDetailed>) => {
            this.$log.error("Error deleting permission");
            //TODO show some sort of message to the user.
        });
    }
}

