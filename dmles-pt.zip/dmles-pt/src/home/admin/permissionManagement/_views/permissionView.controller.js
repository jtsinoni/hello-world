define(["require", "exports"], function (require, exports) {
    'use strict';
    var PermissionViewController = (function () {
        // @ngInject
        function PermissionViewController($log, $state, StateConstants, PermissionManagementService, UtilService) {
            this.$log = $log;
            this.$state = $state;
            this.StateConstants = StateConstants;
            this.PermissionManagementService = PermissionManagementService;
            this.UtilService = UtilService;
            this.controllerName = "Permission View Controller";
            this.permission = null;
            this.init();
        }
        /**
         Initializes the page
         */
        PermissionViewController.prototype.init = function () {
            // this.$log.debug("%s - Start", this.controllerName);
            this.permission = this.PermissionManagementService.getPermission();
            if (this.permission === null) {
                // no permission, return to permission admin
                this.goToPermissionAdmin();
            }
            else {
            }
            this.UtilService.sortResults(this.permission.elements, "name", true);
            this.UtilService.sortResults(this.permission.states, "name", true);
            this.UtilService.sortResults(this.permission.endpoints, "businessMethod", true);
        };
        /**
         Return to Permission Admin page
         */
        PermissionViewController.prototype.goToPermissionAdmin = function () {
            // this.$log.debug("%s - Go back to permissionAdmin", this.controllerName);
            this.PermissionManagementService.loadPermissionsTable();
            this.$state.go(this.StateConstants.ADMIN_PERMISSION_MNG);
        };
        /**
         Go to Permission Edit General Information page
         */
        PermissionViewController.prototype.goToEditPermissionGeneralInfo = function () {
            // this.$log.debug("%s - Go to Permission Edit General Information page", this.controllerName);
            this.$state.go(this.StateConstants.ADMIN_PERMISSION_EDIT_GEN_INFO);
        };
        /**
         Go to Permission Edit Elements page
         */
        PermissionViewController.prototype.goToEditPermissionElements = function () {
            // this.$log.debug("%s - Go to Permission Edit Elements page", this.controllerName);
            this.$state.go(this.StateConstants.ADMIN_PERMISSION_EDIT_ELEMENTS);
        };
        /**
         Go to Permission Edit Endpoints page
         */
        PermissionViewController.prototype.goToEditPermissionEndpoints = function () {
            // this.$log.debug("%s - Go to Permission Edit Endpoints page", this.controllerName);
            this.$state.go(this.StateConstants.ADMIN_PERMISSION_EDIT_ENDPOINTS);
        };
        /**
         Go to Permission Edit States page
         */
        PermissionViewController.prototype.goToEditPermissionStates = function () {
            // this.$log.debug("%s - Go to Permission Edit States page", this.controllerName);
            this.$state.go(this.StateConstants.ADMIN_PERMISSION_EDIT_STATES);
        };
        return PermissionViewController;
    }());
    exports.PermissionViewController = PermissionViewController;
});
//# sourceMappingURL=permissionView.controller.js.map