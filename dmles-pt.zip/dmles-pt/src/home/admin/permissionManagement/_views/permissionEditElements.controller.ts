'use strict';

import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {PermissionDetailed} from "../../../../_models/permissionDetailed.model";

export class PermissionEditElementsController {    

    private controllerName: string = "Permission Edit Elements Controller";
    private permission: PermissionDetailed = null;

    // @ngInject
    constructor(private $log, private PermissionManagementService) {
        this.init();
    }

    /**
     Initializes the page
     */
    private init() {
        // this.$log.debug("%s - Start", this.controllerName);
        this.permission = this.PermissionManagementService.getPermission();

        if (this.permission === null) {
            //no permission, go back
            this.PermissionManagementService.goToPermissionView();
        } else {
            // this.$log.debug("this.permission: %s", JSON.stringify(this.permission));
        }

        this.PermissionManagementService.getAllElements();
    }
    
    private onSubmit() {
        this.PermissionManagementService.savePermissionElements();
    }    
}