define(["require", "exports"], function (require, exports) {
    "use strict";
    'use strict';
    var PermissionManagementController = (function () {
        // @ngInject
        function PermissionManagementController($log, $state, PermissionManagementService, StateConstants, RoleService) {
            this.$log = $log;
            this.$state = $state;
            this.PermissionManagementService = PermissionManagementService;
            this.StateConstants = StateConstants;
            this.RoleService = RoleService;
            this.controllerName = "Permission Management Controller";
            this.permissionFilter = "";
            this.selectedPermission = null;
            this.permissionToDelete = null;
            this.permissionDetailsShowUpdate = false;
            // this.$log.debug("%s - Start", this.controllerName);
            this.init();
        }
        PermissionManagementController.prototype.init = function () {
            this.PermissionManagementService.loadPermissionsTable();
        };
        PermissionManagementController.prototype.permissionManagementFilter = function () {
            this.PermissionManagementService.permissionsNgTable.filter({ $: this.permissionFilter });
            this.PermissionManagementService.permissionsNgTable.reload();
        };
        PermissionManagementController.prototype.goToPermissionManagement = function () {
            // this.$log.debug("%s - Go to Permission Management", this.controllerName);
            this.$state.go(this.StateConstants.ADMIN_PERMISSION_MNG);
        };
        PermissionManagementController.prototype.goToPermissionView = function (permission) {
            this.PermissionManagementService.setPermission(angular.copy(permission));
            // this.$log.debug("%s - Go to Permission View", this.controllerName);
            this.$state.go(this.StateConstants.ADMIN_PERMISSION_VIEW);
        };
        PermissionManagementController.prototype.goToPermissionCreate = function () {
            this.PermissionManagementService.clearPermission();
            // this.$log.debug("%s - Go to Permission Create", this.controllerName);
            this.$state.go(this.StateConstants.ADMIN_PERMISSION_CREATE);
        };
        PermissionManagementController.prototype.setPermissionToBeDeleted = function (permission) {
            // this.$log.debug("setPermissionToBeDeleted: %s", JSON.stringify(permission));
            this.permissionToDelete = angular.copy(permission);
        };
        PermissionManagementController.prototype.deletePermission = function () {
            // this.$log.debug("Deleting permission: %s", JSON.stringify(this.permissionToDelete));
            var _this = this;
            this.RoleService.deletePermissionDetailed(this.permissionToDelete).then(function (response) {
                // this.permission = response.data;
                // this.$log.debug("%s - Delete Permission Returned: %s", this.controllerName, JSON.stringify(response.data));
                _this.init();
            }, function (errResponse) {
                _this.$log.error("Error deleting permission");
                //TODO show some sort of message to the user.
            });
        };
        return PermissionManagementController;
    }());
    exports.PermissionManagementController = PermissionManagementController;
});
//# sourceMappingURL=permissionManagement.controller.js.map