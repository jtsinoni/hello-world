define(["require", "exports", './permissionCreate.controller', './permissionEditElements.controller', './permissionEditEndpoints.controller', './permissionEditGenInfo.controller', './permissionEditStates.controller', './permissionManagement.controller', './permissionView.controller'], function (require, exports, permissionCreate_controller_1, permissionEditElements_controller_1, permissionEditEndpoints_controller_1, permissionEditGenInfo_controller_1, permissionEditStates_controller_1, permissionManagement_controller_1, permissionView_controller_1) {
    'use strict';
    var controllersModule = angular.module('Dmles.Admin.PermissionManagement.Views.Module', []);
    controllersModule.controller('Dmles.Admin.PermissionManagement.Views.PermissionCreateController', permissionCreate_controller_1.PermissionCreateController);
    controllersModule.controller('Dmles.Admin.PermissionManagement.Views.PermissionEditElementsController', permissionEditElements_controller_1.PermissionEditElementsController);
    controllersModule.controller('Dmles.Admin.PermissionManagement.Views.PermissionEditEndpointsController', permissionEditEndpoints_controller_1.PermissionEditEndpointsController);
    controllersModule.controller('Dmles.Admin.PermissionManagement.Views.PermissionEditGenInfoController', permissionEditGenInfo_controller_1.PermissionEditGenInfoController);
    controllersModule.controller('Dmles.Admin.PermissionManagement.Views.PermissionEditStatesController', permissionEditStates_controller_1.PermissionEditStatesController);
    controllersModule.controller('Dmles.Admin.PermissionManagement.Views.PermissionManagementController', permissionManagement_controller_1.PermissionManagementController);
    controllersModule.controller('Dmles.Admin.PermissionManagement.Views.PermissionViewController', permissionView_controller_1.PermissionViewController);
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = controllersModule;
});
//# sourceMappingURL=module.js.map