define(["require", "exports"], function (require, exports) {
    'use strict';
    var PermissionEditElementsController = (function () {
        // @ngInject
        function PermissionEditElementsController($log, PermissionManagementService) {
            this.$log = $log;
            this.PermissionManagementService = PermissionManagementService;
            this.controllerName = "Permission Edit Elements Controller";
            this.permission = null;
            this.init();
        }
        /**
         Initializes the page
         */
        PermissionEditElementsController.prototype.init = function () {
            // this.$log.debug("%s - Start", this.controllerName);
            this.permission = this.PermissionManagementService.getPermission();
            if (this.permission === null) {
                //no permission, go back
                this.PermissionManagementService.goToPermissionView();
            }
            else {
            }
            this.PermissionManagementService.getAllElements();
        };
        PermissionEditElementsController.prototype.onSubmit = function () {
            this.PermissionManagementService.savePermissionElements();
        };
        return PermissionEditElementsController;
    }());
    exports.PermissionEditElementsController = PermissionEditElementsController;
});
//# sourceMappingURL=permissionEditElements.controller.js.map