define(["require", "exports"], function (require, exports) {
    'use strict';
    var PermissionEditStatesController = (function () {
        // @ngInject
        function PermissionEditStatesController($log, PermissionManagementService) {
            this.$log = $log;
            this.PermissionManagementService = PermissionManagementService;
            this.controllerName = "Permission Edit States Controller";
            this.permission = null;
            this.init();
        }
        /**
         Initializes the page
         */
        PermissionEditStatesController.prototype.init = function () {
            // this.$log.debug("%s - Start", this.controllerName);
            this.permission = this.PermissionManagementService.getPermission();
            if (this.permission === null) {
                //no permission, go back
                this.PermissionManagementService.goToPermissionView();
            }
            else {
            }
            this.PermissionManagementService.getAllStates();
        };
        PermissionEditStatesController.prototype.onSubmit = function () {
            this.PermissionManagementService.savePermissionStates();
        };
        return PermissionEditStatesController;
    }());
    exports.PermissionEditStatesController = PermissionEditStatesController;
});
//# sourceMappingURL=permissionEditStates.controller.js.map