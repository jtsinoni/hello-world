'use strict';

import {PermissionCreateController} from './permissionCreate.controller';
import {PermissionEditElementsController} from './permissionEditElements.controller';
import {PermissionEditEndpointsController} from './permissionEditEndpoints.controller';
import {PermissionEditGenInfoController} from './permissionEditGenInfo.controller';
import {PermissionEditStatesController} from './permissionEditStates.controller';
import {PermissionManagementController} from './permissionManagement.controller';
import {PermissionViewController} from './permissionView.controller';

let controllersModule = angular.module('Dmles.Admin.PermissionManagement.Views.Module', []);
controllersModule.controller('Dmles.Admin.PermissionManagement.Views.PermissionCreateController', PermissionCreateController);
controllersModule.controller('Dmles.Admin.PermissionManagement.Views.PermissionEditElementsController', PermissionEditElementsController);
controllersModule.controller('Dmles.Admin.PermissionManagement.Views.PermissionEditEndpointsController', PermissionEditEndpointsController);
controllersModule.controller('Dmles.Admin.PermissionManagement.Views.PermissionEditGenInfoController', PermissionEditGenInfoController);
controllersModule.controller('Dmles.Admin.PermissionManagement.Views.PermissionEditStatesController', PermissionEditStatesController);
controllersModule.controller('Dmles.Admin.PermissionManagement.Views.PermissionManagementController', PermissionManagementController);
controllersModule.controller('Dmles.Admin.PermissionManagement.Views.PermissionViewController', PermissionViewController);

export default controllersModule;

