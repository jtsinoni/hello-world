'use strict';

import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {PermissionDetailed} from "../../../../_models/permissionDetailed.model";

export class PermissionEditGenInfoController {
    public permissionGeneralInfoChanged: boolean = false;

    private controllerName: string = "Permission Edit General Information Controller";
    private permission: PermissionDetailed = null;

    // @ngInject
    constructor(private $log, private $state, private PermissionManagementService, 
                private RoleService, private StateConstants) {
        
        // this.$log.debug("%s - Start", this.controllerName);
        this.permission = PermissionManagementService.getPermission();
        //this.$log.debug(this.permission);

        if (this.permission === null) {
            //no Permission, go back
            this.PermissionManagementService.goToPermissionView();
        } else {
            // this.$log.debug("Selected Permission: %s", JSON.stringify(this.permission));
        }
    }

    /**
     Updates the permission general information and returns to the Permission View state
     */
    public onSubmit() {
        let permissionEditGenInfo: any = angular.copy(this.permission);

        // this.$log.debug("this.permission.name: %s", JSON.stringify(this.permission.name));
        // this.$log.debug("this.permission.description: %s", JSON.stringify(this.permission.description));
        // this.$log.debug("this.permission.functionalArea: %s", JSON.stringify(this.permission.functionalArea));

        // Save button on GUI only gets enabled when all required data has values - so no need to check here
        this.savePermissionGeneralInfo();
        this.PermissionManagementService.goToPermissionView();
    }

    private savePermissionGeneralInfo() {
        this.permissionGeneralInfoChanged = false;

        // this.$log.debug("Saving this.permission: %s", JSON.stringify(this.permission));

        this.RoleService.savePermissionData(this.permission).then((response: IHttpPromiseCallbackArg<PermissionDetailed>) => {
            this.permission = response.data;
            this.PermissionManagementService.setPermission(this.permission);
            this.PermissionManagementService.loadPermissionsTable();
            // this.$log.debug("%s - Saved Permission Returned: %s", this.controllerName, JSON.stringify(this.permission));
        }, (errResponse: IHttpPromiseCallbackArg<PermissionDetailed[]>) => {
            this.$log.error("Error saving permission general info");
            //TODO show some sort of message to the user.
        });
    }   
}