class Router {
    static instance: any;

    // @ngInject
    constructor($stateProvider, $urlRouterProvider, StateConstants) {

        $stateProvider
            .state(StateConstants.ADMIN_ORG_MNG, {
                url: '/organizationManagement',
                templateUrl: '/src/home/admin/organizationManagement/_views/organizationManagement.html',
                controller: 'OrganizationManagementController',
                controllerAs: 'vm',
                data: {
                    displayName: 'Organization Management'
                }
            })
            ;

    }

    static factory($stateProvider, $urlRouterProvider, StateConstants) {
        Router.instance = new Router($stateProvider, $urlRouterProvider, StateConstants);
        return Router.instance;
    }
}

Router.factory.$inject = ['$stateProvider', '$urlRouterProvider', 'StateConstants'];

export default Router;