import {ApiService} from "../../../../_services/api.service";

export class OrganizationManagementService extends ApiService {
    private serviceName: String = "Organization Management Service";

    // @ngInject
    constructor($http, $log, Authentication, $httpParamSerializerJQLike, private NotificationService) {
        super($http, $log, Authentication, $httpParamSerializerJQLike, "Organization");
        this.$log.debug("%s - Start", this.serviceName);
    }

    public getChildren(parentGuid:String) {
        return this.get("getChildren?parentGuid=" + parentGuid).then((response: any) => {
            return response.data;
        }, (errResponse: any) => {
            this.$log.error("%s - Error retrieving children", this.serviceName);
            this.NotificationService.errorMsg("Unable to get children");
        });
    }

    public getNodes(isRefresh:boolean) {
        return this.get("getNodes?isRefresh=" + isRefresh).then((response: any) => {
            return response.data;
        }, (errResponse: any) => {
            this.$log.error("%s - Error retrieving nodes", this.serviceName);
            this.NotificationService.errorMsg("Unable to get nodes");
        });
    }

    public getNodeDetails(nodeGuid:String) {
        return this.get("getNode?nodeGuid=" + nodeGuid).then((response: any) => {
            return response.data;
        }, (errResponse: any) => {
            this.$log.error("%s - Error retrieving node details for id: %s", this.serviceName, nodeGuid);
            this.NotificationService.errorMsg("Unable to get node details");
        });
    }

}