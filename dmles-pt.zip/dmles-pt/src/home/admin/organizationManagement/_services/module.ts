import {OrganizationManagementService} from './organizationManagement.service';

let servicesModule = angular.module('Dmles.Admin.OrganizationManagementService.Services.Module', []);
servicesModule.service('OrganizationManagementService', OrganizationManagementService);

export default servicesModule;