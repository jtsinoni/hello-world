export class OrganizationManagementController {
    private controllerName = 'Organization Management Controller';

    private nodeRowIndex:number = null;
    private nodeDetailFilterName:string = 'W33DME';  // TODO: Pull in from User Object
    private nodeDetailFilterGuid:string = '2305BBEF73454A54B90BB2412505F658';  // TODO: Pull in from User Object

    public treeOptions:any = {};
    public treeData:any;
    public treeIsLoading:boolean = false;

    public nodeDetail:Node = null;
    public nodeChildren:Array<any> = [];
    public nodeChildrenLoading:boolean = false;

    public searchChildOrgs:string = "";

    // @ngInject
    constructor(private $log, private $interval, private $scope, private $timeout, private uiGridTreeViewConstants, private uiGridGroupingConstants, private uiGridConstants, private OrganizationManagementService) {
        this.$log.info("%s - Started", this.controllerName);
        this.init();
    }

    private getTreeData(){
        this.treeIsLoading = true;
        this.OrganizationManagementService.getNodes(false).then((data: any) => {

            for ( var i = 0; i < data.length; i++ ){
                data[i].$$treeLevel = data[i].treeLevel;

                if(data[i].guid === this.nodeDetailFilterGuid){
                    this.nodeDetail = data[i];
                    this.nodeDetailFilterName = data[i].name;
                    this.nodeRowIndex = i;
                }

            }

            this.treeData = data;

            this.loadNodeDetails(this.nodeDetailFilterGuid);
            this.treeIsLoading = false;
        });
    }

    private buildOpts(){
        this.treeOptions = {
            data: [],
            enableRowSelection:       true,
            enableRowHeaderSelection: true,
            multiSelect:              false,
            selectionRowHeaderWidth:  35,
            rowHeight:                35,
            showGridFooter:           true,
            columnDefs: [
                { name: 'guid', visible: false, allowCellFocus : false },
                { name: 'name', enableSorting: false, enableHiding: false }
            ]
        };

        this.getTreeData();
    }

    private init(){
        this.buildOpts();
    }

    private loadNodeDetails(guid){
        this.OrganizationManagementService.getNodeDetails(guid).then((data: any) => {
            this.nodeDetail = data;

            if(data.children && data.children.length > 0){
                this.OrganizationManagementService.getChildren(guid).then((data: any) => {
                    this.nodeChildren = data;
                    this.nodeChildrenLoading = false;
                })
            }else{
                this.nodeChildrenLoading = false;
                this.nodeChildren = null;
            }

        })
    }

    public onNodeClicked(itemData:any): void{
        this.nodeChildrenLoading = true;
        if(itemData.guid){
            this.loadNodeDetails(itemData.guid);
        }
    }

}