import {OrganizationManagementController} from './organizationManagement.controller'

var module = angular.module('Dmles.Home.Admin.OrganizationManagement.Views.Module', []);
module.controller('OrganizationManagementController', OrganizationManagementController);

export default module;