define(["require", "exports", './adminShell.controller', './router', './permissionManagement/module', './roleManagement/module', './userProfileManagement/module'], function (require, exports, adminShell_controller_1, router_1, module_1, module_2, module_3) {
    'use strict';
    var module = angular.module('Dmles.AdminModule', [
        module_1.default.name,
        module_2.default.name,
        module_3.default.name
    ]);
    module.controller('Dmles.Admin.AdminShellController', adminShell_controller_1.AdminShellController);
    module.config(router_1.default.factory);
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = module;
});
//# sourceMappingURL=module.js.map