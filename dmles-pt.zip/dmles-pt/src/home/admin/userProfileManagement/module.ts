'use strict';

import router from './router';

import servicesModule from './_services/module';
import controllersModule from './_views/module';

let module = angular.module('Dmles.Admin.UserProfileManagementModule', [   
    servicesModule.name,
    controllersModule.name
]);

module.config(router.factory);

export default module;