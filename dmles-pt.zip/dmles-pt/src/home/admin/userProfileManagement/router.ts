class Router {
    static instance:any;

    // @ngInject
    constructor($stateProvider, $urlRouterProvider, StateConstants) {
        // For any unmatched url, redirect to /home

        $stateProvider
            .state(StateConstants.ADMIN_USER_PROFILE_MNG, {
                url: '/userProfileManagement',
                templateUrl: '/src/home/admin/userProfileManagement/_views/userProfileManagement.html',
                controller: 'UserProfileManagementController',
                controllerAs: 'vm',
                data: {
                    displayName: 'User Profile Management'
                }
            }).state(StateConstants.ADMIN_USER_PROFILE_VIEW, {
                url: '/userProfileView',
                templateUrl: '/src/home/admin/userProfileManagement/_views/userProfileView.html',
                controller: 'UserProfileViewController',
                controllerAs: 'vm',
                data: {
                    displayName: 'User Profile View'
                }
            }).state(StateConstants.ADMIN_USER_PROFILE_EDIT_GEN_INFO, {
                url: '/userProfileEditGenInfo',
                templateUrl: '/src/home/admin/userProfileManagement/_views/userProfileEditGenInfo.html',
                controller: 'UserProfileEditGenInfoController',
                controllerAs: 'vm',
                data: {
                    displayName: 'User Profile Edit General Info'
                }
            }).state(StateConstants.ADMIN_USER_PROFILE_EDIT_ROLES, {
                url: '/userProfileEditRoles',
                templateUrl: '/src/home/admin/userProfileManagement/_views/userProfileEditRoles.html',
                controller: 'UserProfileEditRolesController',
                controllerAs: 'vm',
                data: {
                    displayName: 'User Profile Edit Roles'
                }
            }).state(StateConstants.ADMIN_USER_PROFILE_EDIT_PERMS, {
                url: '/userProfileEditPermissions',
                templateUrl: '/src/home/admin/userProfileManagement/_views/userProfileEditPermissions.html',
                controller: 'UserProfileEditPermissionsController',
                controllerAs: 'vm',
                data: {
                    displayName: 'User Profile Edit Permissions'
                }
            });
    }

    static factory($stateProvider, $urlRouterProvider, StateConstants) {
        Router.instance = new Router($stateProvider, $urlRouterProvider, StateConstants);
        return Router.instance;
    }
}

Router.factory.$inject = ['$stateProvider', '$urlRouterProvider', 'StateConstants'];

export default Router;