import {UserProfileRegistration} from "../../../../_models/userProfileRegistration.model";
import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {UserProfile} from '../../../../_models/userProfile.model';
import {DmlesPanelTableColumns} from "../../../../_models/dmlesPanelTableColumns.model";

export class UserProfileManagementController {
    private controllerName: string = "UserProfileManagementController";

    public pendingUsersInitialSort:any = { lastName: "asc" };
    public pendingUsersCols:DmlesPanelTableColumns[] =  [
        { title: 'ID', field: 'id', show: false, sortable: 'id', type: 'text', filter: null,  filterData: null },
        { title: 'Last Name', field: 'lastName', show: true, sortable: 'lastName', type: 'text', filter: null,  filterData: null },
        { title: 'First Name', field: 'firstName', show: true, sortable: 'firstName', type: 'text', filter: null,  filterData: null },
        { title: 'Email', field: 'email', show: true, sortable: 'email', type: 'text', filter: null,  filterData: null }
    ];

    public activeInactiveSelections:Array<any> = [{ id: '', title: "Any"}, { id: 'active', title: "Active"}, { id: 'inactive', title: "Inactive"}];
    public trueFalseSelections:Array<any> = [{ id: '', title: "Any"}, { id: 'true', title: "True"}, { id: 'false', title: "False"}];

    public userInitialSort:any = { pkiDn: "asc" };
    public usersCols:DmlesPanelTableColumns[] =  [
        { title: 'ID', field: 'id', show: false, sortable: 'id', type: 'text', filter: null,  filterData: null },
        { title: 'PKI DN', field: 'pkiDn', show: true, sortable: 'pkiDn', type: 'text', filter: { 'pkiDn': 'text' },  filterData: null },
        { title: 'Last Name', field: 'lastName', show: true, sortable: 'lastName', type: 'text', filter: { 'lastName': 'text' },  filterData: null },
        { title: 'First Name', field: 'firstName', show: true, sortable: 'firstName', type: 'text', filter: { 'firstName': 'text' },  filterData: null },
        { title: 'Email', field: 'email', show: true, sortable: 'email', type: 'text', filter: { 'email': 'text' },  filterData: null },
        { title: 'Profile Name', field: 'profileName', show: true, sortable: 'profileName', type: 'text', filter: { 'profileName': 'text' },  filterData: null },
        { title: 'Current Profile', field: 'current', show: true, sortable: 'current', type: 'titleCase', filter: { 'current': 'select' }, filterData: this.trueFalseSelections },
        { title: 'Last Login', field: 'lastLoginDate', show: true, sortable: 'lastLoginDate', type: 'date', filter: { 'lastLoginDate': 'text' },  filterData: null },
        { title: 'Status', field: 'userStatus', show: true, sortable: 'userStatus', type: 'titleCase', filter: { userStatus: 'select' }, filterData: this.activeInactiveSelections }
    ];

    // @ngInject
    constructor(private $log, private $state, private $timeout, private StateConstants, public UserProfileManagementService, private UserProfileService) {
        this.$log.debug("%s - Start", this.controllerName);
        this.init();
    }

    private init() {
        this.UserProfileManagementService.loadRegistrationData();
        this.UserProfileManagementService.loadAuthorizedUsersData();
    }

    public getCustomClass(rowData:UserProfile) {
        this.$log.debug("Get Class called");
        var cssClass:string;
        if(rowData.userStatus == "Denied"){
            cssClass = "danger";
        }

        if(rowData.userStatus == "Inactive"){
            cssClass = "gray-color";
        }
        return cssClass;
    }

    public regRefreshClick(): void {
        this.$log.debug("%s - Reg refresh clicked", this.controllerName);
        this.UserProfileManagementService.loadRegistrationData();
    }

    public userRefreshClick(): void {
        this.$log.debug("%s - User refresh clicked", this.controllerName);
        this.UserProfileManagementService.loadAuthorizedUsersData();
    }

    // TODO: Currently combining the UserProfile and the PendingUserProfile, this is risky.
    // They should be separated.
    public regRowClick(rowData:UserProfileRegistration): void {
        //this.$log.debug("Row clicked: %s", JSON.stringify(rowData));
        this.UserProfileManagementService.setUserProfile(rowData);
        this.$state.go(this.StateConstants.ADMIN_USER_PROFILE_VIEW);
    }

    // TODO: Currently combining the UserProfile and the PendingUserProfile, this is risky.
    // They should be separated.
    public userRowClick(rowData:UserProfile): void {
        //this.$log.debug("Row clicked: %s", JSON.stringify(rowData));
        this.UserProfileManagementService.setUserProfile(rowData);
        this.$state.go(this.StateConstants.ADMIN_USER_PROFILE_VIEW);
    }

}