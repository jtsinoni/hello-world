import {UserProfileRegistration} from "../../../../_models/userProfileRegistration.model";
import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {UserProfile} from '../../../../_models/userProfile.model';

export class UserProfileManagementController {
    private controllerName: string = "UserProfileManagementController";

    public pendingRegGridOpts:any = {};
    public userProfileGridOpts:any = {};

    public activeInactiveSelections:Array<any> = [{ value: 'ACTIVE', label: "Active"}, { value: 'INACTIVE', label: "Inactive"}];
    public yesNoSelections:Array<any> = [{ value: 'true', label: "Yes"}, { value: 'false', label: "No"}];

    // @ngInject
    constructor(private $log, private $state, private $timeout, private ContentConstants, private StateConstants, public UserProfileManagementService, private uiGridConstants, private UserProfileService) {
        this.$log.debug("%s - Start", this.controllerName);
        this.buildPendingRegGridOpts();
        this.buildUserProfileGridOpts();
        this.getData();
    }

    private buildPendingRegGridOpts(){
        this.pendingRegGridOpts = {
            data: null,
            enableCellEditOnFocus: false,
            enableColumnResizing: false,
            enableFiltering: true,
            enableGridMenu: true,
            enablePaginationControls: false,
            enableRowHeaderSelection: false,
            enableRowSelection: true,
            enableSelectAll: true,
            enableSorting: true,
            exporterCsvFilename: 'registrations.csv',
            multiSelect: true,
            showColumnFooter: false,
            showGridFooter:true,
            columnDefs: [
                { field: 'id', displayName: 'id', visible: false, },
                { field: 'lastName', displayName: 'Last Name' },
                { field: 'firstName', displayName: 'First Name' },
                { field: 'email', displayName: 'Email' },
                { field: 'accessRequestedDate', displayName: 'Request Date', cellFilter: 'date:"'+this.ContentConstants.FORMAT_DATE_TIME+'"', filterCellFiltered:true, sort: { direction: this.uiGridConstants.DESC }  }
            ]
        };
    }

    private buildUserProfileGridOpts(){
        this.userProfileGridOpts = {
            data: null,
            enableCellEditOnFocus: false,
            enableColumnResizing: false,
            enableFiltering: true,
            enableGridMenu: true,
            enablePaginationControls: true,
            enableRowHeaderSelection: false,
            enableRowSelection: true,
            enableSelectAll: true,
            enableSorting: true,
            exporterCsvFilename: 'user-profiles.csv',
            multiSelect: false,
            showColumnFooter: false,
            showGridFooter:true,
            columnDefs: [
                { field: 'id', displayName: 'id', visible: false },
                { field: 'pkiDn', displayName: 'PKI DN' },
                { field: 'lastName', displayName: 'Last Name', sort: { direction: this.uiGridConstants.ASC } },
                { field: 'firstName', displayName: 'First Name' },
                { field: 'email', displayName: 'Email' },
                { field: 'profileName', displayName: 'Profile Name' },
                { field: 'current', displayName: 'Current Profile', width: '125',
                    cellTemplate: "<div class='ui-grid-cell-contents'><div ng-if='COL_FIELD' class='text-center'><i class='fa fa-check-square'></i></div></div>",
                    cellClass: function(grid, row, col, rowRenderIndex, colRenderIndex) {
                        if (grid.getCellValue(row,col) === true) {
                            return 'green';
                        }
                    },
                    filter: {
                        type: this.uiGridConstants.filter.SELECT,
                        selectOptions: this.yesNoSelections
                    }
                },
                { field: 'lastLoginDate', displayName: 'Last Login', width: '135', cellFilter: 'date:"'+this.ContentConstants.FORMAT_DATE_TIME+'"', filterCellFiltered:true  },
                { field: 'userStatus', displayName: 'Status', width: '125',
                    cellTemplate: "<div class='ui-grid-cell-contents'>{{ COL_FIELD | dmlesTitleCaseFilter }}</div>",
                    cellClass: function(grid, row, col, rowRenderIndex, colRenderIndex) {
                        if (grid.getCellValue(row,col) === 'ACTIVE') {
                            return 'green';
                        } else if (grid.getCellValue(row,col) === 'INACTIVE') {
                            return 'red'
                        }
                    },
                   filter: {
                        term: 'ACTIVE',
                        condition: this.uiGridConstants.filter.EXACT,
                        type: this.uiGridConstants.filter.SELECT,
                        selectOptions: this.activeInactiveSelections
                   }
                }
            ]
        };
    }

    private getData() {
        this.UserProfileManagementService.loadRegistrationData();
        this.UserProfileManagementService.loadAuthorizedUsersData();
    }

    public regRefreshClick(): void {
        this.$log.debug("%s - Reg refresh clicked", this.controllerName);
        this.UserProfileManagementService.loadRegistrationData();
    }

    public userProfileRefreshClick(): void {
        this.$log.debug("%s - User refresh clicked", this.controllerName);
        this.UserProfileManagementService.loadAuthorizedUsersData();
    }

    // TODO: Currently combining the UserProfile and the PendingUserProfile, this is risky.
    // They should be separated.
    public regRowClick(rowData:UserProfileRegistration): void {
        //this.$log.debug("Row clicked: %s", JSON.stringify(rowData));
        this.UserProfileManagementService.setUserProfile(rowData);
        this.$state.go(this.StateConstants.ADMIN_USER_PROFILE_VIEW);
    }

    // TODO: Currently combining the UserProfile and the PendingUserProfile, this is risky.
    // They should be separated.
    public userProfileRowClick(rowData:UserProfile): void {
        //this.$log.debug("Row clicked: %s", JSON.stringify(rowData));
        this.UserProfileManagementService.refreshUserProfile(rowData);
        this.$state.go(this.StateConstants.ADMIN_USER_PROFILE_VIEW);
    }

}