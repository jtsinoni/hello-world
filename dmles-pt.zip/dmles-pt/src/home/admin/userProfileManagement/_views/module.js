define(["require", "exports", './userProfileEditGenInfo.controller', './userProfileEditPermissions.controller', './userProfileEditRoles.controller', './userProfileManagement.controller', './userProfileView.controller'], function (require, exports, userProfileEditGenInfo_controller_1, userProfileEditPermissions_controller_1, userProfileEditRoles_controller_1, userProfileManagement_controller_1, userProfileView_controller_1) {
    'use strict';
    var controllersModule = angular.module('Dmles.Admin.UserManagement.Views.Module', []);
    controllersModule.controller('Dmles.Admin.UserProfileManagement.Views.UserProfileEditGenInfoController', userProfileEditGenInfo_controller_1.UserProfileEditGenInfoController);
    controllersModule.controller('Dmles.Admin.UserProfileManagement.Views.UserProfileEditPermissionsController', userProfileEditPermissions_controller_1.UserProfileEditPermissionsController);
    controllersModule.controller('Dmles.Admin.UserProfileManagement.Views.UserProfileEditRolesController', userProfileEditRoles_controller_1.UserProfileEditRolesController);
    controllersModule.controller('Dmles.Admin.UserProfileManagement.Views.UserProfileManagementController', userProfileManagement_controller_1.UserProfileManagementController);
    controllersModule.controller('Dmles.Admin.UserProfileManagement.Views.UserProfileViewController', userProfileView_controller_1.UserProfileViewController);
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = controllersModule;
});
//# sourceMappingURL=module.js.map