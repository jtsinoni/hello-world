define(["require", "exports"], function (require, exports) {
    "use strict";
    var UserProfileViewController = (function () {
        // @ngInject
        function UserProfileViewController($log, $state, RoleManagementService, StateConstants, UserProfileService, UserProfileManagementService) {
            this.$log = $log;
            this.$state = $state;
            this.RoleManagementService = RoleManagementService;
            this.StateConstants = StateConstants;
            this.UserProfileService = UserProfileService;
            this.UserProfileManagementService = UserProfileManagementService;
            this.controllerName = "User Profile View Controller";
            this.isPendingUserProfile = false;
            this.userProfile = null;
            this.init();
        }
        UserProfileViewController.prototype.init = function () {
            this.$log.debug("%s - Start", this.controllerName);
            this.userProfile = this.UserProfileManagementService.getUserProfile();
            if (this.userProfile === null) {
                this.goToUserProfileAdmin();
            }
            else {
                // Check if userProfile is an Approved UserProfile or a Pending UserProfile
                if (this.userProfile.userStatus === null || this.userProfile.userStatus === "PENDING") {
                    // UserProfile is pending, initially show edit
                    this.isPendingUserProfile = true;
                }
                else {
                    this.isPendingUserProfile = false;
                }
                this.initializeAssignedPermissions();
            }
        };
        UserProfileViewController.prototype.initializeAssignedPermissions = function () {
            this.RoleManagementService.clearPermissionGroups();
            // Loop through the user profile's assignedPermissions and create updatedAssignedPermissions that
            // include both allowed and denied Booleans - for internal use in GUI
            var updatedAssignedPermissions = [];
            angular.forEach(this.userProfile.assignedPermissions, function (perm) {
                var opt = {
                    "id": perm.id,
                    "name": perm.name,
                    "description": perm.permission.description,
                    "functionalArea": perm.permission.functionalArea,
                    "allowed": perm.allowed,
                    "denied": !perm.allowed,
                    "permission": perm.permission
                };
                updatedAssignedPermissions.push(opt);
            });
            this.buildDisplayedPermissionCollections("VIEW", updatedAssignedPermissions);
        };
        UserProfileViewController.prototype.buildDisplayedPermissionCollections = function (typeOfDisplay, updatedAssignedPermissions) {
            this.RoleManagementService.populatePermissionGroups(typeOfDisplay, updatedAssignedPermissions);
        };
        UserProfileViewController.prototype.activateUserProfile = function () {
            this.userProfile.userStatus = "ACTIVE";
            this.saveUserProfileGeneralInfo();
        };
        UserProfileViewController.prototype.deactivateUserProfile = function () {
            this.userProfile.userStatus = "INACTIVE";
            this.saveUserProfileGeneralInfo();
        };
        UserProfileViewController.prototype.saveUserProfileGeneralInfo = function () {
            var _this = this;
            this.UserProfileService.saveUserProfileData(this.userProfile).then(function (response) {
                _this.userProfile = response.data;
                _this.UserProfileManagementService.setUserProfile(_this.userProfile);
                _this.init();
                _this.$state.go(_this.StateConstants.ADMIN_USER_PROFILE_VIEW);
            }, function (errResponse) {
                _this.$log.error("%s - Error saving userProfile general information, err: %s", _this.controllerName, errResponse);
            });
        };
        UserProfileViewController.prototype.approveUserProfile = function () {
            var _this = this;
            this.UserProfileService.approveUserProfile(this.userProfile).then(function (response) {
                _this.userProfile = response.data;
                _this.UserProfileManagementService.setUserProfile(_this.userProfile);
                _this.init();
                _this.UserProfileManagementService.loadRegistrationData();
                _this.UserProfileManagementService.loadAuthorizedUsersData();
                _this.$state.go(_this.StateConstants.ADMIN_USER_PROFILE_VIEW);
            }, function (errResponse) {
                _this.$log.error("%s - Error approving userProfile, err: %s", _this.controllerName, errResponse);
            });
        };
        UserProfileViewController.prototype.denyUserProfile = function () {
            var _this = this;
            this.UserProfileService.denyUserProfile(this.userProfile).then(function (response) {
                _this.userProfile = response.data;
                _this.UserProfileManagementService.loadRegistrationData();
                _this.UserProfileManagementService.loadAuthorizedUsersData();
                _this.$state.go(_this.StateConstants.ADMIN_USER_PROFILE_MNG);
            }, function (errResponse) {
                _this.$log.error("%s - Error denying userProfile, err: %s", _this.controllerName, errResponse);
            });
        };
        UserProfileViewController.prototype.goToUserProfileAdmin = function () {
            this.$state.go(this.StateConstants.ADMIN_USER_PROFILE_MNG);
        };
        UserProfileViewController.prototype.goToEditUserProfileGeneralInfo = function () {
            this.$state.go(this.StateConstants.ADMIN_USER_PROFILE_EDIT_GEN_INFO);
        };
        UserProfileViewController.prototype.goToEditUserProfileRoles = function () {
            this.$state.go(this.StateConstants.ADMIN_USER_PROFILE_EDIT_ROLES);
        };
        UserProfileViewController.prototype.goToEditUserProfilePermissions = function () {
            this.$state.go(this.StateConstants.ADMIN_USER_PROFILE_EDIT_PERMS);
        };
        return UserProfileViewController;
    }());
    exports.UserProfileViewController = UserProfileViewController;
});
//# sourceMappingURL=userProfileView.controller.js.map