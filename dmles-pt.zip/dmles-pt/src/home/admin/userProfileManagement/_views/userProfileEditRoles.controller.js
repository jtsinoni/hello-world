define(["require", "exports"], function (require, exports) {
    'use strict';
    var UserProfileEditRolesController = (function () {
        // @ngInject
        function UserProfileEditRolesController($log, $state, RoleService, UserProfileManagementService, UserProfileService, StateConstants) {
            this.$log = $log;
            this.$state = $state;
            this.RoleService = RoleService;
            this.UserProfileManagementService = UserProfileManagementService;
            this.UserProfileService = UserProfileService;
            this.StateConstants = StateConstants;
            this.userProfileRolesChanged = false;
            this.controllerName = "User Profile Edit Roles Controller";
            this.userProfile = null;
            this.allRoles = [];
            this.roleOpts = [];
            this.errorMsg = "";
            this.click = false;
            this.init();
        }
        /**
         Initializes the page
         */
        UserProfileEditRolesController.prototype.init = function () {
            this.$log.debug("%s - Start", this.controllerName);
            this.userProfile = this.UserProfileManagementService.getUserProfile();
            if (this.userProfile === null) {
                //no userProfile, go back
                this.UserProfileManagementService.goToUserProfileView();
            }
            else {
            }
            this.initializeRoles();
        };
        /**
         Initializes the page
         */
        UserProfileEditRolesController.prototype.initializeRoles = function () {
            this.loadRoleData();
        };
        /**
         Fetches all roles from the database
         //TODO put correct type for 'result'
         */
        UserProfileEditRolesController.prototype.loadRoleData = function () {
            var _this = this;
            this.RoleService.getAllRoles().then(function (response) {
                // this.$log.debug("%s - Roles Returned: %s", this.controllerName, JSON.stringify(response.data));
                _this.allRoles = response.data;
                _this.allRoles = _this.sortAllRoles();
                // this.$log.debug("%s, Roles Returned: %s", this.controllerName, JSON.stringify(this.allRoles));
                //populate checkbox
                for (var r in _this.allRoles) {
                    var role = _this.allRoles[r];
                    var selected = false;
                    //pre-select userProfile roles
                    for (var s in _this.userProfile.roles) {
                        var userProfileRole = _this.userProfile.roles[s];
                        if (role.id === userProfileRole.id) {
                            selected = true;
                        }
                    }
                    _this.roleOpts.push({
                        "id": role.id,
                        "name": role.name,
                        "selected": selected,
                        "readOnly": role.systemRole
                    });
                }
                // this.$log.debug("this.roleOpts: %s", JSON.stringify(this.roleOpts));
            }, function (errResponse) {
                _this.$log.error("Error retrieving all roles");
            });
        };
        UserProfileEditRolesController.prototype.sortAllRoles = function () {
            return this.allRoles.sort();
        };
        /**
         Validates the userProfile, sets the access approved time and updates the userProfile in the database.
         */
        UserProfileEditRolesController.prototype.onSubmit = function () {
            this.validateUserProfileRoles();
        };
        UserProfileEditRolesController.prototype.validateUserProfileRoles = function () {
            this.userProfileRolesChanged = false;
            var userProfileUpdate = angular.copy(this.userProfile);
            // this.$log.debug("userProfileUpdate: %s", JSON.stringify(userProfileUpdate));
            // Validate UserProfile
            var isValid = this.validateUserProfile("is required");
            if (isValid) {
                // Add roles
                userProfileUpdate.roles = [];
                for (var r in this.roleOpts) {
                    var roleOpt = this.roleOpts[r];
                    if (roleOpt.selected === true) {
                        // Add role id to userProfile role array
                        userProfileUpdate.roles.push(this.retrieveRoleFromAllRoles(roleOpt.id));
                    }
                }
                this.saveUserProfileRoles(userProfileUpdate);
            }
            else {
                this.$log.debug("%s - Error validating userProfile", this.controllerName);
            }
        };
        UserProfileEditRolesController.prototype.saveUserProfileRoles = function (userProfileUpdate) {
            var _this = this;
            // this.$log.debug("%s - Submitting UserProfile:", this.controllerName, userProfileUpdate);
            this.UserProfileService.saveUserProfileRoles(userProfileUpdate).then(function (response) {
                // this.$log.debug("%s - Saved UserProfile Returned: %s", this.controllerName, JSON.stringify(response.data));
                _this.userProfile = response.data;
                _this.UserProfileManagementService.setUserProfile(_this.userProfile);
                _this.UserProfileManagementService.loadAuthorizedUsersData();
                _this.UserProfileManagementService.goToUserProfileView();
            }, function (errResponse) {
                _this.$log.error("Error updating userProfile roles");
            });
        };
        /**
         Checks to see if a role has been selected
         @returns - a boolean - true if a role has been selected, otherwise false
         */
        UserProfileEditRolesController.prototype.validateUserProfile = function (suffix) {
            var retval = true;
            this.errorMsg = "";
            // Check for Role Selection
            var roleSelected = false;
            for (var r in this.roleOpts) {
                var role = this.roleOpts[r];
                if (role.selected === true) {
                    roleSelected = true;
                }
            }
            if (!roleSelected) {
                this.errorMsg = "Role selection " + suffix;
                retval = false;
            }
            return retval;
        };
        UserProfileEditRolesController.prototype.retrieveRoleFromAllRoles = function (roleId) {
            var returnValue = {};
            angular.forEach(this.allRoles, function (role) {
                if (roleId === role.id) {
                    returnValue = role;
                }
            });
            return returnValue;
        };
        UserProfileEditRolesController.prototype.buttonClicked = function () {
            this.click = !this.click;
        };
        return UserProfileEditRolesController;
    }());
    exports.UserProfileEditRolesController = UserProfileEditRolesController;
});
//# sourceMappingURL=userProfileEditRoles.controller.js.map