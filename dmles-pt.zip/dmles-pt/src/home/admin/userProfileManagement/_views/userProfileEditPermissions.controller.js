define(["require", "exports"], function (require, exports) {
    'use strict';
    var UserProfileEditPermissionsController = (function () {
        // @ngInject
        function UserProfileEditPermissionsController($log, $state, RoleManagementService, RoleService, UserProfileService, UserProfileManagementService, StateConstants) {
            this.$log = $log;
            this.$state = $state;
            this.RoleManagementService = RoleManagementService;
            this.RoleService = RoleService;
            this.UserProfileService = UserProfileService;
            this.UserProfileManagementService = UserProfileManagementService;
            this.StateConstants = StateConstants;
            this.userProfilePermissionsChanged = false;
            this.controllerName = "User Profile Edit Permissions Controller";
            this.userProfile = null;
            this.allPermissions = [];
            this.updatedAllPermissions = [];
            this.updatedAssignedPermissions = [];
            this.init();
        }
        /**
         Initializes the page
         */
        UserProfileEditPermissionsController.prototype.init = function () {
            this.$log.debug("%s - Start", this.controllerName);
            this.userProfile = this.UserProfileManagementService.getUserProfile();
            if (this.userProfile === null) {
                //no userProfile, go back
                this.UserProfileManagementService.goToUserProfileView();
            }
            else {
                // this.$log.debug("this.userProfile: %s", JSON.stringify(this.userProfile));
                this.initializePermissions();
            }
        };
        /**
         Initialize the permissions
         */
        UserProfileEditPermissionsController.prototype.initializePermissions = function () {
            var _this = this;
            // The database just keeps allowed status for an assigned permission - this.userProfile.assignedPermissions
            // The GUI code will contain and track allowed and denied both - this.assignedPermissions
            angular.forEach(this.userProfile.assignedPermissions, function (perm) {
                var opt = {
                    "id": perm.id,
                    "name": perm.name,
                    "allowed": perm.allowed,
                    "denied": !perm.allowed
                };
                _this.updatedAssignedPermissions.push(opt);
            });
            // this.$log.debug("this.updatedAssignedPermissions: %s", JSON.stringify(this.updatedAssignedPermissions));
            this.getAllPermissionsAndBuildPermissionCollections();
        };
        UserProfileEditPermissionsController.prototype.getAllPermissionsAndBuildPermissionCollections = function () {
            var _this = this;
            this.RoleService.getAllPermissions().then(function (response) {
                // this.$log.debug("%s - Permissions Returned: %s", this.controllerName, JSON.stringify(response.data));
                // permissions come in using hierarchical structure (per TS)
                // we actually want them sans the hierarchical structure - so convert
                angular.forEach(response.data, function (element) {
                    angular.forEach(element.permissions, function (permission) {
                        _this.allPermissions.push(permission);
                    });
                });
                // this.$log.debug("this.allPermissions: %s", JSON.stringify(this.allPermissions));
                // update the retrieved list of all permissions with the correct
                // allowed and denied settings - updatedAllPermissions - for display on Edit Permissions page
                angular.forEach(_this.allPermissions, function (perm) {
                    var opt = {
                        "id": perm.id,
                        "name": perm.name,
                        "description": perm.description,
                        "functionalArea": perm.functionalArea,
                        "allowed": _this.retrieveFieldValueFromAssignedPermissions(perm.name, "allowed"),
                        "denied": _this.retrieveFieldValueFromAssignedPermissions(perm.name, "denied"),
                        "active": perm.active
                    };
                    _this.updatedAllPermissions.push(opt);
                });
                // List of all permissions with the correct allowed and denied settings for the selected Role
                // this.$log.debug("this.updatedAllPermissions: %s", JSON.stringify(this.updatedAllPermissions));
                _this.buildDisplayedPermissionCollections("EDIT", _this.updatedAllPermissions);
            }, function (errResponse) {
                _this.$log.error("Error retrieving all permissions");
            });
        };
        UserProfileEditPermissionsController.prototype.buildDisplayedPermissionCollections = function (typeOfDisplay, updatedAllPermissions) {
            this.RoleManagementService.populatePermissionGroups(typeOfDisplay, updatedAllPermissions);
        };
        UserProfileEditPermissionsController.prototype.retrieveFieldValueFromAssignedPermissions = function (field, fieldValue) {
            var returnValue = false;
            angular.forEach(this.updatedAssignedPermissions, function (perm) {
                if (field === perm.name) {
                    returnValue = perm[fieldValue];
                }
            });
            return returnValue;
        };
        /**
         Updates the user profile, if it is valid, and returns to the User Profile Management state
         */
        UserProfileEditPermissionsController.prototype.onSubmit = function () {
            // this.$log.debug("this.RoleManagementService.getAdminPermCollection(): %s", JSON.stringify(this.RoleManagementService.getAdminPermCollection()));
            // this.$log.debug("this.RoleManagementService.getEquipmentPermCollection(): %s", JSON.stringify(this.RoleManagementService.getEquipmentPermCollection()));
            // this.$log.debug("this.RoleManagementService.getOtherPermCollection(): %s", JSON.stringify(this.RoleManagementService.getOtherPermCollection()));
            var _this = this;
            // build Role's assignedPermissions to include any with either Allowed or Denied checked and set the correct allowed setting
            var selectedPermissions = this.getSelectedPerms();
            // this.$log.debug("selectedPermissions: %s", JSON.stringify(selectedPermissions));
            var assignedPermissions = [];
            angular.forEach(selectedPermissions, function (perm) {
                var assignedPermission = {
                    name: perm.name,
                    allowed: perm.allowed,
                    permission: _this.retrievePermissionFromAllPermissions(perm.id)
                };
                assignedPermissions.push(assignedPermission);
            });
            // this.$log.debug("assignedPermissions: %s", JSON.stringify(assignedPermissions));
            // this.$log.debug("this.userProfile.assignedPermissions: %s", JSON.stringify(this.userProfile.assignedPermissions));
            this.userProfile.assignedPermissions = assignedPermissions;
            // this.$log.debug("this.userProfile.assignedPermissions: %s", JSON.stringify(this.userProfile.assignedPermissions));
            this.saveUserProfilePermissions();
            this.UserProfileManagementService.goToUserProfileView();
        };
        /**
         Checks each PermCollection in the given array of PermCollections to determine what permissions
         have been selected
         @returns - an array of ids for the selected permissions
         */
        UserProfileEditPermissionsController.prototype.getSelectedPerms = function () {
            var permCollections = [
                this.RoleManagementService.getAdminPermCollection(),
                this.RoleManagementService.getEquipmentPermCollection(),
                this.RoleManagementService.getOtherPermCollection()];
            var selPerms = [];
            angular.forEach(permCollections, function (permCollection) {
                angular.forEach(permCollection.allPermOpts, function (permOpt) {
                    if (permOpt.allowed || permOpt.denied) {
                        selPerms.push(permOpt);
                    }
                });
            });
            return selPerms;
        };
        UserProfileEditPermissionsController.prototype.retrievePermissionFromAllPermissions = function (permId) {
            var returnValue = {};
            angular.forEach(this.allPermissions, function (perm) {
                if (permId === perm.id) {
                    returnValue = perm;
                }
            });
            return returnValue;
        };
        UserProfileEditPermissionsController.prototype.saveUserProfilePermissions = function () {
            var _this = this;
            this.userProfilePermissionsChanged = false;
            // this.$log.debug("Saving this.userProfile: %s", JSON.stringify(this.userProfile));
            this.UserProfileService.saveUserProfilePermissions(this.userProfile).then(function (response) {
                // this.$log.debug("%s - Saved UserProfile Returned: %s", this.controllerName, JSON.stringify(response.data));
                _this.userProfile = response.data;
                _this.UserProfileManagementService.setUserProfile(_this.userProfile);
            }, function (errResponse) {
                _this.$log.error("Error saving userProfile permissions");
            });
        };
        return UserProfileEditPermissionsController;
    }());
    exports.UserProfileEditPermissionsController = UserProfileEditPermissionsController;
});
//# sourceMappingURL=userProfileEditPermissions.controller.js.map