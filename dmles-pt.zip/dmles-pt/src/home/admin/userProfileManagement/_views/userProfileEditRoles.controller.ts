'use strict';

import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {UserProfile} from '../../../../_models/userProfile.model';
import {Role} from "../../../../_models/role.model";

export class UserProfileEditRolesController {
    public userProfileRolesChanged: boolean = false;

    private controllerName: string = "User Profile Edit Roles Controller";
    private userProfile: UserProfile = null;

    private allRoles: Role[] = [];
    private roleOpts: any[] = [];
    private errorMsg: string = "";

    private click: boolean = false;

    // @ngInject
    constructor(private $log, private $state, private RoleService, private UserProfileManagementService,
                private UserProfileService, private StateConstants) {

        this.init();
    }

    /**
     Initializes the page
     */
    private init() {
        this.$log.debug("%s - Start", this.controllerName);
        this.userProfile = this.UserProfileManagementService.getUserProfile();


        if (this.userProfile === null) {
            //no userProfile, go back
            this.UserProfileManagementService.goToUserProfileView();
        } else {
            // this.$log.debug("this.userProfile: %s", JSON.stringify(this.userProfile));
        }

        this.initializeRoles();
    }

    /**
     Initializes the page
     */
    private initializeRoles() {
        this.loadRoleData();
    }

    /**
     Fetches all roles from the database
     //TODO put correct type for 'result'
     */
    private loadRoleData() {
        this.RoleService.getAllRoles().then((response: IHttpPromiseCallbackArg<Role[]>) => {
            // this.$log.debug("%s - Roles Returned: %s", this.controllerName, JSON.stringify(response.data));
            this.allRoles = response.data;
            this.allRoles = this.sortAllRoles();

            // this.$log.debug("%s, Roles Returned: %s", this.controllerName, JSON.stringify(this.allRoles));

            //populate checkbox
            for (let r in this.allRoles) {
                let role: Role = this.allRoles[r];
                let selected: boolean = false;

                //pre-select userProfile roles
                for (let s in this.userProfile.roles) {
                    let userProfileRole: Role = this.userProfile.roles[s];
                    if (role.id === userProfileRole.id) {
                        selected = true;
                    }
                }

                this.roleOpts.push({
                    "id": role.id,
                    "name": role.name,
                    "selected": selected,
                    "readOnly":role.systemRole
                });
            }
            // this.$log.debug("this.roleOpts: %s", JSON.stringify(this.roleOpts));
        }, (errResponse: IHttpPromiseCallbackArg<Role[]>) => {
            this.$log.error("Error retrieving all roles");            
        });
    }

    private sortAllRoles(): Role [] {
        return this.allRoles.sort();
    }

    /**
     Validates the userProfile, sets the access approved time and updates the userProfile in the database.
     */
    private onSubmit() {
        this.validateUserProfileRoles();
    }

    public validateUserProfileRoles() {
        this.userProfileRolesChanged = false;

        let userProfileUpdate: UserProfile = angular.copy(this.userProfile);
        // this.$log.debug("userProfileUpdate: %s", JSON.stringify(userProfileUpdate));

        // Validate UserProfile
        let isValid: boolean = this.validateUserProfile("is required");
        if (isValid) {

            // Add roles
            userProfileUpdate.roles = [];
            for (let r in this.roleOpts) {
                let roleOpt: any = this.roleOpts[r];
                if (roleOpt.selected === true) {
                    // Add role id to userProfile role array
                    userProfileUpdate.roles.push(this.retrieveRoleFromAllRoles(roleOpt.id));
                }
            }
            
            this.saveUserProfileRoles(userProfileUpdate);
            
        } else {
            this.$log.debug("%s - Error validating userProfile", this.controllerName);
            //validateUserProfile should set error message
        }
    }

    public saveUserProfileRoles(userProfileUpdate: UserProfile) {
        // this.$log.debug("%s - Submitting UserProfile:", this.controllerName, userProfileUpdate);
        this.UserProfileService.saveUserProfileRoles(userProfileUpdate).then((response: IHttpPromiseCallbackArg<UserProfile>) => {
            // this.$log.debug("%s - Saved UserProfile Returned: %s", this.controllerName, JSON.stringify(response.data));
            this.userProfile = response.data;
            this.UserProfileManagementService.setUserProfile(this.userProfile);            
            this.UserProfileManagementService.loadAuthorizedUsersData();
            this.UserProfileManagementService.goToUserProfileView();
        }, (errResponse: IHttpPromiseCallbackArg<UserProfile>) => {
            this.$log.error("Error updating userProfile roles");
        });
    }

    /**
     Checks to see if a role has been selected
     @returns - a boolean - true if a role has been selected, otherwise false
     */
    private validateUserProfile(suffix: string) {
        let retval: boolean = true;
        this.errorMsg = "";

        // Check for Role Selection
        let roleSelected: boolean = false;
        for (let r in this.roleOpts) {
            let role: any = this.roleOpts[r];

            if (role.selected === true) {
                roleSelected = true;
            }
        }
        if (!roleSelected) {
            this.errorMsg = "Role selection " + suffix;
            retval = false;
        }
        return retval;
    }

    private retrieveRoleFromAllRoles(roleId: string): any {
        let returnValue = {};
        angular.forEach(this.allRoles, (role) => {
            if (roleId === role.id) {
                returnValue = role;
            }
        });
        return returnValue;
    }

    private buttonClicked() {
        this.click = !this.click;
    }
}