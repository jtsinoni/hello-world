'use strict';

import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {UserProfile} from '../../../../_models/userProfile.model';
import {Role} from "../../../../_models/role.model";
import {RoleFunctionalAreaConfig} from '../../../../_models/roleFunctionalAreaConfig.model';

export class UserProfileEditRolesController {
    public userProfileRolesChanged: boolean = false;

    private controllerName: string = "User Profile Edit Roles Controller";
    private userProfile: UserProfile = null;
    private roleFunctionalAreas:Array<RoleFunctionalAreaConfig> = null;
    private roleCollections: RoleCollection[] = [];

    private allRoles: Role[] = [];
    private roleOpts: any[] = [];
    private errorMsg: string = "";

    private click: boolean = false;

    // @ngInject
    constructor(private $filter, private $log, private $state, private RoleService, private UserProfileManagementService,
                private UserProfileService, private StateConstants) {

        this.init();
    }

    /**
     Initializes the page
     */
    private init() {
        this.$log.debug("%s - Start", this.controllerName);
        this.userProfile = this.UserProfileManagementService.getUserProfile();


        if (this.userProfile === null) {
            //no userProfile, go back
            this.UserProfileManagementService.goToUserProfileView();
        } else {
            // this.$log.debug("this.userProfile: %s", JSON.stringify(this.userProfile));
        }
        this.getRoleFunctionalAreaConfig();
        this.initializeRoles();
    }

    private getRoleFunctionalAreaConfig() {
        if (!this.roleFunctionalAreas) {
            this.RoleService.getRoleFunctionalAreaConfig().then((response: IHttpPromiseCallbackArg<RoleFunctionalAreaConfig[]>) => {
                this.roleFunctionalAreas = response.data;
            }, (errResponse: IHttpPromiseCallbackArg<RoleFunctionalAreaConfig[]>) => {
                this.$log.error("Error retrieving All RoleFunctionalAreaConfig");
            });
        }
    }

    /**
     Initializes the page
     */
    private initializeRoles() {
        this.loadRoleData();
    }

    /**
     Fetches all roles from the database
     //TODO put correct type for 'result'
     */
    private loadRoleData() {
        this.RoleService.getAllRoles().then((response: IHttpPromiseCallbackArg<Role[]>) => {
            // this.$log.debug("%s - Roles Returned: %s", this.controllerName, JSON.stringify(response.data));
            this.allRoles = response.data;

            //populate checkbox
            for (let r in this.allRoles) {
                let role: Role = this.allRoles[r];
                let allowed: boolean = false;

                //pre-select userProfile roles
                for (let s in this.userProfile.roles) {
                    let userProfileRole: Role = this.userProfile.roles[s];
                    if (role.id === userProfileRole.id) {
                        allowed = true;
                    }
                }


                this.roleOpts.push({
                    "id": role.id,
                    "name": role.name,
                    "allowed": allowed,
                    "readOnly":role.systemRole,
                    "functionalArea":role.functionalArea
                });
            }
            this.populateRoleGroups('EDIT', this.roleOpts);
            // this.$log.debug("this.roleOpts: %s", JSON.stringify(this.roleOpts));
        }, (errResponse: IHttpPromiseCallbackArg<Role[]>) => {
            this.$log.error("Error retrieving all roles");            
        });
    }

    private createDisplayedRolesForAGivenCollection(filteredRolesBelongingToACollection: any[],
                                                          type: string): any[] {

        let displayedPermissionsForAGivenCollection: any[] = [];

        if (type === "CREATE") {
            angular.forEach(filteredRolesBelongingToACollection, (perm) => {
                let opt: any = {
                    "id": perm.id,
                    "name": perm.name,
                    "allowed": false,
                    "active": perm.active,
                    "description": perm.description,
                    "functionalArea": perm.functionalArea,
                };

                displayedPermissionsForAGivenCollection.push(opt);
            });
        } else if (type === "VIEW") {
            angular.forEach(filteredRolesBelongingToACollection, (perm) => {
                let opt: any = {
                    "id": perm.id,
                    "name": perm.name,
                    "allowed": perm.allowed,
                    "active": perm.active,
                    "description": perm.description,
                    "functionalArea": perm.functionalArea,
                };

                displayedPermissionsForAGivenCollection.push(opt);
            });
        } else if (type === "EDIT") {
            angular.forEach(filteredRolesBelongingToACollection, (perm) => {
                let opt: any = {
                    "id": perm.id,
                    "name": perm.name,
                    "allowed": perm.allowed,
                    "active": perm.active,
                    "description": perm.description,
                    "functionalArea": perm.functionalArea,
                };

                displayedPermissionsForAGivenCollection.push(opt);
            });
        }

        return displayedPermissionsForAGivenCollection;
    }

    private populateRoleGroups(type:string, allRoles: any[]) {

        angular.forEach(this.roleFunctionalAreas, (funcArea) => {
            let perms = this.$filter('filter')(allRoles, {"functionalArea": funcArea.option}, true);
            perms = this.$filter('orderBy')(perms, "name");
            let opts = this.createDisplayedRolesForAGivenCollection(perms, type);
            let permc = new RoleCollection(funcArea.displayName, opts);
            this.roleCollections.push(permc);
        })
    }

    public getRoleCollections () {
        return this.roleCollections;
    }

    private sortAllRoles(): Role [] {
        return this.allRoles.sort();
    }

    /**
     Validates the userProfile, sets the access approved time and updates the userProfile in the database.
     */
    private onSubmit() {
        this.validateUserProfileRoles();
    }

    public validateUserProfileRoles() {
        this.userProfileRolesChanged = false;

        let userProfileUpdate: UserProfile = angular.copy(this.userProfile);
        // this.$log.debug("userProfileUpdate: %s", JSON.stringify(userProfileUpdate));

        // Validate UserProfile
        let isValid: boolean = this.validateUserProfile("is required");
        if (isValid) {

            // Add roles
            userProfileUpdate.roles = [];
            for (let r in this.roleOpts) {
                let roleOpt: any = this.roleOpts[r];
                if (roleOpt.allowed === true) {
                    // Add role id to userProfile role array
                    userProfileUpdate.roles.push(this.retrieveRoleFromAllRoles(roleOpt.id));
                }
            }
            
            this.saveUserProfileRoles(userProfileUpdate);
            
        } else {
            this.$log.debug("%s - Error validating userProfile", this.controllerName);
            //validateUserProfile should set error message
        }
    }

    public saveUserProfileRoles(userProfileUpdate: UserProfile) {
        // this.$log.debug("%s - Submitting UserProfile:", this.controllerName, userProfileUpdate);
        this.UserProfileService.saveUserProfileRoles(userProfileUpdate).then((response: IHttpPromiseCallbackArg<UserProfile>) => {
            // this.$log.debug("%s - Saved UserProfile Returned: %s", this.controllerName, JSON.stringify(response.data));
            this.userProfile = response.data;
            this.UserProfileManagementService.setUserProfile(this.userProfile);            
            this.UserProfileManagementService.loadAuthorizedUsersData();
            this.UserProfileManagementService.goToUserProfileView();
        }, (errResponse: IHttpPromiseCallbackArg<UserProfile>) => {
            this.$log.error("Error updating userProfile roles");
        });
    }

    /**
     Checks to see if a role has been selected
     @returns - a boolean - true if a role has been selected, otherwise false
     */
    private validateUserProfile(suffix: string) {
        let retval: boolean = true;
        this.errorMsg = "";

        // Check for Role Selection
        let roleSelected: boolean = false;
        for (let r in this.roleOpts) {
            let role: any = this.roleOpts[r];

            if (role.allowed === true) {
                roleSelected = true;
            }
        }
        if (!roleSelected) {
            this.errorMsg = "Role selection " + suffix;
            retval = false;
        }
        return retval;
    }

    private retrieveRoleFromAllRoles(roleId: string): any {
        let returnValue = {};
        angular.forEach(this.allRoles, (role) => {
            if (roleId === role.id) {
                returnValue = role;
            }
        });
        return returnValue;
    }

    private buttonClicked() {
        this.click = !this.click;
    }

    public setAllowed(role:any) {
        let id = role.id;
        angular.forEach(this.roleOpts, (roleOpt) =>{
            if (id == roleOpt.id) {
                roleOpt.allowed = !roleOpt.allowed;
            }
        })
    }
}
export class RoleCollection {
    public allOpts: any[] = [];
    public displayName: string = null;

    /**
     @param displayName the display name of the functionalArea to show
     @param allPermOpts an array of objects to be used to create the checkboxes
     */
    constructor(displayName: string, allOpts: any[]) {
        this.displayName = displayName;
        this.allOpts = allOpts;

        // Split Roles into functionalAreas
        // this.splitPermOpts(angular.copy(allPermOpts));
    };
}
