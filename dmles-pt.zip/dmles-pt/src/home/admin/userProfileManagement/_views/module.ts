'use strict';

import {UserProfileEditGenInfoController} from './userProfileEditGenInfo.controller';
import {UserProfileEditPermissionsController} from './userProfileEditPermissions.controller';
import {UserProfileEditRolesController} from './userProfileEditRoles.controller';
import {UserProfileManagementController} from './userProfileManagement.controller';
import {UserProfileViewController} from './userProfileView.controller';

let controllersModule = angular.module('Dmles.Admin.UserManagement.Views.Module', []);
controllersModule.controller('Dmles.Admin.UserProfileManagement.Views.UserProfileEditGenInfoController', UserProfileEditGenInfoController);
controllersModule.controller('Dmles.Admin.UserProfileManagement.Views.UserProfileEditPermissionsController', UserProfileEditPermissionsController);
controllersModule.controller('Dmles.Admin.UserProfileManagement.Views.UserProfileEditRolesController', UserProfileEditRolesController);
controllersModule.controller('Dmles.Admin.UserProfileManagement.Views.UserProfileManagementController', UserProfileManagementController);
controllersModule.controller('Dmles.Admin.UserProfileManagement.Views.UserProfileViewController', UserProfileViewController);

export default controllersModule;

