'use strict';

import {UserProfileEditGenInfoController} from './userProfileEditGenInfo.controller';
import {UserProfileEditPermissionsController} from './userProfileEditPermissions.controller';
import {UserProfileEditRolesController} from './userProfileEditRoles.controller';
import {UserProfileManagementController} from './userProfileManagement.controller';
import {UserProfileViewController} from './userProfileView.controller';

let controllersModule = angular.module('Dmles.Admin.UserManagement.Views.Module', []);
controllersModule.controller('UserProfileEditGenInfoController', UserProfileEditGenInfoController);
controllersModule.controller('UserProfileEditPermissionsController', UserProfileEditPermissionsController);
controllersModule.controller('UserProfileEditRolesController', UserProfileEditRolesController);
controllersModule.controller('UserProfileManagementController', UserProfileManagementController);
controllersModule.controller('UserProfileViewController', UserProfileViewController);

export default controllersModule;

