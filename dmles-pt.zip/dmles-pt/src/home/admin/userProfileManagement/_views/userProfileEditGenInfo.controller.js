define(["require", "exports"], function (require, exports) {
    'use strict';
    var UserProfileEditGenInfoController = (function () {
        // @ngInject
        function UserProfileEditGenInfoController($log, UserProfileService, UserProfileManagementService) {
            this.$log = $log;
            this.UserProfileService = UserProfileService;
            this.UserProfileManagementService = UserProfileManagementService;
            this.userProfileGeneralInfoChanged = false;
            this.controllerName = "User Profile Edit General Information Controller";
            this.userProfile = null;
            this.init();
        }
        /**
         Initializes the page
         */
        UserProfileEditGenInfoController.prototype.init = function () {
            this.$log.debug("%s - Start", this.controllerName);
            this.userProfile = this.UserProfileManagementService.getUserProfile();
            if (this.userProfile === null) {
                //no userProfile, go back
                this.UserProfileManagementService.goToUserProfileView();
            }
            else {
            }
        };
        /**
         Updates the userProfile general information and returns to the userProfile View state
         */
        UserProfileEditGenInfoController.prototype.onSubmit = function () {
            var userProfileEditGenInfo = angular.copy(this.userProfile);
            // this.$log.debug("this.userProfile.lastName: %s", JSON.stringify(this.userProfile.lastName));
            // Save button on GUI only gets enabled when all required data has values - so no need to check here
            this.saveUserProfileGeneralInfo();
            this.UserProfileManagementService.goToUserProfileView();
        };
        UserProfileEditGenInfoController.prototype.saveUserProfileGeneralInfo = function () {
            var _this = this;
            this.userProfileGeneralInfoChanged = false;
            // this.$log.debug("Saving this.userProfile: %s", JSON.stringify(this.userProfile));
            this.UserProfileService.saveUserProfileData(this.userProfile).then(function (response) {
                _this.userProfile = response.data;
                _this.UserProfileManagementService.setUserProfile(_this.userProfile);
                // this.$log.debug("%s - Saved UserProfile Returned: %s", this.controllerName, JSON.stringify(this.userProfile));
            }, function (errResponse) {
                _this.$log.error("Error saving userProfile general information");
            });
        };
        return UserProfileEditGenInfoController;
    }());
    exports.UserProfileEditGenInfoController = UserProfileEditGenInfoController;
});
//# sourceMappingURL=userProfileEditGenInfo.controller.js.map