'use strict';

import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {AssignedPermission} from "../../../../_models/assignedPermission.model";
import {UserProfile} from '../../../../_models/userProfile.model';

export class UserProfileViewController {
    private controllerName: string = "User Profile View Controller";
    private isPendingUserProfile: boolean = false;
    private userProfile: UserProfile = null;

    // @ngInject
    constructor(private $log, private $state, private RoleManagementService, private StateConstants,
                private UserProfileService, private UserProfileManagementService) {
        this.init();
    }

    /**
     Initializes the page
     */
    private init() {
        this.$log.debug("%s - Start", this.controllerName);

        //let userProfile = angular.copy(UserProfileManagementService.getUserProfile());
        //this.$log.debug("userProfile", JSON.stringify(userProfile));

        this.userProfile = this.UserProfileManagementService.getUserProfile();

        if (this.userProfile === null) {
            // no userProfile, return to userProfile admin
            this.goToUserProfileAdmin();
        } else {
            // this.userProfile = userProfile;
            // this.$log.debug("this.userProfile", JSON.stringify(this.userProfile));

            // Check if userProfile is an Approved UserProfile or a Pending UserProfile
            if (this.userProfile.userStatus === null || this.userProfile.userStatus === "PENDING") {
                // UserProfile is pending, initially show edit
                this.isPendingUserProfile = true;
            } else {
                this.isPendingUserProfile = false;
            }
            // this.$log.debug("this.isPendingUserProfile ", this.isPendingUserProfile);

            this.initializeAssignedPermissions();
        }
    }

    /**
     Initializes the assigned permissions
     */
    private initializeAssignedPermissions() {

        this.RoleManagementService.clearPermissionGroups();

        // Loop through the user profile's assignedPermissions and create updatedAssignedPermissions that
        // include both allowed and denied Booleans - for internal use in GUI
        let updatedAssignedPermissions: any[] = [];
        angular.forEach(this.userProfile.assignedPermissions, (perm) => {
            let opt: any = {
                "id": perm.id,
                "name": perm.name,
                "description": perm.permission.description,
                "functionalArea": perm.permission.functionalArea,
                "allowed": perm.allowed,
                "denied": !perm.allowed,
                "permission": perm.permission
            };
            updatedAssignedPermissions.push(opt);
        });
        // this.$log.debug("updatedAssignedPermissions: %s", JSON.stringify(updatedAssignedPermissions));

        this.buildDisplayedPermissionCollections("VIEW", updatedAssignedPermissions);
    }

    private buildDisplayedPermissionCollections(typeOfDisplay: string, updatedAssignedPermissions: Array<AssignedPermission>): void {
        this.RoleManagementService.populatePermissionGroups(typeOfDisplay, updatedAssignedPermissions);
    }

    private activateUserProfile() {
        this.userProfile.userStatus = "ACTIVE";
        this.saveUserProfileGeneralInfo();
    }

    private deactivateUserProfile() {
        this.userProfile.userStatus = "INACTIVE";
        this.saveUserProfileGeneralInfo();
    }

    private saveUserProfileGeneralInfo() {
        // this.$log.debug("Saving this.userProfile: %s", JSON.stringify(this.userProfile));

        this.UserProfileService.saveUserProfileData(this.userProfile).then((response: IHttpPromiseCallbackArg<UserProfile>) => {
            this.userProfile = response.data;
            // this.$log.debug("%s - Saved UserProfile Returned: %s", this.controllerName, JSON.stringify(this.userProfile));
            this.UserProfileManagementService.setUserProfile(this.userProfile);
            this.init();
            // this.$log.debug("%s - Go to userProfileView", this.controllerName);
            this.$state.go(this.StateConstants.ADMIN_USER_PROFILE_VIEW);
        }, (errResponse: IHttpPromiseCallbackArg<UserProfile[]>) => {
            this.$log.error("Error saving userProfile general information");            
        });
    }

    private approveUserProfile() {
        // this.$log.debug("Attempting approval of this.userProfile: %s", JSON.stringify(this.userProfile));

        this.UserProfileService.approveUserProfile(this.userProfile).then((response: IHttpPromiseCallbackArg<UserProfile>) => {
            this.userProfile = response.data;
            // this.$log.debug("%s - Approved UserProfile Returned: %s", this.controllerName, JSON.stringify(this.userProfile));
            this.UserProfileManagementService.setUserProfile(this.userProfile);
            this.init();
            this.UserProfileManagementService.loadPendingUserProfileTable();
            this.UserProfileManagementService.loadAuthorizedUsersData();
            // this.$log.debug("%s - Go to userProfileView", this.controllerName);
            this.$state.go(this.StateConstants.ADMIN_USER_PROFILE_VIEW);
        }, (errResponse: IHttpPromiseCallbackArg<UserProfile[]>) => {
            this.$log.error("Error approving userProfile");            
        });
    }

    private denyUserProfile() {
        // this.$log.debug("Attempting denial of this.userProfile: %s", JSON.stringify(this.userProfile));

        this.UserProfileService.denyUserProfile(this.userProfile).then((response: IHttpPromiseCallbackArg<UserProfile>) => {
            this.userProfile = response.data;
            //this.$log.debug("%s - Denied UserProfile Returned: %s", this.controllerName, JSON.stringify(this.userProfile));
            //this.$log.debug("%s - Go back to userProfileAdmin", this.controllerName);
            this.UserProfileManagementService.loadPendingUserProfileTable();
            this.UserProfileManagementService.loadAuthorizedUsersData();
            this.$state.go(this.StateConstants.ADMIN_USER_PROFILE_MNG);
        }, (errResponse: IHttpPromiseCallbackArg<UserProfile[]>) => {
            this.$log.error("Error denying userProfile");            
        });
    }

    /**
     Return to UserProfile Admin page
     */
    private goToUserProfileAdmin() {
        // this.$log.debug("%s - Go back to userProfileAdmin", this.controllerName);
        //this.UserProfileManagementService.loadPendingUserProfileTable();
        //this.UserProfileManagementService.loadAuthorizedUsersData();
        this.$state.go(this.StateConstants.ADMIN_USER_PROFILE_MNG);
    }

    /**
     Return to User Profile Edit General Information page
     */
    private goToEditUserProfileGeneralInfo() {
        // this.$log.debug("%s - Go to User Profile Edit General Information page", this.controllerName);
        this.$state.go(this.StateConstants.ADMIN_USER_PROFILE_EDIT_GEN_INFO);
    }

    /**
     Return to User Profile Roles page
     */
    private goToEditUserProfileRoles() {
        // this.$log.debug("%s - Go to User Profile Edit Roles page", this.controllerName);
        this.$state.go(this.StateConstants.ADMIN_USER_PROFILE_EDIT_ROLES);
    }

    /**
     Return to User Profile Permissions page
     */
    private goToEditUserProfilePermissions() {
        // this.$log.debug("%s - Go to User Profile Edit Permissions page", this.controllerName);
        this.$state.go(this.StateConstants.ADMIN_USER_PROFILE_EDIT_PERMS);
    }
}