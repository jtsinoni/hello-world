import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {AssignedPermission} from "../../../../_models/assignedPermission.model";
import {UserProfile} from '../../../../_models/userProfile.model';

export class UserProfileViewController {
    private controllerName: string = "User Profile View Controller";
    private isPendingUserProfile: boolean = false;
    private userProfile: UserProfile = null;

    // @ngInject
    constructor(private $log, private $state, private RoleManagementService, private StateConstants,
                private UserProfileService, private UserProfileManagementService) {
        this.init();
    }

    private init() {
        this.$log.debug("%s - Start", this.controllerName);
        this.userProfile = this.UserProfileManagementService.getUserProfile();

        if (this.userProfile === null) {
            this.goToUserProfileAdmin();
        } else {
            // Check if userProfile is an Approved UserProfile or a Pending UserProfile
            if (this.userProfile.userStatus === null || this.userProfile.userStatus === "PENDING") {
                // UserProfile is pending, initially show edit
                this.isPendingUserProfile = true;
            } else {
                this.isPendingUserProfile = false;
            }

            this.initializeAssignedPermissions();
        }
    }

    private initializeAssignedPermissions() {

        this.RoleManagementService.clearPermissionGroups();

        // Loop through the user profile's assignedPermissions and create updatedAssignedPermissions that
        // include both allowed and denied Booleans - for internal use in GUI
        let updatedAssignedPermissions: any[] = [];
        angular.forEach(this.userProfile.assignedPermissions, (perm) => {
            let opt: any = {
                "id": perm.id,
                "name": perm.name,
                "description": perm.permission.description,
                "functionalArea": perm.permission.functionalArea,
                "allowed": perm.allowed,
                "denied": !perm.allowed,
                "permission": perm.permission
            };
            updatedAssignedPermissions.push(opt);
        });
        this.buildDisplayedPermissionCollections("VIEW", updatedAssignedPermissions);
    }

    private buildDisplayedPermissionCollections(typeOfDisplay: string, updatedAssignedPermissions: Array<AssignedPermission>): void {
        this.RoleManagementService.populatePermissionGroups(typeOfDisplay, updatedAssignedPermissions);
    }

    private activateUserProfile() {
        this.userProfile.userStatus = "ACTIVE";
        this.saveUserProfileGeneralInfo();
    }

    private deactivateUserProfile() {
        this.userProfile.userStatus = "INACTIVE";
        this.saveUserProfileGeneralInfo();
    }

    private saveUserProfileGeneralInfo() {
        this.UserProfileService.saveUserProfileData(this.userProfile).then((response: IHttpPromiseCallbackArg<UserProfile>) => {
            this.userProfile = response.data;
            this.UserProfileManagementService.setUserProfile(this.userProfile);
            this.init();
            this.$state.go(this.StateConstants.ADMIN_USER_PROFILE_VIEW);
        }, (errResponse: IHttpPromiseCallbackArg<UserProfile[]>) => {
            this.$log.error("%s - Error saving userProfile general information, err: %s", this.controllerName, errResponse);
        });
    }

    private approveUserProfile() {
        this.UserProfileService.approveUserProfile(this.userProfile).then((response: IHttpPromiseCallbackArg<UserProfile>) => {
            this.userProfile = response.data;
            this.UserProfileManagementService.setUserProfile(this.userProfile);
            this.init();
            this.UserProfileManagementService.loadRegistrationData();
            this.UserProfileManagementService.loadAuthorizedUsersData();
            this.$state.go(this.StateConstants.ADMIN_USER_PROFILE_VIEW);
        }, (errResponse: IHttpPromiseCallbackArg<UserProfile[]>) => {
            this.$log.error("%s - Error approving userProfile, err: %s", this.controllerName, errResponse);
        });
    }

    private denyUserProfile() {
        this.UserProfileService.denyUserProfile(this.userProfile).then((response: IHttpPromiseCallbackArg<UserProfile>) => {
            this.userProfile = response.data;
            this.UserProfileManagementService.loadRegistrationData();
            this.UserProfileManagementService.loadAuthorizedUsersData();
            this.$state.go(this.StateConstants.ADMIN_USER_PROFILE_MNG);
        }, (errResponse: IHttpPromiseCallbackArg<UserProfile[]>) => {
            this.$log.error("%s - Error denying userProfile, err: %s", this.controllerName, errResponse);
        });
    }

    private goToUserProfileAdmin() {
        this.$state.go(this.StateConstants.ADMIN_USER_PROFILE_MNG);
    }

    private goToEditUserProfileGeneralInfo() {
        this.$state.go(this.StateConstants.ADMIN_USER_PROFILE_EDIT_GEN_INFO);
    }

    private goToEditUserProfileRoles() {
        this.$state.go(this.StateConstants.ADMIN_USER_PROFILE_EDIT_ROLES);
    }

    private goToEditUserProfilePermissions() {
        this.$state.go(this.StateConstants.ADMIN_USER_PROFILE_EDIT_PERMS);
    }
}