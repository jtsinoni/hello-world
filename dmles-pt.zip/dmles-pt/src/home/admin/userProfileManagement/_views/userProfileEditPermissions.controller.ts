'use strict';

import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {UserProfile} from '../../../../_models/userProfile.model';
import {Permission} from "../../../../_models/permission.model";
import {AssignedPermission} from "../../../../_models/assignedPermission.model";
import {PermCollection} from "../../roleManagement/_services/roleManagement.service";

export class UserProfileEditPermissionsController {
    public userProfilePermissionsChanged: boolean = false;

    private controllerName: string = "User Profile Edit Permissions Controller";
    private userProfile: UserProfile = null;

    private allPermissions: Permission[] = [];
    private updatedAllPermissions: Permission[] = [];
    private updatedAssignedPermissions: AssignedPermission[] = [];

    // @ngInject
    constructor(private $log, private $state, private RoleManagementService, private RoleService,
                private UserProfileService, private UserProfileManagementService, private StateConstants) {

        this.init();
    }

    /**
     Initializes the page
     */
    private init() {
        this.$log.debug("%s - Start", this.controllerName);
        this.userProfile = this.UserProfileManagementService.getUserProfile();

        if (this.userProfile === null) {
            //no userProfile, go back
            this.UserProfileManagementService.goToUserProfileView();
        } else {
            // this.$log.debug("this.userProfile: %s", JSON.stringify(this.userProfile));
            this.initializePermissions();
        }
    }

    /**
     Initialize the permissions
     */
    private initializePermissions(): void {

        // The database just keeps allowed status for an assigned permission - this.userProfile.assignedPermissions
        // The GUI code will contain and track allowed and denied both - this.assignedPermissions
        angular.forEach(this.userProfile.assignedPermissions, (perm) => {
            let opt: any = {
                "id": perm.id,
                "name": perm.name,
                "allowed": perm.allowed,
                "denied": !perm.allowed
            };
            this.updatedAssignedPermissions.push(opt);
        });
        // this.$log.debug("this.updatedAssignedPermissions: %s", JSON.stringify(this.updatedAssignedPermissions));

        this.getAllPermissionsAndBuildPermissionCollections();
    }

    private getAllPermissionsAndBuildPermissionCollections() {
        this.RoleService.getAllPermissions().then((response: IHttpPromiseCallbackArg<Permission[]>) => {
            // this.$log.debug("%s - Permissions Returned: %s", this.controllerName, JSON.stringify(response.data));

            // permissions come in using hierarchical structure (per TS)
            // we actually want them sans the hierarchical structure - so convert
            angular.forEach(response.data, (element: any) => {
                angular.forEach(element.permissions, (permission) => {
                    this.allPermissions.push(permission);
                });
            });
            // this.$log.debug("this.allPermissions: %s", JSON.stringify(this.allPermissions));

            // update the retrieved list of all permissions with the correct
            // allowed and denied settings - updatedAllPermissions - for display on Edit Permissions page
            angular.forEach(this.allPermissions, (perm) => {
                let opt: any = {
                    "id": perm.id,
                    "name": perm.name,
                    "description": perm.description,
                    "functionalArea": perm.functionalArea,
                    "allowed": this.retrieveFieldValueFromAssignedPermissions(perm.name, "allowed"),
                    "denied": this.retrieveFieldValueFromAssignedPermissions(perm.name, "denied"),
                    "active": perm.active
                };
                this.updatedAllPermissions.push(opt);
            });

            // List of all permissions with the correct allowed and denied settings for the selected Role
            // this.$log.debug("this.updatedAllPermissions: %s", JSON.stringify(this.updatedAllPermissions));

            this.buildDisplayedPermissionCollections("EDIT", this.updatedAllPermissions);

        }, (errResponse: IHttpPromiseCallbackArg<Permission[]>) => {
            this.$log.error("Error retrieving all permissions");           
        });
    }

    private buildDisplayedPermissionCollections(typeOfDisplay: string, updatedAllPermissions: Array<Permission>): void {
        this.RoleManagementService.populatePermissionGroups(typeOfDisplay, updatedAllPermissions);
    }

    private retrieveFieldValueFromAssignedPermissions(field: string, fieldValue: string): boolean {

        let returnValue = false;
        angular.forEach(this.updatedAssignedPermissions, (perm) => {
            if (field === perm.name) {
                returnValue = perm[fieldValue];
            }
        });
        return returnValue;
    }

    /**
     Updates the user profile, if it is valid, and returns to the User Profile Management state
     */
    private onSubmit() {
        // this.$log.debug("this.RoleManagementService.getAdminPermCollection(): %s", JSON.stringify(this.RoleManagementService.getAdminPermCollection()));
        // this.$log.debug("this.RoleManagementService.getEquipmentPermCollection(): %s", JSON.stringify(this.RoleManagementService.getEquipmentPermCollection()));
        // this.$log.debug("this.RoleManagementService.getOtherPermCollection(): %s", JSON.stringify(this.RoleManagementService.getOtherPermCollection()));

        // build Role's assignedPermissions to include any with either Allowed or Denied checked and set the correct allowed setting
        let selectedPermissions = this.getSelectedPerms();
        // this.$log.debug("selectedPermissions: %s", JSON.stringify(selectedPermissions));

        let assignedPermissions: any[] = [];
        angular.forEach(selectedPermissions, (perm) => {
            let assignedPermission: any = {
                name: perm.name,
                allowed: perm.allowed, // if Allowed checked - true; if Deny checked - false
                permission: this.retrievePermissionFromAllPermissions(perm.id)
            };
            assignedPermissions.push(assignedPermission);
        });
        // this.$log.debug("assignedPermissions: %s", JSON.stringify(assignedPermissions));

        // this.$log.debug("this.userProfile.assignedPermissions: %s", JSON.stringify(this.userProfile.assignedPermissions));
        this.userProfile.assignedPermissions = assignedPermissions;
        // this.$log.debug("this.userProfile.assignedPermissions: %s", JSON.stringify(this.userProfile.assignedPermissions));

        this.saveUserProfilePermissions();
        this.UserProfileManagementService.goToUserProfileView();
    }

    /**
     Checks each PermCollection in the given array of PermCollections to determine what permissions
     have been selected
     @returns - an array of ids for the selected permissions
     */
    private getSelectedPerms(): any[] {

        let permCollections: PermCollection[] = [
            this.RoleManagementService.getAdminPermCollection(),
            this.RoleManagementService.getEquipmentPermCollection(),
            this.RoleManagementService.getOtherPermCollection()];

        let selPerms: any[] = [];
        angular.forEach(permCollections, (permCollection: PermCollection) => {
            angular.forEach(permCollection.allPermOpts, (permOpt) => {
                if (permOpt.allowed || permOpt.denied) {
                    selPerms.push(permOpt);
                }
            });
        });

        return selPerms;
    }

    private retrievePermissionFromAllPermissions(permId: string): any {
        let returnValue = {};
        angular.forEach(this.allPermissions, (perm) => {
            if (permId === perm.id) {
                returnValue = perm;
            }
        });
        return returnValue;
    }

    public saveUserProfilePermissions() {
        this.userProfilePermissionsChanged = false;

        // this.$log.debug("Saving this.userProfile: %s", JSON.stringify(this.userProfile));

        this.UserProfileService.saveUserProfilePermissions(this.userProfile).then((response: IHttpPromiseCallbackArg<UserProfile>) => {
            // this.$log.debug("%s - Saved UserProfile Returned: %s", this.controllerName, JSON.stringify(response.data));
            this.userProfile = response.data;
            this.UserProfileManagementService.setUserProfile(this.userProfile);
        }, (errResponse: IHttpPromiseCallbackArg<UserProfile[]>) => {
            this.$log.error("Error saving userProfile permissions");            
        });
    }    
}