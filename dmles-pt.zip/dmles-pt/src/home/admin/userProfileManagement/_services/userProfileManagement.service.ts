import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {UserProfile} from '../../../../_models/userProfile.model';
import {CurrentUserProfile} from "../../../../_models/currentUserProfile.model";

export class UserProfileManagementService {
    private serviceName: String = "UserProfileManagementService";
    private userProfile: UserProfile = null;

    public pendingUsersData:any;
    public usersData:any;

    constructor(private $log, private $state,  private StateConstants, private UserProfileService) {
        this.$log.debug("%s - Start", this.serviceName);
    }

    public getUserProfile(): UserProfile {
        return this.userProfile;
    }

    public setUserProfile(userProfile: UserProfile): void {
        this.userProfile = userProfile;
    }

    public loadRegistrationData(){
        this.UserProfileService.getPendingUserProfiles().then((response: IHttpPromiseCallbackArg<UserProfile[]>) => {
            this.pendingUsersData = response.data;
        }, (errResponse: IHttpPromiseCallbackArg<UserProfile[]>) => {
            this.$log.error("Error retrieving user registrations");
        });
    }

    public loadAuthorizedUsersData() {
        this.UserProfileService.getApprovedUserProfiles().then((response: IHttpPromiseCallbackArg<UserProfile[]>) => {
            this.usersData = response.data;
        }, (errResponse: IHttpPromiseCallbackArg<UserProfile[]>) => {
            this.$log.error("Error retrieving user list");
        });
    };

    /**
     Return to User Profile view state
     */
    private goToUserProfileView(): void {
        this.$state.go(this.StateConstants.ADMIN_USER_PROFILE_VIEW);
    }
}
