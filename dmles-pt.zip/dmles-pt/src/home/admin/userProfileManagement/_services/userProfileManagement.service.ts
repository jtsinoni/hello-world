import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {UserProfile} from '../../../../_models/userProfile.model';
import {CurrentUserProfile} from "../../../../_models/currentUserProfile.model";
import {UserProfileService} from "../../../../_services/userProfile.service";

export class UserProfileManagementService {
    private serviceName: String = "UserProfileManagementService";
    public userProfile: UserProfile = null;

    public pendingUsersData:any;
    public usersData:any;

    constructor(private $log, private $state,  private StateConstants, private UserProfileService) {
        this.$log.debug("%s - Start", this.serviceName);
    }

    public getUserProfile(): UserProfile {
        return this.userProfile;
    }

    public setUserProfile(userProfile: UserProfile): void {
        this.userProfile = userProfile;
    }

    public refreshUserProfile(userProfile: UserProfile) : void {
        let upid = userProfile.id;
        this.UserProfileService.getUserProfileById(upid).then((response: any) => {
            this.userProfile = response.data;
        }, (errResponse: any) => {
            this.$log.error("Error retrieving user: %s", errResponse);
        });
    }

    public loadRegistrationData(){
        this.UserProfileService.getPendingUserProfiles().then((response: any) => {
            this.pendingUsersData = response.data;
        }, (errResponse: any) => {
            this.$log.error("Error retrieving user registrations: %s", errResponse);
        });
    }

    public loadAuthorizedUsersData() {
        this.UserProfileService.getApprovedUserProfiles().then((response: any) => {
            this.usersData = response.data;
        }, (errResponse: any) => {
            this.$log.error("Error retrieving user list: %s", errResponse);
        });
    };

    /**
     Return to User Profile view state
     */
    private goToUserProfileView(): void {
        this.$state.go(this.StateConstants.ADMIN_USER_PROFILE_VIEW);
    }
}
