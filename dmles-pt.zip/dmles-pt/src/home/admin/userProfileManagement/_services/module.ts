'use strict';

import {UserProfileManagementService} from './userProfileManagement.service';

let servicesModule = angular.module('Dmles.Admin.UserProfileManagement.Services.Module', []);
servicesModule.service('UserProfileManagementService', UserProfileManagementService);

export default servicesModule;

