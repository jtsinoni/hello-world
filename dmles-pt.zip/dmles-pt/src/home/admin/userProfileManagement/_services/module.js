define(["require", "exports", './userProfileManagement.service'], function (require, exports, userProfileManagement_service_1) {
    'use strict';
    var servicesModule = angular.module('Dmles.Admin.UserProfileManagement.Services.Module', []);
    servicesModule.service('UserProfileManagementService', userProfileManagement_service_1.UserProfileManagementService);
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = servicesModule;
});
//# sourceMappingURL=module.js.map