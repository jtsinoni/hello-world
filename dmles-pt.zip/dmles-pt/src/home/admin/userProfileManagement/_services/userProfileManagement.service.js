define(["require", "exports"], function (require, exports) {
    "use strict";
    var UserProfileManagementService = (function () {
        function UserProfileManagementService($log, $state, StateConstants, UserProfileService) {
            this.$log = $log;
            this.$state = $state;
            this.StateConstants = StateConstants;
            this.UserProfileService = UserProfileService;
            this.serviceName = "UserProfileManagementService";
            this.userProfile = null;
            this.$log.debug("%s - Start", this.serviceName);
        }
        UserProfileManagementService.prototype.getUserProfile = function () {
            return this.userProfile;
        };
        UserProfileManagementService.prototype.setUserProfile = function (userProfile) {
            this.userProfile = userProfile;
        };
        UserProfileManagementService.prototype.loadRegistrationData = function () {
            var _this = this;
            this.UserProfileService.getPendingUserProfiles().then(function (response) {
                _this.pendingUsersData = response.data;
            }, function (errResponse) {
                _this.$log.error("Error retrieving user registrations: %s", errResponse);
            });
        };
        UserProfileManagementService.prototype.loadAuthorizedUsersData = function () {
            var _this = this;
            this.UserProfileService.getApprovedUserProfiles().then(function (response) {
                _this.usersData = response.data;
            }, function (errResponse) {
                _this.$log.error("Error retrieving user list: %s", errResponse);
            });
        };
        ;
        /**
         Return to User Profile view state
         */
        UserProfileManagementService.prototype.goToUserProfileView = function () {
            this.$state.go(this.StateConstants.ADMIN_USER_PROFILE_VIEW);
        };
        return UserProfileManagementService;
    }());
    exports.UserProfileManagementService = UserProfileManagementService;
});
//# sourceMappingURL=userProfileManagement.service.js.map