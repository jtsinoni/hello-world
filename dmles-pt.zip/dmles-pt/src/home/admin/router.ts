'use strict';

class Router {
    static instance:any;

    // @ngInject
    constructor($stateProvider, $urlRouterProvider, StateConstants) {
        // For any unmatched url, redirect to /home

        $stateProvider
            .state(StateConstants.ADMIN_SHELL, {
                abstract: true,
                url: '/admin',
                templateUrl: '/src/home/admin/adminShell.html',
                controller: 'Dmles.Admin.AdminShellController',
                controllerAs: 'vm'
            })
        ;
    }

    static factory($stateProvider, $urlRouterProvider, StateConstants) {
        Router.instance = new Router($stateProvider, $urlRouterProvider, StateConstants);
        return Router.instance;
    }
}

Router.factory.$inject = ['$stateProvider', '$urlRouterProvider', 'StateConstants'];

export default Router;