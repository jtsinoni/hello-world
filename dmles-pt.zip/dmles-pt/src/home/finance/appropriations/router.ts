'use strict';

class Router {
    static instance:any;

    // @ngInject
    constructor($stateProvider, $urlRouterProvider, StateConstants) {

        $stateProvider
            .state(StateConstants.FIN_APPROPRIATIONS_SHELL, {
                url: '/finance',
                templateUrl: '/src/home/finance/appropriations/financeAdminShell.html',
                controller: 'FinanceAdminShellController',
                controllerAs: 'vm',
                abstract: true
            }).state(StateConstants.FIN_MY_APPROPRIATIONS, {
                url: '/appropriations',
                templateUrl: '/src/home/finance/appropriations/_views/myAppropriations.html',
                controller: 'MyAppropriationsController',
                controllerAs: 'vm',
                data: {
                    displayName: 'Appropriations'
                }
            }).state(StateConstants.FIN_MY_APPROPRIATIONS_DETAIL, {
            url: '/detail',
            templateUrl: '/src/home/finance/appropriations/_views/myAppropriationsDetailView.html',
            controller: 'MyAppropriationsDetailViewController',
            controllerAs: 'vm',
            data: {
                displayName: 'Detail'
            }
        })
            ;
    }

    static factory($stateProvider, $urlRouterProvider, StateConstants) {
        Router.instance = new Router($stateProvider, $urlRouterProvider, StateConstants);
        return Router.instance;
    }
}

Router.factory.$inject = ['$stateProvider', '$urlRouterProvider', 'StateConstants'];

export default Router;