'use strict';

//import {NotificationMessages} from './notificationMessages.constant';

var constantModule = angular.module('Dmles.Finance.Admin.Constants.Module', []);
//constantModule.constant('NotificationMessages', NotificationMessages);

export default constantModule;