'use strict';

export class FinanceAdminShellController {
    viewName: string;

    // @ngInject
    constructor() {
        this.init();
    }

    init(){
        this.viewName = 'Shell View';
    }
}