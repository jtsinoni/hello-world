import {AssignedPermission} from "../../../../_models/assignedPermission.model";
import {UserProfile} from '../../../../_models/userProfile.model';
import {Appropriation} from "../_models/appropriation.model";
import {AppropriationService} from "../_services/appropriation.service";

export class MyAppropriationsDetailViewController {
    private controllerName: string = "Appropriations Detail View Controller";
    private appropriation: Appropriation = null;
    public selectedAppropriation:Appropriation;
    public isEditing:boolean = false;

    // @ngInject
    constructor(private $log, private StateConstants, private AppropriationService) {
        this.$log.debug("%s - Start", this.controllerName);
        this.init();
    }

    private init() {
        this.$log.debug("%s - Selected appropriation: %s", this.controllerName, JSON.stringify(this.selectedAppropriation));
    }

    public toggleEdit() {
        return this.isEditing = !this.isEditing;
    }

    public saveAppropriationInfo() {
        this.isEditing = false;
        this.$log.debug("%s - Saving appropriation: %s", this.controllerName, JSON.stringify(this.selectedAppropriation));
        this.AppropriationService.save();
    }
}