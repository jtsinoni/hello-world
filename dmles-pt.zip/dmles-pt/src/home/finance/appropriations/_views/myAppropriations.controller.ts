'use strict';

import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {Appropriation} from '../_models/appropriation.model';
import {AppropriationService} from '../_services/appropriation.service';
import {CurrentUserProfile} from '../../../../_models/currentUserProfile.model';
import {DmlesPanelTableColumns} from "../../../../_models/dmlesPanelTableColumns.model";

export class MyAppropriationsController {
    private controllerName:string = "My Appropriations Controller";
    private currentUser:CurrentUserProfile = new CurrentUserProfile();
    private activePill:string;
    public loadingTable:boolean = true;

    public initialSort:any = [{ targetAmount: "asc" }];
    //public initialSort:any = [];
    public appropriationSummaryCols:DmlesPanelTableColumns[] =  [
        { title: 'ID', field: 'id', show: false, sortable: 'id', type: 'text', filter: null,  filterData: null },
        { title: 'Main Acct', field: 'fund', show: true, sortable: 'fund', type: 'text', filter: null,  filterData: null },
        { title: 'Reimbursable', field: 'reimbursableFlag', show: true, sortable: 'reimbursableFlag', type: 'text', filter: null,  filterData: null },
        { title: 'Program Code', field: 'programCode', show: true, sortable: 'programCode', type: 'text', filter: null,  filterData: null },
        { title: 'StartDate', field: 'startDate', show: true, sortable: 'startDate', type: 'date', filter: null,  filterData: null },
        { title: 'EndDate', field: 'endDate', show: true, sortable: 'endDate', type: 'date', filter: null,  filterData: null },
        { title: 'Functional Area', field: 'functionalArea', show: true, sortable: 'functionalArea', type: 'text', filter: null,  filterData: null }
    ];

    // @ngInject
    constructor(private $filter, private $log, private $state, private ContentConstants, private datatableService, private NotificationService,
                private StateConstants, private UserService,
                private AppropriationService) {
        this.$log.debug("%s - Start", this.controllerName);
        this.currentUser = this.UserService.currentUser;
        this.$log.debug("this.currentUser: %s", JSON.stringify(this.currentUser));
        this.init();
    }

    private init() {
        this.$log.debug("%s - Init Appropriations", this.controllerName);
        this.AppropriationService.getAppropriations();
    }

    public regRowClick(rowData:Appropriation): void {
        this.$log.debug("Row clicked: %s", JSON.stringify(rowData));
        this.AppropriationService.setSelectedAppropriation(rowData);
        this.$state.go(this.StateConstants.FIN_MY_APPROPRIATIONS_DETAIL);
    }
}

