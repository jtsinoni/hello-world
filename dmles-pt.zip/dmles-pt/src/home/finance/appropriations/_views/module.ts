'use strict';

import {MyAppropriationsController} from './myAppropriations.controller';
import {MyAppropriationsDetailViewController} from './myAppropriationsDetailView.controller';

var controllersModule = angular.module('Dmles.Home.Finance.Admin.Views.Module', []);
controllersModule.controller('MyAppropriationsController', MyAppropriationsController);
controllersModule.controller('MyAppropriationsDetailViewController', MyAppropriationsDetailViewController);

export default controllersModule;