'use strict';

 import router from './router';
import {FinanceAdminShellController} from './financeAdminShell.controller';

// modules
import constantModule from './_constants/module';
import modelsModule from './_models/module';
import servicesModule from './_services/module';
import controllersModule from './_views/module';
import directivesModule from './_directives/module';

var module = angular.module('Dmles.Home.Finance.Admin.Module', [
	constantModule.name,
	modelsModule.name,
	servicesModule.name,
	controllersModule.name,
	directivesModule.name
]);

module.controller('FinanceAdminShellController', FinanceAdminShellController);
module.config(router.factory);

export default module;