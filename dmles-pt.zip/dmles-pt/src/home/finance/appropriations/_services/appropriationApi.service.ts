'use strict';

import {ApiService} from '../../../../_services/api.service';

export interface IAppropriationApiService {

}

export class AppropriationApi extends ApiService implements IAppropriationApiService {

    // @ngInject
    constructor($http, public $log, Authentication, $httpParamSerializerJQLike) {
        super($http, $log, Authentication, $httpParamSerializerJQLike, "FundAdmin");
    }

    public getMyAppropriations() {
        return this.get("getMyAppropriations");
    }

    public saveAppropriation(data:any) {
        return this.post("updateAppropriation", data);
    }


}