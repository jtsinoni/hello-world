'use strict';

import {AppropriationService} from './appropriation.service';
import {AppropriationApi} from './appropriationApi.service';

var servicesModule = angular.module('Dmles.Finance.Appropriation.Services.Module', []);
servicesModule.service('AppropriationService', AppropriationService);
servicesModule.service('AppropriationApi', AppropriationApi);

export default servicesModule;