import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {Appropriation} from "../_models/appropriation.model";

export interface IAppropriationService {
    
}

export class AppropriationService implements IAppropriationService {
    private serviceName: string = "AppropriationService";

    public selectedAppropriation:Appropriation;
    public appropriations:any;


    // @ngInject
    constructor(private $log, private ContentConstants,
                private NotificationService, private StateConstants, private AppropriationApi, private UserService) {
        this.$log.debug("%s - Start", this.serviceName);

    }

    public getMyActiveAppropriations() {
        if (!this.appropriations) {
            this.getAppropriations();
        }
    }

    public getAppropriations(){

        this.$log.debug("Getting appropriations");

        this.AppropriationApi.getMyAppropriations().then((result:IHttpPromiseCallbackArg<Appropriation[]>) => {
            this.$log.debug("making call for appropriations");
            this.appropriations = result.data;
            this.$log.debug("result %s", result.data);
        }, (errResponse:IHttpPromiseCallbackArg<Appropriation[]>) => {
                this.$log.error("Error retrieving appropriations from users id." + errResponse.data);
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
            }
        );
    }

    public clearAppropriation() {
        this.selectedAppropriation = new Appropriation();
    }

    public getSelectedAppropriation() {
        return this.selectedAppropriation;
    }

    public setSelectedAppropriation(rowData:Appropriation) {
        this.selectedAppropriation = rowData;
    }

    public save() {
        this.AppropriationApi.saveAppropriation(this.selectedAppropriation)
            .then((result:IHttpPromiseCallbackArg<Appropriation>) => {
                    this.$log.debug("making call to save appropriation");
                    this.appropriations = result.data;
                    this.$log.debug("result %s", result.data);
                }, (errResponse:IHttpPromiseCallbackArg<Appropriation>) => {
                    this.$log.error("Error saving appropriation.");
                    this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
                }
            );
    }
}