'use strict';

//import {EntrySectionHeader} from './EntrySectionHeader/entrySectionHeader.directive';

var directivesModule = angular.module('Dmles.Finance.Admin.Directives.Module', []);

export default directivesModule;