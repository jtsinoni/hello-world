import {Account} from "./account.model";
import {CostCenter} from "./costCenter.model";

export class Appropriation {
    public id:any;
    public service:String;
    public fund:any;
    public type:String;
    public mainAccount:Account;
    public subAccount:String;
    public costCenter:CostCenter;
    public responsibleCostCenterId:String;
    public functionalArea: String;
    public targetAmount:String;
    public wbsElementId:String;
    public wbsDescription:String ;
    public budgetActivityId:String;
    public budgetSubActivityId:String;
    public budgetLineItemId:String;
    public startDate:Date;
    public endDate:Date;
    public status:String;
    public departmentTransferCode:String;
    public programCode:String;
    public programYear:String;
    public fundedProgramName:String;
    public agencyDisbursing:String;
    public agencyAccounting:String;
    public bpn:String;
    public eoyRollover:String;
    public availabilityPeriod:String;
    public availabilityTypeCode:String;
    public beginPeriodAvailabilityYear:String;
    public endPeriodAvailabilityYear:String;
    public reimbursableFlag:String;
    public fundGroupDesignator:String;
    public subAllocationHolder:String;
    public fundType:String;
    public fundCode:String;
    public subClassCode:String;
    public fundingCenterId:String;
    public businessEventyTypeCode:String;
    public reimbursableBillCode:String;
    public reimbursableOrderNumber:String;
    public costElementCode:String;


    constructor();
    constructor(obj:Appropriation);
    constructor(obj?:any) {
        this.id = obj && obj.id || null;
        this.service = obj && obj.service || null;
        this.fund = obj && obj.fund || null;
        this.type = obj && obj.type || null;
        this.mainAccount = obj && obj.mainAccount || null;
        this.subAccount = obj && obj.subAccount || null;
        this.costCenter = obj && obj.costCenter || null;
        this.responsibleCostCenterId = obj && obj.responsibleCostCenterId || null;
        this.functionalArea = obj && obj.functionalArea || null;
        this.targetAmount = obj && obj.targetAmount || null;
        this.wbsElementId = obj && obj.wbsElementId || null;
        this.wbsDescription = obj && obj.wbsDescription || null;
        this.budgetActivityId = obj && obj.budgetActivityId || null;
        this.budgetSubActivityId = obj && obj.budgetSubActivityId || null;
        this.budgetLineItemId = obj && obj.budgetLineItemId || null;
        this.startDate = obj && obj.startDate || null;
        this.endDate = obj && obj.endDate || null;
        this.status = obj && obj.status || null;
        this.departmentTransferCode = obj && obj.departmentTransferCode || null;
        this.programCode = obj && obj.programCode || null;
        this.programYear = obj && obj.programYear || null;
        this.fundedProgramName = obj && obj.fundedProgramName || null;
        this.agencyDisbursing = obj && obj.agencyDisbursing || null;
        this.agencyAccounting = obj && obj.agencyAccounting || null;
        this.bpn = obj && obj.bpn || null;
        this.eoyRollover = obj && obj.eoyRollover || null;
        this.availabilityPeriod = obj && obj.availabilityPeriod || null;
        this.availabilityTypeCode = obj && obj.availabilityTypeCode || null;
        this.beginPeriodAvailabilityYear = obj && obj.beginPeriodAvailabilityYear || null;
        this.endPeriodAvailabilityYear = obj && obj.endPeriodAvailabilityYear || null;
        this.reimbursableFlag = obj && obj.reimbursableFlag || null;
        this.fundGroupDesignator = obj && obj.fundGroupDesignator || null;
        this.subAllocationHolder = obj && obj.subAllocationHolder || null;
        this.fundType = obj && obj.fundType || null;
        this.fundCode = obj && obj.fundCode || null;
        this.subClassCode = obj && obj.subClassCode || null;
        this.fundingCenterId = obj && obj.fundingCenterId || null;
        this.businessEventyTypeCode = obj && obj.businessEventyTypeCode || null;
        this.reimbursableBillCode = obj && obj.reimbursableBillCode || null;
        this.reimbursableOrderNumber = obj && obj.reimbursableOrderNumber || null;
        this.costElementCode = obj && obj.costElementCode || null;

    }

}