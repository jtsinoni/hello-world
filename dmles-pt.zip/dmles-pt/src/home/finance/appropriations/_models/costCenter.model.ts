import {Address} from "./address.model";

export class CostCenter {
    public id:any;
    public ouid:String;
    public type:String;
    public departmentRegularCode:String;
    public address:Address;

    constructor();
    constructor(obj:CostCenter);
    constructor(obj?:any) {
        this.id = obj && obj.id || null;
        this.ouid = obj && obj.ouid || null;
        this.type = obj && obj.type || null;
        this.departmentRegularCode = obj && obj.departmentRegularCode || null;
        this.address = obj && obj.address || null;
    }

}