import {Fund} from "./fund.model";
import {ProjectCenter} from "./projectCenter.model";

export class ExpenseCenter extends Fund {

    public customerId:String[];
    public projectCenter:ProjectCenter;
    public fundUsages:String[];

    constructor(obj?:any) {
        super(obj);
        this.customerId = obj && obj.customerId || null;
        this.projectCenter = obj && obj.projectCenter || null;
        this.fundUsages = obj && obj.fundUsages || null;
    }
}
