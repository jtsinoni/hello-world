import {Fund} from "./fund.model";
import {ExpenseCenter} from "./expenseCenter.model";

export class ProjectCenter extends Fund {

    public fundedProgramName:String;
    public expenseCenters:ExpenseCenter[];

    constructor(obj?:any) {
        super(obj);
        this.fundedProgramName = obj && obj.fundedProgramName || null;
        this.expenseCenters = obj && obj.expenseCenters || null;
    }
}
