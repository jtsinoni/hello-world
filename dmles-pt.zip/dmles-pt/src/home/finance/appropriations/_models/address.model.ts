export class Address {
    public names:String[];
    public addressLines:String[];
    public city:String;
    public district:String;
    public region:String;
    public postalCode:String;
    public poBox:String;
    public poBoxPostalCode:String;

    constructor();
    constructor(obj:Address);
    constructor(obj?:any) {
        this.names = obj && obj.names || null;
        this.addressLines = obj && obj.addressLines || null;
        this.city = obj && obj.city || null;
        this.district = obj && obj.district || null;
        this.region = obj && obj.region || null;
        this.postalCode = obj && obj.postalCode || null;
        this.poBox = obj && obj.poBox || null;
        this.poBoxPostalCode = obj && obj.poBoxPostalCode || null;
    }

}