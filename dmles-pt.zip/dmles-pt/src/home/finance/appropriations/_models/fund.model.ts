
import {Appropriation} from "./appropriation.model";

export class Fund {
    public id:String;
    public fundCenterId:String;
    public fundCenterName:String;
    public appropriation:Appropriation;
    public code:String;
    public category:String;
    public fiscalYear:String;
    public availableBalance:number;
    public commitments:number;
    public obligations:number;
    public credits:number;
    public expenses:number;
    public reimburseSales:number;
    public nonReimburseSales:number;
    public status:String;
    public dailyConsumptionRate:number;
    public projectedExhaustionDate:Date;
    public orgId:String;
    public targetAmount:String;

    constructor();
    constructor(obj:Fund);
    constructor(obj?:any) {
        this.id = obj && obj.id || null;
        this.fundCenterId = obj && obj.fundCenterId || null;
        this.fundCenterName = obj && obj.fundCenterName || null;
        this.appropriation = obj && obj.appropriation || null;
        this.code = obj && obj.code || null;
        this.category = obj && obj.category || null;
        this.fiscalYear = obj && obj.fiscalYear || null;
        this.availableBalance = obj && obj.availableBalance || null;
        this.commitments = obj && obj.commitments || null;
        this.obligations = obj && obj.obligations || null;
        this.credits = obj && obj.credits || null;
        this.expenses = obj && obj.expenses || null;
        this.reimburseSales = obj && obj.reimburseSales || null;
        this.nonReimburseSales = obj && obj.nonReimburseSales || null;
        this.status = obj && obj.status || null;
        this.dailyConsumptionRate = obj && obj.dailyConsumptionRate || null;
        this.projectedExhaustionDate = obj && obj.projectedExhaustionDate || null;
        this.orgId = obj && obj.orgId || null;
        this.targetAmount = obj && obj.targetAmount || null;

    }
}
