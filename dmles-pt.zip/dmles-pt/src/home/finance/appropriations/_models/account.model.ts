//import {Account} from "./account.model";

export class Account {
    public id:String;
    public code:String;
    public name:String;
    public type:String;
    public departmentRegularCode:String;

    constructor();
    constructor(obj:Account);
    constructor(obj?:any) {
        this.id = obj && obj.id || null;
        this.code = obj && obj.code || null;
        this.name = obj && obj.name || null;
        this.type = obj && obj.type || null;
        this.departmentRegularCode = obj && obj.departmentRegularCode || null;
    }

}