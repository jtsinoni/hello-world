'use strict';

import {Appropriation} from './appropriation.model';
import {Account} from './account.model';
import {CostCenter} from './costCenter.model';
import {Address} from './address.model';
import {Fund} from './fund.model';
import {ExpenseCenter} from './expenseCenter.model';
import {ProjectCenter} from './projectCenter.model';

var modelsModule = angular.module('Dmles.Home.Finance.Admin.Models.Module', []);
modelsModule.value('Appropriation', Appropriation);
modelsModule.value('Account', Account);
modelsModule.value('CostCenter', CostCenter);
modelsModule.value('Address', Address);
modelsModule.value('Fund', Fund);
modelsModule.value('ExpenseCenter', ExpenseCenter);
modelsModule.value('ProjectCenter', ProjectCenter);

export default modelsModule;