'use strict';

// modules
import modelsModule from './_models/module';
import landingModule from './landing/module';
import adminModule from './appropriations/module';

var module = angular.module('Dmles.Home.Finance.Module', [
    modelsModule.name,
    landingModule.name,
    adminModule.name
]);

export default module;
