'use strict';

export class FinanceLanding {

    public _id:String = "";

    // used with orgId to uniquely identify an ER at an MTF
    // not displayed on GUI - used for DB lookup only
    public meId:String = "";

    public selected:boolean = false;

    public detailsRetrieved:boolean = false;
    public detailsFound:boolean = false;

    // basic equipment record detail info - located above tabs
    public shortItemDesc:String = "";
    public longItemDesc:String = "";
    public equipmentStatus:String = "";
    public orgId:String = "";
    public ecn:String = "";
    public nomenclature:String = "";
    public itemId:String = "";
    public deviceClass:String = "";

    // Main Tab
    public manufacturer:String = "";
    public division:String = "";
    public nameplateModel:String = "";
    public commonModel:String = "";
    public manufacturerSerialNumber:String = "";
    public acquisitionDate:Date;
    public acquisitionCost:Number = 0;
    public lifeExpectancy:String = "";
    public assetControlNumber:String = "";
    public acquisitionCommodityClass:String = "";

    public equipmentType:String = "";
    public systemEcn:String = "";
    public accountingStatus:String = "";
    public isAccountableEquipment:Boolean = false;
    public isMaintenanceRequired:Boolean = false;
    public ownership:String = "";
    public condition:String = "";
    public accountingStatusDate:Date;

    public organization:String = "";
    public customerName:String = "";
    public customerId:String = "";
    public custodianName:String = "";
    public custodianPhone:String = "";
    public subcustodianName:String = "";
    public subcustodianPhone:String = "";

    public assemblageOrganization:String = "";
    public assemblageDescription:String = "";
    public assemblageNumber:String = "";

    // Location & Inventory Tab
    public isOnLoan:Boolean = false;
    public loanReturnDate:Date;
    public equipmentReturnDate:Date;
    public building:String = "";
    public floor:String = "";
    public room:String = "";
    public equipmentLocation:String = "";
    public temporaryLocation:String = "";
    public locationId:String = "";
    public rfidTag:String = "";
    public rfLocation:String = "";
    public rfDate:Date;
    public subLocation:String = "";

    public lastInventoryDate:Date;
    public inventoryPerformedBy:String = "";
    public inventoryLocation:String = "";
    public inventoryEntryMethod:String = "";
    public inventoryReason:String = "";

    // Approval/Acquisition Tab
    public approvalReference:String = "";
    public acquisitionSpeciality:String = "";
    public replacementRequestNumber:String = "";

    public transactionReason:String = "";
    public sourceOfSupply:String = "";
    public contractNumber:String = "";
    public documentNumber:String = "";
    public receivedFromDocumentNumber:String = "";

    public installationDate:Date;
    public warrantyBeginDate:Date;
    public warrantyEndDateLabor:Date;
    public warrantyEndDateParts:Date;

    public accumulatedDepreciation:Number = 0.00;
    public cfoAssetClassification:String = "";
    public acquisitionFundCode:String = "";

    public iuid:String = "";
    public uiiType:String = "";
    public uiiStatus:String = "";
    public uiiStatusDate:Date;
    public isUiiLabelAffixed:Boolean = false;
    public userName:String = "";
    public uiiAffixedDate:Date;

    // Maintenance Data Tab
    public maintenanceActivity:String = "";
    public scheduledTeam:String = "";
    public unscheduledTeam:String = "";
    public otherGovernmentAgency:String = "";
    public contractor:String = "";
    public siteId:String = "";
    public firmwareNumber:String = "";
    public riskLevel:String = "";

    public schedulingFactor:String = "";
    public equipmentReadinessCode:String = "";
    public maintenanceAssessment:String = "";
    public operationalStatus:String = "";
    public procedureNumber:String = "";
    public outstandingWorkOrders:Number = 0;
    public modifications:Number = 0;
    public maximumExpenditureLimit:Number = 0;
    public maximumRepairLimitCumulative:Number = 0;
    public dateLastServiced:Date;

    public containsPatientData:Boolean = false;
    public clinicalAlarmIndicator:Boolean = false;
    public lifeSafety:Boolean = false;
    public suspendScheduledWorkOrders:Boolean = false;
    public tmde:Boolean = false;
    public downStatus:Boolean = false;
    public suspendReason:String = "";

    public maintenancePlan:Array<any> = [];

    // Maintenance Cost Tab
    public maintenanceCostHistory:Array<any> = [];
    public totalSystemAcquisitionCost:Number = 0;
    public totalMaintenanceCost:Number = 0;
    public totalDownTime:Number = 0;
    public totalMaintenanceUnscheduledWorkOrders:Number = 0;
    public totalOrganizationalCosts:any = {
        "partsCost": 0,
        "unscheduledTime": 0,
        "unscheduledLaborCost": 0,
        "scheduledTime": 0,
        "scheduledLaborCost": 0,
        "totalCost": 0
    };
    public totalContractCosts:any = {
        "partsCost": 0,
        "unscheduledTime": 0,
        "unscheduledLaborCost": 0,
        "scheduledTime": 0,
        "scheduledLaborCost": 0,
        "totalCost": 0
    };

    //Components
    public components:Array<any> = [];

    //Notes
    public notes:Array<any> = [];

    // Need for now to just to keep ER demo (using Catalog Search data) working
    public deviceText:String = "";
    public manufacturerNm:String = "";
    public supplierNm:String = "";

    constructor();
    constructor(obj:FinanceLanding);
    constructor(obj?:any) {
        this._id = obj && obj.id || "";
        this.deviceText = obj && obj.deviceText || "";
        this.itemId = obj && obj.itemId || "";
        this.longItemDesc = obj && obj.longItemDesc || "";
        this.manufacturerNm = obj && obj.manufacturerNm || "";
        this.orgId = obj && obj.orgId || "";
        this.shortItemDesc = obj && obj.shortItemDesc || "";
        this.supplierNm = obj && obj.supplierNm || "";
    };

}