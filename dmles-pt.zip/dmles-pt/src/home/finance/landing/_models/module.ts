'use strict';

import {FinanceLanding} from './financeLanding.model';

let modelsModule = angular.module('Dmles.Home.Fin.Landing.Models.Module', []);
modelsModule.value('FinanceLanding', FinanceLanding);

export default modelsModule;