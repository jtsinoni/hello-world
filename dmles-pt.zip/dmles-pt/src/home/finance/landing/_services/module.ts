'use strict';

import {CustomerNameFilterService} from './customerNameFilter.service';

let servicesModule = angular.module('Dmles.Home.Finance.Landing.Services.Module', []);
servicesModule.service('CustomerNameFilterService', CustomerNameFilterService);

export default servicesModule;