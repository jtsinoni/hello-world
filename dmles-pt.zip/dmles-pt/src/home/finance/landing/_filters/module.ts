'use strict';

import CutFilter from './cut.filter';
import RefineFilter from './refine.filter';

let filtersModule = angular.module('Dmles.Home.Fin.Landing.Filters.Module', []);
filtersModule.filter('cut', CutFilter);
filtersModule.filter('refine', RefineFilter);

export default filtersModule;