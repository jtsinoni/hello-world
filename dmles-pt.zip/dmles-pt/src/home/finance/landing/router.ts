class Router {
    static instance: any;

    // @ngInject
    constructor($stateProvider, $urlRouterProvider, StateConstants) {

        $stateProvider
            .state(StateConstants.FIN_SHELL, {
                url: '',
                templateUrl: '/src/home/finance/landing/_views/financeShell.html',
                controller: 'FinanceShellController',
                controllerAs: 'vm',
                data: {
                    displayName: 'Finance Page'
                }
            }).state(StateConstants.FIN_LANDING, {
            url: '/landing',
            templateUrl: '/src/home/finance/landing/_views/financeLanding.html',
            controller: 'FinanceLandingController',
            controllerAs: 'vm',
            data: {
                displayName: 'Finance Landing Page'
            }
        })
        ;

    }

    static factory($stateProvider, $urlRouterProvider, StateConstants) {
        Router.instance = new Router($stateProvider, $urlRouterProvider, StateConstants);
        return Router.instance;
    }
}

Router.factory.$inject = ['$stateProvider', '$urlRouterProvider', 'StateConstants'];

export default Router;