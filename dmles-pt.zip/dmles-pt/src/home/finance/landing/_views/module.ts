'use strict';

import {FinanceLandingController} from './finance.landing.controller';
import {FinanceShellController} from "./financeShell.controller";

let controllersModule = angular.module('Dmles.Home.Finance.Landing.Views.Module', []);
controllersModule.controller('FinanceLandingController', FinanceLandingController);
controllersModule.controller('FinanceShellController', FinanceShellController);

export default controllersModule;