'use strict';

export class FinanceShellController {
    private controllerName: string = "Finance Shell - Main Tab Controller";

    // @ngInject
    constructor(private DetailsPaginationService) {
    }

}