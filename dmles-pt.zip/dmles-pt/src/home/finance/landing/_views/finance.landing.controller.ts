'use strict';

export class FinanceLandingController {
    private controllerName: string = "Finance Landing - Main Tab Controller";

    // @ngInject
    constructor(private DetailsPaginationService) {
    }

}