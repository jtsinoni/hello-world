'use strict';

import {ApiService} from '../../../_services/api.service';
import {CatalogItem} from '../_models/catalogItem.model';

export interface ICatalogService {

}

export class CatalogService extends ApiService implements ICatalogService {
    private catalogItem:CatalogItem = new CatalogItem();
    private serviceName:string = "Catalog Service";
    public activeRequestTable:any;
    public catalogFavorites:Array<CatalogItem> = [];

    // @ngInject
    constructor($http, $httpParamSerializerJQLike, private $filter, $log, private $state,
                Authentication, private datatableService, private NotificationService, private RequestService,
                private StateConstants, private UtilService, private WorkFlowService) {
        super($http, $log, Authentication, $httpParamSerializerJQLike, "EquipmentManagement");
        this.$log.debug("%s - Start", this.serviceName);
    }

    /*
     Checks to see if the item is already in favorites and if it does, then it ignores the addition.
     Note: Filter says, compare the itemId field with newItem.item.itemId, true means
     return an exact match.
     */
    public addToFavorites(newItem) {
        if(newItem && newItem.itemId){
            var found = this.$filter('filter')(this.catalogFavorites, {itemId: newItem.itemId}, true);
            if (found.length === 0) {
                this.catalogFavorites.push(angular.copy(newItem));
                this.NotificationService.successMsg("New favorite item added");
            }else{
                this.NotificationService.infoMsg("Item already saved in favorites");
            }
        }else{
            this.$log.warn("%s - Add to favorites, item not found", this.serviceName);
        }
    }

    public addToRequest(equip){
        if(equip && equip.itemId) {
            this.RequestService.clearRequest();
            this.setCatalogItem(equip);
            var getRequests = this.RequestService.getRequests();
            getRequests.then((result) => {
                this.createActiveRequestTable(this.filterActiveRequests(result));
            });
        }else{
            this.$log.warn("%s - Add to request, item not found", this.serviceName);
        }
    }

    public buildRequest(item){
        this.RequestService.clearRequest();  // TODO: Add ability to associate with an active request?
        this.RequestService.buildRequestFromCatalog(item);
        this.$state.go(this.StateConstants.EQUIP_REQUEST_VIEW);
    }

    public clearCatalogItem() {
        this.catalogItem = null;
    }

    public clearFavorites() {
        this.catalogFavorites = [];
    }

    public createActiveRequestTable(data){
        this.activeRequestTable = this.datatableService.createNgTable(data, 25, { updatedDate: 'desc' });
    }

    public filterActiveRequests(requestList){
        return this.$filter('filter')(requestList, (o) => {
            return o.wfProcessing && this.WorkFlowService.isRequestAtUsersLevel(o);
        });
    }

    public getCatalogItem() {
        if (this.catalogItem) {
            return this.catalogItem;
        }
        return null;
    }

    public getEquipItems(searchValue:string, dodaac:string, userSpecifiedFilters:string) {
        //Note: check to see if anything got sent through, otherwise a string 'undefined' will be sent to bt.
        var dodaacStr:string = (dodaac) ? dodaac : "";
        var searchValue:string = (searchValue) ? searchValue : "";
        var userSpecifiedFilters:string = (userSpecifiedFilters) ? userSpecifiedFilters : "";

        // escape special characters
        searchValue = this.UtilService.esEscapeSpecialChars(searchValue);

        if (searchValue === "" || searchValue === "*") {
            searchValue = userSpecifiedFilters;
        } else {
            searchValue = searchValue + " " + userSpecifiedFilters;
        }

        // encode URI/URL reserved characters
        searchValue = encodeURIComponent(searchValue);

        return this.get("getCatalogSearchResults?searchValue=" + searchValue + "&?dodaac=" + dodaacStr);
    }

    public getSearchStats(result) {
        var retVal = {
            "total": 0,
            "time": 0.00
        };

        if (result && result.data && result.data.hits) {
            if (result.data.hits.total) {
                retVal.total = result.data.hits.total;
            }

            if (result.data.took) {
                retVal.time = result.data.took;
            }
        }
        else {
            this.$log.debug("%s - Warning: No data returned", this.serviceName);
        }
        return retVal;
    }

    public parseEquipResults(results) {
        var equipList:Array<CatalogItem> = [];
        if (results && results.data.hits.hits) {
            var esResults = results.data.hits.hits;

            // TODO: This iteration may not be needed once dmles-gui pulls from the Java EndPoint for
            // ES equipment search results.  Currently dmles-gui is hitting ES directly, which nests the
            // equipment search results under data.hits.hits.fields.
            for (var i in esResults) {
                var resultItem = esResults[i];
                if (resultItem.hasOwnProperty("fields")) {
                    var catItem:CatalogItem = new CatalogItem();
                    for (var key in resultItem.fields) {
                        var value:Array<any> = resultItem.fields[key];
                        catItem[key] = value[0];
                    }
                    equipList.push(catItem);
                }
            }

        } else {
            this.$log.debug("%s - Warning: No data returned", this.serviceName);
        }

        return equipList;
    }

    public removeFromFavorites(item) {
        var index = this.catalogFavorites.indexOf(item);
        this.catalogFavorites.splice(index, 1);
    }

    public setCatalogItem(item) {
        this.catalogItem = new CatalogItem(angular.copy(item));
    }
}