'use strict';

import {AcquisitionCostFilter} from './acquisitionCostFilter.service';
import {CatalogService} from './catalog.service';
import {ManufacturerFilter} from './manufacturerFilter.service';
import {SourceOfSupplyFilter} from './sourceOfSupplyFilter.service';

var servicesModule = angular.module('Dmles.Home.Catalog.Services.Module', []);
servicesModule.service('AcquisitionCostFilter', AcquisitionCostFilter);
servicesModule.service('CatalogService', CatalogService);
servicesModule.service('ManufacturerFilter', ManufacturerFilter);
servicesModule.service('SourceOfSupplyFilter', SourceOfSupplyFilter);

export default servicesModule;