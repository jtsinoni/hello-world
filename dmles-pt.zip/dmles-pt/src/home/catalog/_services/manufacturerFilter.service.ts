'use strict';

import {BaseSelectFilterService} from "../../../_services/baseSelectFilter.service";

export class ManufacturerFilter extends BaseSelectFilterService {
    public manufacturers:Array<string> = [];

    // @ngInject
    constructor(private MultiSelectService) {
        super();
    }

    public load() {
        this.initialize();
        var n:string;
        for (n in this.manufacturers) {
            var selection = this.manufacturers[n];
            this.options.push(this.MultiSelectService.buildSelection(selection, selection, selection, false));
        }
    }

    public initializeList() {
        if (this.optionsSelected.length === 0) {
            this.manufacturers = [];
        }
    }

    public buildList(searchResult:any) {
        if (this.optionsSelected.length === 0) {
            this.manufacturers.push(searchResult.manufacturerNm);
        }
    }

    public loadList() {
        if (this.optionsSelected.length === 0) {
            this.manufacturers = this.removeDuplicates(this.manufacturers);
            this.manufacturers = this.manufacturers.sort();
            this.load();
        }
    }

    public reset() {
        this.manufacturers = [];
        this.initialize();
    }
}