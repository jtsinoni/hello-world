define(["require", "exports", './acquisitionCostFilter.service', './catalog.service', './manufacturerFilter.service', './sourceOfSupplyFilter.service'], function (require, exports, acquisitionCostFilter_service_1, catalog_service_1, manufacturerFilter_service_1, sourceOfSupplyFilter_service_1) {
    'use strict';
    var servicesModule = angular.module('Dmles.Home.Catalog.Services.Module', []);
    servicesModule.service('AcquisitionCostFilter', acquisitionCostFilter_service_1.AcquisitionCostFilter);
    servicesModule.service('CatalogService', catalog_service_1.CatalogService);
    servicesModule.service('ManufacturerFilter', manufacturerFilter_service_1.ManufacturerFilter);
    servicesModule.service('SourceOfSupplyFilter', sourceOfSupplyFilter_service_1.SourceOfSupplyFilter);
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = servicesModule;
});
//# sourceMappingURL=module.js.map