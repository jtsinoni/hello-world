'use strict';

export class AcquisitionCostFilter {
    public zero:number = 0;
    public hugeNumber:number = 100000000000; // 100 billion
    public userMin:number = this.zero;
    public userMax:number = this.hugeNumber;
    public userSpecifiedMin:number = null;
    public userSpecifiedMax:number = null;
    public userMinValue:Array<any> = [];
    public userMaxValue:Array<any> = [];
    public rangeOptions:string[] = ["Any Cost", "$0 - $500", "$0 - $2,500", "More than $2500"];
    public rangeValue:string = "Any Cost";

    // @ngInject
    constructor() {
    }

    public buildSearchClause():string {
        var returnValue:string = "packPriceAmt:[";
        if (this.userMin === this.zero) {
            if (this.userMax === this.hugeNumber) {
                returnValue = "";
            } else {
                returnValue += "* TO " + this.userMax + "]";
            }
        } else {
            returnValue += this.userMin;
            if (this.userMax === this.hugeNumber) {
                returnValue += " TO *]";
            } else {
                returnValue += " TO " + this.userMax + "]";
            }
        }
        return returnValue;
    }

    public initialize() {
        this.zero = 0;
        this.hugeNumber = 100000000000; // 100 billion
        this.userMin = this.zero;
        this.userMax = this.hugeNumber;
        this.userSpecifiedMin = null;
        this.userSpecifiedMax = null;
        this.userMinValue = [];
        this.userMaxValue = [];
        this.rangeOptions = ["Any Cost", "$0 - $500", "$0 - $2,500", "More than $2500"];
        this.rangeValue = "Any Cost";
    }

    public process() {
        this.userMinValue = [{selValue: this.userMin}];
        this.userMaxValue = [{selValue: this.userMax}];
    }

    public processRange() {
        if (this.rangeValue === this.rangeOptions[0]) {
            this.userMin = this.zero;
            this.userMax = this.hugeNumber;
        } else if (this.rangeValue === this.rangeOptions[1]) {
            this.userMin = this.zero;
            this.userMax = 500;
        } else if (this.rangeValue === this.rangeOptions[2]) {
            this.userMin = this.zero;
            this.userMax = 2500;
        } else if (this.rangeValue === this.rangeOptions[3]) {
            this.userMin = 2500;
            this.userMax = this.hugeNumber;
        } else if (this.rangeValue === this.rangeOptions[4]) {
            // User Specified Values
            this.processUserSpecifiedValues();
        }
    }

    public processUserSpecifiedValues() {
        // setting this allows us to set radio button (via ng-checked) even if user didn't select it before clinking Apply
        this.rangeValue = this.rangeOptions[4];

        if (this.userSpecifiedMin) {
            this.userMin = parseInt(this.userSpecifiedMin.toString());
        } else {
            this.userMin = this.zero;
        }
        if (this.userSpecifiedMax) {
            this.userMax = parseInt(this.userSpecifiedMax.toString());
        } else {
            this.userMax = this.hugeNumber;
        }
    }

    public reset() {
        this.initialize();
    }
}