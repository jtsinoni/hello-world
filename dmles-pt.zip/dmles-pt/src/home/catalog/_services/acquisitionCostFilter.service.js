define(["require", "exports"], function (require, exports) {
    'use strict';
    var AcquisitionCostFilter = (function () {
        // @ngInject
        function AcquisitionCostFilter() {
            this.zero = 0;
            this.hugeNumber = 100000000000; // 100 billion
            this.userMin = this.zero;
            this.userMax = this.hugeNumber;
            this.userSpecifiedMin = null;
            this.userSpecifiedMax = null;
            this.userMinValue = [];
            this.userMaxValue = [];
            this.rangeOptions = ["Any Cost", "$0 - $500", "$0 - $2,500", "More than $2500"];
            this.rangeValue = "Any Cost";
        }
        AcquisitionCostFilter.prototype.buildSearchClause = function () {
            var returnValue = "packPriceAmt:[";
            if (this.userMin === this.zero) {
                if (this.userMax === this.hugeNumber) {
                    returnValue = "";
                }
                else {
                    returnValue += "* TO " + this.userMax + "]";
                }
            }
            else {
                returnValue += this.userMin;
                if (this.userMax === this.hugeNumber) {
                    returnValue += " TO *]";
                }
                else {
                    returnValue += " TO " + this.userMax + "]";
                }
            }
            return returnValue;
        };
        AcquisitionCostFilter.prototype.initialize = function () {
            this.zero = 0;
            this.hugeNumber = 100000000000; // 100 billion
            this.userMin = this.zero;
            this.userMax = this.hugeNumber;
            this.userSpecifiedMin = null;
            this.userSpecifiedMax = null;
            this.userMinValue = [];
            this.userMaxValue = [];
            this.rangeOptions = ["Any Cost", "$0 - $500", "$0 - $2,500", "More than $2500"];
            this.rangeValue = "Any Cost";
        };
        AcquisitionCostFilter.prototype.process = function () {
            this.userMinValue = [{ selValue: this.userMin }];
            this.userMaxValue = [{ selValue: this.userMax }];
        };
        AcquisitionCostFilter.prototype.processRange = function () {
            if (this.rangeValue === this.rangeOptions[0]) {
                this.userMin = this.zero;
                this.userMax = this.hugeNumber;
            }
            else if (this.rangeValue === this.rangeOptions[1]) {
                this.userMin = this.zero;
                this.userMax = 500;
            }
            else if (this.rangeValue === this.rangeOptions[2]) {
                this.userMin = this.zero;
                this.userMax = 2500;
            }
            else if (this.rangeValue === this.rangeOptions[3]) {
                this.userMin = 2500;
                this.userMax = this.hugeNumber;
            }
            else if (this.rangeValue === this.rangeOptions[4]) {
                // User Specified Values
                this.processUserSpecifiedValues();
            }
        };
        AcquisitionCostFilter.prototype.processUserSpecifiedValues = function () {
            // setting this allows us to set radio button (via ng-checked) even if user didn't select it before clinking Apply
            this.rangeValue = this.rangeOptions[4];
            if (this.userSpecifiedMin) {
                this.userMin = parseInt(this.userSpecifiedMin.toString());
            }
            else {
                this.userMin = this.zero;
            }
            if (this.userSpecifiedMax) {
                this.userMax = parseInt(this.userSpecifiedMax.toString());
            }
            else {
                this.userMax = this.hugeNumber;
            }
        };
        AcquisitionCostFilter.prototype.reset = function () {
            this.initialize();
        };
        return AcquisitionCostFilter;
    }());
    exports.AcquisitionCostFilter = AcquisitionCostFilter;
});
//# sourceMappingURL=acquisitionCostFilter.service.js.map