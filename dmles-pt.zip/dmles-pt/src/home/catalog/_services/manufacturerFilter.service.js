var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", '../../../_common/_services/baseSelectFilter.service'], function (require, exports, baseSelectFilter_service_1) {
    'use strict';
    var ManufacturerFilter = (function (_super) {
        __extends(ManufacturerFilter, _super);
        // @ngInject
        function ManufacturerFilter(MultiSelectService) {
            _super.call(this);
            this.MultiSelectService = MultiSelectService;
            this.manufacturers = [];
        }
        ManufacturerFilter.prototype.load = function () {
            this.initialize();
            var n;
            for (n in this.manufacturers) {
                var selection = this.manufacturers[n];
                this.options.push(this.MultiSelectService.buildSelection(selection, selection, selection, false));
            }
        };
        ManufacturerFilter.prototype.initializeList = function () {
            if (this.optionsSelected.length === 0) {
                this.manufacturers = [];
            }
        };
        ManufacturerFilter.prototype.buildList = function (searchResult) {
            if (this.optionsSelected.length === 0) {
                this.manufacturers.push(searchResult.manufacturerNm);
            }
        };
        ManufacturerFilter.prototype.loadList = function () {
            if (this.optionsSelected.length === 0) {
                this.manufacturers = this.removeDuplicates(this.manufacturers);
                this.manufacturers = this.manufacturers.sort();
                this.load();
            }
        };
        ManufacturerFilter.prototype.reset = function () {
            this.manufacturers = [];
            this.initialize();
        };
        return ManufacturerFilter;
    }(baseSelectFilter_service_1.BaseSelectFilterService));
    exports.ManufacturerFilter = ManufacturerFilter;
});
//# sourceMappingURL=manufacturerFilter.service.js.map