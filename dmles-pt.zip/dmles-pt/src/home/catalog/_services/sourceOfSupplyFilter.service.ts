'use strict';

import {BaseSelectFilterService} from '../../../_common/_services/baseSelectFilter.service';

export class SourceOfSupplyFilter extends BaseSelectFilterService {
    public suppliers:Array<string> = [];

    // @ngInject
    constructor(private MultiSelectService) {
        super();
    }

    public load() {
        this.initialize();
        var n:string;
        for (n in this.suppliers) {
            var selection = this.suppliers[n];
            this.options.push(this.MultiSelectService.buildSelection(selection, selection, selection, false));
        }
    }

    public initializeList() {
        if (this.optionsSelected.length === 0) {
            this.suppliers = [];
        }
    }

    public buildList(searchResult:any) {
        if (this.optionsSelected.length === 0) {
            this.suppliers.push(searchResult.supplierNm);
        }
    }

    public loadList() {
        if (this.optionsSelected.length === 0) {
            this.suppliers = this.removeDuplicates(this.suppliers);
            this.suppliers = this.suppliers.sort();
            this.load();
        }
    }

    public reset() {
        this.suppliers = [];
        this.initialize();
    }
}