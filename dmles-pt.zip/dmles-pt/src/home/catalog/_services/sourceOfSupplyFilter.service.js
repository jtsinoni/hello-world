var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", '../../../_common/_services/baseSelectFilter.service'], function (require, exports, baseSelectFilter_service_1) {
    'use strict';
    var SourceOfSupplyFilter = (function (_super) {
        __extends(SourceOfSupplyFilter, _super);
        // @ngInject
        function SourceOfSupplyFilter(MultiSelectService) {
            _super.call(this);
            this.MultiSelectService = MultiSelectService;
            this.suppliers = [];
        }
        SourceOfSupplyFilter.prototype.load = function () {
            this.initialize();
            var n;
            for (n in this.suppliers) {
                var selection = this.suppliers[n];
                this.options.push(this.MultiSelectService.buildSelection(selection, selection, selection, false));
            }
        };
        SourceOfSupplyFilter.prototype.initializeList = function () {
            if (this.optionsSelected.length === 0) {
                this.suppliers = [];
            }
        };
        SourceOfSupplyFilter.prototype.buildList = function (searchResult) {
            if (this.optionsSelected.length === 0) {
                this.suppliers.push(searchResult.supplierNm);
            }
        };
        SourceOfSupplyFilter.prototype.loadList = function () {
            if (this.optionsSelected.length === 0) {
                this.suppliers = this.removeDuplicates(this.suppliers);
                this.suppliers = this.suppliers.sort();
                this.load();
            }
        };
        SourceOfSupplyFilter.prototype.reset = function () {
            this.suppliers = [];
            this.initialize();
        };
        return SourceOfSupplyFilter;
    }(baseSelectFilter_service_1.BaseSelectFilterService));
    exports.SourceOfSupplyFilter = SourceOfSupplyFilter;
});
//# sourceMappingURL=sourceOfSupplyFilter.service.js.map