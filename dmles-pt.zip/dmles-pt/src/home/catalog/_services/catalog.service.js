var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", '../../../_services/api.service', '../_models/catalogItem.model'], function (require, exports, api_service_1, catalogItem_model_1) {
    'use strict';
    var CatalogService = (function (_super) {
        __extends(CatalogService, _super);
        // @ngInject
        function CatalogService($http, $httpParamSerializerJQLike, $filter, $log, $state, Authentication, App, datatableService, NotificationService, RequestService, StateConstants, UtilService, WorkFlowService) {
            _super.call(this, $http, $log, Authentication, App, $httpParamSerializerJQLike, "EquipmentManagement");
            this.$filter = $filter;
            this.$state = $state;
            this.datatableService = datatableService;
            this.NotificationService = NotificationService;
            this.RequestService = RequestService;
            this.StateConstants = StateConstants;
            this.UtilService = UtilService;
            this.WorkFlowService = WorkFlowService;
            this.catalogItem = new catalogItem_model_1.CatalogItem();
            this.serviceName = "Catalog Service";
            this.catalogFavorites = [];
            this.$log.debug("%s - Start", this.serviceName);
        }
        /*
         Checks to see if the item is already in favorites and if it does, then it ignores the addition.
         Note: Filter says, compare the itemId field with newItem.item.itemId, true means
         return an exact match.
         */
        CatalogService.prototype.addToFavorites = function (newItem) {
            if (newItem && newItem.itemId) {
                var found = this.$filter('filter')(this.catalogFavorites, { itemId: newItem.itemId }, true);
                if (found.length === 0) {
                    this.catalogFavorites.push(angular.copy(newItem));
                    this.NotificationService.successMsg("New favorite item added");
                }
                else {
                    this.NotificationService.infoMsg("Item already saved in favorites");
                }
            }
            else {
                this.$log.warn("%s - Add to favorites, item not found", this.serviceName);
            }
        };
        CatalogService.prototype.addToRequest = function (equip) {
            var _this = this;
            if (equip && equip.itemId) {
                this.RequestService.clearRequest();
                this.setCatalogItem(equip);
                var getRequests = this.RequestService.getRequests();
                getRequests.then(function (result) {
                    _this.createActiveRequestTable(_this.filterActiveRequests(result));
                });
            }
            else {
                this.$log.warn("%s - Add to request, item not found", this.serviceName);
            }
        };
        CatalogService.prototype.buildRequest = function (item) {
            this.RequestService.clearRequest(); // TODO: Add ability to associate with an active request?
            this.RequestService.buildRequestFromCatalog(item);
            this.$state.go(this.StateConstants.EQUIP_REQUEST_VIEW);
        };
        CatalogService.prototype.clearCatalogItem = function () {
            this.catalogItem = null;
        };
        CatalogService.prototype.clearFavorites = function () {
            this.catalogFavorites = [];
        };
        CatalogService.prototype.createActiveRequestTable = function (data) {
            this.activeRequestTable = this.datatableService.createNgTable(data, 25, { updatedDate: 'desc' });
        };
        CatalogService.prototype.filterActiveRequests = function (requestList) {
            var _this = this;
            return this.$filter('filter')(requestList, function (o) {
                return o.wfProcessing && _this.WorkFlowService.isRequestAtUsersLevel(o);
            });
        };
        CatalogService.prototype.getCatalogItem = function () {
            if (this.catalogItem) {
                return this.catalogItem;
            }
            return null;
        };
        CatalogService.prototype.getEquipItems = function (searchValue, dodaac, userSpecifiedFilters) {
            //Note: check to see if anything got sent through, otherwise a string 'undefined' will be sent to bt.
            var dodaacStr = (dodaac) ? dodaac : "";
            var searchValue = (searchValue) ? searchValue : "";
            var userSpecifiedFilters = (userSpecifiedFilters) ? userSpecifiedFilters : "";
            // escape special characters
            searchValue = this.UtilService.esEscapeSpecialChars(searchValue);
            if (searchValue === "" || searchValue === "*") {
                searchValue = userSpecifiedFilters;
            }
            else {
                searchValue = searchValue + " " + userSpecifiedFilters;
            }
            // encode URI/URL reserved characters
            searchValue = encodeURIComponent(searchValue);
            return this.get("getCatalogSearchResults?searchValue=" + searchValue + "&?dodaac=" + dodaacStr);
        };
        CatalogService.prototype.getSearchStats = function (result) {
            var retVal = {
                "total": 0,
                "time": 0.00
            };
            if (result && result.data && result.data.hits) {
                if (result.data.hits.total) {
                    retVal.total = result.data.hits.total;
                }
                if (result.data.took) {
                    retVal.time = result.data.took;
                }
            }
            else {
                this.$log.debug("%s - Warning: No data returned", this.serviceName);
            }
            return retVal;
        };
        CatalogService.prototype.parseEquipResults = function (results) {
            var equipList = [];
            if (results && results.data.hits.hits) {
                var esResults = results.data.hits.hits;
                // TODO: This iteration may not be needed once dmles-gui pulls from the Java EndPoint for
                // ES equipment search results.  Currently dmles-gui is hitting ES directly, which nests the
                // equipment search results under data.hits.hits.fields.
                for (var i in esResults) {
                    var resultItem = esResults[i];
                    if (resultItem.hasOwnProperty("fields")) {
                        var catItem = new catalogItem_model_1.CatalogItem();
                        for (var key in resultItem.fields) {
                            var value = resultItem.fields[key];
                            catItem[key] = value[0];
                        }
                        equipList.push(catItem);
                    }
                }
            }
            else {
                this.$log.debug("%s - Warning: No data returned", this.serviceName);
            }
            return equipList;
        };
        CatalogService.prototype.removeFromFavorites = function (item) {
            var index = this.catalogFavorites.indexOf(item);
            this.catalogFavorites.splice(index, 1);
        };
        CatalogService.prototype.setCatalogItem = function (item) {
            this.catalogItem = new catalogItem_model_1.CatalogItem(angular.copy(item));
        };
        return CatalogService;
    }(api_service_1.ApiService));
    exports.CatalogService = CatalogService;
});
//# sourceMappingURL=catalog.service.js.map