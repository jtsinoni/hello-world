'use strict';

export class ShellController {
    viewName: string;
    public requestSearch;
    public

    // @ngInject
    constructor(private $filter, private $log, private $state, private CatalogService,
                private RequestService, private StateConstants, private WorkFlowService) {
        this.init();
    }

    public addCatalogItemToRequest(){
        //This checks if the item already has a requested Item Id it will not overwrite
        if(!this.RequestService.request.requestInformation.equipment.catalogId &&
            !this.RequestService.request.requestInformation.equipment.description){
            this.RequestService.addCatalogInfoToRequest(this.CatalogService.getCatalogItem());
        }
        else{
            this.RequestService.request.catalogItem = this.CatalogService.getCatalogItem();
            this.RequestService.request.requestInformation.quantityRequested = this.RequestService.request.catalogItem.quantity;
            this.RequestService.request.requestInformation.equipment.unitCost = this.RequestService.request.catalogItem.burdenedPriceAmt;
        }


        var saveRequest = this.RequestService.save();
        saveRequest.then((result) => {
            if(result) {
                this.$state.go(this.StateConstants.EQUIP_REQUEST_VIEW);
            }
        });
    }

    public requestsFilter() {
        this.CatalogService.activeRequestTable.filter({$: this.requestSearch});
        this.CatalogService.activeRequestTable.reload();
    }

    public setSelected(request, id) {
        angular.element(id).addClass("background-gray").siblings().removeClass("background-gray");
        this.RequestService.request = request;
    }

    init(){
        this.viewName = 'Shell View';
    }
}