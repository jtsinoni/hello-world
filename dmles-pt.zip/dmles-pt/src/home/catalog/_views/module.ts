'use strict';

import {CatalogFavoritesController} from './catalogFavorites.controller';
import {CatalogItemDetailsController} from './catalogItemDetails.controller';
import {CatalogSearchController} from './catalogSearch.controller';
import {CustomerCatalogController} from './customerCatalog.controller';
import {ItemDetailsController} from './itemDetails.controller';

var controllersModule = angular.module('Dmles.Home.Catalog.Views.Module', []);
controllersModule.controller('CatalogFavoritesController', CatalogFavoritesController);
controllersModule.controller('CatalogItemDetailsController', CatalogItemDetailsController);
controllersModule.controller('CatalogSearchController', CatalogSearchController);
controllersModule.controller('CustomerCatalogController', CustomerCatalogController);
controllersModule.controller('ItemDetailsController', ItemDetailsController);

export default controllersModule;