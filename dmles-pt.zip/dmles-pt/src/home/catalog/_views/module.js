define(["require", "exports", './catalogFavorites.controller', './catalogItemDetails.controller', './catalogSearch.controller', './itemDetails.controller'], function (require, exports, catalogFavorites_controller_1, catalogItemDetails_controller_1, catalogSearch_controller_1, itemDetails_controller_1) {
    'use strict';
    var controllersModule = angular.module('Dmles.Home.Catalog.Views.Module', []);
    controllersModule.controller('CatalogFavoritesController', catalogFavorites_controller_1.CatalogFavoritesController);
    controllersModule.controller('CatalogItemDetailsController', catalogItemDetails_controller_1.CatalogItemDetailsController);
    controllersModule.controller('CatalogSearchController', catalogSearch_controller_1.CatalogSearchController);
    controllersModule.controller('ItemDetailsController', itemDetails_controller_1.ItemDetailsController);
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = controllersModule;
});
//# sourceMappingURL=module.js.map