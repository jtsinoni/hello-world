'use strict';

export class CatalogItemDetailsController {
    private controllerName:string = "Catalog Item Details Controller";

    // @ngInject
    constructor(private $log, private $rootScope, private CatalogService, private StateConstants,
                private UserService, private UserTypeConstants) {
        this.$log.debug("%s - Start", this.controllerName);
    }
}

