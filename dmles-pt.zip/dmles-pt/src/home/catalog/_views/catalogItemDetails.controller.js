define(["require", "exports"], function (require, exports) {
    'use strict';
    var CatalogItemDetailsController = (function () {
        // @ngInject
        function CatalogItemDetailsController($log, $rootScope, CatalogService, StateConstants, UserService, UserTypeConstants) {
            this.$log = $log;
            this.$rootScope = $rootScope;
            this.CatalogService = CatalogService;
            this.StateConstants = StateConstants;
            this.UserService = UserService;
            this.UserTypeConstants = UserTypeConstants;
            this.controllerName = "Catalog Item Details Controller";
            this.$log.debug("%s - Start", this.controllerName);
        }
        return CatalogItemDetailsController;
    }());
    exports.CatalogItemDetailsController = CatalogItemDetailsController;
});
//# sourceMappingURL=catalogItemDetails.controller.js.map