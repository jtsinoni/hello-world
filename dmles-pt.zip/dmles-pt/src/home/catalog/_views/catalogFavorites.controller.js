define(["require", "exports", '../_models/catalogItem.model'], function (require, exports, catalogItem_model_1) {
    'use strict';
    var CatalogFavoritesController = (function () {
        // @ngInject
        function CatalogFavoritesController($log, $rootScope, $state, CatalogService, EquipmentRecordService, RequestService, StateConstants, UserService, UserTypeConstants) {
            this.$log = $log;
            this.$rootScope = $rootScope;
            this.$state = $state;
            this.CatalogService = CatalogService;
            this.EquipmentRecordService = EquipmentRecordService;
            this.RequestService = RequestService;
            this.StateConstants = StateConstants;
            this.UserService = UserService;
            this.UserTypeConstants = UserTypeConstants;
            this.controllerName = "Catalog Favorites Controller";
            this.$log.debug("%s - Start", this.controllerName);
            $(window).scrollTop(0);
        }
        // TODO: Add catItem to request service not the catalog service
        CatalogFavoritesController.prototype.createRequest = function (catItem) {
            this.$log.debug("%s - Sending item to Create a Request: %s", this.controllerName, catItem.shortItemDesc);
            //this.CatalogService.setCatalogItem(catItem);
            this.RequestService.clearRequest(); // TODO: Add ability to associate with an active request?
            this.RequestService.buildRequestFromCatalog(catItem, catItem.cartQuantity);
            this.$state.go(this.StateConstants.EQUIP_REQUEST_VIEW);
        };
        CatalogFavoritesController.prototype.goToDetails = function (item) {
            this.CatalogService.setCatalogItem(new catalogItem_model_1.CatalogItem(item));
            this.$state.go(this.StateConstants.CATALOG_ITEM_DETAILS); //TODO put new/correct state here.
        };
        CatalogFavoritesController.prototype.gotToEquipmentRecord = function (cartItem, isActive) {
            var erSearchObj = {
                "catalogItem": cartItem,
                "isActive": isActive
            };
            this.EquipmentRecordService.itemFromCatalog = erSearchObj;
            this.$state.go(this.StateConstants.EQUIP_RECORD_DETAILS);
        };
        CatalogFavoritesController.prototype.goToPreviousState = function () {
            if (this.$rootScope.previousState) {
                this.$state.go(this.$rootScope.previousState);
            }
            else {
                this.$state.go(this.StateConstants.CATALOG_SEARCH);
            }
        };
        return CatalogFavoritesController;
    }());
    exports.CatalogFavoritesController = CatalogFavoritesController;
});
//# sourceMappingURL=catalogFavorites.controller.js.map