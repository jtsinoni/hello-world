'use strict';

import {CatalogItem} from '../_models/catalogItem.model';

export class CatalogFavoritesController {
    private controllerName:string = "Catalog Favorites Controller";

    // @ngInject
    constructor(private $log, private $rootScope, private $state, private CatalogService,
                private EquipmentRecordService, private RequestService, private StateConstants, private UserService, private UserTypeConstants) {
        this.$log.debug("%s - Start", this.controllerName);
        $(window).scrollTop(0);
    }

    // TODO: Add catItem to request service not the catalog service
    public createRequest(catItem) {
        this.$log.debug("%s - Sending item to Create a Request: %s", this.controllerName, catItem.shortItemDesc);
        //this.CatalogService.setCatalogItem(catItem);
        this.RequestService.clearRequest();  // TODO: Add ability to associate with an active request?
        this.RequestService.buildRequestFromCatalog(catItem, catItem.cartQuantity);
        this.$state.go(this.StateConstants.EQUIP_REQUEST_VIEW);
    }

    public goToDetails(item) {
        this.CatalogService.setCatalogItem(new CatalogItem(item));
        this.$state.go(this.StateConstants.CATALOG_ITEM_DETAILS); //TODO put new/correct state here.
    }

    public gotToEquipmentRecord(cartItem, isActive) {
        var erSearchObj:any = {
            "catalogItem": cartItem,
            "isActive": isActive
        };
        this.EquipmentRecordService.itemFromCatalog = erSearchObj;
        this.$state.go(this.StateConstants.EQUIP_RECORD_DETAILS);
    }

    public goToPreviousState() {
        if(this.$rootScope.previousState){
            this.$state.go(this.$rootScope.previousState);
        }else{
            this.$state.go(this.StateConstants.CATALOG_SEARCH);
        }
    }

}