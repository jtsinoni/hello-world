'use strict';
import {CatalogItem} from '../_models/catalogItem.model';

export class ItemDetailsController {
    private controllerName:string = "Item Details Controller";
    public previousState:string;

    // @ngInject
    constructor(private $log, private $rootScope, private $state, private RequestService,
                private EquipmentRecordService, private StateConstants, private UserService, private UserTypeConstants) {
        this.$log.debug("%s - Start", this.controllerName);
        this.previousState = this.$rootScope.previousState;
    }

    public gotToEquipmentRecord(item, isActive) {
        var erSearchObj:any = {
            "catalogItem": item,
            "isActive": isActive
        };
        this.EquipmentRecordService.itemFromCatalog = erSearchObj;
        this.$state.go(this.StateConstants.EQUIP_RECORD_SEARCH);
    }
}

