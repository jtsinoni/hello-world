define(["require", "exports", "../../../_models/currentUserProfile.model"], function (require, exports, currentUserProfile_model_1) {
    'use strict';
    var CatalogSearchController = (function () {
        // @ngInject
        function CatalogSearchController($log, $state, AcquisitionCostFilter, CatalogService, ContentConstants, datatableService, EquipmentRecordService, ManufacturerFilter, NotificationService, SidePanelService, SourceOfSupplyFilter, RequestService, StateConstants, UserService, UserTypeConstants, UtilService) {
            this.$log = $log;
            this.$state = $state;
            this.AcquisitionCostFilter = AcquisitionCostFilter;
            this.CatalogService = CatalogService;
            this.ContentConstants = ContentConstants;
            this.datatableService = datatableService;
            this.EquipmentRecordService = EquipmentRecordService;
            this.ManufacturerFilter = ManufacturerFilter;
            this.NotificationService = NotificationService;
            this.SidePanelService = SidePanelService;
            this.SourceOfSupplyFilter = SourceOfSupplyFilter;
            this.RequestService = RequestService;
            this.StateConstants = StateConstants;
            this.UserService = UserService;
            this.UserTypeConstants = UserTypeConstants;
            this.UtilService = UtilService;
            this.controllerName = "Catalog Search Controller";
            this.searchStats = {};
            this.userSpecifiedFilters = "";
            this.catalogSearchResults = [];
            this.currUser = new currentUserProfile_model_1.CurrentUserProfile();
            this.ngCatalogTable = null;
            this.searchPlaceholder = "What are you looking for? Try searching our catalog ...";
            this.sortOrder = "shortItemDesc";
            this.$log.debug("%s - Start", this.controllerName);
            $(window).scrollTop(0);
            this.currUser = this.UserService.currentUser;
            this.searchMaxResultsText = "Over " + this.ContentConstants.SEARCH_MAX + " items have been found, please refine your search";
            this.init();
        }
        CatalogSearchController.prototype.init = function () {
            this.ManufacturerFilter.load();
            this.SourceOfSupplyFilter.load();
            this.AcquisitionCostFilter.initialize();
        };
        CatalogSearchController.prototype.applyFilters = function () {
            this.showMaxResultsWarning = false;
            this.populateDropDownFiltersPerCurrentResults();
            this.ngCatalogTable = this.datatableService.createNgTable(this.catalogSearchResults);
            if (this.ContentConstants.SEARCH_MAX <= this.catalogSearchResults.length) {
                this.catalogSearchStats = this.UtilService.esBuildSearchStatsStr(this.searchStats.total, this.searchStats.time);
                this.showMaxResultsWarning = true;
                this.NotificationService.warningMsg("The maximum search results were reached, please refine your search.");
            }
            else {
                this.catalogSearchStats = this.UtilService.esBuildSearchStatsStr(this.catalogSearchResults.length, this.searchStats.time);
            }
            this.isLoadingSearch = false;
        };
        CatalogSearchController.prototype.getCatalogItems = function () {
            var _this = this;
            this.isLoadingSearch = true;
            this.catalogSearchStats = "";
            this.processUserSpecifiedFilters();
            // this.CatalogService.getEquipItems(this.searchInput, this.currUser.defaultDodaac.siteDodaac, this.userSpecifiedFilters).then((response:IHttpPromiseCallbackArg<any>) => {
            this.CatalogService.getEquipItems(this.searchInput, this.currUser.dodaac, this.userSpecifiedFilters).then(function (response) {
                _this.catalogSearchResults = _this.CatalogService.parseEquipResults(response);
                _this.searchStats = _this.CatalogService.getSearchStats(response);
                _this.applyFilters();
            }, function (errResponse) {
                _this.isLoadingSearch = false;
                _this.$log.debug("%s - Error getting catalog items from elastic.", _this.controllerName);
                _this.NotificationService.errorMsg("An error occured while retrieving catalog items");
            });
        };
        CatalogSearchController.prototype.executeSearch = function () {
            this.$log.debug("%s - UpdateCatalogSearch: %s", this.controllerName, this.searchInput);
            this.getCatalogItems();
        };
        CatalogSearchController.prototype.goToDetails = function (equipItem) {
            this.CatalogService.setCatalogItem(equipItem);
            this.RequestService.getRequests();
            this.$state.go(this.StateConstants.CATALOG_ITEM_DETAILS);
        };
        //public goToBuildRequest(selectedItem) {
        //    this.$log.debug("%s - Sending item to Create a Request: %s", this.controllerName, selectedItem.shortItemDesc);
        //
        //    //this.RequestService.clearRequest();  // TODO: Add ability to associate with an active request?
        //    //this.RequestService.buildRequestFromCatalog(selectedItem);
        //    //this.$state.go(this.StateConstants.EQUIP_REQUEST_VIEW);
        //}
        CatalogSearchController.prototype.gotToEquipmentRecord = function (catalogItem, isActive) {
            // TODO: Send catalogItem to Equipment Record Service to be used in the equipment controller to pre-fill the search options
            var erSearchObj = {
                "catalogItem": catalogItem,
                "isActive": isActive
            };
            this.EquipmentRecordService.itemFromCatalog = erSearchObj;
            this.$state.go(this.StateConstants.EQUIP_RECORD_SEARCH);
        };
        CatalogSearchController.prototype.goToCreateRequest = function () {
            this.CatalogService.clearCatalogItem();
            this.RequestService.clearRequest();
            this.$state.go(this.StateConstants.EQUIP_REQUEST_VIEW);
        };
        /**
         * Refine By Filters
         */
        CatalogSearchController.prototype.processFilters = function () {
            this.ManufacturerFilter.processOptionsSelected();
            this.SourceOfSupplyFilter.processOptionsSelected();
            this.AcquisitionCostFilter.processOptionsSelected();
            //Getting the filtered list
            if (this.catalogSearchResults.length === 0) {
                this.getCatalogItems();
            }
            else {
                this.applyFilters();
            }
        };
        CatalogSearchController.prototype.resetFilters = function () {
            this.ManufacturerFilter.reset();
            this.AcquisitionCostFilter.reset();
            this.SourceOfSupplyFilter.reset();
            this.executeSearch();
        };
        CatalogSearchController.prototype.buildLists = function (searchResult) {
            this.ManufacturerFilter.buildList(searchResult);
            this.SourceOfSupplyFilter.buildList(searchResult);
        };
        CatalogSearchController.prototype.loadLists = function () {
            this.ManufacturerFilter.loadList();
            this.SourceOfSupplyFilter.loadList();
        };
        CatalogSearchController.prototype.initializeLists = function () {
            this.ManufacturerFilter.initializeList();
            this.SourceOfSupplyFilter.initializeList();
        };
        CatalogSearchController.prototype.populateDropDownFiltersPerCurrentResults = function () {
            this.initializeLists();
            var n;
            for (n in this.catalogSearchResults) {
                this.buildLists(this.catalogSearchResults[n]);
            }
            this.loadLists();
        };
        CatalogSearchController.prototype.processUserSpecifiedFilters = function () {
            this.userSpecifiedFilters = "";
            this.userSpecifiedFilters = this.userSpecifiedFilters.trim() + " " + this.AcquisitionCostFilter.buildSearchClause();
            this.userSpecifiedFilters = this.userSpecifiedFilters.trim() + " " + this.ManufacturerFilter.buildSearchClause("manufacturerNm");
            this.userSpecifiedFilters = this.userSpecifiedFilters.trim() + " " + this.SourceOfSupplyFilter.buildSearchClause("supplierNm");
            this.userSpecifiedFilters = this.userSpecifiedFilters.trim();
        };
        return CatalogSearchController;
    }());
    exports.CatalogSearchController = CatalogSearchController;
});
//# sourceMappingURL=catalogSearch.controller.js.map