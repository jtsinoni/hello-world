/*
TODO: Need to add states and permissions to DB.
 */
export class CustomerCatalogController {
    private controllerName:string = "Customer Catalog Controller";

    public gridData:any;
    public gridOpts:any;

    // @ngInject
    constructor(private $log, private CatalogService, private ContentConstants, private NotificationService, private PermissionService, private ResourceConstants, private SidePanelService, private uiGridConstants) {
        this.$log.debug("%s - Start", this.controllerName);
        $(window).scrollTop(0);
        this.init();
    }

    private init() {
        this.buildGridOpts();
        this.loadData();
    }

    private buildGridOpts(){
        this.gridOpts = {
            data: null,
            enableCellEditOnFocus: false,
            enableColumnResizing: false,
            enableFiltering: true,
            enableGridMenu: true,
            enablePaginationControls: false,
            enableRowHeaderSelection: false,
            enableRowSelection: true,
            enableSelectAll: true,
            enableSorting: true,
            exporterCsvFilename: 'data.csv',
            multiSelect: false,
            showColumnFooter: false,
            showGridFooter:true,
            columnDefs: [
                { field: 'id', displayName: 'id', visible: false, },
                { field: 'shortItemDesc', displayName: 'Name', filterCellFiltered:true, sort: { direction: this.uiGridConstants.DESC } },
                { field: 'longItemDesc', displayName: 'Description' },

                { field: 'packPriceAmt', displayName: 'Price' },
                { field: 'upCreateDt', displayName: 'Created Date', cellFilter: 'date:"'+this.ContentConstants.FORMAT_DATE_TIME+'"'  }
            ]
        };
    }

    private loadData() {
        this.CatalogService.getEquipItems("test", "W33DME", "").then((response: any) => {
            this.gridData = this.CatalogService.parseEquipResults(response);
        }, (errResponse: any) => {
            this.$log.error("Error retrieving data");
            this.NotificationService.errorMsg("Unable to retrieve data");
        });
    }

}