define(["require", "exports"], function (require, exports) {
    'use strict';
    var ItemDetailsController = (function () {
        // @ngInject
        function ItemDetailsController($log, $rootScope, $state, RequestService, EquipmentRecordService, StateConstants, UserService, UserTypeConstants) {
            this.$log = $log;
            this.$rootScope = $rootScope;
            this.$state = $state;
            this.RequestService = RequestService;
            this.EquipmentRecordService = EquipmentRecordService;
            this.StateConstants = StateConstants;
            this.UserService = UserService;
            this.UserTypeConstants = UserTypeConstants;
            this.controllerName = "Item Details Controller";
            this.$log.debug("%s - Start", this.controllerName);
            this.previousState = this.$rootScope.previousState;
        }
        ItemDetailsController.prototype.gotToEquipmentRecord = function (item, isActive) {
            var erSearchObj = {
                "catalogItem": item,
                "isActive": isActive
            };
            this.EquipmentRecordService.itemFromCatalog = erSearchObj;
            this.$state.go(this.StateConstants.EQUIP_RECORD_SEARCH);
        };
        return ItemDetailsController;
    }());
    exports.ItemDetailsController = ItemDetailsController;
});
//# sourceMappingURL=itemDetails.controller.js.map