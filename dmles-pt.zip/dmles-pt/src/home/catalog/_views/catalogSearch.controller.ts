'use strict';

import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {CatalogItem} from '../_models/catalogItem.model';
import {CurrentUserProfile} from "../../../_models/currentUserProfile.model";

export class CatalogSearchController {
    private controllerName:string = "Catalog Search Controller";
    private searchStats:any = {};
    private userSpecifiedFilters:string = "";

    public abiSearchResults:Array<CatalogItem> = [];
    public catalogSearchStats:string;
    public currUser:CurrentUserProfile = new CurrentUserProfile();
    public isLoadingSearch:boolean;

    public ngCatalogTable:any = null;
    public searchInput:string;
    public searchMaxResultsText:string;
    public searchPlaceholder:string = "What are you looking for? Try searching our catalog ...";
    public showMaxResultsWarning:boolean;
    public sortOrder:string = "shortItemDesc";

    // @ngInject
    constructor(private $log, private $state, private AcquisitionCostFilter, private CatalogService, private ContentConstants,
                private datatableService, private EquipmentRecordService, private ManufacturerFilter, private NotificationService,
                private SidePanelService, private SourceOfSupplyFilter, private RequestService,
                private StateConstants, private UserService, private UserTypeConstants, private UtilService) {
        this.$log.debug("%s - Start", this.controllerName);
        $(window).scrollTop(0);
        this.currUser = this.UserService.currentUser;
        this.searchMaxResultsText = "Over " + this.ContentConstants.SEARCH_MAX + " items have been found, please refine your search";
        this.init();
    }

    private init() {
        this.ManufacturerFilter.load();
        this.SourceOfSupplyFilter.load();
        this.AcquisitionCostFilter.initialize();
    }

    private applyFilters() {
        this.showMaxResultsWarning = false;
        this.populateDropDownFiltersPerCurrentResults();

        this.ngCatalogTable = this.datatableService.createNgTable(this.abiSearchResults);

        if (this.ContentConstants.SEARCH_MAX <= this.abiSearchResults.length) {
            this.catalogSearchStats = this.UtilService.esBuildSearchStatsStr(this.searchStats.total, this.searchStats.time);
            this.showMaxResultsWarning = true;
            this.NotificationService.warningMsg("The maximum search results were reached, please refine your search.");
        } else {
            this.catalogSearchStats = this.UtilService.esBuildSearchStatsStr( this.abiSearchResults.length, this.searchStats.time);
        }
        this.isLoadingSearch = false;
    }

    private getCatalogItems() {
        this.isLoadingSearch = true;
        this.catalogSearchStats = "";
        this.processUserSpecifiedFilters();

        // this.CatalogService.getEquipItems(this.searchInput, this.currUser.defaultDodaac.siteDodaac, this.userSpecifiedFilters).then((response:IHttpPromiseCallbackArg<any>) => {
        this.CatalogService.getEquipItems(this.searchInput, this.currUser.dodaac, this.userSpecifiedFilters).then((response: IHttpPromiseCallbackArg<any>) => {
            this.abiSearchResults = this.CatalogService.parseEquipResults(response);
            this.searchStats = this.CatalogService.getSearchStats(response);
            this.applyFilters();
        }, (errResponse:IHttpPromiseCallbackArg<boolean>) => {
            this.isLoadingSearch = false;
            this.$log.debug("%s - Error getting catalog items from elastic.", this.controllerName);
            this.NotificationService.errorMsg("An error occurred while retrieving catalog items");
        });
    }

    public executeSearch(searchCriteria) {
        this.searchInput = searchCriteria;
        this.$log.debug("%s - UpdateCatalogSearch: %s", this.controllerName, this.searchInput);
        this.getCatalogItems();
    }

    public goToDetails(equipItem) {
        this.CatalogService.setCatalogItem(equipItem);
        this.RequestService.getRequests();
        this.$state.go(this.StateConstants.CATALOG_ITEM_DETAILS);
    }

    //public goToBuildRequest(selectedItem) {
    //    this.$log.debug("%s - Sending item to Create a Request: %s", this.controllerName, selectedItem.shortItemDesc);
    //
    //    //this.RequestService.clearRequest();  // TODO: Add ability to associate with an active request?
    //    //this.RequestService.buildRequestFromCatalog(selectedItem);
    //    //this.$state.go(this.StateConstants.EQUIP_REQUEST_VIEW);
    //}

    public gotToEquipmentRecord(catalogItem, isActive) {
        // TODO: Send catalogItem to Equipment Record Service to be used in the equipment controller to pre-fill the search options
        var erSearchObj:any = {
            "catalogItem": catalogItem,
            "isActive": isActive
        };
        this.EquipmentRecordService.itemFromCatalog = erSearchObj;
        this.$state.go(this.StateConstants.EQUIP_RECORD_SEARCH);
    }

    public goToCreateRequest() {
        this.CatalogService.clearCatalogItem();
        this.RequestService.clearRequest();
        this.$state.go(this.StateConstants.EQUIP_REQUEST_VIEW);
    }

    /**
     * Refine By Filters
     */
    public processFilters() {
        this.ManufacturerFilter.processOptionsSelected();
        this.SourceOfSupplyFilter.processOptionsSelected();
        this.AcquisitionCostFilter.processOptionsSelected();

        //Getting the filtered list
        if (this.abiSearchResults.length === 0) {
            this.getCatalogItems();
        }
        else {
            this.applyFilters();
        }
    }

    public resetFilters() {
        this.ManufacturerFilter.reset();
        this.AcquisitionCostFilter.reset();
        this.SourceOfSupplyFilter.reset();
        this.executeSearch(this.searchInput);
    }

    private buildLists(searchResult:any) {
        this.ManufacturerFilter.buildList(searchResult);
        this.SourceOfSupplyFilter.buildList(searchResult);
    }

    private loadLists() {
        this.ManufacturerFilter.loadList();
        this.SourceOfSupplyFilter.loadList();
    }

    private initializeLists() {
        this.ManufacturerFilter.initializeList();
        this.SourceOfSupplyFilter.initializeList();
    }

    private populateDropDownFiltersPerCurrentResults() {
        this.initializeLists();
        var n:string;
        for (n in this.abiSearchResults) {
            this.buildLists(this.abiSearchResults[n]);
        }
        this.loadLists();
    }

    private processUserSpecifiedFilters() {
        this.userSpecifiedFilters = "";
        this.userSpecifiedFilters = this.userSpecifiedFilters.trim() + " " + this.AcquisitionCostFilter.buildSearchClause();
        this.userSpecifiedFilters = this.userSpecifiedFilters.trim() + " " + this.ManufacturerFilter.buildSearchClause("manufacturerNm");
        this.userSpecifiedFilters = this.userSpecifiedFilters.trim() + " " + this.SourceOfSupplyFilter.buildSearchClause("supplierNm");
        this.userSpecifiedFilters = this.userSpecifiedFilters.trim();
    }

}