'use strict';

class Router {
    static instance:any;

    // @ngInject
    constructor($stateProvider, $urlRouterProvider, StateConstants) {

        $stateProvider
            .state(StateConstants.CATALOG_SHELL, {
                url: '/catalog',
                templateUrl: '/src/home/catalog/shell.html',
                controller: 'Dmles.Home.Catalog.ShellController',
                controllerAs: 'vm',
                abstract: true
            }).state(StateConstants.CATALOG_FAVS, {
                url: '/favorites',
                templateUrl: '/src/home/catalog/_views/catalogFavorites.html',
                controller: 'CatalogFavoritesController',
                controllerAs: 'vm',
                data: {
                    displayName: 'Catalog Favorites'
                }
            }).state(StateConstants.CATALOG_SEARCH, {
                url: '/search',
                templateUrl: '/src/home/catalog/_views/catalogSearch.html',
                controller: 'CatalogSearchController',
                controllerAs: 'vm',
                data: {
                    displayName: 'Equipment Catalog Search'
                }
            }).state(StateConstants.CATALOG_ITEM_DETAILS, {
                url: '/details',
                templateUrl: '/src/home/catalog/_views/catalogItemDetails.html',
                controller: 'CatalogItemDetailsController',
                controllerAs: 'vm',
                data: {
                    displayName: 'Details'
                }
            });
    }

    static factory($stateProvider, $urlRouterProvider, StateConstants) {
        Router.instance = new Router($stateProvider, $urlRouterProvider, StateConstants);
        return Router.instance;
    }
}

Router.factory.$inject = ['$stateProvider', '$urlRouterProvider', 'StateConstants'];

export default Router;