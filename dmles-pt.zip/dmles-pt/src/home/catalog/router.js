define(["require", "exports"], function (require, exports) {
    'use strict';
    var Router = (function () {
        // @ngInject
        function Router($stateProvider, $urlRouterProvider, StateConstants) {
            $stateProvider
                .state(StateConstants.CATALOG_SHELL, {
                url: '/catalog',
                templateUrl: '/src/home/catalog/shell.html',
                controller: 'Dmles.Home.Catalog.ShellController',
                controllerAs: 'vm',
                abstract: true
            }).state(StateConstants.CATALOG_FAVS, {
                url: '/favorites',
                templateUrl: '/src/home/catalog/_views/catalogFavorites.html',
                controller: 'CatalogFavoritesController',
                controllerAs: 'vm',
                data: {
                    displayName: 'Catalog Favorites'
                }
            }).state(StateConstants.CATALOG_SEARCH, {
                url: '/search',
                templateUrl: '/src/home/catalog/_views/catalogSearch.html',
                controller: 'CatalogSearchController',
                controllerAs: 'vm',
                data: {
                    displayName: 'Equipment Catalog Search'
                }
            }).state(StateConstants.CATALOG_ITEM_DETAILS, {
                url: '/details',
                templateUrl: '/src/home/catalog/_views/catalogItemDetails.html',
                controller: 'CatalogItemDetailsController',
                controllerAs: 'vm',
                data: {
                    displayName: 'Details'
                }
            });
        }
        Router.factory = function ($stateProvider, $urlRouterProvider, StateConstants) {
            Router.instance = new Router($stateProvider, $urlRouterProvider, StateConstants);
            return Router.instance;
        };
        return Router;
    }());
    Router.factory.$inject = ['$stateProvider', '$urlRouterProvider', 'StateConstants'];
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = Router;
});
//# sourceMappingURL=router.js.map