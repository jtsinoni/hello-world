define(["require", "exports", './router', './shell.controller', './_models/module', './_services/module', './_views/module'], function (require, exports, router_1, shell_controller_1, module_1, module_2, module_3) {
    'use strict';
    var module = angular.module('Dmles.Home.CatalogModule', [
        module_3.default.name,
        module_1.default.name,
        module_2.default.name
    ]);
    module.controller('Dmles.Home.Catalog.ShellController', shell_controller_1.ShellController);
    module.config(router_1.default.factory);
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = module;
});
//# sourceMappingURL=module.js.map