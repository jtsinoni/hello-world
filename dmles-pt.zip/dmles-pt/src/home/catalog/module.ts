'use strict';

import router from './router';
import {ShellController} from './shell.controller';

// modules
import modelsModule from './_models/module';
import servicesModule from './_services/module';
import controllersModule from './_views/module';

var module = angular.module('Dmles.Home.CatalogModule', [
	controllersModule.name,
	modelsModule.name,
    servicesModule.name
]);

module.controller('Dmles.Home.Catalog.ShellController', ShellController);
module.config(router.factory);

export default module;