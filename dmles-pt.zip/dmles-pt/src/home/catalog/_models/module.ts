'use strict';

import {CatalogItem} from './catalogItem.model';

var modelsModule = angular.module('Dmles.Home.Catalog.Module', []);
modelsModule.value('CatalogItem', CatalogItem);

export default modelsModule;