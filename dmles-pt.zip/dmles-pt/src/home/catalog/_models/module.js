define(["require", "exports", './catalogItem.model'], function (require, exports, catalogItem_model_1) {
    'use strict';
    var modelsModule = angular.module('Dmles.Home.Catalog.Module', []);
    modelsModule.value('CatalogItem', catalogItem_model_1.CatalogItem);
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = modelsModule;
});
//# sourceMappingURL=module.js.map