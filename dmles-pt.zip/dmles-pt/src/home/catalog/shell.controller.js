define(["require", "exports"], function (require, exports) {
    'use strict';
    var ShellController = (function () {
        // @ngInject
        function ShellController($filter, $log, $state, CatalogService, RequestService, StateConstants, WorkFlowService) {
            this.$filter = $filter;
            this.$log = $log;
            this.$state = $state;
            this.CatalogService = CatalogService;
            this.RequestService = RequestService;
            this.StateConstants = StateConstants;
            this.WorkFlowService = WorkFlowService;
            this.init();
        }
        ShellController.prototype.addCatalogItemToRequest = function () {
            var _this = this;
            //This checks if the item already has a requested Item Id it will not overwrite
            if (!this.RequestService.request.requestInformation.equipment.catalogId &&
                !this.RequestService.request.requestInformation.equipment.description) {
                this.RequestService.addCatalogInfoToRequest(this.CatalogService.getCatalogItem());
            }
            else {
                this.RequestService.request.catalogItem = this.CatalogService.getCatalogItem();
                this.RequestService.request.requestInformation.quantityRequested = this.RequestService.request.catalogItem.quantity;
                this.RequestService.request.requestInformation.equipment.unitCost = this.RequestService.request.catalogItem.burdenedPriceAmt;
            }
            var saveRequest = this.RequestService.save();
            saveRequest.then(function (result) {
                if (result) {
                    _this.$state.go(_this.StateConstants.EQUIP_REQUEST_VIEW);
                }
            });
        };
        ShellController.prototype.requestsFilter = function () {
            this.CatalogService.activeRequestTable.filter({ $: this.requestSearch });
            this.CatalogService.activeRequestTable.reload();
        };
        ShellController.prototype.setSelected = function (request, id) {
            angular.element(id).addClass("background-gray").siblings().removeClass("background-gray");
            this.RequestService.request = request;
        };
        ShellController.prototype.init = function () {
            this.viewName = 'Shell View';
        };
        return ShellController;
    }());
    exports.ShellController = ShellController;
});
//# sourceMappingURL=shell.controller.js.map