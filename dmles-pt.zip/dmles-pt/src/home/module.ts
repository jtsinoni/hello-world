'use strict';

import router from './router';
import {HomeShellController} from './homeShell.controller';

import adminModule from './admin/module';
import catalogModule from './catalog/module';
import dashboardModule from './dashboard/module';
import equipmentModule from './equipment/module';
import jmarModule from './jmar/module';
import viewsModule from './_views/module';

var module = angular.module('Dmles.Home.Module', [
    adminModule.name,
    catalogModule.name,
    dashboardModule.name,
    equipmentModule.name,
    jmarModule.name,
    viewsModule.name
]);

module.controller('Dmles.Home.HomeShellController', HomeShellController);
module.config(router.factory);

export default module;