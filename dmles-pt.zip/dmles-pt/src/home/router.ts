'use strict';

class Router {
    static instance:any;

    // @ngInject
    constructor($stateProvider, $urlRouterProvider, StateConstants) {

        $stateProvider
        .state(StateConstants.HOME_ROOT, {
                url: '/home',
                templateUrl: '/src/home/homeShell.html',
                controller: 'Dmles.Home.HomeShellController',
                controllerAs: 'vm',
                abstract: true
            })
        .state(StateConstants.ABOUT, {
            url: '/about',
            templateUrl: '/src/home/_views/about.html',
            controller: 'Dmles.Home.Views.AboutController',
            controllerAs: 'vm',
            data: {
                displayName: 'About'
            }
        }).state(StateConstants.HELP, {
            url: '/help',
            templateUrl: '/src/home/_views/help.html',
            controller: 'Dmles.Home.Views.HelpController',
            controllerAs: 'vm',
            data: {
                displayName: 'Help'
            }
        }).state(StateConstants.USER_PROFILE, {
            url: '/userProfile',
            templateUrl: '/src/home/_views/userProfile.html',
            controller: 'Dmles.Home.Views.UserProfileController',
            controllerAs: 'vm',
            data: {
                displayName: 'User Profile'
            }
        }).state(StateConstants.USER_PROFILE_EDIT_GEN_INFO, {
            url: '/userProfileEditGenInfo',
            templateUrl: '/src/home/_views/userProfileEditGenInfo.html',
            controller: 'Dmles.Home.Views.UserProfileEditGenInfoController',
            controllerAs: 'vm',
            data: {
                displayName: 'User Profile - Edit General Info'
            }
        });

    }

    static factory($stateProvider, $urlRouterProvider, StateConstants) {
        Router.instance = new Router($stateProvider, $urlRouterProvider, StateConstants);
        return Router.instance;
    }
}

Router.factory.$inject = ['$stateProvider', '$urlRouterProvider', 'StateConstants'];

export default Router;