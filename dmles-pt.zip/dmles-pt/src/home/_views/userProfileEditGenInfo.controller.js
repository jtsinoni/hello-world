define(["require", "exports"], function (require, exports) {
    'use strict';
    var UserProfileEditGenInfoController = (function () {
        // @ngInject
        function UserProfileEditGenInfoController($log, $state, NotificationService, StateConstants, UserProfileService, UserProfileManagementService, UserService) {
            this.$log = $log;
            this.$state = $state;
            this.NotificationService = NotificationService;
            this.StateConstants = StateConstants;
            this.UserProfileService = UserProfileService;
            this.UserProfileManagementService = UserProfileManagementService;
            this.UserService = UserService;
            this.userProfileGeneralInfoChanged = false;
            this.controllerName = "User Profile Edit General Information Controller";
            this.userProfile = null;
            this.currentUserProfile = null;
            this.init();
        }
        /**
         Initializes the page
         */
        UserProfileEditGenInfoController.prototype.init = function () {
            // this.$log.debug("%s - Start", this.controllerName);
            this.userProfile = this.UserProfileManagementService.getUserProfile();
            // Get current userProfile
            this.currentUserProfile = this.UserService.currentUser;
            // this.$log.debug("this.currentUserProfile: %s", JSON.stringify(this.currentUserProfile));
            if (this.userProfile === null) {
                //no userProfile, go back
                this.goToUserProfileView();
            }
            else {
            }
        };
        /**
         Updates the userProfile general information and returns to the userProfile View state
         */
        UserProfileEditGenInfoController.prototype.onSubmit = function () {
            var userProfileEditGenInfo = angular.copy(this.userProfile);
            // Save button on GUI only gets enabled when all required data has values - so no need to check here
            this.saveUserProfileGeneralInfo();
            this.goToUserProfileView();
            this.NotificationService.infoMsg("Profile Updated");
        };
        UserProfileEditGenInfoController.prototype.saveUserProfileGeneralInfo = function () {
            var _this = this;
            this.userProfileGeneralInfoChanged = false;
            // this.userProfile.current = true;
            // this.$log.debug("Saving this.userProfile: %s", JSON.stringify(this.userProfile));
            this.UserProfileService.saveUserProfileData(this.userProfile).then(function (response) {
                _this.userProfile = response.data;
                _this.UserProfileManagementService.setUserProfile(_this.userProfile);
                _this.updateCurrentUserProfile();
                // this.$log.debug("%s - Saved UserProfile Returned: %s", this.controllerName, JSON.stringify(this.userProfile));           
            }, function (errResponse) {
                _this.$log.error("Error saving userProfile general information");
            });
        };
        UserProfileEditGenInfoController.prototype.updateCurrentUserProfile = function () {
            this.currentUserProfile.profileName = this.userProfile.profileName;
            this.currentUserProfile.lastName = this.userProfile.lastName;
            this.currentUserProfile.firstName = this.userProfile.firstName;
            this.currentUserProfile.email = this.userProfile.email;
            this.currentUserProfile.phoneNumbers[0].value = this.userProfile.phoneNumbers[0].value;
            this.UserService.setCurrentUser(this.currentUserProfile);
            // this.$log.debug("this.currentUserProfile: %s", JSON.stringify(this.currentUserProfile));
            this.getActiveUserProfiles();
        };
        /**
         Gets an array of User Profiles to user for selection drop-down, etc (once we use CAC login and have token)
         */
        UserProfileEditGenInfoController.prototype.getActiveUserProfiles = function () {
            // this.$log.debug("%s - this.currentUserProfile: %s", this.controllerName, JSON.stringify(this.currentUserProfile));
            var _this = this;
            this.UserProfileService.getActiveUserProfiles().then(function (response) {
                // this.$log.debug("%s - response.data: %s", this.controllerName, JSON.stringify(response.data));
                _this.UserProfileManagementService.userProfiles = angular.copy(response.data);
                // this.$log.debug("this.showUserProfileSelector: %s", this.showUserProfileSelector);
            }, function (errResponse) {
                _this.$log.error("Error retrieving list of User Profiles associated with this user");
            });
        };
        /**
         Return to User Profile view state
         */
        UserProfileEditGenInfoController.prototype.goToUserProfileView = function () {
            // this.$log.debug("%s - Go to User Profile View", this.controllerName);
            this.$state.go(this.StateConstants.USER_PROFILE);
        };
        return UserProfileEditGenInfoController;
    }());
    exports.UserProfileEditGenInfoController = UserProfileEditGenInfoController;
});
//# sourceMappingURL=userProfileEditGenInfo.controller.js.map