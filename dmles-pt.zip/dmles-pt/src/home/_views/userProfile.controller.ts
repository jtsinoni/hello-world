'use strict';

import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {CurrentUserProfile} from "../../_models/currentUserProfile.model";
import {UserProfile} from "../../_models/userProfile.model";

export class UserProfileController {
    private controllerName:string = "UserProfileController";
    private currentUserProfile: CurrentUserProfile = null;
    private selectedUserProfile: CurrentUserProfile = null;
    private userName: string;
    public currentUserProfileService: any = null;
    public currentUserProfileSite: any = null;
    public completeUserProfile: UserProfile = null;
    public showUserProfileSelector: boolean = false;

    // @ngInject
    constructor(private $log, private $state, private ContentConstants, private MainNavService, private OAuthService,
                private NotificationService, private StateConstants, private SystemService,
                private UserProfileService, private UserProfileManagementService, private UserService) {
        this.$log.debug('%s - Start', this.controllerName);
        this.currentUserProfile = this.UserService.currentUser;
        this.init();
        this.selectedUserProfile = this.currentUserProfile;
        this.getActiveUserProfiles();
    }

    public init() {
        this.userName = this.currentUserProfile.firstName + " " + this.currentUserProfile.lastName;
        this.currentUserProfileService = this.SystemService.lookupServiceGivenServiceCode(this.currentUserProfile.serviceCode);
        this.currentUserProfileSite = this.SystemService.lookupSiteGivenSiteDodaac(this.currentUserProfile.dodaac);
        this.UserProfileService.getUserProfileById(this.currentUserProfile.id).then((response: IHttpPromiseCallbackArg<UserProfile>) => {
            this.completeUserProfile = response.data;
            this.UserProfileManagementService.setUserProfile(this.completeUserProfile);
        }, (errResponse: IHttpPromiseCallbackArg<UserProfile>) => {
            this.$log.error("Error getting User Profile by ID");
        });
    }

    private changeUserProfile() {

        this.MainNavService.animateOutNavItems();

        this.currentUserProfile = this.selectedUserProfile;

        this.UserProfileService.setCurrentProfile(this.currentUserProfile.id).then((response: IHttpPromiseCallbackArg<CurrentUserProfile>) => {

            this.init();
            this.UserService.setCurrentUser(this.currentUserProfile);
            this.MainNavService.getMyNavItems().then((data) => {
                this.MainNavService.mainNavItems = data;
                this.MainNavService.animateInNavItems();
            });

            // DSE-108 need to get a new Token from BT after changing to a new current profile
            this.OAuthService.getNewToken(this.currentUserProfile.pkiDn).then((data: any) => {
                if (!data) {
                    this.NotificationService.errorMsg("Unable to authenticate user");
                }
            }, (err) => {
                this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
            });
        }, (errResponse: IHttpPromiseCallbackArg<CurrentUserProfile>) => {
            this.$log.error("Error changing User Profile");
        });
    }

    private getActiveUserProfiles() {

        this.UserProfileService.getActiveUserProfiles().then((response: IHttpPromiseCallbackArg<CurrentUserProfile[]>) => {
            this.UserProfileManagementService.userProfiles = angular.copy(response.data);
            if (this.UserProfileManagementService.userProfiles.length > 1) {
                this.showUserProfileSelector = true;
            } else {
                this.showUserProfileSelector = false;
            }
        }, (errResponse: IHttpPromiseCallbackArg<CurrentUserProfile[]>) => {
            this.$log.error("Error retrieving list of User Profiles associated with this user");
        });
    }

    public goToEditUserProfileGeneralInfo(): void {
        this.$state.go(this.StateConstants.USER_PROFILE_EDIT_GEN_INFO);
    }
}

