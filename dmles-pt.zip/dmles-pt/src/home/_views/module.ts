'use strict';

import {AboutController} from './about.controller';
import {HelpController} from './help.controller';
import {UserProfileController} from './userProfile.controller';
import {UserProfileEditGenInfoController} from './userProfileEditGenInfo.controller';

var controllersModule = angular.module('Dmles.Views.Module', []);
controllersModule.controller('Dmles.Home.Views.AboutController', AboutController);
controllersModule.controller('Dmles.Home.Views.HelpController', HelpController);
controllersModule.controller('Dmles.Home.Views.UserProfileController', UserProfileController);
controllersModule.controller('Dmles.Home.Views.UserProfileEditGenInfoController', UserProfileEditGenInfoController);

export default controllersModule;