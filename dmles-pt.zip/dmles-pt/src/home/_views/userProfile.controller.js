define(["require", "exports"], function (require, exports) {
    'use strict';
    var UserProfileController = (function () {
        // @ngInject
        function UserProfileController($log, $state, ContentConstants, MainNavService, OAuthService, NotificationService, StateConstants, SystemService, UserProfileService, UserProfileManagementService, UserService) {
            this.$log = $log;
            this.$state = $state;
            this.ContentConstants = ContentConstants;
            this.MainNavService = MainNavService;
            this.OAuthService = OAuthService;
            this.NotificationService = NotificationService;
            this.StateConstants = StateConstants;
            this.SystemService = SystemService;
            this.UserProfileService = UserProfileService;
            this.UserProfileManagementService = UserProfileManagementService;
            this.UserService = UserService;
            this.controllerName = "UserProfileController";
            this.currentUserProfile = null;
            this.selectedUserProfile = null;
            this.currentUserProfileService = null;
            this.currentUserProfileSite = null;
            this.completeUserProfile = null;
            this.showUserProfileSelector = false;
            this.$log.debug('%s - Start', this.controllerName);
            this.currentUserProfile = this.UserService.currentUser;
            this.init();
            this.selectedUserProfile = this.currentUserProfile;
            this.getActiveUserProfiles();
        }
        UserProfileController.prototype.init = function () {
            var _this = this;
            this.userName = this.currentUserProfile.firstName + " " + this.currentUserProfile.lastName;
            this.currentUserProfileService = this.SystemService.lookupServiceGivenServiceCode(this.currentUserProfile.serviceCode);
            this.currentUserProfileSite = this.SystemService.lookupSiteNameGivenSiteDodaac(this.currentUserProfile.dodaac);
            this.UserProfileService.getUserProfileById(this.currentUserProfile.id).then(function (response) {
                _this.completeUserProfile = response.data;
                _this.UserProfileManagementService.setUserProfile(_this.completeUserProfile);
            }, function (errResponse) {
                _this.$log.error("Error getting User Profile by ID");
            });
        };
        UserProfileController.prototype.changeUserProfile = function () {
            var _this = this;
            this.MainNavService.animateOutNavItems();
            this.currentUserProfile = this.selectedUserProfile;
            this.UserProfileService.setCurrentProfile(this.currentUserProfile.id).then(function (response) {
                _this.init();
                _this.UserService.setCurrentUser(_this.currentUserProfile);
                _this.MainNavService.getMyNavItems().then(function (data) {
                    _this.MainNavService.mainNavItems = data;
                    _this.MainNavService.animateInNavItems();
                });
                // DSE-108 need to get a new Token from BT after changing to a new current profile
                _this.OAuthService.getNewToken(_this.currentUserProfile.pkiDn).then(function (data) {
                    if (!data) {
                        _this.NotificationService.errorMsg("Unable to authenticate user");
                    }
                }, function (err) {
                    _this.NotificationService.errorMsg(_this.ContentConstants.ERR_MSG);
                });
            }, function (errResponse) {
                _this.$log.error("Error changing User Profile");
            });
        };
        UserProfileController.prototype.getActiveUserProfiles = function () {
            var _this = this;
            this.UserProfileService.getActiveUserProfiles().then(function (response) {
                _this.UserProfileManagementService.userProfiles = angular.copy(response.data);
                if (_this.UserProfileManagementService.userProfiles.length > 1) {
                    _this.showUserProfileSelector = true;
                }
                else {
                    _this.showUserProfileSelector = false;
                }
            }, function (errResponse) {
                _this.$log.error("Error retrieving list of User Profiles associated with this user");
            });
        };
        UserProfileController.prototype.goToEditUserProfileGeneralInfo = function () {
            this.$state.go(this.StateConstants.USER_PROFILE_EDIT_GEN_INFO);
        };
        return UserProfileController;
    }());
    exports.UserProfileController = UserProfileController;
});
//# sourceMappingURL=userProfile.controller.js.map