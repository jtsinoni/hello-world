define(["require", "exports"], function (require, exports) {
    'use strict';
    var AboutController = (function () {
        // @ngInject
        function AboutController(ConfigConstants) {
            this.ConfigConstants = ConfigConstants;
            this.init();
        }
        AboutController.prototype.init = function () {
            this.viewName = 'About View';
        };
        return AboutController;
    }());
    exports.AboutController = AboutController;
});
//# sourceMappingURL=about.controller.js.map