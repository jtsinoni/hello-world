'use strict';

export class AboutController {
    viewName: string;

    // @ngInject
    constructor() {
        this.init();
    }

    init(){
        this.viewName = 'About View';
    }
}

