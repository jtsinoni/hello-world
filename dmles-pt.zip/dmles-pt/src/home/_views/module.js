define(["require", "exports", './about.controller', './help.controller', './userProfile.controller', './userProfileEditGenInfo.controller'], function (require, exports, about_controller_1, help_controller_1, userProfile_controller_1, userProfileEditGenInfo_controller_1) {
    'use strict';
    var controllersModule = angular.module('Dmles.Views.Module', []);
    controllersModule.controller('Dmles.Home.Views.AboutController', about_controller_1.AboutController);
    controllersModule.controller('Dmles.Home.Views.HelpController', help_controller_1.HelpController);
    controllersModule.controller('Dmles.Home.Views.UserProfileController', userProfile_controller_1.UserProfileController);
    controllersModule.controller('Dmles.Home.Views.UserProfileEditGenInfoController', userProfileEditGenInfo_controller_1.UserProfileEditGenInfoController);
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = controllersModule;
});
//# sourceMappingURL=module.js.map