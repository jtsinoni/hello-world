'use strict';

export class HelpController {
    viewName: string;

    // @ngInject
    constructor() {
        this.init();
    }

    init(){
        this.viewName = 'Help View';
    }
}

