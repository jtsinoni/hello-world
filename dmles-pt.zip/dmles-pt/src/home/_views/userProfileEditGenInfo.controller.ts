'use strict';

import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {UserProfile} from "../../_models/userProfile.model";
import {CurrentUserProfile} from "../../_models/currentUserProfile.model";


export class UserProfileEditGenInfoController {
    public userProfileGeneralInfoChanged: boolean = false;

    private controllerName: string = "User Profile Edit General Information Controller";
    private userProfile: UserProfile = null;
    private currentUserProfile: CurrentUserProfile = null;

    // @ngInject
    constructor(private $log, private $state, private NotificationService, private StateConstants,
                private UserProfileService, private UserProfileManagementService, private UserService) {

        this.init();
    }

    /**
     Initializes the page
     */
    private init() {
        // this.$log.debug("%s - Start", this.controllerName);
        this.userProfile = this.UserProfileManagementService.getUserProfile();

        // Get current userProfile
        this.currentUserProfile = this.UserService.currentUser;
        // this.$log.debug("this.currentUserProfile: %s", JSON.stringify(this.currentUserProfile));

        if (this.userProfile === null) {
            //no userProfile, go back
            this.goToUserProfileView();
        } else {
            // this.$log.debug("this.userProfile: %s", JSON.stringify(this.userProfile));
        }
    }

    /**
     Updates the userProfile general information and returns to the userProfile View state
     */
    public onSubmit() {
        var userProfileEditGenInfo: any = angular.copy(this.userProfile);

        // Save button on GUI only gets enabled when all required data has values - so no need to check here
        this.saveUserProfileGeneralInfo();
        this.goToUserProfileView();
        this.NotificationService.infoMsg("Profile Updated");
    }

    private saveUserProfileGeneralInfo() {
        this.userProfileGeneralInfoChanged = false;

        // this.userProfile.current = true;

        // this.$log.debug("Saving this.userProfile: %s", JSON.stringify(this.userProfile));

        this.UserProfileService.saveUserProfileData(this.userProfile).then((response: IHttpPromiseCallbackArg<UserProfile>) => {
            this.userProfile = response.data;
            this.UserProfileManagementService.setUserProfile(this.userProfile);
            this.updateCurrentUserProfile();
            // this.$log.debug("%s - Saved UserProfile Returned: %s", this.controllerName, JSON.stringify(this.userProfile));           
        }, (errResponse: IHttpPromiseCallbackArg<UserProfile[]>) => {
            this.$log.error("Error saving userProfile general information");
        });
    }

    private updateCurrentUserProfile() {
        this.currentUserProfile.profileName = this.userProfile.profileName;
        this.currentUserProfile.lastName = this.userProfile.lastName;
        this.currentUserProfile.firstName = this.userProfile.firstName;
        this.currentUserProfile.email = this.userProfile.email;
        this.currentUserProfile.phoneNumbers[0].value = this.userProfile.phoneNumbers[0].value;
        this.currentUserProfile.profileSuspensionDate = this.userProfile.profileSuspensionDate;
        this.currentUserProfile.profileExpirationDate = this.userProfile.profileExpirationDate;
        this.UserService.setCurrentUser(this.currentUserProfile);
        // this.$log.debug("this.currentUserProfile: %s", JSON.stringify(this.currentUserProfile));
        this.getActiveUserProfiles();
    }

    /**
     Gets an array of User Profiles to user for selection drop-down, etc (once we use CAC login and have token)
     */
    private getActiveUserProfiles() {
        // this.$log.debug("%s - this.currentUserProfile: %s", this.controllerName, JSON.stringify(this.currentUserProfile));

        this.UserProfileService.getActiveUserProfiles().then((response: IHttpPromiseCallbackArg<CurrentUserProfile[]>) => {
            // this.$log.debug("%s - response.data: %s", this.controllerName, JSON.stringify(response.data));
            this.UserProfileManagementService.userProfiles = angular.copy(response.data);
            // this.$log.debug("this.showUserProfileSelector: %s", this.showUserProfileSelector);
        }, (errResponse: IHttpPromiseCallbackArg<CurrentUserProfile[]>) => {
            this.$log.error("Error retrieving list of User Profiles associated with this user");
        });
    }

    /**
     Return to User Profile view state
     */
    private goToUserProfileView(): void {
        // this.$log.debug("%s - Go to User Profile View", this.controllerName);
        this.$state.go(this.StateConstants.USER_PROFILE);
    }
}