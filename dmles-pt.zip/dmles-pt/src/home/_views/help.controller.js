define(["require", "exports"], function (require, exports) {
    'use strict';
    var HelpController = (function () {
        // @ngInject
        function HelpController() {
            this.init();
        }
        HelpController.prototype.init = function () {
            this.viewName = 'Help View';
        };
        return HelpController;
    }());
    exports.HelpController = HelpController;
});
//# sourceMappingURL=help.controller.js.map