define(["require", "exports"], function (require, exports) {
    "use strict";
    var AppConfig = (function () {
        // @ngInject
        function AppConfig() {
            this.apiHosts = {
                //"btBaseUrl"   : "http://jw8cui04:8080/"  // Test
                //"btBaseUrl"   : "http://jw8dmles102:8080/"  // Dev Old
                //"btBaseUrl"   : "https:/140.139.35.29:8443/"  // Dev New
                "btBaseUrl": "http://localhost:8080/"
            };
        }
        return AppConfig;
    }());
    exports.AppConfig = AppConfig;
});
//# sourceMappingURL=appConfig.js.map