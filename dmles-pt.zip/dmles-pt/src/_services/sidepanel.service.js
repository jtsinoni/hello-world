define(["require", "exports"], function (require, exports) {
    'use strict';
    var SidePanelService = (function () {
        //@inject
        function SidePanelService($log, DmlesGridService, StateConstants) {
            this.$log = $log;
            this.DmlesGridService = DmlesGridService;
            this.StateConstants = StateConstants;
            this.serviceName = "SidePanelService";
            this.closedStyle = { "width": "20px", "padding": "5px" };
            this.openStyle = { "width": "20px", "padding": "5px" };
            this.iconRightOpen = "fa fa-angle-double-right";
            this.iconRightClosed = "fa fa-angle-double-left";
            this.iconLeftOpen = "fa fa-angle-double-left";
            this.iconLeftClosed = "fa fa-angle-double-right";
            this.defaultPanelWidth = '25%';
            this.isLeftPanelButtonShown = false;
            this.isLeftPanelShown = false;
            this.leftOutterStyle = {};
            this.leftPanelStyle = {};
            this.isRightPanelButtonShown = false;
            this.isRightPanelShown = false;
            this.rightOutterStyle = {};
            this.rightPanelStyle = {};
            this.resetLeftPanel();
            this.resetRightPanel();
        }
        SidePanelService.prototype.resetLeftPanel = function () {
            this.leftPanelIcon = this.iconLeftClosed;
            this.leftPanelWidthOpened = this.defaultPanelWidth;
            this.leftPanelStyle = this.closedStyle;
            this.leftOutterStyle = { "margin-left": "5px" };
        };
        SidePanelService.prototype.resetRightPanel = function () {
            this.rightPanelIcon = this.iconRightClosed;
            this.rightPanelWidthOpened = this.defaultPanelWidth;
            this.rightPanelStyle = this.closedStyle;
            this.rightOutterStyle = { "margin-right": 0 };
        };
        SidePanelService.prototype.checkForPanelButton = function (toState) {
            this.$log.info(this.serviceName + ": Checking for side panels");
            this.isLeftPanelButtonShown = false;
            this.isRightPanelButtonShown = false;
            if (toState.name === this.StateConstants.EQUIP_REQUEST_VIEW) {
                this.$log.info(this.serviceName + ": Show right side panel button");
                this.isRightPanelButtonShown = true;
            }
            else if (toState.name === this.StateConstants.CATALOG_SEARCH) {
                this.$log.info(this.serviceName + ": Show left side panel button");
                this.isLeftPanelButtonShown = true;
            }
            else if (toState.name === this.StateConstants.EQUIP_RECORD_SEARCH) {
                this.$log.info(this.serviceName + ": Show left side panel button");
                this.isLeftPanelButtonShown = true;
                this.$log.info(this.serviceName + ": Show right side panel button");
                this.isRightPanelButtonShown = true;
            }
        };
        SidePanelService.prototype.toggleLeftPanel = function () {
            if (this.isLeftPanelShown) {
                this.$log.info(this.serviceName + ": Toggle to closed");
                this.leftPanelStyle = this.openStyle;
                this.leftOutterStyle = { "margin-left": "5px" };
                this.leftPanelIcon = this.iconLeftClosed;
            }
            else {
                this.$log.info(this.serviceName + ": Toggle to open");
                this.$log.info(this.serviceName + ": Toggle to opened " + this.leftPanelWidthOpened);
                this.leftPanelStyle = { "width": this.leftPanelWidthOpened, "padding": "0 10px" };
                this.leftOutterStyle = { "margin-left": this.leftPanelWidthOpened };
                this.leftPanelIcon = this.iconLeftOpen;
            }
            this.isLeftPanelShown = !this.isLeftPanelShown;
            this.DmlesGridService.handleWindowResize();
        };
        SidePanelService.prototype.toggleRightPanel = function () {
            if (this.isRightPanelShown) {
                this.$log.info(this.serviceName + ": Toggle to closed");
                this.rightPanelStyle = this.openStyle;
                this.rightOutterStyle = { "margin-right": 0 };
                this.rightPanelIcon = this.iconRightClosed;
            }
            else {
                this.$log.info(this.serviceName + ": Toggle to open");
                this.$log.info(this.serviceName + ": Toggle to opened " + this.rightPanelWidthOpened);
                this.rightPanelStyle = { "width": this.rightPanelWidthOpened, "padding": "0 10px" };
                this.rightOutterStyle = { "margin-right": this.rightPanelWidthOpened };
                this.rightPanelIcon = this.iconRightOpen;
            }
            this.isRightPanelShown = !this.isRightPanelShown;
            this.DmlesGridService.handleWindowResize();
        };
        return SidePanelService;
    }());
    exports.SidePanelService = SidePanelService;
});
//# sourceMappingURL=sidepanel.service.js.map