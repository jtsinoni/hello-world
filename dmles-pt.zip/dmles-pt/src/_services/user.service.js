var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", '../_services/api.service', "../_models/currentUserProfile.model"], function (require, exports, api_service_1, currentUserProfile_model_1) {
    'use strict';
    var UserService = (function (_super) {
        __extends(UserService, _super);
        //@inject;
        function UserService($http, $log, Authentication, $httpParamSerializerJQLike, $q, $rootScope, ContentConstants) {
            _super.call(this, $http, $log, Authentication, $httpParamSerializerJQLike, "User");
            this.$q = $q;
            this.$rootScope = $rootScope;
            this.ContentConstants = ContentConstants;
            this.userServiceName = "User Service";
            this.$log.debug("%s - Start", this.userServiceName);
        }
        /*
         Gets the current user either from cache or DB, and loads it into the
         model, for use by other services, directives and controllers.
    
         Called by the dmlesApp.run $rootScope.$on('$stateChangeStart') ....
         */
        UserService.prototype.loadCurrentUser = function () {
            var _this = this;
            if (this.currentUser) {
                var deferred = this.$q.defer();
                deferred.resolve(this.currentUser);
                return deferred.promise;
            }
            else {
                return this.signIn().then(function (result) {
                    var user = result;
                    //this.$log.debug("%s - User Profile loaded", this.userServiceName);
                    _this.setCurrentUser(user);
                    return _this.currentUser;
                });
            }
        };
        UserService.prototype.signIn = function () {
            var _this = this;
            return this.get("signIn").then(function (result) {
                var user = result.data;
                //this.$log.debug("%s - signIn - Current User: %s", this.userServiceName, JSON.stringify(user));
                _this.setCurrentUser(user);
                return _this.currentUser;
            });
        };
        UserService.prototype.setCurrentUser = function (currentUserProfile) {
            this.currentUser = new currentUserProfile_model_1.CurrentUserProfile(angular.copy(currentUserProfile));
            var data = {
                "user": this.currentUser
            };
            //this.$log.debug("setCurrentUser - this.currentUser: %s", JSON.stringify(this.currentUser));
            // Note: Broadcast used to hit banner items, such as User Profile, currently
            // TODO: This shouldn't be needed, remove eventually...
            this.$rootScope.$broadcast(this.ContentConstants.EVENT_USER_UPDATE, data);
        };
        return UserService;
    }(api_service_1.ApiService));
    exports.UserService = UserService;
});
//# sourceMappingURL=user.service.js.map