'use strict';

export class NotificationService {
    private serviceName:string = "Notification Service";

    //@inject
    constructor(private $log, private growl) {
        this.$log.info("%s - started", this.serviceName);
    }

    public errorMsg(msg, ttl){
        var config:any = {};
        if(ttl){
             config = {ttl: ttl};
        }
        this.growl.error(msg, config);
    }

    public infoMsg(msg, ttl){
        var config:any = {};
        if(ttl){
            config = {ttl: ttl};
        }
        this.growl.info(msg, config);
    }

    public successMsg(msg, ttl){
        var config:any = {};
        if(ttl){
            config = {ttl: ttl};
        }
        this.growl.success(msg, config);
    }

    public warningMsg(msg, ttl){
        var config:any = {};
        if(ttl){
            config = {ttl: ttl};
        }
        this.growl.warning(msg, config);
    }

}