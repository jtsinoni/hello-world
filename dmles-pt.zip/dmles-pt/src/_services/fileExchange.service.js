define(["require", "exports", '../_models/fileUploadData.model'], function (require, exports, fileUploadData_model_1) {
    "use strict";
    var FileExchangeService = (function () {
        //@inject
        function FileExchangeService($http, App) {
            this.$http = $http;
            this.App = App;
            this.serviceName = "File Exchange Service";
            this.uploadService = "file-exchange/dmles/rest-api/upload";
            this.downloadService = "file-exchange/dmles/rest-api/download?fileurl=";
        }
        FileExchangeService.prototype.uploadFile = function (fileInfo) {
            if (fileInfo) {
                var uri = this.App.getBtBaseUrl() + this.uploadService;
                var filedata = fileUploadData_model_1.FileUploadData.create(fileInfo);
                var fd = new FormData();
                fd.append('fileDescription', fileInfo.description);
                fd.append('fileName', fileInfo.file.name);
                fd.append('attachment', fileInfo.file.contents);
                fd.append('fileData', JSON.stringify(filedata));
                var data = {
                    transformRequest: angular.identity,
                    headers: {
                        "Content-Type": undefined
                    }
                };
                return this.$http.post(uri, fd, data);
            }
        };
        FileExchangeService.prototype.getDownloadUrl = function () {
            var uri = this.App.getBtBaseUrl() + this.downloadService;
            return uri;
        };
        return FileExchangeService;
    }());
    exports.FileExchangeService = FileExchangeService;
});
//# sourceMappingURL=fileExchange.service.js.map