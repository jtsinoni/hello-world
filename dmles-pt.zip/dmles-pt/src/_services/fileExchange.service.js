define(["require", "exports"], function (require, exports) {
    "use strict";
    var FileExchangeService = (function () {
        //@inject
        function FileExchangeService($http) {
            this.$http = $http;
            this.serviceName = "File Exchange Service";
            this.uploadService = "file-exchange/dmles/rest-api/upload";
            this.downloadService = "file-exchange/dmles/rest-api/download?fileurl=";
        }
        FileExchangeService.prototype.uploadFile = function (fileInfo) {
            /*
            if (fileInfo) {
                var uri:string = this.App.getBtBaseUrl() + this.uploadService;
                var filedata:FileUploadData = FileUploadData.create(fileInfo);
                var fd:FormData = new FormData();
    
                fd.append('fileDescription', fileInfo.description);
                fd.append('fileName', fileInfo.file.name);
                fd.append('attachment', fileInfo.file.contents);
                fd.append('fileData', JSON.stringify(filedata));
    
                var data = {
                    transformRequest: angular.identity,
                    headers: {
                        "Content-Type": undefined
                    }
                };
    
                return this.$http.post(uri, fd, data);
            }
            */
        };
        FileExchangeService.prototype.getDownloadUrl = function () {
            /*
            var uri:string = this.App.getBtBaseUrl() + this.downloadService;
            return uri;
            */
        };
        return FileExchangeService;
    }());
    exports.FileExchangeService = FileExchangeService;
});
//# sourceMappingURL=fileExchange.service.js.map