define(["require", "exports"], function (require, exports) {
    'use strict';
    var NotificationService = (function () {
        //@inject
        function NotificationService($log, growl) {
            this.$log = $log;
            this.growl = growl;
            this.serviceName = "Notification Service";
            this.$log.info("%s - started", this.serviceName);
        }
        NotificationService.prototype.errorMsg = function (msg, ttl) {
            var config = {};
            if (ttl) {
                config = { ttl: ttl };
            }
            this.growl.error(msg, config);
        };
        NotificationService.prototype.infoMsg = function (msg, ttl) {
            var config = {};
            if (ttl) {
                config = { ttl: ttl };
            }
            this.growl.info(msg, config);
        };
        NotificationService.prototype.successMsg = function (msg, ttl) {
            var config = {};
            if (ttl) {
                config = { ttl: ttl };
            }
            this.growl.success(msg, config);
        };
        NotificationService.prototype.warningMsg = function (msg, ttl) {
            var config = {};
            if (ttl) {
                config = { ttl: ttl };
            }
            this.growl.warning(msg, config);
        };
        return NotificationService;
    }());
    exports.NotificationService = NotificationService;
});
//# sourceMappingURL=notification.service.js.map