import {ApiConstants} from '../_constants/api.constants';
import {ConfigConstants} from '../_constants/config.constants';

export class ApiService {
    private apiServiceName: string = "Api Service";
    private baseUrl: string;

    //@inject
    constructor(private $http, public $log, protected Authentication, private $httpParamSerializerJQLike, private managerName: string) {
        if (ConfigConstants.BT_BASE_URL) {
            this.baseUrl = ConfigConstants.BT_BASE_URL;
            this.$log.info('%s - btBaseUrl loaded: %s', this.apiServiceName, this.baseUrl);
        } else {
            this.$log.error('%s - Error: Unable to load btBaseUrl', this.apiServiceName);
        }
    }

    private determineUrl(action: string, managerName?: string) {
        var url: string = '';
        var managerToUse = this.managerName;
        if (managerName) {
            managerToUse = managerName;
        }
        if (managerToUse === "User") {
            url = this.baseUrl + ApiConstants.USER_API + action;
        } else if (managerToUse === "Role") {
            url = this.baseUrl + ApiConstants.ROLE_API + action;
        } else if (managerToUse === "EquipmentManagement") {
            url = this.baseUrl + ApiConstants.EQUIPMENT_API + action;
        } else if (managerToUse === "Site") {
            url = this.baseUrl + ApiConstants.SITE_API + action;
        } else if (managerToUse === "System") {
            url = this.baseUrl + ApiConstants.SYSTEM_API + action;
        } else if (managerToUse === "OAuth") {
            url = this.baseUrl + ApiConstants.OAUTH_API + action;
        } else if (this.managerName === "FundAdmin") {
            url = this.baseUrl + ApiConstants.FUNDADMIN_API + action;
        } else if (managerToUse === "Catalog") {
            url = this.baseUrl + ApiConstants.CATALOG_API + action;
        } else if (managerToUse === "ABiStagingManagement") {
            url = this.baseUrl + ApiConstants.ABI_STAGING_API + action;
        } else if (managerToUse === "ABiProductionManagment") {
            url = this.baseUrl + ApiConstants.ABI_PRODUCTION_API + action;
        } else {
            url = this.baseUrl + this.managerName + '/Api/' + action;
        }
        return url;
    };

    public getTokenViaOAuth(action: string, encodedDn: string) {
        var url: string = this.determineUrl(action);
        this.$log.debug("%s - BT getToken URL: %s", this.apiServiceName, url);
        return this.$http.post(url, {}, {
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Basic ' + encodedDn,
                'ClientId':'dmles'
            }
        });
    };

    public get(action: string, managerName?: string) {
        var url: string = this.determineUrl(action, managerName);
        this.$log.debug("%s - BT Get URL: %s", this.apiServiceName, url);
        return this.$http.get(url, {
            headers: {
                'Authorization': 'Token ' + this.Authentication.getToken(),
                'ClientId':'dmles'
            }
        });
    };

    public post(action: string, data: any) {
        var url: string = this.determineUrl(action);
        this.$log.debug("%s - BT Post URL: %s", this.apiServiceName, url);
        return this.$http.post(url, data, {
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Token ' + this.Authentication.getToken(),
                'ClientId':'dmles'
            }
        });
    };

}