'use strict';

import {ApiConstants} from "../_constants/api.constants";

export interface IApiService {

}

export class ApiService implements IApiService {
    private apiServiceName: string = "Api Service";

    //@inject
    constructor(private $http, public $log, protected Authentication, private App, private $httpParamSerializerJQLike, private managerName: string) {
    }

    private determineUrl(action: string) {
        var url: string = '';
        if (this.managerName === "User") {
            url = this.App.getBtBaseUrl() + ApiConstants.USER_API + action;
        } else if (this.managerName === "Role") {
            url = this.App.getBtBaseUrl() + ApiConstants.ROLE_API + action;
        } else if (this.managerName === "EquipmentManagement") {
            url = this.App.getBtBaseUrl() + ApiConstants.EQUIPMENT_API + action;
        } else if (this.managerName === "Site") {
            url = this.App.getBtBaseUrl() + ApiConstants.SITE_API + action;
        } else if (this.managerName === "System") {
            url = this.App.getBtBaseUrl() + ApiConstants.SYSTEM_API + action;
        } else if (this.managerName === "OAuth") {
            url = this.App.getBtBaseUrl() + ApiConstants.OAUTH_API + action;
        } else {
            url = this.App.getBtBaseUrl() + this.managerName + '/Api/' + action;
        }
        return url;
    };

    public getTokenViaOAuth(action: string, encodedDn: string) {
        var url: string = this.determineUrl(action);
        this.$log.debug("%s - BT getToken URL: %s", this.apiServiceName, url);
        return this.$http.post(url, {}, {
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Basic ' + encodedDn,
                'ClientId':'dmles'
            }
        });
    };

    public get(action: string) {
        var url: string = this.determineUrl(action);
        this.$log.debug("%s - BT Get URL: %s", this.apiServiceName, url);
        return this.$http.get(url, {
            headers: {
                'Authorization': 'Token ' + this.Authentication.getToken(),
                'ClientId':'dmles'
            }
        });
    };

    public post(action: string, data: any) {
        var url: string = this.determineUrl(action);
        this.$log.debug("%s - BT Post URL: %s", this.apiServiceName, url);
        return this.$http.post(url, data, {
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Token ' + this.Authentication.getToken(),
                'ClientId':'dmles'
            }
        });
    };

}