define(["require", "exports"], function (require, exports) {
    'use strict';
    var MultiSelectService = (function () {
        //@inject
        function MultiSelectService() {
        }
        MultiSelectService.prototype.buildSelection = function (itemId, selId, selValue, selected) {
            return {
                "itemId": itemId,
                "selId": selId,
                "selValue": selValue,
                "selected": selected
            };
        };
        return MultiSelectService;
    }());
    exports.MultiSelectService = MultiSelectService;
});
//# sourceMappingURL=multiSelect.service.js.map