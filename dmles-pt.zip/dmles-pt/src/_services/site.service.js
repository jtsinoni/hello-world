var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", "./api.service"], function (require, exports, api_service_1) {
    'use strict';
    var SiteService = (function (_super) {
        __extends(SiteService, _super);
        //@inject
        function SiteService($http, $log, Authentication, $httpParamSerializerJQLike) {
            _super.call(this, $http, $log, Authentication, $httpParamSerializerJQLike, "Site");
            this.siteServiceName = "Site Service";
            this.$log.debug("%s - Start", this.siteServiceName);
        }
        SiteService.prototype.getSites = function () {
            return this.get("getSitesAll");
        };
        SiteService.prototype.getSitesByRegion = function (region) {
            var query = "getSitesByRegion?region=" + region;
            return this.get(query);
        };
        SiteService.prototype.getSitesByService = function (serviceID) {
            var query = "getSitesByService?serviceID=" + serviceID;
            return this.get(query);
        };
        SiteService.prototype.getSiteOrgsByDodaac = function (siteDodaac) {
            var query = "getSiteOrgsByDodaac?siteDodaac=" + siteDodaac;
            return this.get(query);
        };
        return SiteService;
    }(api_service_1.ApiService));
    exports.SiteService = SiteService;
});
//# sourceMappingURL=site.service.js.map