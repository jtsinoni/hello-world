var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", '../_services/api.service', '../_constants/api.constants'], function (require, exports, api_service_1, api_constants_1) {
    'use strict';
    var OAuthService = (function (_super) {
        __extends(OAuthService, _super);
        //@inject;
        function OAuthService($http, $log, Authentication, $httpParamSerializerJQLike, $q, $window, Base64Service) {
            _super.call(this, $http, $log, Authentication, $httpParamSerializerJQLike, "OAuth");
            this.$q = $q;
            this.$window = $window;
            this.Base64Service = Base64Service;
            this.serviceName = "OAuth Service";
            this.$log.debug("%s - Start", this.serviceName);
        }
        OAuthService.prototype.apiGetToken = function (dn) {
            var encodedDn = this.Base64Service.b64EncodeUnicode(dn + ":password");
            return this.getTokenViaOAuth("token", encodedDn);
        };
        OAuthService.prototype.getToken = function (dn) {
            var token = this.$window.localStorage[api_constants_1.ApiConstants.DMLES_TOKEN];
            if (!token) {
                return this.getNewToken(dn);
            }
            else {
                this.$log.debug("%s - Token found locally", this.serviceName);
                var deferred = this.$q.defer();
                deferred.resolve(token);
                return deferred.promise;
            }
        };
        OAuthService.prototype.getNewToken = function (dn) {
            var _this = this;
            return this.apiGetToken(dn).then(function (result) {
                if (result && result.data && result.data.authctoken) {
                    _this.Authentication.saveToken(result.data.authctoken);
                    _this.$log.debug("%s - New token received and saved", _this.serviceName);
                    return result.data.authctoken;
                }
                else {
                    return null;
                }
            });
        };
        return OAuthService;
    }(api_service_1.ApiService));
    exports.OAuthService = OAuthService;
});
//# sourceMappingURL=oauth.service.js.map