'use strict';

import {ApiService} from '../_services/api.service';
import {ApiConstants} from '../_constants/api.constants';
import {User} from '../_models/user.model';
import {CurrentUserProfile} from "../_models/currentUserProfile.model";

export class OAuthService extends ApiService {
    public currentUser: CurrentUserProfile;
    public serviceName: string = "OAuth Service";

    //@inject;
    constructor($http, $log, Authentication, App, $httpParamSerializerJQLike, private $q, private $window, private Base64Service) {
        super($http, $log, Authentication, App, $httpParamSerializerJQLike, "OAuth");
        this.$log.debug("%s - Start", this.serviceName);
    }

    private apiGetToken(dn:string){
        var encodedDn = this.Base64Service.b64EncodeUnicode(dn + ":password");
        return this.getTokenViaOAuth("token", encodedDn);
    }

    public getToken(dn) {
        var token = this.$window.localStorage[ApiConstants.DMLES_TOKEN];
        if(!token){
            return this.getNewToken(dn);
        }else{
            this.$log.debug("%s - Token found locally", this.serviceName);
            var deferred = this.$q.defer();
            deferred.resolve(token);
            return deferred.promise;
        }
    }

    public getNewToken(dn) {
        return this.apiGetToken(dn).then((result: any) => {
            if(result && result.data && result.data.authctoken){
                this.Authentication.saveToken(result.data.authctoken);
                this.$log.debug("%s - New token received and saved", this.serviceName);
                return result.data.authctoken;
            }else{
                return null;
            }
        });
    }

}