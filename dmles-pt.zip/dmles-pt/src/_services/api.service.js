define(["require", "exports", "../_constants/api.constants", "../_constants/config.constants"], function (require, exports, api_constants_1, config_constants_1) {
    "use strict";
    var ApiService = (function () {
        //@inject
        function ApiService($http, $log, Authentication, $httpParamSerializerJQLike, managerName) {
            this.$http = $http;
            this.$log = $log;
            this.Authentication = Authentication;
            this.$httpParamSerializerJQLike = $httpParamSerializerJQLike;
            this.managerName = managerName;
            this.apiServiceName = "Api Service";
            if (config_constants_1.ConfigConstants.BT_BASE_URL) {
                this.baseUrl = config_constants_1.ConfigConstants.BT_BASE_URL;
                this.$log.info('%s - btBaseUrl loaded: %s', this.apiServiceName, this.baseUrl);
            }
            else {
                this.$log.error('%s - Error: Unable to load btBaseUrl', this.apiServiceName);
            }
        }
        // TODO: Replace if/else statements with a constant that's passed in
        ApiService.prototype.determineUrl = function (action, managerName) {
            var url = '';
            var managerToUse = this.managerName;
            if (managerName) {
                managerToUse = managerName;
            }
            if (managerToUse === "AssetManagement") {
                url = this.baseUrl + api_constants_1.ApiConstants.ASSET_MANAGEMENT_API + action;
            }
            else if (managerToUse === "User") {
                url = this.baseUrl + api_constants_1.ApiConstants.USER_API + action;
            }
            else if (managerToUse === "Role") {
                url = this.baseUrl + api_constants_1.ApiConstants.ROLE_API + action;
            }
            else if (managerToUse === "EquipmentManagement") {
                url = this.baseUrl + api_constants_1.ApiConstants.EQUIPMENT_API + action;
            }
            else if (managerToUse === "Site") {
                url = this.baseUrl + api_constants_1.ApiConstants.SITE_API + action;
            }
            else if (managerToUse === "System") {
                url = this.baseUrl + api_constants_1.ApiConstants.SYSTEM_API + action;
            }
            else if (managerToUse === "OAuth") {
                url = this.baseUrl + api_constants_1.ApiConstants.OAUTH_API + action;
            }
            else if (managerToUse === "OrderStatus") {
                url = this.baseUrl + api_constants_1.ApiConstants.DUE_IN_API + action;
            }
            else if (managerToUse === "Organization") {
                url = this.baseUrl + api_constants_1.ApiConstants.ORG_API + action;
            }
            else if (this.managerName === "FundAdmin") {
                url = this.baseUrl + api_constants_1.ApiConstants.FUNDADMIN_API + action;
            }
            else if (this.managerName === "Inventory") {
                url = this.baseUrl + api_constants_1.ApiConstants.INVENTORY_API + action;
            }
            else if (this.managerName === "Buyer") {
                url = this.baseUrl + api_constants_1.ApiConstants.BUYER_API + action;
            }
            else if (this.managerName === "StorageLocation") {
                url = this.baseUrl + api_constants_1.ApiConstants.STORAGE_LOCATION_API + action;
            }
            else if (managerToUse === "Catalog") {
                url = this.baseUrl + api_constants_1.ApiConstants.CATALOG_API + action;
            }
            else if (managerToUse === "ABiStagingManagement") {
                url = this.baseUrl + api_constants_1.ApiConstants.ABI_STAGING_API + action;
            }
            else if (managerToUse === "ABiStagingJoinManagement") {
                url = this.baseUrl + api_constants_1.ApiConstants.ABI_STAGING_JOIN_API + action;
            }
            else if (managerToUse === "ABiStagingLookupManagement") {
                url = this.baseUrl + api_constants_1.ApiConstants.ABI_STAGING_LOOKUP_API + action;
            }
            else if (managerToUse === "ABiProductionManagement") {
                url = this.baseUrl + api_constants_1.ApiConstants.ABI_PRODUCTION_API + action;
            }
            else if (managerToUse === "ABiTaxonomyManagement") {
                url = this.baseUrl + api_constants_1.ApiConstants.ABI_TAXONOMY_API + action;
            }
            else if (managerToUse === "ABiStagingMoveRecordsManagement") {
                url = this.baseUrl + api_constants_1.ApiConstants.ABI_STAGING_MOVE_RECORDS_API + action;
            }
            else if (managerToUse === "FileManager") {
                url = this.baseUrl + api_constants_1.ApiConstants.FILE_MANAGER_API + action;
            }
            else if (managerToUse === "ABiSiteCatalog") {
                url = this.baseUrl + api_constants_1.ApiConstants.ABI_SITE_CATALOG_API + action;
            }
            else if (managerToUse === "RealEstate") {
                url = this.baseUrl + api_constants_1.ApiConstants.REAL_ESTATE_API + action;
            }
            else if (managerToUse === "SellerAdmin") {
                url = this.baseUrl + api_constants_1.ApiConstants.SELLER_API + action;
            }
            else {
                url = this.baseUrl + this.managerName + '/Api/' + action;
            }
            return url;
        };
        ;
        ApiService.prototype.getTokenViaOAuth = function (action, encodedDn) {
            var url = this.determineUrl(action);
            this.$log.debug("%s - BT getToken URL: %s", this.apiServiceName, url);
            return this.$http.post(url, {}, {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'Basic ' + encodedDn,
                    'ClientId': 'dmles'
                }
            });
        };
        ;
        ApiService.prototype.get = function (action, managerName) {
            var url = this.determineUrl(action, managerName);
            this.$log.debug("%s - BT Get URL: %s", this.apiServiceName, url);
            return this.$http.get(url, {
                headers: {
                    'Authorization': 'Token ' + this.Authentication.getToken(),
                    'ClientId': 'dmles'
                }
            });
        };
        ;
        ApiService.prototype.getArrayBuffer = function (action, managerName) {
            var url = this.determineUrl(action, managerName);
            this.$log.debug("%s - BT Get URL: %s", this.apiServiceName, url);
            return this.$http.get(url, {
                headers: {
                    'Authorization': 'Token ' + this.Authentication.getToken(),
                    'ClientId': 'dmles',
                },
                responseType: 'arraybuffer'
            });
        };
        ;
        ApiService.prototype.post = function (action, data) {
            var url = this.determineUrl(action);
            this.$log.debug("%s - BT Post URL: %s", this.apiServiceName, url);
            return this.$http.post(url, data, {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'Token ' + this.Authentication.getToken(),
                    'ClientId': 'dmles'
                }
            });
        };
        ;
        return ApiService;
    }());
    exports.ApiService = ApiService;
});
//# sourceMappingURL=api.service.js.map