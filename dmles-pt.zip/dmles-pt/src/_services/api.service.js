define(["require", "exports", "../_constants/api.constants"], function (require, exports, api_constants_1) {
    'use strict';
    var ApiService = (function () {
        //@inject
        function ApiService($http, $log, Authentication, App, $httpParamSerializerJQLike, managerName) {
            this.$http = $http;
            this.$log = $log;
            this.Authentication = Authentication;
            this.App = App;
            this.$httpParamSerializerJQLike = $httpParamSerializerJQLike;
            this.managerName = managerName;
            this.apiServiceName = "Api Service";
        }
        ApiService.prototype.determineUrl = function (action) {
            var url = '';
            if (this.managerName === "User") {
                url = this.App.getBtBaseUrl() + api_constants_1.ApiConstants.USER_API + action;
            }
            else if (this.managerName === "Role") {
                url = this.App.getBtBaseUrl() + api_constants_1.ApiConstants.ROLE_API + action;
            }
            else if (this.managerName === "EquipmentManagement") {
                url = this.App.getBtBaseUrl() + api_constants_1.ApiConstants.EQUIPMENT_API + action;
            }
            else if (this.managerName === "Site") {
                url = this.App.getBtBaseUrl() + api_constants_1.ApiConstants.SITE_API + action;
            }
            else if (this.managerName === "System") {
                url = this.App.getBtBaseUrl() + api_constants_1.ApiConstants.SYSTEM_API + action;
            }
            else if (this.managerName === "OAuth") {
                url = this.App.getBtBaseUrl() + api_constants_1.ApiConstants.OAUTH_API + action;
            }
            else {
                url = this.App.getBtBaseUrl() + this.managerName + '/Api/' + action;
            }
            return url;
        };
        ;
        ApiService.prototype.getTokenViaOAuth = function (action, encodedDn) {
            var url = this.determineUrl(action);
            this.$log.debug("%s - BT getToken URL: %s", this.apiServiceName, url);
            return this.$http.post(url, {}, {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'Basic ' + encodedDn,
                    'ClientId': 'dmles'
                }
            });
        };
        ;
        ApiService.prototype.get = function (action) {
            var url = this.determineUrl(action);
            this.$log.debug("%s - BT Get URL: %s", this.apiServiceName, url);
            return this.$http.get(url, {
                headers: {
                    'Authorization': 'Token ' + this.Authentication.getToken(),
                    'ClientId': 'dmles'
                }
            });
        };
        ;
        ApiService.prototype.post = function (action, data) {
            var url = this.determineUrl(action);
            this.$log.debug("%s - BT Post URL: %s", this.apiServiceName, url);
            return this.$http.post(url, data, {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'Token ' + this.Authentication.getToken(),
                    'ClientId': 'dmles'
                }
            });
        };
        ;
        return ApiService;
    }());
    exports.ApiService = ApiService;
});
//# sourceMappingURL=api.service.js.map