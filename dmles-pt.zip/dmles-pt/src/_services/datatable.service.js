define(["require", "exports"], function (require, exports) {
    "use strict";
    var datatableService = (function () {
        //@inject
        function datatableService($log, NgTableParams) {
            this.$log = $log;
            this.NgTableParams = NgTableParams;
            this.serviceName = "datatableService";
            this.$log.debug("%s - Start", this.serviceName);
        }
        datatableService.prototype.createNgTable = function (data, pg_size, initSort) {
            if (!initSort) {
                initSort = {};
            }
            if (!pg_size) {
                pg_size = 25;
            }
            var initialParams = {
                count: pg_size,
                sorting: initSort
            };
            var initialSettings = {
                counts: [5, 25, 100, 500],
                paginationMaxBlocks: 10,
                paginationMinBlocks: 2,
                dataset: data
            };
            return new this.NgTableParams(initialParams, initialSettings);
        };
        return datatableService;
    }());
    exports.datatableService = datatableService;
});
//# sourceMappingURL=datatable.service.js.map