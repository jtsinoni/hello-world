var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", '../_services/api.service'], function (require, exports, api_service_1) {
    'use strict';
    var RoleService = (function (_super) {
        __extends(RoleService, _super);
        //@inject;
        function RoleService($http, $log, Authentication, $httpParamSerializerJQLike) {
            _super.call(this, $http, $log, Authentication, $httpParamSerializerJQLike, "Role");
            this.roleServiceName = "Role Service";
            this.$log.debug("%s - Start", this.roleServiceName);
        }
        /************************************************
         //
         // Functions used for Role amd User Management
         //
         *************************************************/
        RoleService.prototype.createRole = function (role) {
            return this.post("createRole", role).then(function (result) {
                return result;
            });
        };
        RoleService.prototype.toggleRoleEnabled = function (roleId) {
            return this.post("toggleRoleEnabled", roleId).then(function (result) {
                return result;
            });
        };
        // uses permission model - without elements, states and endpoints - used to build lists for
        // User and Role Management purposes
        RoleService.prototype.getAllPermissions = function () {
            return this.get("getAllPermissions");
        };
        RoleService.prototype.getAllRoles = function () {
            return this.get("getAllRoles");
        };
        RoleService.prototype.saveRoleData = function (role) {
            return this.post("saveRoleData", role).then(function (result) {
                return result;
            });
        };
        RoleService.prototype.saveRolePermissions = function (role) {
            return this.post("saveRolePermissions", role).then(function (result) {
                return result;
            });
        };
        /************************************************
         //
         // Functions used for Permission Management
         //
         *************************************************/
        RoleService.prototype.createPermissionDetailed = function (permission) {
            return this.post("createPermissionDetailed", permission).then(function (result) {
                return result;
            });
        };
        RoleService.prototype.deletePermissionDetailed = function (permission) {
            return this.post("deletePermissionDetailed", permission).then(function (result) {
                return result;
            });
        };
        RoleService.prototype.getAllElements = function () {
            return this.get("getAllElements");
        };
        RoleService.prototype.getAllEndpoints = function () {
            return this.get("getAllEndpoints");
        };
        // uses permissionDetailed model - includes elements, states and endpoints - used to access 
        // Permissions for CRUD by Permission Management
        RoleService.prototype.getAllPermissionsDetailed = function () {
            return this.get("getAllPermissionsDetailed");
        };
        RoleService.prototype.getRoleFunctionalAreaConfig = function () {
            return this.get("getRoleFunctionalAreaConfigs");
        };
        RoleService.prototype.getRoleFunctionalAreaConfigNames = function () {
            return this.get("getRoleFunctionalAreaConfigsDisplayNames");
        };
        RoleService.prototype.getAllStates = function () {
            return this.get("getAllStates");
        };
        RoleService.prototype.savePermissionData = function (permission) {
            return this.post("savePermissionDetailed", permission).then(function (result) {
                return result;
            });
        };
        RoleService.prototype.savePermissionElements = function (permission) {
            return this.post("savePermissionElements", permission).then(function (result) {
                return result;
            });
        };
        RoleService.prototype.savePermissionEndpoints = function (permission) {
            return this.post("savePermissionEndpoints", permission).then(function (result) {
                return result;
            });
        };
        RoleService.prototype.savePermissionStates = function (permission) {
            return this.post("savePermissionStates", permission).then(function (result) {
                return result;
            });
        };
        return RoleService;
    }(api_service_1.ApiService));
    exports.RoleService = RoleService;
});
//# sourceMappingURL=role.service.js.map