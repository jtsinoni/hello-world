'use strict';

import {User} from "../_models/user.model";
import {ApiConstants} from "../_constants/api.constants";
import {StateConstants} from "../_constants/state.constants";

export class AuthenticationService {
    private serviceName = "Authentication Service";

    //@inject
    constructor(private $log, private $state, private LocalStorageService) {
        this.$log.debug('%s - Start', this.serviceName);
    }

    public getToken() {
        return this.LocalStorageService.getData(ApiConstants.DMLES_TOKEN);
    }

    public isLoggedIn() {
        return !!this.getToken();
    }

    public logout() {
        this.LocalStorageService.removeData(ApiConstants.DMLES_TOKEN);
        this.LocalStorageService.clearData();
    }

    private saveToken(token) {
        this.LocalStorageService.storeData(ApiConstants.DMLES_TOKEN, token, false);
    }

    public verifyLogin() {
        if (!this.isLoggedIn()) {
            this.$state.go(StateConstants.LOGIN);
        }
    }
}