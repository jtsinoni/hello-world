'use strict';

export class SidePanelService {
    private serviceName:string = "SidePanelService";

    private closedStyle:any = { "width" : "20px", "padding" : "5px" };
    private openStyle:any = { "width" : "20px", "padding" : "5px" };
    private iconRightOpen:string = "fa fa-angle-double-right";
    private iconRightClosed:string = "fa fa-angle-double-left";
    private iconLeftOpen:string = "fa fa-angle-double-left";
    private iconLeftClosed:string = "fa fa-angle-double-right";

    public defaultPanelWidth:string = '25%';

    public isLeftPanelButtonShown:boolean = false;
    public isLeftPanelShown:boolean = false;
    public leftOutterStyle:any = {};
    public leftPanelIcon:string;
    public leftPanelStyle:any = {};
    public leftPanelWidthOpened:string;

    public isRightPanelButtonShown:boolean = false;
    public isRightPanelShown:boolean = false;
    public rightOutterStyle:any = {};
    public rightPanelIcon:string;
    public rightPanelStyle:any = {};
    public rightPanelWidthOpened:string;

    //@inject
    constructor(private $log, private DmlesGridService, private StateConstants) {
        this.resetLeftPanel();
        this.resetRightPanel();
    }

    private resetLeftPanel(){
        this.leftPanelIcon = this.iconLeftClosed;
        this.leftPanelWidthOpened = this.defaultPanelWidth;
        this.leftPanelStyle = this.closedStyle;
        this.leftOutterStyle = { "margin-left" : "5px" };
    }

    private resetRightPanel(){
        this.rightPanelIcon = this.iconRightClosed;
        this.rightPanelWidthOpened = this.defaultPanelWidth;
        this.rightPanelStyle = this.closedStyle;
        this.rightOutterStyle = { "margin-right" : 0 };
    }

    public checkForPanelButton(toState){
        this.$log.info(this.serviceName + ": Checking for side panels");

        this.isLeftPanelButtonShown = false;
        this.isRightPanelButtonShown = false;

        if (toState.name === this.StateConstants.EQUIP_REQUEST_VIEW) {
            this.$log.info(this.serviceName + ": Show right side panel button");
            this.isRightPanelButtonShown = true;
        }else if (toState.name === this.StateConstants.CATALOG_SEARCH) {
            this.$log.info(this.serviceName + ": Show left side panel button");
            this.isLeftPanelButtonShown = true;
        }else if(toState.name === this.StateConstants.EQUIP_RECORD_SEARCH){
            this.$log.info(this.serviceName + ": Show left side panel button");
            this.isLeftPanelButtonShown = true;
            this.$log.info(this.serviceName + ": Show right side panel button");
            this.isRightPanelButtonShown = true;
        }
    }

    public toggleLeftPanel(){
        if(this.isLeftPanelShown){
            this.$log.info(this.serviceName + ": Toggle to closed");
            this.leftPanelStyle = this.openStyle;
            this.leftOutterStyle = { "margin-left" : "5px" };
            this.leftPanelIcon = this.iconLeftClosed;
        }else{
            this.$log.info(this.serviceName + ": Toggle to open");
            this.$log.info(this.serviceName + ": Toggle to opened " + this.leftPanelWidthOpened);
            this.leftPanelStyle = { "width" : this.leftPanelWidthOpened, "padding" : "0 10px" };
            this.leftOutterStyle = { "margin-left" : this.leftPanelWidthOpened };
            this.leftPanelIcon = this.iconLeftOpen;
        }
        this.isLeftPanelShown = !this.isLeftPanelShown;

        this.DmlesGridService.handleWindowResize();        
    }

    public toggleRightPanel(){
        if(this.isRightPanelShown){
            this.$log.info(this.serviceName + ": Toggle to closed");
            this.rightPanelStyle = this.openStyle;
            this.rightOutterStyle = { "margin-right" : 0 };
            this.rightPanelIcon = this.iconRightClosed;
        }else{
            this.$log.info(this.serviceName + ": Toggle to open");
            this.$log.info(this.serviceName + ": Toggle to opened " + this.rightPanelWidthOpened);
            this.rightPanelStyle = { "width" : this.rightPanelWidthOpened, "padding" : "0 10px" };
            this.rightOutterStyle = { "margin-right" : this.rightPanelWidthOpened };
            this.rightPanelIcon = this.iconRightOpen;
        }
        this.isRightPanelShown = !this.isRightPanelShown;

        this.DmlesGridService.handleWindowResize();
    }
}