define(["require", "exports", './api.service', './authentication.service', './base64.service', './baseSelectFilter.service', './commonData.service', './data.service', './datatable.service', './fileExchange.service', './localStorage.service', './multiSelect.service', './notification.service', './permission.service', './oauth.service', './role.service', './search.service', './sidepanel.service', './site.service', './system.service', './user.service', './userProfile.service', './fileManager.service', './util.service'], function (require, exports, api_service_1, authentication_service_1, base64_service_1, baseSelectFilter_service_1, commonData_service_1, data_service_1, datatable_service_1, fileExchange_service_1, localStorage_service_1, multiSelect_service_1, notification_service_1, permission_service_1, oauth_service_1, role_service_1, search_service_1, sidepanel_service_1, site_service_1, system_service_1, user_service_1, userProfile_service_1, fileManager_service_1, util_service_1) {
    "use strict";
    var servicesModule = angular.module('Dmles.Services.Module', []);
    servicesModule.service('Api', api_service_1.ApiService);
    servicesModule.service('Authentication', authentication_service_1.AuthenticationService);
    servicesModule.service('Base64Service', base64_service_1.Base64Service);
    servicesModule.service('BaseSelectFilterService', baseSelectFilter_service_1.BaseSelectFilterService);
    servicesModule.service('CommonDataService', commonData_service_1.CommonDataService);
    servicesModule.service('dataService', data_service_1.DataService);
    servicesModule.service('datatableService', datatable_service_1.datatableService);
    servicesModule.service('FileExchangeService', fileExchange_service_1.FileExchangeService);
    servicesModule.service('FileManagerService', fileManager_service_1.FileManagerService);
    servicesModule.service('LocalStorageService', localStorage_service_1.LocalStorageService);
    servicesModule.service('MultiSelectService', multiSelect_service_1.MultiSelectService);
    servicesModule.service('NotificationService', notification_service_1.NotificationService);
    servicesModule.service('PermissionService', permission_service_1.PermissionService);
    servicesModule.service('OAuthService', oauth_service_1.OAuthService);
    servicesModule.service('RoleService', role_service_1.RoleService);
    servicesModule.service('SearchService', search_service_1.SearchService);
    servicesModule.service('SidePanelService', sidepanel_service_1.SidePanelService);
    servicesModule.service('SiteService', site_service_1.SiteService);
    servicesModule.service('SystemService', system_service_1.SystemService);
    servicesModule.service('UserService', user_service_1.UserService);
    servicesModule.service('UserProfileService', userProfile_service_1.UserProfileService);
    servicesModule.service('UtilService', util_service_1.UtilService);
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = servicesModule;
});
//# sourceMappingURL=module.js.map