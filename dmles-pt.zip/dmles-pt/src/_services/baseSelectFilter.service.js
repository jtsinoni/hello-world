define(["require", "exports"], function (require, exports) {
    'use strict';
    var BaseSelectFilterService = (function () {
        // @ngInject
        function BaseSelectFilterService() {
            this.value = [];
            this.options = [];
            this.optionsSelected = [];
        }
        BaseSelectFilterService.prototype.buildSearchClause = function (dbFieldName) {
            var returnValue = "";
            var i = 0;
            for (i = 0; i < this.optionsSelected.length; i++) {
                if (i > 0) {
                    returnValue = returnValue + " OR ";
                }
                if (this.optionsSelected[i] !== "") {
                    // escape special characters that might be embedded in DMLSS/DML-ES data
                    // not doing this causes issues for elasticsearch
                    returnValue = returnValue + "(" + dbFieldName + ':"'
                        + this.optionsSelected[i].selValue.replace(/[!@#$%^&()+=\-[\]\\';,./{}|":<>?~_]/g, "\\$&")
                        + '")';
                }
            }
            if (this.optionsSelected.length > 1) {
                returnValue = "(" + returnValue + ")";
            }
            // console.log("returnValue: %s", JSON.stringify(returnValue));
            return returnValue;
        };
        BaseSelectFilterService.prototype.initialize = function () {
            this.value = [];
            this.options = [];
            this.optionsSelected = [];
        };
        BaseSelectFilterService.prototype.process = function () {
            this.value = [];
            var n;
            for (n in this.optionsSelected) {
                var selection = this.optionsSelected[n];
                this.value.push(selection.selValue);
            }
        };
        BaseSelectFilterService.prototype.processOptionsSelected = function () {
            this.optionsSelected = [];
            var n;
            for (n in this.options) {
                if (this.options[n].selected) {
                    var selection = this.options[n];
                    this.optionsSelected.push(selection);
                }
            }
        };
        BaseSelectFilterService.prototype.removeDuplicates = function (inputArray) {
            var seen = {};
            var out = [];
            var len = inputArray.length;
            var j = 0;
            for (var i = 0; i < len; i++) {
                var item = inputArray[i];
                if (seen[item] !== 1) {
                    seen[item] = 1;
                    out[j++] = item;
                }
            }
            return out;
        };
        return BaseSelectFilterService;
    }());
    exports.BaseSelectFilterService = BaseSelectFilterService;
});
//# sourceMappingURL=baseSelectFilter.service.js.map