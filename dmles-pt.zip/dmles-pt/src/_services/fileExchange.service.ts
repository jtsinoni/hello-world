import {UploadFileInformation} from '../_models/uploadFileInformation.model';
import {FileUploadData} from '../_models/fileUploadData.model';

export interface IFileExchangeService {

}

export class FileExchangeService implements IFileExchangeService {

    private serviceName:string = "File Exchange Service";
    private uploadService:string = "file-exchange/dmles/rest-api/upload";
    private downloadService:string = "file-exchange/dmles/rest-api/download?fileurl=";


    //@inject
    constructor(private $http) {
    }

    public uploadFile(fileInfo:UploadFileInformation) {
        /*
        if (fileInfo) {
            var uri:string = this.App.getBtBaseUrl() + this.uploadService;
            var filedata:FileUploadData = FileUploadData.create(fileInfo);
            var fd:FormData = new FormData();

            fd.append('fileDescription', fileInfo.description);
            fd.append('fileName', fileInfo.file.name);
            fd.append('attachment', fileInfo.file.contents);
            fd.append('fileData', JSON.stringify(filedata));

            var data = {
                transformRequest: angular.identity,
                headers: {
                    "Content-Type": undefined
                }
            };

            return this.$http.post(uri, fd, data);
        }
        */
    }

    public getDownloadUrl() {
        /*
        var uri:string = this.App.getBtBaseUrl() + this.downloadService;
        return uri;
        */
    }
}