var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", './api.service', "../_constants/api.constants", "../_constants/config.constants"], function (require, exports, api_service_1, api_constants_1, config_constants_1) {
    "use strict";
    var FileManagerService = (function (_super) {
        __extends(FileManagerService, _super);
        // @ngInject
        function FileManagerService($http, $httpParamSerializerJQLike, $log, Authentication) {
            _super.call(this, $http, $log, Authentication, $httpParamSerializerJQLike, "FileManager");
            this.serviceName = "FileManagerService";
            this.lastSearchFilter = null;
            this.$log.debug("%s - Start", this.serviceName);
            this.myHttp = $http;
        }
        FileManagerService.prototype.download = function (fileId) {
            this.$log.debug("%s - Calling getImage(%s) REST service.", this.serviceName, fileId);
            var query = "download?fileId=" + fileId;
            return this.getArrayBuffer(query);
        };
        FileManagerService.prototype.base64download = function (fileId) {
            this.$log.debug("%s - Calling base64download(%s) REST service.", this.serviceName, fileId);
            var query = "base64Download?fileId=" + fileId;
            return this.get(query);
        };
        FileManagerService.prototype.getManagedFileInfo = function (fileId) {
            this.$log.debug("%s - Calling base64download(%s) REST service.", this.serviceName, fileId);
            var query = "getManagedFileInfo?fileId=" + fileId;
            return this.get(query);
        };
        FileManagerService.prototype.getUploadConfiguration = function () {
            this.$log.debug("%s - called getUploadConfigurations) API.");
            var uploadUrl = config_constants_1.ConfigConstants.BT_BASE_URL + api_constants_1.ApiConstants.FILE_MANAGER_API + 'upload';
            return {
                url: uploadUrl,
                headers: {
                    'authorization': 'Token ' + this.Authentication.getToken(),
                    'ClientId': 'dmles'
                }
            };
        };
        FileManagerService.prototype.getMaxPostSize = function () {
            this.$log.debug("%s - called getMaxPostSize) API.");
            var query = 'getMaxPostSize';
            return this.get(query);
        };
        FileManagerService.prototype.getPermittedFileExtensions = function () {
            this.$log.debug("%s - called getPermittedFileExtensions) API.");
            var query = 'getPermittedFileExtensions';
            return this.get(query);
        };
        FileManagerService.prototype.removeFile = function (fileId) {
            var query = "removeManagedFile?fileId=" + fileId;
            return this.get(query);
        };
        return FileManagerService;
    }(api_service_1.ApiService));
    exports.FileManagerService = FileManagerService;
});
//# sourceMappingURL=fileManager.service.js.map