'use strict';

export interface ISearchService {
    
}

export class SearchService implements ISearchService {

    //@inject
    constructor() {}

    public getSearchData(result) {
        var retVal = {};
        if (result && result.data.hits.hits) {
            retVal = result.data.hits.hits;
            //console.log("Data Service - DB return data: %s", JSON.stringify(retVal));
        } else {
//            console.log("Search Service - Warning: No data returned");
        }
        return retVal;
    };

    public getSearchStats(result) {
        var retVal = {
            "total": 0,
            "time": 0.00
        };
        if (result && result.data && result.data.hits) {
            if (result.data.hits.total) {
                retVal.total = result.data.hits.total;
            }

            if (result.data.took) {
                retVal.time = result.data.took;
            }
        }
        else {
//            console.log("Search Service - Warning: No data returned");
        }
        return retVal;
    };
}