define(["require", "exports"], function (require, exports) {
    "use strict";
    var LocalStorageService = (function () {
        //@inject
        function LocalStorageService($log, $window, UtilService) {
            this.$log = $log;
            this.$window = $window;
            this.UtilService = UtilService;
            this.serviceName = "LocalStorageService";
            this.$log.debug('%s - Start', this.serviceName);
        }
        LocalStorageService.prototype.clearData = function () {
            this.$window.localStorage.clear();
            this.$log.info("%s - Cache data cleared", this.serviceName);
        };
        LocalStorageService.prototype.getData = function (key) {
            var value = this.$window.localStorage.getItem(key);
            if (!value || "undefined" == value || "null" == value) {
                return null;
            }
            // assume it is an object that has been stringified
            if (value[0] === "{") {
                value = JSON.parse(value);
            }
            this.$log.info("%s - Get cache data: %s => %s", this.serviceName, key, value);
            return value;
        };
        LocalStorageService.prototype.removeData = function (key) {
            this.$window.localStorage.removeItem(key);
            this.$log.info("%s - Cache data removed: %s", this.serviceName, key);
        };
        LocalStorageService.prototype.storeData = function (key, data, stringify) {
            this.$log.info("%s - Store cache data: %s => %s", this.serviceName, key, JSON.stringify(data));
            if (stringify && !this.UtilService.isObjectEmpty(data)) {
                data = JSON.stringify(data);
                this.$log.info("%s - Stringified cached data", this.serviceName);
            }
            this.$window.localStorage[key] = data;
        };
        return LocalStorageService;
    }());
    exports.LocalStorageService = LocalStorageService;
});
//# sourceMappingURL=localStorage.service.js.map