'use strict';
import {ApiService} from "./api.service";
import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;

export interface ISystemService {

}

export class SystemService extends ApiService implements ISystemService {
    private serviceName: string = "System Service";

    private serviceRegionSiteHierarchicalData: any[] = null;
    private services: any[] = [];
    private regions: any[] = [];
    private sites: any[] = [];

    //@inject
    constructor($http, $log, Authentication, $httpParamSerializerJQLike, private $filter) {
        super($http, $log, Authentication, $httpParamSerializerJQLike, "System");
        this.$log.debug("%s - Start", this.serviceName);
    }

    // this actually now returns service, regions and site in hierarchical structure
    public getServices() {
        return this.get("getServices");
    }

    // parse the response from getServices into services, regions, sites
    private buildServicesRegionsSites() {
        this.getServices().then((response: IHttpPromiseCallbackArg<any>) => {
            // this.$log.debug("MainNav Returned: %s", JSON.stringify(response.data));

            // this response now includes services, regions within service and dodaacs within regions
            this.serviceRegionSiteHierarchicalData = response.data;

            var i: number = 0;
            var j: number = 0;
            var k: number = 0;
            var s: string;
            for (s in this.serviceRegionSiteHierarchicalData) {
                var service = this.serviceRegionSiteHierarchicalData[s];
                this.services[i++] = service;
                var r: string;
                for (r in service.regions) {
                    var region = service.regions[r];
                    this.regions[j] = region;
                    var t: string;
                    for (t in region.sites) {
                        var site = region.sites[t];
                        this.sites[k] = site;
                        this.sites[k].regionCode = region.code;
                        this.sites[k].regionName = region.name;
                        this.sites[k].serviceCode = service.code;
                        this.sites[k].serviceName = service.name;
                        k++;
                    }
                    this.regions[j].serviceCode = service.code;
                    this.regions[j].serviceName = service.name;
                    j++;
                    delete this.regions[r].sites;
                }
                delete this.services[s].regions;
            }
            // this.$log.debug("this.services: %s", JSON.stringify(this.services));
            // this.$log.debug("this.regions: %s", JSON.stringify(this.regions));
            // this.$log.debug("this.sites: %s", JSON.stringify(this.sites));

        }, (errResponse: IHttpPromiseCallbackArg<any>) => {
            this.$log.error("%s - Error retrieving hierarchical data that contains services, regions and sites", this.serviceName);            
        });
    }

    public lookupServiceGivenServiceCode(serviceCode: string): string {        
        var filteredService = this.$filter('filter')(this.services, {"code": serviceCode}, true);
        return filteredService[0];
    }

    public lookupSiteGivenSiteDodaac(dodaac: string): string {
        var filteredSite = this.$filter('filter')(this.sites, {"dodaac": dodaac}, true);
        return filteredSite[0];
    }

    public lookupSiteNameGivenSiteDodaac(dodaac: string): string {
        let filteredSite = this.$filter('filter')(this.sites, {"dodaac": dodaac}, true);
        if (filteredSite && filteredSite[0]) {
            return filteredSite[0].name;
        } else {
            return "Not Found";
        }
    }

    /**
     public getRegions() {
        return this.get("getRegions");
    }
     **/
}