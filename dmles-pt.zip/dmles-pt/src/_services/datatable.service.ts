export class datatableService {
    private serviceName:string = "datatableService";

    //@inject
    constructor(private $log, private NgTableParams) {
        this.$log.debug("%s - Start", this.serviceName);
    }

    public createNgTable(data, pg_size, initSort) {

        if(!initSort){
            initSort = {};
        }

        if(!pg_size){
            pg_size = 25;
        }

        var initialParams:any = {
            count: pg_size,
            sorting: initSort
        };

        var initialSettings:any = {
            counts: [5, 25, 100, 500],
            paginationMaxBlocks: 10,
            paginationMinBlocks: 2,
            dataset: data
        };

        return new this.NgTableParams(initialParams, initialSettings);
    }

}