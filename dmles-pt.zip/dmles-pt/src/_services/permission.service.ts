'use strict';

import {CurrentUserProfile} from "../_models/currentUserProfile.model";

export class PermissionService {
    private serviceName: string = "Permission Service";

    //@inject;
    constructor(private $log, private UserService) {
    }

    /***
     * Becky's function for the gui - Returns the boolean value if the user has permission or not
     * not sure what params it will need
     */

    public hasPermission(role) {
        return true;
    }

    /**
     Checks to see if the CurrentUserProfile.elements contain the given element - if so, it has permission to access
     @param elementName - the element to look for
     @returns true if found, else false
     */
    public checkElements(elementName: string): boolean {
        var canAccess: boolean = false;

        var currentUserProfile: CurrentUserProfile = this.UserService.currentUser;
        if (currentUserProfile && currentUserProfile.elements) {
            // this.$log.debug("checkElements: %s, %s", elementName, JSON.stringify(currentUserProfile.elements));
            canAccess = this.isAssignedPermissionFound(elementName, currentUserProfile.elements);
            // this.$log.debug("canAccess: %s", canAccess);
        }
        return canAccess;
    };

    /**
     Searches the given CurrentUserProfile elements for the given element.
     @param elementName - a string representing the elementName to look for.
     @returns true if found, else false
     */
    public isAssignedPermissionFound(elementName: string, userElements: string[]): boolean {
        // this.$log.debug("isAssignedPermissionFound: %s, %s", elementName, JSON.stringify(userElements));
        // this.$log.debug("userElements.indexOf(elementName): %s", userElements.indexOf(elementName));
        if (userElements.indexOf(elementName) > -1) {
            // this.$log.debug("isAssignedPermissionFound: returning true");
            return true;
        } else {
            // this.$log.debug("isAssignedPermissionFound: returning false");
            return false;
        }
    };

    /**
     Checks to see if the CurrentUserProfile.states contain the given state - if so, it has permission to access
     @param stateName - the state to look for
     @returns true if found, else false
     */
    public checkStates(stateName: string): boolean {
        var canAccess: boolean = false;

        var currentUserProfile: CurrentUserProfile = this.UserService.currentUser;
        if (currentUserProfile && currentUserProfile.states) {
            // this.$log.debug("checkStates: %s, %s", stateName, JSON.stringify(currentUserProfile.states));
            canAccess = this.isStateFound(stateName, currentUserProfile.states);
            // this.$log.debug("canAccess: %s", canAccess);
        }
        return canAccess;
    };

    /**
     Searches the given CurrentUserProfile states for the given state.
     @param stateName - a string representing the stateName to look for.
     @returns true if found, else false
     */
    public isStateFound(stateName: string, userStates: string[]): boolean {
        // this.$log.debug("isStateFound: %s, %s", stateName, JSON.stringify(userStates));
        // this.$log.debug("userStates.indexOf(stateName): %s", userStates.indexOf(stateName));
        if (userStates.indexOf(stateName) > -1) {
            // this.$log.debug("isStateFound: returning true");
            return true;
        } else {
            // this.$log.debug("isStateFound: returning false");
            return false;
        }
    };
}