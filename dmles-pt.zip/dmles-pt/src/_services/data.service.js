define(["require", "exports"], function (require, exports) {
    'use strict';
    var DataService = (function () {
        //@inject
        function DataService($cacheFactory, $http, $q, ApiConstants, App, Authentication) {
            this.$cacheFactory = $cacheFactory;
            this.$http = $http;
            this.$q = $q;
            this.ApiConstants = ApiConstants;
            this.App = App;
            this.Authentication = Authentication;
            this.serviceName = "Data Service";
            this.cache = this.$cacheFactory('dataCache');
        }
        /*
         The $q.defer() simulates a promise.  This allows you to get data locally,
         for instance from cache, before making an $http call and return data.
         */
        DataService.prototype.error = function (data, stats) {
            var deferred = this.$q.defer();
            console.log("Data Service - Error, data: %s", JSON.stringify(data));
            console.log("Data Service - Error, stats: %s", JSON.stringify(stats));
            deferred.reject(data);
            return deferred.promise;
        };
        /*
         The $q.defer() simulates a promise.  This allows you to get data locally,
         for instance from cache, before making an $http call and return data.
         */
        DataService.prototype.success = function (data) {
            var deferred = this.$q.defer();
            //console.log("Data Service - Success, data: %s", JSON.stringify(data));
            deferred.resolve(data);
            return deferred.promise;
        };
        DataService.prototype.clearCache = function () {
            this.cache.removeAll();
        };
        DataService.prototype.getAuthHeader = function () {
            return {
                headers: {
                    Authorization: 'Bearer ' + this.Authentication.getToken()
                }
            };
        };
        DataService.prototype.getResultData = function (result) {
            var retVal = {};
            if (result && result.data) {
                retVal = result.data;
            }
            else {
            }
            return retVal;
        };
        DataService.prototype.postCacheOrData = function (url, postData) {
            var cacheId = url + '*' + postData; // Note: Key * Value
            var cachedData = this.cache.get(cacheId);
            // Check cache first
            if (cachedData) {
                var result = { "data": cachedData }; // Simulates a database return
                return this.success(result);
            }
            // If it's not cached then, go get it
            //console.log("Data Service - Getting from DB");
            return this.$http.post(url, postData, this.getAuthHeader()).success(function (data, status, headers, config) {
                // Put this in our cache using our 'unique' id for future use
                this.cache.put(cacheId, data);
                this.success(data);
            }).error(this.error);
        };
        return DataService;
    }());
    exports.DataService = DataService;
});
//# sourceMappingURL=data.service.js.map