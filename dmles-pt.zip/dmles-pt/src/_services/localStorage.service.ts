export class LocalStorageService {
    private serviceName = "LocalStorageService";

    //@inject
    constructor(private $log, private $window, private UtilService) {
        this.$log.debug('%s - Start', this.serviceName);
    }

    public clearData(){
        this.$window.localStorage.clear();
        this.$log.debug("%s - Cache data cleared", this.serviceName);
    }

    public getData(key:string){
        var value:any = this.$window.localStorage.getItem(key);

        if (!value || "undefined" == value || "null" == value) {
            return null;
        }

        // assume it is an object that has been stringified
        if (value[0] === "{") {
            value = JSON.parse(value);
        }

        //this.$log.debug("%s - Get cache data: %s => %s", this.serviceName, key, value);
        return value;
    }

    public removeData(key:string){
        this.$window.localStorage.removeItem(key);
        //this.$log.debug("%s - Cache data removed: %s", this.serviceName, key);
    }

    public storeData(key:string, data:any, stringify:boolean){
        //this.$log.debug("%s - Store cache data: %s => %s", this.serviceName, key, JSON.stringify(data));

        if(stringify && !this.UtilService.isObjectEmpty(data)){
            data = JSON.stringify(data);
            //this.$log.debug("%s - Stringified cached data", this.serviceName);
        }

        this.$window.localStorage[key] = data;
    }
}