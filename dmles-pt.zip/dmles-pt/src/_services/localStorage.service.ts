'use strict';

import {User} from "../_models/user.model";
import {ApiConstants} from "../_constants/api.constants";
import {StateConstants} from "../_constants/state.constants";

export class LocalStorageService {
    private serviceName = "LocalStorageService";

    //@inject
    constructor(private $log, private $window) {
        this.$log.debug('%s - Start', this.serviceName);
    }

    public clearData(){
        this.$window.localStorage = null;
        this.$log.info("%s - Local data cleared", this.serviceName);
    }

    public getData(key:string){
        this.$log.info("%s - Get local data: %s", this.serviceName, key);
        var data:any = this.$window.localStorage[key];
        return data;
    }

    public removeData(key:string){
        this.$window.localStorage.removeItem(key);
        this.$log.info("%s - Local data removed: %s", this.serviceName, key);
    }

    public storeData(key:string, data:any){
        this.$log.info("%s - Store local data: %s => %s", this.serviceName, key, data);
        this.$window.localStorage[key] = data;
    }
}