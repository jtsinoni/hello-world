'use strict';

export interface IDataService {

}

export class DataService implements IDataService {
    private serviceName:string = "Data Service";
    private cache:any;

    //@inject
    constructor(private $cacheFactory, private $http, private $q, private ApiConstants, private App, private Authentication) {
        this.cache = this.$cacheFactory('dataCache');
    }

    /*
     The $q.defer() simulates a promise.  This allows you to get data locally,
     for instance from cache, before making an $http call and return data.
     */
    private error(data, stats) {
        var deferred = this.$q.defer();
        console.log("Data Service - Error, data: %s", JSON.stringify(data));
        console.log("Data Service - Error, stats: %s", JSON.stringify(stats));
        deferred.reject(data);
        return deferred.promise;
    }

    /*
     The $q.defer() simulates a promise.  This allows you to get data locally,
     for instance from cache, before making an $http call and return data.
     */
    private success(data) {
        var deferred = this.$q.defer();
        //console.log("Data Service - Success, data: %s", JSON.stringify(data));
        deferred.resolve(data);
        return deferred.promise;
    }


    public clearCache() {
        this.cache.removeAll();
    }

    public getAuthHeader() {
        return {
            headers: {
                Authorization: 'Bearer ' + this.Authentication.getToken()
            }
        }
    }

    public getResultData(result) {
        var retVal = {};
        if (result && result.data) {
            retVal = result.data;
            //console.log("Data Service - DB return data: %s", JSON.stringify(retVal));
        } else {
            //console.log("Data Service - Warning: No data returned");
        }
        return retVal;
    }

    public postCacheOrData(url, postData) {
        var cacheId = url + '*' + postData;  // Note: Key * Value
        var cachedData = this.cache.get(cacheId);

        // Check cache first
        if (cachedData) {
            var result = {"data": cachedData};  // Simulates a database return
            return this.success(result);
        }

        // If it's not cached then, go get it
        //console.log("Data Service - Getting from DB");
        return this.$http.post(url, postData, this.getAuthHeader()).success(function (data, status, headers, config) {
            // Put this in our cache using our 'unique' id for future use
            this.cache.put(cacheId, data);
            this.success(data);
        }).error(this.error);

    }

}