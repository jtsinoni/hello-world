'use strict';

export class MultiSelectService {

   //@inject
    constructor() {}

    public buildSelection(itemId, selId, selValue, selected) {
        return {
            "itemId": itemId,
            "selId": selId,
            "selValue": selValue,
            "selected": selected
        };
    }
}