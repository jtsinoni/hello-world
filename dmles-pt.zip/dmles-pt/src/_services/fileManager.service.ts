import {ApiService} from "./api.service";

export class FileManagerService extends ApiService {
    private serviceName: String = "FileManagerService";
    private myHttp: any;

    public file: any;
    public fileURL: any;
    public embedContentToDisplay:any;
    public embedContentToDisplayFileName:string;
    public lastSearchFilter: String = null;

    // @ngInject
    constructor($http, $httpParamSerializerJQLike, $log, Authentication, private AppConfig, private ApiConstants) {
        super($http, $log, Authentication, $httpParamSerializerJQLike, "FileManager");
        this.$log.debug("%s - Start", this.serviceName);
        this.myHttp = $http;
    }

    public download(fileId:string) {
        this.$log.debug("%s - Calling getImage(%s) REST service.", this.serviceName, fileId);
        var query = "download?fileId=" + fileId;
        return this.getArrayBuffer(query);
    }

    public base64download(fileId:string) {
        this.$log.debug("%s - Calling base64download(%s) REST service.", this.serviceName, fileId);
        var query = "base64Download?fileId=" + fileId;
        return this.get(query);
    }

    public getManagedFileInfo(fileId:string) {
        this.$log.debug("%s - Calling base64download(%s) REST service.", this.serviceName, fileId);
        var query = "getManagedFileInfo?fileId=" + fileId;
        return this.get(query);
    }

    public getUploadConfiguration():any {

        this.$log.debug("%s - called getUploadConfigurations) API.");
        var uploadUrl: string = this.AppConfig.BT_BASE_URL + this.ApiConstants.FILE_MANAGER_API  +'upload';

        return {
            url: uploadUrl,
            headers: {
                'authorization': 'Token ' + this.Authentication.getToken(),
                'ClientId': 'dmles'
            }
        };
    }

    public getMaxPostSize(): any {
        this.$log.debug("%s - called getMaxPostSize) API.");
        var query = 'getMaxPostSize';

        return this.get(query);
    }

    public getPermittedFileExtensions(): Array<string>  {
        this.$log.debug("%s - called getPermittedFileExtensions) API.");
        var query = 'getPermittedFileExtensions';

        return this.get(query);
    }

    public removeFile(fileId:string) {
        var query = "removeManagedFile?fileId=" + fileId;
        return this.get(query);
    }
}
