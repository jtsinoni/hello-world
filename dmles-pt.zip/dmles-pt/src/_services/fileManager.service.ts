import {ApiService} from './api.service';
import {ApiConstants} from "../_constants/api.constants";
import {ConfigConstants} from "../_constants/config.constants";

export class FileManagerService extends ApiService {
    private serviceName: String = "FileManagerService";
    private myHttp: any;

    public lastSearchFilter: String = null;

    // @ngInject
    constructor($http, $httpParamSerializerJQLike, $log, Authentication) {
        super($http, $log, Authentication, $httpParamSerializerJQLike, "FileManager");
        this.$log.debug("%s - Start", this.serviceName);
        this.myHttp = $http;
    }

    public download(fileId:string) {
        this.$log.debug("%s - Calling getImage(%s) REST service.", this.serviceName, fileId);
        var query = "download?fileId=" + fileId;
        return this.get(query);
    }

    public base64download(fileId:string) {
        this.$log.debug("%s - Calling base64download(%s) REST service.", this.serviceName, fileId);
        var query = "base64Download?fileId=" + fileId;
        return this.get(query);
    }

    public getManagedFileInfo(fileId:string) {
        this.$log.debug("%s - Calling base64download(%s) REST service.", this.serviceName, fileId);
        var query = "getManagedFileInfo?fileId=" + fileId;
        return this.get(query);
    }

    public getUploadConfiguration():any {

        this.$log.debug("%s - called getUploadConfigurations) API.");
        var uploadUrl: string = ConfigConstants.BT_BASE_URL + ApiConstants.FILE_MANAGER_API  +'upload';

        return {
            url: uploadUrl,
            headers: {
                'authorization': 'Token ' + this.Authentication.getToken(),
                'ClientId': 'dmles'
            }
        };
    }

}
