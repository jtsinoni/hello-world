'use strict';

export interface IAppService {

}

export class AppService implements IAppService {
    private btBaseUrl:string;
    private serviceName:string = "App Service";

    //@inject
    constructor(private $http, private $log, private AppConfig) {
    }

    public getBtBaseUrl() {
        return this.btBaseUrl;
    }

    public setConfigs() {
        if (this.AppConfig.apiHosts.btBaseUrl) {
            this.btBaseUrl = this.AppConfig.apiHosts.btBaseUrl;
            this.$log.debug("%s - btBaseUrl loaded: %s", this.serviceName, this.btBaseUrl);
        } else {
            this.$log.error("%s - Error: Unable to load btBaseUrl", this.serviceName);
        }
    }
}