import {Site} from "../_models/site.model";
'use strict';

import {ApiService} from '../_services/api.service';
import {UserProfile} from '../_models/userProfile.model';
import {CurrentUserProfile} from "../_models/currentUserProfile.model";

export interface IUserProfileService {

}

export class UserProfileService extends ApiService implements IUserProfileService {

    public userProfileServiceName: string = "User Profile Service";

    //@inject;
    constructor($http, $log, Authentication, App, $httpParamSerializerJQLike) {
        super($http, $log, Authentication, App, $httpParamSerializerJQLike, "User");
        this.$log.debug("%s - Start", this.userProfileServiceName);
    }

    public approveUserProfile(userProfile: UserProfile): UserProfile {
        return this.post("approveUserProfile", userProfile).then((result) => {
            return result;
        });
    }

    public checkUserEmail(checkEmail: string) {
        return this.get("checkUserEmail?email=" + checkEmail);
    }

    public deleteUserProfile(userProfile: UserProfile): UserProfile {
        return this.post("deleteUserProfile", userProfile).then((result) => {
            return result;
        });
    }

    public denyUserProfile(userProfile: UserProfile): UserProfile {
        return this.post("denyUserProfile", userProfile).then((result) => {
            return result;
        });
    }

    public getActiveUserProfiles(): CurrentUserProfile[] {
        return this.get("getActiveUserProfiles");
    }

    public getAllUserProfiles() {
        return this.get("getAllUserProfiles");
    }

    public getApprovedUserProfiles() {
        return this.get("getApprovedUserProfiles");
    }

    public getCurrentProfile(): CurrentUserProfile {
        return this.get("getCurrentProfile");
    }

    public getPendingUserProfiles() {
        return this.get("getPendingUserProfiles");
    }

    public getTotalPendingUserProfiles() {
        var pendingUserProfiles: UserProfile[] = this.get("getPendingUserProfiles");
        return pendingUserProfiles.length;
    }

    public getUserProfileById(id: string): UserProfile {
        return this.get("getUserProfileById?id=" + id);
    }

    public getUserByPkiDn(pkiDn: string): CurrentUserProfile[] {
        var queryString: string = "getUserByPkiDn?pkiDn=" + pkiDn;
        return this.get(queryString).then((result) => {
            return result;
        });
    }

    public saveUserProfileData(userProfile: UserProfile): UserProfile {
        return this.post("saveUserData", userProfile).then((result) => {
            return result;
        });
    }

    public saveUserProfilePermissions(userProfile: UserProfile): UserProfile {
        return this.post("saveUserPermissions", userProfile).then((result) => {
            return result;
        });
    }

    public saveUserProfileRoles(userProfile: UserProfile): UserProfile {
        return this.post("saveUserRoles", userProfile).then((result) => {
            return result;
        });
    }

    public setCurrentProfile(id: string): CurrentUserProfile {
        return this.post("setCurrentProfile", id).then((result) => {
            return result;
        });
    }

    public getAllSites() {
        return this.get("getSites");
    }
}