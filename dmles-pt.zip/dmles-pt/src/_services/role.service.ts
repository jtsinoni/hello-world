'use strict';

import {ApiService} from '../_services/api.service';
import {Permission} from "../_models/permission.model";
import {PermissionDetailed} from "../_models/permissionDetailed.model";
import {PermElement} from "../_models/permElement.model";
import {PermEndpoint} from "../_models/permEndpoint.model";
import {PermState} from "../_models/permState.model";
import {Role} from "../_models/role.model";

export interface IRoleService {

}

export class RoleService extends ApiService implements IRoleService {
    public roleServiceName: string = "Role Service";

    //@inject;
    constructor($http, $log, Authentication, $httpParamSerializerJQLike) {
        super($http, $log, Authentication, $httpParamSerializerJQLike, "Role");
        this.$log.debug("%s - Start", this.roleServiceName);
    }

    /************************************************
     //
     // Functions used for Role amd User Management
     //
     *************************************************/
    public createRole(role: Role) {
        return this.post("createRole", role).then((result) => {
            return result;
        });
    }

    public deleteRole(roleId: string) {
        return this.post("deleteRole", roleId).then((result) => {
            return result;
        });
    }

    // uses permission model - without elements, states and endpoints - used to build lists for
    // User and Role Management purposes
    public getAllPermissions(): Permission[] {
        return this.get("getAllPermissions");
    }

    public getAllRoles() {
        return this.get("getAllRoles");
    }

    public saveRoleData(role: Role) {
        return this.post("saveRoleData", role).then((result) => {
            return result;
        });
    }

    public saveRolePermissions(role: Role) {
        return this.post("saveRolePermissions", role).then((result) => {
            return result;
        });
    }

    /************************************************
     //
     // Functions used for Permission Management
     //
     *************************************************/
    public createPermissionDetailed(permission: PermissionDetailed) {
        return this.post("createPermissionDetailed", permission).then((result) => {
            return result;
        });
    }

    public deletePermissionDetailed(permission: PermissionDetailed) {
        return this.post("deletePermissionDetailed", permission).then((result) => {
            return result;
        });
    }

    public getAllElements(): PermElement[] {
        return this.get("getAllElements");
    }

    public getAllEndpoints(): PermEndpoint[] {
        return this.get("getAllEndpoints");
    }

    // uses permissionDetailed model - includes elements, states and endpoints - used to access 
    // Permissions for CRUD by Permission Management
    public getAllPermissionsDetailed(): PermissionDetailed[] {
        return this.get("getAllPermissionsDetailed");
    }

    public getAllStates(): PermState[] {
        return this.get("getAllStates");
    }

    public savePermissionData(permission: PermissionDetailed) {
        return this.post("savePermissionDetailed", permission).then((result) => {
            return result;
        });
    }

    public savePermissionElements(permission: PermissionDetailed) {
        return this.post("savePermissionElements", permission).then((result) => {
            return result;
        });
    }

    public savePermissionEndpoints(permission: PermissionDetailed) {
        return this.post("savePermissionEndpoints", permission).then((result) => {
            return result;
        });
    }

    public savePermissionStates(permission: PermissionDetailed) {
        return this.post("savePermissionStates", permission).then((result) => {
            return result;
        });
    }
}