var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", '../_services/api.service'], function (require, exports, api_service_1) {
    'use strict';
    var UserProfileService = (function (_super) {
        __extends(UserProfileService, _super);
        //@inject;
        function UserProfileService($http, $log, Authentication, $httpParamSerializerJQLike) {
            _super.call(this, $http, $log, Authentication, $httpParamSerializerJQLike, "User");
            this.userProfileServiceName = "User Profile Service";
            this.$log.debug("%s - Start", this.userProfileServiceName);
        }
        UserProfileService.prototype.approveUserProfile = function (userProfile) {
            return this.post("approveUserProfile", userProfile).then(function (result) {
                return result;
            });
        };
        UserProfileService.prototype.checkUserEmail = function (checkEmail) {
            return this.get("checkUserEmail?email=" + checkEmail);
        };
        UserProfileService.prototype.deleteUserProfileRegistration = function (userProfile) {
            return this.post("deleteUserProfileRegistration", userProfile).then(function (result) {
                return result;
            });
        };
        UserProfileService.prototype.denyUserProfile = function (userProfile) {
            return this.post("denyUserProfile", userProfile).then(function (result) {
                return result;
            });
        };
        UserProfileService.prototype.getActiveUserProfiles = function () {
            return this.get("getActiveUserProfiles");
        };
        UserProfileService.prototype.getAllUserProfiles = function () {
            return this.get("getAllUserProfiles");
        };
        UserProfileService.prototype.getApprovedUserProfiles = function () {
            return this.get("getApprovedUserProfiles");
        };
        UserProfileService.prototype.getCurrentProfile = function () {
            return this.get("getCurrentProfile");
        };
        UserProfileService.prototype.getPendingUserProfiles = function () {
            return this.get("getPendingUserProfiles");
        };
        UserProfileService.prototype.getTotalPendingUserProfiles = function () {
            var pendingUserProfiles = this.get("getPendingUserProfiles");
            return pendingUserProfiles.length;
        };
        UserProfileService.prototype.getUserProfileById = function (id) {
            return this.get("getUserProfileById?id=" + id);
        };
        UserProfileService.prototype.getUserByPkiDn = function (pkiDn) {
            var queryString = "getUserByPkiDn?pkiDn=" + pkiDn;
            return this.get(queryString).then(function (result) {
                return result;
            });
        };
        UserProfileService.prototype.saveUserProfileData = function (userProfile) {
            return this.post("saveUserData", userProfile).then(function (result) {
                return result;
            });
        };
        UserProfileService.prototype.saveUserProfilePermissions = function (userProfile) {
            return this.post("saveUserPermissions", userProfile).then(function (result) {
                return result;
            });
        };
        UserProfileService.prototype.saveUserProfileRoles = function (userProfile) {
            return this.post("saveUserRoles", userProfile).then(function (result) {
                return result;
            });
        };
        UserProfileService.prototype.setCurrentProfile = function (id) {
            return this.post("setCurrentProfile", id).then(function (result) {
                return result;
            });
        };
        UserProfileService.prototype.getAllSites = function () {
            return this.get("getSites");
        };
        return UserProfileService;
    }(api_service_1.ApiService));
    exports.UserProfileService = UserProfileService;
});
//# sourceMappingURL=userProfile.service.js.map