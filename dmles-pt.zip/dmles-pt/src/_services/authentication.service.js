define(["require", "exports", "../_constants/api.constants", "../_constants/state.constants"], function (require, exports, api_constants_1, state_constants_1) {
    'use strict';
    var AuthenticationService = (function () {
        //@inject
        function AuthenticationService($log, $state, LocalStorageService) {
            this.$log = $log;
            this.$state = $state;
            this.LocalStorageService = LocalStorageService;
            this.serviceName = "Authentication Service";
            this.$log.debug('%s - Start', this.serviceName);
        }
        AuthenticationService.prototype.getToken = function () {
            return this.LocalStorageService.getData(api_constants_1.ApiConstants.DMLES_TOKEN);
        };
        AuthenticationService.prototype.isLoggedIn = function () {
            return !!this.getToken();
        };
        AuthenticationService.prototype.logout = function () {
            this.LocalStorageService.removeData(api_constants_1.ApiConstants.DMLES_TOKEN);
            this.LocalStorageService.clearData();
        };
        AuthenticationService.prototype.saveToken = function (token) {
            this.LocalStorageService.storeData(api_constants_1.ApiConstants.DMLES_TOKEN, token, false);
        };
        AuthenticationService.prototype.verifyLogin = function () {
            if (!this.isLoggedIn()) {
                this.$state.go(state_constants_1.StateConstants.LOGIN);
            }
        };
        return AuthenticationService;
    }());
    exports.AuthenticationService = AuthenticationService;
});
//# sourceMappingURL=authentication.service.js.map