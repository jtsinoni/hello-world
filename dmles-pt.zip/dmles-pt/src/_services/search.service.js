define(["require", "exports"], function (require, exports) {
    'use strict';
    var SearchService = (function () {
        //@inject
        function SearchService() {
        }
        SearchService.prototype.getSearchData = function (result) {
            var retVal = {};
            if (result && result.data.hits.hits) {
                retVal = result.data.hits.hits;
            }
            else {
            }
            return retVal;
        };
        ;
        SearchService.prototype.getSearchStats = function (result) {
            var retVal = {
                "total": 0,
                "time": 0.00
            };
            if (result && result.data && result.data.hits) {
                if (result.data.hits.total) {
                    retVal.total = result.data.hits.total;
                }
                if (result.data.took) {
                    retVal.time = result.data.took;
                }
            }
            else {
            }
            return retVal;
        };
        ;
        return SearchService;
    }());
    exports.SearchService = SearchService;
});
//# sourceMappingURL=search.service.js.map