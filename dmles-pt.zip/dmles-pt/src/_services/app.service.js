define(["require", "exports"], function (require, exports) {
    'use strict';
    var AppService = (function () {
        //@inject
        function AppService($http, $log, AppConfig) {
            this.$http = $http;
            this.$log = $log;
            this.AppConfig = AppConfig;
            this.serviceName = "App Service";
        }
        AppService.prototype.getBtBaseUrl = function () {
            return this.btBaseUrl;
        };
        AppService.prototype.setConfigs = function () {
            if (this.AppConfig.apiHosts.btBaseUrl) {
                this.btBaseUrl = this.AppConfig.apiHosts.btBaseUrl;
                this.$log.debug("%s - btBaseUrl loaded: %s", this.serviceName, this.btBaseUrl);
            }
            else {
                this.$log.error("%s - Error: Unable to load btBaseUrl", this.serviceName);
            }
        };
        return AppService;
    }());
    exports.AppService = AppService;
});
//# sourceMappingURL=app.service.js.map