var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
define(["require", "exports", "./api.service"], function (require, exports, api_service_1) {
    'use strict';
    var SystemService = (function (_super) {
        __extends(SystemService, _super);
        //@inject
        function SystemService($http, $log, Authentication, App, $httpParamSerializerJQLike, $filter) {
            _super.call(this, $http, $log, Authentication, App, $httpParamSerializerJQLike, "System");
            this.$filter = $filter;
            this.serviceName = "System Service";
            this.serviceRegionSiteHierarchicalData = null;
            this.services = [];
            this.regions = [];
            this.sites = [];
            this.$log.debug("%s - Start", this.serviceName);
        }
        // this actually now returns service, regions and site in hierarchical structure
        SystemService.prototype.getServices = function () {
            return this.get("getServices");
        };
        // parse the response from getServices into services, regions, sites
        SystemService.prototype.buildServicesRegionsSites = function () {
            var _this = this;
            this.getServices().then(function (response) {
                // this.$log.debug("MainNav Returned: %s", JSON.stringify(response.data));
                // this response now includes services, regions within service and dodaacs within regions
                _this.serviceRegionSiteHierarchicalData = response.data;
                var i = 0;
                var j = 0;
                var k = 0;
                var s;
                for (s in _this.serviceRegionSiteHierarchicalData) {
                    var service = _this.serviceRegionSiteHierarchicalData[s];
                    _this.services[i++] = service;
                    var r;
                    for (r in service.regions) {
                        var region = service.regions[r];
                        _this.regions[j] = region;
                        var t;
                        for (t in region.sites) {
                            var site = region.sites[t];
                            _this.sites[k] = site;
                            _this.sites[k].regionCode = region.code;
                            _this.sites[k].regionName = region.name;
                            _this.sites[k].serviceCode = service.code;
                            _this.sites[k].serviceName = service.name;
                            k++;
                        }
                        _this.regions[j].serviceCode = service.code;
                        _this.regions[j].serviceName = service.name;
                        j++;
                        delete _this.regions[r].sites;
                    }
                    delete _this.services[s].regions;
                }
                // this.$log.debug("this.services: %s", JSON.stringify(this.services));
                // this.$log.debug("this.regions: %s", JSON.stringify(this.regions));
                // this.$log.debug("this.sites: %s", JSON.stringify(this.sites));
            }, function (errResponse) {
                _this.$log.error("%s - Error retrieving hierarchical data that contains services, regions and sites", _this.serviceName);
            });
        };
        SystemService.prototype.lookupServiceGivenServiceCode = function (serviceCode) {
            var filteredService = this.$filter('filter')(this.services, { "code": serviceCode }, true);
            return filteredService[0];
        };
        SystemService.prototype.lookupSiteGivenSiteDodaac = function (dodaac) {
            var filteredSite = this.$filter('filter')(this.sites, { "dodaac": dodaac }, true);
            return filteredSite[0];
        };
        return SystemService;
    }(api_service_1.ApiService));
    exports.SystemService = SystemService;
});
//# sourceMappingURL=system.service.js.map