'use strict';
import {ApiService} from "./api.service";

export interface ISiteService {

}

export class SiteService extends ApiService implements ISiteService {
    private siteServiceName:string = "Site Service";

    //@inject
    constructor($http, $log, Authentication, $httpParamSerializerJQLike) {
        super($http, $log, Authentication, $httpParamSerializerJQLike, "Site");
        this.$log.debug("%s - Start", this.siteServiceName);
    }   

    public getSites() {
        return this.get("getSitesAll");
    }

    public getSitesByRegion(region) {
        var query:string =  "getSitesByRegion?region=" + region;
        return this.get(query);
    }

    public getSitesByService(serviceID) {
        var query:string =  "getSitesByService?serviceID=" + serviceID;
        return this.get(query);
    }

    public getSiteOrgsByDodaac(siteDodaac) {
        var query:string =  "getSiteOrgsByDodaac?siteDodaac=" + siteDodaac;
        return this.get(query);
    }
}