'use strict';

import {ApiService} from '../_services/api.service';
import {CurrentUserProfile} from "../_models/currentUserProfile.model";

export interface IUserService {

}

export class UserService extends ApiService implements IUserService {
    public currentUser: CurrentUserProfile;
    public userServiceName: string = "User Service";

    //@inject;
    constructor($http, $log, Authentication, App, $httpParamSerializerJQLike, 
                private $q, private $rootScope, private ContentConstants) {
        
        super($http, $log, Authentication, App, $httpParamSerializerJQLike, "User");
        this.$log.debug("%s - Start", this.userServiceName);
    }

    /*
     Gets the current user either from cache or DB, and loads it into the
     model, for use by other services, directives and controllers.

     Called by the dmlesApp.run $rootScope.$on('$stateChangeStart') ....
     */
    public loadCurrentUser() {
        if (this.currentUser) {
            var deferred = this.$q.defer();
            deferred.resolve(this.currentUser);
            return deferred.promise;
        } else {
            return this.signIn().then((result: CurrentUserProfile) => {
                var user = result;
                //this.$log.debug("%s - loadCurrentUser - Current User: %s", this.userServiceName, JSON.stringify(user));
                this.$log.debug("%s - User Profile Loaded");
                this.setCurrentUser(user);
                return this.currentUser;
            });
        }
    }

    public signIn() {
        return this.get("signIn").then((result: any) => {
            var user = result.data;
            //this.$log.debug("%s - signIn - Current User: %s", this.userServiceName, JSON.stringify(user));
            this.setCurrentUser(user);
            return this.currentUser;
        });
    }

    public setCurrentUser(currentUserProfile: CurrentUserProfile) {      

        this.currentUser = new CurrentUserProfile(angular.copy(currentUserProfile));

        var data = {
            "user": this.currentUser
        };

        //this.$log.debug("setCurrentUser - this.currentUser: %s", JSON.stringify(this.currentUser));

        // Note: Broadcast used to hit banner items, such as User Profile, currently
        // TODO: This shouldn't be needed, remove eventually...
        this.$rootScope.$broadcast(this.ContentConstants.EVENT_USER_UPDATE, data);
    }
}