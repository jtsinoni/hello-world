define(["require", "exports"], function (require, exports) {
    "use strict";
    function dmlesTrueFalseFilter() {
        return function (input) {
            var retVal = "Yes";
            if (input === null || input === "") {
                retVal = "Unknown";
            }
            else if (input === false) {
                retVal = "No";
            }
            return retVal;
        };
    }
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = dmlesTrueFalseFilter;
});
//# sourceMappingURL=dmlesTrueFalse.filter.js.map