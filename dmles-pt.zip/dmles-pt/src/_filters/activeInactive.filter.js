define(["require", "exports"], function (require, exports) {
    'use strict';
    /**
     Converts a boolean value into Active or Inactive
     Expected Usage: {{ true | false }} | activeInactiveFilter
    
     @param input - boolean value
     @returns - string Active or Inactive
     */
    function activeInactiveFilter() {
        return (function (input) {
            return input ? 'Active' : 'Inactive';
        });
    }
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = activeInactiveFilter;
});
//# sourceMappingURL=activeInactive.filter.js.map