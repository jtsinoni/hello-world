define(["require", "exports", './activeInactive.filter', './dmlesDate.filter', './dmlesDateTime.filter', './dmlesService.filter', './dmlesTitleCase.filter', './dmlesTrueFalse.filter'], function (require, exports, activeInactive_filter_1, dmlesDate_filter_1, dmlesDateTime_filter_1, dmlesService_filter_1, dmlesTitleCase_filter_1, dmlesTrueFalse_filter_1) {
    "use strict";
    var filtersModule = angular.module('Dmles.FiltersModule', []);
    filtersModule.filter('activeInactiveFilter', activeInactive_filter_1.default);
    filtersModule.filter('dmlesDateFilter', dmlesDate_filter_1.default);
    filtersModule.filter('dmlesDateTimeFilter', dmlesDateTime_filter_1.default);
    filtersModule.filter('dmlesServiceFilter', dmlesService_filter_1.default);
    filtersModule.filter('dmlesTitleCaseFilter', dmlesTitleCase_filter_1.default);
    filtersModule.filter('dmlesTrueFalseFilter', dmlesTrueFalse_filter_1.default);
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = filtersModule;
});
//# sourceMappingURL=module.js.map