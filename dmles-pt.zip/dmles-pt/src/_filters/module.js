define(["require", "exports", './dmlesTitleCase.filter'], function (require, exports, dmlesTitleCase_filter_1) {
    'use strict';
    var filtersModule = angular.module('Dmles.FiltersModule', []);
    filtersModule.filter('dmlesTitleCaseFilter', dmlesTitleCase_filter_1.default);
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = filtersModule;
});
//# sourceMappingURL=module.js.map