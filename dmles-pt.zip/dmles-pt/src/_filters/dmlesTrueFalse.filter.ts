export default function dmlesTrueFalseFilter() {

    return function(input)
    {
        var retVal:string = "Yes";
        if(input === null || input === ""){
            retVal = "Unknown";
        } else if(input === false){
            retVal = "No";
        }
        return retVal;
    };

}