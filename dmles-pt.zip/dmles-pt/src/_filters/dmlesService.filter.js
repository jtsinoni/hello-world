define(["require", "exports"], function (require, exports) {
    "use strict";
    function dmlesServiceFilter() {
        return function (input) {
            var retVal = "";
            if (input === null || input === "") {
                retVal = "Unknown";
            }
            else if (input === "DA") {
                retVal = "Army";
            }
            else if (input === "DHA") {
                retVal = "Defense Health Agency";
            }
            else if (input === "DF") {
                retVal = "Air Force";
            }
            else if (input === "DN" || input === "NV") {
                retVal = "Navy";
            }
            else if (input === "DM") {
                retVal = "Marine Corps";
            }
            else if (input === "VA") {
                retVal = "Veterans Administration";
            }
            else {
                retVal = "Other";
            }
            return retVal;
        };
    }
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = dmlesServiceFilter;
});
//# sourceMappingURL=dmlesService.filter.js.map