import ActiveInactiveFilter from './activeInactive.filter';
import DateFilter from './dmlesDate.filter';
import DateTimeFilter from './dmlesDateTime.filter';
import dmlesServiceFilter from './dmlesService.filter';
import dmlesTitleCaseFilter from './dmlesTitleCase.filter';
import dmlesTrueFalseFilter from './dmlesTrueFalse.filter';

var filtersModule = angular.module('Dmles.FiltersModule', []);
filtersModule.filter('activeInactiveFilter', ActiveInactiveFilter);
filtersModule.filter('dmlesDateFilter', DateFilter);
filtersModule.filter('dmlesDateTimeFilter', DateTimeFilter);
filtersModule.filter('dmlesServiceFilter', dmlesServiceFilter);
filtersModule.filter('dmlesTitleCaseFilter', dmlesTitleCaseFilter);
filtersModule.filter('dmlesTrueFalseFilter', dmlesTrueFalseFilter);

export default filtersModule;