'use strict';

import dmlesTitleCaseFilter from './dmlesTitleCase.filter';

let filtersModule = angular.module('Dmles.FiltersModule', []);
filtersModule.filter('dmlesTitleCaseFilter', dmlesTitleCaseFilter);

export default filtersModule;