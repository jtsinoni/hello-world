/// <reference path="../typings/index.d.ts" />

'use strict';

import * as angular from 'angular';

import "bootstrap";
import "angular-animate";
import "angular-cookies";
import "angular-file-upload";
import "angular-growl-v2";
import "angular-messages";
import "angular-mocks";
import "angular-sanitize";
import "angular-ui-bootstrap";
import "angular-ui-router";
import "angular-utils-ui-breadcrumbs";
import "dangrossman/bootstrap-daterangepicker";
import "danielcrisp/angular-rangeslider";
import "isteven/angular-multi-select";
import "jtrussell/angular-selection-model";
import "angular-moment";
import "ng-csv";
//import "esvit/ng-table";
import "ng-table";
import "pscarbrough2/angular-daterangepicker";

import router from './router';
import {AppService} from "./_services/app.service";
import {AuthenticationService} from "./_services/authentication.service";
import {AppConfig} from "./configs/appConfig";
import {ShellController} from './shell.controller';
import {StateConstants} from "./_constants/state.constants";
import {UserService} from "./_services/user.service";
import {SidePanelService} from "./_services/sidepanel.service";
import {PermissionService} from "./_services/permission.service";
import {NotificationService} from "./_services/notification.service";

import servicesModule from './_services/module';
import constantsModule from './_constants/module';
import directivesModule from './_directives/module';
import commonModule from './_common/module';
import filtersModule from './_filters/module';

var module = angular.module('DmlesModule', [
    'angularFileUpload',
    'angular-growl',
    'daterangepicker',
    'isteven-multi-select',
    'angularMoment',
    'ngAnimate',
    'ngCookies',
    'ngCsv',
    'ngMessages',
    'ngSanitize',
    'ngTable',
    'selectionModel',
    'ui.bootstrap',
    'ui.router',
    'ui-rangeSlider',
    'angularUtils.directives.uiBreadcrumbs',
    constantsModule.name,
    servicesModule.name,
    directivesModule.name,
    commonModule.name,
    filtersModule.name
]);

module.service('AppConfig', AppConfig);
module.config(router.factory);

module.config(['growlProvider', function (growlProvider) {
    growlProvider.globalTimeToLive({success: 5000, error: 10000, warning: 5000, info: 5000});
    growlProvider.globalPosition('bottom-center');
}]);

module.controller('Dmles.ShellController', ShellController);

module.run(["$log", "$rootScope", "$state", "App", "Authentication", "NotificationService", "PermissionService", "SidePanelService", "UserService", "StateConstants",
    ($log, $rootScope, $state, App, Authentication, NotificationService, PermissionService, SidePanelService, UserService, StateConstants) => {
        $log.debug("App Module - Running");
        App.setConfigs();

        $rootScope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {

            $rootScope.previousState = fromState.name;
            $rootScope.currentState = toState.name;

            // TODO: Update to include states or route checks per role.
            // Ref: http://stackoverflow.com/questions/22537311/angular-ui-router-login-authentication
            if ($rootScope.stateChangeBypass ||
                toState.name === StateConstants.LOGIN ||
                toState.name === StateConstants.REGISTER ||
                toState.name === StateConstants.REGISTER_CONFIRM ||
                toState.name === StateConstants.SECURITY) {
                $rootScope.stateChangeBypass = false;
                return;
            }

            event.preventDefault();

            if (Authentication.isLoggedIn()) {

                UserService.loadCurrentUser().then(function (user) {
                    if (user) {
                        $rootScope.stateChangeBypass = true;
                        //$log.debug("module.run: toState %s, toParams %s", JSON.stringify(toState), JSON.stringify(toParams));
                        //$log.debug("module.run: fromState %s, fromParams %s", JSON.stringify(fromState), JSON.stringify(fromParams));
                        if (PermissionService.checkStates(toState.name)) {
                            $state.go(toState, toParams);
                            SidePanelService.checkForPanelButton(toState);
                            //MainNavService.activateMainNav(toState);
                        } else {
                            // stay where we are at, display warning msg, and make sure we check state change next time
                            $log.debug("User is not allowed to switch to state: %s", toState.name);
                            NotificationService.warningMsg("Permission to this page has not be granted");
                            $rootScope.stateChangeBypass = false;
                        }
                    } else {
                        $state.go(StateConstants.LOGIN);
                    }
                });

            } else {
                $state.go(StateConstants.LOGIN);
            }

        });

    }]);

const App: ng.IAngularStatic = angular;

export {App}