'use strict';

// features
import directivesModule from './_directives/module';
import filtersModule from './_filters/module';
import servicesModule from './_services/module';

var commonModule = angular.module('Dmles.Common.Module', [
    directivesModule.name,
    filtersModule.name,
    servicesModule.name
]);

export default commonModule;