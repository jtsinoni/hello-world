define(["require", "exports"], function (require, exports) {
    'use strict';
    /**
     * Simple solution, works for IE10+.
     * More may be needed here.
     * Alternative if IE10+ is an issue:
     * Reference: https://developer.mozilla.org/en-US/docs/Web/API/WindowBase64/Base64_encoding_and_decoding
     */
    var Base64Service = (function () {
        // @ngInject
        function Base64Service() {
        }
        /**
         * Creates a base-64 encoded ASCII string from a "string" of binary data.
         * @param str
         * @returns {string}
         */
        Base64Service.prototype.b64EncodeUnicode = function (str) {
            return btoa(str.trim());
        };
        /**
         * Decodes a string of data which has been encoded using base-64 encoding.
         * @param str
         * @returns {string}
         */
        Base64Service.prototype.b64DecodeUnicode = function (str) {
            return atob(str);
        };
        return Base64Service;
    }());
    exports.Base64Service = Base64Service;
});
//# sourceMappingURL=base64.service.js.map