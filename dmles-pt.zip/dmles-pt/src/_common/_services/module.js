define(["require", "exports", './base64.service', './baseSelectFilter.service', './util.service'], function (require, exports, base64_service_1, baseSelectFilter_service_1, util_service_1) {
    'use strict';
    var servicesModule = angular.module('Dmles.Common.Services.ServicesModule', []);
    servicesModule.service('Base64Service', base64_service_1.Base64Service);
    servicesModule.service('BaseSelectFilterService', baseSelectFilter_service_1.BaseSelectFilterService);
    servicesModule.service('UtilService', util_service_1.UtilService);
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = servicesModule;
});
//# sourceMappingURL=module.js.map