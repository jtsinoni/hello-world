define(["require", "exports"], function (require, exports) {
    'use strict';
    var UtilService = (function () {
        function UtilService($anchorScroll, $filter, $location, ContentConstants) {
            this.$anchorScroll = $anchorScroll;
            this.$filter = $filter;
            this.$location = $location;
            this.ContentConstants = ContentConstants;
        }
        UtilService.prototype.addZero = function (i) {
            if (i < 10) {
                i = "0" + i;
            }
            return i;
        };
        UtilService.prototype.convertCamelCaseToText = function (camelCaseText) {
            var result = camelCaseText.replace(/([A-Z])/g, " $1");
            return result.charAt(0).toUpperCase() + result.slice(1);
        };
        UtilService.prototype.convertTextToCamelCase = function (text) {
            return text
                .replace(/\s(.)/g, function ($1) {
                return $1.toUpperCase();
            })
                .replace(/\s/g, '')
                .replace(/^(.)/, function ($1) {
                return $1.toLowerCase();
            });
        };
        UtilService.prototype.convertCurrencyToFloat = function (currency) {
            if (!currency) {
                currency = "$0.00";
            }
            return Number(currency.replace(/[^0-9\.]+/g, ""));
        };
        UtilService.prototype.convertFloatToCurrency = function (amount) {
            if (!amount) {
                amount = 0;
            }
            var currency = this.$filter('currency')(amount);
            return currency;
        };
        UtilService.prototype.esBuildSearchStatsStr = function (numResults, time) {
            var searchStatsStr = numResults + " items found ( " + time + " milliseconds )";
            return searchStatsStr;
        };
        /**
         * Escape special characters that might be embedded in the user-input search string(s)
         * not doing this causes issues for elasticsearch
         */
        UtilService.prototype.esEscapeSpecialChars = function (searchInput) {
            var escapedInput = searchInput.replace(/[!@#$%^&()+=\-[\]\\';,./{}|":<>?~_]/g, "\\$&");
            return escapedInput;
        };
        UtilService.prototype.getDateInMillis = function () {
            var d = new Date();
            return d.getTime();
        };
        UtilService.prototype.getDate = function (d) {
            var yr = d.getFullYear();
            var mn = this.addZero(d.getMonth());
            var dy = this.addZero(d.getDay());
            return yr + "-" + mn + "-" + dy;
        };
        UtilService.prototype.getDateTime = function (dateVar) {
            var d = new Date();
            if (dateVar) {
                d = dateVar;
            }
            var nowDateStr = this.getDate(d);
            var nowTimeStr = this.getTime(d);
            var currFullStr = nowDateStr + " " + nowTimeStr;
            return currFullStr;
        };
        UtilService.prototype.getTime = function (d) {
            var h = this.addZero(d.getHours());
            var m = this.addZero(d.getMinutes());
            var s = this.addZero(d.getSeconds());
            var ms = d.getMilliseconds();
            return h + ":" + m + ":" + s + "." + ms;
        };
        UtilService.prototype.getYears = function (numOfYears) {
            var currDate = new Date();
            var years = [];
            for (var i = 0; i < numOfYears; i++) {
                years.push(currDate.getFullYear() + i);
            }
            return years;
        };
        UtilService.prototype.isStringFound = function (searchFor, searchWithin) {
            var isFound = false;
            if (searchWithin.indexOf(searchFor) > -1) {
                isFound = true;
            }
            return isFound;
        };
        UtilService.prototype.isObjectEmpty = function (obj) {
            var isEmpty = false;
            if (angular.equals({}, obj) || null == obj || "" == obj) {
                isEmpty = true;
            }
            return isEmpty;
        };
        UtilService.prototype.isInt = function (value) {
            var x = parseFloat(value);
            return !isNaN(value) && (x | 0) === x;
        };
        UtilService.prototype.replaceDoubleQuotesWithSlash = function (stringVar) {
            return stringVar.toString().replace(/"/g, '\\"');
        };
        /* Combines a list of json or JavaScript objects with a list of selected
         * objects from the original list, then, adds a selected
         * field to each object if the coparison field matches.
         *
         * Returns a list of JavaScript objects with the selected field where
         * the comparison is true.
         */
        UtilService.prototype.selectionListCreation = function (argFullList, argSelectionList, compareField) {
            var _this = this;
            var fullList = angular.copy(argFullList);
            var selectionList = angular.copy(argSelectionList);
            var comboList = [];
            angular.forEach(fullList, function (f_value, f_key) {
                //console.log(f_key + " : " + f_value);
                var listObj = f_value;
                listObj.selected = null;
                angular.forEach(selectionList, function (s_value, s_key) {
                    // JavaScript objects are associative arrays, which makes this possible
                    // Similar to dot notation, ex: listObj.name
                    var compareListItem = listObj[compareField];
                    var compareSelItem = s_value[compareField];
                    if (compareListItem === compareSelItem) {
                        listObj.selected = _this.ContentConstants.SELECTED; // Adds selected value
                    }
                });
                comboList.push(listObj);
            });
            return comboList;
        };
        /* Returns a list of all selected JavaScript objects from the selection
         * list created from the selectionListCreation function.
         */
        UtilService.prototype.selectionListGetSelected = function (argComboList) {
            var _this = this;
            var comboList = angular.copy(argComboList);
            var selectedList = [];
            angular.forEach(comboList, function (value, key) {
                if (value.selected === _this.ContentConstants.SELECTED) {
                    selectedList.push(value);
                }
            });
            return selectedList;
        };
        /* Updates the selection list from selected or not.  This works with a
         * standard table or list, but will not update a ng-table.
         */
        UtilService.prototype.selectionListUpdate = function (selectionList, newItem, compareField) {
            var _this = this;
            angular.forEach(selectionList, function (value, key) {
                if (value.name === newItem[compareField]) {
                    if (value.selected) {
                        value.selected = null;
                    }
                    else {
                        value.selected = _this.ContentConstants.SELECTED;
                    }
                }
            });
        };
        UtilService.prototype.sortByName = function (arrayOfObjects, nameToCompare) {
            if (arrayOfObjects && arrayOfObjects.length > 0 && nameToCompare) {
                return arrayOfObjects.sort(function (a, b) {
                    var lowerA = a[nameToCompare].toLocaleLowerCase();
                    var lowerB = b[nameToCompare].toLocaleLowerCase();
                    if (lowerA < lowerB)
                        return -1;
                    else if (lowerA > lowerB)
                        return 1;
                    else
                        return 0;
                });
            }
            else {
                return arrayOfObjects;
            }
        };
        UtilService.prototype.sortResults = function (jList, prop, isAsc) {
            var jListSorted = jList.sort(function (a, b) {
                if (isAsc)
                    return (a[prop] > b[prop]) ? 1 : ((a[prop] < b[prop]) ? -1 : 0);
                else
                    return (b[prop] > a[prop]) ? 1 : ((b[prop] < a[prop]) ? -1 : 0);
            });
            return jListSorted;
        };
        UtilService.prototype.validateEmail = function (email) {
            var re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            return re.test(email);
        };
        UtilService.$inject = ['$anchorScroll', '$filter', '$location', 'ContentConstants'];
        return UtilService;
    }());
    exports.UtilService = UtilService;
});
//# sourceMappingURL=util.service.js.map