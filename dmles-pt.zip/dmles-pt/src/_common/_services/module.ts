'use strict';

import {Base64Service} from './base64.service';
import {BaseSelectFilterService} from './baseSelectFilter.service';
import {UtilService} from './util.service';

var servicesModule = angular.module('Dmles.Common.Services.ServicesModule', []);
servicesModule.service('Base64Service', Base64Service);
servicesModule.service('BaseSelectFilterService', BaseSelectFilterService);
servicesModule.service('UtilService', UtilService);

export default servicesModule;