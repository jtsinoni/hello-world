'use strict';

export class UtilService {

    public static $inject = ['$anchorScroll', '$filter', '$location', 'ContentConstants'];

    constructor(private $anchorScroll, private $filter, private $location, private ContentConstants) {
    }

    public addZero(i) {
        if (i < 10) {
            i = "0" + i;
        }
        return i;
    };

    public convertCamelCaseToText(camelCaseText) {
        var result = camelCaseText.replace(/([A-Z])/g, " $1");
        return result.charAt(0).toUpperCase() + result.slice(1);
    };

    public convertTextToCamelCase(text) {
        return text
            .replace(/\s(.)/g, ($1) => {
                return $1.toUpperCase();
            })
            .replace(/\s/g, '')
            .replace(/^(.)/, ($1) => {
                return $1.toLowerCase();
            });
    };

    public convertCurrencyToFloat(currency) {
        if (!currency) {
            currency = "$0.00";
        }
        return Number(currency.replace(/[^0-9\.]+/g, ""));
    };

    public convertFloatToCurrency(amount) {
        if (!amount) {
            amount = 0;
        }
        var currency = this.$filter('currency')(amount);
        return currency;
    };

    public esBuildSearchStatsStr(numResults:string, time:string){
        var searchStatsStr:string = numResults + " items found ( " + time + " milliseconds )";
        return searchStatsStr;
    }

    /**
     * Escape special characters that might be embedded in the user-input search string(s)
     * not doing this causes issues for elasticsearch
     */
    public esEscapeSpecialChars(searchInput:string) {
        var escapedInput:string = searchInput.replace(/[!@#$%^&()+=\-[\]\\';,./{}|":<>?~_]/g, "\\$&");
        return escapedInput;
    }

    public getDateInMillis() {
        var d = new Date();
        return d.getTime();
    };

    public getDate(d) {
        var yr = d.getFullYear();
        var mn = this.addZero(d.getMonth());
        var dy = this.addZero(d.getDay());
        return yr + "-" + mn + "-" + dy;
    };

    public getDateTime(dateVar) {
        var d = new Date();
        if (dateVar) {
            d = dateVar;
        }
        var nowDateStr = this.getDate(d);
        var nowTimeStr = this.getTime(d);
        var currFullStr = nowDateStr + " " + nowTimeStr;
        return currFullStr;
    };

    public getTime(d) {
        var h = this.addZero(d.getHours());
        var m = this.addZero(d.getMinutes());
        var s = this.addZero(d.getSeconds());
        var ms = d.getMilliseconds();
        return h + ":" + m + ":" + s + "." + ms;
    };

    public getYears(numOfYears) {
        var currDate = new Date();
        var years = [];
        for (var i = 0; i < numOfYears; i++) {
            years.push(currDate.getFullYear() + i);
        }
        return years;
    };

    public isStringFound(searchFor, searchWithin) {
        var isFound = false;
        if (searchWithin.indexOf(searchFor) > -1) {
            isFound = true;
        }
        return isFound;
    };

    public isInt(value) {
        var x = parseFloat(value);
        return !isNaN(value) && (x | 0) === x;
    };

    public replaceDoubleQuotesWithSlash(stringVar) {
        return stringVar.toString().replace(/"/g, '\\"');
    };

    /* Combines a list of json or JavaScript objects with a list of selected
     * objects from the original list, then, adds a selected
     * field to each object if the coparison field matches.
     *
     * Returns a list of JavaScript objects with the selected field where
     * the comparison is true.
     */
    public selectionListCreation(argFullList, argSelectionList, compareField) {
        var fullList = angular.copy(argFullList);
        var selectionList = angular.copy(argSelectionList);
        var comboList = [];

        angular.forEach(fullList, (f_value, f_key) => {
            //console.log(f_key + " : " + f_value);
            var listObj:any = f_value;
            listObj.selected = null;

            angular.forEach(selectionList, (s_value, s_key) => {
                // JavaScript objects are associative arrays, which makes this possible
                // Similar to dot notation, ex: listObj.name
                var compareListItem = listObj[compareField];
                var compareSelItem = s_value[compareField];
                if (compareListItem === compareSelItem) {
                    listObj.selected = this.ContentConstants.SELECTED;  // Adds selected value
                }
            });

            comboList.push(listObj);
        });

        return comboList;
    };

    /* Returns a list of all selected JavaScript objects from the selection
     * list created from the selectionListCreation function.
     */
    public selectionListGetSelected(argComboList) {
        var comboList = angular.copy(argComboList);
        var selectedList = [];
        angular.forEach(comboList, (value, key) => {
            if (value.selected === this.ContentConstants.SELECTED) {
                selectedList.push(value);
            }
        });
        return selectedList;
    };

    /* Updates the selection list from selected or not.  This works with a
     * standard table or list, but will not update a ng-table.
     */
    public selectionListUpdate(selectionList, newItem, compareField) {
        angular.forEach(selectionList, (value:any, key) => {
            if (value.name === newItem[compareField]) {
                if (value.selected) {
                    value.selected = null;
                } else {
                    value.selected = this.ContentConstants.SELECTED;
                }
            }
        });
    };

    public sortByName(arrayOfObjects, nameToCompare) {
        if (arrayOfObjects && arrayOfObjects.length > 0 && nameToCompare) {
            return arrayOfObjects.sort((a, b) => {
                var lowerA = a[nameToCompare].toLocaleLowerCase();
                var lowerB = b[nameToCompare].toLocaleLowerCase();
                if (lowerA < lowerB)
                    return -1;
                else if (lowerA > lowerB)
                    return 1;
                else
                    return 0;
            });
        } else {
            return arrayOfObjects;
        }
    };


    public sortResults(jList, prop, isAsc) {
        var jListSorted = jList.sort((a, b) => {
            if (isAsc) return (a[prop] > b[prop]) ? 1 : ((a[prop] < b[prop]) ? -1 : 0);
            else return (b[prop] > a[prop]) ? 1 : ((b[prop] < a[prop]) ? -1 : 0);
        });
        return jListSorted;
    };


    public validateEmail(email) {
        var re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(email);
    };

}