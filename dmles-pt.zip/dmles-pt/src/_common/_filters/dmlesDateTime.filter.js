define(["require", "exports"], function (require, exports) {
    'use strict';
    /**
     To be used as an angular filter in the html file when formatting a date and time.
     Expected Usage: {{ vm.someDateAndTime }} | dmlesDateTimeFilter
    
     @param input - the date given to format, in the above example it would be vm.someDateAndTime
     @returns - the neatly formatted date and time
     */
    function dmlesDateTimeFilter($filter) {
        var angularDateFilter = $filter('date');
        return (function (input) {
            return angularDateFilter(input, 'dd MMM yyyy HH:mm:ss');
        });
    }
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = dmlesDateTimeFilter;
});
//# sourceMappingURL=dmlesDateTime.filter.js.map