define(["require", "exports", './activeInactive.filter', './dmlesDate.filter', './dmlesDateTime.filter'], function (require, exports, activeInactive_filter_1, dmlesDate_filter_1, dmlesDateTime_filter_1) {
    'use strict';
    var filtersModule = angular.module('Dmles.Common.Filters.Module', []);
    filtersModule.filter('activeInactiveFilter', activeInactive_filter_1.default);
    filtersModule.filter('dmlesDateFilter', dmlesDate_filter_1.default);
    filtersModule.filter('dmlesDateTimeFilter', dmlesDateTime_filter_1.default);
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = filtersModule;
});
//# sourceMappingURL=module.js.map