'use strict';

/**
 Converts a boolean value into Active or Inactive
 Expected Usage: {{ true | false }} | activeInactiveFilter

 @param input - boolean value
 @returns - string Active or Inactive
 */
export default function activeInactiveFilter() {
    return ((input) => {
        return input ? 'Active' : 'Inactive';
    })
}