'use strict';

import ActiveInactiveFilter from './activeInactive.filter';
import DateFilter from './dmlesDate.filter';
import DateTimeFilter from './dmlesDateTime.filter';

var filtersModule = angular.module('Dmles.Common.Filters.Module', []);
filtersModule.filter('activeInactiveFilter', ActiveInactiveFilter);
filtersModule.filter('dmlesDateFilter', DateFilter);
filtersModule.filter('dmlesDateTimeFilter', DateTimeFilter);

export default filtersModule;