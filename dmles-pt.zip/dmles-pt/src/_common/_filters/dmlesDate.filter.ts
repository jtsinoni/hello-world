'use strict';

/**
 To be used as an angular filter in the html file when formatting a date.
 Expected Usage: {{ vm.someDate }} | dmlesDateFilter

 @param input - the date given to format, in the above example it would be vm.someDate
 @returns - the neatly formatted date
 */
export default function dmlesDateFilter($filter) {
    var angularDateFilter = $filter('date');
    return ((input) => {
        return angularDateFilter(input, 'dd MMM yyyy');
    })
}