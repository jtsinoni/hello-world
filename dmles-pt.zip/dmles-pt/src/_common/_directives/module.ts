'use strict';

import CompileDirective from './compile/compile.directive';
import {DataTableOptions} from './dataGrid/dataGrid.class';
import DataGridDirective from './dataGrid/dataGrid.directive';
import SearchDirective from './searchComponents/searchInput.directive';

var directivesModule = angular.module('Dmles.Common.DirectivesModule', []);
directivesModule.directive('compile', CompileDirective);
directivesModule.value('Dmles.DataTableOptions', DataTableOptions);
directivesModule.directive('dmlesDataGrid', DataGridDirective);
directivesModule.directive('searchInput', SearchDirective);

export default directivesModule;