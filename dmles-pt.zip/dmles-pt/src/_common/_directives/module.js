define(["require", "exports", './compile/compile.directive', './dataGrid/dataGrid.class', './dataGrid/dataGrid.directive', './searchComponents/searchInput.directive'], function (require, exports, compile_directive_1, dataGrid_class_1, dataGrid_directive_1, searchInput_directive_1) {
    'use strict';
    var directivesModule = angular.module('Dmles.Common.DirectivesModule', []);
    directivesModule.directive('compile', compile_directive_1.default);
    directivesModule.value('Dmles.DataTableOptions', dataGrid_class_1.DataTableOptions);
    directivesModule.directive('dmlesDataGrid', dataGrid_directive_1.default);
    directivesModule.directive('searchInput', searchInput_directive_1.default);
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = directivesModule;
});
//# sourceMappingURL=module.js.map