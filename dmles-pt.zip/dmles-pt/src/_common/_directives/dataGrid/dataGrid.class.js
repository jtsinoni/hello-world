define(["require", "exports"], function (require, exports) {
    'use strict';
    /*
     TODO Note: dataGrid class filter not working
     */
    var DataTableOptions = (function () {
        // @ngInject
        function DataTableOptions(datatableService) {
            this.className = "DataGrid Class";
            this.isLoading = false;
            this.isSubPanel = false;
            this.noDataMessage = "No data available";
            this.numberOfRows = 5;
            this.showExportBtn = true;
            var inj = angular.injector(['ng']);
            this.$sce = inj.get('$sce');
            this.datatableService = datatableService;
        }
        Object.defineProperty(DataTableOptions.prototype, "dataList", {
            get: function () {
                return this._dataList;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DataTableOptions.prototype, "dataTable", {
            get: function () {
                return this._dataTable;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DataTableOptions.prototype, "exportFilename", {
            get: function () {
                if (this._exportFilename === undefined) {
                    return this.filename + ".csv";
                }
                return this._exportFilename;
            },
            set: function (value) {
                this._exportFilename = value;
            },
            enumerable: true,
            configurable: true
        });
        DataTableOptions.prototype.evaluatedValue = function ($scope, col, row) {
            return $scope.$eval("data." + col.field + " | " + col.valueFormatter, {
                data: row
            });
        };
        DataTableOptions.prototype.filterData = function (searchTerm) {
            this.dataTable.filter({ $: searchTerm });
        };
        // TODO: Change to pass in what to call to get data.
        // TODO: Remove bpm service, this will be taken care of in the business tier
        DataTableOptions.prototype.loadData = function (data) {
            this.isLoading = true;
            this._dataList = data;
            this._dataTable = this.datatableService.createNgTable(data, this.numberOfRows, this.defaultSort);
            this.isLoading = false;
        };
        /*
         * An empty function to be set when the DataGrid's options are declared.
         */
        DataTableOptions.prototype.linkClick = function (a, b) {
            //        console.log("In dataGrid linkClick...");
        };
        /*
         * An empty function to be set when the DataGrid's options are declared.
         */
        DataTableOptions.prototype.linkValue = function ($scope, col, row) {
        };
        DataTableOptions.prototype.permitHtml = function (htmlString) {
            return this.$sce.trustAsHtml(htmlString);
        };
        return DataTableOptions;
    }());
    exports.DataTableOptions = DataTableOptions;
});
//# sourceMappingURL=dataGrid.class.js.map