'use strict';

import IInjectorService = angular.auto.IInjectorService;

/*
 TODO Note: dataGrid class filter not working
 */
export class DataTableOptions {
    private className:string = "DataGrid Class";
    private datatableService;
    private _exportFilename:string;
    private _dataList:any;
    private _dataTable:any;
    private $sce;

    public cols:any;
    public defaultSort:any;
    public displayName:string;
    public filename:string;
    public isLoading:boolean = false;
    public isSubPanel:boolean = false;
    public noDataMessage:string = "No data available";
    public numberOfRows:number = 5;
    public showExportBtn:boolean = true;

    // @ngInject
    constructor(datatableService) {
        var inj = angular.injector(['ng']);
        this.$sce = inj.get('$sce');
        this.datatableService = datatableService;
    }

    public get dataList() {
        return this._dataList;
    }

    public get dataTable() {
        return this._dataTable;
    }

    public set exportFilename(value:string) {
        this._exportFilename = value;
    }

    public get exportFilename() {
        if (this._exportFilename === undefined) {
            return this.filename + ".csv";
        }
        return this._exportFilename;
    }


    public evaluatedValue($scope, col, row) {
        return $scope.$eval("data." + col.field + " | " + col.valueFormatter, {
            data: row
        });
    }

    public filterData(searchTerm) {
        this.dataTable.filter({$: searchTerm});
    }

    // TODO: Change to pass in what to call to get data.
    // TODO: Remove bpm service, this will be taken care of in the business tier
    public loadData(data) {
        this.isLoading = true;
        this._dataList = data;
        this._dataTable = this.datatableService.createNgTable(data, this.numberOfRows, this.defaultSort);
        this.isLoading = false;
    }

    /*
     * An empty function to be set when the DataGrid's options are declared.
     */
    public linkClick(a, b) {
//        console.log("In dataGrid linkClick...");
    }

    /*
     * An empty function to be set when the DataGrid's options are declared.
     */
    public linkValue($scope, col, row) {
    }


    public permitHtml(htmlString) {
        return this.$sce.trustAsHtml(htmlString);
    }
}