'use strict';

export default function dmlesDataGrid() {
    return {
        restrict: 'E',
        templateUrl: 'src/_common/_directives/dataGrid/dataGrid.html',
        scope: {
            options: '='
        }
    };
}