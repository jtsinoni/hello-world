define(["require", "exports"], function (require, exports) {
    'use strict';
    function dmlesDataGrid() {
        return {
            restrict: 'E',
            templateUrl: 'src/_common/_directives/dataGrid/dataGrid.html',
            scope: {
                options: '='
            }
        };
    }
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = dmlesDataGrid;
});
//# sourceMappingURL=dataGrid.directive.js.map