define(["require", "exports"], function (require, exports) {
    'use strict';
    function SearchInput() {
        return {
            transclude: true,
            restrict: 'EA',
            templateUrl: 'src/_common/_directives/searchComponents/searchInput.html',
        };
    }
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = SearchInput;
});
//# sourceMappingURL=searchInput.directive.js.map