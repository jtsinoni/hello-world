'use strict';

export default function SearchInput() {
    return {
        transclude: true,
        restrict: 'EA',
        templateUrl: 'src/_common/_directives/searchComponents/searchInput.html',
    };
}
