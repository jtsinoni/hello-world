define(["require", "exports", './_directives/module', './_filters/module', './_services/module'], function (require, exports, module_1, module_2, module_3) {
    'use strict';
    var commonModule = angular.module('Dmles.Common.Module', [
        module_1.default.name,
        module_2.default.name,
        module_3.default.name
    ]);
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = commonModule;
});
//# sourceMappingURL=module.js.map