'use strict';

class Router {
    static instance:any;

    // @ngInject
    constructor($stateProvider, $urlRouterProvider) {

        // For any unmatched url, redirect to /home
        $urlRouterProvider.otherwise('/dmles/security');

        $stateProvider
		.state('dmles', {
			url: '/dmles',
			templateUrl: '/src/shell.html',
			controller: 'Dmles.ShellController',
			controllerAs: 'vm',
			abstract: true
		});

    }

    static factory($stateProvider, $urlRouterProvider) {
        Router.instance = new Router($stateProvider, $urlRouterProvider);
        return Router.instance;
    }
}

Router.factory.$inject = ['$stateProvider', '$urlRouterProvider'];

export default Router