'use strict';

import router from './router';

import controllersModule from './_views/module';
import modelsModule from './_models/module';
import servicesModule from './_services/module';

var module = angular.module('Dmles.RegisterModule', [
    servicesModule.name,
    controllersModule.name,
    modelsModule.name
]);

module.config(router.factory);

export default module;