'use strict;'

class Router {
    static instance:any;

    // @ngInject
    constructor($stateProvider, $urlRouterProvider, StateConstants) {

        $stateProvider
            .state(StateConstants.REGISTER, {
                url: '/register',
                templateUrl: '/src/login/register/_views/register.html',
                controller: 'Dmles.Login.Register.Views.RegisterController',
                controllerAs: 'vm',
                data: {
                    displayName: 'Register'
                }
            })
            .state(StateConstants.REGISTER_CONFIRM, {
                url: '/confirmation',
                templateUrl: '/src/login/register/_views/confirmation.html',
                controller: 'Dmles.Login.Register.Views.ConfirmationController',
                controllerAs: 'vm',
                data: {
                    displayName: 'Confirm Registration'
                }
            });

    }

    static factory($stateProvider, $urlRouterProvider, StateConstants) {
        Router.instance = new Router($stateProvider, $urlRouterProvider, StateConstants);
        return Router.instance;
    }
}

Router.factory.$inject = ['$stateProvider', '$urlRouterProvider', 'StateConstants'];

export default Router;