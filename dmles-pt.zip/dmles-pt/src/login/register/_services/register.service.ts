import {UserProfileRegistration} from "../../../_models/userProfileRegistration.model";
import {ApiService} from "../../../_services/api.service";

export class RegistrationService extends ApiService {
    private serviceName: String = "Registration Service";
    private userCandidate: UserProfileRegistration = null; //Based on the UserProfileRegistration obj in RegisterController

    // @ngInject
    constructor($http, $log, Authentication, App, $httpParamSerializerJQLike) {
        super($http, $log, Authentication, App, $httpParamSerializerJQLike, "User");
        this.$log.debug("%s - Start", this.serviceName);
    }

    public getUserCandidate(): any {
        return this.userCandidate;
    }

    public register(userProfileCandidate) {
        /*var url:string = this.App.getBtBaseUrl() + "Dmles.User.Server/V1/unsecured/register";
        return this.$http.post(url, userProfileCandidate).then((response) => {
            this.$log.debug("%s - Registering userProfileCandidate:", this.serviceName);
        });*/

        return this.post("register", userProfileCandidate).then((result) => {
            this.userCandidate = null;
        });
    }

    public setUserCandidate(userCandidate: any): void {
        this.userCandidate = userCandidate;
    }
}