'use strict';

import {RegistrationService} from './register.service';
import {UserProfileTypeSelectionService} from './userProfileTypeSelection.service';

var servicesModule = angular.module('Dmles.Login.Register.Services.Module', []);
servicesModule.service('RegistrationService', RegistrationService);
servicesModule.service('UserProfileTypeSelectionService', UserProfileTypeSelectionService);

export default servicesModule;