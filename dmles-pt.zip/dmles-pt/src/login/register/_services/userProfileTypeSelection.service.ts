import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
'use strict';

import {UserProfile} from '../_models/userProfile.model';
import {UserProfileTypeSelection} from "../_models/userProfileTypeSelection.model";

export class UserProfileTypeSelectionService {
    private serviceName: string = "UserProfileTypeSelection Service";

    private serviceRegionSiteHierarchicalData: any[] = null;
    private services: any[] = [];
    private regions: any[] = [];
    private sites: any[] = [];

    private regionOpts: any[] = [];

    private userProfileTypeSelection = new UserProfileTypeSelection();

    // @ngInject
    constructor(private $filter, private $log, private MultiSelectService, private SiteService, private SystemService) {
        this.$log.debug("%s - Start", this.serviceName);
    }

    public getUserProfileTypeSelection(): any {
        return this.userProfileTypeSelection;
    }

    public setUserProfileTypeSelection(userProfileTypeSelection: any): void {
        this.userProfileTypeSelection = userProfileTypeSelection;
    }

    public lookupSiteGivenSiteDodaac(dodaac: string): string {
        var filteredSite = this.$filter('filter')(this.sites, {"dodaac": dodaac}, true);
        return filteredSite[0];
    }

    /**
     Initializes the MultiSelect options for the given UserProfileTypeSelection object. If a
     UserProfile is given, the selections already belonging to the userProfile will show as selected.
     @param uptSel - the UserProfileTypeSelection object to initializes
     @param userProfile - the userProfile from which the pre-selected options will be determined, can be null
     */
    private initMultiSelectOpts(userProfile: UserProfile) {
        // this.$log.debug("%s - Initializing UserProfileTypeSelection object", this.serviceName);
        // this.$log.debug("%s - uptSel: %s, userProfile: %s", this.serviceName, JSON.stringify(this.userProfileTypeSelection), userProfile);

        this.buildServicesRegionsSites(userProfile);

        // this.$log.debug("%s - return uptSel: %s", this.serviceName, JSON.stringify(this.userProfileTypeSelection));
        return this.userProfileTypeSelection;

    }

    private buildServicesRegionsSites(userProfile: UserProfile) {
        this.SystemService.getServices().then((response: IHttpPromiseCallbackArg<any>) => {
            // this.$log.debug("MainNav Returned: %s", JSON.stringify(response.data));

            // this response now includes services, regions within service and dodaacs within regions
            this.serviceRegionSiteHierarchicalData = response.data;

            var i: number = 0;
            var j: number = 0;
            var k: number = 0;
            var s: string;
            for (s in this.serviceRegionSiteHierarchicalData) {
                var service = this.serviceRegionSiteHierarchicalData[s];
                this.services[i++] = service;
                var r: string;
                for (r in service.regions) {
                    var region = service.regions[r];
                    this.regions[j] = region;
                    var t: string;
                    for (t in region.sites) {
                        var site = region.sites[t];
                        this.sites[k] = site;
                        this.sites[k].regionCode = region.code;
                        this.sites[k].regionName = region.name;
                        this.sites[k].serviceCode = service.code;
                        this.sites[k].serviceName = service.name;
                        k++;
                    }
                    this.regions[j].serviceCode = service.code;
                    this.regions[j].serviceName = service.name;
                    j++;
                    delete this.regions[r].sites;
                }
                delete this.services[s].regions;
            }
            // this.$log.debug("this.services: %s", JSON.stringify(this.services));
            // this.$log.debug("this.regions: %s", JSON.stringify(this.regions));
            // this.$log.debug("this.sites: %s", JSON.stringify(this.sites));

            this.loadServices(userProfile);
            this.loadRegions(userProfile);
            this.loadDodaacs(userProfile);

        }, (errResponse: IHttpPromiseCallbackArg<any>) => {
            this.$log.error("%s - Error retrieving services", this.serviceName);
            //TODO show some sort of message to the userProfile.
        });
    }

    /**
     Fetches the services from the database and initializes the services MultiSelect options for the
     given UserProfileTypeSelection object. If a UserProfile is given, the services  belonging to the userProfile will show as selected.
     @param uptSel - the UserProfileTypeSelection object to initialize
     @param userProfile - the userProfile from which the pre-selected services will be determined
     */
    private loadServices(userProfile: UserProfile) {
        var selectOpts = this.crServiceOpts(this.services, userProfile);
        this.userProfileTypeSelection.selectOptsServices = angular.copy(selectOpts);
        this.userProfileTypeSelection.masterServiceOpts = angular.copy(selectOpts);
        this.userProfileTypeSelection.isLoadingService = false;
        // this.$log.debug("loadServices uptSel: %s", JSON.stringify(this.userProfileTypeSelection));
    }

    /**
     Fetches the regions from the database and initializes the regions MultiSelect options for the
     given UserProfileTypeSelection object. If a UserProfile is given, the regions  belonging to the userProfile will show as selected.
     @param uptSel - the UserProfileTypeSelection object to initialize
     @param userProfile - the userProfile from which the pre-selected regions will be determined
     */
    private loadRegions(userProfile: UserProfile) {
        var selectOpts = this.crRegionOpts(this.regions, userProfile);
        this.userProfileTypeSelection.selectOptsRegions = angular.copy(selectOpts);
        this.userProfileTypeSelection.masterRegionOpts = angular.copy(selectOpts);
        this.userProfileTypeSelection.isLoadingRegion = false;
        // this.$log.debug("loadRegions uptSel: %s", JSON.stringify(this.userProfileTypeSelection));
    }

    /**
     Fetches the DoDAACs from the database and initializes the DoDAAC MultiSelect options for the
     given UserProfileTypeSelection object. If a UserProfile is given, the DoDAACs  belonging to the userProfile will show as selected.
     @param uptSel - the UserProfileTypeSelection object to initialize
     @param userProfile - the userProfile from which the pre-selected DoDAACs will be determined
     */
    private loadDodaacs(userProfile: UserProfile) {
        var selectOpts: any[] = this.crDodaacOpts(this.sites, userProfile);
        this.userProfileTypeSelection.selectOptsDodaacs = angular.copy(selectOpts);
        this.userProfileTypeSelection.masterDodaacOpts = angular.copy(selectOpts);
        this.userProfileTypeSelection.isLoadingDodaac = false;
        // this.$log.debug("loadDodaacs uptSel: %s", JSON.stringify(this.userProfileTypeSelection));
    }

    /**
     Creates SingleSelect Options based on the given services. If a userProfile is given
     and has a service selected, it will stay selected.

     @param services - an array of services to create MultiSelect Options from
     @userProfile - the userProfile for whom the currently selected service will be determined, can be null
     @returns - an array of MultiSelect options
     */
    private crServiceOpts(services: any[], userProfile: UserProfile) {
        services = services.sort();
        // this.$log.debug("services: %s", JSON.stringify(services));

        var selections: any[] = [];
        var s: string;
        for (s in services) {
            var service = services[s];
            var selected: boolean = false;
            if (userProfile && (userProfile.userType === "SERVICE" || userProfile.userType === "SERVICEREGION")) {
                if (userProfile.serviceCode === service.code) {
                    selected = true;
                }
            }
            selections.push(this.MultiSelectService.buildSelection(service.code, service.code, service.name, selected));
        }

        return selections;
    }

    /**
     Creates MultiSelect Options based on the given regions. If a userProfile is given
     and has a region selected, it will stay selected.

     @param regions - an array of regions to create MultiSelect Options from
     @userProfile - the userProfile for whom the currently selected region will be determined, can be null
     @returns an array of MultiSelect options
     */
    private crRegionOpts(regions: any[], userProfile: UserProfile) {
        // regions = regions.sort();
        // this.$log.debug("regions: %s", JSON.stringify(regions));

        var selections: any[] = [];
        var r: string;
        for (r in regions) {
            var region = regions[r];
            var selected: boolean = false;
            if (userProfile && (userProfile.userType === "SERVICE" || userProfile.userType === "SERVICEREGION")) {
                if (userProfile.serviceCode === region.code) {
                    selected = true;
                }
            }
            selections.push(this.MultiSelectService.buildSelection(region.code, region.code, region.name, selected));
        }

        this.regionOpts = selections;

        return selections;
    }

    private updateRegionOpts(selectedService) {

        // this.$log.debug("before this.regionOpts: %s", JSON.stringify(this.regionOpts));

        // this.$log.debug("selectedService.selValue: %s", JSON.stringify(selectedService.selValue));

        //Filter Regions based on selectedService.selValue
        var filteredRegions: any[] = this.$filter('filter')(this.regions, {serviceName: selectedService.selValue}, true);
        // this.$log.debug("filteredRegions: %s", JSON.stringify(filteredRegions));

        // re-initialize
        this.regionOpts = [];

        var r: string;
        for (r in filteredRegions) {
            var region = filteredRegions[r];
            this.regionOpts.push(this.MultiSelectService.buildSelection(region.code, region.code, region.name, false));
        }
        // this.$log.debug("after this.regionOpts: %s", JSON.stringify(this.regionOpts));

        this.userProfileTypeSelection.selectOptsRegions = angular.copy(this.regionOpts);
        this.userProfileTypeSelection.masterRegionOpts = angular.copy(this.regionOpts);
        this.userProfileTypeSelection.isLoadingRegion = false;
        // this.$log.debug("loadRegions uptSel: %s", JSON.stringify(this.userProfileTypeSelection));
    }

    /**
     Creates MultiSelect Options based on the given DoDAACs. If a userProfile is given
     and has DoDAACs selected, these will stay selected.

     @param dodaacs - an array of dodaacs to create MultiSelect Options from
     @userProfile - the userProfile for whom currently selected dodaacs will be determined, can be null
     @returns - an array of MultiSelect options
     */
    private crDodaacOpts(sites: any[], userProfile: UserProfile) {
        sites = sites.sort();
        // this.$log.debug("sites: %s", JSON.stringify(sites));

        //Filter Dodaacs based on dmlesEnabled
        // var filteredSites: any[] = this.$filter('filter')(sites, {dmlesEnabled: true}, true);
        // this.$log.debug("filteredSites: %s", JSON.stringify(filteredSites));

        var selections: any[] = [];
        var s: string;
        for (s in sites) {
            var site = sites[s];
            var selected: boolean = false;
            if (userProfile && userProfile.userType === "SITE") {
                if (userProfile.dodaac) {
                    if (userProfile.dodaac === site.dodaac) {
                        selected = true;
                    }
                }
            }
            selections.push(this.MultiSelectService.buildSelection(site.dodaac, site.dodaac, site.name, selected));
        }

        return selections;
    }
}