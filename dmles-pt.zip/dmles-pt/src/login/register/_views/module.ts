'use strict';

import {ConfirmationController} from './confirmation.controller';
import {RegisterController} from './register.controller';

var controllersModule = angular.module('Dmles.Login.Register.Views.Module', []);
controllersModule.controller('Dmles.Login.Register.Views.ConfirmationController', ConfirmationController);
controllersModule.controller('Dmles.Login.Register.Views.RegisterController', RegisterController);

export default controllersModule;