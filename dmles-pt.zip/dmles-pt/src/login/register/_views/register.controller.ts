'use strict';

import IHttpPromiseCallbackArg = angular.IHttpPromiseCallbackArg;
import {UserProfileRegistration} from "../../../_models/userProfileRegistration.model";

export class RegisterController {
    private controllerName: string = "Register Controller";
    private userProfileRegistration: UserProfileRegistration = new UserProfileRegistration();
    private formError: string;

    // @ngInject
    constructor(private $log, private $state, private ApiConstants, private Authentication, private ContentConstants, private NotificationService,
                private OAuthService, private RegistrationService, private StateConstants, private UserProfileService,
                private UserProfileTypeSelectionService) {

        this.$log.debug("%s - Start", this.controllerName);

        this.userProfileRegistration.phoneNumbers[0] = {
            value: "",
            phoneNumberType: "WORK"
        };

        // temporary until we get getSites working
        this.UserProfileTypeSelectionService.getUserProfileTypeSelection().selDodaac[0] = {
            itemId: "",
            selId: "",
            selValue: ""
        };

        this.init();
    }

    private init(){
        this.getUnregisteredUser();
    }

    private getSelections(){
        this.UserProfileTypeSelectionService.setUserProfileTypeSelection(
            this.UserProfileTypeSelectionService.initMultiSelectOpts(null));
    }

    private getUnregisteredUser() {
        this.$log.debug("%s - Getting unregistered user token", this.controllerName);
        this.OAuthService.getNewToken(this.ApiConstants.UNREGISTERED_USER).then((data: any) => {
            if (!data) {
                this.NotificationService.errorMsg("Unable to authenticate user");
            }else{
                this.getSelections();
            }
        }, (err) => {
            this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
        });
    }

    /**
     * Go to login state
     */
    public goBack() {
        this.$log.debug("%s - Go back to login", this.controllerName);
        this.Authentication.isShowImage = true;
        this.$state.go(this.StateConstants.LOGIN);
    }

    /**
     Checks that each field in the form is completed. Used for enabling the submit button in the html.

     @returns a boolean representing whether or not the form is complete
     */
    private isFormComplete(): boolean {
        // Check for string fields
        if (!this.userProfileRegistration.firstName || !this.userProfileRegistration.lastName || !this.userProfileRegistration.email || !this.userProfileRegistration.phoneNumbers[0].value || !this.userProfileRegistration.pkiDn || !this.userProfileRegistration.reasonForAccess) {
            return false;
        } else {
            // All string fields are complete, check for user type and dodaac
            if (this.UserProfileTypeSelectionService.getUserProfileTypeSelection().userProfileType ===
                this.UserProfileTypeSelectionService.getUserProfileTypeSelection().userProfileTypeOpts.GLOBAL) {
                return true;
            }
            else if (this.UserProfileTypeSelectionService.getUserProfileTypeSelection().userProfileType ===
                this.UserProfileTypeSelectionService.getUserProfileTypeSelection().userProfileTypeOpts.SITE) {
                if (this.UserProfileTypeSelectionService.getUserProfileTypeSelection().selDodaac.length != 0) {
                    return true
                }
            } else if (this.UserProfileTypeSelectionService.getUserProfileTypeSelection().userProfileType ===
                this.UserProfileTypeSelectionService.getUserProfileTypeSelection().userProfileTypeOpts.SERVICE) {

                if (this.UserProfileTypeSelectionService.getUserProfileTypeSelection().selService.length != 0) {
                    return true;
                }
            } else if (this.UserProfileTypeSelectionService.getUserProfileTypeSelection().userProfileType ===
                this.UserProfileTypeSelectionService.getUserProfileTypeSelection().userProfileTypeOpts.SERVICEREGION) {

                if (this.UserProfileTypeSelectionService.getUserProfileTypeSelection().selService.length != 0 ||
                    this.UserProfileTypeSelectionService.getUserProfileTypeSelection().selRegion.length != 0) {
                    return true;
                }
            }
            return false;
        }
    }

    /**
     * Validates the form has been completed with valid data and opens confirmation page
     */
    public onSubmit() {
        if (this.validateCredentials("is required")) {
            // Set fields from multi-select
            if (this.UserProfileTypeSelectionService.getUserProfileTypeSelection().selDodaac[0]) {
                this.userProfileRegistration.dodaac = this.UserProfileTypeSelectionService.getUserProfileTypeSelection().selDodaac[0].selId;
            }
            if (this.UserProfileTypeSelectionService.getUserProfileTypeSelection().selRegion[0]) {
                this.userProfileRegistration.regionCode = this.UserProfileTypeSelectionService.getUserProfileTypeSelection().selRegion[0].selId;
            }
            if (this.UserProfileTypeSelectionService.getUserProfileTypeSelection().selService[0]) {
                this.userProfileRegistration.serviceCode = this.UserProfileTypeSelectionService.getUserProfileTypeSelection().selService[0].selId;
            }
            if (this.UserProfileTypeSelectionService.getUserProfileTypeSelection().userProfileType) {
                this.userProfileRegistration.userType = this.UserProfileTypeSelectionService.getUserProfileTypeSelection().userProfileType;
            }

            // Show confirmation page
            this.$log.debug("%s - On Submit, this.userProfileRegistration: %s", this.controllerName,
                JSON.stringify(this.userProfileRegistration));
            this.RegistrationService.setUserCandidate(this.userProfileRegistration);
            this.$state.go(this.StateConstants.REGISTER_CONFIRM);
        }
    }

    /**
     Resets the multi-selects when user profile type changes
     */
    private onUserProfileTypeChange(value: string): void {

        // reset dodaac, service and region if selected
        this.UserProfileTypeSelectionService.getUserProfileTypeSelection().selectOptsDodaacs =
            angular.copy(this.UserProfileTypeSelectionService.getUserProfileTypeSelection().masterDodaacOpts);

        this.UserProfileTypeSelectionService.getUserProfileTypeSelection().selectOptsServices =
            angular.copy(this.UserProfileTypeSelectionService.getUserProfileTypeSelection().masterServiceOpts);

        this.UserProfileTypeSelectionService.getUserProfileTypeSelection().selectOptsRegions =
            angular.copy(this.UserProfileTypeSelectionService.getUserProfileTypeSelection().masterRegionOpts);
    }

    /**
     Checks to see that all required fields are populated and the the given email
     is not already in the database. If a field is empty, or the email already exists, the form
     error is set

     @param suffix - a message to append at the end of the field in the form error
     @returns - a promise with the data of true if all fields are valid, otherwise false
     */
    private validateCredentials(suffix: string) {
        var retval: boolean = true;
        this.formError = "";

        if (!this.userProfileRegistration.firstName) {
            this.formError = "First name " + suffix;
            retval = false;
        } else if (!this.userProfileRegistration.lastName) {
            this.formError = "Last name " + suffix;
            retval = false;
        } else if (!this.userProfileRegistration.email) {
            this.formError = "E-mail " + suffix;
            retval = false;
        } else if (!this.userProfileRegistration.phoneNumbers[0].value) {
            this.formError = "Phone Number " + suffix;
            retval = false;
        } else if (!this.userProfileRegistration.pkiDn) {
            this.formError = "pkiDn " + suffix;
            retval = false;
        } else if (!this.UserProfileTypeSelectionService.getUserProfileTypeSelection().userProfileType) {
            this.formError = "User Profile Type " + suffix;
            retval = false;
        } else if (this.UserProfileTypeSelectionService.getUserProfileTypeSelection().userProfileType ===
            this.UserProfileTypeSelectionService.getUserProfileTypeSelection().userProfileTypeOpts.SITE) {

            if (this.UserProfileTypeSelectionService.getUserProfileTypeSelection().selDodaac.length === 0) {
                this.formError = "DoDAAC selection " + suffix;
                retval = false;
            }
        } else if (this.UserProfileTypeSelectionService.getUserProfileTypeSelection().userProfileType ===
            this.UserProfileTypeSelectionService.getUserProfileTypeSelection().userProfileTypeOpts.SERVICE) {

            if (this.UserProfileTypeSelectionService.getUserProfileTypeSelection().selService.length === 0) {

                this.formError = "A Service selection " + suffix;
                retval = false;

            }
        } else if (this.UserProfileTypeSelectionService.getUserProfileTypeSelection().userProfileType ===
            this.UserProfileTypeSelectionService.getUserProfileTypeSelection().userProfileTypeOpts.SERVICEREGION) {

            if (this.UserProfileTypeSelectionService.getUserProfileTypeSelection().selService.length === 0 ||
                this.UserProfileTypeSelectionService.getUserProfileTypeSelection().selRegion.length === 0) {

                this.formError = "A Region and Service selection " + suffix;
                retval = false;

            }
        }
        return retval;
    }
}

