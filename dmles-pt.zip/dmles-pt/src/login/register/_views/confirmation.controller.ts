'use strict';
import {UserProfileRegistration} from "../../../_models/userProfileRegistration.model";

export class ConfirmationController {
    private controllerName: string = "Registration Confirmation Controller";
    private dodaacDisp: string = "";
    private regionDisp: string = "";
    private serviceDisp: string = "";
    private submitComplete: boolean;
    private userCandidate: UserProfileRegistration = null;

    private errorMsg: string = "Error submitting the registration";
    private successMsg: string = "Registration successfully submitted";

    // @ngInject
    constructor(private $log, private $state, private NotificationService, private RegistrationService, private StateConstants,
                private UserProfileTypeSelectionService) {
        this.$log.debug("%s - Start", this.controllerName);

        this.userCandidate = this.RegistrationService.getUserCandidate();
        if (this.userCandidate === null) {
            // No user candidate, return to login screen
            this.$log.debug("%s - Go back to login", this.controllerName);
            this.$state.go(this.StateConstants.LOGIN);
        }

        this.init();
    }

    /**
     Registers the given userProfileCandidate by adding them to the database
     @param userProfileCandidate - the userProfileCandidate to be added
     */
    private doRegister(userProfileCandidate: UserProfileRegistration) {

        //do registration        
        this.RegistrationService.register(userProfileCandidate)
            .then((result) => {
                this.submitComplete = true;
                //this.RegistrationService.setUserCandidate(null);
                this.NotificationService.successMsg(this.successMsg);
            }, (errResponse) => {
                this.$log.error("Error registering userProfileCandidate");
                this.$log.debug(errResponse);
                this.NotificationService.errorMsg(this.errorMsg);
            });
    }

    /**
     * Initializes variables used for display on the web page
     */
    private init() {
        //Set display information for dodaac/region/service
        //When they get reset to go to the BT the name is lost...
        if (this.userCandidate.userType === "SITE") {
            this.dodaacDisp = this.userCandidate.dodaac;
            this.userCandidate.userProfileId = "SITE " + this.dodaacDisp;
            var site = this.UserProfileTypeSelectionService.lookupSiteGivenSiteDodaac(this.userCandidate.dodaac);
            this.userCandidate.serviceCode = site.serviceCode;
            this.serviceDisp = this.userCandidate.serviceCode;
            this.userCandidate.regionCode = site.regionCode;
            this.regionDisp = this.userCandidate.regionCode;            
        } else if (this.userCandidate.userType === "SERVICE") {
            this.userCandidate.dodaac = "";
            this.serviceDisp = this.userCandidate.serviceCode;
            this.userCandidate.userProfileId = "SERVICE " + this.serviceDisp;
            this.userCandidate.regionCode = "";
        } else if (this.userCandidate.userType === "SERVICEREGION") {
            this.userCandidate.dodaac = "";
            this.serviceDisp = this.userCandidate.serviceCode;
            this.regionDisp = this.userCandidate.regionCode;
            this.userCandidate.userProfileId = "SERVICEREGION " + this.serviceDisp + " " + this.regionDisp;
        } else if (this.userCandidate.userType === "GLOBAL") {
            this.userCandidate.dodaac = "";
            this.userCandidate.serviceCode = "DHA";
            this.serviceDisp = this.userCandidate.serviceCode;
            this.userCandidate.regionCode = "";
            this.userCandidate.userProfileId = "GLOBAL";
        }
    }

    /**
     Takes the user to either the Register Page or the Login Page depending on the state of the registration.
     */
    public goBack() {
        this.$log.debug("%s - Go back to register", this.controllerName);
        if (this.submitComplete) {
            this.$state.go(this.StateConstants.LOGIN);
        } else {
            this.$state.go(this.StateConstants.REGISTER);
        }
    }

    /**
     Sends the userCandidate object to be registered.
     Note - User has already been validated in the RegisterController, so there
     is no need to re-validate.
     */
    public onConfirm(): void {
        this.$log.debug("Registration onConfirm, this.userCandidate: ", JSON.stringify(this.userCandidate));
        this.doRegister(this.userCandidate);
    }
}

