'use strict';

export class UserProfileTypeSelection {
    public isLoadingDodaac:boolean = true;
    public isLoadingRegion:boolean = true;
    public isLoadingService:boolean = true;
    public masterDodaacOpts:any = [];
    public masterRegionOpts:any = [];
    public masterServiceOpts:any = [];
    public selDodaac:any[] = [];
    public selRegion:any[] = [];
    public selService:any[] = [];
    public selectOptsDodaacs:any[] = [];
    public selectOptsRegions:any[] = [];
    public selectOptsServices:any[] = [];
    public userProfileType:string = "";
    public userProfileTypeOpts:any = {
        SITE: "SITE",
        SERVICE: "SERVICE",
        SERVICEREGION: "SERVICEREGION",
        GLOBAL: "GLOBAL"
    };

    constructor();
    constructor(obj:UserProfileTypeSelection);
    constructor(obj?:any) {
        this.isLoadingDodaac = obj && obj.isLoadingDodaac || true;
        this.isLoadingRegion = obj && obj.isLoadingRegion || true;
        this.isLoadingService = obj && obj.isLoadingService || true;
        this.masterDodaacOpts = obj && obj.masterDodaacOpts || [];
        this.masterRegionOpts = obj && obj.masterRegionOpts || [];
        this.masterServiceOpts = obj && obj.masterServiceOpts || [];
        this.selDodaac = obj && obj.selDodaac || [];
        this.selRegion = obj && obj.selRegion || [];
        this.selService = obj && obj.selService || [];
        this.selectOptsDodaacs = obj && obj.selectOptsDodaacs || [];
        this.selectOptsRegions = obj && obj.selectOptsRegions || [];
        this.selectOptsServices = obj && obj.selectOptsServices || [];
        this.userProfileType = obj && obj.userProfileType || "";
        this.userProfileTypeOpts = obj && obj.userProfileTypeOpts ||
            {
                SITE: "SITE",
                SERVICE: "SERVICE",
                SERVICEREGION: "SERVICEREGION",
                GLOBAL: "GLOBAL"
            };
    }
}