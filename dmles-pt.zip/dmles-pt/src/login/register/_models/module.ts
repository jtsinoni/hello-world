'use strict';

import {UserProfileTypeSelection} from './userProfileTypeSelection.model';

var modelsModule = angular.module('Dmles.Login.Register.Models.Module', []);
modelsModule.value('UserProfileTypeSelection', UserProfileTypeSelection);

export default modelsModule;