'use strict';

export class LoginShellController {
    viewName:string;

    // @ngInject
    constructor() {
        this.init();
    }

    init() {
        this.viewName = 'Login Shell View';
    }
}