'use strict;'

class Router {
    static instance:any;

    // @ngInject
    constructor($stateProvider, $urlRouterProvider, StateConstants) {

        $stateProvider
        .state(StateConstants.LOGIN_SHELL, {
            url: '/login',
            templateUrl: '/src/login/loginShell.html',
            controller: 'Dmles.Login.LoginShellController',
            controllerAs: 'vm',
            abstract: true
        })
        .state(StateConstants.LOGIN, {
            url: '/form',
            templateUrl: '/src/login/_views/login.html',
            controller: 'Dmles.Login.Views.LoginController',
            controllerAs: 'vm',
            data: {
                displayName: 'Login'
            }
		});

    }

    static factory($stateProvider, $urlRouterProvider, StateConstants) {
        Router.instance = new Router($stateProvider, $urlRouterProvider, StateConstants);
        return Router.instance;
    }
}

Router.factory.$inject = ['$stateProvider', '$urlRouterProvider', 'StateConstants'];

export default Router;