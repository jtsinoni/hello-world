'use strict';
import {CurrentUserProfile} from "../../_models/currentUserProfile.model";

export class LoginController {
    private controllerName: string = "Login Controller";
    public credentials: any = {};
    public returnPage: string;

    // @ngInject
    constructor(private $location, private $log, private $state, private ApiConstants, private OAuthService, private ContentConstants,
                private NotificationService, private StateConstants, private SystemService,
                private UserService) {
        this.$log.debug("%s - Start", this.controllerName);
        $(window).scrollTop(0);

        this.credentials = {
            dn: ""
        };

        this.returnPage = this.$location.search().page || '/';
    }

    private doCacLogin() {
        this.$log.debug("%s - Performing CAC login", this.controllerName);
        this.$log.debug("%s - CAC ID: %s", this.controllerName, this.credentials.dn);

        this.OAuthService.getNewToken(this.credentials.dn).then((data: any) => {
            if (data) {
                this.UserService.signIn().then((signInData: any) => {
                    if(signInData){

                        // Pull and build common data
                        this.SystemService.buildServicesRegionsSites();
                        this.goToHome();

                    } else{
                        this.NotificationService.errorMsg("Unable to sign in");
                    }
                }, (err) => {
                    this.NotificationService.errorMsg("User permissions not found");
                });
            } else {
                this.NotificationService.errorMsg("Unable to authenticate user");
            }
        }, (err) => {
            this.NotificationService.errorMsg(this.ContentConstants.ERR_MSG);
        });

    }

    private goToHome() {
        this.$log.debug("%s - Go to home", this.controllerName);
        this.$state.go(this.StateConstants.MY_DASHBOARD);
    }

    public getRegistration() {
        this.$state.go(this.StateConstants.REGISTER);
    }

    public onCacLogin() {
        if (!this.credentials.dn) {
            this.NotificationService.errorMsg("CAC DN is required, please try again");
            return false;
        } else {
            this.doCacLogin();
        }
    }

}

