'use strict';

import {LoginController} from './login.controller';

var controllersModule = angular.module('Dmles.Login.Views.Module', []);
controllersModule.controller('Dmles.Login.Views.LoginController', LoginController);

export default controllersModule;