'use strict';

import router from './router';
import {LoginShellController} from './loginShell.controller';

import registerModule from './register/module';
import viewsModule from './_views/module';

var module = angular.module('Dmles.LoginModule', [
    registerModule.name,
    viewsModule.name
]);

module.controller('Dmles.Login.LoginShellController', LoginShellController);
module.config(router.factory);

export default module;