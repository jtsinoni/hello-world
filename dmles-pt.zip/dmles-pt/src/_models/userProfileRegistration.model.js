define(["require", "exports", "../login/register/_models/realEstateSite.model"], function (require, exports, realEstateSite_model_1) {
    'use strict';
    // model that contains the information that a User Administrator would 
    // need to know about a userProfile to administer it in the database
    var UserProfileRegistration = (function () {
        function UserProfileRegistration(obj) {
            this.id = null;
            this.accessApprovedDate = null;
            this.accessDeniedDate = null;
            this.adminNotes = "";
            this.dodaac = "";
            this.email = "";
            this.firstName = "";
            this.lastName = "";
            this.phoneNumbers = [];
            this.pkiDn = "";
            this.reasonForAccess = "";
            this.regionCode = "";
            this.serviceCode = "";
            this.userProfileId = "";
            this.userStatus = null;
            this.userType = null;
            this.appProfileType = "";
            this.id = obj && obj.id || null;
            this.accessApprovedDate = obj && obj.accessApprovedDate || null;
            this.accessDeniedDate = obj && obj.accessDeniedDate || null;
            this.adminNotes = obj && obj.adminNotes || "";
            this.dodaac = obj && obj.dodaac || "";
            this.email = obj && obj.email || "";
            this.firstName = obj && obj.firstName || "";
            this.lastName = obj && obj.lastName || "";
            this.phoneNumbers = obj && obj.phoneNumbers || [];
            this.pkiDn = obj && obj.pkiDn || "";
            this.reasonForAccess = obj && obj.reasonForAccess || "";
            this.regionCode = obj && obj.regionCode || "";
            this.serviceCode = obj && obj.serviceCode || "";
            this.userProfileId = obj && obj.userProfileId || "";
            this.userStatus = obj && obj.userStatus || null;
            this.userType = obj && obj.userType || null;
            this.appProfileType = obj && obj.appProfileType || "";
            this.realEstateSite = obj && obj.realEstateSite || new realEstateSite_model_1.RealEstateSite();
        }
        ;
        return UserProfileRegistration;
    }());
    exports.UserProfileRegistration = UserProfileRegistration;
});
//# sourceMappingURL=userProfileRegistration.model.js.map