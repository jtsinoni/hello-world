'use strict';

import {RealEstateSite} from "../login/register/_models/realEstateSite.model";
import {Invitation} from "./invitation.model";

// model that contains the information that a User Administrator would
// need to know about a userProfile to administer it in the database

export class UserProfile {

    public id: string = "";
    public appProfileType: string = "";
    public assignedPermissions: Array<any> = [];
    public current: Boolean = true;
    public dodaac: any = "";
    public email: string = "";
    public firstName: string = "";
    public lastLoginDate: Date = null;
    public lastName: string = "";
    //public password: string = "";
    public phoneNumbers: Array<any> = [];
    public pkiDn: string = "";
    public profileName: string = "";
    public reasonForAccess: string = "";
    public regionCode: string = "";
    //public registrationId: string = "";
    public roles: Array<any> = [];
    public serviceCode: string = "";
    public userProfileStatus: any = null;
    public userType: any = null;
    public updatedDate: Date = null;
    public updatedBy: string = "";
    public lockedDate: Date = null;
    public unlockedDate: Date = null;
    public reason: string ="";
    public _isDeleted: Boolean = false;
    public deletedDate: Date = null;
    public realEstateSite: RealEstateSite;
    public profileExpirationDate: Date;
    public profileSuspensionDate: Date;
    public invitation:Invitation;

    constructor();
    constructor(obj: UserProfile);
    constructor(obj?: any) {
        this.id = obj && obj.id || "";
        this.appProfileType = obj && obj.appProfileType || "";
        this.assignedPermissions = obj && obj.assignedPermissions || [];
        this.current = obj && obj.current || true;
        this.dodaac = obj && obj.dodaac || "";
        this.email = obj && obj.email || "";
        this.firstName = obj && obj.firstName || "";
        this.lastLoginDate = obj && obj.lastLoginDate || null;
        this.lastName = obj && obj.lastName || "";
        //this.password = obj && obj.password || "";
        this.phoneNumbers = obj && obj.phoneNumbers || [];
        this.pkiDn = obj && obj.pkiDn || "";
        this.profileName = obj && obj.profileName || "";
        this.reasonForAccess = obj && obj.reasonForAccess || "";
        this.regionCode = obj && obj.regionCode || "";
        //this.registrationId = obj && obj.registrationId || "";
        this.roles = obj && obj.roles || [];
        this.serviceCode = obj && obj.serviceCode || "";
        this.userProfileStatus = obj && obj.userProfileStatus || null;
        this.userType = obj && obj.userType || null;
        this.updatedDate = obj && obj.updatedDate || null;
        this.updatedBy = obj && obj.updatedBy || null;
        this.lockedDate = obj && obj.lockedDate || null;
        this.unlockedDate = obj && obj.unlockedDate || null;
        this.reason = obj && obj.reason || null;
        this.updatedBy = obj && obj.updatedBy || "";
        this._isDeleted = obj && obj._isDeleted || false;
        this.deletedDate = obj && obj.deletedDate || null;
        this.realEstateSite = obj && obj.realEstateSite || new RealEstateSite();
        this.profileExpirationDate = obj && obj.profileExpirationDate || null;
        this.profileSuspensionDate = obj && obj.profileSuspensionDate || null;
        this.invitation = obj && obj.invitation || new Invitation();
    };
}
