'use strict';

import {RealEstateSite} from "../login/register/_models/realEstateSite.model";

// model that contains the information that a User Administrator would
// need to know about a userProfile to administer it in the database

export class UserProfile {

    public id: string = "";
    public appProfileType: string = "";
    public assignedPermissions: Array<any> = [];
    public current: Boolean = true;
    public dodaac: any = "";
    public email: string = "";
    public firstName: string = "";
    public lastLoginDate: Date = null;
    public lastName: string = "";
    public password: string = "";
    public phoneNumbers: Array<any> = [];
    public pkiDn: string = "";
    public profileName: string = "";
    public reasonForAccess: string = "";
    public regionCode: string = "";
    public registrationId: string = "";
    public roles: Array<any> = [];
    public serviceCode: string = "";
    public userStatus: any = null;
    public userType: any = null;
    public updatedDate: Date = null;
    public updatedBy: string = "";
    public realEstateSite: RealEstateSite;

    constructor();
    constructor(obj: UserProfile);
    constructor(obj?: any) {
        this.id = obj && obj.id || "";
        this.appProfileType = obj && obj.appProfileType || "";
        this.assignedPermissions = obj && obj.assignedPermissions || [];
        this.current = obj && obj.current || true;
        this.dodaac = obj && obj.dodaac || "";
        this.email = obj && obj.email || "";
        this.firstName = obj && obj.firstName || "";
        this.lastLoginDate = obj && obj.lastLoginDate || null;
        this.lastName = obj && obj.lastName || "";
        this.password = obj && obj.password || "";
        this.phoneNumbers = obj && obj.phoneNumbers || [];
        this.pkiDn = obj && obj.pkiDn || "";
        this.profileName = obj && obj.profileName || "";
        this.reasonForAccess = obj && obj.reasonForAccess || "";
        this.regionCode = obj && obj.regionCode || "";
        this.registrationId = obj && obj.registrationId || "";
        this.roles = obj && obj.roles || [];
        this.serviceCode = obj && obj.serviceCode || "";
        this.userStatus = obj && obj.userStatus || null;
        this.userType = obj && obj.userType || null;
        this.updatedDate = obj && obj.updatedDate || null;
        this.updatedBy = obj && obj.updatedBy || null;
        // this.realEstateSite = obj && obj.realEstateSite || [];
        this.realEstateSite = obj && obj.realEstateSite || new RealEstateSite();
    };
}
