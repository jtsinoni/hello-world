define(["require", "exports"], function (require, exports) {
    'use strict';
    var PermEndpoint = (function () {
        function PermEndpoint(obj) {
            this.id = "";
            this.businessMethod = "";
            this.id = obj && obj.id || "";
            this.businessMethod = obj && obj.businessMethod || "";
        }
        return PermEndpoint;
    }());
    exports.PermEndpoint = PermEndpoint;
});
//# sourceMappingURL=permEndpoint.model.js.map