'use strict';

export class Note {
    public noteText:string;
    public section:string;
    public firstName:string;
    public lastName:string;
    public dateCreated:string;

    constructor();
    constructor(obj:Note);
    constructor(obj?:any) {
        this.noteText = obj && obj.noteText || "";
        this.section = obj && obj.section || "";
        this.firstName = obj && obj.firstName || "";
        this.lastName = obj && obj.lastName || "";
        this.dateCreated = obj && obj.dateCreated || null;
    };
}