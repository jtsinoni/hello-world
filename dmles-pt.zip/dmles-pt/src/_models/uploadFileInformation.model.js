define(["require", "exports", "./uploadFile.model"], function (require, exports, uploadFile_model_1) {
    'use strict;';
    var UploadFileInformation = (function () {
        function UploadFileInformation(obj) {
            this.orgId = "";
            this.itemId = "";
            this.catalogNumber = "";
            this.manufacturerName = "";
            this.description = "";
            this.file = new uploadFile_model_1.UploadFile();
            this.requestId = obj && obj.id || "";
            this.orgId = obj && obj.orgId || "";
            this.itemId = obj && obj.itemId || "";
            this.catalogNumber = obj && obj.catalogNumber || "";
            this.manufacturerName = obj && obj.manufacturerName || "";
            this.description = obj && obj.description || "";
            this.file = obj && obj.file || new uploadFile_model_1.UploadFile();
        }
        ;
        return UploadFileInformation;
    }());
    exports.UploadFileInformation = UploadFileInformation;
});
//# sourceMappingURL=uploadFileInformation.model.js.map