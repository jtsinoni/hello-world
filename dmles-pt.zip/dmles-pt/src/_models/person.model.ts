'use strict';

export class Person {

    public defaultDodaac:string;
    public email:string;
    public userId:string;
    public nameFirst:string;
    public nameLast:string;
    public phoneNumber:string;
    public dodaac:string;
    public serviceCode:string;
    public regionCode:string;

    constructor();
    constructor(obj:Person);
    constructor(obj?:any) {
        this.defaultDodaac = obj && obj.defaultDodaac || "";
        this.email = obj && obj.email || "";
        this.userId = obj && obj.userId || "";
        this.nameFirst = obj && obj.nameFirst || "";
        this.nameLast = obj && obj.nameLast || "";
        this.phoneNumber = obj && obj.phoneNumber || "";
    };
}