define(["require", "exports"], function (require, exports) {
    'use strict';
    var Organization = (function () {
        function Organization(obj) {
            this.id = obj && obj.id || "";
            this.organizationID = obj && obj.organizationID || "";
            this.organizationOrgName = obj && obj.organizationOrgName || "";
            this.organizationSerial = obj && obj.organizationSerial || "";
        }
        ;
        return Organization;
    }());
    exports.Organization = Organization;
});
//# sourceMappingURL=organization.model.js.map