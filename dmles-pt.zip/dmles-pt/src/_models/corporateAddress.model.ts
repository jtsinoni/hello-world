'use strict';

export class CorporateAddress {
    public addressLine1:string;
    public addressLine2:string;
    public city:string;
    public state:string;
    public country:string;
    public zipCode:string;

    constructor();
    constructor(obj:CorporateAddress);
    constructor(obj?:any) {
        this.addressLine1 = obj && obj.addressLine1 || "";
        this.addressLine2 = obj && obj.addressLine2 || "";
        this.city = obj && obj.city || "";
        this.state = obj && obj.state || "";
        this.country = obj && obj.country || "";
        this.zipCode = obj && obj.zipCode || "";
    };
}