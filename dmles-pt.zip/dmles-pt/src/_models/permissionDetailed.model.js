define(["require", "exports"], function (require, exports) {
    'use strict';
    var PermissionDetailed = (function () {
        function PermissionDetailed(obj) {
            this.id = "";
            this.name = "";
            this.description = "";
            this.functionalArea = "";
            this.elements = [];
            this.states = [];
            this.endpoints = [];
            this.id = obj && obj.id || "";
            this.name = obj && obj.name || "";
            this.description = obj && obj.description || "";
            this.functionalArea = obj && obj.functionalArea || "";
            this.elements = obj && obj.elements || [];
            this.states = obj && obj.states || [];
            this.endpoints = obj && obj.endpoints || [];
        }
        return PermissionDetailed;
    }());
    exports.PermissionDetailed = PermissionDetailed;
});
//# sourceMappingURL=permissionDetailed.model.js.map