define(["require", "exports"], function (require, exports) {
    'use strict';
    var FacetConfiguration = (function () {
        function FacetConfiguration(obj) {
            this.displayLabel = "";
            this.aggregationIdentifier = "";
            this.elasticSearchFieldName = "";
            this.initializeAsCollapsed = false;
            this.isDisplayed = true;
            this.displayLabel = obj && obj.displayLabel || "";
            this.aggregationIdentifier = obj && obj.aggregationIdentifier || "";
            this.elasticSearchFieldName = obj && obj.elasticSearchFieldName || "";
            this.initializeAsCollapsed = obj && obj.initializeAsCollapsed || false;
            this.isDisplayed = obj && obj.isDisplayed || true;
        }
        ;
        return FacetConfiguration;
    }());
    exports.FacetConfiguration = FacetConfiguration;
});
//# sourceMappingURL=facetConfiguration.model.js.map