define(["require", "exports"], function (require, exports) {
    'use strict';
    var CategoryOption = (function () {
        function CategoryOption(obj) {
            this.optionValue = "";
            this.isSelected = false;
            this.level = 0;
            this.optionValue = obj && obj.optionValue || "";
            this.isSelected = obj && obj.isSelected || false;
            this.level = obj && obj.level || 0;
        }
        ;
        return CategoryOption;
    }());
    exports.CategoryOption = CategoryOption;
});
//# sourceMappingURL=categoryOption.model.js.map