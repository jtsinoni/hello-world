'use strict';

export class RoleFunctionalAreaConfig {
    public id:any = "";
    public option:string = "";
    public displayName:string = "";

    constructor();
    constructor(obj:RoleFunctionalAreaConfig);
    constructor(obj?:any) {
        this.id = obj && obj.id || "";
        this.option = obj && obj.option || "";
        this.displayName = obj && obj.displayName || "";
    }
}