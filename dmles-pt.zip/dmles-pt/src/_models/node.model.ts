export class Node {
    public id:string;
    public guid:string;
    public parent:string;
    public name:string;
    public milServiceId:string;
    public providerCode:string;
    public isPrimaryOrg: Boolean;
    public orgRef:string;
    public parentRef:string;

    constructor();
    constructor(obj:Node);
    constructor(obj?:any) {
        this.id = obj && obj.id || "";
        this.guid = obj && obj.guid || "";
        this.parent = obj && obj.parent || "";
        this.name = obj && obj.name || "";
        this.milServiceId = obj && obj.milServiceId || "";
        this.providerCode = obj && obj.providerCode || "";
        this.isPrimaryOrg = obj && obj.isPrimaryOrg || false;
        this.orgRef = obj && obj.orgRef || "";
        this.parentRef = obj && obj.parentRef || "";
    };

}
