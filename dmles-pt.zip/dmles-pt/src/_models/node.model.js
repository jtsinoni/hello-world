define(["require", "exports"], function (require, exports) {
    "use strict";
    var Node = (function () {
        function Node(obj) {
            this.id = obj && obj.id || "";
            this.guid = obj && obj.guid || "";
            this.parent = obj && obj.parent || "";
            this.name = obj && obj.name || "";
            this.milServiceId = obj && obj.milServiceId || "";
            this.providerCode = obj && obj.providerCode || "";
            this.isPrimaryOrg = obj && obj.isPrimaryOrg || false;
            this.orgRef = obj && obj.orgRef || "";
            this.parentRef = obj && obj.parentRef || "";
        }
        ;
        return Node;
    }());
    exports.Node = Node;
});
//# sourceMappingURL=node.model.js.map