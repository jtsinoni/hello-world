define(["require", "exports"], function (require, exports) {
    'use strict';
    // model that contains the information that a User Administrator would 
    // need to know about a userProfile to administer it in the database
    var UserProfile = (function () {
        function UserProfile(obj) {
            this.id = "";
            this.assignedPermissions = [];
            this.current = true;
            this.dodaac = "";
            this.email = "";
            this.firstName = "";
            this.lastLoginDate = null;
            this.lastName = "";
            this.password = "";
            this.phoneNumbers = [];
            this.pkiDn = "";
            this.profileName = "";
            this.reasonForAccess = "";
            this.regionCode = "";
            this.registrationId = "";
            this.roles = [];
            this.serviceCode = "";
            this.userStatus = null;
            this.userType = null;
            this.id = obj && obj.id || "";
            this.assignedPermissions = obj && obj.assignedPermissions || [];
            this.current = obj && obj.current || true;
            this.dodaac = obj && obj.dodaac || "";
            this.email = obj && obj.email || "";
            this.firstName = obj && obj.firstName || "";
            this.lastLoginDate = obj && obj.lastLoginDate || null;
            this.lastName = obj && obj.lastName || "";
            this.password = obj && obj.password || "";
            this.phoneNumbers = obj && obj.phoneNumbers || [];
            this.pkiDn = obj && obj.pkiDn || "";
            this.profileName = obj && obj.profileName || "";
            this.reasonForAccess = obj && obj.reasonForAccess || "";
            this.regionCode = obj && obj.regionCode || "";
            this.registrationId = obj && obj.registrationId || "";
            this.roles = obj && obj.roles || [];
            this.serviceCode = obj && obj.serviceCode || "";
            this.userStatus = obj && obj.userStatus || null;
            this.userType = obj && obj.userType || null;
        }
        ;
        return UserProfile;
    }());
    exports.UserProfile = UserProfile;
});
//# sourceMappingURL=userProfile.model.js.map