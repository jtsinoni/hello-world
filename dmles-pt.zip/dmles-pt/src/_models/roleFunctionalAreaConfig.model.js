define(["require", "exports"], function (require, exports) {
    'use strict';
    var RoleFunctionalAreaConfig = (function () {
        function RoleFunctionalAreaConfig(obj) {
            this.id = "";
            this.option = "";
            this.displayName = "";
            this.id = obj && obj.id || "";
            this.option = obj && obj.option || "";
            this.displayName = obj && obj.displayName || "";
        }
        return RoleFunctionalAreaConfig;
    }());
    exports.RoleFunctionalAreaConfig = RoleFunctionalAreaConfig;
});
//# sourceMappingURL=roleFunctionalAreaConfig.model.js.map