define(["require", "exports"], function (require, exports) {
    'use strict';
    var FileUploadData = (function () {
        function FileUploadData(obj) {
            this.orgId = "";
            this.itemId = "";
            this.manufacturerName = "";
            this.description = "";
            this.catalogNumber = "";
            this.fileName = "";
            this.orgId = obj && obj.orgId || "";
            this.itemId = obj && obj.itemId || "";
            this.manufacturerName = obj && obj.manufacturerName || "";
            this.description = obj && obj.description || "";
            this.catalogNumber = obj && obj.catalogNumber || "";
            this.fileName = obj && obj.fileName || "";
        }
        FileUploadData.create = function (uploadFileInfo) {
            var obj = new FileUploadData();
            obj.orgId = uploadFileInfo.orgId;
            obj.itemId = uploadFileInfo.itemId;
            obj.manufacturerName = uploadFileInfo.manufacturerName;
            obj.description = uploadFileInfo.description;
            obj.catalogNumber = uploadFileInfo.catalogNumber;
            obj.fileName = uploadFileInfo.file.name;
            return obj;
        };
        ;
        return FileUploadData;
    }());
    exports.FileUploadData = FileUploadData;
});
//# sourceMappingURL=fileUploadData.model.js.map