define(["require", "exports"], function (require, exports) {
    'use strict';
    var FileRef = (function () {
        function FileRef(obj) {
            this.id = obj && obj.id || null;
            this.fileId = obj && obj.fileId || "";
            this.uploadDateTime = obj && obj.uploadDateTime || null;
            this.uploadedFileName = obj && obj.uploadedFileName || "";
            this.fileSize = obj && obj.fileSize || null;
            this.uploadedBy = obj && obj.uploadedBy || "";
        }
        return FileRef;
    }());
    exports.FileRef = FileRef;
});
//# sourceMappingURL=fileRef.model.js.map