define(["require", "exports", './comment.model', './corporateAddress.model', './customer.model', './dmlesPanelTableColumns.model', './organization.model'], function (require, exports, comment_model_1, corporateAddress_model_1, customer_model_1, dmlesPanelTableColumns_model_1, organization_model_1) {
    'use strict';
    var modelsModule = angular.module('Dmles.Models.Module', []);
    modelsModule.value('Comment', comment_model_1.Comment);
    modelsModule.value('CorporateAddress', corporateAddress_model_1.CorporateAddress);
    modelsModule.value('Customer', customer_model_1.Customer);
    modelsModule.value('DmlesPanelTableColumns', dmlesPanelTableColumns_model_1.DmlesPanelTableColumns);
    modelsModule.value('Organization', organization_model_1.Organization);
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = modelsModule;
});
//# sourceMappingURL=module.js.map