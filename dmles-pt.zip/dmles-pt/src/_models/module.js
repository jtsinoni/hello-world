define(["require", "exports", './attachment.model', './categoryConfiguration.model', './categoryOption.model', './comment.model', './corporateAddress.model', './customer.model', './dmlesPanelTableColumns.model', './facetConfiguration.model', './facetOption.model', './fileRef.model', './organization.model', './node.model', './note.model'], function (require, exports, attachment_model_1, categoryConfiguration_model_1, categoryOption_model_1, comment_model_1, corporateAddress_model_1, customer_model_1, dmlesPanelTableColumns_model_1, facetConfiguration_model_1, facetOption_model_1, fileRef_model_1, organization_model_1, node_model_1, note_model_1) {
    'use strict';
    var modelsModule = angular.module('Dmles.Models.Module', []);
    modelsModule.value('Attachment', attachment_model_1.Attachment);
    modelsModule.value('CategoryConfiguration', categoryConfiguration_model_1.CategoryConfiguration);
    modelsModule.value('CategoryOption', categoryOption_model_1.CategoryOption);
    modelsModule.value('Comment', comment_model_1.Comment);
    modelsModule.value('CorporateAddress', corporateAddress_model_1.CorporateAddress);
    modelsModule.value('Customer', customer_model_1.Customer);
    modelsModule.value('DmlesPanelTableColumns', dmlesPanelTableColumns_model_1.DmlesPanelTableColumns);
    modelsModule.value('FacetConfiguration', facetConfiguration_model_1.FacetConfiguration);
    modelsModule.value('FacetOption', facetOption_model_1.FacetOption);
    modelsModule.value('FileRef', fileRef_model_1.FileRef);
    modelsModule.value('Organization', organization_model_1.Organization);
    modelsModule.value('Node', node_model_1.Node);
    modelsModule.value('Note', note_model_1.Note);
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = modelsModule;
});
//# sourceMappingURL=module.js.map