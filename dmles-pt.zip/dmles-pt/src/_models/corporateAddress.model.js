define(["require", "exports"], function (require, exports) {
    'use strict';
    var CorporateAddress = (function () {
        function CorporateAddress(obj) {
            this.addressLine1 = obj && obj.addressLine1 || "";
            this.addressLine2 = obj && obj.addressLine2 || "";
            this.city = obj && obj.city || "";
            this.state = obj && obj.state || "";
            this.country = obj && obj.country || "";
            this.zipCode = obj && obj.zipCode || "";
        }
        ;
        return CorporateAddress;
    }());
    exports.CorporateAddress = CorporateAddress;
});
//# sourceMappingURL=corporateAddress.model.js.map