define(["require", "exports"], function (require, exports) {
    'use strict';
    var Permission = (function () {
        function Permission(obj) {
            this.id = "";
            this.name = "";
            this.description = "";
            this.functionalArea = "";
            this.active = true;
            this.id = obj && obj.id || "";
            this.name = obj && obj.name || "";
            this.description = obj && obj.description || "";
            this.functionalArea = obj && obj.functionalArea || "";
            this.active = obj && obj.active || true;
        }
        return Permission;
    }());
    exports.Permission = Permission;
});
//# sourceMappingURL=permission.model.js.map