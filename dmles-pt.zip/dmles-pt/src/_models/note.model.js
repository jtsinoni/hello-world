define(["require", "exports"], function (require, exports) {
    'use strict';
    var Note = (function () {
        function Note(obj) {
            this.noteText = obj && obj.noteText || "";
            this.section = obj && obj.section || "";
            this.firstName = obj && obj.firstName || "";
            this.lastName = obj && obj.lastName || "";
            this.dateCreated = obj && obj.dateCreated || null;
        }
        ;
        return Note;
    }());
    exports.Note = Note;
});
//# sourceMappingURL=note.model.js.map