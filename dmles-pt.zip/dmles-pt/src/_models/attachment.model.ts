'use strict';
import {FileRef} from "./fileRef.model";

export class Attachment {
    public description:string;
    public fileRef: FileRef;
    public section: string;


    constructor();
    constructor(obj:Attachment);
    constructor(obj?:any) {
        this.description = obj && obj.description || "";
        this.fileRef = obj && obj.fileRef || null;
        this.section = obj && obj.section || "";
    }
}