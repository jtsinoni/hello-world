'use strict;'

import {UploadFile} from "./uploadFile.model";

export class UploadFileInformation {
    public requestId:string;
    public orgId:string = "";
    public itemId:string = "";
    public catalogNumber:string = "";
    public manufacturerName:string = "";
    public description:string = "";
    public file:UploadFile = new UploadFile();

    constructor();
    constructor(obj:UploadFileInformation);
    constructor(obj?:any) {
        this.requestId = obj && obj.id || "";
        this.orgId = obj && obj.orgId || "";
        this.itemId = obj && obj.itemId || "";
        this.catalogNumber = obj && obj.catalogNumber || "";
        this.manufacturerName = obj && obj.manufacturerName || "";
        this.description = obj && obj.description || "";
        this.file = obj && obj.file || new UploadFile();
    };
}
