define(["require", "exports"], function (require, exports) {
    'use strict';
    var CategoryConfiguration = (function () {
        function CategoryConfiguration(obj) {
            this.displayLabel = "";
            this.aggregationIdentifiers = [];
            this.elasticSearchFieldNames = [];
            this.initializeAsCollapsed = false;
            this.topLevelInitialCategoryOptions = [];
            this.displayLabel = obj && obj.displayLabel || "";
            this.aggregationIdentifiers = obj && obj.aggregationIdentifiers || [];
            this.elasticSearchFieldNames = obj && obj.elasticSearchFieldNames || [];
            this.initializeAsCollapsed = obj && obj.initializeAsCollapsed || false;
            this.topLevelInitialCategoryOptions = obj && obj.topLevelInitialCategoryOptions || [];
        }
        ;
        return CategoryConfiguration;
    }());
    exports.CategoryConfiguration = CategoryConfiguration;
});
//# sourceMappingURL=categoryConfiguration.model.js.map