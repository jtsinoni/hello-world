'use strict';

export class Organization {
    public id:any;
    public organizationID:string;
    public organizationOrgName:string;
    public organizationSerial:string;

    constructor();
    constructor(obj:Organization);
    constructor(obj?:any) {
        this.id = obj && obj.id || "";
        this.organizationID = obj && obj.organizationID || "";
        this.organizationOrgName = obj && obj.organizationOrgName || "";
        this.organizationSerial = obj && obj.organizationSerial || "";
    };

}
