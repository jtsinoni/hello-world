'use strict';

export class FacetConfiguration {
    public displayLabel: string = "";
    public aggregationIdentifier: string = "";
    public elasticSearchFieldName: string = "";
    public initializeAsCollapsed: boolean = false;
    public isDisplayed: boolean = true;

    constructor();
    constructor(obj: FacetConfiguration);
    constructor(obj?: any) {
        this.displayLabel = obj && obj.displayLabel || "";
        this.aggregationIdentifier = obj && obj.aggregationIdentifier || "";
        this.elasticSearchFieldName = obj && obj.elasticSearchFieldName || "";
        this.initializeAsCollapsed = obj && obj.initializeAsCollapsed || false;
        this.isDisplayed = obj && obj.isDisplayed || true;
    };
}
