define(["require", "exports"], function (require, exports) {
    'use strict';
    var Comment = (function () {
        function Comment(obj) {
            this.id = obj && obj.id || "";
            this.comment = obj && obj.comment || "";
            this.created = obj && obj.created || null;
            this.firstName = obj && obj.firstName || "";
            this.lastName = obj && obj.lastName || "";
        }
        ;
        return Comment;
    }());
    exports.Comment = Comment;
});
//# sourceMappingURL=comment.model.js.map