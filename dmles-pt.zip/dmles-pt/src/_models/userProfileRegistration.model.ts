'use strict';
import {RealEstateSite} from "../login/register/_models/realEstateSite.model";

// model that contains the information that a User Administrator would 
// need to know about a userProfile to administer it in the database

export class UserProfileRegistration {
    public id: any = null;
    public accessApprovedDate: Date = null;
    public accessDeniedDate: Date = null;
    public adminNotes: string = "";
    public dodaac: string = "";
    public email: string = "";
    public firstName: string = "";
    public lastName: string = "";
    public phoneNumbers: Array<any> = [];
    public pkiDn: string = "";
    public reasonForAccess: string = "";
    public regionCode: string = "";
    public serviceCode: string = "";
    public userProfileId: string = "";
    public userStatus: any = null;
    public userType: any = null;
    public appProfileType: string = "";
    public realEstateSite: RealEstateSite;

    constructor();
    constructor(obj: UserProfileRegistration);
    constructor(obj?: any) {
        this.id = obj && obj.id || null;
        this.accessApprovedDate = obj && obj.accessApprovedDate || null;
        this.accessDeniedDate = obj && obj.accessDeniedDate || null;
        this.adminNotes = obj && obj.adminNotes || "";
        this.dodaac = obj && obj.dodaac || "";
        this.email = obj && obj.email || "";
        this.firstName = obj && obj.firstName || "";
        this.lastName = obj && obj.lastName || "";
        this.phoneNumbers = obj && obj.phoneNumbers || [];
        this.pkiDn = obj && obj.pkiDn || "";
        this.reasonForAccess = obj && obj.reasonForAccess || "";
        this.regionCode = obj && obj.regionCode || "";
        this.serviceCode = obj && obj.serviceCode || "";
        this.userProfileId = obj && obj.userProfileId || "";
        this.userStatus = obj && obj.userStatus || null;
        this.userType = obj && obj.userType || null;
        this.appProfileType = obj && obj.appProfileType || "";
        this.realEstateSite = obj && obj.realEstateSite || new RealEstateSite();
    };
}
