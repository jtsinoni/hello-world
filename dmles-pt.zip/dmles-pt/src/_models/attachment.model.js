define(["require", "exports"], function (require, exports) {
    'use strict';
    var Attachment = (function () {
        function Attachment(obj) {
            this.description = obj && obj.description || "";
            this.fileRef = obj && obj.fileRef || null;
            this.section = obj && obj.section || "";
        }
        return Attachment;
    }());
    exports.Attachment = Attachment;
});
//# sourceMappingURL=attachment.model.js.map