define(["require", "exports"], function (require, exports) {
    'use strict';
    var Person = (function () {
        function Person(obj) {
            this.defaultDodaac = obj && obj.defaultDodaac || "";
            this.email = obj && obj.email || "";
            this.userId = obj && obj.userId || "";
            this.firstName = obj && obj.firstName || "";
            this.lastName = obj && obj.lastName || "";
            this.phoneNumber = obj && obj.phoneNumber || "";
        }
        ;
        return Person;
    }());
    exports.Person = Person;
});
//# sourceMappingURL=person.model.js.map