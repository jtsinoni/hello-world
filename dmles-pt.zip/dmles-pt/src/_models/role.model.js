define(["require", "exports"], function (require, exports) {
    'use strict';
    var Role = (function () {
        function Role(obj) {
            this.id = "";
            this.name = "";
            this.description = "";
            this.functionalArea = "";
            this.assignedPermissions = [];
            this.systemRole = false;
            this.isActive = true;
            this.id = obj && obj.id || "";
            this.name = obj && obj.name || "";
            this.description = obj && obj.description || "";
            this.functionalArea = obj && obj.functionalArea || "";
            this.assignedPermissions = obj && obj.assignedPermissions || [];
            this.systemRole = obj && obj.systemRole || false;
            this.isActive = obj && obj.isActive || false;
        }
        return Role;
    }());
    exports.Role = Role;
});
//# sourceMappingURL=role.model.js.map