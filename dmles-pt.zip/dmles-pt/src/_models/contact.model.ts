export class Contact {
    public firstName:String;
    public lastName:String;
    public title:String;
    public mobilePhone:String;
    public workPhone:String;
    public email:String;
    public website:String;

}

