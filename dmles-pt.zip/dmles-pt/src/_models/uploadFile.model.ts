'use strict';

export class UploadFile {
    public name:string = "";
    public size:Number = 0;
    public date:Date = new Date();
    public contents:any = null;

    constructor();
    constructor(obj:UploadFile);
    constructor(obj?:any) {
        this.name = obj && obj.title || "";
        this.size = obj && obj.size || 0;
        this.date = obj && obj.date || new Date();
        this.contents = obj && obj.contents || null;
    };
}