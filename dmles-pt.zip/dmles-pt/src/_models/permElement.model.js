define(["require", "exports"], function (require, exports) {
    'use strict';
    var PermElement = (function () {
        function PermElement(obj) {
            this.id = "";
            this.name = "";
            this.id = obj && obj.id || "";
            this.name = obj && obj.name || "";
        }
        return PermElement;
    }());
    exports.PermElement = PermElement;
});
//# sourceMappingURL=permElement.model.js.map