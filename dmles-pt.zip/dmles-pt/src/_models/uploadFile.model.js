define(["require", "exports"], function (require, exports) {
    'use strict';
    var UploadFile = (function () {
        function UploadFile(obj) {
            this.name = "";
            this.size = 0;
            this.date = new Date();
            this.contents = null;
            this.name = obj && obj.title || "";
            this.size = obj && obj.size || 0;
            this.date = obj && obj.date || new Date();
            this.contents = obj && obj.contents || null;
        }
        ;
        return UploadFile;
    }());
    exports.UploadFile = UploadFile;
});
//# sourceMappingURL=uploadFile.model.js.map