define(["require", "exports"], function (require, exports) {
    'use strict';
    var Site = (function () {
        function Site(obj) {
            this.id = "";
            this.dodaac = "";
            this.name = "";
            this.description = "";
            this.service = null;
            this.region = "";
            this.active = true;
            this.enabled = true;
            this.dmlesEnabled = true;
            this.id = obj && obj.id || "";
            this.dodaac = obj && obj.dodaac || "";
            this.name = obj && obj.name || "";
            this.description = obj && obj.description || "";
            this.service = obj && obj.service || null;
            this.region = obj && obj.region || "";
            this.active = obj && obj.active || true;
            this.enabled = obj && obj.enabled || true;
            this.dmlesEnabled = obj && obj.dmlesEnabled || true;
        }
        return Site;
    }());
    exports.Site = Site;
});
//# sourceMappingURL=site.model.js.map