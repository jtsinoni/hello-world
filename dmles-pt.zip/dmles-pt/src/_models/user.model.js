define(["require", "exports"], function (require, exports) {
    'use strict';
    var User = (function () {
        function User(obj) {
            this.accessApprovedDate = null;
            this.createdDate = null;
            this.defaultDodaac = null;
            this.dodaacs = [];
            this.email = "";
            this.id = "";
            this.isActive = true;
            this.firstName = "";
            this.lastName = "";
            this.password = "";
            this.phoneNumbers = [];
            this.notesAccess = "";
            this.notesAdmin = "";
            this.organizations = [];
            this.region = null;
            this.roles = [];
            this.service = null;
            this.updatedDate = null;
            this.userType = "";
            this.accessApprovedDate = obj && obj.accessApprovedDate || null;
            this.createdDate = obj && obj.createdDate || null;
            this.defaultDodaac = obj && obj.defaultDodaac || null;
            this.dodaacs = obj && obj.dodaacs || [];
            this.email = obj && obj.email || "";
            this.id = obj && obj.id || "";
            this.isActive = obj && obj.isActive || true;
            this.firstName = obj && obj.firstName || "";
            this.lastName = obj && obj.lastName || "";
            this.organizations = obj && obj.organizations || [];
            this.password = obj && obj.password || "";
            this.phoneNumbers = obj && obj.phoneNumbers || [];
            this.notesAccess = obj && obj.notesAccess || "";
            this.notesAdmin = obj && obj.notesAdmin || "";
            this.region = obj && obj.region || null;
            this.roles = obj && obj.roles || [];
            this.service = obj && obj.service || null;
            this.updatedDate = obj && obj.updatedDate || null;
            this.userType = obj && obj.userType || "";
        }
        ;
        return User;
    }());
    exports.User = User;
});
//# sourceMappingURL=user.model.js.map