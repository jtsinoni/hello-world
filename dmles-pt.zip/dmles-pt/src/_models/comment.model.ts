'use strict';

export class Comment {
    public id:string;
    public comment:string;
    public created: Date;
    public firstName:string;
    public lastName:string;

    constructor();
    constructor(obj:Comment);
    constructor(obj?:any) {
        this.id = obj && obj.id || "";
        this.comment = obj && obj.comment || "";
        this.created = obj && obj.created || null;
        this.firstName = obj && obj.firstName || "";
        this.lastName = obj && obj.lastName || "";
    };

}
