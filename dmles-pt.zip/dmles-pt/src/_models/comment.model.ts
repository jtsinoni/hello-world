'use strict';

export class Comment {
    public id:string;
    public comment:string;
    public created: Date;
    public nameFirst:string;
    public nameLast:string;

    constructor();
    constructor(obj:Comment);
    constructor(obj?:any) {
        this.id = obj && obj.id || "";
        this.comment = obj && obj.comment || "";
        this.created = obj && obj.created || null;
        this.nameFirst = obj && obj.nameFirst || "";
        this.nameLast = obj && obj.nameLast || "";
    };

}
