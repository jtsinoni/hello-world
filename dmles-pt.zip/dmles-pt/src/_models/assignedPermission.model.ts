'use strict';

export class AssignedPermission {
    public id:any = "";
    public name:string = "";
    public description:string = "";
    public functionalArea:string = "";
    public allowed:Boolean = false;
    public denied:Boolean = false;
    public permission:any = null;


    constructor();
    constructor(obj:AssignedPermission);
    constructor(obj?:any) {
        this.id = obj && obj.id || "";
        this.name = obj && obj.name || "";
        this.description = obj && obj.description || "";
        this.functionalArea = obj && obj.functionalArea || "";
        this.allowed = obj && obj.allowed || false;
        this.denied = obj && obj.denied || false;
        this.permission = obj && obj.permission || null;
    }
}