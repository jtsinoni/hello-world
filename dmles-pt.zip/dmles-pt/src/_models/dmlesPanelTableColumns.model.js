define(["require", "exports"], function (require, exports) {
    'use strict';
    var DmlesPanelTableColumns = (function () {
        function DmlesPanelTableColumns(obj) {
            this.filter = null;
            this.filterData = null;
            this.title = obj && obj.title || "";
            this.field = obj && obj.field || "";
            this.show = obj && obj.show || true;
            this.sortable = obj && obj.sortable || "";
            this.type = obj && obj.type || "text";
            if (obj.filter) {
                this.filter = obj && obj.filter || null;
            }
            if (obj.filterData) {
                this.filterData = obj && obj.filterData || null;
            }
        }
        return DmlesPanelTableColumns;
    }());
    exports.DmlesPanelTableColumns = DmlesPanelTableColumns;
});
//# sourceMappingURL=dmlesPanelTableColumns.model.js.map