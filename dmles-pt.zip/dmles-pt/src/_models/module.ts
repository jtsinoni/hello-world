'use strict';

import {Comment} from './comment.model';
import {CorporateAddress} from './corporateAddress.model';
import {Customer} from './customer.model';
import {DmlesPanelTableColumns} from './dmlesPanelTableColumns.model';
import {Organization} from './organization.model';
import {Node} from './node.model';

var modelsModule = angular.module('Dmles.Models.Module', []);
modelsModule.value('Comment', Comment);
modelsModule.value('CorporateAddress', CorporateAddress);
modelsModule.value('Customer', Customer);
modelsModule.value('DmlesPanelTableColumns', DmlesPanelTableColumns);
modelsModule.value('Organization', Organization);
modelsModule.value('Node', Node);

export default modelsModule;