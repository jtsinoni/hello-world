'use strict';

import {Attachment} from './attachment.model';
import {CategoryConfiguration} from './categoryConfiguration.model';
import {CategoryOption} from './categoryOption.model';
import {Comment} from './comment.model';
import {CorporateAddress} from './corporateAddress.model';
import {Customer} from './customer.model';
import {DmlesPanelTableColumns} from './dmlesPanelTableColumns.model';
import {FacetConfiguration} from './facetConfiguration.model';
import {FacetOption} from './facetOption.model';
import {FileRef} from './fileRef.model';
import {Organization} from './organization.model';
import {Node} from './node.model';
import {Note} from './note.model';
import {NodeTypeRef} from './nodeTypeRef.model';
import {NewUserProfile} from './newUserProfile.model';
import {Invitation} from './invitation.model';

var modelsModule = angular.module('Dmles.Models.Module', []);
modelsModule.value('Attachment', Attachment);
modelsModule.value('CategoryConfiguration', CategoryConfiguration);
modelsModule.value('CategoryOption', CategoryOption);
modelsModule.value('Comment', Comment);
modelsModule.value('CorporateAddress', CorporateAddress);
modelsModule.value('Customer', Customer);
modelsModule.value('DmlesPanelTableColumns', DmlesPanelTableColumns);
modelsModule.value('FacetConfiguration', FacetConfiguration);
modelsModule.value('FacetOption', FacetOption);
modelsModule.value('FileRef', FileRef);
modelsModule.value('Organization', Organization);
modelsModule.value('Node', Node);
modelsModule.value('Note', Note);
modelsModule.value('NewUserProfile', NewUserProfile);
modelsModule.value('NodeTypeRef', NodeTypeRef);
modelsModule.value('Invitation', Invitation);

export default modelsModule;