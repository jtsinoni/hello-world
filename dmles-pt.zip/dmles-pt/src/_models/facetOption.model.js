define(["require", "exports"], function (require, exports) {
    'use strict';
    var FacetOption = (function () {
        function FacetOption(obj) {
            this.type = "";
            this.value = "";
            this.count = 0;
            this.selected = false;
            this.type = obj && obj.type || "";
            this.value = obj && obj.value || "";
            this.count = obj && obj.value || 0;
            this.selected = obj && obj.selected || false;
        }
        ;
        return FacetOption;
    }());
    exports.FacetOption = FacetOption;
});
//# sourceMappingURL=facetOption.model.js.map