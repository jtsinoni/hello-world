'use strict';
export class Role {
    public id:any = "";
    public name:string = "";
    public assignedPermissions:Array<any> = [];
    public roles:Array<any> = [];
    public nodeTypeRefs:Array<any> = [];
    public functionalArea:string = "";
    public description:string = "";
    public updatedDate: Date = null;
    public updatedBy: string = "";
    public systemRole:boolean = false;
    public isActive:boolean = true;

    constructor();
    constructor(obj:Role);
    constructor(obj?:any) {
        this.id = obj && obj.id || "";
        this.name = obj && obj.name || "";
        this.assignedPermissions = obj && obj.assignedPermissions || [];
        this.roles = obj && obj.roles || [];
        this.nodeTypeRefs = obj && obj.nodeTypeRefs || [];
        this.functionalArea = obj && obj.functionalArea || "";
        this.description = obj && obj.description || "";
        this.updatedDate = obj && obj.updatedDate || null;
        this.updatedBy = obj && obj.updatedBy || "";
        this.systemRole = obj && obj.systemRole || false;
        this.isActive = obj && obj.isActive || false;
    }
}