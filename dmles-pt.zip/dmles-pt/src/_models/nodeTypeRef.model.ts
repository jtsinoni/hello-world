'use strict';

export class NodeTypeRef {
    public id:any = "";
    public name:string = "";


    constructor();
    constructor(obj:NodeTypeRef);
    constructor(obj?:any) {
        this.id = obj && obj.id || "";
        this.name = obj && obj.name || "";
    }
}
