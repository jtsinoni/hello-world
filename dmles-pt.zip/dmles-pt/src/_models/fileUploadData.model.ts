'use strict';

import {UploadFileInformation} from "./uploadFileInformation.model";

export class FileUploadData {
    public orgId:string = "";
    public itemId:string = "";
    public manufacturerName:string = "";
    public description:string = "";
    public catalogNumber:string = "";
    public fileName:string = "";

    public static create(uploadFileInfo:UploadFileInformation):FileUploadData {
        var obj:FileUploadData = new FileUploadData();
        obj.orgId = uploadFileInfo.orgId;
        obj.itemId = uploadFileInfo.itemId;
        obj.manufacturerName = uploadFileInfo.manufacturerName;
        obj.description = uploadFileInfo.description;
        obj.catalogNumber = uploadFileInfo.catalogNumber;
        obj.fileName = uploadFileInfo.file.name;
        return obj;
    }

    constructor();
    constructor(obj:FileUploadData);
    constructor(obj?:any) {
        this.orgId = obj && obj.orgId || "";
        this.itemId = obj && obj.itemId || "";
        this.manufacturerName = obj && obj.manufacturerName || "";
        this.description = obj && obj.description || "";
        this.catalogNumber = obj && obj.catalogNumber || "";
        this.fileName = obj && obj.fileName || "";
    };
}