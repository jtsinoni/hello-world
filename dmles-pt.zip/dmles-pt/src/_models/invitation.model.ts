'use strict';

export class Invitation {
    public id:string;
    public acceptedDate:Date;
    public deniedDate:Date;
    public expirationDate:Date;
    public sentDate:Date;

    constructor();
    constructor(obj:Invitation);
    constructor(obj?:any) {
        this.id = obj && obj.id || "";
        this.acceptedDate = obj && obj.acceptedDate || null;
        this.deniedDate = obj && obj.deniedDate || null;
        this.expirationDate = obj && obj.expirationDate || null;
        this.sentDate = obj && obj.sentDate || null;
    };

}


