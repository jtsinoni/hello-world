define(["require", "exports"], function (require, exports) {
    'use strict';
    var AssignedPermission = (function () {
        function AssignedPermission(obj) {
            this.id = "";
            this.name = "";
            this.description = "";
            this.functionalArea = "";
            this.allowed = false;
            this.denied = false;
            this.permission = null;
            this.id = obj && obj.id || "";
            this.name = obj && obj.name || "";
            this.description = obj && obj.description || "";
            this.functionalArea = obj && obj.functionalArea || "";
            this.allowed = obj && obj.allowed || false;
            this.denied = obj && obj.denied || false;
            this.permission = obj && obj.permission || null;
        }
        return AssignedPermission;
    }());
    exports.AssignedPermission = AssignedPermission;
});
//# sourceMappingURL=assignedPermission.model.js.map