'use strict';

export class Site {
    public id:any = "";
    public dodaac:string = "";
    public name:string = "";
    public description:string = "";
    public service:any = null;
    public region:string = "";
    public active:Boolean = true;
    public enabled:Boolean = true;
    public dmlesEnabled:Boolean = true;   

    constructor();
    constructor(obj:Site);
    constructor(obj?:any) {
        this.id = obj && obj.id || "";
        this.dodaac = obj && obj.dodaac || "";
        this.name = obj && obj.name || "";
        this.description = obj && obj.description || "";
        this.service = obj && obj.service || null;
        this.region = obj && obj.region || "";
        this.active = obj && obj.active || true;
        this.enabled = obj && obj.enabled || true;
        this.dmlesEnabled = obj && obj.dmlesEnabled || true;        
    }
}