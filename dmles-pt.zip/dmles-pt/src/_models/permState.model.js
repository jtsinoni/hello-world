define(["require", "exports"], function (require, exports) {
    'use strict';
    var PermState = (function () {
        function PermState(obj) {
            this.id = "";
            this.name = "";
            this.id = obj && obj.id || "";
            this.name = obj && obj.name || "";
        }
        return PermState;
    }());
    exports.PermState = PermState;
});
//# sourceMappingURL=permState.model.js.map