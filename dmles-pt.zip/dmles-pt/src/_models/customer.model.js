define(["require", "exports"], function (require, exports) {
    'use strict';
    var Customer = (function () {
        function Customer(obj) {
            this.id = obj && obj.id || "";
            this.custodianFirstName = obj && obj.custodianFirstName || "";
            this.custodianLastName = obj && obj.custodianLastName || "";
            this.custodianPhoneNum = obj && obj.custodianPhoneNum || "";
            this.customerID = obj && obj.customerID || "";
            this.customerName = obj && obj.customerName || "";
            this.customerSerial = obj && obj.customerSerial || "";
        }
        ;
        return Customer;
    }());
    exports.Customer = Customer;
});
//# sourceMappingURL=customer.model.js.map