define(["require", "exports"], function (require, exports) {
    'use strict';
    // TODO: Once the permission's collection has been made, these should be pulled from that
    // collection and then, used appropriately.
    var ResourceConstants = (function () {
        function ResourceConstants() {
            //no-op
        }
        ResourceConstants.ALL = 'all';
        ResourceConstants.CATALOG_VIEW = 'equip-catalog';
        ResourceConstants.EQUIP_REQUESTS_VIEW = 'requests-service';
        ResourceConstants.EQUIP_REQUESTS_MY_REQUESTS = 'equip-my-requests';
        ResourceConstants.EQUIP_REQUESTS_CREATE = 'equip-request-create';
        ResourceConstants.EQUIP_REQUESTS_FACILITIES = 'equip-request-facilities';
        ResourceConstants.EQUIP_REQUESTS_MAINTENANCE = 'equip-request-maintenance';
        ResourceConstants.EQUIP_REQUESTS_SAFETY = 'equip-request-safety';
        ResourceConstants.EQUIP_REQUESTS_TECHNOLOGY = 'equip-request-technology';
        ResourceConstants.EQUIP_REQUESTS_WEIGHIN = 'equip-request-weighin';
        ResourceConstants.EQUIP_REQUESTS_UPDATE = 'equip-update';
        ResourceConstants.EQUIP_RECORDS_VIEW = 'equip-records';
        ResourceConstants.EQUIP_RECORD_DATA_MANAGEMENT = 'record-data-management';
        ResourceConstants.PERMISSION_MANAGEMENT = 'permission-management';
        ResourceConstants.ROLE_MANAGEMENT = 'role-management';
        ResourceConstants.USER_PROFILE_MANAGEMENT = 'user-profile-management';
        ResourceConstants.VIEW_ALL_REQUESTS = 'view-all-requests';
        ResourceConstants.WORKFLOW_MANAGEMENT = 'workflow-management';
        ResourceConstants.JMAR_VIEW = 'jmar';
        return ResourceConstants;
    }());
    exports.ResourceConstants = ResourceConstants;
});
//# sourceMappingURL=resource.constants.js.map