define(["require", "exports"], function (require, exports) {
    "use strict";
    // TODO: Once the permission's collection has been made, these should be pulled from that
    // collection and then, used appropriately.
    var ResourceConstants = (function () {
        function ResourceConstants() {
            //no-op
        }
        ResourceConstants.ABI = 'abi';
        ResourceConstants.ALL = 'all';
        ResourceConstants.ASSET_MANAGEMENT_VIEW = 'asset-management-view';
        ResourceConstants.ASSET_MANAGEMENT_MAIN_VIEW = 'asset-management-main-view';
        ResourceConstants.ASSET_MANAGEMENT_MEDICAL_EQUIPMENT_VIEW = 'asset-management-medical-equipment-view';
        ResourceConstants.ASSET_MANAGEMENT_REAL_PROPERTY_INSTALLED_VIEW = 'asset-management-real-property-installed-view';
        ResourceConstants.ASSET_MANAGEMENT_UPLOAD_COBIE_FILE_VIEW = 'asset-management-upload-cobie-file-view';
        ResourceConstants.BUYER_VIEW = 'buyer-view';
        ResourceConstants.BUYER_PURCHASES_VIEW = 'buyer-purchases-view';
        ResourceConstants.BUYER_REQUISITION_VIEW = 'buyer-requisition-view';
        ResourceConstants.BUYER_RECEIPTS_VIEW = 'buyer-receipts-view';
        ResourceConstants.BUYER_ORDER_STATUS_VIEW = 'buyer-order-status-view';
        ResourceConstants.CATALOG_VIEW = 'equip-catalog';
        ResourceConstants.CUSTOMER_CATALOG_VIEW = 'customer-catalog-view';
        ResourceConstants.EQUIP_REQUESTS_VIEW = 'requests-service';
        ResourceConstants.EQUIP_REQUESTS_MY_REQUESTS = 'equip-my-requests';
        ResourceConstants.EQUIP_REQUESTS_CREATE = 'equip-request-create';
        ResourceConstants.EQUIP_REQUESTS_FACILITIES = 'equip-request-facilities';
        ResourceConstants.EQUIP_REQUESTS_MAINTENANCE = 'equip-request-maintenance';
        ResourceConstants.EQUIP_REQUESTS_SAFETY = 'equip-request-safety';
        ResourceConstants.EQUIP_REQUESTS_TECHNOLOGY = 'equip-request-technology';
        ResourceConstants.EQUIP_REQUESTS_REVIEW = 'equip-request-review';
        ResourceConstants.EQUIP_REQUESTS_UPDATE = 'equip-update';
        ResourceConstants.EQUIP_RECORDS_VIEW = 'equip-records';
        ResourceConstants.EQUIP_RECORD_DATA_MANAGEMENT = 'record-data-management';
        ResourceConstants.FIN_LANDING_VIEW = 'finance-landing';
        ResourceConstants.FIN_APPROPRIATIONS_VIEW = 'finance-landing';
        ResourceConstants.INVENTORY_RECORD_VIEW = 'inventory-record-view';
        ResourceConstants.INVENTORY_PHYSICAL_VIEW = 'inventory-physical-view';
        ResourceConstants.INVENTORY_STORAGE_VIEW = 'inventory-storage-view';
        ResourceConstants.INVENTORY_GAIN_LOSS_VIEW = 'inventory-gain-loss-view';
        ResourceConstants.INVENTORY_TRANSFER_VIEW = 'inventory-transfer-view';
        ResourceConstants.PERMISSION_MANAGEMENT = 'permission-management';
        ResourceConstants.ROLE_MANAGEMENT = 'role-management';
        ResourceConstants.SELLER_VIEW = 'seller-view';
        ResourceConstants.SELLER_FULFILLMENT_VIEW = 'seller-fulfillment-view';
        ResourceConstants.SELLER_BACK_ORDER_STATUS_VIEW = 'seller-back-order-status-view';
        ResourceConstants.USER_PROFILE_MANAGEMENT = 'user-profile-management';
        ResourceConstants.VIEW_ALL_REQUESTS = 'view-all-requests';
        ResourceConstants.WORKFLOW_MANAGEMENT = 'workflow-management';
        ResourceConstants.ORGANIZATION_MANAGEMENT = 'organization-management';
        ResourceConstants.REAL_ESTATE_INSTALLATION_RECORD_VIEW = 'real-estate-installation-view';
        ResourceConstants.REAL_ESTATE_INSTALLATION_SITE_RECORD_VIEW = 'real-estate-site-view';
        ResourceConstants.BUYER_DETAIL_VIEW = 'buyer-main';
        ResourceConstants.BUYER_LOOKUP_VIEW = 'buyer-lookup';
        // SES - not sure about this
        ResourceConstants.MANAGE_ABI_STAGING = 'manage-abi-staging';
        ResourceConstants.MANAGE_ABI_MOVE_TO_PRODUCTION = 'manage-abi-move-to-production';
        ResourceConstants.MANAGE_ABI_DELTA = 'manage-abi-delta';
        return ResourceConstants;
    }());
    exports.ResourceConstants = ResourceConstants;
});
//# sourceMappingURL=resource.constants.js.map