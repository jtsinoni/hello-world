define(["require", "exports"], function (require, exports) {
    'use strict';
    var ContentConstants = (function () {
        function ContentConstants() {
        }
        ContentConstants.ACCESS_ALL = 'Admin';
        ContentConstants.COMMENT_SUCCESSFULL_DELETE = "Comment Successfully deleted.";
        ContentConstants.DATE_TIME = 'dd MMM yyyy HH:mm:ss';
        ContentConstants.DODAAC_COMPARE_FIELD = 'dodaac';
        ContentConstants.EMPLOYEE_EMAIL_COMPARE_FIELD = 'email';
        ContentConstants.ERR_MSG = 'An error occurred, please try again later. If this error persists, contact the system admin.';
        ContentConstants.EVENT_ITEMS_IN_CART = 'eventItemsInCart';
        ContentConstants.EVENT_USER_UPDATE = 'eventUserUpdate';
        ContentConstants.FORMAT_DATE = 'dd MMM yyyy';
        ContentConstants.FORMAT_DATE_TIME = 'dd MMM yyyy HH:mm:ss';
        ContentConstants.MANUFACTURER_SITE_ID = 'DMLSS';
        ContentConstants.ORDER_REQ_TYPE_CATALOG = 'CATALOG';
        ContentConstants.ORDER_REQ_TYPE_NEW_ITEM = 'NEW_ITEM';
        ContentConstants.REGEX_EMAIL = '/^[_a-z0-9]+(\.[_a-z0-9]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/';
        ContentConstants.REGEX_PHONE = '/\d{3}-\d{3}-\d{4}/';
        ContentConstants.ROLE_COMPARE_FIELD = 'name';
        ContentConstants.SELECTED = 'SELECTED';
        ContentConstants.SEARCH_MAX = 250;
        ContentConstants.UNREGISTERED_USER = 'UnregisteredUser';
        return ContentConstants;
    }());
    exports.ContentConstants = ContentConstants;
});
//# sourceMappingURL=content.constants.js.map