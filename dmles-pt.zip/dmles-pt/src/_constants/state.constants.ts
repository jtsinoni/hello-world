export class StateConstants {
    static SECURITY:string         = 'dmles.security';
    static LOGIN_SHELL:string      = 'dmles.login';
    static LOGIN:string            = 'dmles.login.form';
    static REGISTER:string         = 'dmles.login.form.register';
    static REGISTER_CONFIRM:string = 'dmles.login.form.register.confirmation';
    static ACCESSIBILITY:string    = 'dmles.login.form.accessibility';

    static HOME_ROOT:string                  = 'dmles.home';
    static ABOUT:string                      = 'dmles.home.about';
    static HELP:string                       = 'dmles.home.help';
    static MY_DASHBOARD:string               = 'dmles.home.dashboard';
    static USER_PROFILE:string               = 'dmles.home.userProfile';
    static USER_PROFILE_EDIT_GEN_INFO:string = 'dmles.home.userProfile.editGenInfoUserProfile';

    static ABI_SHELL:string                                 = 'dmles.home.abi';
    static ABI_SEARCH:string                                = 'dmles.home.abi.search';
    static ABI_SEARCH_HELP:string                           = 'dmles.home.abi.search.help';
    static ABI_PREFERRED_PRODUCT:string                     = 'dmles.home.abi.search.preferredProduct';
    static ABI_PRODUCT_COMPARISON:string                    = 'dmles.home.abi.search.productComparison';
    static ABI_PRODUCT_DETAILS:string                       = 'dmles.home.abi.search.productDetails';
    static ABI_PRODUCTS_IN_SAME_PRODUCT_GROUP:string        = 'dmles.home.abi.search.sameProductGroup';
    static ABI_PRODUCTS_IN_SUBSTITUTE_PRODUCT_GROUP:string  = 'dmles.home.abi.search.substituteProductGroup';
    static ABI_PRODUCTS_SITE_CATALOG_ITEMS:string           = 'dmles.home.abi.search.siteCatalogItems';

    static ADMIN_SHELL:string                     = 'dmles.home.admin';
    static ADMIN_PERMISSION_MNG:string            = 'dmles.home.admin.permissionMng';
    static ADMIN_PERMISSION_CREATE:string         = 'dmles.home.admin.permissionMng.createPermission';
    static ADMIN_PERMISSION_EDIT_ELEMENTS:string  = 'dmles.home.admin.permissionMng.editElementsPermission';
    static ADMIN_PERMISSION_EDIT_ENDPOINTS:string = 'dmles.home.admin.permissionMng.editEndpointsPermission';
    static ADMIN_PERMISSION_EDIT_GEN_INFO:string  = 'dmles.home.admin.permissionMng.editGenInfoPermission';
    static ADMIN_PERMISSION_EDIT_STATES:string    = 'dmles.home.admin.permissionMng.editStatesPermission';
    static ADMIN_PERMISSION_VIEW:string           = 'dmles.home.admin.permissionMng.viewPermission';
    static ADMIN_ROLE_MNG:string                  = 'dmles.home.admin.roleMng';
    static ADMIN_ROLE_CREATE:string               = 'dmles.home.admin.roleMng.createRole';
    static ADMIN_ROLE_EDIT_GEN_INFO:string        = 'dmles.home.admin.roleMng.editGenInfoRole';
    static ADMIN_ROLE_EDIT_PERMS:string           = 'dmles.home.admin.roleMng.editPermsRole';
    static ADMIN_ROLE_VIEW:string                 = 'dmles.home.admin.roleMng.viewRole';
    static ADMIN_ORG_MNG:string                   = 'dmles.home.admin.orgMng';

    static ADMIN_USER_PROFILE_MNG: string               = 'dmles.home.admin.userProfileMng';
    static ADMIN_USER_PROFILE_CREATE: string            = 'dmles.home.admin.userProfileMng.createUserProfile';
    static ADMIN_USER_PROFILE_EDIT_GEN_INFO: string     = 'dmles.home.admin.userProfileMng.editGenInfoUserProfile';
    static ADMIN_USER_PROFILE_EDIT_PERMS: string        = 'dmles.home.admin.userProfileMng.editPermsUserProfile';
    static ADMIN_USER_PROFILE_EDIT_ROLES: string        = 'dmles.home.admin.userProfileMng.editRolesUserProfile';
    static ADMIN_USER_PROFILE_EDIT_STATUS_INFO: string  = 'dmles.home.admin.userProfileMng.editStatus';
    static ADMIN_USER_PROFILE_VIEW: string              = 'dmles.home.admin.userProfileMng.viewUserProfile';
    static ADMIN_USER_PROFILE_ASSIGN_ROLES: string      = 'dmles.home.admin.userProfileMng.userProfileAssignRoles';
    static ADMIN_USER_PROFILE_CREATE_CONFIRM: string    = 'dmles.home.admin.userProfileMng.userProfileCreateConfirm';

    static ASSET_MANAGEMENT_SHELL:string                   = 'dmles.home.assetManagement';
    static ASSET_MANAGEMENT_MAIN:string                    = 'dmles.home.assetManagement.main';
    static ASSET_MANAGEMENT_MEDICAL_EQUIPMENT:string       = 'dmles.home.assetManagement.medicalEquipment';
    static ASSET_MANAGEMENT_REAL_PROPERTY_INSTALLED:string = 'dmles.home.assetManagement.realPropertyInstalled';
    static ASSET_MANAGEMENT_UPLOAD_COBIE_FILE:string       = 'dmles.home.assetManagement.realPropertyInstalled.uploadCobieFile';

    static BUYER_SHELL:string        = 'dmles.home.buyer';
    static BUYER_MY_BUYERS:string    = 'dmles.home.buyer.mybuyers';
    static BUYER_MAIN:string         = 'dmles.home.buyer.main';
    static BUYER_DETAIL_VIEW:string  = 'dmles.home.buyer.main';
    static BUYER_LOOKUP_VIEW:string  = 'dmles.home.buyer.lookup';
    static BUYER_PURCHASES:string    = 'dmles.home.buyer.purchases';
    static BUYER_REQUISITION:string  = 'dmles.home.buyer.requisition';
    static BUYER_RECEIPTS:string     = 'dmles.home.buyer.receipts';
    static BUYER_ORDER_STATUS:string = 'dmles.home.buyer.orderStatus';

    static CATALOG_SHELL:string              = 'dmles.home.catalog';
    static CATALOG_FAVS:string               = 'dmles.home.catalog.favs';
    static CATALOG_SEARCH:string             = 'dmles.home.catalog.search';
    static CATALOG_ITEM_DETAILS:string       = 'dmles.home.catalog.search.details';
    static CUSTOMER_CATALOG:string           = 'dmles.home.catalog.customerCatalog';
    //static CUSTOMER_CATALOG_DETAILS:string = 'dmles.home.catalog.customerCatalog.details';

    static EQUIP_SHELL:string                  = 'dmles.home.equipment';
    static EQUIP_RECORD_SEARCH:string          = 'dmles.home.equipment.record';
    static EQUIP_RECORD_DATA_MANAGEMENT:string = 'dmles.home.equipment.recordDataManagement';
    static EQUIP_RECORD_DETAILS:string         = 'dmles.home.equipment.record.details';

    static EQUIP_REQUEST_SHELL:string       = 'dmles.home.equipment.request';
    static EQUIP_REQUEST_MY_REQUESTS:string = 'dmles.home.equipment.request.myRequests';
    static EQUIP_REQUEST_VIEW:string        = 'dmles.home.equipment.request.myRequests.view';
    static EQUIP_REQUEST_HISTORY:string     = 'dmles.home.equipment.request.myRequests.view.history';
    static EQUIP_REQUEST_ATTACHMENTS:string = 'dmles.home.equipment.request.myRequests.view.attachments';
    static EQUIP_REQUEST_NOTES:string       = 'dmles.home.equipment.request.myRequests.view.notes';
    static EQUIP_REQUEST_PRINT:string       = 'dmles.home.equipment.request.myRequests.view.print';

    static FIN_SHELL:string = 'dmles.home.finance';
    static FIN_LANDING:string = 'dmles.home.finance.landing';
    static FIN_APPROPRIATIONS_SHELL = 'dmles.home.finance.appropriation';
    static FIN_MY_APPROPRIATIONS = 'dmles.home.finance.appropriation.myappropriations';
    static FIN_MY_APPROPRIATIONS_DETAIL = 'dmles.home.finance.appropriation.myappropriations.detail';
    
    static JMLFDC_ADMIN_SHELL:string = 'dmles.home.jmlfdcAdmin';

    static INVENTORY_SHELL:string     = 'dmles.home.inventory';
    static INVENTORY_RECORD:string    = 'dmles.home.inventory.record';
    static INVENTORY_PHYSICAL:string  = 'dmles.home.inventory.physical';
    static INVENTORY_STORAGE:string   = 'dmles.home.inventory.storage';
    static INVENTORY_GAIN_LOSS:string = 'dmles.home.inventory.gainLoss';
    static INVENTORY_TRANSFER:string  = 'dmles.home.inventory.transfer';

    static REAL_ESTATE_SHELL:string = 'dmles.home.realEstate';
    static REAL_ESTATE_INSTALLATION_RECORD_VIEW:string = 'dmles.home.realEstate.installationView';
    static REAL_ESTATE_INSTALLATION_SITE_RECORD_VIEW:string = 'dmles.home.realEstate.siteView';

    static SELLER_FULFILLMENT:string        = 'dmles.home.seller.fulfillment';
    static SELLER_BACK_ORDER_STATUS:string  = 'dmles.home.seller.backOrderStatus';
    static SELLER_DETAIL_VIEW:string        = 'dmles.home.seller.main.detail';
    static SELLER_DETAIL_ADD:string         = 'dmles.home.seller.main.add';
    static SELLER_MAIN:string               = 'dmles.home.seller.main';
    static SELLER_SHELL:string              = 'dmles.home.seller';

    static ABI_STAGING_VIEW:string = 'dmles.home.jmlfdcAdmin.abiStaging.viewAbiStaging';
    static ABI_STAGING_EDIT:string = "dmles.home.jmlfdcAdmin.abiStaging.viewAbiStaging.editAbiStaging";
    static ABI_STAGING_SHELL:string = 'dmles.home.jmlfdcAdmin.abiStaging';
    static ABI_STAGING_MERGE_BY_MMC:string = "dmles.home.jmlfdcAdmin.abiStaging.mergeByMmc";
    static ABI_STAGING_MERGE_RECORDS:string = "dmles.home.jmlfdcAdmin.abiStaging.mergeRecords";
    static ABI_STAGING_SET_UNSPSC:string = "dmles.home.jmlfdcAdmin.abiStaging.viewAbiStaging.setUnspsc";
    static ABI_STAGING_SET_ATTRS:string = "dmles.home.jmlfdcAdmin.abiStaging.viewAbiStaging.setAttributes";
    static ABI_STAGING_MANAGE_MERGED_RECS: string = "dmles.home.jmlfdcAdmin.abiStaging.manageMergedRecords";
    static ABI_STAGING_MOVE_TO_PRODUCTION:string = 'dmles.home.jmlfdcAdmin.abiStaging.abiMoveToProduction';
    static ABI_STAGING_DELTA_VIEW:string = 'dmles.home.jmlfdcAdmin.abiStaging.viewAbiDelta';

    // @ngInject
    constructor() {
    }

}