'use strict';

export class UserTypeConstants {

    static SITE:string = 'SITE';
    static REGION:string = "SERVICEREGION";
    static SERVICE:string = 'SERVICE';
    static GLOBAL:string = 'GLOBAL';

    constructor(){}
}