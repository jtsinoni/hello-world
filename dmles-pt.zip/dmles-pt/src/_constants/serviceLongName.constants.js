define(["require", "exports"], function (require, exports) {
    'use strict';
    var ServiceLongName = (function () {
        function ServiceLongName() {
        }
        ServiceLongName.AIR_FORCE_LONG_NAME = "Air Force";
        ServiceLongName.ARMY_LONG_NAME = "Army";
        ServiceLongName.NAVY_LONG_NAME = "Navy";
        return ServiceLongName;
    }());
    exports.ServiceLongName = ServiceLongName;
});
//# sourceMappingURL=serviceLongName.constants.js.map