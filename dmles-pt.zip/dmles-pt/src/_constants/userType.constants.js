define(["require", "exports"], function (require, exports) {
    'use strict';
    var UserTypeConstants = (function () {
        function UserTypeConstants() {
        }
        UserTypeConstants.SITE = 'SITE';
        UserTypeConstants.REGION = "SERVICEREGION";
        UserTypeConstants.SERVICE = 'SERVICE';
        UserTypeConstants.GLOBAL = 'GLOBAL';
        return UserTypeConstants;
    }());
    exports.UserTypeConstants = UserTypeConstants;
});
//# sourceMappingURL=userType.constants.js.map