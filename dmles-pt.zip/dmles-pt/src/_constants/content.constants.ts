'use strict';

export class ContentConstants {

    static ACCESS_ALL:string = 'Admin';
    static COMMENT_SUCCESSFULL_DELETE:string = "Comment Successfully deleted.";
    static DATE_TIME:string = 'dd MMM yyyy HH:mm:ss';
    static DODAAC_COMPARE_FIELD:string = 'dodaac';
    static EMPLOYEE_EMAIL_COMPARE_FIELD:string = 'email';
    static ERR_MSG:string = 'An error occurred, please try again later. If this error persists, contact the system admin.';
    static SIGN_IN_ERR_MSG:string = '"There was a problem processing your request. If the problem persists please contact application support personnel."';
    static EVENT_ITEMS_IN_CART:string = 'eventItemsInCart';
    static EVENT_USER_UPDATE:string = 'eventUserUpdate';
    static FORMAT_DATE:string = 'dd MMM yyyy';
    static FORMAT_DATE_TIME:string = 'dd MMM yyyy HH:mm:ss';
    static MANUFACTURER_SITE_ID:string = 'DMLSS';
    static ORDER_REQ_TYPE_CATALOG:string = 'CATALOG';
    static ORDER_REQ_TYPE_NEW_ITEM:string = 'NEW_ITEM';
    static REGEX_EMAIL:string = '/^[_a-z0-9]+(\.[_a-z0-9]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/';
    static REGEX_PHONE:string = '/\d{3}-\d{3}-\d{4}/';
    static ROLE_COMPARE_FIELD:string = 'name';
    static SELECTED:string = 'SELECTED';
    static SEARCH_MAX:number = 250;
    static UNREGISTERED_USER:string = 'UnregisteredUser';
    static DELETED_USER_ERR_MSG:string = "User Profile is deleted. Please contact application support personnel.";
    static EXPIRED_USER_ERR_MSG:string = "User Profile has expired. Please contact application support personnel.";
    static LOCKED_USER_ERR_MSG:string = "User Profile is locked. Please contact application support personnel.";
    static PENDING_USER_ERR_MSG:string = "User Profile is pending. Please contact application support personnel.";
    static SUSPENDED_USER_ERR_MSG:string = "User Profile is suspended. Please contact application support personnel.";
    static ACTIVE:string = 'ACTIVE';
    static LOCKED:string = 'Locked';
    static PENDING:string = 'Pending';
    static SUSPENDED:string = 'Suspended';

    constructor(){}
}