import {ApiConstants} from './api.constants';
import {ConfigConstants} from './config.constants';
import {ContentConstants} from './content.constants';
import {CookieConstants} from './cookie.constants';
import {ProcessStages} from './process.constants';
import {ResourceConstants} from './resource.constants';
import {StateConstants} from './state.constants';
import {UserTypeConstants} from './userType.constants';
import {ServiceLongName} from './serviceLongName.constants';
import {ServiceShortName} from './serviceShortName.constants';

var constantModule = angular.module('Dmles.Constants.Module', []);
constantModule.constant('ApiConstants', ApiConstants);
constantModule.constant('ConfigConstants', ConfigConstants);
constantModule.constant('ContentConstants', ContentConstants);
constantModule.constant('CookieConstants', CookieConstants);
constantModule.constant('ProcessStages', ProcessStages);
constantModule.constant('ResourceConstants', ResourceConstants);
constantModule.constant('StateConstants', StateConstants);
constantModule.constant('UserTypeConstants', UserTypeConstants);
constantModule.constant('ServiceLongName', ServiceLongName);
constantModule.constant('ServiceShortName', ServiceShortName);

export default constantModule;