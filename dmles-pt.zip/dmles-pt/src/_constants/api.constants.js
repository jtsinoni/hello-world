define(["require", "exports"], function (require, exports) {
    'use strict';
    var ApiConstants = (function () {
        function ApiConstants() {
        }
        ApiConstants.DMLES_TOKEN = "dmles-token";
        ApiConstants.CLIENT_ID = "dmles";
        ApiConstants.UNREGISTERED_USER = "UnregisteredUser";
        ApiConstants.EQUIPMENT_API = "Dmles.Equipment.Server/V1/";
        ApiConstants.OAUTH_API = "Dmles.OAuth.Server/";
        ApiConstants.ROLE_API = "Dmles.User.Server/V1/role/";
        ApiConstants.SITE_API = "Dmles.Site.Server/V1/";
        ApiConstants.SYSTEM_API = "Dmles.System.Server/V1/";
        ApiConstants.USER_API = "Dmles.User.Server/V1/user/";
        return ApiConstants;
    }());
    exports.ApiConstants = ApiConstants;
});
//# sourceMappingURL=api.constants.js.map