define(["require", "exports"], function (require, exports) {
    'use strict';
    var ApiConstants = (function () {
        function ApiConstants() {
        }
        // Note: Keep these lines sorted to avoid merge conflicts
        ApiConstants.ABI_PRODUCTION_API = "Dmles.ABi.Server/V1/production/";
        ApiConstants.ABI_SITE_CATALOG_API = "Dmles.ABi.Server/V1/sitecatalog/";
        ApiConstants.ASSET_MANAGEMENT_API = "Dmles.AssetManagement.Server/V1/AssetManagement/";
        ApiConstants.ABI_STAGING_API = "Dmles.ABi.Server/V1/staging/";
        ApiConstants.ABI_STAGING_JOIN_API = "Dmles.ABi.Server/V1/staging/join/";
        ApiConstants.ABI_STAGING_LOOKUP_API = "Dmles.ABi.Server/V1/staging/lookup/";
        ApiConstants.ABI_TAXONOMY_API = "Dmles.ABi.Server/V1/taxonomy/";
        ApiConstants.ABI_STAGING_MOVE_RECORDS_API = "Dmles.ABi.Server/V1/staging/moveRecords/";
        ApiConstants.BUYER_API = "Dmles.Buyer.Server/V1/Buyer/";
        ApiConstants.CATALOG_API = "Dmles.Catalog.Server/V1/";
        ApiConstants.CLIENT_ID = "dmles";
        ApiConstants.DMLES_TOKEN = "dmles-token";
        ApiConstants.DUE_IN_API = "Dmles.DueIn.Server/V1/DueIn/";
        ApiConstants.EQUIPMENT_API = "Dmles.Equipment.Server/V1/";
        ApiConstants.FILE_MANAGER_API = "Dmles.FileManager.Server/V1/";
        ApiConstants.FUNDADMIN_API = "Dmles.Finance.Server/V1/fundAdmin/";
        ApiConstants.INVENTORY_API = "Dmles.Inventory.Server/V1/inventory/";
        ApiConstants.STORAGE_LOCATION_API = "Dmles.Inventory.Server/V1/storageLocation/";
        ApiConstants.OAUTH_API = "Dmles.OAuth.Server/";
        ApiConstants.ORG_API = "Dmles.Organization.Server/V1/organization/";
        ApiConstants.REAL_ESTATE_API = "Dmles.RealEstate.Server/V1/";
        ApiConstants.ROLE_API = "Dmles.User.Server/V1/role/";
        ApiConstants.SELLER_API = "Dmles.Seller.Server/V1/";
        ApiConstants.SITE_API = "Dmles.Site.Server/V1/";
        ApiConstants.SYSTEM_API = "Dmles.System.Server/V1/";
        ApiConstants.UNREGISTERED_USER = "UnregisteredUser";
        ApiConstants.USER_API = "Dmles.User.Server/V1/user/";
        return ApiConstants;
    }());
    exports.ApiConstants = ApiConstants;
});
//# sourceMappingURL=api.constants.js.map