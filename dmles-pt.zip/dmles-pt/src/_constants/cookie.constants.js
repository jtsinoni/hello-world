define(["require", "exports"], function (require, exports) {
    'use strict';
    var CookieConstants = (function () {
        function CookieConstants() {
        }
        Object.defineProperty(CookieConstants, "Default", {
            get: function () {
                return {
                    KEY_CURRENT_STATE: 'currentState'
                };
            },
            enumerable: true,
            configurable: true
        });
        return CookieConstants;
    }());
    exports.CookieConstants = CookieConstants;
});
//# sourceMappingURL=cookie.constants.js.map