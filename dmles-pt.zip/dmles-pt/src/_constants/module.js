define(["require", "exports", './api.constants', './config.constants', './content.constants', './cookie.constants', './process.constants', './resource.constants', './search.constants', './state.constants', './userType.constants', './serviceLongName.constants', './serviceShortName.constants'], function (require, exports, api_constants_1, config_constants_1, content_constants_1, cookie_constants_1, process_constants_1, resource_constants_1, search_constants_1, state_constants_1, userType_constants_1, serviceLongName_constants_1, serviceShortName_constants_1) {
    "use strict";
    var constantModule = angular.module('Dmles.Constants.Module', []);
    constantModule.constant('ApiConstants', api_constants_1.ApiConstants);
    constantModule.constant('ConfigConstants', config_constants_1.ConfigConstants);
    constantModule.constant('ContentConstants', content_constants_1.ContentConstants);
    constantModule.constant('CookieConstants', cookie_constants_1.CookieConstants);
    constantModule.constant('ProcessStages', process_constants_1.ProcessStages);
    constantModule.constant('ResourceConstants', resource_constants_1.ResourceConstants);
    constantModule.constant('SearchConstants', search_constants_1.SearchConstants);
    constantModule.constant('StateConstants', state_constants_1.StateConstants);
    constantModule.constant('UserTypeConstants', userType_constants_1.UserTypeConstants);
    constantModule.constant('ServiceLongName', serviceLongName_constants_1.ServiceLongName);
    constantModule.constant('ServiceShortName', serviceShortName_constants_1.ServiceShortName);
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = constantModule;
});
//# sourceMappingURL=module.js.map