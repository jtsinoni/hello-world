define(["require", "exports", './api.constants', './content.constants', './cookie.constants', './process.constants', './resource.constants', './state.constants', './userType.constants'], function (require, exports, api_constants_1, content_constants_1, cookie_constants_1, process_constants_1, resource_constants_1, state_constants_1, userType_constants_1) {
    'use strict';
    var constantModule = angular.module('Dmles.Constants.Module', []);
    constantModule.constant('ApiConstants', api_constants_1.ApiConstants);
    constantModule.constant('ContentConstants', content_constants_1.ContentConstants);
    constantModule.constant('CookieConstants', cookie_constants_1.CookieConstants);
    constantModule.constant('ProcessStages', process_constants_1.ProcessStages);
    constantModule.constant('ResourceConstants', resource_constants_1.ResourceConstants);
    constantModule.constant('StateConstants', state_constants_1.StateConstants);
    constantModule.constant('UserTypeConstants', userType_constants_1.UserTypeConstants);
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = constantModule;
});
//# sourceMappingURL=module.js.map