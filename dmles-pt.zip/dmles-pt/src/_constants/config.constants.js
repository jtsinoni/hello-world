define(["require", "exports"], function (require, exports) {
    "use strict";
    var ConfigConstants = (function () {
        function ConfigConstants() {
        }
        //"http://dmetpx4007.jmlfdc.mil:8080/"  -- Test
        //"http://dmedpx3005.jmlfdc.mil:8080/"  -- Dev
        //"http://localhost:8000/" -- Local
        ConfigConstants.BT_BASE_URL = "http://localhost:8080/";
        ConfigConstants.BUILD_DATE = "YYYY";
        ConfigConstants.BUILD_VERSION = "NNNN";
        return ConfigConstants;
    }());
    exports.ConfigConstants = ConfigConstants;
});
//# sourceMappingURL=config.constants.js.map