'use strict';

// TODO: Once the permission's collection has been made, these should be pulled from that
// collection and then, used appropriately.
export class ResourceConstants {
    static ALL:string = 'all';
    static CATALOG_VIEW:string = 'equip-catalog';
    static EQUIP_REQUESTS_VIEW:string = 'requests-service';
    static EQUIP_REQUESTS_MY_REQUESTS:string = 'equip-my-requests';
    static EQUIP_REQUESTS_CREATE:string = 'equip-request-create';
    static EQUIP_REQUESTS_FACILITIES:string = 'equip-request-facilities';
    static EQUIP_REQUESTS_MAINTENANCE:string = 'equip-request-maintenance';
    static EQUIP_REQUESTS_SAFETY:string = 'equip-request-safety';
    static EQUIP_REQUESTS_TECHNOLOGY:string = 'equip-request-technology';
    static EQUIP_REQUESTS_WEIGHIN:string = 'equip-request-weighin';
    static EQUIP_REQUESTS_UPDATE:string = 'equip-update';
    static EQUIP_RECORDS_VIEW:string = 'equip-records';
    static EQUIP_RECORD_DATA_MANAGEMENT:string = 'record-data-management';
    static PERMISSION_MANAGEMENT:string = 'permission-management';
    static ROLE_MANAGEMENT:string = 'role-management';    
    static USER_PROFILE_MANAGEMENT:string = 'user-profile-management';
    static VIEW_ALL_REQUESTS:string = 'view-all-requests';
    static WORKFLOW_MANAGEMENT:string = 'workflow-management';
    static JMAR_VIEW:string = 'jmar';

    constructor() {
        //no-op
    }
}