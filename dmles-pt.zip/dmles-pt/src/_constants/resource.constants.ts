// TODO: Once the permission's collection has been made, these should be pulled from that
// collection and then, used appropriately.
export class ResourceConstants {

    static ABI: string = 'abi';

    static ALL: string = 'all';

    static ASSET_MANAGEMENT_VIEW: string = 'asset-management-view';
    static ASSET_MANAGEMENT_MAIN_VIEW: string = 'asset-management-main-view';
    static ASSET_MANAGEMENT_MEDICAL_EQUIPMENT_VIEW: string = 'asset-management-medical-equipment-view';
    static ASSET_MANAGEMENT_REAL_PROPERTY_INSTALLED_VIEW: string = 'asset-management-real-property-installed-view';
    static ASSET_MANAGEMENT_UPLOAD_COBIE_FILE_VIEW: string = 'asset-management-upload-cobie-file-view';

    static BUYER_VIEW: string = 'buyer-view';
    static BUYER_PURCHASES_VIEW: string = 'buyer-purchases-view';
    static BUYER_REQUISITION_VIEW: string = 'buyer-requisition-view';
    static BUYER_RECEIPTS_VIEW: string = 'buyer-receipts-view';
    static BUYER_ORDER_STATUS_VIEW: string = 'buyer-order-status-view';

    static CATALOG_VIEW: string = 'equip-catalog';
    static CUSTOMER_CATALOG_VIEW: string = 'customer-catalog-view';

    static EQUIP_REQUESTS_VIEW: string = 'requests-service';
    static EQUIP_REQUESTS_MY_REQUESTS: string = 'equip-my-requests';
    static EQUIP_REQUESTS_CREATE: string = 'equip-request-create';
    static EQUIP_REQUESTS_FACILITIES: string = 'equip-request-facilities';
    static EQUIP_REQUESTS_MAINTENANCE: string = 'equip-request-maintenance';
    static EQUIP_REQUESTS_SAFETY: string = 'equip-request-safety';
    static EQUIP_REQUESTS_TECHNOLOGY: string = 'equip-request-technology';
    static EQUIP_REQUESTS_REVIEW: string = 'equip-request-review';
    static EQUIP_REQUESTS_UPDATE: string = 'equip-update';
    static EQUIP_RECORDS_VIEW: string = 'equip-records';
    static EQUIP_RECORD_DATA_MANAGEMENT: string = 'record-data-management';

    static FIN_LANDING_VIEW: string = 'finance-landing';
    static FIN_APPROPRIATIONS_VIEW: string = 'finance-landing';

    static INVENTORY_RECORD_VIEW: string = 'inventory-record-view';
    static INVENTORY_PHYSICAL_VIEW: string = 'inventory-physical-view';
    static INVENTORY_STORAGE_VIEW: string = 'inventory-storage-view';
    static INVENTORY_GAIN_LOSS_VIEW: string = 'inventory-gain-loss-view';
    static INVENTORY_TRANSFER_VIEW: string = 'inventory-transfer-view';

    static PERMISSION_MANAGEMENT: string = 'permission-management';
    static ROLE_MANAGEMENT: string = 'role-management';

    static SELLER_VIEW: string = 'seller-view';
    static SELLER_FULFILLMENT_VIEW: string = 'seller-fulfillment-view';
    static SELLER_BACK_ORDER_STATUS_VIEW: string = 'seller-back-order-status-view';

    static USER_PROFILE_MANAGEMENT: string = 'user-profile-management';
    static VIEW_ALL_REQUESTS: string = 'view-all-requests';
    static WORKFLOW_MANAGEMENT: string = 'workflow-management';
    static ORGANIZATION_MANAGEMENT: string = 'organization-management';

    static REAL_ESTATE_INSTALLATION_RECORD_VIEW: string = 'real-estate-installation-view';
    static REAL_ESTATE_INSTALLATION_SITE_RECORD_VIEW: string = 'real-estate-site-view';

    static BUYER_DETAIL_VIEW: string = 'buyer-main';
    static BUYER_LOOKUP_VIEW: string = 'buyer-lookup';

    // SES - not sure about this
    static MANAGE_ABI_STAGING: string = 'manage-abi-staging';
    static MANAGE_ABI_MOVE_TO_PRODUCTION: string = 'manage-abi-move-to-production';
    static MANAGE_ABI_DELTA: string = 'manage-abi-delta';
    
    constructor() {
        //no-op
    }
}