define(["require", "exports"], function (require, exports) {
    'use strict';
    var ProcessStages = (function () {
        function ProcessStages() {
        }
        ProcessStages.REQUEST_NEW = "New";
        ProcessStages.REQUEST_SAVED = "Saved";
        ProcessStages.REQUEST_PENDING_APPROVAL = "InProcess";
        ProcessStages.REQUEST_APPROVED = "Approved";
        ProcessStages.REQUEST_DENIED = "Denied";
        return ProcessStages;
    }());
    exports.ProcessStages = ProcessStages;
});
//# sourceMappingURL=process.constants.js.map