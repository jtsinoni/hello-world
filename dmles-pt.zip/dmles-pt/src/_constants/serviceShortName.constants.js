define(["require", "exports"], function (require, exports) {
    'use strict';
    var ServiceShortName = (function () {
        function ServiceShortName() {
        }
        ServiceShortName.AIR_FORCE_SHORT_NAME = "DF";
        ServiceShortName.ARMY_SHORT_NAME = "DA";
        ServiceShortName.NAVY_SHORT_NAME = "NV";
        return ServiceShortName;
    }());
    exports.ServiceShortName = ServiceShortName;
});
//# sourceMappingURL=serviceShortName.constants.js.map