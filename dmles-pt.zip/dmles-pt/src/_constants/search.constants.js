define(["require", "exports"], function (require, exports) {
    'use strict';
    var SearchConstants = (function () {
        function SearchConstants() {
        }
        SearchConstants.EVENT_MODULE_ABI = "ABi";
        SearchConstants.EVENT_MODULE_BASE = "BaseModule";
        // components that potentially have many specific instances
        SearchConstants.EVENT_TARGET_COMPONENT_CATEGORY = " Category";
        SearchConstants.EVENT_TARGET_COMPONENT_CATEGORY_BREADCRUMB = " CategoryBreadcrumb";
        SearchConstants.EVENT_TARGET_COMPONENT_FACET = " Facet";
        // breadbox component
        SearchConstants.EVENT_TARGET_COMPONENT_SELECTED_FACET_OPTIONS_BREADBOX = " SelectedFacetOptionsBreadbox";
        // parent search component
        SearchConstants.EVENT_TARGET_COMPONENT_SEARCH = " Search";
        // Category component methods
        SearchConstants.EVENT_TARGET_METHOD_CLEAR_ALL_CATEGORY_OPTION_SELECTIONS = "clearAllCategoryOptionSelections";
        SearchConstants.EVENT_TARGET_METHOD_UPDATE_CATEGORY_OPTION_SELECTIONS_PER_BREADCRUMB_CLICK = "updateCategoryOptionSelectionsPerBreadcrumbClick";
        // Category Breadcrumb component methods
        SearchConstants.EVENT_TARGET_METHOD_UPDATE_BREADCRUMB_PER_CATEGORY_OPTION_SELECTION = "updateBreadcrumbPerCategoryOptionSelection";
        // Facet component methods
        SearchConstants.EVENT_TARGET_METHOD_CLEAR_SELECTED_FACET_OPTION = "clearSelectedFacetOption";
        SearchConstants.EVENT_TARGET_METHOD_CLEAR_FILTERING_MATCH_STRING = "clearFilteringMatchString";
        // Selected Facet Options Breadbox component methods
        SearchConstants.EVENT_TARGET_METHOD_CLEAR_ALL_SELECTED_FACET_OPTIONS = "clearAllSelectedFacetOptions";
        SearchConstants.EVENT_TARGET_METHOD_REMOVE_SELECTED_FACET_OPTION = "removeSelectedFacetOption";
        SearchConstants.EVENT_TARGET_METHOD_UPDATE_SELECTED_FACET_OPTIONS = "updateSelectedFacetOptions";
        // Search component methods
        SearchConstants.EVENT_TARGET_METHOD_EXECUTE_SEARCH = "executeSearch";
        return SearchConstants;
    }());
    exports.SearchConstants = SearchConstants;
});
//# sourceMappingURL=search.constants.js.map