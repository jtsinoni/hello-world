export class ConfigConstants {

    //"http://dmetpx4007.jmlfdc.mil:8080/"  -- Test
    //"http://dmedpx3005.jmlfdc.mil:8080/"  -- Dev
    //"http://localhost:8000/" -- Local

    static BT_BASE_URL:string = "http://localhost:8080/";
    static BUILD_DATE:string = "YYYY";
    static BUILD_VERSION:string = "NNNN";

    constructor(){}

}