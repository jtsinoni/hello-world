export class ConfigConstants {

    //static BT_BASE_URL:string = "https://140.139.36.40:8443/"; // Test New
    //static BT_BASE_URL:string = "http://jw8cui04:8080/";  // Test Old
    //static BT_BASE_URL:string = "http://jw8dmles102:8080/";  // Dev Old
    //static BT_BASE_URL:string = "https:/140.139.35.29:8443/";  // Dev New

    static BT_BASE_URL:string = "http://localhost:8080/";
    static BUILD_DATE:string = "YYYY";
    static BUILD_VERSION:string = "NNNN";

    constructor(){}

}