export class ConfigConstants {

    static BUILD_DATE:string = "YYYY";
    static BUILD_VERSION:string = "NNNN";

    constructor(){}

}