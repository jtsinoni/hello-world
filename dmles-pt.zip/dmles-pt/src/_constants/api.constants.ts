'use strict';

export class ApiConstants {

    // Note: Keep these lines sorted to avoid merge conflicts
    static ABI_PRODUCTION_API = "Dmles.ABi.Server/V1/production/";
    static ABI_SITE_CATALOG_API = "Dmles.ABi.Server/V1/sitecatalog/";
    static ASSET_MANAGEMENT_API = "Dmles.AssetManagement.Server/V1/AssetManagement/";
    static ABI_STAGING_API = "Dmles.ABi.Server/V1/staging/";
    static ABI_STAGING_JOIN_API = "Dmles.ABi.Server/V1/staging/join/";
    static ABI_STAGING_LOOKUP_API = "Dmles.ABi.Server/V1/staging/lookup/";
    static ABI_TAXONOMY_API = "Dmles.ABi.Server/V1/taxonomy/";
    static ABI_STAGING_MOVE_RECORDS_API = "Dmles.ABi.Server/V1/staging/moveRecords/";
    static BUYER_API = "Dmles.Buyer.Server/V1/Buyer/";
    static CATALOG_API = "Dmles.Catalog.Server/V1/";
    static CLIENT_ID:string = "dmles";
    static DMLES_TOKEN:string = "dmles-token";
    static DUE_IN_API = "Dmles.DueIn.Server/V1/DueIn/";
    static EQUIPMENT_API = "Dmles.Equipment.Server/V1/";
    static FILE_MANAGER_API = "Dmles.FileManager.Server/V1/";
    static FUNDADMIN_API = "Dmles.Finance.Server/V1/fundAdmin/";
    static INVENTORY_API = "Dmles.Inventory.Server/V1/inventory/";
    static STORAGE_LOCATION_API = "Dmles.Inventory.Server/V1/storageLocation/";
    static OAUTH_API = "Dmles.OAuth.Server/";
    static ORG_API = "Dmles.Organization.Server/V1/organization/";
    static REAL_ESTATE_API = "Dmles.RealEstate.Server/V1/";
    static ROLE_API = "Dmles.User.Server/V1/role/";
    static SELLER_API = "Dmles.Seller.Server/V1/";
    static SITE_API = "Dmles.Site.Server/V1/";
    static SYSTEM_API = "Dmles.System.Server/V1/";
    static UNREGISTERED_USER:string = "UnregisteredUser";
    static USER_API = "Dmles.User.Server/V1/user/";

    constructor(){}

}
