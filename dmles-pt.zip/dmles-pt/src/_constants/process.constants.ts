'use strict';

export class ProcessStages {
    static REQUEST_NEW:string = "New";
    static REQUEST_SAVED:string = "Saved";
    static REQUEST_PENDING_APPROVAL:string = "InProcess";
    static REQUEST_APPROVED:string = "Approved";
    static REQUEST_DENIED:string = "Denied";

    constructor() {}
}