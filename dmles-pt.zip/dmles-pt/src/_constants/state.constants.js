define(["require", "exports"], function (require, exports) {
    "use strict";
    var StateConstants = (function () {
        // @ngInject
        function StateConstants() {
        }
        StateConstants.SECURITY = 'dmles.security';
        StateConstants.LOGIN_SHELL = 'dmles.login';
        StateConstants.LOGIN = 'dmles.login.form';
        StateConstants.REGISTER = 'dmles.login.form.register';
        StateConstants.REGISTER_CONFIRM = 'dmles.login.form.register.confirmation';
        StateConstants.HOME_ROOT = 'dmles.home';
        StateConstants.ABOUT = 'dmles.home.about';
        StateConstants.HELP = 'dmles.home.help';
        StateConstants.MY_DASHBOARD = 'dmles.home.dashboard';
        StateConstants.USER_PROFILE = 'dmles.home.userProfile';
        StateConstants.USER_PROFILE_EDIT_GEN_INFO = 'dmles.home.userProfile.editGenInfoUserProfile';
        StateConstants.ADMIN_SHELL = 'dmles.home.admin';
        StateConstants.ADMIN_PERMISSION_MNG = 'dmles.home.admin.permissionMng';
        StateConstants.ADMIN_PERMISSION_CREATE = 'dmles.home.admin.permissionMng.createPermission';
        StateConstants.ADMIN_PERMISSION_EDIT_ELEMENTS = 'dmles.home.admin.permissionMng.editElementsPermission';
        StateConstants.ADMIN_PERMISSION_EDIT_ENDPOINTS = 'dmles.home.admin.permissionMng.editEndpointsPermission';
        StateConstants.ADMIN_PERMISSION_EDIT_GEN_INFO = 'dmles.home.admin.permissionMng.editGenInfoPermission';
        StateConstants.ADMIN_PERMISSION_EDIT_STATES = 'dmles.home.admin.permissionMng.editStatesPermission';
        StateConstants.ADMIN_PERMISSION_VIEW = 'dmles.home.admin.permissionMng.viewPermission';
        StateConstants.ADMIN_ROLE_MNG = 'dmles.home.admin.roleMng';
        StateConstants.ADMIN_ROLE_CREATE = 'dmles.home.admin.roleMng.createRole';
        StateConstants.ADMIN_ROLE_EDIT_GEN_INFO = 'dmles.home.admin.roleMng.editGenInfoRole';
        StateConstants.ADMIN_ROLE_EDIT_PERMS = 'dmles.home.admin.roleMng.editPermsRole';
        StateConstants.ADMIN_ROLE_VIEW = 'dmles.home.admin.roleMng.viewRole';
        StateConstants.ADMIN_USER_PROFILE_MNG = 'dmles.home.admin.userProfileMng';
        StateConstants.ADMIN_USER_PROFILE_EDIT_GEN_INFO = 'dmles.home.admin.userProfileMng.editGenInfoUserProfile';
        StateConstants.ADMIN_USER_PROFILE_EDIT_PERMS = 'dmles.home.admin.userProfileMng.editPermsUserProfile';
        StateConstants.ADMIN_USER_PROFILE_EDIT_ROLES = 'dmles.home.admin.userProfileMng.editRolesUserProfile';
        StateConstants.ADMIN_USER_PROFILE_VIEW = 'dmles.home.admin.userProfileMng.viewUserProfile';
        StateConstants.CATALOG_SHELL = 'dmles.home.catalog';
        StateConstants.CATALOG_FAVS = 'dmles.home.catalog.favs';
        StateConstants.CATALOG_SEARCH = 'dmles.home.catalog.search';
        StateConstants.CATALOG_ITEM_DETAILS = 'dmles.home.catalog.search.details';
        StateConstants.EQUIP_RECORD_SEARCH = 'dmles.home.record';
        StateConstants.EQUIP_RECORD_DATA_MANAGEMENT = 'dmles.home.recordDataManagement';
        StateConstants.EQUIP_RECORD_DETAILS = 'dmles.home.record.details';
        StateConstants.EQUIP_RECORD_DOC_SEARCH = 'dmles.home.record.docSearch';
        StateConstants.EQUIP_RECORD_JMAR_STATUS = 'dmles.home.record.jmarStatus';
        StateConstants.EQUIP_REQUEST_SHELL = 'dmles.home.request';
        StateConstants.EQUIP_REQUEST_MY_REQUESTS = 'dmles.home.request.myRequests';
        StateConstants.EQUIP_REQUEST_CRITERIA = 'dmles.home.request.myRequests.view.criteria';
        StateConstants.EQUIP_REQUEST_HISTORY = 'dmles.home.request.myRequests.view.history';
        StateConstants.EQUIP_REQUEST_VIEW = 'dmles.home.request.myRequests.view';
        StateConstants.EQUIP_REQUEST_WORKFLOW_MNG = 'dmles.home.request.workflowMng';
        StateConstants.EQUIP_REQUEST_WORKFLOW_EDIT_NEXT_LEVEL_CRITERIA = 'dmles.home.request.workflowMng.editNextLevelCriteria';
        StateConstants.EQUIP_REQUEST_WORKFLOW_EDIT_OWNER_ROLE = 'dmles.home.request.workflowMng.editOwnerRole';
        StateConstants.EQUIP_REQUEST_WORKFLOW_EDIT_RULES = 'dmles.home.request.workflowMng.editRules';
        StateConstants.JMAR_SHELL = 'dmles.home.jmar';
        return StateConstants;
    }());
    exports.StateConstants = StateConstants;
});
//# sourceMappingURL=state.constants.js.map