const gulp = require('gulp');
const path = require('path');

const config = {
    projectDir: __dirname,
    srcDir: path.join(__dirname, 'src'),
    watchDir: path.join (__dirname, 'src'),
    docsDir: path.join(__dirname, 'docs'),
    distDir: path.join(__dirname, 'dist'),
    testDir: path.join(__dirname, 'tests')
};

gulp.task('clean:src', require('./tasks/clean')(gulp, config.srcDir));
gulp.task('clean:test', require('./tasks/clean')(gulp, config.testDir));
gulp.task('clean', ['clean:src', 'clean:test']);

gulp.task('compile:src', ['clean:src'], require('./tasks/compile')(gulp, config.srcDir));
gulp.task('compile:test', ['clean:test'], require('./tasks/compile')(gulp, config.testDir));
gulp.task('compile', ['compile:src', 'compile:test']);

gulp.task('serve:docs', ['build:docs'], require('./tasks/server')(gulp, config.docsDir));
gulp.task('serve:dist', require('./tasks/server')(gulp, config.distDir, false));
gulp.task('serve', ['compile'], require('./tasks/server')(gulp, config.projectDir, config.watchDir));

gulp.task('test:unit', require('./tasks/test-unit')(config.testDir));
gulp.task('test', require('./tasks/test')());

//gulp.task('build:compile', require('./tasks/compile')(gulp, config.srcDir));
//gulp.task('build:dist', ['ng:annotate'], require('./tasks/build')(gulp, config));
//gulp.task('build:docs', require('./tasks/buildDocs')(gulp, config));
//gulp.task('build', ['build:compile', 'build:test']);

gulp.task('default', require('./tasks/default')());

gulp.task('ng:directives', require('./tasks/ngdirectives')(gulp, config));
gulp.task('ng:annotate', ['ng:directives'], require('./tasks/ngannotate')(gulp, config));

gulp.task('deploy:replace', require('./tasks/replace')(gulp, config.srcDir));
gulp.task('deploy:buildVer', require('./tasks/buildVer')(gulp, config.srcDir));
gulp.task('deploy:compile', require('./tasks/compile')(gulp, config.srcDir));
gulp.task('deploy:bundle', require('./tasks/bundle')(gulp, config));
gulp.task('deployPrep', ['deploy:replace', 'deploy:compile', 'deploy:bundle']);
gulp.task('deployPrepNix', ['deploy:replace', 'deploy:buildVer','deploy:compile']);
gulp.task('deploy:wipe', require('./tasks/wipe')(gulp, config.srcDir));
gulp.task('deployWipe', ['deploy:wipe']);
