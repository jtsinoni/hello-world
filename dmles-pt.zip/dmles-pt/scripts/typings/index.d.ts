/// <reference path="globals/angular-mocks/index.d.ts" />
/// <reference path="globals/angular-ui-router/index.d.ts" />
/// <reference path="globals/angular/index.d.ts" />
/// <reference path="globals/jasmine/index.d.ts" />
/// <reference path="globals/jquery/index.d.ts" />
/// <reference path="modules/debug/index.d.ts" />
