These 2 directories contain the maven assemblies configuration for packaging and deploying the presentation tier.

The infrastructure-assembly packages all the supporting directories, library modules and configuration files and pushes them to Nexus for versioning.

To run this, go to the dmles-pt root directory

    run mvn clean deploy -f deployment-assemblies/infrastructure-assembly/pom.xml

    A target directory will be created in deployment-assemblies/infrastructure-assembly inside of which the resultant
    .tar file will be placed.

The src-assembly package all the src code and pushes it to Nexus for versioning.

    run mvn clean deploy -f deployment-assemblies/src-assembly/pom.xml

    A target directory will be created in deployment-assemblies/src-assembly inside of which the resultant
    .tar file will be placed.

    The src package will include the entire src directory and the appconfig.js file. When deployed on the target host,
    the tar file is simply untarred at the project root directory.

    For example:

            Base directory is dmles-pt
            cd dmles-pt
            copy the src assembly .tar file here:
            tar xvf logicole-presentation-src-1.0-DEVTIP-bin.tar

Use of the mvn version command will adjust the versions. If you run the following command

        mvn versions:set -DnewVersion=<VERSION> versions:commit

        This will version element in each pom file will be adjusted to the defined version and clean up the temporary files.