module.exports = function () {
    return function () {
        return require('run-sequence')('check', 'compile', function () {
            console.log('Done');
        });
    };
};


