module.exports = function (gulp, config) {
    return function () {
        const directiveReplace = require('gulp-directive-replace');
        const path = require('path');

        console.log('calling directive Replace');

        return gulp.src(path.join(config.srcDir, '**', '*.js'))
            //.pipe(directiveReplace())
            .pipe(directiveReplace({root: config.srcDir}))
            .pipe(gulp.dest(config.srcDir));
    };
};
