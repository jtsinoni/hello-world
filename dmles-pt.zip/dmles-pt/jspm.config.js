System.config({
  defaultJSExtensions: true,
  transpiler: false,
  paths: {
    "github:*": "jspm_packages/github/*",
    "npm:*": "jspm_packages/npm/*",
    "app": "src/index"
  },

  map: {
    "angular": "github:angular/bower-angular@1.5.8",
    "angular-animate": "github:angular/bower-angular-animate@1.5.5",
    "angular-aria": "npm:angular-aria@1.6.0",
    "angular-cookies": "github:angular/bower-angular-cookies@1.5.0",
    "angular-file-saver": "npm:angular-file-saver@1.1.3",
    "angular-file-upload": "npm:angular-file-upload@2.2.0",
    "angular-growl-v2": "npm:angular-growl-v2@0.7.5",
    "angular-messages": "npm:angular-messages@1.5.5",
    "angular-mocks": "github:angular/bower-angular-mocks@1.5.8",
    "angular-moment": "npm:angular-moment@1.0.0-beta.5",
    "angular-multi-select": "github:isteven/angular-multi-select@4.0.0",
    "angular-sanitize": "github:angular/bower-angular-sanitize@1.5.0",
    "angular-tree-control": "github:wix/angular-tree-control@0.2.28",
    "angular-ui-bootstrap": "npm:angular-ui-bootstrap@1.2.2",
    "angular-ui-grid": "github:angular-ui/bower-ui-grid@4.0.4",
    "angular-ui-router": "github:angular-ui/ui-router@0.4.2",
    "angular-utils-ui-breadcrumbs": "npm:angular-utils-ui-breadcrumbs@0.2.2-1",
    "bootstrap": "github:twbs/bootstrap@3.3.5",
    "bootstrap-accessibility-plugin": "npm:bootstrap-accessibility-plugin@1.0.2",
    "bootstrap-notify": "npm:bootstrap-notify@3.1.3",
    "css": "github:systemjs/plugin-css@0.1.32",
    "dangrossman/bootstrap-daterangepicker": "github:dangrossman/bootstrap-daterangepicker@2.1.19",
    "danielcrisp/angular-rangeslider": "github:danielcrisp/angular-rangeslider@0.0.14",
    "isteven/angular-multi-select": "github:isteven/angular-multi-select@4.0.0",
    "jtrussell/angular-selection-model": "github:jtrussell/angular-selection-model@0.10.2",
    "ng-csv": "npm:ng-csv@0.3.6",
    "ng-file-upload": "npm:ng-file-upload@12.2.13",
    "ng-table": "npm:ng-table@2.2.0",
    "pscarbrough2/angular-daterangepicker": "github:pscarbrough2/angular-daterangepicker@0.2.3",
    "github:angular/bower-angular-animate@1.5.5": {
      "angular": "github:angular/bower-angular@1.5.8"
    },
    "github:angular/bower-angular-cookies@1.5.0": {
      "angular": "github:angular/bower-angular@1.5.8"
    },
    "github:angular/bower-angular-mocks@1.5.8": {
      "angular": "github:angular/bower-angular@1.5.8"
    },
    "github:angular/bower-angular-sanitize@1.5.0": {
      "angular": "github:angular/bower-angular@1.5.8"
    },
    "github:dangrossman/bootstrap-daterangepicker@2.1.19": {
      "jquery": "github:components/jquery@2.1.4",
      "moment": "npm:moment@2.12.0"
    },
    "github:jspm/nodelibs-assert@0.1.0": {
      "assert": "npm:assert@1.4.1"
    },
    "github:jspm/nodelibs-buffer@0.1.0": {
      "buffer": "npm:buffer@3.6.0"
    },
    "github:jspm/nodelibs-constants@0.1.0": {
      "constants-browserify": "npm:constants-browserify@0.0.1"
    },
    "github:jspm/nodelibs-events@0.1.1": {
      "events": "npm:events@1.0.2"
    },
    "github:jspm/nodelibs-http@1.7.1": {
      "Base64": "npm:Base64@0.2.1",
      "events": "github:jspm/nodelibs-events@0.1.1",
      "inherits": "npm:inherits@2.0.1",
      "stream": "github:jspm/nodelibs-stream@0.1.0",
      "url": "github:jspm/nodelibs-url@0.1.0",
      "util": "github:jspm/nodelibs-util@0.1.0"
    },
    "github:jspm/nodelibs-os@0.1.0": {
      "os-browserify": "npm:os-browserify@0.1.2"
    },
    "github:jspm/nodelibs-path@0.1.0": {
      "path-browserify": "npm:path-browserify@0.0.0"
    },
    "github:jspm/nodelibs-process@0.1.2": {
      "process": "npm:process@0.11.9"
    },
    "github:jspm/nodelibs-stream@0.1.0": {
      "stream-browserify": "npm:stream-browserify@1.0.0"
    },
    "github:jspm/nodelibs-tty@0.1.0": {
      "tty-browserify": "npm:tty-browserify@0.0.0"
    },
    "github:jspm/nodelibs-url@0.1.0": {
      "url": "npm:url@0.10.3"
    },
    "github:jspm/nodelibs-util@0.1.0": {
      "util": "npm:util@0.10.3"
    },
    "github:jspm/nodelibs-vm@0.1.0": {
      "vm-browserify": "npm:vm-browserify@0.0.4"
    },
    "github:twbs/bootstrap@3.3.5": {
      "jquery": "github:components/jquery@2.1.4"
    },
    "npm:@types/angular@1.5.20": {
      "@types/jquery": "npm:@types/jquery@2.0.34"
    },
    "npm:amdefine@1.0.1": {
      "fs": "github:jspm/nodelibs-fs@0.1.2",
      "module": "github:jspm/nodelibs-module@0.1.0",
      "path": "github:jspm/nodelibs-path@0.1.0",
      "process": "github:jspm/nodelibs-process@0.1.2"
    },
    "npm:angular-file-saver@1.1.3": {
      "blob-tmp": "npm:blob-tmp@1.0.0",
      "file-saver": "npm:file-saver@1.3.3",
      "process": "github:jspm/nodelibs-process@0.1.2"
    },
    "npm:angular-file-upload@2.2.0": {
      "systemjs-json": "github:systemjs/plugin-json@0.1.2"
    },
    "npm:angular-moment@1.0.0-beta.5": {
      "moment": "npm:moment@2.12.0"
    },
    "npm:argparse@0.1.16": {
      "assert": "github:jspm/nodelibs-assert@0.1.0",
      "fs": "github:jspm/nodelibs-fs@0.1.2",
      "path": "github:jspm/nodelibs-path@0.1.0",
      "process": "github:jspm/nodelibs-process@0.1.2",
      "underscore": "npm:underscore@1.7.0",
      "underscore.string": "npm:underscore.string@2.4.0",
      "util": "github:jspm/nodelibs-util@0.1.0"
    },
    "npm:assert@1.4.1": {
      "assert": "github:jspm/nodelibs-assert@0.1.0",
      "buffer": "github:jspm/nodelibs-buffer@0.1.0",
      "process": "github:jspm/nodelibs-process@0.1.2",
      "util": "npm:util@0.10.3"
    },
    "npm:async@0.1.22": {
      "process": "github:jspm/nodelibs-process@0.1.2"
    },
    "npm:async@0.2.10": {
      "process": "github:jspm/nodelibs-process@0.1.2"
    },
    "npm:bootstrap-accessibility-plugin@1.0.2": {
      "fs": "github:jspm/nodelibs-fs@0.1.2",
      "grunt": "npm:grunt@0.4.5",
      "grunt-contrib-jshint": "npm:grunt-contrib-jshint@0.6.5",
      "grunt-contrib-uglify": "npm:grunt-contrib-uglify@0.2.7",
      "path": "github:jspm/nodelibs-path@0.1.0",
      "process": "github:jspm/nodelibs-process@0.1.2"
    },
    "npm:buffer@3.6.0": {
      "base64-js": "npm:base64-js@0.0.8",
      "child_process": "github:jspm/nodelibs-child_process@0.1.0",
      "fs": "github:jspm/nodelibs-fs@0.1.2",
      "ieee754": "npm:ieee754@1.1.8",
      "isarray": "npm:isarray@1.0.0",
      "process": "github:jspm/nodelibs-process@0.1.2"
    },
    "npm:cli@0.4.5": {
      "glob": "npm:glob@3.2.11",
      "process": "github:jspm/nodelibs-process@0.1.2"
    },
    "npm:coffee-script@1.3.3": {
      "child_process": "github:jspm/nodelibs-child_process@0.1.0",
      "events": "github:jspm/nodelibs-events@0.1.1",
      "fs": "github:jspm/nodelibs-fs@0.1.2",
      "module": "github:jspm/nodelibs-module@0.1.0",
      "path": "github:jspm/nodelibs-path@0.1.0",
      "process": "github:jspm/nodelibs-process@0.1.2",
      "readline": "github:jspm/nodelibs-readline@0.1.0",
      "util": "github:jspm/nodelibs-util@0.1.0",
      "vm": "github:jspm/nodelibs-vm@0.1.0"
    },
    "npm:colors@0.6.2": {
      "assert": "github:jspm/nodelibs-assert@0.1.0"
    },
    "npm:console-browserify@0.1.6": {
      "assert": "github:jspm/nodelibs-assert@0.1.0",
      "util": "github:jspm/nodelibs-util@0.1.0"
    },
    "npm:constants-browserify@0.0.1": {
      "systemjs-json": "github:systemjs/plugin-json@0.1.2"
    },
    "npm:core-util-is@1.0.2": {
      "buffer": "github:jspm/nodelibs-buffer@0.1.0"
    },
    "npm:esprima@1.0.4": {
      "fs": "github:jspm/nodelibs-fs@0.1.2",
      "process": "github:jspm/nodelibs-process@0.1.2"
    },
    "npm:exit@0.1.2": {
      "process": "github:jspm/nodelibs-process@0.1.2"
    },
    "npm:findup-sync@0.1.3": {
      "glob": "npm:glob@3.2.11",
      "lodash": "npm:lodash@2.4.2",
      "path": "github:jspm/nodelibs-path@0.1.0"
    },
    "npm:glob@3.1.21": {
      "assert": "github:jspm/nodelibs-assert@0.1.0",
      "events": "github:jspm/nodelibs-events@0.1.1",
      "graceful-fs": "npm:graceful-fs@1.2.3",
      "inherits": "npm:inherits@1.0.2",
      "minimatch": "npm:minimatch@0.2.14",
      "path": "github:jspm/nodelibs-path@0.1.0",
      "process": "github:jspm/nodelibs-process@0.1.2",
      "systemjs-json": "github:systemjs/plugin-json@0.1.2"
    },
    "npm:glob@3.2.11": {
      "assert": "github:jspm/nodelibs-assert@0.1.0",
      "events": "github:jspm/nodelibs-events@0.1.1",
      "fs": "github:jspm/nodelibs-fs@0.1.2",
      "inherits": "npm:inherits@2.0.1",
      "minimatch": "npm:minimatch@0.3.0",
      "path": "github:jspm/nodelibs-path@0.1.0",
      "process": "github:jspm/nodelibs-process@0.1.2",
      "systemjs-json": "github:systemjs/plugin-json@0.1.2"
    },
    "npm:graceful-fs@1.2.3": {
      "constants": "github:jspm/nodelibs-constants@0.1.0",
      "fs": "github:jspm/nodelibs-fs@0.1.2",
      "process": "github:jspm/nodelibs-process@0.1.2"
    },
    "npm:grunt-contrib-jshint@0.6.5": {
      "grunt": "npm:grunt@0.4.5",
      "jshint": "npm:jshint@2.1.11",
      "path": "github:jspm/nodelibs-path@0.1.0",
      "process": "github:jspm/nodelibs-process@0.1.2"
    },
    "npm:grunt-contrib-uglify@0.2.7": {
      "fs": "github:jspm/nodelibs-fs@0.1.2",
      "grunt": "npm:grunt@0.4.5",
      "grunt-lib-contrib": "npm:grunt-lib-contrib@0.6.1",
      "uglify-js": "npm:uglify-js@2.4.24"
    },
    "npm:grunt-legacy-log-utils@0.1.1": {
      "colors": "npm:colors@0.6.2",
      "lodash": "npm:lodash@2.4.2",
      "underscore.string": "npm:underscore.string@2.3.3"
    },
    "npm:grunt-legacy-log@0.1.3": {
      "colors": "npm:colors@0.6.2",
      "grunt-legacy-log-utils": "npm:grunt-legacy-log-utils@0.1.1",
      "hooker": "npm:hooker@0.2.3",
      "lodash": "npm:lodash@2.4.2",
      "process": "github:jspm/nodelibs-process@0.1.2",
      "underscore.string": "npm:underscore.string@2.3.3",
      "util": "github:jspm/nodelibs-util@0.1.0"
    },
    "npm:grunt-legacy-util@0.2.0": {
      "async": "npm:async@0.1.22",
      "buffer": "github:jspm/nodelibs-buffer@0.1.0",
      "child_process": "github:jspm/nodelibs-child_process@0.1.0",
      "exit": "npm:exit@0.1.2",
      "getobject": "npm:getobject@0.1.0",
      "hooker": "npm:hooker@0.2.3",
      "lodash": "npm:lodash@0.9.2",
      "path": "github:jspm/nodelibs-path@0.1.0",
      "process": "github:jspm/nodelibs-process@0.1.2",
      "underscore.string": "npm:underscore.string@2.2.1",
      "util": "github:jspm/nodelibs-util@0.1.0",
      "which": "npm:which@1.0.9"
    },
    "npm:grunt-lib-contrib@0.6.1": {
      "path": "github:jspm/nodelibs-path@0.1.0",
      "zlib-browserify": "npm:zlib-browserify@0.0.1"
    },
    "npm:grunt@0.4.5": {
      "async": "npm:async@0.1.22",
      "buffer": "github:jspm/nodelibs-buffer@0.1.0",
      "coffee-script": "npm:coffee-script@1.3.3",
      "colors": "npm:colors@0.6.2",
      "dateformat": "npm:dateformat@1.0.2-1.2.3",
      "eventemitter2": "npm:eventemitter2@0.4.14",
      "exit": "npm:exit@0.1.2",
      "findup-sync": "npm:findup-sync@0.1.3",
      "fs": "github:jspm/nodelibs-fs@0.1.2",
      "getobject": "npm:getobject@0.1.0",
      "glob": "npm:glob@3.1.21",
      "grunt-legacy-log": "npm:grunt-legacy-log@0.1.3",
      "grunt-legacy-util": "npm:grunt-legacy-util@0.2.0",
      "hooker": "npm:hooker@0.2.3",
      "iconv-lite": "npm:iconv-lite@0.2.11",
      "js-yaml": "npm:js-yaml@2.0.5",
      "lodash": "npm:lodash@0.9.2",
      "minimatch": "npm:minimatch@0.2.14",
      "nopt": "npm:nopt@1.0.10",
      "path": "github:jspm/nodelibs-path@0.1.0",
      "process": "github:jspm/nodelibs-process@0.1.2",
      "rimraf": "npm:rimraf@2.2.8",
      "systemjs-json": "github:systemjs/plugin-json@0.1.2",
      "underscore.string": "npm:underscore.string@2.2.1",
      "which": "npm:which@1.0.9"
    },
    "npm:hooker@0.2.3": {
      "child_process": "github:jspm/nodelibs-child_process@0.1.0",
      "fs": "github:jspm/nodelibs-fs@0.1.2",
      "path": "github:jspm/nodelibs-path@0.1.0",
      "process": "github:jspm/nodelibs-process@0.1.2"
    },
    "npm:iconv-lite@0.2.11": {
      "buffer": "github:jspm/nodelibs-buffer@0.1.0",
      "fs": "github:jspm/nodelibs-fs@0.1.2",
      "http": "github:jspm/nodelibs-http@1.7.1"
    },
    "npm:inherits@2.0.1": {
      "util": "github:jspm/nodelibs-util@0.1.0"
    },
    "npm:js-yaml@2.0.5": {
      "argparse": "npm:argparse@0.1.16",
      "buffer": "github:jspm/nodelibs-buffer@0.1.0",
      "esprima": "npm:esprima@1.0.4",
      "fs": "github:jspm/nodelibs-fs@0.1.2",
      "path": "github:jspm/nodelibs-path@0.1.0",
      "process": "github:jspm/nodelibs-process@0.1.2",
      "systemjs-json": "github:systemjs/plugin-json@0.1.2",
      "util": "github:jspm/nodelibs-util@0.1.0"
    },
    "npm:jshint@2.1.11": {
      "buffer": "github:jspm/nodelibs-buffer@0.1.0",
      "cli": "npm:cli@0.4.5",
      "console-browserify": "npm:console-browserify@0.1.6",
      "events": "github:jspm/nodelibs-events@0.1.1",
      "minimatch": "npm:minimatch@0.3.0",
      "path": "github:jspm/nodelibs-path@0.1.0",
      "process": "github:jspm/nodelibs-process@0.1.2",
      "shelljs": "npm:shelljs@0.1.4",
      "underscore": "npm:underscore@1.4.4"
    },
    "npm:lodash@0.9.2": {
      "process": "github:jspm/nodelibs-process@0.1.2"
    },
    "npm:lodash@2.4.2": {
      "process": "github:jspm/nodelibs-process@0.1.2"
    },
    "npm:minimatch@0.2.14": {
      "lru-cache": "npm:lru-cache@2.7.3",
      "path": "github:jspm/nodelibs-path@0.1.0",
      "process": "github:jspm/nodelibs-process@0.1.2",
      "sigmund": "npm:sigmund@1.0.1"
    },
    "npm:minimatch@0.3.0": {
      "lru-cache": "npm:lru-cache@2.7.3",
      "path": "github:jspm/nodelibs-path@0.1.0",
      "process": "github:jspm/nodelibs-process@0.1.2",
      "sigmund": "npm:sigmund@1.0.1"
    },
    "npm:moment@2.12.0": {
      "process": "github:jspm/nodelibs-process@0.1.2"
    },
    "npm:ng-file-upload@12.2.13": {
      "process": "github:jspm/nodelibs-process@0.1.2"
    },
    "npm:ng-table@2.2.0": {
      "@types/angular": "npm:@types/angular@1.5.20",
      "angular": "npm:angular@1.5.9"
    },
    "npm:nopt@1.0.10": {
      "abbrev": "npm:abbrev@1.0.9",
      "assert": "github:jspm/nodelibs-assert@0.1.0",
      "path": "github:jspm/nodelibs-path@0.1.0",
      "process": "github:jspm/nodelibs-process@0.1.2",
      "stream": "github:jspm/nodelibs-stream@0.1.0",
      "url": "github:jspm/nodelibs-url@0.1.0",
      "util": "github:jspm/nodelibs-util@0.1.0"
    },
    "npm:os-browserify@0.1.2": {
      "os": "github:jspm/nodelibs-os@0.1.0"
    },
    "npm:path-browserify@0.0.0": {
      "process": "github:jspm/nodelibs-process@0.1.2"
    },
    "npm:process@0.11.9": {
      "assert": "github:jspm/nodelibs-assert@0.1.0",
      "fs": "github:jspm/nodelibs-fs@0.1.2",
      "vm": "github:jspm/nodelibs-vm@0.1.0"
    },
    "npm:punycode@1.3.2": {
      "process": "github:jspm/nodelibs-process@0.1.2"
    },
    "npm:readable-stream@1.1.14": {
      "buffer": "github:jspm/nodelibs-buffer@0.1.0",
      "core-util-is": "npm:core-util-is@1.0.2",
      "events": "github:jspm/nodelibs-events@0.1.1",
      "inherits": "npm:inherits@2.0.1",
      "isarray": "npm:isarray@0.0.1",
      "process": "github:jspm/nodelibs-process@0.1.2",
      "stream-browserify": "npm:stream-browserify@1.0.0",
      "string_decoder": "npm:string_decoder@0.10.31"
    },
    "npm:rimraf@2.2.8": {
      "assert": "github:jspm/nodelibs-assert@0.1.0",
      "fs": "github:jspm/nodelibs-fs@0.1.2",
      "path": "github:jspm/nodelibs-path@0.1.0",
      "process": "github:jspm/nodelibs-process@0.1.2"
    },
    "npm:shelljs@0.1.4": {
      "buffer": "github:jspm/nodelibs-buffer@0.1.0",
      "child_process": "github:jspm/nodelibs-child_process@0.1.0",
      "fs": "github:jspm/nodelibs-fs@0.1.2",
      "os": "github:jspm/nodelibs-os@0.1.0",
      "path": "github:jspm/nodelibs-path@0.1.0",
      "process": "github:jspm/nodelibs-process@0.1.2",
      "util": "github:jspm/nodelibs-util@0.1.0",
      "vm": "github:jspm/nodelibs-vm@0.1.0"
    },
    "npm:sigmund@1.0.1": {
      "http": "github:jspm/nodelibs-http@1.7.1",
      "util": "github:jspm/nodelibs-util@0.1.0"
    },
    "npm:source-map@0.1.34": {
      "amdefine": "npm:amdefine@1.0.1",
      "fs": "github:jspm/nodelibs-fs@0.1.2",
      "path": "github:jspm/nodelibs-path@0.1.0",
      "process": "github:jspm/nodelibs-process@0.1.2"
    },
    "npm:stream-browserify@1.0.0": {
      "events": "github:jspm/nodelibs-events@0.1.1",
      "inherits": "npm:inherits@2.0.1",
      "readable-stream": "npm:readable-stream@1.1.14"
    },
    "npm:string_decoder@0.10.31": {
      "buffer": "github:jspm/nodelibs-buffer@0.1.0"
    },
    "npm:uglify-js@2.4.24": {
      "async": "npm:async@0.2.10",
      "buffer": "github:jspm/nodelibs-buffer@0.1.0",
      "fs": "github:jspm/nodelibs-fs@0.1.2",
      "path": "github:jspm/nodelibs-path@0.1.0",
      "process": "github:jspm/nodelibs-process@0.1.2",
      "source-map": "npm:source-map@0.1.34",
      "uglify-to-browserify": "npm:uglify-to-browserify@1.0.2",
      "vm": "github:jspm/nodelibs-vm@0.1.0",
      "yargs": "npm:yargs@3.5.4"
    },
    "npm:uglify-to-browserify@1.0.2": {
      "fs": "github:jspm/nodelibs-fs@0.1.2",
      "stream": "github:jspm/nodelibs-stream@0.1.0"
    },
    "npm:url@0.10.3": {
      "assert": "github:jspm/nodelibs-assert@0.1.0",
      "punycode": "npm:punycode@1.3.2",
      "querystring": "npm:querystring@0.2.0",
      "util": "github:jspm/nodelibs-util@0.1.0"
    },
    "npm:util@0.10.3": {
      "inherits": "npm:inherits@2.0.1",
      "process": "github:jspm/nodelibs-process@0.1.2"
    },
    "npm:vm-browserify@0.0.4": {
      "indexof": "npm:indexof@0.0.1"
    },
    "npm:which@1.0.9": {
      "fs": "github:jspm/nodelibs-fs@0.1.2",
      "path": "github:jspm/nodelibs-path@0.1.0",
      "process": "github:jspm/nodelibs-process@0.1.2"
    },
    "npm:window-size@0.1.0": {
      "process": "github:jspm/nodelibs-process@0.1.2",
      "tty": "github:jspm/nodelibs-tty@0.1.0"
    },
    "npm:yargs@3.5.4": {
      "assert": "github:jspm/nodelibs-assert@0.1.0",
      "camelcase": "npm:camelcase@1.2.1",
      "decamelize": "npm:decamelize@1.2.0",
      "fs": "github:jspm/nodelibs-fs@0.1.2",
      "path": "github:jspm/nodelibs-path@0.1.0",
      "process": "github:jspm/nodelibs-process@0.1.2",
      "window-size": "npm:window-size@0.1.0",
      "wordwrap": "npm:wordwrap@0.0.2"
    },
    "npm:zlib-browserify@0.0.1": {
      "buffer": "github:jspm/nodelibs-buffer@0.1.0",
      "process": "github:jspm/nodelibs-process@0.1.2"
    }
  }
});
