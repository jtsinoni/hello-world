/// <reference path="./references.ts" />

import * as angular from "angular";

import "angular-mocks";
