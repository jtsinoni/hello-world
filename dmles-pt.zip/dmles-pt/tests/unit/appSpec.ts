/// <reference path="../references.ts" />
import {App} from "../../src/module";

describe("DMLES Application", () => {
    describe("during initialization", () => {
        it("Application is initiated", () => {
            expect(App).toBeDefined();
        });
    });
});
