import "../../../../src/module";
import "../../../../src/home/module";
import "../../../../src/home/_views/module";

describe('Home _Views Module Tests', () => {

    beforeEach(() => {
        module('DmlesModule');
        module('Dmles.Home.Module');
        module('Dmles.Views.Module');
    });

    var controller;
    var scope;

    beforeEach(inject(($rootScope, $controller) => {
        scope = $rootScope.$new();
    }));

    it('Has scope', () => {
        expect(scope).toBeDefined();
    });

});