import "../../../../src/module";
import "../../../../src/home/module";
import "../../../../src/home/_views/module";
import "../../../../src/home/admin/userProfileManagement/module";

describe('Home _Views User Profile Edit Gen Info.Controller Tests', () => {
    var userProfileEditGenInfoController;
    var mock;

    var userProfile = {
        "id": "5797741eb6c6b99956f06cc7",
        "registrationId": "5797741eb6c6b99956f06cc7",
        "userStatus": "ACTIVE",
        "email": "Forrest1@aol.com",
        "lastLoginDate": null,
        "firstName": "Forrest",
        "lastName": "Gump",
        "password": null,
        "pkiDn": null,
        "phoneNumbers": [
            {
                "phoneNumberType": "MOBILE",
                "value": "string"
            }
        ],
        "serviceCode": "string",
        "regionCode": "string",
        "profileName": "GLOBAL",
        "roles": [],
        "assignedPermissions": null,
        "userType": "GLOBAL",
        "dodaac": "string",
        "isDefault": false
    };

    var userProfiles = [{"id":"5790c87a4c08b0003d9782f0","profileName":"GLOBAL","pkiDn":"all.123","dodaac":null,"email":"all@mail.mil","firstName":"All","lastName":"Permissions","userType":"GLOBAL","serviceCode":"DHA","regionCode":null,"states":["dmles.login.register","dmles.home.userProfile","dmles.home.account","dmles.home.admin.roleMng.editPermsRole","dmles","dmles.home.admin.roleMng","dmles.home.admin.permissionMng.editElementsPermission","dmles.home.help","dmles.home.admin.permissionMng.viewPermission","dmles.home.admin.permissionMng.editStatesPermission","dmles.login","dmles.home.record.details","dmles.home.about","dmles.home.admin.permissionMng.createPermission","dmles.home.myServices","dmles.home.catalog.search.details","dmles.home.admin","dmles.home.catalog.favs","dmles.home.request.myRequests.new.confirm","dmles.home.admin.userProfileMng.editGenInfoUserProfile","dmles.home.admin.userProfileMng.viewUserProfile","dmles.home.userProfile.editGenInfoUserProfile","dmles.home.jmar","dmles.home.admin.userProfileMng","dmles.home.catalog","dmles.home","dmles.home.request.myRequest","dmles.home.admin.permissionMng.editEndpointsPermission","dmles.home.record.docSearch","dmles.home.request.myRequest.confirm","dmles.security","dmles.home.request","dmles.home.admin.permissionMng","dmles.home.admin.permissionMng.editGenInfoPermission","dmles.home.request.myRequests.view","dmles.login.form","dmles.home.record","dmles.home.admin.userProfileMng.editRolesUserProfile","dmles.home.dashboard","dmles.home.admin.roleMng.createRole","dmles.login.register.confirmation","dmles.home.request.myRequests.new","dmles.home.admin.userProfileMng.editPermsUserProfile","dmles.home.request.myRequests","dmles.home.admin.roleMng.viewRole","dmles.home.admin.roleMng.editGenInfoRole","dmles.home.catalog.search","dmles.home.request.myRequests.new.details"],"elements":["all","equip-update","equip-review","jmar","equip-request-safety","equip-records","equip-my-requests","permission-management","equip-approve","requests-service","equip-request-weighin","equip-request-facilities","user-profile-management","equip-records-search","equip-request-maintenance","equip-catalog","equip-request-create","role-management","equip-request-technology"],"phoneNumbers":[{"phoneNumberType":"HOME","value":"123-123-GUMP"}]},{"id":"57b4ce739ce7b19e3a0cf892","profileName":"SITE W33DME","pkiDn":"all.123","dodaac":"W33DME","email":"site.all@mail.mil","firstName":"Site","lastName":"All","userType":"SITE","serviceCode":"DA","regionCode":"RHC-A","states":["dmles.login.register","dmles.home.userProfile","dmles.home.account","dmles.home.admin.roleMng.editPermsRole","dmles","dmles.home.admin.roleMng","dmles.home.admin.permissionMng.editElementsPermission","dmles.home.help","dmles.home.admin.permissionMng.viewPermission","dmles.home.admin.permissionMng.editStatesPermission","dmles.login","dmles.home.record.details","dmles.home.about","dmles.home.admin.permissionMng.createPermission","dmles.home.myServices","dmles.home.catalog.search.details","dmles.home.admin","dmles.home.catalog.favs","dmles.home.request.myRequests.new.confirm","dmles.home.admin.userProfileMng.editGenInfoUserProfile","dmles.home.admin.userProfileMng.viewUserProfile","dmles.home.userProfile.editGenInfoUserProfile","dmles.home.jmar","dmles.home.admin.userProfileMng","dmles.home.catalog","dmles.home","dmles.home.request.myRequest","dmles.home.admin.permissionMng.editEndpointsPermission","dmles.home.record.docSearch","dmles.home.request.myRequest.confirm","dmles.security","dmles.home.request","dmles.home.admin.permissionMng","dmles.home.admin.permissionMng.editGenInfoPermission","dmles.home.request.myRequests.view","dmles.login.form","dmles.home.record","dmles.home.admin.userProfileMng.editRolesUserProfile","dmles.home.dashboard","dmles.home.admin.roleMng.createRole","dmles.login.register.confirmation","dmles.home.request.myRequests.new","dmles.home.admin.userProfileMng.editPermsUserProfile","dmles.home.request.myRequests","dmles.home.admin.roleMng.viewRole","dmles.home.admin.roleMng.editGenInfoRole","dmles.home.catalog.search","dmles.home.request.myRequests.new.details"],"elements":["all","equip-update","equip-review","jmar","equip-request-safety","equip-records","equip-my-requests","permission-management","equip-approve","requests-service","equip-request-weighin","equip-request-facilities","user-profile-management","equip-records-search","equip-request-maintenance","equip-catalog","equip-request-create","role-management","equip-request-technology"],"phoneNumbers":[{"phoneNumberType":"WORK","value":"111-111-1111"}]}];

    var currentUserProfile = {"id":"5790c87a4c08b0003d9782f0","profileName":"GLOBAL","pkiDn":"all.123","dodaac":"","email":"all@mail.mil","firstName":"All","lastName":"Permissions","userType":"GLOBAL","serviceCode":"DHA","regionCode":"","active":true,"states":["dmles.login.register","dmles.home.userProfile","dmles.home.account","dmles.home.admin.roleMng.editPermsRole","dmles","dmles.home.admin.roleMng","dmles.home.admin.permissionMng.editElementsPermission","dmles.home.help","dmles.home.admin.permissionMng.viewPermission","dmles.home.admin.permissionMng.editStatesPermission","dmles.login","dmles.home.record.details","dmles.home.about","dmles.home.admin.permissionMng.createPermission","dmles.home.myServices","dmles.home.catalog.search.details","dmles.home.admin","dmles.home.catalog.favs","dmles.home.request.myRequests.new.confirm","dmles.home.admin.userProfileMng.editGenInfoUserProfile","dmles.home.admin.userProfileMng.viewUserProfile","dmles.home.userProfile.editGenInfoUserProfile","dmles.home.jmar","dmles.home.admin.userProfileMng","dmles.home.catalog","dmles.home","dmles.home.request.myRequest","dmles.home.admin.permissionMng.editEndpointsPermission","dmles.home.record.docSearch","dmles.home.request.myRequest.confirm","dmles.security","dmles.home.request","dmles.home.admin.permissionMng","dmles.home.admin.permissionMng.editGenInfoPermission","dmles.home.request.myRequests.view","dmles.login.form","dmles.home.record","dmles.home.admin.userProfileMng.editRolesUserProfile","dmles.home.dashboard","dmles.home.admin.roleMng.createRole","dmles.login.register.confirmation","dmles.home.request.myRequests.new","dmles.home.admin.userProfileMng.editPermsUserProfile","dmles.home.request.myRequests","dmles.home.admin.roleMng.viewRole","dmles.home.admin.roleMng.editGenInfoRole","dmles.home.catalog.search","dmles.home.request.myRequests.new.details"],"elements":["all","equip-update","equip-review","jmar","equip-request-safety","equip-records","equip-my-requests","permission-management","equip-approve","requests-service","equip-request-weighin","equip-request-facilities","user-profile-management","equip-records-search","equip-request-maintenance","equip-catalog","equip-request-create","role-management","equip-request-technology"],"phoneNumbers":[{"phoneNumberType":"HOME","value":"123-123-GUMP"}]};

    var myUserService;

    var myUserProfileManagementService;

    beforeEach(() => {
        module('DmlesModule');
        module('Dmles.Home.Module');
        module('Dmles.Views.Module');
        module('Dmles.Admin.UserProfileManagementModule');

        inject(($rootScope, $controller, $state, StateConstants, UserProfileService, UserProfileManagementService, UserService) => {

            spyOn(UserProfileManagementService, 'getUserProfile').and.callFake(() => {
                return userProfile;
            });
            myUserProfileManagementService = UserProfileManagementService;
            
            myUserService = UserService;
            myUserService.currentUser = currentUserProfile;

            mock = {
                $scope: $rootScope.$new(),
                StateConstants: StateConstants,
                $state: $state,
                UserProfileService: UserProfileService,
                UserProfileManagementService: myUserProfileManagementService,
                UserService: myUserService
            };

            userProfileEditGenInfoController = $controller('Dmles.Home.Views.UserProfileEditGenInfoController', mock);
        });
    });

    it('Has scope', () => {        
        expect(mock.$scope).not.toEqual(undefined);
    });

    it('Has a userProfileEditGenInfoController controller', () => {        
        expect(userProfileEditGenInfoController).toBeDefined();
    });

    it('Has a controllerName variable', () => {        
        expect(userProfileEditGenInfoController.controllerName).toBeDefined();
    });

    it('The controllerName variable has the correct value', () => {        
        expect(userProfileEditGenInfoController.controllerName).toEqual("User Profile Edit General Information Controller");
    });

    it('The userProfile controller onSubmit function works', () => {
        spyOn(mock.$state, 'go');
        userProfileEditGenInfoController.userProfile = userProfile;
        spyOn(userProfileEditGenInfoController, "onSubmit").and.callThrough();

        userProfileEditGenInfoController.onSubmit();

        expect(userProfileEditGenInfoController.onSubmit).toHaveBeenCalled();
        expect(mock.$state.go).toHaveBeenCalledWith(mock.StateConstants.USER_PROFILE);
    });

    it('The userProfile controller saveUserProfileGeneralInfo function works - resolve path', () => {
        userProfileEditGenInfoController.userProfile = userProfile;
        spyOn(userProfileEditGenInfoController, "saveUserProfileGeneralInfo").and.callThrough();
        spyOn(userProfileEditGenInfoController.UserProfileService, "saveUserProfileData").and.callFake(() => {
            return $.Deferred().resolve(userProfile);
        });
        spyOn(userProfileEditGenInfoController.UserProfileManagementService, "setUserProfile").and.callFake(() => {
            return $.Deferred().resolve(userProfile);
        });
        spyOn(userProfileEditGenInfoController, "updateCurrentUserProfile").and.callFake(() => {
            return $.Deferred().resolve(currentUserProfile);
        });

        userProfileEditGenInfoController.saveUserProfileGeneralInfo();

        expect(userProfileEditGenInfoController.saveUserProfileGeneralInfo).toHaveBeenCalled();
        expect(userProfileEditGenInfoController.UserProfileService.saveUserProfileData).toHaveBeenCalled();
        expect(userProfileEditGenInfoController.UserProfileManagementService.setUserProfile).toHaveBeenCalled();
        expect(userProfileEditGenInfoController.updateCurrentUserProfile).toHaveBeenCalled();
    });

    it('The userProfile controller saveUserProfileGeneralInfo function works - reject path', () => {
        userProfileEditGenInfoController.userProfile = userProfile;
        spyOn(userProfileEditGenInfoController, "saveUserProfileGeneralInfo").and.callThrough();
        spyOn(userProfileEditGenInfoController.UserProfileService, "saveUserProfileData").and.callFake(() => {
            return $.Deferred().reject();
        });

        userProfileEditGenInfoController.saveUserProfileGeneralInfo();

        expect(userProfileEditGenInfoController.saveUserProfileGeneralInfo).toHaveBeenCalled();
        expect(userProfileEditGenInfoController.UserProfileService.saveUserProfileData).toHaveBeenCalled();
    });

    it('The userProfile controller updateCurrentUserProfile function works', () => {
        userProfileEditGenInfoController.userProfile = userProfile;
        userProfileEditGenInfoController.currentUserProfile = currentUserProfile;
        spyOn(userProfileEditGenInfoController, "updateCurrentUserProfile").and.callThrough();

        userProfileEditGenInfoController.updateCurrentUserProfile();

        expect(userProfileEditGenInfoController.updateCurrentUserProfile).toHaveBeenCalled();
    });

    it('The userProfile controller getActiveUserProfiles function works - resolve path', () => {
        spyOn(userProfileEditGenInfoController, "getActiveUserProfiles").and.callThrough();
        spyOn(userProfileEditGenInfoController.UserProfileService, "getActiveUserProfiles").and.callFake(() => {
            return $.Deferred().resolve(userProfiles);
        });

        userProfileEditGenInfoController.getActiveUserProfiles();

        expect(userProfileEditGenInfoController.getActiveUserProfiles).toHaveBeenCalled();
        expect(userProfileEditGenInfoController.UserProfileService.getActiveUserProfiles).toHaveBeenCalled();
    });

    it('The userProfile controller getActiveUserProfiles function works - reject path', () => {
        spyOn(userProfileEditGenInfoController, "getActiveUserProfiles").and.callThrough();
        spyOn(userProfileEditGenInfoController.UserProfileService, "getActiveUserProfiles").and.callFake(() => {
            return $.Deferred().reject();
        });

        userProfileEditGenInfoController.getActiveUserProfiles();

        expect(userProfileEditGenInfoController.getActiveUserProfiles).toHaveBeenCalled();
        expect(userProfileEditGenInfoController.UserProfileService.getActiveUserProfiles).toHaveBeenCalled();
    });

    it('The userProfile controller goToUserProfileView function works', () => {
        spyOn(mock.$state, 'go');
        spyOn(userProfileEditGenInfoController, "goToUserProfileView").and.callThrough();

        userProfileEditGenInfoController.goToUserProfileView();

        expect(userProfileEditGenInfoController.goToUserProfileView).toHaveBeenCalled();
        expect(mock.$state.go).toHaveBeenCalledWith(mock.StateConstants.USER_PROFILE);
    });
});

