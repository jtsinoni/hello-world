import "../../../../src/module";
import "../../../../src/home/module";
import "../../../../src/home/_views/module";
import "../../../../src/home/admin/userProfileManagement/module";

describe('Home _Views UserProfile.Controller Tests', () => {
    var userProfileController;
    var mock;

    var userProfile = {
        "id": "5797741eb6c6b99956f06cc7",
        "registrationId": "5797741eb6c6b99956f06cc7",
        "userStatus": "ACTIVE",
        "email": "Forrest1@aol.com",
        "lastLoginDate": null,
        "firstName": "Forrest",
        "lastName": "Gump",
        "password": null,
        "pkiDn": null,
        "phoneNumbers": [
            {
                "phoneNumberType": "MOBILE",
                "value": "string"
            }
        ],
        "serviceCode": "string",
        "regionCode": "string",
        "profileName": "GLOBAL",
        "roles": [],
        "assignedPermissions": null,
        "userType": "GLOBAL",
        "dodaac": "string",
        "isDefault": false
    };

    var userProfiles = [{"id":"5790c87a4c08b0003d9782f0","profileName":"GLOBAL","pkiDn":"all.123","dodaac":null,"email":"all@mail.mil","firstName":"All","lastName":"Permissions","userType":"GLOBAL","serviceCode":"DHA","regionCode":null,"states":["dmles.login.register","dmles.home.userProfile","dmles.home.account","dmles.home.admin.roleMng.editPermsRole","dmles","dmles.home.admin.roleMng","dmles.home.admin.permissionMng.editElementsPermission","dmles.home.help","dmles.home.admin.permissionMng.viewPermission","dmles.home.admin.permissionMng.editStatesPermission","dmles.login","dmles.home.record.details","dmles.home.about","dmles.home.admin.permissionMng.createPermission","dmles.home.myServices","dmles.home.catalog.search.details","dmles.home.admin","dmles.home.catalog.favs","dmles.home.request.myRequests.new.confirm","dmles.home.admin.userProfileMng.editGenInfoUserProfile","dmles.home.admin.userProfileMng.viewUserProfile","dmles.home.userProfile.editGenInfoUserProfile","dmles.home.jmar","dmles.home.admin.userProfileMng","dmles.home.catalog","dmles.home","dmles.home.request.myRequest","dmles.home.admin.permissionMng.editEndpointsPermission","dmles.home.record.docSearch","dmles.home.request.myRequest.confirm","dmles.security","dmles.home.request","dmles.home.admin.permissionMng","dmles.home.admin.permissionMng.editGenInfoPermission","dmles.home.request.myRequests.view","dmles.login.form","dmles.home.record","dmles.home.admin.userProfileMng.editRolesUserProfile","dmles.home.dashboard","dmles.home.admin.roleMng.createRole","dmles.login.register.confirmation","dmles.home.request.myRequests.new","dmles.home.admin.userProfileMng.editPermsUserProfile","dmles.home.request.myRequests","dmles.home.admin.roleMng.viewRole","dmles.home.admin.roleMng.editGenInfoRole","dmles.home.catalog.search","dmles.home.request.myRequests.new.details"],"elements":["all","equip-update","equip-review","jmar","equip-request-safety","equip-records","equip-my-requests","permission-management","equip-approve","requests-service","equip-request-weighin","equip-request-facilities","user-profile-management","equip-records-search","equip-request-maintenance","equip-catalog","equip-request-create","role-management","equip-request-technology"],"phoneNumbers":[{"phoneNumberType":"HOME","value":"123-123-GUMP"}]},{"id":"57b4ce739ce7b19e3a0cf892","profileName":"SITE W33DME","pkiDn":"all.123","dodaac":"W33DME","email":"site.all@mail.mil","firstName":"Site","lastName":"All","userType":"SITE","serviceCode":"DA","regionCode":"RHC-A","states":["dmles.login.register","dmles.home.userProfile","dmles.home.account","dmles.home.admin.roleMng.editPermsRole","dmles","dmles.home.admin.roleMng","dmles.home.admin.permissionMng.editElementsPermission","dmles.home.help","dmles.home.admin.permissionMng.viewPermission","dmles.home.admin.permissionMng.editStatesPermission","dmles.login","dmles.home.record.details","dmles.home.about","dmles.home.admin.permissionMng.createPermission","dmles.home.myServices","dmles.home.catalog.search.details","dmles.home.admin","dmles.home.catalog.favs","dmles.home.request.myRequests.new.confirm","dmles.home.admin.userProfileMng.editGenInfoUserProfile","dmles.home.admin.userProfileMng.viewUserProfile","dmles.home.userProfile.editGenInfoUserProfile","dmles.home.jmar","dmles.home.admin.userProfileMng","dmles.home.catalog","dmles.home","dmles.home.request.myRequest","dmles.home.admin.permissionMng.editEndpointsPermission","dmles.home.record.docSearch","dmles.home.request.myRequest.confirm","dmles.security","dmles.home.request","dmles.home.admin.permissionMng","dmles.home.admin.permissionMng.editGenInfoPermission","dmles.home.request.myRequests.view","dmles.login.form","dmles.home.record","dmles.home.admin.userProfileMng.editRolesUserProfile","dmles.home.dashboard","dmles.home.admin.roleMng.createRole","dmles.login.register.confirmation","dmles.home.request.myRequests.new","dmles.home.admin.userProfileMng.editPermsUserProfile","dmles.home.request.myRequests","dmles.home.admin.roleMng.viewRole","dmles.home.admin.roleMng.editGenInfoRole","dmles.home.catalog.search","dmles.home.request.myRequests.new.details"],"elements":["all","equip-update","equip-review","jmar","equip-request-safety","equip-records","equip-my-requests","permission-management","equip-approve","requests-service","equip-request-weighin","equip-request-facilities","user-profile-management","equip-records-search","equip-request-maintenance","equip-catalog","equip-request-create","role-management","equip-request-technology"],"phoneNumbers":[{"phoneNumberType":"WORK","value":"111-111-1111"}]}];

    var currentUserProfile = {"id":"5790c87a4c08b0003d9782f0","profileName":"GLOBAL","pkiDn":"all.123","dodaac":"","email":"all@mail.mil","firstName":"All","lastName":"Permissions","userType":"GLOBAL","serviceCode":"DHA","regionCode":"","active":true,"states":["dmles.login.register","dmles.home.userProfile","dmles.home.account","dmles.home.admin.roleMng.editPermsRole","dmles","dmles.home.admin.roleMng","dmles.home.admin.permissionMng.editElementsPermission","dmles.home.help","dmles.home.admin.permissionMng.viewPermission","dmles.home.admin.permissionMng.editStatesPermission","dmles.login","dmles.home.record.details","dmles.home.about","dmles.home.admin.permissionMng.createPermission","dmles.home.myServices","dmles.home.catalog.search.details","dmles.home.admin","dmles.home.catalog.favs","dmles.home.request.myRequests.new.confirm","dmles.home.admin.userProfileMng.editGenInfoUserProfile","dmles.home.admin.userProfileMng.viewUserProfile","dmles.home.userProfile.editGenInfoUserProfile","dmles.home.jmar","dmles.home.admin.userProfileMng","dmles.home.catalog","dmles.home","dmles.home.request.myRequest","dmles.home.admin.permissionMng.editEndpointsPermission","dmles.home.record.docSearch","dmles.home.request.myRequest.confirm","dmles.security","dmles.home.request","dmles.home.admin.permissionMng","dmles.home.admin.permissionMng.editGenInfoPermission","dmles.home.request.myRequests.view","dmles.login.form","dmles.home.record","dmles.home.admin.userProfileMng.editRolesUserProfile","dmles.home.dashboard","dmles.home.admin.roleMng.createRole","dmles.login.register.confirmation","dmles.home.request.myRequests.new","dmles.home.admin.userProfileMng.editPermsUserProfile","dmles.home.request.myRequests","dmles.home.admin.roleMng.viewRole","dmles.home.admin.roleMng.editGenInfoRole","dmles.home.catalog.search","dmles.home.request.myRequests.new.details"],"elements":["all","equip-update","equip-review","jmar","equip-request-safety","equip-records","equip-my-requests","permission-management","equip-approve","requests-service","equip-request-weighin","equip-request-facilities","user-profile-management","equip-records-search","equip-request-maintenance","equip-catalog","equip-request-create","role-management","equip-request-technology"],"phoneNumbers":[{"phoneNumberType":"HOME","value":"123-123-GUMP"}]};

    var data = {};
    var token = "ABCDEFG";

    var myUserService;

    beforeEach(() => {
        module('DmlesModule');
        module('Dmles.Home.Module');
        module('Dmles.Views.Module');
        module('Dmles.Admin.UserProfileManagementModule');

        inject(($rootScope, $controller, $state, StateConstants, MainNavService, OAuthService, UserProfileService, UserProfileManagementService, UserService) => {

            myUserService = UserService;
            myUserService.currentUser = currentUserProfile;

            mock = {
                $scope: $rootScope.$new(),
                StateConstants: StateConstants,
                $state: $state,
                MainNavService: MainNavService,
                OAuthService: OAuthService,
                UserProfileService: UserProfileService,
                UserProfileManagementService: UserProfileManagementService,
                UserService: myUserService
            };

            userProfileController = $controller('Dmles.Home.Views.UserProfileController', mock);
        });
    });

    it('Has scope', () => {
        // userProfileController.UserService.currentUser = currentUserProfile;
        expect(mock.$scope).not.toEqual(undefined);
    });

    it('Has a userProfileController controller', () => {        
        expect(userProfileController).toBeDefined();
    });

    it('Has a controllerName variable', () => {        
        expect(userProfileController.controllerName).toBeDefined();
    });

    it('The controllerName variable has the correct value', () => {        
        expect(userProfileController.controllerName).toEqual("User Profile Controller");
    });

    it('The userProfile controller init function works - resolve path', () => {
        spyOn(userProfileController, "init").and.callThrough();
        spyOn(userProfileController.UserProfileService, "getUserProfileById").and.callFake(() => {
            return $.Deferred().resolve(userProfile);
        });

        userProfileController.init();

        expect(userProfileController.init).toHaveBeenCalled();
        expect(userProfileController.UserProfileService.getUserProfileById).toHaveBeenCalled();
    });

    it('The userProfile controller init function works - reject path', () => {
        spyOn(userProfileController, "init").and.callThrough();
        spyOn(userProfileController.UserProfileService, "getUserProfileById").and.callFake(() => {
            return $.Deferred().reject();
        });

        userProfileController.init();

        expect(userProfileController.init).toHaveBeenCalled();
        expect(userProfileController.UserProfileService.getUserProfileById).toHaveBeenCalled();
    });

    it('The userProfile controller changeUserProfile function works - resolve path', () => {
        userProfileController.selectedUserProfile = currentUserProfile;
        spyOn(userProfileController, "changeUserProfile").and.callThrough();
        spyOn(userProfileController.UserProfileService, "setCurrentProfile").and.callFake(() => {
            return $.Deferred().resolve(userProfile);
        });
        spyOn(userProfileController.MainNavService, "getMyNavItems").and.callFake(() => {
            return $.Deferred().resolve(data);
        });
        spyOn(userProfileController.OAuthService, "getNewToken").and.callFake(() => {
            return $.Deferred().resolve(token);
        });

        userProfileController.changeUserProfile();

        expect(userProfileController.changeUserProfile).toHaveBeenCalled();
        expect(userProfileController.UserProfileService.setCurrentProfile).toHaveBeenCalled();
        expect(userProfileController.MainNavService.getMyNavItems).toHaveBeenCalled();
        expect(userProfileController.OAuthService.getNewToken).toHaveBeenCalled();
    });

    it('The userProfile controller changeUserProfile function works - returns null data', () => {
        userProfileController.selectedUserProfile = currentUserProfile;
        spyOn(userProfileController, "changeUserProfile").and.callThrough();
        spyOn(userProfileController.UserProfileService, "setCurrentProfile").and.callFake(() => {
            return $.Deferred().resolve(userProfile);
        });
        spyOn(userProfileController.MainNavService, "getMyNavItems").and.callFake(() => {
            return $.Deferred().resolve(data);
        });
        spyOn(userProfileController.OAuthService, "getNewToken").and.callFake(() => {
            return $.Deferred().resolve(null);
        });

        userProfileController.changeUserProfile();

        expect(userProfileController.changeUserProfile).toHaveBeenCalled();
        expect(userProfileController.UserProfileService.setCurrentProfile).toHaveBeenCalled();
        expect(userProfileController.MainNavService.getMyNavItems).toHaveBeenCalled();
        expect(userProfileController.OAuthService.getNewToken).toHaveBeenCalled();
    });


    it('The userProfile controller changeUserProfile function works - resolve path - getNewToken fails', () => {
        userProfileController.selectedUserProfile = currentUserProfile;
        spyOn(userProfileController, "changeUserProfile").and.callThrough();
        spyOn(userProfileController.UserProfileService, "setCurrentProfile").and.callFake(() => {
            return $.Deferred().resolve(userProfile);
        });
        spyOn(userProfileController.MainNavService, "getMyNavItems").and.callFake(() => {
            return $.Deferred().resolve(data);
        });
        spyOn(userProfileController.OAuthService, "getNewToken").and.callFake(() => {
            return $.Deferred().reject();
        });

        userProfileController.changeUserProfile();

        expect(userProfileController.changeUserProfile).toHaveBeenCalled();
        expect(userProfileController.UserProfileService.setCurrentProfile).toHaveBeenCalled();
        expect(userProfileController.MainNavService.getMyNavItems).toHaveBeenCalled();
    });

    it('The userProfile controller changeUserProfile function works - reject path', () => {
        userProfileController.selectedUserProfile = currentUserProfile;
        spyOn(userProfileController, "changeUserProfile").and.callThrough();
        spyOn(userProfileController.UserProfileService, "setCurrentProfile").and.callFake(() => {
            return $.Deferred().reject();
        });

        userProfileController.changeUserProfile();

        expect(userProfileController.changeUserProfile).toHaveBeenCalled();
        expect(userProfileController.UserProfileService.setCurrentProfile).toHaveBeenCalled();
    });

    it('The userProfile controller getActiveUserProfiles function works - reject path', () => {
        spyOn(userProfileController, "getActiveUserProfiles").and.callThrough();
        spyOn(userProfileController.UserProfileService, "getActiveUserProfiles").and.callFake(() => {
            return $.Deferred().reject();
        });

        userProfileController.getActiveUserProfiles();

        expect(userProfileController.getActiveUserProfiles).toHaveBeenCalled();
        expect(userProfileController.UserProfileService.getActiveUserProfiles).toHaveBeenCalled();
    });

    it('The userProfile controller goToEditUserProfileGeneralInfo function works', () => {
        spyOn(mock.$state, 'go');
        spyOn(userProfileController, "goToEditUserProfileGeneralInfo").and.callThrough();

        userProfileController.goToEditUserProfileGeneralInfo();

        expect(userProfileController.goToEditUserProfileGeneralInfo).toHaveBeenCalled();
        expect(mock.$state.go).toHaveBeenCalledWith(mock.StateConstants.USER_PROFILE_EDIT_GEN_INFO);
    });
});

