import "../../../../../src/module";
import "../../../../../src/home/module";
import "../../../../../src/home/catalog/module";
import "../../../../../src/home/catalog/_services/module";
import "../../../../../src/home/catalog/_views/module";
import {CurrentUserProfile} from "../../../../../src/_models/currentUserProfile.model";

describe('Home/Catalog/_Views CatalogController Tests', () => {

    var catalogSearchController;
    var mock;

    beforeEach(() => {
        module('DmlesModule');
        module('Dmles.Home.Module');
        module('Dmles.Home.CatalogModule');
        module('Dmles.Home.Catalog.Views.Module');
        module('Dmles.MainNav.Module');

        inject(($rootScope, $controller, $q, CatalogService, AcquisitionCostFilter, ManufacturerFilter,
                SourceOfSupplyFilter, UserService) => {

            mock = {
                $scope: $rootScope.$new(),

                AcquisitionCostFilter: AcquisitionCostFilter,
                ManufacturerFilter: ManufacturerFilter,
                SourceOfSupplyFilter: SourceOfSupplyFilter,
                CatalogService: CatalogService,
                UserService: UserService,
                deferred: $q.defer(),
                skip: $q.defer()
            };

            catalogSearchController = $controller('CatalogSearchController', mock);
        });
    });

        it('Has scope', () => {
            expect(mock.$scope).not.toEqual(undefined);
        });

        it('Has a catalogSearch controller', () => {
            expect(catalogSearchController).toBeDefined();
        });

        it('The catalogSearch controller has a service', () => {
            expect(catalogSearchController.CatalogService).toBeDefined();
        });

        it('Has an AcquisitionCostFilter mock', () => {
            expect(mock.AcquisitionCostFilter).toBeDefined();
        });

        it('Has an SourceOfSupplyFilter mock', () => {
            expect(mock.SourceOfSupplyFilter).toBeDefined();
        });

        it('Has an ManufacturerFilter mock', () => {
            expect(mock.ManufacturerFilter).toBeDefined();
        });

        it('Has an CatalogService mock', () => {
            expect(mock.CatalogService).toBeDefined();
        });

        it('Execute Search works with good input', () => {
            var searchInput = "isotemp freezer";
            var dodaac = "W33DME";
            catalogSearchController.searchInput = searchInput;
            catalogSearchController.userSpecifiedFilters = [];

            spyOn(mock.CatalogService, "getEquipItems").and.returnValue(mock.deferred.promise);

            catalogSearchController.executeSearch();

            var mockResponse = {
                "data": {
                    "took": 26,
                    "timed_out": false,
                    "_shards": {
                        "total": 296,
                        "successful": 296,
                        "failed": 0
                    },
                    "hits": {
                        "total": 1,
                        "max_score": 1.7241237,
                        "hits": [{
                            "_index": "siteequipitemlist",
                            "_type": "Oracle-SiteEquipItemList",
                            "_id": "FM527013-986-144",
                            "_score": 1.7241237,
                            "fields": {
                                "itemSerial": [32544],
                                "ipPackQty": [1],
                                "shortItemDesc": ["FISHER ISOTEMP FREEZER"],
                                "demilCd": ["A"],
                                "freeIssueInd": ["N"],
                                "milServiceId": ["AF"],
                                "deviceCd": ["15145"],
                                "eiVoltageRate": ["100"],
                                "orgId": ["FM5270"],
                                "eiMaintReqrCd": ["Y"],
                                "deviceCentralMgInd": ["Y"],
                                "sosCd": ["OGR"],
                                "eiHertzRate": ["60"],
                                "vendItemNum": ["13-986-144"],
                                "eorSerial": [16],
                                "eiAccntblCd": ["Y"],
                                "manufacturerNm": ["MODERN LABORATORY SERVICES"],
                                "longItemDesc": ["FISHER ISOTEMP FREEZER"],
                                "eiTmdeInd": ["N"],
                                "standardized": ["N"],
                                "commodClsSerial": [7],
                                "phaseRate": ["SINGLE"],
                                "commodityClsNm": ["EQUIPMENT-EXPENSE MEDICAL"],
                                "deviceText": ["FREEZER, LABORATORY"],
                                "packPriceAmt": [6134.52],
                                "activeEquipRecords": [0],
                                "supplierNm": ["V. A. LOGISTICS CENTER"],
                                "itemId": ["13-986-144"],
                                "inactiveEquipRecords": [1],
                                "systemTypeCd": ["I"],
                                "hazmatCd": ["N"],
                                "sosTypeCd": ["DLA"],
                                "typeItemId": ["MFG/PN"],
                                "pcPayInd": ["N"],
                                "commType": ["Q"],
                                "capitalEquip": ["N"],
                                "burdenedPriceAmt": [6134.52],
                                "manufCatNum": ["13-986-144"],
                                "commcClassCentralMgInd": ["Y"],
                                "acctReqCd": ["2"],
                                "packCd": ["EA"],
                                "ipPackCd": ["EA"]
                            }
                        }]
                    }
                }
            };

            mock.deferred.resolve(mockResponse);
            mock.$scope.$apply();

            expect(catalogSearchController.executeSearch).toHaveBeenCalled();
            expect(catalogSearchController.getCatalogItems).toHaveBeenCalled();
            expect(catalogSearchController.processUserSpecifiedFilters).toHaveBeenCalled();
            expect(mock.CatalogService.getEquipItems).toHaveBeenCalled();
            expect(mock.CatalogService.getEquipItems).toHaveBeenCalledWith(searchInput, dodaac, "");

            expect(catalogSearchController.catalogSearchResults.length).toBeGreaterThan(0);
        });

        it('Execute Search works with bad input', () => {
            var searchInput = "banana";
            var dodaac = "W33DME";
            catalogSearchController.searchInput = searchInput;
            catalogSearchController.userSpecifiedFilters = [];

            spyOn(mock.CatalogService, "getEquipItems").and.returnValue(mock.deferred.promise);

            catalogSearchController.executeSearch();

            var mockResponse = {
                "data": {
                    "took": 26,
                    "timed_out": false,
                    "_shards": {
                        "total": 296,
                        "successful": 296,
                        "failed": 0
                    },
                    "hits": {
                        "total": 0,
                        "max_score": null,
                        "hits": []
                    }
                }
            };

            mock.deferred.resolve(mockResponse);
            mock.$scope.$apply();

            expect(catalogSearchController.executeSearch).toHaveBeenCalled();
            expect(catalogSearchController.getCatalogItems).toHaveBeenCalled();
            expect(catalogSearchController.processUserSpecifiedFilters).toHaveBeenCalled();
            expect(mock.CatalogService.getEquipItems).toHaveBeenCalled();
            expect(mock.CatalogService.getEquipItems).toHaveBeenCalledWith(searchInput, dodaac, "");

            expect(catalogSearchController.catalogSearchResults.length).toBe(0);
        });

        //it('Process filters with good input', () => {
        //    var optionsSelected = "isotemp freezer";
        //    var dodaac = "W33DME";
        //    catalogSearchController.searchInput = searchInput;
        //    catalogSearchController.userSpecifiedFilters = [];
        //
        //    spyOn(mock.CatalogService, "getEquipItems").and.returnValue(mock.deferred.promise);
        //
        //    catalogSearchController.getCatalogItems();
        //
        //    var mockResponse = {
        //        "data" : {
        //            "took": 26,
        //            "timed_out": false,
        //            "_shards": {
        //                "total": 296,
        //                "successful": 296,
        //                "failed": 0
        //            },
        //            "hits": {
        //                "total": 1,
        //                "max_score": 1.7241237,
        //                "hits": [{
        //                    "_index": "siteequipitemlist",
        //                    "_type": "Oracle-SiteEquipItemList",
        //                    "_id": "FM527013-986-144",
        //                    "_score": 1.7241237,
        //                    "fields": {
        //                        "itemSerial": [32544],
        //                        "ipPackQty": [1],
        //                        "shortItemDesc": ["FISHER ISOTEMP FREEZER"],
        //                        "demilCd": ["A"],
        //                        "freeIssueInd": ["N"],
        //                        "milServiceId": ["AF"],
        //                        "deviceCd": ["15145"],
        //                        "eiVoltageRate": ["100"],
        //                        "orgId": ["FM5270"],
        //                        "eiMaintReqrCd": ["Y"],
        //                        "deviceCentralMgInd": ["Y"],
        //                        "sosCd": ["OGR"],
        //                        "eiHertzRate": ["60"],
        //                        "vendItemNum": ["13-986-144"],
        //                        "eorSerial": [16],
        //                        "eiAccntblCd": ["Y"],
        //                        "manufacturerNm": ["MODERN LABORATORY SERVICES"],
        //                        "longItemDesc": ["FISHER ISOTEMP FREEZER"],
        //                        "eiTmdeInd": ["N"],
        //                        "standardized": ["N"],
        //                        "commodClsSerial": [7],
        //                        "phaseRate": ["SINGLE"],
        //                        "commodityClsNm": ["EQUIPMENT-EXPENSE MEDICAL"],
        //                        "deviceText": ["FREEZER, LABORATORY"],
        //                        "packPriceAmt": [6134.52],
        //                        "activeEquipRecords": [0],
        //                        "supplierNm": ["V. A. LOGISTICS CENTER"],
        //                        "itemId": ["13-986-144"],
        //                        "inactiveEquipRecords": [1],
        //                        "systemTypeCd": ["I"],
        //                        "hazmatCd": ["N"],
        //                        "sosTypeCd": ["DLA"],
        //                        "typeItemId": ["MFG/PN"],
        //                        "pcPayInd": ["N"],
        //                        "commType": ["Q"],
        //                        "capitalEquip": ["N"],
        //                        "burdenedPriceAmt": [6134.52],
        //                        "manufCatNum": ["13-986-144"],
        //                        "commcClassCentralMgInd": ["Y"],
        //                        "acctReqCd": ["2"],
        //                        "packCd": ["EA"],
        //                        "ipPackCd": ["EA"]
        //                    }
        //                }]
        //            }
        //        }
        //    };
        //
        //    mock.deferred.resolve(mockResponse);
        //    mock.$scope.$apply();
        //
        //    expect(mock.CatalogService.getEquipItems).toHaveBeenCalled();
        //    expect(mock.CatalogService.getEquipItems).toHaveBeenCalledWith(searchInput, dodaac, "");
        //
        //    expect(catalogSearchController.catalogSearchResults.length).toBeGreaterThan(0);
        //});

    });
