import "../../../../../src/module";
import "../../../../../src/home/module";
import "../../../../../src/home/catalog/module";
import "../../../../../src/home/catalog/_services/module";
import "../../../../../src/home/catalog/_views/module";
import {RequestService} from "../../../../../src/home/equipment/requests/_services/request.service";
import {StateConstants} from "../../../../../src/_constants/state.constants";

describe('Home/Catalog/_Views CatalogFavoritesController Tests', () => {

    var catalogFavoritesController;
    var mock;

    beforeEach(() => {
        module('DmlesModule');
        module('Dmles.Home.Module');
        module('Dmles.Home.CatalogModule');
        module('Dmles.Home.Catalog.Views.Module');

        inject(($rootScope, $controller, $q, $state, CatalogService, EquipmentRecordService,
                RequestService, StateConstants) => {
            mock = {
                $rootScope: $rootScope,
                $scope: $rootScope.$new(),
                $state: $state,

                CatalogService: CatalogService,
                EquipmentRecordService: EquipmentRecordService,
                RequestService: RequestService,
                deferred: $q.defer(),
                skip: $q.defer()
            };

            catalogFavoritesController = $controller('CatalogFavoritesController', mock);
        });

    });

    it('Has scope', () => {
        expect(mock.$scope).not.toEqual(undefined);
    });

    it('Has a catalogFavoritesController controller', () => {
        expect(catalogFavoritesController).toBeDefined();
    });

    it('The catalogFavoritesController controller has a CatalogService', () => {
        expect(catalogFavoritesController.CatalogService).toBeDefined();
    });

    it('The catalogFavoritesController controller has a EquipmentRecordService', () => {
        expect(catalogFavoritesController.EquipmentRecordService).toBeDefined();
    });

    it('The catalogFavoritesController controller has a RequestService', () => {
        expect(catalogFavoritesController.RequestService).toBeDefined();
    });

    it('createRequest success', () => {
        var item = {
            "acctReqCd": "2",
            "activeEquipRecords": 0,
            "burdenedPriceAmt": 3731.84,
            "capitalEquip": "N",
            "cartPrice": 0,
            "cartQuantity": 0,
            "ciiCd": "",
            "cogCd": "",
            "commType": "Q",
            "commcClassCentralMgInd": "Y",
            "commodClsSerial": 7,
            "commodityClsNm": "EQUIPMENT-EXPENSE MEDICAL",
            "contractTypeCd": "",
            "createDt": "",
            "createUserId": "",
            "dapaNum": "",
            "demilCd": "A",
            "deviceCd": "C0167",
            "deviceCentralMgInd": "Y",
            "deviceText": "METER, SOUND LEVEL",
            "dispAuthorityCd": "",
            "dmTypeCd": "",
            "ecatItemId": "",
            "eiAccntblCd": "Y",
            "eiEqpmtSrc": "",
            "eiHertzRate": "60",
            "eiLineItemNum": "",
            "eiLogsControlCd": "",
            "eiMaintReqrCd": "Y",
            "eiTmdeInd": "N",
            "eiVoltageRate": "110",
            "endItemCd": "",
            "eorSerial": 16,
            "eqpmtCategoryCd": "",
            "eqpmtModelNum": "",
            "freeIssueInd": "N",
            "hazmatCd": "N",
            "hibcc": "",
            "id": "",
            "inactiveEquipRecords": 0,
            "ipPackCd": "EA",
            "ipPackQty": 1,
            "itemCatCd": "",
            "itemId": "4138-A-015",
            "itemSerial": 52962,
            "lastUpdateDt": "",
            "lastUpdateUserId": "",
            "longItemDesc": "'1/8' PRESSURE FIELD MICROPHONE, PREAMPLIFIER 2670",
            "manufCatNum": "4138-A-0105",
            "manufacturerNm": "BRUEL & KJAER",
            "milServiceId": "AF",
            "naicsSerial": "",
            "ndc": "",
            "nsn": "",
            "orgId": "FM5270",
            "packCd": "",
            "packPriceAmt": 3731.84,
            "pcPayInd": "N",
            "phaseRate": "SINGLE",
            "productSeqId": "",
            "quantity": 1,
            "shortItemDesc": "'1/8' PRESSURE FIELD MICROPHONE, PREAMP",
            "sosCd": "LPP",
            "sosTypeCd": "CON",
            "standardized": "N",
            "supplierNm": "AFMOA CONTRACTING DIVISION",
            "systemTypeCd": "C",
            "typeItemId": "MFG/PN",
            "upCreateDt": "",
            "upCreateUserId": "",
            "upLastUpdateDt": "",
            "upLastUpdateUserId": "",
            "vendItemNum": "4138-A-0105",
        };

        spyOn(catalogFavoritesController, "createRequest").and.callThrough();
        spyOn(mock.RequestService, "clearRequest").and.callThrough();
        spyOn(mock.RequestService, "buildRequestFromCatalog").and.callThrough();
        spyOn(mock.$state, "go" );

        catalogFavoritesController.createRequest(item);

        expect(catalogFavoritesController.createRequest).toHaveBeenCalled();
        expect(mock.RequestService.clearRequest).toHaveBeenCalled();
        expect(mock.RequestService.buildRequestFromCatalog).toHaveBeenCalledWith(item,0);
        expect(mock.$state.go).toHaveBeenCalledWith(StateConstants.EQUIP_REQUEST_VIEW);

    });

    it('goToDetails success', () => {
        var item = {
            "acctReqCd": "2",
            "activeEquipRecords": 0,
            "burdenedPriceAmt": 3731.84,
            "capitalEquip": "N",
            "cartPrice": 0,
            "cartQuantity": 0,
            "ciiCd": "",
            "cogCd": "",
            "commType": "Q",
            "commcClassCentralMgInd": "Y",
            "commodClsSerial": 7,
            "commodityClsNm": "EQUIPMENT-EXPENSE MEDICAL",
            "contractTypeCd": "",
            "createDt": "",
            "createUserId": "",
            "dapaNum": "",
            "demilCd": "A",
            "deviceCd": "C0167",
            "deviceCentralMgInd": "Y",
            "deviceText": "METER, SOUND LEVEL",
            "dispAuthorityCd": "",
            "dmTypeCd": "",
            "ecatItemId": "",
            "eiAccntblCd": "Y",
            "eiEqpmtSrc": "",
            "eiHertzRate": "60",
            "eiLineItemNum": "",
            "eiLogsControlCd": "",
            "eiMaintReqrCd": "Y",
            "eiTmdeInd": "N",
            "eiVoltageRate": "110",
            "endItemCd": "",
            "eorSerial": 16,
            "eqpmtCategoryCd": "",
            "eqpmtModelNum": "",
            "freeIssueInd": "N",
            "hazmatCd": "N",
            "hibcc": "",
            "id": "",
            "inactiveEquipRecords": 0,
            "ipPackCd": "EA",
            "ipPackQty": 1,
            "itemCatCd": "",
            "itemId": "4138-A-015",
            "itemSerial": 52962,
            "lastUpdateDt": "",
            "lastUpdateUserId": "",
            "longItemDesc": "'1/8' PRESSURE FIELD MICROPHONE, PREAMPLIFIER 2670",
            "manufCatNum": "4138-A-0105",
            "manufacturerNm": "BRUEL & KJAER",
            "milServiceId": "AF",
            "naicsSerial": "",
            "ndc": "",
            "nsn": "",
            "orgId": "FM5270",
            "packCd": "",
            "packPriceAmt": 3731.84,
            "pcPayInd": "N",
            "phaseRate": "SINGLE",
            "productSeqId": "",
            "quantity": 1,
            "shortItemDesc": "'1/8' PRESSURE FIELD MICROPHONE, PREAMP",
            "sosCd": "LPP",
            "sosTypeCd": "CON",
            "standardized": "N",
            "supplierNm": "AFMOA CONTRACTING DIVISION",
            "systemTypeCd": "C",
            "typeItemId": "MFG/PN",
            "upCreateDt": "",
            "upCreateUserId": "",
            "upLastUpdateDt": "",
            "upLastUpdateUserId": "",
            "vendItemNum": "4138-A-0105",
        };

        spyOn(catalogFavoritesController, "goToDetails").and.callThrough();
        spyOn(mock.CatalogService, "setCatalogItem").and.callThrough();
        spyOn(mock.$state, "go" );

        catalogFavoritesController.goToDetails(item);

        expect(catalogFavoritesController.goToDetails).toHaveBeenCalled();
        expect(mock.CatalogService.setCatalogItem).toHaveBeenCalled();
        expect(mock.$state.go).toHaveBeenCalledWith(StateConstants.CATALOG_ITEM_DETAILS);

    });

    it('gotToEquipmentRecord - Active record success', () => {
        var item = {
            "acctReqCd": "2",
            "activeEquipRecords": 0,
            "burdenedPriceAmt": 3731.84,
            "capitalEquip": "N",
            "cartPrice": 0,
            "cartQuantity": 0,
            "ciiCd": "",
            "cogCd": "",
            "commType": "Q",
            "commcClassCentralMgInd": "Y",
            "commodClsSerial": 7,
            "commodityClsNm": "EQUIPMENT-EXPENSE MEDICAL",
            "contractTypeCd": "",
            "createDt": "",
            "createUserId": "",
            "dapaNum": "",
            "demilCd": "A",
            "deviceCd": "C0167",
            "deviceCentralMgInd": "Y",
            "deviceText": "METER, SOUND LEVEL",
            "dispAuthorityCd": "",
            "dmTypeCd": "",
            "ecatItemId": "",
            "eiAccntblCd": "Y",
            "eiEqpmtSrc": "",
            "eiHertzRate": "60",
            "eiLineItemNum": "",
            "eiLogsControlCd": "",
            "eiMaintReqrCd": "Y",
            "eiTmdeInd": "N",
            "eiVoltageRate": "110",
            "endItemCd": "",
            "eorSerial": 16,
            "eqpmtCategoryCd": "",
            "eqpmtModelNum": "",
            "freeIssueInd": "N",
            "hazmatCd": "N",
            "hibcc": "",
            "id": "",
            "inactiveEquipRecords": 0,
            "ipPackCd": "EA",
            "ipPackQty": 1,
            "itemCatCd": "",
            "itemId": "4138-A-015",
            "itemSerial": 52962,
            "lastUpdateDt": "",
            "lastUpdateUserId": "",
            "longItemDesc": "'1/8' PRESSURE FIELD MICROPHONE, PREAMPLIFIER 2670",
            "manufCatNum": "4138-A-0105",
            "manufacturerNm": "BRUEL & KJAER",
            "milServiceId": "AF",
            "naicsSerial": "",
            "ndc": "",
            "nsn": "",
            "orgId": "FM5270",
            "packCd": "",
            "packPriceAmt": 3731.84,
            "pcPayInd": "N",
            "phaseRate": "SINGLE",
            "productSeqId": "",
            "quantity": 1,
            "shortItemDesc": "'1/8' PRESSURE FIELD MICROPHONE, PREAMP",
            "sosCd": "LPP",
            "sosTypeCd": "CON",
            "standardized": "N",
            "supplierNm": "AFMOA CONTRACTING DIVISION",
            "systemTypeCd": "C",
            "typeItemId": "MFG/PN",
            "upCreateDt": "",
            "upCreateUserId": "",
            "upLastUpdateDt": "",
            "upLastUpdateUserId": "",
            "vendItemNum": "4138-A-0105",
        };
        var isActive:boolean = true;

        spyOn(catalogFavoritesController, "gotToEquipmentRecord").and.callThrough();
        spyOn(mock.$state, "go" );

        catalogFavoritesController.gotToEquipmentRecord(item, isActive);

        expect(catalogFavoritesController.gotToEquipmentRecord).toHaveBeenCalled();
        expect(mock.EquipmentRecordService.itemFromCatalog.catalogItem).toBe(item);
        expect(mock.EquipmentRecordService.itemFromCatalog.isActive).toBe(isActive);
        expect(mock.$state.go).toHaveBeenCalledWith(StateConstants.EQUIP_RECORD_DETAILS);

    });

    it('gotToEquipmentRecord - In-Active record success', () => {
        var item = {
            "acctReqCd": "2",
            "activeEquipRecords": 0,
            "burdenedPriceAmt": 3731.84,
            "capitalEquip": "N",
            "cartPrice": 0,
            "cartQuantity": 0,
            "ciiCd": "",
            "cogCd": "",
            "commType": "Q",
            "commcClassCentralMgInd": "Y",
            "commodClsSerial": 7,
            "commodityClsNm": "EQUIPMENT-EXPENSE MEDICAL",
            "contractTypeCd": "",
            "createDt": "",
            "createUserId": "",
            "dapaNum": "",
            "demilCd": "A",
            "deviceCd": "C0167",
            "deviceCentralMgInd": "Y",
            "deviceText": "METER, SOUND LEVEL",
            "dispAuthorityCd": "",
            "dmTypeCd": "",
            "ecatItemId": "",
            "eiAccntblCd": "Y",
            "eiEqpmtSrc": "",
            "eiHertzRate": "60",
            "eiLineItemNum": "",
            "eiLogsControlCd": "",
            "eiMaintReqrCd": "Y",
            "eiTmdeInd": "N",
            "eiVoltageRate": "110",
            "endItemCd": "",
            "eorSerial": 16,
            "eqpmtCategoryCd": "",
            "eqpmtModelNum": "",
            "freeIssueInd": "N",
            "hazmatCd": "N",
            "hibcc": "",
            "id": "",
            "inactiveEquipRecords": 0,
            "ipPackCd": "EA",
            "ipPackQty": 1,
            "itemCatCd": "",
            "itemId": "4138-A-015",
            "itemSerial": 52962,
            "lastUpdateDt": "",
            "lastUpdateUserId": "",
            "longItemDesc": "'1/8' PRESSURE FIELD MICROPHONE, PREAMPLIFIER 2670",
            "manufCatNum": "4138-A-0105",
            "manufacturerNm": "BRUEL & KJAER",
            "milServiceId": "AF",
            "naicsSerial": "",
            "ndc": "",
            "nsn": "",
            "orgId": "FM5270",
            "packCd": "",
            "packPriceAmt": 3731.84,
            "pcPayInd": "N",
            "phaseRate": "SINGLE",
            "productSeqId": "",
            "quantity": 1,
            "shortItemDesc": "'1/8' PRESSURE FIELD MICROPHONE, PREAMP",
            "sosCd": "LPP",
            "sosTypeCd": "CON",
            "standardized": "N",
            "supplierNm": "AFMOA CONTRACTING DIVISION",
            "systemTypeCd": "C",
            "typeItemId": "MFG/PN",
            "upCreateDt": "",
            "upCreateUserId": "",
            "upLastUpdateDt": "",
            "upLastUpdateUserId": "",
            "vendItemNum": "4138-A-0105",
        };
        var isActive:boolean = false;

        spyOn(catalogFavoritesController, "gotToEquipmentRecord").and.callThrough();
        spyOn(mock.$state, "go" );

        catalogFavoritesController.gotToEquipmentRecord(item, isActive);

        expect(catalogFavoritesController.gotToEquipmentRecord).toHaveBeenCalled();
        expect(mock.EquipmentRecordService.itemFromCatalog.catalogItem).toBe(item);
        expect(mock.EquipmentRecordService.itemFromCatalog.isActive).toBe(isActive);
        expect(mock.$state.go).toHaveBeenCalledWith(StateConstants.EQUIP_RECORD_DETAILS);

    });

    it('goToPreviousState - previous state success', () => {
        mock.$rootScope.previousState = StateConstants.EQUIP_REQUEST_MY_REQUESTS;
        spyOn(mock.$state, "go" );

        catalogFavoritesController.goToPreviousState();

        expect(mock.$state.go).toHaveBeenCalledWith(StateConstants.EQUIP_REQUEST_MY_REQUESTS);

    });

    it('goToPreviousState - no previous state success', () => {
        spyOn(mock.$state, "go" );

        catalogFavoritesController.goToPreviousState();

        expect(mock.$state.go).toHaveBeenCalledWith(StateConstants.CATALOG_SEARCH);

    });
});