import "../../../../../src/module";
import "../../../../../src/home/module";
import "../../../../../src/home/catalog/module";
import "../../../../../src/home/catalog/_services/module";
import "../../../../../src/home/catalog/_views/module";

describe('Home/Catalog/_Views CatalogItemDetailsController Tests', () => {

    var catalogItemDetailsController;
    var mock;

    beforeEach(() => {
        module('DmlesModule');
        module('Dmles.Home.Module');
        module('Dmles.Home.CatalogModule');
        module('Dmles.Home.Catalog.Views.Module');

        inject(($rootScope, $controller, $q, CatalogService, StateConstants) => {
            mock = {
                $scope: $rootScope.$new(),

                CatalogService: CatalogService,
                deferred: $q.defer(),
                skip: $q.defer()
            };

            catalogItemDetailsController = $controller('CatalogItemDetailsController', mock);
        });

    });

    it('Has scope', () => {
        expect(mock.$scope).not.toEqual(undefined);
    });

    it('Has a catalogItemDetailsController controller', () => {
        expect(catalogItemDetailsController).toBeDefined();
    });

    it('The catalogItemDetailsController controller has a service', () => {
        expect(catalogItemDetailsController.CatalogService).toBeDefined();
    });
});