import "../../../../../src/module";
import "../../../../../src/home/module";
import "../../../../../src/home/catalog/module";
import "../../../../../src/home/catalog/_views/module";

describe('Catalog Records _Views Module Tests', () => {
    var catalogFavoritesController;
    var catalogItemDetailsController;
    var catalogSearchController;
    var mock;

    beforeEach(() => {
        module('DmlesModule');
        module('Dmles.Home.Module');
        module('Dmles.Home.CatalogModule');
        module('Dmles.Home.Catalog.Views.Module');
    });

    beforeEach(inject(($rootScope, $controller) => {
        mock = {
            $scope: $rootScope.$new(),
        };

        catalogFavoritesController = $controller('CatalogFavoritesController', mock);
        catalogItemDetailsController = $controller('CatalogItemDetailsController', mock);
        catalogSearchController = $controller('CatalogSearchController', mock);
    }));

    it('Has an catalog controller', () => {
        expect(catalogSearchController).toBeDefined();
    });

    it('Has an catalogItemDetailsController controller', () => {
        expect(catalogItemDetailsController).toBeDefined();
    });

    it('Has an catalogFavoritesController controller', () => {
        expect(catalogFavoritesController).toBeDefined();
    });
});