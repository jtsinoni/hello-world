import "../../../../src/module";
import "../../../../src/home/module";
import "../../../../src/home/catalog/module";

describe('Catalog Module Tests', () => {

    beforeEach(() => {
        module('DmlesModule');
        module('Dmles.Home.Module');
        module('Dmles.Home.CatalogModule');
    });

    var controller;
    var scope;

    beforeEach(inject(($rootScope, $controller) => {
        scope = $rootScope.$new();
    }));

    it('Has scope', () => {
        expect(scope).toBeDefined();
    });

});