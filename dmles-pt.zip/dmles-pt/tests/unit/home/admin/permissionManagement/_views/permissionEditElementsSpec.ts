import "../../../../../../src/module";
import "../../../../../../src/home/module";
import "../../../../../../src/home/admin/module";
import "../../../../../../src/home/admin/permissionManagement/module";
import "../../../../../../src/home/admin/permissionManagement/_services/module";
import "../../../../../../src/home/admin/permissionManagement/_views/module";

describe('Admin PermissionManagement _Views PermissionEditElements.Controller Tests', () => {
    var permissionEditElementsController;
    var mock;

    var permission = {
        "id": "57800a1e768bbb531eecd243",
        "name": "Manage User Profiles",
        "functionalArea": "Administration",
        "description": "Manage User Profiles"
    };

    var allElements = [{"id": "57718452d0142fa833276e73", "name": "all"}, {
        "id": "57718452d0142fa833276e6e",
        "name": "equip-approve"
    }, {"id": "57718452d0142fa833276e66", "name": "equip-catalog"}, {
        "id": "57718452d0142fa833276e68",
        "name": "equip-my-requests"
    }, {"id": "57718452d0142fa833276e70", "name": "equip-records"}, {
        "id": "57718452d0142fa833276e71",
        "name": "equip-records-search"
    }, {"id": "57718452d0142fa833276e67", "name": "equip-request-create"}, {
        "id": "57718452d0142fa833276e6b",
        "name": "equip-request-facilities"
    }, {"id": "57718452d0142fa833276e6c", "name": "equip-request-maintenance"}, {
        "id": "578011b0768bbb531eecd250",
        "name": "equip-request-safety"
    }, {"id": "57718452d0142fa833276e6d", "name": "equip-request-technology"}, {
        "id": "57718452d0142fa833276e6a",
        "name": "equip-request-weighin"
    }, {"id": "57718452d0142fa833276e69", "name": "equip-review"}, {
        "id": "57718452d0142fa833276e6f",
        "name": "equip-update"
    }, {"id": "57718452d0142fa833276e72", "name": "jmar"}, {
        "id": "57ade6d8a8ac2ac9a4fdc8de",
        "name": "permission-management"
    }, {"id": "57718452d0142fa833276e65", "name": "requests-service"}, {
        "id": "57718452d0142fa833276e64",
        "name": "role-management"
    }, {"id": "57718452d0142fa833276e63", "name": "user-profile-management"}];

    var myPermissionManagementService;

    beforeEach(() => {
        module('DmlesModule');
        module('Dmles.Home.Module');
        module('Dmles.AdminModule');
        module('Dmles.Admin.PermissionManagementModule');
        module('Dmles.Admin.PermissionManagement.Views.Module');

        inject(($rootScope, $controller, PermissionManagementService) => {

            spyOn(PermissionManagementService, 'getPermission').and.callFake(() => {
                return permission;
            });
            spyOn(PermissionManagementService, 'getAllElements').and.callFake(() => {
                return allElements;
            });
            spyOn(PermissionManagementService, 'savePermissionElements').and.callFake(() => {
                return permission;
            });
            myPermissionManagementService = PermissionManagementService;

            mock = {
                $scope: $rootScope.$new(),
                PermissionManagementService: myPermissionManagementService
            };

            permissionEditElementsController = $controller('Dmles.Admin.PermissionManagement.Views.PermissionEditElementsController', mock);
        });
    });

    it('Has scope', () => {
        expect(mock.$scope).not.toEqual(undefined);
    });

    it('Has a permissionEditElementsController controller', () => {
        expect(permissionEditElementsController).toBeDefined();
    });

    it('Has an PermissionManagement Service', () => {
        expect(permissionEditElementsController.PermissionManagementService).toBeDefined();
    });

    it('The permissionEditElements controller onSubmit function works', () => {
        spyOn(permissionEditElementsController, "onSubmit").and.callThrough();

        permissionEditElementsController.onSubmit();

        expect(permissionEditElementsController.onSubmit).toHaveBeenCalled();
    });
});

