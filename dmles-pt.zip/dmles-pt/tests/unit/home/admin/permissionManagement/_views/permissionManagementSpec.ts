import "../../../../../../src/module";
import "../../../../../../src/home/module";
import "../../../../../../src/home/admin/module";
import "../../../../../../src/home/admin/permissionManagement/module";
import "../../../../../../src/home/admin/permissionManagement/_services/module";
import "../../../../../../src/home/admin/permissionManagement/_views/module";

describe('Admin PermissionManagement _Views PermissionManagement.Controller Tests', () => {
    var permissionManagementController;
    var mock;
    
    var permission = {
        "id": "57800a1e768bbb531eecd243",
        "name": "Manage User Profiles",
        "functionalArea": "Administration",
        "description": "Manage User Profiles"
    };

    beforeEach(() => {
        module('DmlesModule');
        module('Dmles.Home.Module');
        module('Dmles.AdminModule');
        module('Dmles.Admin.PermissionManagementModule');
        module('Dmles.Admin.PermissionManagement.Views.Module');

        inject(($rootScope, $controller, $q, $state, StateConstants, RoleService, PermissionManagementService) => {
            mock = {
                $scope: $rootScope.$new(),
                StateConstants: StateConstants,
                RoleService: RoleService,
                PermissionManagementService: PermissionManagementService,
                deferred: $q.defer(),
                skip: $q.defer(),
                $state: $state
            };

            permissionManagementController = $controller('Dmles.Admin.PermissionManagement.Views.PermissionManagementController', mock);
        });
    });

    it('Has scope', () => {
        expect(mock.$scope).not.toEqual(undefined);
    });

    it('Has a permissionManagementController controller', () => {
        expect(permissionManagementController).toBeDefined();
    });

    it('Has an Role Service', () => {
        expect(permissionManagementController.RoleService).toBeDefined();
    });

    it('Has an PermissionManagement Service', () => {
        expect(permissionManagementController.PermissionManagementService).toBeDefined();
    });

    it('The permissionManagement controller goToPermissionManagement function works', () => {
        spyOn(mock.$state, 'go');
        spyOn(permissionManagementController, "goToPermissionManagement").and.callThrough();

        permissionManagementController.goToPermissionManagement();

        expect(permissionManagementController.goToPermissionManagement).toHaveBeenCalled();
        expect(mock.$state.go).toHaveBeenCalledWith(mock.StateConstants.ADMIN_PERMISSION_MNG);
    });

    it('The permissionManagement controller goToPermissionView function works', () => {
        spyOn(mock.$state, 'go');
        spyOn(permissionManagementController, "goToPermissionView").and.callThrough();

        permissionManagementController.goToPermissionView();

        expect(permissionManagementController.goToPermissionView).toHaveBeenCalled();
        expect(mock.$state.go).toHaveBeenCalledWith(mock.StateConstants.ADMIN_PERMISSION_VIEW);
    });

    it('The permissionManagement controller goToPermissionCreate function works', () => {
        spyOn(mock.$state, 'go');
        spyOn(permissionManagementController, "goToPermissionCreate").and.callThrough();

        permissionManagementController.goToPermissionCreate();

        expect(permissionManagementController.goToPermissionCreate).toHaveBeenCalled();
        expect(mock.$state.go).toHaveBeenCalledWith(mock.StateConstants.ADMIN_PERMISSION_CREATE);
    });

    it('The permissionManagement controller setPermissionToBeDeleted function works', () => {
        spyOn(permissionManagementController, "setPermissionToBeDeleted").and.callThrough();

        permissionManagementController.setPermissionToBeDeleted(permission);

        expect(permissionManagementController.setPermissionToBeDeleted).toHaveBeenCalled();
    });

    it('The permissionManagement controller deletePermission function works - resolve path', () => {
        spyOn(permissionManagementController, "deletePermission").and.callThrough();
        spyOn(permissionManagementController.RoleService, "deletePermissionDetailed").and.callFake(() => {
            return $.Deferred().resolve(permission);
        });

        permissionManagementController.permissionToDelete = permission;
        permissionManagementController.deletePermission();

        expect(permissionManagementController.deletePermission).toHaveBeenCalled();
        expect(permissionManagementController.RoleService.deletePermissionDetailed).toHaveBeenCalled();
    });

    it('The permissionManagement controller deletePermission function works - reject path', () => {
        spyOn(permissionManagementController, "deletePermission").and.callThrough();
        spyOn(permissionManagementController.RoleService, "deletePermissionDetailed").and.callFake(() => {
            return $.Deferred().reject();
        });

        permissionManagementController.permissionToDelete = permission;
        permissionManagementController.deletePermission();

        expect(permissionManagementController.deletePermission).toHaveBeenCalled();
        expect(permissionManagementController.RoleService.deletePermissionDetailed).toHaveBeenCalled();
    });
});

