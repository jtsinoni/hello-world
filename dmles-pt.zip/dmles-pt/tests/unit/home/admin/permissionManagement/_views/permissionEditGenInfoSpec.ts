import "../../../../../../src/module";
import "../../../../../../src/home/module";
import "../../../../../../src/home/admin/module";
import "../../../../../../src/home/admin/permissionManagement/module";
import "../../../../../../src/home/admin/permissionManagement/_services/module";
import "../../../../../../src/home/admin/permissionManagement/_views/module";

describe('Admin PermissionManagement _Views PermissionEditGenInfo.Controller Tests', () => {
    var permissionEditGenInfoController;
    var mock;

    var permission = {
        "id": "57800a1e768bbb531eecd243",
        "name": "Manage User Profiles",
        "functionalArea": "Administration",
        "description": "Manage User Profiles"
    };

    var invalidPermission = {
        "id": "57800a1e768bbb531eecd243",
        "name": "Manage User Profiles",
        "description": "Manage User Profiles"
    };

    var myPermissionManagementService;

    beforeEach(() => {
        module('DmlesModule');
        module('Dmles.Home.Module');
        module('Dmles.AdminModule');
        module('Dmles.Admin.PermissionManagementModule');
        module('Dmles.Admin.PermissionManagement.Views.Module');

        inject(($rootScope, $controller, $q, $state, StateConstants, RoleService, PermissionManagementService) => {

            spyOn(PermissionManagementService, 'getPermission').and.callFake(() => {
                return permission;
            });
            myPermissionManagementService = PermissionManagementService;

            mock = {
                $scope: $rootScope.$new(),
                StateConstants: StateConstants,
                RoleService: RoleService,
                PermissionManagementService: myPermissionManagementService,
                deferred: $q.defer(),
                skip: $q.defer(),
                $state: $state
            };

            permissionEditGenInfoController = $controller('Dmles.Admin.PermissionManagement.Views.PermissionEditGenInfoController', mock);
        });
    });

    it('Has scope', () => {
        expect(mock.$scope).not.toEqual(undefined);
    });

    it('Has a permissionEditGenInfoController controller', () => {
        expect(permissionEditGenInfoController).toBeDefined();
    });

    it('Has a Role Service', () => {
        expect(permissionEditGenInfoController.RoleService).toBeDefined();
    });

    it('Has an PermissionManagement Service', () => {
        expect(permissionEditGenInfoController.PermissionManagementService).toBeDefined();
    });

    it('The permissionEditGenInfo controller onSubmit function works with valid permission', () => {
        spyOn(mock.$state, 'go');
        spyOn(permissionEditGenInfoController, "onSubmit").and.callThrough();

        permissionEditGenInfoController.permission = permission;
        permissionEditGenInfoController.onSubmit();

        expect(permissionEditGenInfoController.onSubmit).toHaveBeenCalled();
        expect(mock.$state.go).toHaveBeenCalledWith(mock.StateConstants.ADMIN_PERMISSION_VIEW);
    });   

    it('The permissionEditGenInfo controller savePermissionGeneralInfo function works - resolve path', () => {        
        spyOn(permissionEditGenInfoController, "savePermissionGeneralInfo").and.callThrough();
        spyOn(permissionEditGenInfoController.RoleService, "savePermissionData").and.callFake(() => {
            return $.Deferred().resolve(permission);
        });

        permissionEditGenInfoController.permission = permission;
        permissionEditGenInfoController.savePermissionGeneralInfo();

        expect(permissionEditGenInfoController.savePermissionGeneralInfo).toHaveBeenCalled();
        expect(permissionEditGenInfoController.RoleService.savePermissionData).toHaveBeenCalled();        
    });

    it('The permissionEditGenInfo controller savePermissionGeneralInfo function works - reject path', () => {        
        spyOn(permissionEditGenInfoController, "savePermissionGeneralInfo").and.callThrough();
        spyOn(permissionEditGenInfoController.RoleService, "savePermissionData").and.callFake(() => {
            return $.Deferred().reject();
        });

        permissionEditGenInfoController.permission = permission;
        permissionEditGenInfoController.savePermissionGeneralInfo();

        expect(permissionEditGenInfoController.savePermissionGeneralInfo).toHaveBeenCalled();        
    });

    
});

