import "../../../../../../src/module";
import "../../../../../../src/home/module";
import "../../../../../../src/home/admin/module";
import "../../../../../../src/home/admin/permissionManagement/module";
import "../../../../../../src/home/admin/permissionManagement/_services/module";
import "../../../../../../src/home/admin/permissionManagement/_views/module";

describe('Admin PermissionManagement _Views PermissionView.Controller Tests', () => {
    var permissionViewController;
    var mock;
    
    var permission = {
        "id": "57800a1e768bbb531eecd243",
        "name": "Manage User Profiles",
        "functionalArea": "Administration",
        "description": "Manage User Profiles"
    };

    var myPermissionManagementService;
    var myUtilService;

    beforeEach(() => {
        module('DmlesModule');
        module('Dmles.Home.Module');
        module('Dmles.AdminModule');
        module('Dmles.Admin.PermissionManagementModule');
        module('Dmles.Admin.PermissionManagement.Views.Module');

        inject(($rootScope, $controller, $q, $state, StateConstants, UtilService, PermissionManagementService) => {

            spyOn(PermissionManagementService, 'getPermission').and.callFake(() => {
                return permission;
            });
            myPermissionManagementService = PermissionManagementService;

            spyOn(UtilService, 'sortResults').and.callFake(() => {
                return [];
            });
            myUtilService = UtilService;

            mock = {
                $scope: $rootScope.$new(),
                StateConstants: StateConstants,
                UtilService: myUtilService,
                PermissionManagementService: myPermissionManagementService,
                deferred: $q.defer(),
                skip: $q.defer(),
                $state: $state
            };

            permissionViewController = $controller('Dmles.Admin.PermissionManagement.Views.PermissionViewController', mock);
        });
    });

    it('Has scope', () => {
        expect(mock.$scope).not.toEqual(undefined);
    });

    it('Has a permissionViewController controller', () => {
        expect(permissionViewController).toBeDefined();
    });

    it('Has a Util Service', () => {
        expect(permissionViewController.UtilService).toBeDefined();
    });

    it('Has an PermissionManagement Service', () => {
        expect(permissionViewController.PermissionManagementService).toBeDefined();
    });

    it('The permissionView controller goToPermissionAdmin function works', () => {
        spyOn(mock.$state, 'go');
        spyOn(permissionViewController, "goToPermissionAdmin").and.callThrough();

        permissionViewController.goToPermissionAdmin();

        expect(permissionViewController.goToPermissionAdmin).toHaveBeenCalled();
        expect(mock.$state.go).toHaveBeenCalledWith(mock.StateConstants.ADMIN_PERMISSION_MNG);
    });

    it('The permissionView controller goToEditPermissionGeneralInfo function works', () => {
        spyOn(mock.$state, 'go');
        spyOn(permissionViewController, "goToEditPermissionGeneralInfo").and.callThrough();

        permissionViewController.goToEditPermissionGeneralInfo();

        expect(permissionViewController.goToEditPermissionGeneralInfo).toHaveBeenCalled();
        expect(mock.$state.go).toHaveBeenCalledWith(mock.StateConstants.ADMIN_PERMISSION_EDIT_GEN_INFO);
    });

    it('The permissionView controller goToEditPermissionElements function works', () => {
        spyOn(mock.$state, 'go');
        spyOn(permissionViewController, "goToEditPermissionElements").and.callThrough();

        permissionViewController.goToEditPermissionElements();

        expect(permissionViewController.goToEditPermissionElements).toHaveBeenCalled();
        expect(mock.$state.go).toHaveBeenCalledWith(mock.StateConstants.ADMIN_PERMISSION_EDIT_ELEMENTS);
    });

    it('The permissionView controller goToEditPermissionEndpoints function works', () => {
        spyOn(mock.$state, 'go');
        spyOn(permissionViewController, "goToEditPermissionEndpoints").and.callThrough();

        permissionViewController.goToEditPermissionEndpoints();

        expect(permissionViewController.goToEditPermissionEndpoints).toHaveBeenCalled();
        expect(mock.$state.go).toHaveBeenCalledWith(mock.StateConstants.ADMIN_PERMISSION_EDIT_ENDPOINTS);
    });

    it('The permissionView controller goToEditPermissionStates function works', () => {
        spyOn(mock.$state, 'go');
        spyOn(permissionViewController, "goToEditPermissionStates").and.callThrough();

        permissionViewController.goToEditPermissionStates();

        expect(permissionViewController.goToEditPermissionStates).toHaveBeenCalled();
        expect(mock.$state.go).toHaveBeenCalledWith(mock.StateConstants.ADMIN_PERMISSION_EDIT_STATES);
    });
});

