import "../../../../../../src/module";
import "../../../../../../src/home/module";
import "../../../../../../src/home/admin/module";
import "../../../../../../src/home/admin/permissionManagement/module";
import "../../../../../../src/home/admin/permissionManagement/_services/module";
import "../../../../../../src/home/admin/permissionManagement/_views/module";

describe('Admin PermissionManagement _Views PermissionCreate.Controller Tests', () => {
    var permissionCreateController;
    var mock;

    var permission = {
        "id": "57800a1e768bbb531eecd243",
        "name": "Manage User Profiles",
        "functionalArea": "Administration",
        "description": "Manage User Profiles"
    };

    var invalidPermission = {
        "id": "57800a1e768bbb531eecd243",
        "name": "Manage User Profiles",
        "description": "Manage User Profiles"
    };

    var myPermissionManagementService;

    beforeEach(() => {
        module('DmlesModule');
        module('Dmles.Home.Module');
        module('Dmles.AdminModule');
        module('Dmles.Admin.PermissionManagementModule');
        module('Dmles.Admin.PermissionManagement.Views.Module');

        inject(($rootScope, $controller, $q, $state, StateConstants, RoleService, PermissionManagementService) => {

            spyOn(PermissionManagementService, 'getPermission').and.callFake(() => {
                return permission;
            });
            myPermissionManagementService = PermissionManagementService;

            mock = {
                $scope: $rootScope.$new(),
                StateConstants: StateConstants,
                RoleService: RoleService,
                PermissionManagementService: myPermissionManagementService,
                deferred: $q.defer(),
                skip: $q.defer(),
                $state: $state
            };

            permissionCreateController = $controller('Dmles.Admin.PermissionManagement.Views.PermissionCreateController', mock);
        });
    });

    it('Has scope', () => {
        expect(mock.$scope).not.toEqual(undefined);
    });

    it('Has a permissionCreateController controller', () => {
        expect(permissionCreateController).toBeDefined();
    });

    it('Has a Role Service', () => {
        expect(permissionCreateController.RoleService).toBeDefined();
    });

    it('Has an PermissionManagement Service', () => {
        expect(permissionCreateController.PermissionManagementService).toBeDefined();
    });

    it('The permissionCreate controller onSubmit function works with valid permission', () => {
        spyOn(permissionCreateController, "onSubmit").and.callThrough();

        permissionCreateController.permission = permission;
        permissionCreateController.onSubmit();

        expect(permissionCreateController.onSubmit).toHaveBeenCalled();
    });
    
    it('The permissionCreate controller onSubmit function works with invalid permission', () => {
        spyOn(permissionCreateController, "onSubmit").and.callThrough();

        permissionCreateController.permission = invalidPermission;
        permissionCreateController.onSubmit();

        expect(permissionCreateController.onSubmit).toHaveBeenCalled();
    });

    it('The permissionCreate controller createPermission function works - resolve path', () => {
        spyOn(mock.$state, 'go');
        spyOn(permissionCreateController, "createPermission").and.callThrough();
        spyOn(permissionCreateController.RoleService, "createPermissionDetailed").and.callFake(() => {
            return $.Deferred().resolve(permission);
        });

        permissionCreateController.createPermission(permission);

        expect(permissionCreateController.createPermission).toHaveBeenCalled();
        expect(permissionCreateController.RoleService.createPermissionDetailed).toHaveBeenCalled();
        expect(mock.$state.go).toHaveBeenCalledWith(mock.StateConstants.ADMIN_PERMISSION_MNG);
    });

    it('The permissionCreate controller createPermission function works - reject path', () => {
        spyOn(mock.$state, 'go');
        spyOn(permissionCreateController, "createPermission").and.callThrough();
        spyOn(permissionCreateController.RoleService, "createPermissionDetailed").and.callFake(() => {
            return $.Deferred().reject();
        });

        permissionCreateController.createPermission(permission);

        expect(permissionCreateController.createPermission).toHaveBeenCalled();
        expect(permissionCreateController.RoleService.createPermissionDetailed).toHaveBeenCalled();
    });

    it('The permissionCreate controller goToPermissionManagement function works', () => {
        spyOn(mock.$state, 'go');
        spyOn(permissionCreateController, "goToPermissionManagement").and.callThrough();

        permissionCreateController.goToPermissionManagement();

        expect(permissionCreateController.goToPermissionManagement).toHaveBeenCalled();
        expect(mock.$state.go).toHaveBeenCalledWith(mock.StateConstants.ADMIN_PERMISSION_MNG);
    });
});

