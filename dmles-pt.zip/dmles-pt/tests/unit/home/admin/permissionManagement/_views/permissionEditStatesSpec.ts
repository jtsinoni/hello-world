import "../../../../../../src/module";
import "../../../../../../src/home/module";
import "../../../../../../src/home/admin/module";
import "../../../../../../src/home/admin/permissionManagement/module";
import "../../../../../../src/home/admin/permissionManagement/_services/module";
import "../../../../../../src/home/admin/permissionManagement/_views/module";

describe('Admin PermissionManagement _Views PermissionEditStates.Controller Tests', () => {
    var permissionEditStatesController;
    var mock;

    var permission = {
        "id": "57800a1e768bbb531eecd243",
        "name": "Manage User Profiles",
        "functionalArea": "Administration",
        "description": "Manage User Profiles"
    };
   
    var allStates = [{"id": "57718452d0142fa833276e3e", "name": "dmles"}, {
        "id": "57718452d0142fa833276e44",
        "name": "dmles.home"
    }, {"id": "57718452d0142fa833276e45", "name": "dmles.home.about"}, {
        "id": "57718452d0142fa833276e46",
        "name": "dmles.home.account"
    }, {"id": "57718452d0142fa833276e4a", "name": "dmles.home.admin"}, {
        "id": "57ade465a8ac2ac9a4fdc8d6",
        "name": "dmles.home.admin.permissionMng"
    }, {
        "id": "57ade4d4a8ac2ac9a4fdc8d7",
        "name": "dmles.home.admin.permissionMng.createPermission"
    }, {
        "id": "57ade509a8ac2ac9a4fdc8d8",
        "name": "dmles.home.admin.permissionMng.editElementsPermission"
    }, {
        "id": "57ade55ea8ac2ac9a4fdc8d9",
        "name": "dmles.home.admin.permissionMng.editStatesPermission"
    }, {
        "id": "57ade595a8ac2ac9a4fdc8da",
        "name": "dmles.home.admin.permissionMng.editGenInfoPermission"
    }, {
        "id": "57ade5cda8ac2ac9a4fdc8db",
        "name": "dmles.home.admin.permissionMng.editStatesPermission"
    }, {
        "id": "57ade603a8ac2ac9a4fdc8dc",
        "name": "dmles.home.admin.permissionMng.viewPermission"
    }, {"id": "57718452d0142fa833276e4b", "name": "dmles.home.admin.roleMng"}, {
        "id": "57718452d0142fa833276e4c",
        "name": "dmles.home.admin.roleMng.createRole"
    }, {
        "id": "57718452d0142fa833276e58",
        "name": "dmles.home.admin.roleMng.editGenInfoRole"
    }, {
        "id": "57718452d0142fa833276e59",
        "name": "dmles.home.admin.roleMng.editPermsRole"
    }, {
        "id": "57718452d0142fa833276e50",
        "name": "dmles.home.admin.roleMng.viewRole"
    }, {"id": "57718452d0142fa833276e4d", "name": "dmles.home.admin.userProfileMng"}, {
        "id": "57718452d0142fa833276e5a",
        "name": "dmles.home.admin.userProfileMng.editGenInfoUserProfile"
    }, {
        "id": "57718452d0142fa833276e5b",
        "name": "dmles.home.admin.userProfileMng.editPermsUserProfile"
    }, {
        "id": "57718452d0142fa833276e5c",
        "name": "dmles.home.admin.userProfileMng.editRolesUserProfile"
    }, {
        "id": "57718452d0142fa833276e4e",
        "name": "dmles.home.admin.userProfileMng.viewUserProfile"
    }, {"id": "57718452d0142fa833276e4f", "name": "dmles.home.catalog"}, {
        "id": "57718452d0142fa833276e51",
        "name": "dmles.home.catalog.favs"
    }, {"id": "57718452d0142fa833276e52", "name": "dmles.home.catalog.search"}, {
        "id": "57718452d0142fa833276e53",
        "name": "dmles.home.catalog.search.details"
    }, {"id": "57aa2af5a8ac2ac9a4fdc8ce", "name": "dmles.home.dashboard"}, {
        "id": "57718452d0142fa833276e48",
        "name": "dmles.home.help"
    }, {"id": "57718452d0142fa833276e62", "name": "dmles.home.jmar"}, {
        "id": "57718452d0142fa833276e49",
        "name": "dmles.home.myServices"
    }, {"id": "57718452d0142fa833276e54", "name": "dmles.home.record"}, {
        "id": "57718452d0142fa833276e55",
        "name": "dmles.home.record.details"
    }, {"id": "57718452d0142fa833276e56", "name": "dmles.home.record.docSearch"}, {
        "id": "57718452d0142fa833276e57",
        "name": "dmles.home.request"
    }, {"id": "57718452d0142fa833276e5e", "name": "dmles.home.request.myRequest"}, {
        "id": "57718452d0142fa833276e5f",
        "name": "dmles.home.request.myRequest.confirm"
    }, {"id": "57718452d0142fa833276e5d", "name": "dmles.home.request.myRequests"}, {
        "id": "57718452d0142fa833276e60",
        "name": "dmles.home.request.myRequests.new"
    }, {
        "id": "57718452d0142fa833276e61",
        "name": "dmles.home.request.myRequests.new.confirm"
    }, {
        "id": "57ab55632e9d66322fd89fbc",
        "name": "dmles.home.request.myRequests.new.details"
    }, {
        "id": "57bc4ae303e0fba04e9bba19",
        "name": "dmles.home.request.myRequests.view"
    }, {"id": "57718452d0142fa833276e47", "name": "dmles.home.userProfile"}, {
        "id": "57bc5bc803e0fba04e9bba1c",
        "name": "dmles.home.userProfile.editGenInfoUserProfile"
    }, {"id": "57718452d0142fa833276e40", "name": "dmles.login"}, {
        "id": "57718452d0142fa833276e41",
        "name": "dmles.login.form"
    }, {"id": "57718452d0142fa833276e42", "name": "dmles.login.register"}, {
        "id": "57718452d0142fa833276e43",
        "name": "dmles.login.register.confirmation"
    }, {"id": "57718452d0142fa833276e3f", "name": "dmles.security"}];

    var myPermissionManagementService;

    beforeEach(() => {
        module('DmlesModule');
        module('Dmles.Home.Module');
        module('Dmles.AdminModule');
        module('Dmles.Admin.PermissionManagementModule');
        module('Dmles.Admin.PermissionManagement.Views.Module');

        inject(($rootScope, $controller, PermissionManagementService) => {

            spyOn(PermissionManagementService, 'getPermission').and.callFake(() => {
                return permission;
            });
            spyOn(PermissionManagementService, 'getAllStates').and.callFake(() => {
                return allStates;
            });
            spyOn(PermissionManagementService, 'savePermissionStates').and.callFake(() => {
                return permission;
            });
            myPermissionManagementService = PermissionManagementService;

            mock = {
                $scope: $rootScope.$new(),
                PermissionManagementService: myPermissionManagementService
            };

            permissionEditStatesController = $controller('Dmles.Admin.PermissionManagement.Views.PermissionEditStatesController', mock);
        });
    });

    it('Has scope', () => {
        expect(mock.$scope).not.toEqual(undefined);
    });

    it('Has a permissionEditStatesController controller', () => {
        expect(permissionEditStatesController).toBeDefined();
    });

    it('Has an PermissionManagement Service', () => {
        expect(permissionEditStatesController.PermissionManagementService).toBeDefined();
    });

    it('The permissionEditStates controller onSubmit function works', () => {
        spyOn(permissionEditStatesController, "onSubmit").and.callThrough();

        permissionEditStatesController.onSubmit();

        expect(permissionEditStatesController.onSubmit).toHaveBeenCalled();
    });
});

