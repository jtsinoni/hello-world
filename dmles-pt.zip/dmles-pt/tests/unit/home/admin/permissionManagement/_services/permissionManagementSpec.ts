import "../../../../../../src/module";
import "../../../../../../src/home/module";
import "../../../../../../src/home/admin/module";
import "../../../../../../src/home/admin/permissionManagement/module";
import "../../../../../../src/home/admin/permissionManagement/_services/module";
import "../../../../../../src/home/admin/permissionManagement/_views/module";

describe('Admin PermissionManagement _Services PermissionManagement Service Tests', () => {

    var permission = {
        "id": "57800a1e768bbb531eecd243",
        "name": "Manage User Profiles",
        "functionalArea": "Administration",
        "description": "Manage User Profiles"
    };

    var allPermissionsDetailed = [{
        "id": "57728d844c08ed9af7596da7",
        "name": "All Permissions",
        "functionalArea": "Other",
        "description": "All Permissions",
        "endpoints": [],
        "states": [{
            "id": "57aa2af5a8ac2ac9a4fdc8ce",
            "name": "dmles.home.dashboard"
        }, {"id": "57718452d0142fa833276e3e", "name": "dmles"}, {
            "id": "57718452d0142fa833276e3f",
            "name": "dmles.security"
        }, {"id": "57718452d0142fa833276e40", "name": "dmles.login"}, {
            "id": "57718452d0142fa833276e41",
            "name": "dmles.login.form"
        }, {"id": "57718452d0142fa833276e42", "name": "dmles.login.register"}, {
            "id": "57718452d0142fa833276e43",
            "name": "dmles.login.register.confirmation"
        }, {"id": "57718452d0142fa833276e44", "name": "dmles.home"}, {
            "id": "57718452d0142fa833276e45",
            "name": "dmles.home.about"
        }, {"id": "57718452d0142fa833276e46", "name": "dmles.home.account"}, {
            "id": "57718452d0142fa833276e47",
            "name": "dmles.home.userProfile"
        }, {"id": "57718452d0142fa833276e48", "name": "dmles.home.help"}, {
            "id": "57718452d0142fa833276e49",
            "name": "dmles.home.myServices"
        }, {"id": "57718452d0142fa833276e4a", "name": "dmles.home.admin"}, {
            "id": "57718452d0142fa833276e4b",
            "name": "dmles.home.admin.roleMng"
        }, {
            "id": "57718452d0142fa833276e4c",
            "name": "dmles.home.admin.roleMng.createRole"
        }, {
            "id": "57718452d0142fa833276e4d",
            "name": "dmles.home.admin.userProfileMng"
        }, {
            "id": "57718452d0142fa833276e4e",
            "name": "dmles.home.admin.userProfileMng.viewUserProfile"
        }, {"id": "57718452d0142fa833276e4f", "name": "dmles.home.catalog"}, {
            "id": "57718452d0142fa833276e50",
            "name": "dmles.home.admin.roleMng.viewRole"
        }, {"id": "57718452d0142fa833276e51", "name": "dmles.home.catalog.favs"}, {
            "id": "57718452d0142fa833276e52",
            "name": "dmles.home.catalog.search"
        }, {
            "id": "57718452d0142fa833276e53",
            "name": "dmles.home.catalog.search.details"
        }, {"id": "57718452d0142fa833276e54", "name": "dmles.home.record"}, {
            "id": "57718452d0142fa833276e55",
            "name": "dmles.home.record.details"
        }, {"id": "57718452d0142fa833276e56", "name": "dmles.home.record.docSearch"}, {
            "id": "57718452d0142fa833276e57",
            "name": "dmles.home.request"
        }, {
            "id": "57718452d0142fa833276e58",
            "name": "dmles.home.admin.roleMng.editGenInfoRole"
        }, {
            "id": "57718452d0142fa833276e59",
            "name": "dmles.home.admin.roleMng.editPermsRole"
        }, {
            "id": "57718452d0142fa833276e5a",
            "name": "dmles.home.admin.userProfileMng.editGenInfoUserProfile"
        }, {
            "id": "57718452d0142fa833276e5b",
            "name": "dmles.home.admin.userProfileMng.editPermsUserProfile"
        }, {
            "id": "57718452d0142fa833276e5c",
            "name": "dmles.home.admin.userProfileMng.editRolesUserProfile"
        }, {
            "id": "57718452d0142fa833276e5d",
            "name": "dmles.home.request.myRequests"
        }, {
            "id": "57718452d0142fa833276e5e",
            "name": "dmles.home.request.myRequest"
        }, {
            "id": "57718452d0142fa833276e5f",
            "name": "dmles.home.request.myRequest.confirm"
        }, {
            "id": "57718452d0142fa833276e60",
            "name": "dmles.home.request.myRequests.new"
        }, {
            "id": "57718452d0142fa833276e61",
            "name": "dmles.home.request.myRequests.new.confirm"
        }, {"id": "57718452d0142fa833276e62", "name": "dmles.home.jmar"}, {
            "id": "57ab55632e9d66322fd89fbc",
            "name": "dmles.home.request.myRequests.new.details"
        }, {
            "id": "57ade465a8ac2ac9a4fdc8d6",
            "name": "dmles.home.admin.permissionMng"
        }, {
            "id": "57ade4d4a8ac2ac9a4fdc8d7",
            "name": "dmles.home.admin.permissionMng.createPermission"
        }, {
            "id": "57ade509a8ac2ac9a4fdc8d8",
            "name": "dmles.home.admin.permissionMng.editElementsPermission"
        }, {
            "id": "57ade55ea8ac2ac9a4fdc8d9",
            "name": "dmles.home.admin.permissionMng.editEndpointsPermission"
        }, {
            "id": "57ade595a8ac2ac9a4fdc8da",
            "name": "dmles.home.admin.permissionMng.editGenInfoPermission"
        }, {
            "id": "57ade5cda8ac2ac9a4fdc8db",
            "name": "dmles.home.admin.permissionMng.editStatesPermission"
        }, {
            "id": "57ade603a8ac2ac9a4fdc8dc",
            "name": "dmles.home.admin.permissionMng.viewPermission"
        }, {
            "id": "57bc4ae303e0fba04e9bba19",
            "name": "dmles.home.request.myRequests.view"
        }, {"id": "57bc5bc803e0fba04e9bba1c", "name": "dmles.home.userProfile.editGenInfoUserProfile"}],
        "elements": [{
            "id": "57718452d0142fa833276e63",
            "name": "user-profile-management"
        }, {"id": "57718452d0142fa833276e64", "name": "role-management"}, {
            "id": "57718452d0142fa833276e65",
            "name": "requests-service"
        }, {"id": "57718452d0142fa833276e66", "name": "equip-catalog"}, {
            "id": "57718452d0142fa833276e67",
            "name": "equip-request-create"
        }, {"id": "57718452d0142fa833276e68", "name": "equip-my-requests"}, {
            "id": "57718452d0142fa833276e69",
            "name": "equip-review"
        }, {"id": "57718452d0142fa833276e6a", "name": "equip-request-weighin"}, {
            "id": "57718452d0142fa833276e6b",
            "name": "equip-request-facilities"
        }, {"id": "57718452d0142fa833276e6c", "name": "equip-request-maintenance"}, {
            "id": "57718452d0142fa833276e6d",
            "name": "equip-request-technology"
        }, {"id": "57718452d0142fa833276e6e", "name": "equip-approve"}, {
            "id": "57718452d0142fa833276e6f",
            "name": "equip-update"
        }, {"id": "57718452d0142fa833276e70", "name": "equip-records"}, {
            "id": "57718452d0142fa833276e71",
            "name": "equip-records-search"
        }, {"id": "57718452d0142fa833276e72", "name": "jmar"}, {
            "id": "57718452d0142fa833276e73",
            "name": "all"
        }, {"id": "578011b0768bbb531eecd250", "name": "equip-request-safety"}, {
            "id": "57ade6d8a8ac2ac9a4fdc8de",
            "name": "permission-management"
        }]
    }, {"id": "57800a1e768bbb531eecd243", "name": "Manage User Profiles", "functionalArea": "Administration", "description": "Manage User Profiles", "endpoints": [], "states": [{ "id": "57aa2af5a8ac2ac9a4fdc8ce", "name": "dmles.home.dashboard" }, {"id": "57718452d0142fa833276e44", "name": "dmles.home"}, { "id": "57718452d0142fa833276e45", "name": "dmles.home.about" }, {"id": "57718452d0142fa833276e46", "name": "dmles.home.account"}, {
            "id": "57718452d0142fa833276e47",
            "name": "dmles.home.userProfile"
        }, {"id": "57718452d0142fa833276e48", "name": "dmles.home.help"}, {
            "id": "57718452d0142fa833276e49",
            "name": "dmles.home.myServices"
        }, {"id": "57718452d0142fa833276e4a", "name": "dmles.home.admin"}, {
            "id": "57718452d0142fa833276e4d",
            "name": "dmles.home.admin.userProfileMng"
        }, {
            "id": "57718452d0142fa833276e4e",
            "name": "dmles.home.admin.userProfileMng.viewUserProfile"
        }, {
            "id": "57718452d0142fa833276e5a",
            "name": "dmles.home.admin.userProfileMng.editGenInfoUserProfile"
        }, {
            "id": "57718452d0142fa833276e5b",
            "name": "dmles.home.admin.userProfileMng.editPermsUserProfile"
        }, {
            "id": "57718452d0142fa833276e5c",
            "name": "dmles.home.admin.userProfileMng.editRolesUserProfile"
        }, {"id": "57bc5bc803e0fba04e9bba1c", "name": "dmles.home.userProfile.editGenInfoUserProfile"}],         "elements": [{"id": "57718452d0142fa833276e63", "name": "user-profile-management"}] }, {
        "id": "57800c60768bbb531eecd245",
        "name": "Manage User Roles",
        "functionalArea": "Administration",
        "description": "Manage User Roles",
        "endpoints": [],
        "states": [{
            "id": "57aa2af5a8ac2ac9a4fdc8ce",
            "name": "dmles.home.dashboard"
        }, {"id": "57718452d0142fa833276e44", "name": "dmles.home"}, {
            "id": "57718452d0142fa833276e45",
            "name": "dmles.home.about"
        }, {"id": "57718452d0142fa833276e46", "name": "dmles.home.account"}, {
            "id": "57718452d0142fa833276e47",
            "name": "dmles.home.userProfile"
        }, {"id": "57718452d0142fa833276e48", "name": "dmles.home.help"}, {
            "id": "57718452d0142fa833276e49",
            "name": "dmles.home.myServices"
        }, {"id": "57718452d0142fa833276e4a", "name": "dmles.home.admin"}, {
            "id": "57718452d0142fa833276e4b",
            "name": "dmles.home.admin.roleMng"
        }, {
            "id": "57718452d0142fa833276e4c",
            "name": "dmles.home.admin.roleMng.createRole"
        }, {
            "id": "57718452d0142fa833276e50",
            "name": "dmles.home.admin.roleMng.viewRole"
        }, {
            "id": "57718452d0142fa833276e58",
            "name": "dmles.home.admin.roleMng.editGenInfoRole"
        }, {
            "id": "57718452d0142fa833276e59",
            "name": "dmles.home.admin.roleMng.editPermsRole"
        }, {"id": "57bc5bc803e0fba04e9bba1c", "name": "dmles.home.userProfile.editGenInfoUserProfile"}],
        "elements": [{"id": "57718452d0142fa833276e64", "name": "role-management"}]
    }, {
        "id": "57800e6f768bbb531eecd247",
        "name": "Submit Equipment Requests",
        "functionalArea": "Equipment_Request",
        "description": "Submit Equipment Requests",
        "endpoints": [],
        "states": [{
            "id": "57aa2af5a8ac2ac9a4fdc8ce",
            "name": "dmles.home.dashboard"
        }, {"id": "57718452d0142fa833276e44", "name": "dmles.home"}, {
            "id": "57718452d0142fa833276e45",
            "name": "dmles.home.about"
        }, {"id": "57718452d0142fa833276e46", "name": "dmles.home.account"}, {
            "id": "57718452d0142fa833276e47",
            "name": "dmles.home.userProfile"
        }, {"id": "57718452d0142fa833276e48", "name": "dmles.home.help"}, {
            "id": "57718452d0142fa833276e49",
            "name": "dmles.home.myServices"
        }, {"id": "57718452d0142fa833276e4f", "name": "dmles.home.catalog"}, {
            "id": "57718452d0142fa833276e51",
            "name": "dmles.home.catalog.favs"
        }, {"id": "57718452d0142fa833276e52", "name": "dmles.home.catalog.search"}, {
            "id": "57718452d0142fa833276e53",
            "name": "dmles.home.catalog.search.details"
        }, {"id": "57718452d0142fa833276e54", "name": "dmles.home.record"}, {
            "id": "57718452d0142fa833276e55",
            "name": "dmles.home.record.details"
        }, {"id": "57718452d0142fa833276e56", "name": "dmles.home.record.docSearch"}, {
            "id": "57718452d0142fa833276e57",
            "name": "dmles.home.request"
        }, {
            "id": "57718452d0142fa833276e5d",
            "name": "dmles.home.request.myRequests"
        }, {
            "id": "57718452d0142fa833276e5e",
            "name": "dmles.home.request.myRequest"
        }, {
            "id": "57718452d0142fa833276e5f",
            "name": "dmles.home.request.myRequest.confirm"
        }, {
            "id": "57718452d0142fa833276e60",
            "name": "dmles.home.request.myRequests.new"
        }, {
            "id": "57718452d0142fa833276e61",
            "name": "dmles.home.request.myRequests.new.confirm"
        }, {
            "id": "57ab55632e9d66322fd89fbc",
            "name": "dmles.home.request.myRequests.new.details"
        }, {
            "id": "57bc5bc803e0fba04e9bba1c",
            "name": "dmles.home.userProfile.editGenInfoUserProfile"
        }, {"id": "57bc4ae303e0fba04e9bba19", "name": "dmles.home.request.myRequests.view"}],
        "elements": [{"id": "57718452d0142fa833276e65", "name": "requests-service"}, {
            "id": "57718452d0142fa833276e66",
            "name": "equip-catalog"
        }, {"id": "57718452d0142fa833276e67", "name": "equip-request-create"}, {
            "id": "57718452d0142fa833276e68",
            "name": "equip-my-requests"
        }]
    }, {
        "id": "57801183768bbb531eecd24f",
        "name": "Manage Equipment Requests",
        "functionalArea": "Equipment_Request",
        "description": "Manage Equipment Requests",
        "endpoints": [],
        "states": [{
            "id": "57aa2af5a8ac2ac9a4fdc8ce",
            "name": "dmles.home.dashboard"
        }, {"id": "57718452d0142fa833276e44", "name": "dmles.home"}, {
            "id": "57718452d0142fa833276e45",
            "name": "dmles.home.about"
        }, {"id": "57718452d0142fa833276e46", "name": "dmles.home.account"}, {
            "id": "57718452d0142fa833276e47",
            "name": "dmles.home.userProfile"
        }, {"id": "57718452d0142fa833276e48", "name": "dmles.home.help"}, {
            "id": "57718452d0142fa833276e49",
            "name": "dmles.home.myServices"
        }, {"id": "57718452d0142fa833276e4f", "name": "dmles.home.catalog"}, {
            "id": "57718452d0142fa833276e51",
            "name": "dmles.home.catalog.favs"
        }, {"id": "57718452d0142fa833276e52", "name": "dmles.home.catalog.search"}, {
            "id": "57718452d0142fa833276e53",
            "name": "dmles.home.catalog.search.details"
        }, {"id": "57718452d0142fa833276e54", "name": "dmles.home.record"}, {
            "id": "57718452d0142fa833276e55",
            "name": "dmles.home.record.details"
        }, {"id": "57718452d0142fa833276e56", "name": "dmles.home.record.docSearch"}, {
            "id": "57718452d0142fa833276e57",
            "name": "dmles.home.request"
        }, {
            "id": "57718452d0142fa833276e5d",
            "name": "dmles.home.request.myRequests"
        }, {
            "id": "57718452d0142fa833276e5e",
            "name": "dmles.home.request.myRequest"
        }, {
            "id": "57718452d0142fa833276e5f",
            "name": "dmles.home.request.myRequest.confirm"
        }, {
            "id": "57718452d0142fa833276e60",
            "name": "dmles.home.request.myRequests.new"
        }, {
            "id": "57718452d0142fa833276e61",
            "name": "dmles.home.request.myRequests.new.confirm"
        }, {
            "id": "57ab55632e9d66322fd89fbc",
            "name": "dmles.home.request.myRequests.new.details"
        }, {
            "id": "57bc5bc803e0fba04e9bba1c",
            "name": "dmles.home.userProfile.editGenInfoUserProfile"
        }, {"id": "57bc4ae303e0fba04e9bba19", "name": "dmles.home.request.myRequests.view"}],
        "elements": [{"id": "57718452d0142fa833276e69", "name": "equip-review"}, {
            "id": "57718452d0142fa833276e6a",
            "name": "equip-request-weighin"
        }, {"id": "57718452d0142fa833276e6b", "name": "equip-request-facilities"}, {
            "id": "57718452d0142fa833276e6c",
            "name": "equip-request-maintenance"
        }, {"id": "57718452d0142fa833276e6d", "name": "equip-request-technology"}, {
            "id": "578011b0768bbb531eecd250",
            "name": "equip-request-safety"
        }, {"id": "57718452d0142fa833276e6e", "name": "equip-approve"}, {
            "id": "57718452d0142fa833276e6f",
            "name": "equip-update"
        }]
    }, {
        "id": "57801466768bbb531eecd251",
        "name": "Add Facility Weigh-Ins",
        "functionalArea": "Equipment_Request",
        "description": "Add Facility Weigh-Ins",
        "endpoints": [],
        "states": [{
            "id": "57aa2af5a8ac2ac9a4fdc8ce",
            "name": "dmles.home.dashboard"
        }, {"id": "57718452d0142fa833276e44", "name": "dmles.home"}, {
            "id": "57718452d0142fa833276e45",
            "name": "dmles.home.about"
        }, {"id": "57718452d0142fa833276e46", "name": "dmles.home.account"}, {
            "id": "57718452d0142fa833276e47",
            "name": "dmles.home.userProfile"
        }, {"id": "57718452d0142fa833276e48", "name": "dmles.home.help"}, {
            "id": "57718452d0142fa833276e49",
            "name": "dmles.home.myServices"
        }, {"id": "57718452d0142fa833276e4f", "name": "dmles.home.catalog"}, {
            "id": "57718452d0142fa833276e51",
            "name": "dmles.home.catalog.favs"
        }, {"id": "57718452d0142fa833276e52", "name": "dmles.home.catalog.search"}, {
            "id": "57718452d0142fa833276e53",
            "name": "dmles.home.catalog.search.details"
        }, {"id": "57718452d0142fa833276e54", "name": "dmles.home.record"}, {
            "id": "57718452d0142fa833276e55",
            "name": "dmles.home.record.details"
        }, {"id": "57718452d0142fa833276e56", "name": "dmles.home.record.docSearch"}, {
            "id": "57718452d0142fa833276e57",
            "name": "dmles.home.request"
        }, {
            "id": "57718452d0142fa833276e5d",
            "name": "dmles.home.request.myRequests"
        }, {
            "id": "57718452d0142fa833276e5e",
            "name": "dmles.home.request.myRequest"
        }, {
            "id": "57718452d0142fa833276e5f",
            "name": "dmles.home.request.myRequest.confirm"
        }, {
            "id": "57718452d0142fa833276e60",
            "name": "dmles.home.request.myRequests.new"
        }, {
            "id": "57718452d0142fa833276e61",
            "name": "dmles.home.request.myRequests.new.confirm"
        }, {
            "id": "57ab55632e9d66322fd89fbc",
            "name": "dmles.home.request.myRequests.new.details"
        }, {"id": "57bc5bc803e0fba04e9bba1c", "name": "dmles.home.userProfile.editGenInfoUserProfile"}],
        "elements": [{
            "id": "57718452d0142fa833276e6b",
            "name": "equip-request-facilities"
        }, {"id": "57718452d0142fa833276e6a", "name": "equip-request-weighin"}]
    }, {
        "id": "5780147e768bbb531eecd252",
        "name": "Add Maintenance Weigh-Ins",
        "functionalArea": "Equipment_Request",
        "description": "Add Maintenance Weigh-Ins",
        "endpoints": [],
        "states": [{
            "id": "57aa2af5a8ac2ac9a4fdc8ce",
            "name": "dmles.home.dashboard"
        }, {"id": "57718452d0142fa833276e44", "name": "dmles.home"}, {
            "id": "57718452d0142fa833276e45",
            "name": "dmles.home.about"
        }, {"id": "57718452d0142fa833276e46", "name": "dmles.home.account"}, {
            "id": "57718452d0142fa833276e47",
            "name": "dmles.home.userProfile"
        }, {"id": "57718452d0142fa833276e48", "name": "dmles.home.help"}, {
            "id": "57718452d0142fa833276e49",
            "name": "dmles.home.myServices"
        }, {"id": "57718452d0142fa833276e4f", "name": "dmles.home.catalog"}, {
            "id": "57718452d0142fa833276e51",
            "name": "dmles.home.catalog.favs"
        }, {"id": "57718452d0142fa833276e52", "name": "dmles.home.catalog.search"}, {
            "id": "57718452d0142fa833276e53",
            "name": "dmles.home.catalog.search.details"
        }, {"id": "57718452d0142fa833276e54", "name": "dmles.home.record"}, {
            "id": "57718452d0142fa833276e55",
            "name": "dmles.home.record.details"
        }, {"id": "57718452d0142fa833276e56", "name": "dmles.home.record.docSearch"}, {
            "id": "57718452d0142fa833276e57",
            "name": "dmles.home.request"
        }, {
            "id": "57718452d0142fa833276e5d",
            "name": "dmles.home.request.myRequests"
        }, {
            "id": "57718452d0142fa833276e5e",
            "name": "dmles.home.request.myRequest"
        }, {
            "id": "57718452d0142fa833276e5f",
            "name": "dmles.home.request.myRequest.confirm"
        }, {
            "id": "57718452d0142fa833276e60",
            "name": "dmles.home.request.myRequests.new"
        }, {
            "id": "57718452d0142fa833276e61",
            "name": "dmles.home.request.myRequests.new.confirm"
        }, {
            "id": "57ab55632e9d66322fd89fbc",
            "name": "dmles.home.request.myRequests.new.details"
        }, {"id": "57bc5bc803e0fba04e9bba1c", "name": "dmles.home.userProfile.editGenInfoUserProfile"}],
        "elements": [{
            "id": "57718452d0142fa833276e6c",
            "name": "equip-request-maintenance"
        }, {"id": "57718452d0142fa833276e6a", "name": "equip-request-weighin"}]
    }, {
        "id": "57801498768bbb531eecd253",
        "name": "Add Technology Weigh-Ins",
        "functionalArea": "Equipment_Request",
        "description": "Add Technology Weigh-Ins",
        "endpoints": [],
        "states": [{
            "id": "57aa2af5a8ac2ac9a4fdc8ce",
            "name": "dmles.home.dashboard"
        }, {"id": "57718452d0142fa833276e44", "name": "dmles.home"}, {
            "id": "57718452d0142fa833276e45",
            "name": "dmles.home.about"
        }, {"id": "57718452d0142fa833276e46", "name": "dmles.home.account"}, {
            "id": "57718452d0142fa833276e47",
            "name": "dmles.home.userProfile"
        }, {"id": "57718452d0142fa833276e48", "name": "dmles.home.help"}, {
            "id": "57718452d0142fa833276e49",
            "name": "dmles.home.myServices"
        }, {"id": "57718452d0142fa833276e4f", "name": "dmles.home.catalog"}, {
            "id": "57718452d0142fa833276e51",
            "name": "dmles.home.catalog.favs"
        }, {"id": "57718452d0142fa833276e52", "name": "dmles.home.catalog.search"}, {
            "id": "57718452d0142fa833276e53",
            "name": "dmles.home.catalog.search.details"
        }, {"id": "57718452d0142fa833276e54", "name": "dmles.home.record"}, {
            "id": "57718452d0142fa833276e55",
            "name": "dmles.home.record.details"
        }, {"id": "57718452d0142fa833276e56", "name": "dmles.home.record.docSearch"}, {
            "id": "57718452d0142fa833276e57",
            "name": "dmles.home.request"
        }, {
            "id": "57718452d0142fa833276e5d",
            "name": "dmles.home.request.myRequests"
        }, {
            "id": "57718452d0142fa833276e5e",
            "name": "dmles.home.request.myRequest"
        }, {
            "id": "57718452d0142fa833276e5f",
            "name": "dmles.home.request.myRequest.confirm"
        }, {
            "id": "57718452d0142fa833276e60",
            "name": "dmles.home.request.myRequests.new"
        }, {
            "id": "57718452d0142fa833276e61",
            "name": "dmles.home.request.myRequests.new.confirm"
        }, {
            "id": "57ab55632e9d66322fd89fbc",
            "name": "dmles.home.request.myRequests.new.details"
        }, {"id": "57bc5bc803e0fba04e9bba1c", "name": "dmles.home.userProfile.editGenInfoUserProfile"}],
        "elements": [{
            "id": "57718452d0142fa833276e6d",
            "name": "equip-request-technology"
        }, {"id": "57718452d0142fa833276e6a", "name": "equip-request-weighin"}]
    }, {
        "id": "578014b2768bbb531eecd254",
        "name": "Add Safety Weigh-Ins",
        "functionalArea": "Equipment_Request",
        "description": "Add Safety Weigh-Ins",
        "endpoints": [],
        "states": [{
            "id": "57aa2af5a8ac2ac9a4fdc8ce",
            "name": "dmles.home.dashboard"
        }, {"id": "57718452d0142fa833276e44", "name": "dmles.home"}, {
            "id": "57718452d0142fa833276e45",
            "name": "dmles.home.about"
        }, {"id": "57718452d0142fa833276e46", "name": "dmles.home.account"}, {
            "id": "57718452d0142fa833276e47",
            "name": "dmles.home.userProfile"
        }, {"id": "57718452d0142fa833276e48", "name": "dmles.home.help"}, {
            "id": "57718452d0142fa833276e49",
            "name": "dmles.home.myServices"
        }, {"id": "57718452d0142fa833276e4f", "name": "dmles.home.catalog"}, {
            "id": "57718452d0142fa833276e51",
            "name": "dmles.home.catalog.favs"
        }, {"id": "57718452d0142fa833276e52", "name": "dmles.home.catalog.search"}, {
            "id": "57718452d0142fa833276e53",
            "name": "dmles.home.catalog.search.details"
        }, {"id": "57718452d0142fa833276e54", "name": "dmles.home.record"}, {
            "id": "57718452d0142fa833276e55",
            "name": "dmles.home.record.details"
        }, {"id": "57718452d0142fa833276e56", "name": "dmles.home.record.docSearch"}, {
            "id": "57718452d0142fa833276e57",
            "name": "dmles.home.request"
        }, {
            "id": "57718452d0142fa833276e5d",
            "name": "dmles.home.request.myRequests"
        }, {
            "id": "57718452d0142fa833276e5e",
            "name": "dmles.home.request.myRequest"
        }, {
            "id": "57718452d0142fa833276e5f",
            "name": "dmles.home.request.myRequest.confirm"
        }, {
            "id": "57718452d0142fa833276e60",
            "name": "dmles.home.request.myRequests.new"
        }, {
            "id": "57718452d0142fa833276e61",
            "name": "dmles.home.request.myRequests.new.confirm"
        }, {
            "id": "57ab55632e9d66322fd89fbc",
            "name": "dmles.home.request.myRequests.new.details"
        }, {"id": "57bc5bc803e0fba04e9bba1c", "name": "dmles.home.userProfile.editGenInfoUserProfile"}],
        "elements": [{
            "id": "578011b0768bbb531eecd250",
            "name": "equip-request-safety"
        }, {"id": "57718452d0142fa833276e6a", "name": "equip-request-weighin"}]
    }, {
        "id": "5780174e768bbb531eecd255",
        "name": "View Equipment Requests",
        "functionalArea": "Equipment_Request",
        "description": "View Equipment Requests",
        "endpoints": [],
        "states": [{
            "id": "57aa2af5a8ac2ac9a4fdc8ce",
            "name": "dmles.home.dashboard"
        }, {"id": "57718452d0142fa833276e44", "name": "dmles.home"}, {
            "id": "57718452d0142fa833276e45",
            "name": "dmles.home.about"
        }, {"id": "57718452d0142fa833276e46", "name": "dmles.home.account"}, {
            "id": "57718452d0142fa833276e47",
            "name": "dmles.home.userProfile"
        }, {"id": "57718452d0142fa833276e48", "name": "dmles.home.help"}, {
            "id": "57718452d0142fa833276e49",
            "name": "dmles.home.myServices"
        }, {"id": "57718452d0142fa833276e4f", "name": "dmles.home.catalog"}, {
            "id": "57718452d0142fa833276e51",
            "name": "dmles.home.catalog.favs"
        }, {"id": "57718452d0142fa833276e52", "name": "dmles.home.catalog.search"}, {
            "id": "57718452d0142fa833276e53",
            "name": "dmles.home.catalog.search.details"
        }, {"id": "57718452d0142fa833276e54", "name": "dmles.home.record"}, {
            "id": "57718452d0142fa833276e55",
            "name": "dmles.home.record.details"
        }, {"id": "57718452d0142fa833276e56", "name": "dmles.home.record.docSearch"}, {
            "id": "57718452d0142fa833276e57",
            "name": "dmles.home.request"
        }, {
            "id": "57718452d0142fa833276e5d",
            "name": "dmles.home.request.myRequests"
        }, {
            "id": "57718452d0142fa833276e5e",
            "name": "dmles.home.request.myRequest"
        }, {
            "id": "57718452d0142fa833276e5f",
            "name": "dmles.home.request.myRequest.confirm"
        }, {
            "id": "57718452d0142fa833276e60",
            "name": "dmles.home.request.myRequests.new"
        }, {
            "id": "57718452d0142fa833276e61",
            "name": "dmles.home.request.myRequests.new.confirm"
        }, {
            "id": "57ab55632e9d66322fd89fbc",
            "name": "dmles.home.request.myRequests.new.details"
        }, {
            "id": "57bc5bc803e0fba04e9bba1c",
            "name": "dmles.home.userProfile.editGenInfoUserProfile"
        }, {"id": "57bc4ae303e0fba04e9bba19", "name": "dmles.home.request.myRequests.view"}],
        "elements": [{"id": "57718452d0142fa833276e68", "name": "equip-my-requests"}, {
            "id": "57718452d0142fa833276e69",
            "name": "equip-review"
        }, {"id": "57718452d0142fa833276e65", "name": "requests-service"}]
    }, {
        "id": "5780177a768bbb531eecd256",
        "name": "View Equipment Catalog",
        "functionalArea": "Equipment_Request",
        "description": "View Equipment Catalog",
        "endpoints": [],
        "states": [{
            "id": "57aa2af5a8ac2ac9a4fdc8ce",
            "name": "dmles.home.dashboard"
        }, {"id": "57718452d0142fa833276e44", "name": "dmles.home"}, {
            "id": "57718452d0142fa833276e45",
            "name": "dmles.home.about"
        }, {"id": "57718452d0142fa833276e46", "name": "dmles.home.account"}, {
            "id": "57718452d0142fa833276e47",
            "name": "dmles.home.userProfile"
        }, {"id": "57718452d0142fa833276e48", "name": "dmles.home.help"}, {
            "id": "57718452d0142fa833276e49",
            "name": "dmles.home.myServices"
        }, {"id": "57718452d0142fa833276e4f", "name": "dmles.home.catalog"}, {
            "id": "57718452d0142fa833276e51",
            "name": "dmles.home.catalog.favs"
        }, {"id": "57718452d0142fa833276e52", "name": "dmles.home.catalog.search"}, {
            "id": "57718452d0142fa833276e53",
            "name": "dmles.home.catalog.search.details"
        }, {"id": "57718452d0142fa833276e54", "name": "dmles.home.record"}, {
            "id": "57718452d0142fa833276e55",
            "name": "dmles.home.record.details"
        }, {"id": "57718452d0142fa833276e56", "name": "dmles.home.record.docSearch"}, {
            "id": "57718452d0142fa833276e57",
            "name": "dmles.home.request"
        }, {
            "id": "57718452d0142fa833276e5d",
            "name": "dmles.home.request.myRequests"
        }, {
            "id": "57718452d0142fa833276e5e",
            "name": "dmles.home.request.myRequest"
        }, {
            "id": "57718452d0142fa833276e5f",
            "name": "dmles.home.request.myRequest.confirm"
        }, {
            "id": "57718452d0142fa833276e60",
            "name": "dmles.home.request.myRequests.new"
        }, {
            "id": "57718452d0142fa833276e61",
            "name": "dmles.home.request.myRequests.new.confirm"
        }, {
            "id": "57ab55632e9d66322fd89fbc",
            "name": "dmles.home.request.myRequests.new.details"
        }, {"id": "57bc5bc803e0fba04e9bba1c", "name": "dmles.home.userProfile.editGenInfoUserProfile"}],
        "elements": [{"id": "57718452d0142fa833276e65", "name": "requests-service"}, {
            "id": "57718452d0142fa833276e66",
            "name": "equip-catalog"
        }]
    }, {
        "id": "578017d5768bbb531eecd257",
        "name": "Create Equipment Requests From Catalog",
        "functionalArea": "Equipment_Request",
        "description": "Create Equipment Requests From Catalog",
        "endpoints": [],
        "states": [{
            "id": "57aa2af5a8ac2ac9a4fdc8ce",
            "name": "dmles.home.dashboard"
        }, {"id": "57718452d0142fa833276e44", "name": "dmles.home"}, {
            "id": "57718452d0142fa833276e45",
            "name": "dmles.home.about"
        }, {"id": "57718452d0142fa833276e46", "name": "dmles.home.account"}, {
            "id": "57718452d0142fa833276e47",
            "name": "dmles.home.userProfile"
        }, {"id": "57718452d0142fa833276e48", "name": "dmles.home.help"}, {
            "id": "57718452d0142fa833276e49",
            "name": "dmles.home.myServices"
        }, {"id": "57718452d0142fa833276e4f", "name": "dmles.home.catalog"}, {
            "id": "57718452d0142fa833276e51",
            "name": "dmles.home.catalog.favs"
        }, {"id": "57718452d0142fa833276e52", "name": "dmles.home.catalog.search"}, {
            "id": "57718452d0142fa833276e53",
            "name": "dmles.home.catalog.search.details"
        }, {"id": "57718452d0142fa833276e54", "name": "dmles.home.record"}, {
            "id": "57718452d0142fa833276e55",
            "name": "dmles.home.record.details"
        }, {"id": "57718452d0142fa833276e56", "name": "dmles.home.record.docSearch"}, {
            "id": "57718452d0142fa833276e57",
            "name": "dmles.home.request"
        }, {
            "id": "57718452d0142fa833276e5d",
            "name": "dmles.home.request.myRequests"
        }, {
            "id": "57718452d0142fa833276e5e",
            "name": "dmles.home.request.myRequest"
        }, {
            "id": "57718452d0142fa833276e5f",
            "name": "dmles.home.request.myRequest.confirm"
        }, {
            "id": "57718452d0142fa833276e60",
            "name": "dmles.home.request.myRequests.new"
        }, {
            "id": "57718452d0142fa833276e61",
            "name": "dmles.home.request.myRequests.new.confirm"
        }, {
            "id": "57ab55632e9d66322fd89fbc",
            "name": "dmles.home.request.myRequests.new.details"
        }, {"id": "57bc5bc803e0fba04e9bba1c", "name": "dmles.home.userProfile.editGenInfoUserProfile"}],
        "elements": [{"id": "57718452d0142fa833276e67", "name": "equip-request-create"}]
    }, {
        "id": "5780183b768bbb531eecd258",
        "name": "View JMAR Search",
        "functionalArea": "Other",
        "description": "View JMAR Search",
        "endpoints": [],
        "states": [{
            "id": "57aa2af5a8ac2ac9a4fdc8ce",
            "name": "dmles.home.dashboard"
        }, {"id": "57718452d0142fa833276e44", "name": "dmles.home"}, {
            "id": "57718452d0142fa833276e45",
            "name": "dmles.home.about"
        }, {"id": "57718452d0142fa833276e46", "name": "dmles.home.account"}, {
            "id": "57718452d0142fa833276e47",
            "name": "dmles.home.userProfile"
        }, {"id": "57718452d0142fa833276e48", "name": "dmles.home.help"}, {
            "id": "57718452d0142fa833276e49",
            "name": "dmles.home.myServices"
        }, {"id": "57718452d0142fa833276e62", "name": "dmles.home.jmar"}, {
            "id": "57bc5bc803e0fba04e9bba1c",
            "name": "dmles.home.userProfile.editGenInfoUserProfile"
        }],
        "elements": [{"id": "57718452d0142fa833276e72", "name": "jmar"}]
    }, {
        "id": "57801870768bbb531eecd259",
        "name": "View Equipment Records",
        "functionalArea": "Equipment_Request",
        "description": "View Equipment Records",
        "endpoints": [],
        "states": [{
            "id": "57aa2af5a8ac2ac9a4fdc8ce",
            "name": "dmles.home.dashboard"
        }, {"id": "57718452d0142fa833276e44", "name": "dmles.home"}, {
            "id": "57718452d0142fa833276e45",
            "name": "dmles.home.about"
        }, {"id": "57718452d0142fa833276e46", "name": "dmles.home.account"}, {
            "id": "57718452d0142fa833276e47",
            "name": "dmles.home.userProfile"
        }, {"id": "57718452d0142fa833276e48", "name": "dmles.home.help"}, {
            "id": "57718452d0142fa833276e49",
            "name": "dmles.home.myServices"
        }, {"id": "57718452d0142fa833276e4f", "name": "dmles.home.catalog"}, {
            "id": "57718452d0142fa833276e51",
            "name": "dmles.home.catalog.favs"
        }, {"id": "57718452d0142fa833276e52", "name": "dmles.home.catalog.search"}, {
            "id": "57718452d0142fa833276e53",
            "name": "dmles.home.catalog.search.details"
        }, {"id": "57718452d0142fa833276e54", "name": "dmles.home.record"}, {
            "id": "57718452d0142fa833276e55",
            "name": "dmles.home.record.details"
        }, {"id": "57718452d0142fa833276e56", "name": "dmles.home.record.docSearch"}, {
            "id": "57718452d0142fa833276e57",
            "name": "dmles.home.request"
        }, {
            "id": "57718452d0142fa833276e5d",
            "name": "dmles.home.request.myRequests"
        }, {
            "id": "57718452d0142fa833276e5e",
            "name": "dmles.home.request.myRequest"
        }, {
            "id": "57718452d0142fa833276e5f",
            "name": "dmles.home.request.myRequest.confirm"
        }, {
            "id": "57718452d0142fa833276e60",
            "name": "dmles.home.request.myRequests.new"
        }, {
            "id": "57718452d0142fa833276e61",
            "name": "dmles.home.request.myRequests.new.confirm"
        }, {
            "id": "57ab55632e9d66322fd89fbc",
            "name": "dmles.home.request.myRequests.new.details"
        }, {"id": "57bc5bc803e0fba04e9bba1c", "name": "dmles.home.userProfile.editGenInfoUserProfile"}],
        "elements": [{"id": "57718452d0142fa833276e70", "name": "equip-records"}, {
            "id": "57718452d0142fa833276e71",
            "name": "equip-records-search"
        }]
    }, { "id": "57ade6a1a8ac2ac9a4fdc8dd","name": "Manage Permissions","functionalArea": "Administration", "description": "Manage Permissions","endpoints": [], "states": [{
            "id": "57aa2af5a8ac2ac9a4fdc8ce",
            "name": "dmles.home.dashboard"
        }, {"id": "57718452d0142fa833276e44", "name": "dmles.home"}, {
            "id": "57718452d0142fa833276e45",
            "name": "dmles.home.about"
        }, {"id": "57718452d0142fa833276e46", "name": "dmles.home.account"}, {
            "id": "57718452d0142fa833276e47",
            "name": "dmles.home.userProfile"
        }, {"id": "57718452d0142fa833276e48", "name": "dmles.home.help"}, {
            "id": "57718452d0142fa833276e49",
            "name": "dmles.home.myServices"
        }, {"id": "57718452d0142fa833276e4a", "name": "dmles.home.admin"}, { "id": "57ade465a8ac2ac9a4fdc8d6", "name": "dmles.home.admin.permissionMng" }, {
            "id": "57ade4d4a8ac2ac9a4fdc8d7",
            "name": "dmles.home.admin.permissionMng.createPermission"
        }, {
            "id": "57ade509a8ac2ac9a4fdc8d8",
            "name": "dmles.home.admin.permissionMng.editElementsPermission"
        }, {
            "id": "57ade55ea8ac2ac9a4fdc8d9",
            "name": "dmles.home.admin.permissionMng.editEndpointsPermission"
        }, {
            "id": "57ade595a8ac2ac9a4fdc8da",
            "name": "dmles.home.admin.permissionMng.editGenInfoPermission"
        }, {
            "id": "57ade5cda8ac2ac9a4fdc8db",
            "name": "dmles.home.admin.permissionMng.editStatesPermission"
        }, {
            "id": "57ade603a8ac2ac9a4fdc8dc",
            "name": "dmles.home.admin.permissionMng.viewPermission"
        }, {"id": "57bc5bc803e0fba04e9bba1c", "name": "dmles.home.userProfile.editGenInfoUserProfile"}], "elements": [{"id": "57ade6d8a8ac2ac9a4fdc8de", "name": "permission-management"}] }, {
        "id": "57b21beeb6c6ace31a223cbe",
        "name": "View Equipment Records2asdf",
        "functionalArea": "ABC",
        "description": "View Equipment Recordsasdf",
        "endpoints": [],
        "states": [{
            "id": "57aa2af5a8ac2ac9a4fdc8ce",
            "name": "dmles.home.dashboard"
        }, {"id": "57718452d0142fa833276e45", "name": "dmles.home.about"}],
        "elements": [{"id": "57718452d0142fa833276e70", "name": "equip-records"}, {
            "id": "57718452d0142fa833276e71",
            "name": "equip-records-search"
        }]
    }];
    
    var allElements = [{"id": "57718452d0142fa833276e73", "name": "all"}, {
        "id": "57718452d0142fa833276e6e",
        "name": "equip-approve"
    }, {"id": "57718452d0142fa833276e66", "name": "equip-catalog"}, {
        "id": "57718452d0142fa833276e68",
        "name": "equip-my-requests"
    }, {"id": "57718452d0142fa833276e70", "name": "equip-records"}, {
        "id": "57718452d0142fa833276e71",
        "name": "equip-records-search"
    }, {"id": "57718452d0142fa833276e67", "name": "equip-request-create"}, {
        "id": "57718452d0142fa833276e6b",
        "name": "equip-request-facilities"
    }, {"id": "57718452d0142fa833276e6c", "name": "equip-request-maintenance"}, {
        "id": "578011b0768bbb531eecd250",
        "name": "equip-request-safety"
    }, {"id": "57718452d0142fa833276e6d", "name": "equip-request-technology"}, {
        "id": "57718452d0142fa833276e6a",
        "name": "equip-request-weighin"
    }, {"id": "57718452d0142fa833276e69", "name": "equip-review"}, {
        "id": "57718452d0142fa833276e6f",
        "name": "equip-update"
    }, {"id": "57718452d0142fa833276e72", "name": "jmar"}, {
        "id": "57ade6d8a8ac2ac9a4fdc8de",
        "name": "permission-management"
    }, {"id": "57718452d0142fa833276e65", "name": "requests-service"}, {
        "id": "57718452d0142fa833276e64",
        "name": "role-management"
    }, {"id": "57718452d0142fa833276e63", "name": "user-profile-management"}];

    var elementOpts = [{"id":"57718452d0142fa833276e73","name":"all","selected":false},{"id":"57718452d0142fa833276e6e","name":"equip-approve","selected":false},{"id":"57718452d0142fa833276e66","name":"equip-catalog","selected":false},{"id":"57718452d0142fa833276e68","name":"equip-my-requests","selected":false},{"id":"57718452d0142fa833276e70","name":"equip-records","selected":false},{"id":"57718452d0142fa833276e71","name":"equip-records-search","selected":false},{"id":"57718452d0142fa833276e67","name":"equip-request-create","selected":false},{"id":"57718452d0142fa833276e6b","name":"equip-request-facilities","selected":false},{"id":"57718452d0142fa833276e6c","name":"equip-request-maintenance","selected":false},{"id":"578011b0768bbb531eecd250","name":"equip-request-safety","selected":false},{"id":"57718452d0142fa833276e6d","name":"equip-request-technology","selected":true},{"id":"57718452d0142fa833276e6a","name":"equip-request-weighin","selected":true},{"id":"57718452d0142fa833276e69","name":"equip-review","selected":false},{"id":"57718452d0142fa833276e6f","name":"equip-update","selected":false},{"id":"57718452d0142fa833276e72","name":"jmar","selected":false},{"id":"57ade6d8a8ac2ac9a4fdc8de","name":"permission-management","selected":false},{"id":"57718452d0142fa833276e65","name":"requests-service","selected":false},{"id":"57718452d0142fa833276e64","name":"role-management","selected":false},{"id":"57718452d0142fa833276e63","name":"user-profile-management","selected":false}];

    var allStates = [{"id": "57718452d0142fa833276e3e", "name": "dmles"}, {
        "id": "57718452d0142fa833276e44",
        "name": "dmles.home"
    }, {"id": "57718452d0142fa833276e45", "name": "dmles.home.about"}, {
        "id": "57718452d0142fa833276e46",
        "name": "dmles.home.account"
    }, {"id": "57718452d0142fa833276e4a", "name": "dmles.home.admin"}, {
        "id": "57ade465a8ac2ac9a4fdc8d6",
        "name": "dmles.home.admin.permissionMng"
    }, {
        "id": "57ade4d4a8ac2ac9a4fdc8d7",
        "name": "dmles.home.admin.permissionMng.createPermission"
    }, {
        "id": "57ade509a8ac2ac9a4fdc8d8",
        "name": "dmles.home.admin.permissionMng.editElementsPermission"
    }, {
        "id": "57ade55ea8ac2ac9a4fdc8d9",
        "name": "dmles.home.admin.permissionMng.editStatesPermission"
    }, {
        "id": "57ade595a8ac2ac9a4fdc8da",
        "name": "dmles.home.admin.permissionMng.editGenInfoPermission"
    }, {
        "id": "57ade5cda8ac2ac9a4fdc8db",
        "name": "dmles.home.admin.permissionMng.editStatesPermission"
    }, {
        "id": "57ade603a8ac2ac9a4fdc8dc",
        "name": "dmles.home.admin.permissionMng.viewPermission"
    }, {"id": "57718452d0142fa833276e4b", "name": "dmles.home.admin.roleMng"}, {
        "id": "57718452d0142fa833276e4c",
        "name": "dmles.home.admin.roleMng.createRole"
    }, {
        "id": "57718452d0142fa833276e58",
        "name": "dmles.home.admin.roleMng.editGenInfoRole"
    }, {
        "id": "57718452d0142fa833276e59",
        "name": "dmles.home.admin.roleMng.editPermsRole"
    }, {
        "id": "57718452d0142fa833276e50",
        "name": "dmles.home.admin.roleMng.viewRole"
    }, {"id": "57718452d0142fa833276e4d", "name": "dmles.home.admin.userProfileMng"}, {
        "id": "57718452d0142fa833276e5a",
        "name": "dmles.home.admin.userProfileMng.editGenInfoUserProfile"
    }, {
        "id": "57718452d0142fa833276e5b",
        "name": "dmles.home.admin.userProfileMng.editPermsUserProfile"
    }, {
        "id": "57718452d0142fa833276e5c",
        "name": "dmles.home.admin.userProfileMng.editRolesUserProfile"
    }, {
        "id": "57718452d0142fa833276e4e",
        "name": "dmles.home.admin.userProfileMng.viewUserProfile"
    }, {"id": "57718452d0142fa833276e4f", "name": "dmles.home.catalog"}, {
        "id": "57718452d0142fa833276e51",
        "name": "dmles.home.catalog.favs"
    }, {"id": "57718452d0142fa833276e52", "name": "dmles.home.catalog.search"}, {
        "id": "57718452d0142fa833276e53",
        "name": "dmles.home.catalog.search.details"
    }, {"id": "57aa2af5a8ac2ac9a4fdc8ce", "name": "dmles.home.dashboard"}, {
        "id": "57718452d0142fa833276e48",
        "name": "dmles.home.help"
    }, {"id": "57718452d0142fa833276e62", "name": "dmles.home.jmar"}, {
        "id": "57718452d0142fa833276e49",
        "name": "dmles.home.myServices"
    }, {"id": "57718452d0142fa833276e54", "name": "dmles.home.record"}, {
        "id": "57718452d0142fa833276e55",
        "name": "dmles.home.record.details"
    }, {"id": "57718452d0142fa833276e56", "name": "dmles.home.record.docSearch"}, {
        "id": "57718452d0142fa833276e57",
        "name": "dmles.home.request"
    }, {"id": "57718452d0142fa833276e5e", "name": "dmles.home.request.myRequest"}, {
        "id": "57718452d0142fa833276e5f",
        "name": "dmles.home.request.myRequest.confirm"
    }, {"id": "57718452d0142fa833276e5d", "name": "dmles.home.request.myRequests"}, {
        "id": "57718452d0142fa833276e60",
        "name": "dmles.home.request.myRequests.new"
    }, {
        "id": "57718452d0142fa833276e61",
        "name": "dmles.home.request.myRequests.new.confirm"
    }, {
        "id": "57ab55632e9d66322fd89fbc",
        "name": "dmles.home.request.myRequests.new.details"
    }, {
        "id": "57bc4ae303e0fba04e9bba19",
        "name": "dmles.home.request.myRequests.view"
    }, {"id": "57718452d0142fa833276e47", "name": "dmles.home.userProfile"}, {
        "id": "57bc5bc803e0fba04e9bba1c",
        "name": "dmles.home.userProfile.editGenInfoUserProfile"
    }, {"id": "57718452d0142fa833276e40", "name": "dmles.login"}, {
        "id": "57718452d0142fa833276e41",
        "name": "dmles.login.form"
    }, {"id": "57718452d0142fa833276e42", "name": "dmles.login.register"}, {
        "id": "57718452d0142fa833276e43",
        "name": "dmles.login.register.confirmation"
    }, {"id": "57718452d0142fa833276e3f", "name": "dmles.security"}];

    var stateOptsNoRemainder = [{"id":"57718452d0142fa833276e3e","name":"dmles","selected":false},{"id":"57718452d0142fa833276e44","name":"dmles.home","selected":true},{"id":"57718452d0142fa833276e45","name":"dmles.home.about","selected":true},{"id":"57718452d0142fa833276e46","name":"dmles.home.account","selected":true},{"id":"57718452d0142fa833276e4a","name":"dmles.home.admin","selected":false},{"id":"57ade465a8ac2ac9a4fdc8d6","name":"dmles.home.admin.permissionMng","selected":false},{"id":"57ade4d4a8ac2ac9a4fdc8d7","name":"dmles.home.admin.permissionMng.createPermission","selected":false},{"id":"57ade509a8ac2ac9a4fdc8d8","name":"dmles.home.admin.permissionMng.editElementsPermission","selected":false},{"id":"57ade55ea8ac2ac9a4fdc8d9","name":"dmles.home.admin.permissionMng.editEndpointsPermission","selected":false},{"id":"57ade595a8ac2ac9a4fdc8da","name":"dmles.home.admin.permissionMng.editGenInfoPermission","selected":false},{"id":"57ade5cda8ac2ac9a4fdc8db","name":"dmles.home.admin.permissionMng.editStatesPermission","selected":false},{"id":"57ade603a8ac2ac9a4fdc8dc","name":"dmles.home.admin.permissionMng.viewPermission","selected":false},{"id":"57718452d0142fa833276e4b","name":"dmles.home.admin.roleMng","selected":false},{"id":"57718452d0142fa833276e4c","name":"dmles.home.admin.roleMng.createRole","selected":false},{"id":"57718452d0142fa833276e58","name":"dmles.home.admin.roleMng.editGenInfoRole","selected":false},{"id":"57718452d0142fa833276e59","name":"dmles.home.admin.roleMng.editPermsRole","selected":false},{"id":"57718452d0142fa833276e50","name":"dmles.home.admin.roleMng.viewRole","selected":false},{"id":"57718452d0142fa833276e4d","name":"dmles.home.admin.userProfileMng","selected":false},{"id":"57718452d0142fa833276e5a","name":"dmles.home.admin.userProfileMng.editGenInfoUserProfile","selected":false},{"id":"57718452d0142fa833276e5b","name":"dmles.home.admin.userProfileMng.editPermsUserProfile","selected":false},{"id":"57718452d0142fa833276e5c","name":"dmles.home.admin.userProfileMng.editRolesUserProfile","selected":false},{"id":"57718452d0142fa833276e4e","name":"dmles.home.admin.userProfileMng.viewUserProfile","selected":false},{"id":"57718452d0142fa833276e4f","name":"dmles.home.catalog","selected":true},{"id":"57718452d0142fa833276e51","name":"dmles.home.catalog.favs","selected":true},{"id":"57718452d0142fa833276e52","name":"dmles.home.catalog.search","selected":true},{"id":"57718452d0142fa833276e53","name":"dmles.home.catalog.search.details","selected":true},{"id":"57aa2af5a8ac2ac9a4fdc8ce","name":"dmles.home.dashboard","selected":true},{"id":"57718452d0142fa833276e48","name":"dmles.home.help","selected":true},{"id":"57718452d0142fa833276e62","name":"dmles.home.jmar","selected":false},{"id":"57718452d0142fa833276e49","name":"dmles.home.myServices","selected":true},{"id":"57718452d0142fa833276e54","name":"dmles.home.record","selected":true},{"id":"57718452d0142fa833276e55","name":"dmles.home.record.details","selected":true},{"id":"57718452d0142fa833276e56","name":"dmles.home.record.docSearch","selected":true},{"id":"57718452d0142fa833276e57","name":"dmles.home.request","selected":true},{"id":"57718452d0142fa833276e5e","name":"dmles.home.request.myRequest","selected":true},{"id":"57718452d0142fa833276e5f","name":"dmles.home.request.myRequest.confirm","selected":true},{"id":"57718452d0142fa833276e5d","name":"dmles.home.request.myRequests","selected":true},{"id":"57718452d0142fa833276e60","name":"dmles.home.request.myRequests.new","selected":true},{"id":"57718452d0142fa833276e61","name":"dmles.home.request.myRequests.new.confirm","selected":true},{"id":"57ab55632e9d66322fd89fbc","name":"dmles.home.request.myRequests.new.details","selected":true},{"id":"57bc4ae303e0fba04e9bba19","name":"dmles.home.request.myRequests.view","selected":true},{"id":"57718452d0142fa833276e47","name":"dmles.home.userProfile","selected":true},{"id":"57bc5bc803e0fba04e9bba1c","name":"dmles.home.userProfile.editGenInfoUserProfile","selected":true},{"id":"57718452d0142fa833276e40","name":"dmles.login","selected":false},{"id":"57718452d0142fa833276e41","name":"dmles.login.form","selected":false},{"id":"57718452d0142fa833276e42","name":"dmles.login.register","selected":false},{"id":"57718452d0142fa833276e43","name":"dmles.login.register.confirmation","selected":false},{"id":"57718452d0142fa833276e3f","name":"dmles.security","selected":false}];

    var stateOptsWithRemainder = [{"id":"57718452d0142fa833276e3e","name":"dmles","selected":false},{"id":"57718452d0142fa833276e45","name":"dmles.home.about","selected":true},{"id":"57718452d0142fa833276e46","name":"dmles.home.account","selected":true},{"id":"57718452d0142fa833276e4a","name":"dmles.home.admin","selected":false},{"id":"57ade465a8ac2ac9a4fdc8d6","name":"dmles.home.admin.permissionMng","selected":false},{"id":"57ade4d4a8ac2ac9a4fdc8d7","name":"dmles.home.admin.permissionMng.createPermission","selected":false},{"id":"57ade509a8ac2ac9a4fdc8d8","name":"dmles.home.admin.permissionMng.editElementsPermission","selected":false},{"id":"57ade55ea8ac2ac9a4fdc8d9","name":"dmles.home.admin.permissionMng.editEndpointsPermission","selected":false},{"id":"57ade595a8ac2ac9a4fdc8da","name":"dmles.home.admin.permissionMng.editGenInfoPermission","selected":false},{"id":"57ade5cda8ac2ac9a4fdc8db","name":"dmles.home.admin.permissionMng.editStatesPermission","selected":false},{"id":"57ade603a8ac2ac9a4fdc8dc","name":"dmles.home.admin.permissionMng.viewPermission","selected":false},{"id":"57718452d0142fa833276e4b","name":"dmles.home.admin.roleMng","selected":false},{"id":"57718452d0142fa833276e4c","name":"dmles.home.admin.roleMng.createRole","selected":false},{"id":"57718452d0142fa833276e58","name":"dmles.home.admin.roleMng.editGenInfoRole","selected":false},{"id":"57718452d0142fa833276e59","name":"dmles.home.admin.roleMng.editPermsRole","selected":false},{"id":"57718452d0142fa833276e50","name":"dmles.home.admin.roleMng.viewRole","selected":false},{"id":"57718452d0142fa833276e4d","name":"dmles.home.admin.userProfileMng","selected":false},{"id":"57718452d0142fa833276e5a","name":"dmles.home.admin.userProfileMng.editGenInfoUserProfile","selected":false},{"id":"57718452d0142fa833276e5b","name":"dmles.home.admin.userProfileMng.editPermsUserProfile","selected":false},{"id":"57718452d0142fa833276e5c","name":"dmles.home.admin.userProfileMng.editRolesUserProfile","selected":false},{"id":"57718452d0142fa833276e4e","name":"dmles.home.admin.userProfileMng.viewUserProfile","selected":false},{"id":"57718452d0142fa833276e4f","name":"dmles.home.catalog","selected":true},{"id":"57718452d0142fa833276e51","name":"dmles.home.catalog.favs","selected":true},{"id":"57718452d0142fa833276e52","name":"dmles.home.catalog.search","selected":true},{"id":"57718452d0142fa833276e53","name":"dmles.home.catalog.search.details","selected":true},{"id":"57aa2af5a8ac2ac9a4fdc8ce","name":"dmles.home.dashboard","selected":true},{"id":"57718452d0142fa833276e48","name":"dmles.home.help","selected":true},{"id":"57718452d0142fa833276e62","name":"dmles.home.jmar","selected":false},{"id":"57718452d0142fa833276e49","name":"dmles.home.myServices","selected":true},{"id":"57718452d0142fa833276e54","name":"dmles.home.record","selected":true},{"id":"57718452d0142fa833276e55","name":"dmles.home.record.details","selected":true},{"id":"57718452d0142fa833276e56","name":"dmles.home.record.docSearch","selected":true},{"id":"57718452d0142fa833276e57","name":"dmles.home.request","selected":true},{"id":"57718452d0142fa833276e5e","name":"dmles.home.request.myRequest","selected":true},{"id":"57718452d0142fa833276e5f","name":"dmles.home.request.myRequest.confirm","selected":true},{"id":"57718452d0142fa833276e5d","name":"dmles.home.request.myRequests","selected":true},{"id":"57718452d0142fa833276e60","name":"dmles.home.request.myRequests.new","selected":true},{"id":"57718452d0142fa833276e61","name":"dmles.home.request.myRequests.new.confirm","selected":true},{"id":"57ab55632e9d66322fd89fbc","name":"dmles.home.request.myRequests.new.details","selected":true},{"id":"57bc4ae303e0fba04e9bba19","name":"dmles.home.request.myRequests.view","selected":true},{"id":"57718452d0142fa833276e47","name":"dmles.home.userProfile","selected":true},{"id":"57bc5bc803e0fba04e9bba1c","name":"dmles.home.userProfile.editGenInfoUserProfile","selected":true},{"id":"57718452d0142fa833276e40","name":"dmles.login","selected":false},{"id":"57718452d0142fa833276e41","name":"dmles.login.form","selected":false},{"id":"57718452d0142fa833276e42","name":"dmles.login.register","selected":false},{"id":"57718452d0142fa833276e43","name":"dmles.login.register.confirmation","selected":false},{"id":"57718452d0142fa833276e3f","name":"dmles.security","selected":false}];

    var allEndpoints = [{"id":"57d95aa4370893022d22a987","url":"nowBusinessMethod"},{"id":"57d95aa8370893022d22a988","url":"nowBusinessMethod"},{"id":"57d95aa8370893022d22a989","url":"nowBusinessMethod"},{"id":"57d95aa8370893022d22a98a","url":"nowBusinessMethod","selected":false},{"id":"57d95aa8370893022d22a98b","url":"nowBusinessMethod","selected":false},{"id":"57d95aa8370893022d22a98c","url":"nowBusinessMethod","selected":false},{"id":"57d95aa8370893022d22a98d","url":"nowBusinessMethod","selected":false},{"id":"57d95aa8370893022d22a98e","url":"nowBusinessMethod","selected":false},{"id":"57d95aa8370893022d22a98f","url":"nowBusinessMethod","selected":false},{"id":"57d95aa8370893022d22a990","url":"nowBusinessMethod","selected":false},{"id":"57d95aa8370893022d22a991","url":"nowBusinessMethod","selected":false},{"id":"57d95aa8370893022d22a992","url":"nowBusinessMethod","selected":false},{"id":"57d95aa8370893022d22a993","url":"nowBusinessMethod","selected":false},{"id":"57d95aa8370893022d22a994","url":"nowBusinessMethod","selected":false},{"id":"57d95aa8370893022d22a995","url":"nowBusinessMethod","selected":false},{"id":"57d95aa8370893022d22a996","url":"nowBusinessMethod","selected":false},{"id":"57d95aa8370893022d22a997","url":"nowBusinessMethod","selected":false},{"id":"57d95aa8370893022d22a998","url":"nowBusinessMethod","selected":false},{"id":"57d95aa9370893022d22a999","url":"nowBusinessMethod","selected":false},{"id":"57d95aa9370893022d22a99a","url":"nowBusinessMethod","selected":false},{"id":"57d95aa9370893022d22a99b","url":"nowBusinessMethod","selected":false},{"id":"57d95aa9370893022d22a99c","url":"nowBusinessMethod","selected":false},{"id":"57d95aa9370893022d22a99d","url":"nowBusinessMethod","selected":false},{"id":"57d95aa9370893022d22a99e","url":"nowBusinessMethod","selected":false},{"id":"57d95aa9370893022d22a99f","url":"nowBusinessMethod","selected":false},{"id":"57d95aa9370893022d22a9a0","url":"nowBusinessMethod","selected":false},{"id":"57d95aa9370893022d22a9a1","url":"nowBusinessMethod","selected":false},{"id":"57d95aa9370893022d22a9a2","url":"nowBusinessMethod","selected":false},{"id":"57d95aa9370893022d22a9a3","url":"nowBusinessMethod","selected":false},{"id":"57d95aa9370893022d22a9a4","url":"nowBusinessMethod","selected":false},{"id":"57d95aa9370893022d22a9a5","url":"nowBusinessMethod","selected":false},{"id":"57d95aa9370893022d22a9a6","url":"nowBusinessMethod","selected":false},{"id":"57d95aa9370893022d22a9a7","url":"nowBusinessMethod","selected":false},{"id":"57d95aaa370893022d22a9a8","url":"nowBusinessMethod","selected":false},{"id":"57d95aaa370893022d22a9a9","url":"nowBusinessMethod","selected":false},{"id":"57d95aaa370893022d22a9aa","url":"nowBusinessMethod","selected":false},{"id":"57d95aaa370893022d22a9ab","url":"nowBusinessMethod","selected":false},{"id":"57d95aaa370893022d22a9ac","url":"nowBusinessMethod","selected":false}];;

    var endpointOpts =  [{"id":"57d95aa4370893022d22a987","url":"nowBusinessMethod","selected":false},{"id":"57d95aa8370893022d22a988","url":"nowBusinessMethod","selected":true},{"id":"57d95aa8370893022d22a989","url":"nowBusinessMethod","selected":false},{"id":"57d95aa8370893022d22a98a","url":"nowBusinessMethod","selected":false},{"id":"57d95aa8370893022d22a98b","url":"nowBusinessMethod","selected":false},{"id":"57d95aa8370893022d22a98c","url":"nowBusinessMethod","selected":false},{"id":"57d95aa8370893022d22a98d","url":"nowBusinessMethod","selected":false},{"id":"57d95aa8370893022d22a98e","url":"nowBusinessMethod","selected":false},{"id":"57d95aa8370893022d22a98f","url":"nowBusinessMethod","selected":false},{"id":"57d95aa8370893022d22a990","url":"nowBusinessMethod","selected":false},{"id":"57d95aa8370893022d22a991","url":"nowBusinessMethod","selected":false},{"id":"57d95aa8370893022d22a992","url":"nowBusinessMethod","selected":false},{"id":"57d95aa8370893022d22a993","url":"nowBusinessMethod","selected":false},{"id":"57d95aa8370893022d22a994","url":"nowBusinessMethod","selected":false},{"id":"57d95aa8370893022d22a995","url":"nowBusinessMethod","selected":false},{"id":"57d95aa8370893022d22a996","url":"nowBusinessMethod","selected":false},{"id":"57d95aa8370893022d22a997","url":"nowBusinessMethod","selected":false},{"id":"57d95aa8370893022d22a998","url":"nowBusinessMethod","selected":false},{"id":"57d95aa9370893022d22a999","url":"nowBusinessMethod","selected":false},{"id":"57d95aa9370893022d22a99a","url":"nowBusinessMethod","selected":false},{"id":"57d95aa9370893022d22a99b","url":"nowBusinessMethod","selected":false},{"id":"57d95aa9370893022d22a99c","url":"nowBusinessMethod","selected":false},{"id":"57d95aa9370893022d22a99d","url":"nowBusinessMethod","selected":false},{"id":"57d95aa9370893022d22a99e","url":"nowBusinessMethod","selected":false},{"id":"57d95aa9370893022d22a99f","url":"nowBusinessMethod","selected":false},{"id":"57d95aa9370893022d22a9a0","url":"nowBusinessMethod","selected":false},{"id":"57d95aa9370893022d22a9a1","url":"nowBusinessMethod","selected":false},{"id":"57d95aa9370893022d22a9a2","url":"nowBusinessMethod","selected":false},{"id":"57d95aa9370893022d22a9a3","url":"nowBusinessMethod","selected":false},{"id":"57d95aa9370893022d22a9a4","url":"nowBusinessMethod","selected":false},{"id":"57d95aa9370893022d22a9a5","url":"nowBusinessMethod","selected":false},{"id":"57d95aa9370893022d22a9a6","url":"nowBusinessMethod","selected":false},{"id":"57d95aa9370893022d22a9a7","url":"nowBusinessMethod","selected":false},{"id":"57d95aaa370893022d22a9a8","url":"nowBusinessMethod","selected":false},{"id":"57d95aaa370893022d22a9a9","url":"nowBusinessMethod","selected":false},{"id":"57d95aaa370893022d22a9aa","url":"nowBusinessMethod","selected":false},{"id":"57d95aaa370893022d22a9ab","url":"nowBusinessMethod","selected":false},{"id":"57d95aaa370893022d22a9ac","url":"nowBusinessMethod","selected":false}];

    beforeEach(() => {
        module('DmlesModule');
        module('Dmles.Home.Module');
        module('Dmles.AdminModule');
        module('Dmles.Admin.PermissionManagementModule');
        module('Dmles.UserAdmin.PermissionManagement.MainNav.Module');
    });

    it('Has an permission Service', inject((PermissionManagementService) => {
        expect(PermissionManagementService).toBeDefined();
    }));

    it('The permissionManagement Service has a serviceName', inject((PermissionManagementService) => {
        expect(PermissionManagementService.serviceName).toBeDefined();
    }));

    it("The permissionManagement Service serviceName has the correct value", inject((PermissionManagementService) => {
        expect(PermissionManagementService.serviceName).toMatch("Permission Management Service");
    }));

    it("The permissionManagement Service getPermission function returns the expected value", inject((PermissionManagementService) => {
        PermissionManagementService.permission = permission;
        expect(PermissionManagementService.getPermission()).toEqual(permission);
    }));

    it('The permissionManagement Service loadPermissionsTable function works - resolve path', inject((PermissionManagementService, RoleService) => {
        spyOn(PermissionManagementService, "loadPermissionsTable").and.callThrough();
        spyOn(RoleService, "getAllPermissionsDetailed").and.callFake(() => {
            return $.Deferred().resolve(allPermissionsDetailed);
        });

        PermissionManagementService.loadPermissionsTable();

        expect(PermissionManagementService.loadPermissionsTable).toHaveBeenCalled();
        expect(RoleService.getAllPermissionsDetailed).toHaveBeenCalled();
    }));

    it('The permissionManagement Service loadPermissionsTable function works - reject path', inject((PermissionManagementService, RoleService) => {
        spyOn(PermissionManagementService, "loadPermissionsTable").and.callThrough();
        spyOn(RoleService, "getAllPermissionsDetailed").and.callFake(() => {
            return $.Deferred().reject();
        });

        PermissionManagementService.loadPermissionsTable();

        expect(PermissionManagementService.loadPermissionsTable).toHaveBeenCalled();
        expect(RoleService.getAllPermissionsDetailed).toHaveBeenCalled();
    }));

    it('The permissionManagement Service getAllElements function works - resolve path', inject((PermissionManagementService, RoleService, UtilService) => {
        spyOn(PermissionManagementService, "getAllElements").and.callThrough();
        spyOn(RoleService, "getAllElements").and.callFake(() => {
            return $.Deferred().resolve(allElements);
        });
        spyOn(UtilService, "sortResults").and.callFake(() => {
            return $.Deferred().resolve(allElements);
        });

        PermissionManagementService.getAllElements();

        expect(PermissionManagementService.getAllElements).toHaveBeenCalled();
        expect(RoleService.getAllElements).toHaveBeenCalled();
        expect(UtilService.sortResults).toHaveBeenCalled();
    }));

    it('The permissionManagement Service getAllElements function works - reject path', inject((PermissionManagementService, RoleService) => {
        spyOn(PermissionManagementService, "getAllElements").and.callThrough();
        spyOn(RoleService, "getAllElements").and.callFake(() => {
            return $.Deferred().reject();
        });

        PermissionManagementService.getAllElements();

        expect(PermissionManagementService.getAllElements).toHaveBeenCalled();
        expect(RoleService.getAllElements).toHaveBeenCalled();
    }));

    it('The permissionManagement Service splitElementOpts function works', inject((PermissionManagementService) => {
        spyOn(PermissionManagementService, "splitElementOpts").and.callThrough();

        PermissionManagementService.splitElementOpts(elementOpts);

        expect(PermissionManagementService.splitElementOpts).toHaveBeenCalled();
    }));

    it('The permissionManagement Service savePermissionElements function works - resolve path', inject(($state, StateConstants, PermissionManagementService, RoleService) => {
        PermissionManagementService.permission = permission;
        spyOn($state, 'go');
        spyOn(PermissionManagementService, "savePermissionElements").and.callThrough();
        spyOn(RoleService, "savePermissionElements").and.callFake(() => {
            return $.Deferred().resolve(allElements);
        });       

        PermissionManagementService.savePermissionElements();

        expect(PermissionManagementService.savePermissionElements).toHaveBeenCalled();
        expect(RoleService.savePermissionElements).toHaveBeenCalled();
        expect($state.go).toHaveBeenCalledWith(StateConstants.ADMIN_PERMISSION_VIEW);
    }));

    it('The permissionManagement Service savePermissionElements function works - reject path', inject((PermissionManagementService, RoleService) => {
        PermissionManagementService.permission = permission;
        spyOn(PermissionManagementService, "savePermissionElements").and.callThrough();
        spyOn(RoleService, "savePermissionElements").and.callFake(() => {
            return $.Deferred().reject();
        });

        PermissionManagementService.savePermissionElements();

        expect(PermissionManagementService.savePermissionElements).toHaveBeenCalled();
        expect(RoleService.savePermissionElements).toHaveBeenCalled();
    }));

    it('The permissionManagement Service addElementsToPermission function works', inject((PermissionManagementService) => {
        PermissionManagementService.permission = permission;
        PermissionManagementService.elementOptsGroup1 = elementOpts;
        PermissionManagementService.elementOptsGroup2 = elementOpts;
        PermissionManagementService.elementOptsGroup3 = elementOpts;

        spyOn(PermissionManagementService, "savePermissionElements").and.callThrough();

        PermissionManagementService.savePermissionElements(permission);

        expect(PermissionManagementService.savePermissionElements).toHaveBeenCalled();
    }));

    it('The permissionManagement Service retrieveElementFromAllElements function works', inject((PermissionManagementService) => {
        PermissionManagementService.allElements = allElements;

        spyOn(PermissionManagementService, "retrieveElementFromAllElements").and.callThrough();

        PermissionManagementService.retrieveElementFromAllElements("57718452d0142fa833276e73");

        expect(PermissionManagementService.retrieveElementFromAllElements).toHaveBeenCalled();
    }));

    it('The permissionManagement Service getAllStates function works - resolve path', inject((PermissionManagementService, RoleService, UtilService) => {
        spyOn(PermissionManagementService, "getAllStates").and.callThrough();
        spyOn(RoleService, "getAllStates").and.callFake(() => {
            return $.Deferred().resolve(allStates);
        });
        spyOn(UtilService, "sortResults").and.callFake(() => {
            return $.Deferred().resolve(allStates);
        });

        PermissionManagementService.getAllStates();

        expect(PermissionManagementService.getAllStates).toHaveBeenCalled();
        expect(RoleService.getAllStates).toHaveBeenCalled();
        expect(UtilService.sortResults).toHaveBeenCalled();
    }));

    it('The permissionManagement Service getAllStates function works - reject path', inject((PermissionManagementService, RoleService) => {
        spyOn(PermissionManagementService, "getAllStates").and.callThrough();
        spyOn(RoleService, "getAllStates").and.callFake(() => {
            return $.Deferred().reject();
        });

        PermissionManagementService.getAllStates();

        expect(PermissionManagementService.getAllStates).toHaveBeenCalled();
        expect(RoleService.getAllStates).toHaveBeenCalled();
    }));

    it('The permissionManagement Service splitStateOpts function works - modNum === 0', inject((PermissionManagementService) => {
        spyOn(PermissionManagementService, "splitStateOpts").and.callThrough();

        PermissionManagementService.splitStateOpts(stateOptsNoRemainder);

        expect(PermissionManagementService.splitStateOpts).toHaveBeenCalled();
    }));

    it('The permissionManagement Service splitStateOpts function works - modNum !== 0', inject((PermissionManagementService) => {
        spyOn(PermissionManagementService, "splitStateOpts").and.callThrough();

        PermissionManagementService.splitStateOpts(stateOptsWithRemainder);

        expect(PermissionManagementService.splitStateOpts).toHaveBeenCalled();
    }));

    it('The permissionManagement Service savePermissionStates function works - resolve path', inject(($state, StateConstants, PermissionManagementService, RoleService) => {
        PermissionManagementService.permission = permission;
        spyOn($state, 'go');
        spyOn(PermissionManagementService, "savePermissionStates").and.callThrough();
        spyOn(RoleService, "savePermissionStates").and.callFake(() => {
            return $.Deferred().resolve(allStates);
        });

        PermissionManagementService.savePermissionStates();

        expect(PermissionManagementService.savePermissionStates).toHaveBeenCalled();
        expect(RoleService.savePermissionStates).toHaveBeenCalled();
        expect($state.go).toHaveBeenCalledWith(StateConstants.ADMIN_PERMISSION_VIEW);
    }));

    it('The permissionManagement Service savePermissionStates function works - reject path', inject((PermissionManagementService, RoleService) => {
        PermissionManagementService.permission = permission;
        spyOn(PermissionManagementService, "savePermissionStates").and.callThrough();
        spyOn(RoleService, "savePermissionStates").and.callFake(() => {
            return $.Deferred().reject();
        });

        PermissionManagementService.savePermissionStates();

        expect(PermissionManagementService.savePermissionStates).toHaveBeenCalled();
        expect(RoleService.savePermissionStates).toHaveBeenCalled();
    }));

    it('The permissionManagement Service addStatesToPermission function works', inject((PermissionManagementService) => {
        PermissionManagementService.permission = permission;
        PermissionManagementService.stateOptsGroup1 = stateOptsNoRemainder;
        PermissionManagementService.stateOptsGroup2 = stateOptsNoRemainder;
        PermissionManagementService.stateOptsGroup3 = stateOptsNoRemainder;

        spyOn(PermissionManagementService, "savePermissionStates").and.callThrough();

        PermissionManagementService.savePermissionStates(permission);

        expect(PermissionManagementService.savePermissionStates).toHaveBeenCalled();
    }));

    it('The permissionManagement Service retrieveStateFromAllStates function works', inject((PermissionManagementService) => {
        PermissionManagementService.allStates = allStates;

        spyOn(PermissionManagementService, "retrieveStateFromAllStates").and.callThrough();

        PermissionManagementService.retrieveStateFromAllStates("57718452d0142fa833276e3e");

        expect(PermissionManagementService.retrieveStateFromAllStates).toHaveBeenCalled();
    }));

    it('The permissionManagement Service getAllEndpoints function works - resolve path', inject((PermissionManagementService, RoleService, UtilService) => {
        spyOn(PermissionManagementService, "getAllEndpoints").and.callThrough();
        spyOn(RoleService, "getAllEndpoints").and.callFake(() => {
            return $.Deferred().resolve(allEndpoints);
        });
        spyOn(UtilService, "sortResults").and.callFake(() => {
            return $.Deferred().resolve(allEndpoints);
        });

        PermissionManagementService.getAllEndpoints();

        expect(PermissionManagementService.getAllEndpoints).toHaveBeenCalled();
        expect(RoleService.getAllEndpoints).toHaveBeenCalled();
        expect(UtilService.sortResults).toHaveBeenCalled();
    }));

    it('The permissionManagement Service getAllEndpoints function works - reject path', inject((PermissionManagementService, RoleService) => {
        spyOn(PermissionManagementService, "getAllEndpoints").and.callThrough();
        spyOn(RoleService, "getAllEndpoints").and.callFake(() => {
            return $.Deferred().reject();
        });

        PermissionManagementService.getAllEndpoints();

        expect(PermissionManagementService.getAllEndpoints).toHaveBeenCalled();
        expect(RoleService.getAllEndpoints).toHaveBeenCalled();
    }));

    it('The permissionManagement Service splitEndpointOpts function works', inject((PermissionManagementService) => {
        spyOn(PermissionManagementService, "splitEndpointOpts").and.callThrough();

        PermissionManagementService.splitEndpointOpts(endpointOpts);

        expect(PermissionManagementService.splitEndpointOpts).toHaveBeenCalled();
    }));

    it('The permissionManagement Service savePermissionEndpoints function works - resolve path', inject(($state, StateConstants, PermissionManagementService, RoleService) => {
        PermissionManagementService.permission = permission;
        spyOn($state, 'go');
        spyOn(PermissionManagementService, "savePermissionEndpoints").and.callThrough();
        spyOn(RoleService, "savePermissionEndpoints").and.callFake(() => {
            return $.Deferred().resolve(allEndpoints);
        });

        PermissionManagementService.savePermissionEndpoints();

        expect(PermissionManagementService.savePermissionEndpoints).toHaveBeenCalled();
        expect(RoleService.savePermissionEndpoints).toHaveBeenCalled();
        expect($state.go).toHaveBeenCalledWith(StateConstants.ADMIN_PERMISSION_VIEW);
    }));

    it('The permissionManagement Service savePermissionEndpoints function works - reject path', inject((PermissionManagementService, RoleService) => {
        PermissionManagementService.permission = permission;
        spyOn(PermissionManagementService, "savePermissionEndpoints").and.callThrough();
        spyOn(RoleService, "savePermissionEndpoints").and.callFake(() => {
            return $.Deferred().reject();
        });

        PermissionManagementService.savePermissionEndpoints();

        expect(PermissionManagementService.savePermissionEndpoints).toHaveBeenCalled();
        expect(RoleService.savePermissionEndpoints).toHaveBeenCalled();
    }));

    it('The permissionManagement Service addEndpointsToPermission function works', inject((PermissionManagementService) => {
        PermissionManagementService.permission = permission;
        PermissionManagementService.endpointOptsGroup1 = endpointOpts;
        PermissionManagementService.endpointOptsGroup2 = endpointOpts;
        PermissionManagementService.endpointOptsGroup3 = endpointOpts;

        spyOn(PermissionManagementService, "savePermissionEndpoints").and.callThrough();

        PermissionManagementService.savePermissionEndpoints(permission);

        expect(PermissionManagementService.savePermissionEndpoints).toHaveBeenCalled();
    }));

    it('The permissionManagement Service retrieveEndpointFromAllEndpoints function works', inject((PermissionManagementService) => {
        PermissionManagementService.allEndpoints = allEndpoints;

        spyOn(PermissionManagementService, "retrieveEndpointFromAllEndpoints").and.callThrough();

        PermissionManagementService.retrieveEndpointFromAllEndpoints("57d95aa4370893022d22a987");

        expect(PermissionManagementService.retrieveEndpointFromAllEndpoints).toHaveBeenCalled();
    }));


});

