import "../../../../src/module";
import "../../../../src/home/module";
import "../../../../src/home/admin/module";

describe('Admin AdminShell.Controller Tests', () => {
    var adminShellController;    
    var mock;

    beforeEach(() => {
        module('DmlesModule');
        module('Dmles.Home.Module');
        module('Dmles.AdminModule');

        inject(($rootScope, $controller, $state, StateConstants, UserService) => {

            mock = {
                $scope: $rootScope.$new(),
                StateConstants: StateConstants,
                $state: $state,
                UserService: UserService                
            };

            adminShellController = $controller('Dmles.Admin.AdminShellController', mock);
        });
    });

    it('Has scope', () => {
        expect(mock.$scope).not.toEqual(undefined);
    });

    it('Has a adminShellController controller', () => {
        expect(adminShellController).toBeDefined();
    });

    it('Has a controllerName variable', () => {
        expect(adminShellController.controllerName).toBeDefined();
    });

    it('The controllerName variable has the correct value', () => {
        expect(adminShellController.controllerName).toEqual("Admin Shell Controller");
    });

    it('The userProfileView controller goToUserManagement function works', () => {
        spyOn(mock.$state, 'go');
        spyOn(adminShellController, "goToUserManagement").and.callThrough();

        adminShellController.goToUserManagement();

        expect(adminShellController.goToUserManagement).toHaveBeenCalled();
        expect(mock.$state.go).toHaveBeenCalledWith(mock.StateConstants.ADMIN_USER_MNG);
    });

    it('The userProfileView controller goToUserProfileManagement function works', () => {
        spyOn(mock.$state, 'go');
        spyOn(adminShellController, "goToUserProfileManagement").and.callThrough();

        adminShellController.goToUserProfileManagement();

        expect(adminShellController.goToUserProfileManagement).toHaveBeenCalled();
        expect(mock.$state.go).toHaveBeenCalledWith(mock.StateConstants.ADMIN_USER_PROFILE_MNG);
    });

    it('The userProfileView controller goToRoleManagement function works', () => {
        spyOn(mock.$state, 'go');
        spyOn(adminShellController, "goToRoleManagement").and.callThrough();

        adminShellController.goToRoleManagement();

        expect(adminShellController.goToRoleManagement).toHaveBeenCalled();
        expect(mock.$state.go).toHaveBeenCalledWith(mock.StateConstants.ADMIN_ROLE_MNG);
    });

    it('The userProfileView controller goToPermManagement function works', () => {
        spyOn(mock.$state, 'go');
        spyOn(adminShellController, "goToPermManagement").and.callThrough();

        adminShellController.goToPermManagement();

        expect(adminShellController.goToPermManagement).toHaveBeenCalled();
        expect(mock.$state.go).toHaveBeenCalledWith(mock.StateConstants.ADMIN_PERMISSION_MNG);
    });
});

