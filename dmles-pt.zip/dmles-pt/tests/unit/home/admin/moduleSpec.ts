import "../../../../src/module";
import "../../../../src/home/module";
import "../../../../src/home/admin/module";

describe('Admin Module Tests', () => {

    beforeEach(() => {
        module('DmlesModule');
        module('Dmles.Home.Module');
        module('Dmles.AdminModule');
    });

    var controller;
    var scope;

    beforeEach(inject(($rootScope, $controller) => {
        scope = $rootScope.$new();
    }));

    it('Has scope', () => {
        expect(scope).toBeDefined();
    });

});