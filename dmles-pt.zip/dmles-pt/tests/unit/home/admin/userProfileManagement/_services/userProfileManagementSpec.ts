import "../../../../../../src/module";
import "../../../../../../src/home/module";
import "../../../../../../src/home/equipment/module";
import "../../../../../../src/home/equipment/records/module";
import "../../../../../../src/home/equipment/records/_services/module";
import "../../../../../../src/home/equipment/records/_views/module";

describe('Admin UserProfileManagement _Services UserProfileManagement Service Tests', () => {

    var userProfile = {
        "id": "5797741eb6c6b99956f06cc7",
        "registrationId": "5797741eb6c6b99956f06cc7",
        "userStatus": "ACTIVE",
        "email": "Forrest1@aol.com",
        "lastLoginDate": null,
        "firstName": "Forrest",
        "lastName": "Gump",
        "password": null,
        "pkiDn": null,
        "phoneNumbers": [
            {
                "phoneNumberType": "MOBILE",
                "value": "string"
            }
        ],
        "serviceCode": "string",
        "regionCode": "string",
        "profileName": "GLOBAL",
        "roles": [],
        "assignedPermissions": null,
        "userType": "GLOBAL",
        "dodaac": "string",
        "isDefault": false
    };

    var pendingUserProfiles = [{
        "id": "57b5dbc24163d50d7eae0b8a",
        "userProfileId": "GLOBAL",
        "userStatus": null,
        "accessApprovedDate": null,
        "accessDeniedDate": null,
        "email": "abd-allah.h.afeefy.ctr@mail.mil",
        "firstName": "Abd-Allah",
        "lastName": "Afeefy",
        "reasonForAccess": "Testing",
        "adminNotes": null,
        "password": "password",
        "pkiDn": null,
        "phoneNumbers": [{"phoneNumberType": "WORK", "value": "2407513602"}],
        "serviceCode": "",
        "regionCode": "",
        "userType": "GLOBAL",
        "dodaac": ""
    }];

    var approvedUserProfiles = [{
        "id": "5790c87a4c08b0003d9782f0",
        "registrationId": null,
        "userStatus": "ACTIVE",
        "email": "all@mail.mil",
        "lastLoginDate": 1473432575485,
        "firstName": "All",
        "lastName": "Permissions",
        "password": "password",
        "pkiDn": "all.123",
        "phoneNumbers": [{"phoneNumberType": "HOME", "value": "123-123-GUMP"}],
        "serviceCode": "DHA",
        "regionCode": null,
        "profileName": "GLOBAL",
        "roles": [{
            "id": "57728d8d4c0868770213abd1",
            "name": "All Role",
            "assignedPermissions": [{
                "id": null,
                "name": "All Permissions",
                "allowed": true,
                "permission": {
                    "id": "57728d844c08ed9af7596da7",
                    "name": "All Permissions",
                    "functionalArea": "Other",
                    "description": "All Permissions"
                }
            }],
            "roles": [],
            "functionalArea": "Other",
            "description": "Role that contains all roles"
        }],
        "assignedPermissions": null,
        "userType": "GLOBAL",
        "dodaac": null,
        "current": true
    }, {"id": "579105535eaa4621119bc261",
        "registrationId": null,
        "userStatus": "ACTIVE",
        "email": "bubba@mail.mil",
        "lastLoginDate": null,
        "firstName": "Bubba",
        "lastName": "Gump",
        "password": "Shrimp",
        "pkiDn": "bubba.123",
        "phoneNumbers": [{"phoneNumberType": "HOME", "value": "123-123-GUMP"}],
        "serviceCode": "MD",
        "regionCode": "North",
        "profileName": "GLOBAL",
        "roles": [{
            "id": "5784e3a3768bbb531eecd25b",
            "name": "Test Role",
            "assignedPermissions": [{
                "id": null,
                "name": "All Permissions",
                "allowed": true,
                "permission": {
                    "id": "57728d844c08ed9af7596da7",
                    "name": "All Permissions",
                    "functionalArea": "Other",
                    "description": "All Permissions"
                }
            }, {
                "id": null,
                "name": "Permission2a",
                "allowed": false,
                "permission": {
                    "id": "5780183b768bbb531eecd258",
                    "name": "View JMAR Search",
                    "functionalArea": "Other",
                    "description": "View JMAR Search"
                }
            }, {
                "id": null,
                "name": "Permission4",
                "allowed": true,
                "permission": {
                    "id": "57801870768bbb531eecd259",
                    "name": "View Equipment Records",
                    "functionalArea": "Equipment_Request",
                    "description": "View Equipment Records"
                }
            }],
            "roles": [],
            "functionalArea": "Other",
            "description": "Responsible for testing"
        }],
        "assignedPermissions": null,
        "userType": "GLOBAL",
        "dodaac": "bubbadodaac",
        "current": false
    }, {
        "id": "57966aa6b6c68b2f66ca18c1",
        "registrationId": null,
        "userStatus": "ACTIVE",
        "email": "bubba2@mail.mil",
        "lastLoginDate": null,
        "firstName": "Bubba2",
        "lastName": "Gump",
        "password": null,
        "pkiDn": "bubba2.123",
        "phoneNumbers": [{"phoneNumberType": "HOME", "value": "123-123-GUMP"}],
        "serviceCode": "MD",
        "regionCode": null,
        "profileName": "GLOBAL",
        "roles": [{
            "id": "57800fe5768bbb531eecd24d",
            "name": "Site Equipment Safety",
            "assignedPermissions": [{
                "id": null,
                "name": "Add Safety Weigh-Ins",
                "allowed": true,
                "permission": {
                    "id": "578014b2768bbb531eecd254",
                    "name": "Add Safety Weigh-Ins",
                    "functionalArea": "Equipment_Request",
                    "description": "Add Safety Weigh-Ins"
                }
            }, {
                "id": null,
                "name": "View Equipment Requests",
                "allowed": true,
                "permission": {
                    "id": "5780174e768bbb531eecd255",
                    "name": "View Equipment Requests",
                    "functionalArea": "Equipment_Request",
                    "description": "View Equipment Requests"
                }
            }, {
                "id": null,
                "name": "View Equipment Catalog",
                "allowed": true,
                "permission": {
                    "id": "5780177a768bbb531eecd256",
                    "name": "View Equipment Catalog",
                    "functionalArea": "Equipment_Request",
                    "description": "View Equipment Catalog"
                }
            }],
            "roles": [],
            "functionalArea": "Equipment_Request",
            "description": "Responsible for equipment safety at a site"
        }],
        "assignedPermissions": [{
            "id": null,
            "name": "Add Maintenance Weigh-Ins",
            "allowed": true,
            "permission": {
                "id": "5780147e768bbb531eecd252",
                "name": "Add Maintenance Weigh-Ins",
                "functionalArea": "Equipment_Request",
                "description": "Add Maintenance Weigh-Ins"
            }
        }],
        "userType": "GLOBAL",
        "dodaac": "152231456",
        "current": true
    }];

    var showUserProfileOpts = {
        ALL: "ALL",
        ACTIVE: "ACTIVE",
        INACTIVE: "INACTIVE"
    };

    beforeEach(() => {
        module('DmlesModule');
        module('Dmles.Home.Module');
        module('Dmles.AdminModule');
        module('Dmles.Admin.UserProfileManagementModule');
        module('Dmles.Admin.UserManagement.Views.Module');
        module('Dmles.Admin.UserProfileManagement.Services.Module');
    });

    it('Has an userProfileManagement Service', inject((UserProfileManagementService) => {
        expect(UserProfileManagementService).toBeDefined();
    }));

    it('The userProfileManagement Service has a serviceName', inject((UserProfileManagementService) => {
        expect(UserProfileManagementService.serviceName).toBeDefined();
    }));

    it("The userProfileManagement Service serviceName has the correct value", inject((UserProfileManagementService) => {
        expect(UserProfileManagementService.serviceName).toMatch("User Profile Management Service");
    }));

    it("The userProfileManagement Service getUserProfile function returns the expected value", inject((UserProfileManagementService) => {
        UserProfileManagementService.userProfile = userProfile;
        expect(UserProfileManagementService.getUserProfile()).toEqual(userProfile);
    }));

    it('The userProfileManagement Service loadPendingUserProfileTable function works - resolve path', inject((UserProfileManagementService, UserProfileService) => {
        spyOn(UserProfileManagementService, "loadPendingUserProfileTable").and.callThrough();
        spyOn(UserProfileService, "getPendingUserProfiles").and.callFake(() => {
            return $.Deferred().resolve(pendingUserProfiles);
        });

        UserProfileManagementService.loadPendingUserProfileTable();

        expect(UserProfileManagementService.loadPendingUserProfileTable).toHaveBeenCalled();
        expect(UserProfileService.getPendingUserProfiles).toHaveBeenCalled();
    }));

    it('The userProfileManagement Service loadPendingUserProfileTable function works - reject path', inject((UserProfileManagementService, UserProfileService) => {
        spyOn(UserProfileManagementService, "loadPendingUserProfileTable").and.callThrough();
        spyOn(UserProfileService, "getPendingUserProfiles").and.callFake(() => {
            return $.Deferred().reject();
        });

        UserProfileManagementService.loadPendingUserProfileTable();

        expect(UserProfileManagementService.loadPendingUserProfileTable).toHaveBeenCalled();
        expect(UserProfileService.getPendingUserProfiles).toHaveBeenCalled();
    }));

    it('The userProfileManagement Service loadAuthorizedUsersData function works - resolve path', inject((UserProfileManagementService, UserProfileService) => {
        spyOn(UserProfileManagementService, "loadAuthorizedUsersData").and.callThrough();
        spyOn(UserProfileService, "getApprovedUserProfiles").and.callFake(() => {
            return $.Deferred().resolve(approvedUserProfiles);
        });

        UserProfileManagementService.showUserProfileOpts = showUserProfileOpts;
        UserProfileManagementService.showUserProfiles = "ALL";
        UserProfileManagementService.loadAuthorizedUsersData();

        expect(UserProfileManagementService.loadAuthorizedUsersData).toHaveBeenCalled();
        expect(UserProfileService.getApprovedUserProfiles).toHaveBeenCalled();
    }));

    it('The userProfileManagement Service loadAuthorizedUsersData function works - reject path', inject((UserProfileManagementService, UserProfileService) => {
        spyOn(UserProfileManagementService, "loadAuthorizedUsersData").and.callThrough();
        spyOn(UserProfileService, "getApprovedUserProfiles").and.callFake(() => {
            return $.Deferred().reject();
        });

        UserProfileManagementService.loadAuthorizedUsersData();

        expect(UserProfileManagementService.loadAuthorizedUsersData).toHaveBeenCalled();
        expect(UserProfileService.getApprovedUserProfiles).toHaveBeenCalled();
    }));

    it("The userProfileManagement Service updateApprovedUserProfilesFilter function works with ACTIVE filter value", inject((UserProfileManagementService) => {
        spyOn(UserProfileManagementService, "updateApprovedUserProfilesFilter").and.callThrough();

        UserProfileManagementService.showUserProfileOpts = showUserProfileOpts;
        UserProfileManagementService.updateApprovedUserProfilesFilter("ACTIVE");

        expect(UserProfileManagementService.updateApprovedUserProfilesFilter).toHaveBeenCalled();
    }));

    it("The userProfileManagement Service updateApprovedUserProfilesFilter function works with INACTIVE filter value", inject((UserProfileManagementService) => {
        spyOn(UserProfileManagementService, "updateApprovedUserProfilesFilter").and.callThrough();

        UserProfileManagementService.showUserProfileOpts = showUserProfileOpts;
        UserProfileManagementService.updateApprovedUserProfilesFilter("INACTIVE");

        expect(UserProfileManagementService.updateApprovedUserProfilesFilter).toHaveBeenCalled();
    }));

});

