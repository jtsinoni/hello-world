import "../../../../../src/module";
import "../../../../../src/home/module";
import "../../../../../src/home/admin/module";
import "../../../../../src/home/admin/userProfileManagement/module";

describe('Admin UserProfileManagement Module Tests', () => {

    beforeEach(() => {
        module('DmlesModule');
        module('Dmles.Home.Module');
        module('Dmles.AdminModule');
        module('Dmles.Admin.UserProfileManagementModule');        
    });

    var scope;

    beforeEach(inject(($rootScope, $controller) => {
        scope = $rootScope.$new();
    }));

    it('Has scope', () => {
        expect(scope).toBeDefined();
    });

});