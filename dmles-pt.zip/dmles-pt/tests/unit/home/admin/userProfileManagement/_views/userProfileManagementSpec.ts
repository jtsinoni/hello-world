import "../../../../../../src/module";
import "../../../../../../src/home/module";
import "../../../../../../src/home/admin/module";
import "../../../../../../src/home/admin/userProfileManagement/module";
import "../../../../../../src/home/admin/userProfileManagement/_services/module";
import "../../../../../../src/home/admin/userProfileManagement/_views/module";

describe('Admin UserProfileManagement _Views UserProfileManagement.Controller Tests', () => {
    var userProfileManagementController;
    var mock;

    var userProfile = {
        "id": "5797741eb6c6b99956f06cc7",
        "registrationId": "5797741eb6c6b99956f06cc7",
        "userStatus": "ACTIVE",
        "email": "Forrest1@aol.com",
        "lastLoginDate": null,
        "firstName": "Forrest",
        "lastName": "Gump",
        "password": null,
        "pkiDn": null,
        "phoneNumbers": [
            {
                "phoneNumberType": "MOBILE",
                "value": "string"
            }
        ],
        "serviceCode": "string",
        "regionCode": "string",
        "profileName": "GLOBAL",
        "roles": [],
        "assignedPermissions": null,
        "userType": "GLOBAL",
        "dodaac": "string",
        "isDefault": false
    };

    beforeEach(() => {
        module('DmlesModule');
        module('Dmles.Home.Module');
        module('Dmles.AdminModule');
        module('Dmles.Admin.UserProfileManagementModule');
        module('Dmles.Admin.UserManagement.Views.Module');

        inject(($rootScope, $controller, $q, $state, StateConstants, UserProfileService, UserProfileManagementService) => {
            mock = {
                $scope: $rootScope.$new(),
                StateConstants: StateConstants,
                UserProfileService: UserProfileService,
                UserProfileManagementService: UserProfileManagementService,
                deferred: $q.defer(),
                skip: $q.defer(),
                $state: $state
            };

            userProfileManagementController = $controller('Dmles.Admin.UserProfileManagement.Views.UserProfileManagementController', mock);
        });
    });

    it('Has scope', () => {
        expect(mock.$scope).not.toEqual(undefined);
    });

    it('Has a userProfileManagementController controller', () => {
        expect(userProfileManagementController).toBeDefined();
    });

    it('Has a showUserProfileOpts variable', () => {
        expect(userProfileManagementController.UserProfileManagementService.showUserProfileOpts).toBeDefined();
    });

    it('The showUserProfileOpts variable has the correct value', () => {
        expect(userProfileManagementController.UserProfileManagementService.showUserProfileOpts).toEqual({
            ALL: "ALL",
            ACTIVE: "ACTIVE",
            INACTIVE: "INACTIVE"
        });
    });

    it('Has a showUserProfiles variable', () => {
        expect(userProfileManagementController.UserProfileManagementService.showUserProfiles).toBeDefined();
    });

    it('The showUserProfiles variable has the correct value', () => {
        expect(userProfileManagementController.UserProfileManagementService.showUserProfiles).toEqual("ACTIVE");
    });

    it('Has an UserProfile Service', () => {
        expect(userProfileManagementController.UserProfileService).toBeDefined();
    });

    it('Has an UserProfileManagement Service', () => {
        expect(userProfileManagementController.UserProfileManagementService).toBeDefined();
    });

    it('The userProfileManagement controller activateUserProfile function works', () => {
        spyOn(userProfileManagementController, "activateUserProfile").and.callThrough();
        userProfileManagementController.activateUserProfile(userProfile);
        expect(userProfileManagementController.activateUserProfile).toHaveBeenCalled();
    });

    it('The userProfileManagement controller deactivateUserProfile function works', () => {
        spyOn(userProfileManagementController, "deactivateUserProfile").and.callThrough();
        userProfileManagementController.deactivateUserProfile(userProfile);
        expect(userProfileManagementController.deactivateUserProfile).toHaveBeenCalled();
    });

    it('The userProfileManagement controller saveUserProfileGeneralInfo function works - resolve path', () => {
        spyOn(userProfileManagementController, "saveUserProfileGeneralInfo").and.callThrough();
        spyOn(userProfileManagementController.UserProfileService, "saveUserProfileData").and.callFake(() => {
            return $.Deferred().resolve(userProfile);
        });
        spyOn(userProfileManagementController.UserProfileManagementService, "setUserProfile").and.callThrough();
        spyOn(userProfileManagementController.UserProfileManagementService, "loadAuthorizedUsersData").and.callThrough();

        userProfileManagementController.saveUserProfileGeneralInfo(userProfile);

        expect(userProfileManagementController.saveUserProfileGeneralInfo).toHaveBeenCalled();
        expect(userProfileManagementController.UserProfileService.saveUserProfileData).toHaveBeenCalled();
        expect(userProfileManagementController.UserProfileManagementService.setUserProfile).toHaveBeenCalled();
        expect(userProfileManagementController.UserProfileManagementService.loadAuthorizedUsersData).toHaveBeenCalled();
    });

    it('The userProfileManagement controller saveUserProfileGeneralInfo function works - reject path', () => {
        spyOn(userProfileManagementController, "saveUserProfileGeneralInfo").and.callThrough();
        spyOn(userProfileManagementController.UserProfileService, "saveUserProfileData").and.callFake(() => {
            return $.Deferred().reject();
        });

        userProfileManagementController.saveUserProfileGeneralInfo(userProfile);

        expect(userProfileManagementController.saveUserProfileGeneralInfo).toHaveBeenCalled();
        expect(userProfileManagementController.UserProfileService.saveUserProfileData).toHaveBeenCalled();
    });

    it('The userProfileManagement controller userProfileView function works', () => {
        spyOn(mock.$state, 'go');
        spyOn(userProfileManagementController, "userProfileView").and.callThrough();

        userProfileManagementController.userProfileView(userProfile);

        expect(userProfileManagementController.userProfileView).toHaveBeenCalled();
        expect(mock.$state.go).toHaveBeenCalledWith(mock.StateConstants.ADMIN_USER_PROFILE_VIEW);
    });
});

