import "../../../../../../src/module";
import "../../../../../../src/home/module";
import "../../../../../../src/home/admin/module";
import "../../../../../../src/home/admin/userProfileManagement/module";
import "../../../../../../src/home/admin/userProfileManagement/_services/module";
import "../../../../../../src/home/admin/userProfileManagement/_views/module";

describe('Admin UserProfileManagement _Views UserProfileEditRoles.Controller Tests', () => {
    var userProfileEditRolesController;
    var mock;

    var userProfile = {
        "id": "57b5eef2c6bfe067c5133935",
        "registrationId": "57b5eef2c6bfe067c5133935",
        "userStatus": "ACTIVE",
        "email": "cold@mail.mil",
        "lastLoginDate": 1472044028949,
        "firstName": "Patrick",
        "lastName": "Scarbrough",
        "password": null,
        "pkiDn": "cold.123",
        "phoneNumbers": [{"phoneNumberType": "WORK", "value": "301-123-COLD"}],
        "serviceCode": "DF",
        "regionCode": "AFGSC",
        "profileName": "SITE FM4528",
        "roles": [{
            "id": "57800b36768bbb531eecd244",
            "name": "User Admin",
            "assignedPermissions": [{
                "id": null,
                "name": "Manage User Profiles",
                "allowed": true,
                "permission": {
                    "id": "57800a1e768bbb531eecd243",
                    "name": "Manage User Profiles",
                    "functionalArea": "Administration",
                    "description": "Manage User Profiles"
                }
            }, {
                "id": null,
                "name": "Manage User Roles",
                "allowed": true,
                "permission": {
                    "id": "57800c60768bbb531eecd245",
                    "name": "Manage User Roles",
                    "functionalArea": "Administration",
                    "description": "Manage User Roles"
                }
            }],
            "roles": [],
            "functionalArea": "Administration",
            "description": "Responsible for administration of users",
            "$$hashKey": "object:834"
        }, {
            "id": "57801d01768bbb531eecd25a",
            "name": "JMAR",
            "assignedPermissions": [{
                "id": null,
                "name": "View JMAR Search",
                "allowed": true,
                "permission": {
                    "id": "5780183b768bbb531eecd258",
                    "name": "View JMAR Search",
                    "functionalArea": "Other",
                    "description": "View JMAR Search"
                }
            }],
            "roles": [],
            "functionalArea": "Other",
            "description": "Using DML-ES for coordination with JMAR",
            "$$hashKey": "object:835"
        }],
        "assignedPermissions": [{
            "id": null,
            "name": "Manage Permissions",
            "allowed": true,
            "permission": {
                "id": "57ade6a1a8ac2ac9a4fdc8dd",
                "name": "Manage Permissions",
                "functionalArea": "Administration",
                "description": "Manage Permissions"
            }
        }, {
            "id": null,
            "name": "Manage User Profiles",
            "allowed": true,
            "permission": {
                "id": "57800a1e768bbb531eecd243",
                "name": "Manage User Profiles",
                "functionalArea": "Administration",
                "description": "Manage User Profiles"
            }
        }, {
            "id": null,
            "name": "Manage User Roles",
            "allowed": true,
            "permission": {
                "id": "57800c60768bbb531eecd245",
                "name": "Manage User Roles",
                "functionalArea": "Administration",
                "description": "Manage User Roles"
            }
        }],
        "userType": "SITE",
        "dodaac": "FM4528",
        "current": true,
        "$$hashKey": "object:590"
    };

    var allRolesResponse = [{
        "id": "57728d8d4c0868770213abd1",
        "name": "All Role",
        "assignedPermissions": [{
            "id": null,
            "name": "All Permissions",
            "allowed": true,
            "permission": {
                "id": "57728d844c08ed9af7596da7",
                "name": "All Permissions",
                "functionalArea": "Other",
                "description": "All Permissions"
            }
        }],
        "roles": [],
        "functionalArea": "Other",
        "description": "Role that contains all roles"
    }, {
        "id": "57800b36768bbb531eecd244",
        "name": "User Admin",
        "assignedPermissions": [{
            "id": null,
            "name": "Manage User Profiles",
            "allowed": true,
            "permission": {
                "id": "57800a1e768bbb531eecd243",
                "name": "Manage User Profiles",
                "functionalArea": "Administration",
                "description": "Manage User Profiles"
            }
        }, {
            "id": null,
            "name": "Manage User Roles",
            "allowed": true,
            "permission": {
                "id": "57800c60768bbb531eecd245",
                "name": "Manage User Roles",
                "functionalArea": "Administration",
                "description": "Manage User Roles"
            }
        }],
        "roles": [],
        "functionalArea": "Administration",
        "description": "Responsible for administration of users"
    }, {
        "id": "57800ed6768bbb531eecd248",
        "name": "Site Equipment Custodian",
        "assignedPermissions": [{
            "id": null,
            "name": "View Equipment Catalog",
            "allowed": true,
            "permission": {
                "id": "5780177a768bbb531eecd256",
                "name": "View Equipment Catalog",
                "functionalArea": "Equipment_Request",
                "description": "View Equipment Catalog"
            }
        }, {
            "id": null,
            "name": "Create Equipment Requests From Catalog",
            "allowed": true,
            "permission": {
                "id": "578017d5768bbb531eecd257",
                "name": "Create Equipment Requests From Catalog",
                "functionalArea": "Equipment_Request",
                "description": "Create Equipment Requests From Catalog"
            }
        }, {
            "id": null,
            "name": "Submit Equipment Requests",
            "allowed": true,
            "permission": {
                "id": "57800e6f768bbb531eecd247",
                "name": "Submit Equipment Requests",
                "functionalArea": "Equipment_Request",
                "description": "Submit Equipment Requests"
            }
        }, {
            "id": null,
            "name": "View Equipment Requests",
            "allowed": true,
            "permission": {
                "id": "5780174e768bbb531eecd255",
                "name": "View Equipment Requests",
                "functionalArea": "Equipment_Request",
                "description": "View Equipment Requests"
            }
        }, {
            "id": null,
            "name": "View Equipment Records",
            "allowed": true,
            "permission": {
                "id": "57801870768bbb531eecd259",
                "name": "View Equipment Records",
                "functionalArea": "Equipment_Request",
                "description": "View Equipment Records"
            }
        }],
        "roles": [],
        "functionalArea": "Equipment_Request",
        "description": "Responsible for equipment at a site."
    }, {
        "id": "57800f5d768bbb531eecd249",
        "name": "Site Equipment Manager",
        "assignedPermissions": [{
            "id": null,
            "name": "Submit Equipment Requests",
            "allowed": true,
            "permission": {
                "id": "57800e6f768bbb531eecd247",
                "name": "Submit Equipment Requests",
                "functionalArea": "Equipment_Request",
                "description": "Submit Equipment Requests"
            }
        }, {
            "id": null,
            "name": "Manage Equipment Requests",
            "allowed": true,
            "permission": {
                "id": "57801183768bbb531eecd24f",
                "name": "Manage Equipment Requests",
                "functionalArea": "Equipment_Request",
                "description": "Manage Equipment Requests"
            }
        }, {
            "id": null,
            "name": "View Equipment Records",
            "allowed": true,
            "permission": {
                "id": "57801870768bbb531eecd259",
                "name": "View Equipment Records",
                "functionalArea": "Equipment_Request",
                "description": "View Equipment Records"
            }
        }],
        "roles": [],
        "functionalArea": "Equipment_Request",
        "description": "Responsible for managing equipment at a site"
    }, {
        "id": "57800f96768bbb531eecd24a",
        "name": "Site Equipment Technologist",
        "assignedPermissions": [{
            "id": null,
            "name": "Add Technology Weigh-Ins",
            "allowed": true,
            "permission": {
                "id": "57801498768bbb531eecd253",
                "name": "Add Technology Weigh-Ins",
                "functionalArea": "Equipment_Request",
                "description": "Add Technology Weigh-Ins"
            }
        }, {
            "id": null,
            "name": "View Equipment Requests",
            "allowed": true,
            "permission": {
                "id": "5780174e768bbb531eecd255",
                "name": "View Equipment Requests",
                "functionalArea": "Equipment_Request",
                "description": "View Equipment Requests"
            }
        }, {
            "id": null,
            "name": "View Equipment Catalog",
            "allowed": true,
            "permission": {
                "id": "5780177a768bbb531eecd256",
                "name": "View Equipment Catalog",
                "functionalArea": "Equipment_Request",
                "description": "View Equipment Catalog"
            }
        }],
        "roles": [],
        "functionalArea": "Equipment_Request",
        "description": "Responsible for equipment technology at a site"
    }, {
        "id": "57800fba768bbb531eecd24b",
        "name": "Site Equipment Maintenance",
        "assignedPermissions": [{
            "id": null,
            "name": "Add Maintenance Weigh-Ins",
            "allowed": true,
            "permission": {
                "id": "5780147e768bbb531eecd252",
                "name": "Add Maintenance Weigh-Ins",
                "functionalArea": "Equipment_Request",
                "description": "Add Maintenance Weigh-Ins"
            }
        }, {
            "id": null,
            "name": "View Equipment Requests",
            "allowed": true,
            "permission": {
                "id": "5780174e768bbb531eecd255",
                "name": "View Equipment Requests",
                "functionalArea": "Equipment_Request",
                "description": "View Equipment Requests"
            }
        }, {
            "id": null,
            "name": "View Equipment Catalog",
            "allowed": true,
            "permission": {
                "id": "5780177a768bbb531eecd256",
                "name": "View Equipment Catalog",
                "functionalArea": "Equipment_Request",
                "description": "View Equipment Catalog"
            }
        }],
        "roles": [],
        "functionalArea": "Equipment_Request",
        "description": "Responsible for maintenance of equipment"
    }, {
        "id": "57800fc5768bbb531eecd24c",
        "name": "Site Equipment Facilities",
        "assignedPermissions": [{
            "id": null,
            "name": "Add Facility Weigh-Ins",
            "allowed": true,
            "permission": {
                "id": "57801466768bbb531eecd251",
                "name": "Add Facility Weigh-Ins",
                "functionalArea": "Equipment_Request",
                "description": "Add Facility Weigh-Ins"
            }
        }, {
            "id": null,
            "name": "View Equipment Requests",
            "allowed": true,
            "permission": {
                "id": "5780174e768bbb531eecd255",
                "name": "View Equipment Requests",
                "functionalArea": "Equipment_Request",
                "description": "View Equipment Requests"
            }
        }, {
            "id": null,
            "name": "View Equipment Catalog",
            "allowed": true,
            "permission": {
                "id": "5780177a768bbb531eecd256",
                "name": "View Equipment Catalog",
                "functionalArea": "Equipment_Request",
                "description": "View Equipment Catalog"
            }
        }],
        "roles": [],
        "functionalArea": "Equipment_Request",
        "description": "Responsible for providing equipment facilities at a site"
    }, {
        "id": "57800fe5768bbb531eecd24d",
        "name": "Site Equipment Safety",
        "assignedPermissions": [{
            "id": null,
            "name": "Add Safety Weigh-Ins",
            "allowed": true,
            "permission": {
                "id": "578014b2768bbb531eecd254",
                "name": "Add Safety Weigh-Ins",
                "functionalArea": "Equipment_Request",
                "description": "Add Safety Weigh-Ins"
            }
        }, {
            "id": null,
            "name": "View Equipment Requests",
            "allowed": true,
            "permission": {
                "id": "5780174e768bbb531eecd255",
                "name": "View Equipment Requests",
                "functionalArea": "Equipment_Request",
                "description": "View Equipment Requests"
            }
        }, {
            "id": null,
            "name": "View Equipment Catalog",
            "allowed": true,
            "permission": {
                "id": "5780177a768bbb531eecd256",
                "name": "View Equipment Catalog",
                "functionalArea": "Equipment_Request",
                "description": "View Equipment Catalog"
            }
        }],
        "roles": [],
        "functionalArea": "Equipment_Request",
        "description": "Responsible for equipment safety at a site"
    }, {
        "id": "57801d01768bbb531eecd25a",
        "name": "JMAR",
        "assignedPermissions": [{
            "id": null,
            "name": "View JMAR Search",
            "allowed": true,
            "permission": {
                "id": "5780183b768bbb531eecd258",
                "name": "View JMAR Search",
                "functionalArea": "Other",
                "description": "View JMAR Search"
            }
        }],
        "roles": [],
        "functionalArea": "Other",
        "description": "Using DML-ES for coordination with JMAR"
    }, {
        "id": "5784e3a3768bbb531eecd25b",
        "name": "Test Role",
        "assignedPermissions": [{
            "id": null,
            "name": "All Permissions",
            "allowed": true,
            "permission": {
                "id": "57728d844c08ed9af7596da7",
                "name": "All Permissions",
                "functionalArea": "Other",
                "description": "All Permissions"
            }
        }, {
            "id": null,
            "name": "Permission2a",
            "allowed": false,
            "permission": {
                "id": "5780183b768bbb531eecd258",
                "name": "View JMAR Search",
                "functionalArea": "Other",
                "description": "View JMAR Search"
            }
        }, {
            "id": null,
            "name": "Permission4",
            "allowed": true,
            "permission": {
                "id": "57801870768bbb531eecd259",
                "name": "View Equipment Records",
                "functionalArea": "Equipment_Request",
                "description": "View Equipment Records"
            }
        }],
        "roles": [],
        "functionalArea": "Other",
        "description": "Responsible for testing"
    }, {
        "id": "57bf493c03e0fba04e9bba1e",
        "name": "Regional Equipment Manager",
        "assignedPermissions": [{
            "id": null,
            "name": "Submit Equipment Requests",
            "allowed": true,
            "permission": {
                "id": "57800e6f768bbb531eecd247",
                "name": "Submit Equipment Requests",
                "functionalArea": "Equipment_Request",
                "description": "Submit Equipment Requests"
            }
        }, {
            "id": null,
            "name": "Manage Equipment Requests",
            "allowed": true,
            "permission": {
                "id": "57801183768bbb531eecd24f",
                "name": "Manage Equipment Requests",
                "functionalArea": "Equipment_Request",
                "description": "Manage Equipment Requests"
            }
        }, {
            "id": null,
            "name": "View Equipment Records",
            "allowed": true,
            "permission": {
                "id": "57801870768bbb531eecd259",
                "name": "View Equipment Records",
                "functionalArea": "Equipment_Request",
                "description": "View Equipment Records"
            }
        }],
        "roles": [],
        "functionalArea": "Equipment_Request",
        "description": "Responsible for managing equipment at the regional level"
    }, {
        "id": "57bf49ad03e0fba04e9bba1f",
        "name": "Regional Equipment Technologist",
        "assignedPermissions": [{
            "id": null,
            "name": "Add Technology Weigh-Ins",
            "allowed": true,
            "permission": {
                "id": "57801498768bbb531eecd253",
                "name": "Add Technology Weigh-Ins",
                "functionalArea": "Equipment_Request",
                "description": "Add Technology Weigh-Ins"
            }
        }, {
            "id": null,
            "name": "View Equipment Requests",
            "allowed": true,
            "permission": {
                "id": "5780174e768bbb531eecd255",
                "name": "View Equipment Requests",
                "functionalArea": "Equipment_Request",
                "description": "View Equipment Requests"
            }
        }, {
            "id": null,
            "name": "View Equipment Catalog",
            "allowed": true,
            "permission": {
                "id": "5780177a768bbb531eecd256",
                "name": "View Equipment Catalog",
                "functionalArea": "Equipment_Request",
                "description": "View Equipment Catalog"
            }
        }],
        "roles": [],
        "functionalArea": "Equipment_Request",
        "description": "Responsible for equipment technology at the regional level"
    }, {
        "id": "57bf49da03e0fba04e9bba20",
        "name": "Regional Equipment Maintenance",
        "assignedPermissions": [{
            "id": null,
            "name": "Add Maintenance Weigh-Ins",
            "allowed": true,
            "permission": {
                "id": "5780147e768bbb531eecd252",
                "name": "Add Maintenance Weigh-Ins",
                "functionalArea": "Equipment_Request",
                "description": "Add Maintenance Weigh-Ins"
            }
        }, {
            "id": null,
            "name": "View Equipment Requests",
            "allowed": true,
            "permission": {
                "id": "5780174e768bbb531eecd255",
                "name": "View Equipment Requests",
                "functionalArea": "Equipment_Request",
                "description": "View Equipment Requests"
            }
        }, {
            "id": null,
            "name": "View Equipment Catalog",
            "allowed": true,
            "permission": {
                "id": "5780177a768bbb531eecd256",
                "name": "View Equipment Catalog",
                "functionalArea": "Equipment_Request",
                "description": "View Equipment Catalog"
            }
        }],
        "roles": [],
        "functionalArea": "Equipment_Request",
        "description": "Responsible for maintenance of equipment at the regional level"
    }, {
        "id": "57bf4a1203e0fba04e9bba21",
        "name": "Regional Equipment Facilities",
        "assignedPermissions": [{
            "id": null,
            "name": "Add Facility Weigh-Ins",
            "allowed": true,
            "permission": {
                "id": "57801466768bbb531eecd251",
                "name": "Add Facility Weigh-Ins",
                "functionalArea": "Equipment_Request",
                "description": "Add Facility Weigh-Ins"
            }
        }, {
            "id": null,
            "name": "View Equipment Requests",
            "allowed": true,
            "permission": {
                "id": "5780174e768bbb531eecd255",
                "name": "View Equipment Requests",
                "functionalArea": "Equipment_Request",
                "description": "View Equipment Requests"
            }
        }, {
            "id": null,
            "name": "View Equipment Catalog",
            "allowed": true,
            "permission": {
                "id": "5780177a768bbb531eecd256",
                "name": "View Equipment Catalog",
                "functionalArea": "Equipment_Request",
                "description": "View Equipment Catalog"
            }
        }],
        "roles": [],
        "functionalArea": "Equipment_Request",
        "description": "Responsible for providing equipment facilities at the regional level"
    }, {
        "id": "57bf4a3403e0fba04e9bba22",
        "name": "Regional Equipment Safety",
        "assignedPermissions": [{
            "id": null,
            "name": "Add Safety Weigh-Ins",
            "allowed": true,
            "permission": {
                "id": "578014b2768bbb531eecd254",
                "name": "Add Safety Weigh-Ins",
                "functionalArea": "Equipment_Request",
                "description": "Add Safety Weigh-Ins"
            }
        }, {
            "id": null,
            "name": "View Equipment Requests",
            "allowed": true,
            "permission": {
                "id": "5780174e768bbb531eecd255",
                "name": "View Equipment Requests",
                "functionalArea": "Equipment_Request",
                "description": "View Equipment Requests"
            }
        }, {
            "id": null,
            "name": "View Equipment Catalog",
            "allowed": true,
            "permission": {
                "id": "5780177a768bbb531eecd256",
                "name": "View Equipment Catalog",
                "functionalArea": "Equipment_Request",
                "description": "View Equipment Catalog"
            }
        }],
        "roles": [],
        "functionalArea": "Equipment_Request",
        "description": "Responsible for equipment safety at the regional level"
    }, {
        "id": "57bf4a5303e0fba04e9bba23",
        "name": "Service Equipment Manager",
        "assignedPermissions": [{
            "id": null,
            "name": "Submit Equipment Requests",
            "allowed": true,
            "permission": {
                "id": "57800e6f768bbb531eecd247",
                "name": "Submit Equipment Requests",
                "functionalArea": "Equipment_Request",
                "description": "Submit Equipment Requests"
            }
        }, {
            "id": null,
            "name": "Manage Equipment Requests",
            "allowed": true,
            "permission": {
                "id": "57801183768bbb531eecd24f",
                "name": "Manage Equipment Requests",
                "functionalArea": "Equipment_Request",
                "description": "Manage Equipment Requests"
            }
        }, {
            "id": null,
            "name": "View Equipment Records",
            "allowed": true,
            "permission": {
                "id": "57801870768bbb531eecd259",
                "name": "View Equipment Records",
                "functionalArea": "Equipment_Request",
                "description": "View Equipment Records"
            }
        }, {
            "id": null,
            "name": "Add Facility Weigh-Ins",
            "allowed": true,
            "permission": {
                "id": "57801466768bbb531eecd251",
                "name": "Add Facility Weigh-Ins",
                "functionalArea": "Equipment_Request",
                "description": "Add Facility Weigh-Ins"
            }
        }, {
            "id": null,
            "name": "Add Maintenance Weigh-Ins",
            "allowed": true,
            "permission": {
                "id": "5780147e768bbb531eecd252",
                "name": "Add Maintenance Weigh-Ins",
                "functionalArea": "Equipment_Request",
                "description": "Add Maintenance Weigh-Ins"
            }
        }, {
            "id": null,
            "name": "Add Safety Weigh-Ins",
            "allowed": true,
            "permission": {
                "id": "578014b2768bbb531eecd254",
                "name": "Add Safety Weigh-Ins",
                "functionalArea": "Equipment_Request",
                "description": "Add Safety Weigh-Ins"
            }
        }, {
            "id": null,
            "name": "Add Technology Weigh-Ins",
            "allowed": true,
            "permission": {
                "id": "57801498768bbb531eecd253",
                "name": "Add Technology Weigh-Ins",
                "functionalArea": "Equipment_Request",
                "description": "Add Technology Weigh-Ins"
            }
        }, {
            "id": null,
            "name": "View Equipment Requests",
            "allowed": true,
            "permission": {
                "id": "5780174e768bbb531eecd255",
                "name": "View Equipment Requests",
                "functionalArea": "Equipment_Request",
                "description": "View Equipment Requests"
            }
        }],
        "roles": [],
        "functionalArea": "Equipment_Request",
        "description": "Responsible for managing equipment at the service level"
    }, {
        "id": "57bf4a6e03e0fba04e9bba24",
        "name": "Service Equipment Technologist",
        "assignedPermissions": [{
            "id": null,
            "name": "Add Technology Weigh-Ins",
            "allowed": true,
            "permission": {
                "id": "57801498768bbb531eecd253",
                "name": "Add Technology Weigh-Ins",
                "functionalArea": "Equipment_Request",
                "description": "Add Technology Weigh-Ins"
            }
        }, {
            "id": null,
            "name": "View Equipment Requests",
            "allowed": true,
            "permission": {
                "id": "5780174e768bbb531eecd255",
                "name": "View Equipment Requests",
                "functionalArea": "Equipment_Request",
                "description": "View Equipment Requests"
            }
        }, {
            "id": null,
            "name": "View Equipment Catalog",
            "allowed": true,
            "permission": {
                "id": "5780177a768bbb531eecd256",
                "name": "View Equipment Catalog",
                "functionalArea": "Equipment_Request",
                "description": "View Equipment Catalog"
            }
        }],
        "roles": [],
        "functionalArea": "Equipment_Request",
        "description": "Responsible for equipment technology at the service level"
    }, {
        "id": "57bf4a8403e0fba04e9bba25",
        "name": "Service Equipment Maintenance",
        "assignedPermissions": [{
            "id": null,
            "name": "Add Maintenance Weigh-Ins",
            "allowed": true,
            "permission": {
                "id": "5780147e768bbb531eecd252",
                "name": "Add Maintenance Weigh-Ins",
                "functionalArea": "Equipment_Request",
                "description": "Add Maintenance Weigh-Ins"
            }
        }, {
            "id": null,
            "name": "View Equipment Requests",
            "allowed": true,
            "permission": {
                "id": "5780174e768bbb531eecd255",
                "name": "View Equipment Requests",
                "functionalArea": "Equipment_Request",
                "description": "View Equipment Requests"
            }
        }, {
            "id": null,
            "name": "View Equipment Catalog",
            "allowed": true,
            "permission": {
                "id": "5780177a768bbb531eecd256",
                "name": "View Equipment Catalog",
                "functionalArea": "Equipment_Request",
                "description": "View Equipment Catalog"
            }
        }],
        "roles": [],
        "functionalArea": "Equipment_Request",
        "description": "Responsible for maintenance of equipment at the service level"
    }, {
        "id": "57bf4a9d03e0fba04e9bba26",
        "name": "Service Equipment Facilities",
        "assignedPermissions": [{
            "id": null,
            "name": "Add Facility Weigh-Ins",
            "allowed": true,
            "permission": {
                "id": "57801466768bbb531eecd251",
                "name": "Add Facility Weigh-Ins",
                "functionalArea": "Equipment_Request",
                "description": "Add Facility Weigh-Ins"
            }
        }, {
            "id": null,
            "name": "View Equipment Requests",
            "allowed": true,
            "permission": {
                "id": "5780174e768bbb531eecd255",
                "name": "View Equipment Requests",
                "functionalArea": "Equipment_Request",
                "description": "View Equipment Requests"
            }
        }, {
            "id": null,
            "name": "View Equipment Catalog",
            "allowed": true,
            "permission": {
                "id": "5780177a768bbb531eecd256",
                "name": "View Equipment Catalog",
                "functionalArea": "Equipment_Request",
                "description": "View Equipment Catalog"
            }
        }],
        "roles": [],
        "functionalArea": "Equipment_Request",
        "description": "Responsible for providing equipment facilities at the service level"
    }, {
        "id": "57bf4ab803e0fba04e9bba27",
        "name": "Service Equipment Safety",
        "assignedPermissions": [{
            "id": null,
            "name": "Add Safety Weigh-Ins",
            "allowed": true,
            "permission": {
                "id": "578014b2768bbb531eecd254",
                "name": "Add Safety Weigh-Ins",
                "functionalArea": "Equipment_Request",
                "description": "Add Safety Weigh-Ins"
            }
        }, {
            "id": null,
            "name": "View Equipment Requests",
            "allowed": true,
            "permission": {
                "id": "5780174e768bbb531eecd255",
                "name": "View Equipment Requests",
                "functionalArea": "Equipment_Request",
                "description": "View Equipment Requests"
            }
        }, {
            "id": null,
            "name": "View Equipment Catalog",
            "allowed": true,
            "permission": {
                "id": "5780177a768bbb531eecd256",
                "name": "View Equipment Catalog",
                "functionalArea": "Equipment_Request",
                "description": "View Equipment Catalog"
            }
        }],
        "roles": [],
        "functionalArea": "Equipment_Request",
        "description": "Responsible for equipment safety at the service level"
    }, {
        "id": "57bf4ad903e0fba04e9bba28",
        "name": "DHA Equipment Manager",
        "assignedPermissions": [{
            "id": null,
            "name": "Submit Equipment Requests",
            "allowed": true,
            "permission": {
                "id": "57800e6f768bbb531eecd247",
                "name": "Submit Equipment Requests",
                "functionalArea": "Equipment_Request",
                "description": "Submit Equipment Requests"
            }
        }, {
            "id": null,
            "name": "Manage Equipment Requests",
            "allowed": true,
            "permission": {
                "id": "57801183768bbb531eecd24f",
                "name": "Manage Equipment Requests",
                "functionalArea": "Equipment_Request",
                "description": "Manage Equipment Requests"
            }
        }, {
            "id": null,
            "name": "View Equipment Records",
            "allowed": true,
            "permission": {
                "id": "57801870768bbb531eecd259",
                "name": "View Equipment Records",
                "functionalArea": "Equipment_Request",
                "description": "View Equipment Records"
            }
        }],
        "roles": [],
        "functionalArea": "Equipment_Request",
        "description": "Responsible for managing equipment at the DHA level"
    }, {
        "id": "57bf4af003e0fba04e9bba29",
        "name": "DHA Equipment Technologist",
        "assignedPermissions": [{
            "id": null,
            "name": "Add Technology Weigh-Ins",
            "allowed": true,
            "permission": {
                "id": "57801498768bbb531eecd253",
                "name": "Add Technology Weigh-Ins",
                "functionalArea": "Equipment_Request",
                "description": "Add Technology Weigh-Ins"
            }
        }, {
            "id": null,
            "name": "View Equipment Requests",
            "allowed": true,
            "permission": {
                "id": "5780174e768bbb531eecd255",
                "name": "View Equipment Requests",
                "functionalArea": "Equipment_Request",
                "description": "View Equipment Requests"
            }
        }, {
            "id": null,
            "name": "View Equipment Catalog",
            "allowed": true,
            "permission": {
                "id": "5780177a768bbb531eecd256",
                "name": "View Equipment Catalog",
                "functionalArea": "Equipment_Request",
                "description": "View Equipment Catalog"
            }
        }],
        "roles": [],
        "functionalArea": "Equipment_Request",
        "description": "Responsible for equipment technology at the DHA level"
    }, {
        "id": "57bf4b0b03e0fba04e9bba2a",
        "name": "DHA Equipment Maintenance",
        "assignedPermissions": [{
            "id": null,
            "name": "Add Maintenance Weigh-Ins",
            "allowed": true,
            "permission": {
                "id": "5780147e768bbb531eecd252",
                "name": "Add Maintenance Weigh-Ins",
                "functionalArea": "Equipment_Request",
                "description": "Add Maintenance Weigh-Ins"
            }
        }, {
            "id": null,
            "name": "View Equipment Requests",
            "allowed": true,
            "permission": {
                "id": "5780174e768bbb531eecd255",
                "name": "View Equipment Requests",
                "functionalArea": "Equipment_Request",
                "description": "View Equipment Requests"
            }
        }, {
            "id": null,
            "name": "View Equipment Catalog",
            "allowed": true,
            "permission": {
                "id": "5780177a768bbb531eecd256",
                "name": "View Equipment Catalog",
                "functionalArea": "Equipment_Request",
                "description": "View Equipment Catalog"
            }
        }],
        "roles": [],
        "functionalArea": "Equipment_Request",
        "description": "Responsible for maintenance of equipment at the DHA level"
    }, {
        "id": "57bf4b2203e0fba04e9bba2b",
        "name": "DHA Equipment Facilities",
        "assignedPermissions": [{
            "id": null,
            "name": "Add Facility Weigh-Ins",
            "allowed": true,
            "permission": {
                "id": "57801466768bbb531eecd251",
                "name": "Add Facility Weigh-Ins",
                "functionalArea": "Equipment_Request",
                "description": "Add Facility Weigh-Ins"
            }
        }, {
            "id": null,
            "name": "View Equipment Requests",
            "allowed": true,
            "permission": {
                "id": "5780174e768bbb531eecd255",
                "name": "View Equipment Requests",
                "functionalArea": "Equipment_Request",
                "description": "View Equipment Requests"
            }
        }, {
            "id": null,
            "name": "View Equipment Catalog",
            "allowed": true,
            "permission": {
                "id": "5780177a768bbb531eecd256",
                "name": "View Equipment Catalog",
                "functionalArea": "Equipment_Request",
                "description": "View Equipment Catalog"
            }
        }],
        "roles": [],
        "functionalArea": "Equipment_Request",
        "description": "Responsible for providing equipment facilities at the DHA level"
    }, {
        "id": "57bf4b4c03e0fba04e9bba2c",
        "name": "DHA Equipment Safety",
        "assignedPermissions": [{
            "id": null,
            "name": "Add Safety Weigh-Ins",
            "allowed": true,
            "permission": {
                "id": "578014b2768bbb531eecd254",
                "name": "Add Safety Weigh-Ins",
                "functionalArea": "Equipment_Request",
                "description": "Add Safety Weigh-Ins"
            }
        }, {
            "id": null,
            "name": "View Equipment Requests",
            "allowed": true,
            "permission": {
                "id": "5780174e768bbb531eecd255",
                "name": "View Equipment Requests",
                "functionalArea": "Equipment_Request",
                "description": "View Equipment Requests"
            }
        }, {
            "id": null,
            "name": "View Equipment Catalog",
            "allowed": true,
            "permission": {
                "id": "5780177a768bbb531eecd256",
                "name": "View Equipment Catalog",
                "functionalArea": "Equipment_Request",
                "description": "View Equipment Catalog"
            }
        }],
        "roles": [],
        "functionalArea": "Equipment_Request",
        "description": "Responsible for equipment safety at the DHA level"
    }];
    
    var roleOpts = [{
        "id": "57728d8d4c0868770213abd1",
        "name": "All Role",
        "selected": true
    }, {"id": "57800b36768bbb531eecd244", "name": "User Admin", "selected": false}, {
        "id": "57800ed6768bbb531eecd248",
        "name": "Site Equipment Custodian",
        "selected": false
    }, {
        "id": "57800f5d768bbb531eecd249",
        "name": "Site Equipment Manager",
        "selected": false
    }, {
        "id": "57800f96768bbb531eecd24a",
        "name": "Site Equipment Technologist",
        "selected": false
    }, {
        "id": "57800fba768bbb531eecd24b",
        "name": "Site Equipment Maintenance",
        "selected": false
    }, {
        "id": "57800fc5768bbb531eecd24c",
        "name": "Site Equipment Facilities",
        "selected": false
    }, {
        "id": "57800fe5768bbb531eecd24d",
        "name": "Site Equipment Safety",
        "selected": false
    }, {"id": "57801d01768bbb531eecd25a", "name": "JMAR", "selected": false}, {
        "id": "5784e3a3768bbb531eecd25b",
        "name": "Test Role",
        "selected": false
    }, {
        "id": "57bf493c03e0fba04e9bba1e",
        "name": "Regional Equipment Manager",
        "selected": false
    }, {
        "id": "57bf49ad03e0fba04e9bba1f",
        "name": "Regional Equipment Technologist",
        "selected": false
    }, {
        "id": "57bf49da03e0fba04e9bba20",
        "name": "Regional Equipment Maintenance",
        "selected": false
    }, {
        "id": "57bf4a1203e0fba04e9bba21",
        "name": "Regional Equipment Facilities",
        "selected": false
    }, {
        "id": "57bf4a3403e0fba04e9bba22",
        "name": "Regional Equipment Safety",
        "selected": false
    }, {
        "id": "57bf4a5303e0fba04e9bba23",
        "name": "Service Equipment Manager",
        "selected": false
    }, {
        "id": "57bf4a6e03e0fba04e9bba24",
        "name": "Service Equipment Technologist",
        "selected": false
    }, {
        "id": "57bf4a8403e0fba04e9bba25",
        "name": "Service Equipment Maintenance",
        "selected": false
    }, {
        "id": "57bf4a9d03e0fba04e9bba26",
        "name": "Service Equipment Facilities",
        "selected": false
    }, {
        "id": "57bf4ab803e0fba04e9bba27",
        "name": "Service Equipment Safety",
        "selected": false
    }, {
        "id": "57bf4ad903e0fba04e9bba28",
        "name": "DHA Equipment Manager",
        "selected": false
    }, {
        "id": "57bf4af003e0fba04e9bba29",
        "name": "DHA Equipment Technologist",
        "selected": false
    }, {
        "id": "57bf4b0b03e0fba04e9bba2a",
        "name": "DHA Equipment Maintenance",
        "selected": false
    }, {
        "id": "57bf4b2203e0fba04e9bba2b",
        "name": "DHA Equipment Facilities",
        "selected": false
    }, {"id": "57bf4b4c03e0fba04e9bba2c", "name": "DHA Equipment Safety", "selected": false}];

    var myUserProfileManagementService;

    beforeEach(() => {
        module('DmlesModule');
        module('Dmles.Home.Module');
        module('Dmles.AdminModule');
        module('Dmles.Admin.UserProfileManagementModule');
        module('Dmles.Admin.UserManagement.Views.Module');
        module('Dmles.Admin.RoleManagementModule');
        module('Dmles.UserAdmin.RoleManagement.Services.Module');

        inject(($rootScope, $controller, $state, StateConstants, RoleService, UserProfileService, UserProfileManagementService) => {

            spyOn(UserProfileManagementService, 'getUserProfile').and.callFake(() => {
                return userProfile;
            });
            myUserProfileManagementService = UserProfileManagementService;

            mock = {
                $scope: $rootScope.$new(),
                StateConstants: StateConstants,
                $state: $state,
                RoleService: RoleService,
                UserProfileService: UserProfileService,
                UserProfileManagementService: myUserProfileManagementService,
            };

            userProfileEditRolesController = $controller('Dmles.Admin.UserProfileManagement.Views.UserProfileEditRolesController', mock);
        });
    });

    it('Has scope', () => {
        expect(mock.$scope).not.toEqual(undefined);
    });

    it('Has a userProfileEditRolesController controller', () => {
        expect(userProfileEditRolesController).toBeDefined();
    });

    it('Has a controllerName variable', () => {
        expect(userProfileEditRolesController.controllerName).toBeDefined();
    });

    it('The controllerName variable has the correct value', () => {
        expect(userProfileEditRolesController.controllerName).toEqual("User Profile Edit Roles Controller");
    });

    it('The userProfileEditRoles controller loadRoleData function works - resolve path', () => {
        spyOn(userProfileEditRolesController, "loadRoleData").and.callThrough();
        spyOn(userProfileEditRolesController.RoleService, "getAllRoles").and.callFake(() => {
            return $.Deferred().resolve(allRolesResponse);
        });
        spyOn(userProfileEditRolesController, "sortAllRoles").and.callFake(() => {
            return $.Deferred().resolve(allRolesResponse.sort());
        });

        userProfileEditRolesController.loadRoleData();

        expect(userProfileEditRolesController.loadRoleData).toHaveBeenCalled();
        expect(userProfileEditRolesController.RoleService.getAllRoles).toHaveBeenCalled();
    });

    it('The userProfileEditRoles controller loadRoleData function works - reject path', () => {
        spyOn(userProfileEditRolesController, "loadRoleData").and.callThrough();
        spyOn(userProfileEditRolesController.RoleService, "getAllRoles").and.callFake(() => {
            return $.Deferred().reject();
        });

        userProfileEditRolesController.loadRoleData();

        expect(userProfileEditRolesController.loadRoleData).toHaveBeenCalled();
        expect(userProfileEditRolesController.RoleService.getAllRoles).toHaveBeenCalled();
    });

    it('The userProfileEditRoles controller sortAllRoles function works', () => {
        spyOn(userProfileEditRolesController, "sortAllRoles").and.callThrough();

        userProfileEditRolesController.sortAllRoles();

        expect(userProfileEditRolesController.sortAllRoles).toHaveBeenCalled();
    });

    it('The userProfileEditRoles controller onSubmit function works', () => {
        spyOn(userProfileEditRolesController, "onSubmit").and.callThrough();

        userProfileEditRolesController.userProfile = userProfile;
        userProfileEditRolesController.onSubmit();

        expect(userProfileEditRolesController.onSubmit).toHaveBeenCalled();
    });

    it('The userProfileEditRoles controller validateUserProfileRoles function works', () => {
        spyOn(userProfileEditRolesController, "validateUserProfileRoles").and.callThrough();

        userProfileEditRolesController.userProfile = userProfile;
        userProfileEditRolesController.roleOpts = roleOpts;
        userProfileEditRolesController.validateUserProfileRoles();

        expect(userProfileEditRolesController.validateUserProfileRoles).toHaveBeenCalled();
    });

    it('The userProfileEditRoles controller saveUserProfileRoles function works - resolve path', () => {
        spyOn(userProfileEditRolesController, "saveUserProfileRoles").and.callThrough();
        spyOn(userProfileEditRolesController.UserProfileService, "saveUserProfileRoles").and.callFake(() => {
            return $.Deferred().resolve(userProfile);
        });
        spyOn(userProfileEditRolesController.UserProfileManagementService, "setUserProfile").and.callThrough();
        spyOn(mock.$state, 'go');

        userProfileEditRolesController.saveUserProfileRoles(userProfile);

        expect(userProfileEditRolesController.saveUserProfileRoles).toHaveBeenCalled();
        expect(userProfileEditRolesController.UserProfileService.saveUserProfileRoles).toHaveBeenCalled();
        expect(userProfileEditRolesController.UserProfileManagementService.setUserProfile).toHaveBeenCalled();
        expect(mock.$state.go).toHaveBeenCalledWith(mock.StateConstants.ADMIN_USER_PROFILE_VIEW);
    });

    it('The userProfileEditRoles controller saveUserProfileRoles function works - reject path', () => {
        spyOn(userProfileEditRolesController, "saveUserProfileRoles").and.callThrough();
        spyOn(userProfileEditRolesController.UserProfileService, "saveUserProfileRoles").and.callFake(() => {
            return $.Deferred().reject();
        });

        userProfileEditRolesController.saveUserProfileRoles();

        expect(userProfileEditRolesController.saveUserProfileRoles).toHaveBeenCalled();
        expect(userProfileEditRolesController.UserProfileService.saveUserProfileRoles).toHaveBeenCalled();
    });

    it('The userProfileEditRoles controller validateUserProfile function works', () => {
        spyOn(userProfileEditRolesController, "validateUserProfile").and.callThrough();

        userProfileEditRolesController.roleOpts = roleOpts;
        userProfileEditRolesController.validateUserProfile("is required");

        expect(userProfileEditRolesController.validateUserProfile).toHaveBeenCalled();
    });

    it('The userProfileEditRoles controller retrieveRoleFromAllRoles function works', () => {
        spyOn(userProfileEditRolesController, "retrieveRoleFromAllRoles").and.callThrough();

        userProfileEditRolesController.allRoles = allRolesResponse;
        var returnValue = userProfileEditRolesController.retrieveRoleFromAllRoles("57728d8d4c0868770213abd1");

        expect(userProfileEditRolesController.retrieveRoleFromAllRoles).toHaveBeenCalled();
        expect(returnValue).toEqual({
            id: '57728d8d4c0868770213abd1',
            name: 'All Role',
            assignedPermissions: [Object({
                id: null,
                name: 'All Permissions',
                allowed: true,
                permission: Object({
                    id: '57728d844c08ed9af7596da7',
                    name: 'All Permissions',
                    functionalArea: 'Other',
                    description: 'All Permissions'
                })
            })],
            roles: [],
            functionalArea: 'Other',
            description: 'Role that contains all roles'
        });
    });

    it('The userProfileEditRoles controller buttonClicked function works', () => {
        spyOn(userProfileEditRolesController, "buttonClicked").and.callThrough();

        userProfileEditRolesController.buttonClicked();

        expect(userProfileEditRolesController.buttonClicked).toHaveBeenCalled();
    });


});

