import "../../../../../../src/module";
import "../../../../../../src/home/module";
import "../../../../../../src/home/admin/module";
import "../../../../../../src/home/admin/userProfileManagement/module";
import "../../../../../../src/home/admin/userProfileManagement/_services/module";
import "../../../../../../src/home/admin/userProfileManagement/_views/module";

describe('Admin UserProfileManagement _Views UserProfileView.Controller Tests', () => {
    var userProfileViewController;
    var mock;

    var userProfile = {
        "id": "5797741eb6c6b99956f06cc7",
        "registrationId": "5797741eb6c6b99956f06cc7",
        "userStatus": "ACTIVE",
        "email": "Forrest1@aol.com",
        "lastLoginDate": null,
        "firstName": "Forrest",
        "lastName": "Gump",
        "password": null,
        "pkiDn": null,
        "phoneNumbers": [
            {
                "phoneNumberType": "MOBILE",
                "value": "string"
            }
        ],
        "serviceCode": "string",
        "regionCode": "string",
        "profileName": "GLOBAL",
        "roles": [],
        "assignedPermissions": null,
        "userType": "GLOBAL",
        "dodaac": "string",
        "isDefault": false
    };

    var myUserProfileManagementService;

    beforeEach(() => {
        module('DmlesModule');
        // module('Dmles.Home.Module');
        module('Dmles.AdminModule');
        module('Dmles.Admin.UserProfileManagementModule');
        module('Dmles.Admin.UserManagement.Views.Module');

        inject(($rootScope, $controller, $state, StateConstants, UserProfileService, UserProfileManagementService) => {

            spyOn(UserProfileManagementService, 'getUserProfile').and.callFake(() => {
                return userProfile;
            });
            myUserProfileManagementService = UserProfileManagementService;

            mock = {
                $scope: $rootScope.$new(),
                StateConstants: StateConstants,
                $state: $state,
                UserProfileService: UserProfileService,
                UserProfileManagementService: myUserProfileManagementService,
            };

            userProfileViewController = $controller('Dmles.Admin.UserProfileManagement.Views.UserProfileViewController', mock);
        });
    });

    it('Has scope', () => {
        expect(mock.$scope).not.toEqual(undefined);
    });

    it('Has a userProfileViewController controller', () => {
        expect(userProfileViewController).toBeDefined();
    });

    it('Has a controllerName variable', () => {
        expect(userProfileViewController.controllerName).toBeDefined();
    });

    it('The controllerName variable has the correct value', () => {
        expect(userProfileViewController.controllerName).toEqual("User Profile View Controller");
    });

    it('The userProfileView controller activateUserProfile function works', () => {
        spyOn(userProfileViewController, "activateUserProfile").and.callThrough();
        userProfileViewController.activateUserProfile();
        expect(userProfileViewController.activateUserProfile).toHaveBeenCalled();
    });

    it('The userProfileView controller deactivateUserProfile function works', () => {
        spyOn(userProfileViewController, "deactivateUserProfile").and.callThrough();
        userProfileViewController.deactivateUserProfile();
        expect(userProfileViewController.deactivateUserProfile).toHaveBeenCalled();
    });

    it('The userProfileView controller saveUserProfileGeneralInfo function works', () => {
        spyOn(userProfileViewController, "saveUserProfileGeneralInfo").and.callThrough();
        userProfileViewController.saveUserProfileGeneralInfo();
        expect(userProfileViewController.saveUserProfileGeneralInfo).toHaveBeenCalled();
    });

    it('The userProfileView controller saveUserProfileGeneralInfo function works - resolve path', () => {
        spyOn(userProfileViewController, "saveUserProfileGeneralInfo").and.callThrough();
        spyOn(userProfileViewController.UserProfileService, "saveUserProfileData").and.callFake(() => {
            return $.Deferred().resolve(userProfile);
        });
        spyOn(userProfileViewController.UserProfileManagementService, "setUserProfile").and.callThrough();
        spyOn(userProfileViewController, "init").and.callThrough();
        spyOn(mock.$state, 'go');

        userProfileViewController.saveUserProfileGeneralInfo();

        expect(userProfileViewController.saveUserProfileGeneralInfo).toHaveBeenCalled();
        expect(userProfileViewController.UserProfileService.saveUserProfileData).toHaveBeenCalled();
        expect(userProfileViewController.UserProfileManagementService.setUserProfile).toHaveBeenCalled();
        expect(userProfileViewController.init).toHaveBeenCalled();
        expect(mock.$state.go).toHaveBeenCalledWith(mock.StateConstants.ADMIN_USER_PROFILE_VIEW);
    });

    it('The userProfileView controller saveUserProfileGeneralInfo function works - reject path', () => {
        spyOn(userProfileViewController, "saveUserProfileGeneralInfo").and.callThrough();
        spyOn(userProfileViewController.UserProfileService, "saveUserProfileData").and.callFake(() => {
            return $.Deferred().reject();
        });

        userProfileViewController.saveUserProfileGeneralInfo();

        expect(userProfileViewController.saveUserProfileGeneralInfo).toHaveBeenCalled();
        expect(userProfileViewController.UserProfileService.saveUserProfileData).toHaveBeenCalled();
    });

    it('The userProfileView controller approveUserProfile function works - resolve path', () => {
        spyOn(userProfileViewController, "approveUserProfile").and.callThrough();
        spyOn(userProfileViewController.UserProfileService, "approveUserProfile").and.callFake(() => {
            return $.Deferred().resolve(userProfile);
        });
        spyOn(userProfileViewController.UserProfileManagementService, "setUserProfile").and.callThrough();
        spyOn(userProfileViewController, "init").and.callThrough();
        spyOn(mock.$state, 'go');

        userProfileViewController.approveUserProfile();

        expect(userProfileViewController.approveUserProfile).toHaveBeenCalled();
        expect(userProfileViewController.UserProfileService.approveUserProfile).toHaveBeenCalled();
        expect(userProfileViewController.UserProfileManagementService.setUserProfile).toHaveBeenCalled();
        expect(userProfileViewController.init).toHaveBeenCalled();
        expect(mock.$state.go).toHaveBeenCalledWith(mock.StateConstants.ADMIN_USER_PROFILE_VIEW);
    });

    it('The userProfileView controller approveUserProfile function works - reject path', () => {
        spyOn(userProfileViewController, "approveUserProfile").and.callThrough();
        spyOn(userProfileViewController.UserProfileService, "approveUserProfile").and.callFake(() => {
            return $.Deferred().reject();
        });

        userProfileViewController.approveUserProfile();

        expect(userProfileViewController.approveUserProfile).toHaveBeenCalled();
        expect(userProfileViewController.UserProfileService.approveUserProfile).toHaveBeenCalled();
    });

    it('The userProfileView controller denyUserProfile function works - resolve path', () => {
        spyOn(userProfileViewController, "denyUserProfile").and.callThrough();
        spyOn(userProfileViewController.UserProfileService, "denyUserProfile").and.callFake(() => {
            return $.Deferred().resolve(userProfile);
        });
        spyOn(mock.$state, 'go');

        userProfileViewController.denyUserProfile();

        expect(userProfileViewController.denyUserProfile).toHaveBeenCalled();
        expect(userProfileViewController.UserProfileService.denyUserProfile).toHaveBeenCalled();
        expect(mock.$state.go).toHaveBeenCalledWith(mock.StateConstants.ADMIN_USER_PROFILE_MNG);
    });

    it('The userProfileView controller denyUserProfile function works - reject path', () => {
        spyOn(userProfileViewController, "denyUserProfile").and.callThrough();
        spyOn(userProfileViewController.UserProfileService, "denyUserProfile").and.callFake(() => {
            return $.Deferred().reject();
        });

        userProfileViewController.denyUserProfile();

        expect(userProfileViewController.denyUserProfile).toHaveBeenCalled();
        expect(userProfileViewController.UserProfileService.denyUserProfile).toHaveBeenCalled();
    });

    it('The userProfileView controller goToUserProfileAdmin function works', () => {
        spyOn(mock.$state, 'go');
        spyOn(userProfileViewController, "goToUserProfileAdmin").and.callThrough();

        userProfileViewController.goToUserProfileAdmin();

        expect(userProfileViewController.goToUserProfileAdmin).toHaveBeenCalled();
        expect(mock.$state.go).toHaveBeenCalledWith(mock.StateConstants.ADMIN_USER_PROFILE_MNG);
    });

    it('The userProfileView controller goToEditUserProfileGeneralInfo function works', () => {
        spyOn(mock.$state, 'go');
        spyOn(userProfileViewController, "goToEditUserProfileGeneralInfo").and.callThrough();

        userProfileViewController.goToEditUserProfileGeneralInfo();

        expect(userProfileViewController.goToEditUserProfileGeneralInfo).toHaveBeenCalled();
        expect(mock.$state.go).toHaveBeenCalledWith(mock.StateConstants.ADMIN_USER_PROFILE_EDIT_GEN_INFO);
    });

    it('The userProfileView controller goToEditUserProfileRoles function works', () => {
        spyOn(mock.$state, 'go');
        spyOn(userProfileViewController, "goToEditUserProfileRoles").and.callThrough();

        userProfileViewController.goToEditUserProfileRoles();

        expect(userProfileViewController.goToEditUserProfileRoles).toHaveBeenCalled();
        expect(mock.$state.go).toHaveBeenCalledWith(mock.StateConstants.ADMIN_USER_PROFILE_EDIT_ROLES);
    });

    it('The userProfileView controller goToEditUserProfilePermissions function works', () => {
        spyOn(mock.$state, 'go');
        spyOn(userProfileViewController, "goToEditUserProfilePermissions").and.callThrough();

        userProfileViewController.goToEditUserProfilePermissions();

        expect(userProfileViewController.goToEditUserProfilePermissions).toHaveBeenCalled();
        expect(mock.$state.go).toHaveBeenCalledWith(mock.StateConstants.ADMIN_USER_PROFILE_EDIT_PERMS);
    });
});

