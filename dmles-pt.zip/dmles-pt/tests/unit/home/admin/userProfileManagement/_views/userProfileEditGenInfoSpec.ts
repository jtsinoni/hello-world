import "../../../../../../src/module";
import "../../../../../../src/home/module";
import "../../../../../../src/home/admin/module";
import "../../../../../../src/home/admin/userProfileManagement/module";
import "../../../../../../src/home/admin/userProfileManagement/_services/module";
import "../../../../../../src/home/admin/userProfileManagement/_views/module";

describe('Admin UserProfileManagement _Views UserProfileEditGenInfo.Controller Tests', () => {
    var userProfileEditGenInfoController;
    var mock;

    var userProfile = {
        "id": "5797741eb6c6b99956f06cc7",
        "registrationId": "5797741eb6c6b99956f06cc7",
        "userStatus": "ACTIVE",
        "email": "Forrest1@aol.com",
        "lastLoginDate": null,
        "firstName": "Forrest",
        "lastName": "Gump",
        "password": null,
        "pkiDn": null,
        "phoneNumbers": [
            {
                "phoneNumberType": "MOBILE",
                "value": "string"
            }
        ],
        "serviceCode": "string",
        "regionCode": "string",
        "profileName": "GLOBAL",
        "roles": [],
        "assignedPermissions": null,
        "userType": "GLOBAL",
        "dodaac": "string",
        "isDefault": false
    };

    var myUserProfileManagementService;

    beforeEach(() => {
        module('DmlesModule');
        // module('Dmles.Home.Module');
        module('Dmles.AdminModule');
        module('Dmles.Admin.UserProfileManagementModule');
        module('Dmles.Admin.UserManagement.Views.Module');

        inject(($rootScope, $controller, $state, StateConstants, UserProfileService, UserProfileManagementService) => {

            spyOn(UserProfileManagementService, 'getUserProfile').and.callFake(() => {
                return userProfile;
            });
            myUserProfileManagementService = UserProfileManagementService;

            mock = {
                $scope: $rootScope.$new(),
                StateConstants: StateConstants,
                $state: $state,
                UserProfileService: UserProfileService,
                UserProfileManagementService: myUserProfileManagementService,
            };

            userProfileEditGenInfoController = $controller('Dmles.Admin.UserProfileManagement.Views.UserProfileEditGenInfoController', mock);
        });
    });

    it('Has scope', () => {
        expect(mock.$scope).not.toEqual(undefined);
    });

    it('Has a userProfileEditGenInfoController controller', () => {
        expect(userProfileEditGenInfoController).toBeDefined();
    });

    it('Has a controllerName variable', () => {
        expect(userProfileEditGenInfoController.controllerName).toBeDefined();
    });

    it('The controllerName variable has the correct value', () => {
        expect(userProfileEditGenInfoController.controllerName).toEqual("User Profile Edit General Information Controller");
    });

    it('The userProfileEditGenInfo controller onSubmit function works', () => {
        spyOn(userProfileEditGenInfoController, "onSubmit").and.callThrough();
        spyOn(mock.$state, 'go');

        userProfileEditGenInfoController.onSubmit();

        expect(userProfileEditGenInfoController.onSubmit).toHaveBeenCalled();
        expect(mock.$state.go).toHaveBeenCalledWith(mock.StateConstants.ADMIN_USER_PROFILE_VIEW);
    });

    it('The userProfileEditGenInfo controller saveUserProfileGeneralInfo function works - resolve path', () => {
        spyOn(userProfileEditGenInfoController, "saveUserProfileGeneralInfo").and.callThrough();
        spyOn(userProfileEditGenInfoController.UserProfileService, "saveUserProfileData").and.callFake(() => {
            return $.Deferred().resolve(userProfile);
        });
        spyOn(userProfileEditGenInfoController.UserProfileManagementService, "setUserProfile").and.callThrough();

        userProfileEditGenInfoController.saveUserProfileGeneralInfo();

        expect(userProfileEditGenInfoController.saveUserProfileGeneralInfo).toHaveBeenCalled();
        expect(userProfileEditGenInfoController.UserProfileService.saveUserProfileData).toHaveBeenCalled();
        expect(userProfileEditGenInfoController.UserProfileManagementService.setUserProfile).toHaveBeenCalled();
    });

    it('The userProfileEditGenInfo controller saveUserProfileGeneralInfo function works - reject path', () => {
        spyOn(userProfileEditGenInfoController, "saveUserProfileGeneralInfo").and.callThrough();
        spyOn(userProfileEditGenInfoController.UserProfileService, "saveUserProfileData").and.callFake(() => {
            return $.Deferred().reject();
        });

        userProfileEditGenInfoController.saveUserProfileGeneralInfo();

        expect(userProfileEditGenInfoController.saveUserProfileGeneralInfo).toHaveBeenCalled();
        expect(userProfileEditGenInfoController.UserProfileService.saveUserProfileData).toHaveBeenCalled();
    });
});

