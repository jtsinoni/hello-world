import "../../../../../../src/module";
import "../../../../../../src/home/module";
import "../../../../../../src/home/admin/module";
import "../../../../../../src/home/admin/userProfileManagement/module";
import "../../../../../../src/home/admin/userProfileManagement/_services/module";
import "../../../../../../src/home/admin/userProfileManagement/_views/module";

describe('Admin UserProfileManagement _Views UserProfileEditPermissions.Controller Tests', () => {
    var userProfileEditPermissionsController;
    var mock;

    var userProfile = {
        "id": "57b5eef2c6bfe067c5133935",
        "registrationId": "57b5eef2c6bfe067c5133935",
        "userStatus": "ACTIVE",
        "email": "cold@mail.mil",
        "lastLoginDate": 1472044028949,
        "firstName": "Patrick",
        "lastName": "Scarbrough",
        "password": null,
        "pkiDn": "cold.123",
        "phoneNumbers": [{"phoneNumberType": "WORK", "value": "301-123-COLD"}],
        "serviceCode": "DF",
        "regionCode": "AFGSC",
        "profileName": "SITE FM4528",
        "roles": [{
            "id": "57800b36768bbb531eecd244",
            "name": "User Admin",
            "assignedPermissions": [{
                "id": null,
                "name": "Manage User Profiles",
                "allowed": true,
                "permission": {
                    "id": "57800a1e768bbb531eecd243",
                    "name": "Manage User Profiles",
                    "functionalArea": "Administration",
                    "description": "Manage User Profiles"
                }
            }, {
                "id": null,
                "name": "Manage User Roles",
                "allowed": true,
                "permission": {
                    "id": "57800c60768bbb531eecd245",
                    "name": "Manage User Roles",
                    "functionalArea": "Administration",
                    "description": "Manage User Roles"
                }
            }],
            "roles": [],
            "functionalArea": "Administration",
            "description": "Responsible for administration of users",
            "$$hashKey": "object:834"
        }, {
            "id": "57801d01768bbb531eecd25a",
            "name": "JMAR",
            "assignedPermissions": [{
                "id": null,
                "name": "View JMAR Search",
                "allowed": true,
                "permission": {
                    "id": "5780183b768bbb531eecd258",
                    "name": "View JMAR Search",
                    "functionalArea": "Other",
                    "description": "View JMAR Search"
                }
            }],
            "roles": [],
            "functionalArea": "Other",
            "description": "Using DML-ES for coordination with JMAR",
            "$$hashKey": "object:835"
        }],
        "assignedPermissions": [{
            "id": null,
            "name": "Manage Permissions",
            "allowed": true,
            "permission": {
                "id": "57ade6a1a8ac2ac9a4fdc8dd",
                "name": "Manage Permissions",
                "functionalArea": "Administration",
                "description": "Manage Permissions"
            }
        }, {
            "id": null,
            "name": "Manage User Profiles",
            "allowed": true,
            "permission": {
                "id": "57800a1e768bbb531eecd243",
                "name": "Manage User Profiles",
                "functionalArea": "Administration",
                "description": "Manage User Profiles"
            }
        }, {
            "id": null,
            "name": "Manage User Roles",
            "allowed": true,
            "permission": {
                "id": "57800c60768bbb531eecd245",
                "name": "Manage User Roles",
                "functionalArea": "Administration",
                "description": "Manage User Roles"
            }
        }],
        "userType": "SITE",
        "dodaac": "FM4528",
        "current": true,
        "$$hashKey": "object:590"
    };

    var allPermissionsResponse = [{
        "functionalArea": "Administration",
        "permissions": [{
            "id": "57800a1e768bbb531eecd243",
            "name": "Manage User Profiles",
            "functionalArea": "Administration",
            "description": "Manage User Profiles"
        }, {
            "id": "57800c60768bbb531eecd245",
            "name": "Manage User Roles",
            "functionalArea": "Administration",
            "description": "Manage User Roles"
        }, {
            "id": "57ade6a1a8ac2ac9a4fdc8dd",
            "name": "Manage Permissions",
            "functionalArea": "Administration",
            "description": "Manage Permissions"
        }]
    }, {
        "functionalArea": "Equipment_Request",
        "permissions": [{
            "id": "57800e6f768bbb531eecd247",
            "name": "Submit Equipment Requests",
            "functionalArea": "Equipment_Request",
            "description": "Submit Equipment Requests"
        }, {
            "id": "57801183768bbb531eecd24f",
            "name": "Manage Equipment Requests",
            "functionalArea": "Equipment_Request",
            "description": "Manage Equipment Requests"
        }, {
            "id": "57801466768bbb531eecd251",
            "name": "Add Facility Weigh-Ins",
            "functionalArea": "Equipment_Request",
            "description": "Add Facility Weigh-Ins"
        }, {
            "id": "5780147e768bbb531eecd252",
            "name": "Add Maintenance Weigh-Ins",
            "functionalArea": "Equipment_Request",
            "description": "Add Maintenance Weigh-Ins"
        }, {
            "id": "57801498768bbb531eecd253",
            "name": "Add Technology Weigh-Ins",
            "functionalArea": "Equipment_Request",
            "description": "Add Technology Weigh-Ins"
        }, {
            "id": "578014b2768bbb531eecd254",
            "name": "Add Safety Weigh-Ins",
            "functionalArea": "Equipment_Request",
            "description": "Add Safety Weigh-Ins"
        }, {
            "id": "5780174e768bbb531eecd255",
            "name": "View Equipment Requests",
            "functionalArea": "Equipment_Request",
            "description": "View Equipment Requests"
        }, {
            "id": "5780177a768bbb531eecd256",
            "name": "View Equipment Catalog",
            "functionalArea": "Equipment_Request",
            "description": "View Equipment Catalog"
        }, {
            "id": "578017d5768bbb531eecd257",
            "name": "Create Equipment Requests From Catalog",
            "functionalArea": "Equipment_Request",
            "description": "Create Equipment Requests From Catalog"
        }, {
            "id": "57801870768bbb531eecd259",
            "name": "View Equipment Records",
            "functionalArea": "Equipment_Request",
            "description": "View Equipment Records"
        }]
    }, {
        "functionalArea": "Other",
        "permissions": [{
            "id": "57728d844c08ed9af7596da7",
            "name": "All Permissions",
            "functionalArea": "Other",
            "description": "All Permissions"
        }, {
            "id": "5780183b768bbb531eecd258",
            "name": "View JMAR Search",
            "functionalArea": "Other",
            "description": "View JMAR Search"
        }]
    }];
    var allPermissions = [{
        "id": "57800a1e768bbb531eecd243",
        "name": "Manage User Profiles",
        "functionalArea": "Administration",
        "description": "Manage User Profiles"
    }, {
        "id": "57800c60768bbb531eecd245",
        "name": "Manage User Roles",
        "functionalArea": "Administration",
        "description": "Manage User Roles"
    }, {
        "id": "57ade6a1a8ac2ac9a4fdc8dd",
        "name": "Manage Permissions",
        "functionalArea": "Administration",
        "description": "Manage Permissions"
    }, {
        "id": "57b21beeb6c6ace31a223cbe",
        "name": "View Equipment Records2asdf",
        "functionalArea": "ABC",
        "description": "View Equipment Recordsasdf"
    }, {
        "id": "57800e6f768bbb531eecd247",
        "name": "Submit Equipment Requests",
        "functionalArea": "Equipment_Request",
        "description": "Submit Equipment Requests"
    }, {
        "id": "57801183768bbb531eecd24f",
        "name": "Manage Equipment Requests",
        "functionalArea": "Equipment_Request",
        "description": "Manage Equipment Requests"
    }, {
        "id": "57801466768bbb531eecd251",
        "name": "Add Facility Weigh-Ins",
        "functionalArea": "Equipment_Request",
        "description": "Add Facility Weigh-Ins"
    }, {
        "id": "5780147e768bbb531eecd252",
        "name": "Add Maintenance Weigh-Ins",
        "functionalArea": "Equipment_Request",
        "description": "Add Maintenance Weigh-Ins"
    }, {
        "id": "57801498768bbb531eecd253",
        "name": "Add Technology Weigh-Ins",
        "functionalArea": "Equipment_Request",
        "description": "Add Technology Weigh-Ins"
    }, {
        "id": "578014b2768bbb531eecd254",
        "name": "Add Safety Weigh-Ins",
        "functionalArea": "Equipment_Request",
        "description": "Add Safety Weigh-Ins"
    }, {
        "id": "5780174e768bbb531eecd255",
        "name": "View Equipment Requests",
        "functionalArea": "Equipment_Request",
        "description": "View Equipment Requests"
    }, {
        "id": "5780177a768bbb531eecd256",
        "name": "View Equipment Catalog",
        "functionalArea": "Equipment_Request",
        "description": "View Equipment Catalog"
    }, {
        "id": "578017d5768bbb531eecd257",
        "name": "Create Equipment Requests From Catalog",
        "functionalArea": "Equipment_Request",
        "description": "Create Equipment Requests From Catalog"
    }, {
        "id": "57801870768bbb531eecd259",
        "name": "View Equipment Records",
        "functionalArea": "Equipment_Request",
        "description": "View Equipment Records"
    }, {
        "id": "57728d844c08ed9af7596da7",
        "name": "All Permissions",
        "functionalArea": "Other",
        "description": "All Permissions"
    }, {
        "id": "5780183b768bbb531eecd258",
        "name": "View JMAR Search",
        "functionalArea": "Other",
        "description": "View JMAR Search"
    }];

    var updatedAssignedPermissions = [{"id": null, "name": "View JMAR Search", "allowed": false, "denied": true}];

    var adminPermCollection = {
        "allPermOpts": [{
            "id": "57ade6a1a8ac2ac9a4fdc8dd",
            "name": "Manage Permissions",
            "allowed": false,
            "denied": false,
            "description": "Manage Permissions",
            "functionalArea": "Administration",
            "$$hashKey": "object:1827"
        }, {
            "id": "57800a1e768bbb531eecd243",
            "name": "Manage User Profiles",
            "allowed": false,
            "denied": false,
            "description": "Manage User Profiles",
            "functionalArea": "Administration",
            "$$hashKey": "object:1828"
        }, {
            "id": "57800c60768bbb531eecd245",
            "name": "Manage User Roles",
            "allowed": false,
            "denied": false,
            "description": "Manage User Roles",
            "functionalArea": "Administration",
            "$$hashKey": "object:1829"
        }], "displayName": "Admin"
    };
    var equipmentPermCollection = {
        "allPermOpts": [{
            "id": "57801466768bbb531eecd251",
            "name": "Add Facility Weigh-Ins",
            "allowed": false,
            "denied": false,
            "description": "Add Facility Weigh-Ins",
            "functionalArea": "Equipment_Request",
            "$$hashKey": "object:1836"
        }, {
            "id": "5780147e768bbb531eecd252",
            "name": "Add Maintenance Weigh-Ins",
            "allowed": false,
            "denied": false,
            "description": "Add Maintenance Weigh-Ins",
            "functionalArea": "Equipment_Request",
            "$$hashKey": "object:1837"
        }, {
            "id": "578014b2768bbb531eecd254",
            "name": "Add Safety Weigh-Ins",
            "allowed": false,
            "denied": false,
            "description": "Add Safety Weigh-Ins",
            "functionalArea": "Equipment_Request",
            "$$hashKey": "object:1838"
        }, {
            "id": "57801498768bbb531eecd253",
            "name": "Add Technology Weigh-Ins",
            "allowed": false,
            "denied": false,
            "description": "Add Technology Weigh-Ins",
            "functionalArea": "Equipment_Request",
            "$$hashKey": "object:1839"
        }, {
            "id": "578017d5768bbb531eecd257",
            "name": "Create Equipment Requests From Catalog",
            "allowed": false,
            "denied": false,
            "description": "Create Equipment Requests From Catalog",
            "functionalArea": "Equipment_Request",
            "$$hashKey": "object:1840"
        }, {
            "id": "57801183768bbb531eecd24f",
            "name": "Manage Equipment Requests",
            "allowed": false,
            "denied": false,
            "description": "Manage Equipment Requests",
            "functionalArea": "Equipment_Request",
            "$$hashKey": "object:1841"
        }, {
            "id": "57800e6f768bbb531eecd247",
            "name": "Submit Equipment Requests",
            "allowed": false,
            "denied": false,
            "description": "Submit Equipment Requests",
            "functionalArea": "Equipment_Request",
            "$$hashKey": "object:1842"
        }, {
            "id": "5780177a768bbb531eecd256",
            "name": "View Equipment Catalog",
            "allowed": false,
            "denied": false,
            "description": "View Equipment Catalog",
            "functionalArea": "Equipment_Request",
            "$$hashKey": "object:1843"
        }, {
            "id": "57801870768bbb531eecd259",
            "name": "View Equipment Records",
            "allowed": false,
            "denied": false,
            "description": "View Equipment Records",
            "functionalArea": "Equipment_Request",
            "$$hashKey": "object:1844"
        }, {
            "id": "5780174e768bbb531eecd255",
            "name": "View Equipment Requests",
            "allowed": false,
            "denied": false,
            "description": "View Equipment Requests",
            "functionalArea": "Equipment_Request",
            "$$hashKey": "object:1845"
        }], "displayName": "Equipment"
    };
    var otherPermCollection = {
        "allPermOpts": [{
            "id": "57728d844c08ed9af7596da7",
            "name": "All Permissions",
            "allowed": false,
            "denied": false,
            "description": "All Permissions",
            "functionalArea": "Other",
            "$$hashKey": "object:1856"
        }, {
            "id": "5780183b768bbb531eecd258",
            "name": "View JMAR Search",
            "allowed": false,
            "denied": true,
            "description": "View JMAR Search",
            "functionalArea": "Other",
            "$$hashKey": "object:1857"
        }], "displayName": "Other"
    };
    var myRoleManagementService;

    var myUserProfileManagementService;

    beforeEach(() => {
        module('DmlesModule');
        module('Dmles.Home.Module');
        module('Dmles.AdminModule');
        module('Dmles.Admin.UserProfileManagementModule');
        module('Dmles.Admin.UserManagement.Views.Module');
        module('Dmles.Admin.RoleManagementModule');
        module('Dmles.UserAdmin.RoleManagement.Services.Module');

        inject(($rootScope, $controller, $state, StateConstants, RoleService, RoleManagementService, UserProfileService, UserProfileManagementService) => {

            spyOn(UserProfileManagementService, 'getUserProfile').and.callFake(() => {
                return userProfile;
            });
            myUserProfileManagementService = UserProfileManagementService;

            spyOn(RoleManagementService, 'getAdminPermCollection').and.callFake(() => {
                return adminPermCollection;
            });
            spyOn(RoleManagementService, 'getEquipmentPermCollection').and.callFake(() => {
                return equipmentPermCollection;
            });
            spyOn(RoleManagementService, 'getOtherPermCollection').and.callFake(() => {
                return otherPermCollection;
            });
            myRoleManagementService = RoleManagementService;

            mock = {
                $scope: $rootScope.$new(),
                StateConstants: StateConstants,
                $state: $state,
                RoleService: RoleService,
                RoleManagementService: myRoleManagementService,
                UserProfileService: UserProfileService,
                UserProfileManagementService: myUserProfileManagementService,
            };

            userProfileEditPermissionsController = $controller('Dmles.Admin.UserProfileManagement.Views.UserProfileEditPermissionsController', mock);
        });
    });

    it('Has scope', () => {
        expect(mock.$scope).not.toEqual(undefined);
    });

    it('Has a userProfileEditPermissionsController controller', () => {
        expect(userProfileEditPermissionsController).toBeDefined();
    });

    it('Has a controllerName variable', () => {
        expect(userProfileEditPermissionsController.controllerName).toBeDefined();
    });

    it('The controllerName variable has the correct value', () => {
        expect(userProfileEditPermissionsController.controllerName).toEqual("User Profile Edit Permissions Controller");
    });

    it('The userProfileEditPermissions controller getAllPermissionsAndBuildPermissionCollections function works - resolve path', () => {
        spyOn(userProfileEditPermissionsController, "getAllPermissionsAndBuildPermissionCollections").and.callThrough();
        spyOn(userProfileEditPermissionsController.RoleService, "getAllPermissions").and.callFake(() => {
            return $.Deferred().resolve(allPermissionsResponse);
        });

        userProfileEditPermissionsController.getAllPermissionsAndBuildPermissionCollections();

        expect(userProfileEditPermissionsController.getAllPermissionsAndBuildPermissionCollections).toHaveBeenCalled();
        expect(userProfileEditPermissionsController.RoleService.getAllPermissions).toHaveBeenCalled();
    });

    it('The userProfileEditPermissions controller getAllPermissionsAndBuildPermissionCollections function works - reject path', () => {
        spyOn(userProfileEditPermissionsController, "getAllPermissionsAndBuildPermissionCollections").and.callThrough();
        spyOn(userProfileEditPermissionsController.RoleService, "getAllPermissions").and.callFake(() => {
            return $.Deferred().reject();
        });

        userProfileEditPermissionsController.getAllPermissionsAndBuildPermissionCollections();

        expect(userProfileEditPermissionsController.getAllPermissionsAndBuildPermissionCollections).toHaveBeenCalled();
        expect(userProfileEditPermissionsController.RoleService.getAllPermissions).toHaveBeenCalled();
    });

    it('The userProfileEditPermissions controller retrieveFieldValueFromAssignedPermissions function works', () => {
        spyOn(userProfileEditPermissionsController, "retrieveFieldValueFromAssignedPermissions").and.callThrough();

        userProfileEditPermissionsController.updatedAssignedPermissions = updatedAssignedPermissions;
        var returnValue = userProfileEditPermissionsController.retrieveFieldValueFromAssignedPermissions("View JMAR Search", "denied");

        expect(userProfileEditPermissionsController.retrieveFieldValueFromAssignedPermissions).toHaveBeenCalled();
        expect(returnValue).toBe(true);
    });

    it('The userProfileEditPermissions controller onSubmit function works', () => {
        spyOn(userProfileEditPermissionsController, "onSubmit").and.callThrough();
        spyOn(mock.$state, 'go');

        userProfileEditPermissionsController.onSubmit();

        expect(userProfileEditPermissionsController.onSubmit).toHaveBeenCalled();
        expect(mock.$state.go).toHaveBeenCalledWith(mock.StateConstants.ADMIN_USER_PROFILE_VIEW);
    });

    it('The userProfileEditPermissions controller getSelectedPerms function works', () => {
        spyOn(userProfileEditPermissionsController, "getSelectedPerms").and.callThrough();

        userProfileEditPermissionsController.getSelectedPerms();

        expect(userProfileEditPermissionsController.getSelectedPerms).toHaveBeenCalled();
    });

    it('The userProfileEditPermissions controller retrievePermissionFromAllPermissions function works', () => {
        spyOn(userProfileEditPermissionsController, "retrievePermissionFromAllPermissions").and.callThrough();

        userProfileEditPermissionsController.allPermissions = allPermissions;
        var returnValue = userProfileEditPermissionsController.retrievePermissionFromAllPermissions("57800a1e768bbb531eecd243");

        expect(userProfileEditPermissionsController.retrievePermissionFromAllPermissions).toHaveBeenCalled();
        expect(returnValue).toBeTruthy();
    });

    it('The userProfileEditPermissions controller saveUserProfilePermissions function works - resolve path', () => {
        spyOn(userProfileEditPermissionsController, "saveUserProfilePermissions").and.callThrough();
        spyOn(userProfileEditPermissionsController.UserProfileService, "saveUserProfilePermissions").and.callFake(() => {
            return $.Deferred().resolve(userProfile);
        });
        spyOn(userProfileEditPermissionsController.UserProfileManagementService, "setUserProfile").and.callThrough();

        userProfileEditPermissionsController.saveUserProfilePermissions();

        expect(userProfileEditPermissionsController.saveUserProfilePermissions).toHaveBeenCalled();
        expect(userProfileEditPermissionsController.UserProfileService.saveUserProfilePermissions).toHaveBeenCalled();
        expect(userProfileEditPermissionsController.UserProfileManagementService.setUserProfile).toHaveBeenCalled();
    });

    it('The userProfileEditPermissions controller saveUserProfilePermissions function works - reject path', () => {
        spyOn(userProfileEditPermissionsController, "saveUserProfilePermissions").and.callThrough();
        spyOn(userProfileEditPermissionsController.UserProfileService, "saveUserProfilePermissions").and.callFake(() => {
            return $.Deferred().reject();
        });

        userProfileEditPermissionsController.saveUserProfilePermissions();

        expect(userProfileEditPermissionsController.saveUserProfilePermissions).toHaveBeenCalled();
        expect(userProfileEditPermissionsController.UserProfileService.saveUserProfilePermissions).toHaveBeenCalled();
    });
});

