import "../../../../../../src/module";
import "../../../../../../src/home/module";
import "../../../../../../src/home/admin/module";
import "../../../../../../src/home/admin/userProfileManagement/module";
import "../../../../../../src/home/admin/userProfileManagement/_services/module";
import "../../../../../../src/home/admin/userProfileManagement/_views/module";

describe('Admin UserProfileManagement _Views Module Tests', () => {

    var mock;

    beforeEach(() => {
        module('DmlesModule');
        module('Dmles.Home.Module');
        module('Dmles.AdminModule');
        module('Dmles.Admin.UserProfileManagementModule');
        module('Dmles.Admin.UserManagement.Views.Module');
    });

    beforeEach(inject(($rootScope, $controller) => {
        mock = {
            $scope: $rootScope.$new(),
        };
    }));

    it('Has scope', () => {
        expect(mock.$scope).toBeDefined();
    });


});