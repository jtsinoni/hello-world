import "../../../../../../src/module";
import "../../../../../../src/home/module";
import "../../../../../../src/home/admin/module";
import "../../../../../../src/home/admin/roleManagement/module";
import "../../../../../../src/home/admin/roleManagement/_services/module";
import "../../../../../../src/home/admin/roleManagement/_views/module";

describe('Admin RoleManagement _Services Module Tests', () => {

    var mock;

    beforeEach(() => {
        module('DmlesModule');
        module('Dmles.Home.Module');
        module('Dmles.AdminModule');
        module('Dmles.Admin.RoleManagementModule');
        module('Dmles.UserAdmin.RoleManagement.Services.Module');
    });

    beforeEach(inject(($rootScope) => {
        mock = {
            $scope: $rootScope.$new(),
        };
    }));

    it('Has scope', () => {
        expect(mock.$scope).toBeDefined();
    });
});