import "../../../../../../src/module";
import "../../../../../../src/home/module";
import "../../../../../../src/home/admin/module";
import "../../../../../../src/home/admin/roleManagement/module";
import "../../../../../../src/home/admin/roleManagement/_services/module";
import "../../../../../../src/home/admin/roleManagement/_views/module";

describe('Admin RoleManagement _Views RoleManagement.Controller Tests', () => {
    var roleManagementController;
    var mock;

    var role = {
        "id": "57801d01768bbb531abcd33b",
        "name": "JMAR",
        "assignedPermissions": [{
            "id": null,
            "name": "View JMAR Search",
            "allowed": true,
            "permission": {
                "id": "5780183b768bbb531eecd258",
                "name": "View JMAR Search",
                "functionalArea": "Other",
                "description": "View JMAR Search"
            }
        }],
        "roles": [],
        "functionalArea": "Other",
        "description": "Using DML-ES for coordination with JMAR",
        "$$hashKey": "object:255"
    };

    beforeEach(() => {
        module('DmlesModule');
        module('Dmles.Home.Module');
        module('Dmles.AdminModule');
        module('Dmles.Admin.RoleManagementModule');
        module('Dmles.Admin.RoleManagement.Views.Module');

        inject(($rootScope, $controller, $q, $state, StateConstants, RoleService, RoleManagementService) => {
            mock = {
                $scope: $rootScope.$new(),
                StateConstants: StateConstants,
                RoleService: RoleService,
                RoleManagementService: RoleManagementService,
                deferred: $q.defer(),
                skip: $q.defer(),
                $state: $state
            };

            roleManagementController = $controller('Dmles.Admin.RoleManagement.Views.RoleManagementController', mock);
        });
    });

    it('Has scope', () => {
        expect(mock.$scope).not.toEqual(undefined);
    });

    it('Has a roleManagementController controller', () => {
        expect(roleManagementController).toBeDefined();
    });

    it('Has an Role Service', () => {
        expect(roleManagementController.RoleService).toBeDefined();
    });

    it('Has an RoleManagement Service', () => {
        expect(roleManagementController.RoleManagementService).toBeDefined();
    });

    it('The roleManagement controller goToRoleManagement function works', () => {
        spyOn(mock.$state, 'go');
        spyOn(roleManagementController, "goToRoleManagement").and.callThrough();

        roleManagementController.goToRoleManagement();

        expect(roleManagementController.goToRoleManagement).toHaveBeenCalled();
        expect(mock.$state.go).toHaveBeenCalledWith(mock.StateConstants.ADMIN_ROLE_MNG);
    });

    it('The roleManagement controller goToRoleView function works', () => {
        spyOn(mock.$state, 'go');
        spyOn(roleManagementController, "goToRoleView").and.callThrough();

        roleManagementController.goToRoleView();

        expect(roleManagementController.goToRoleView).toHaveBeenCalled();
        expect(mock.$state.go).toHaveBeenCalledWith(mock.StateConstants.ADMIN_ROLE_VIEW);
    });

    it('The roleManagement controller goToRoleCreate function works', () => {
        spyOn(mock.$state, 'go');
        spyOn(roleManagementController, "goToRoleCreate").and.callThrough();

        roleManagementController.goToRoleCreate();

        expect(roleManagementController.goToRoleCreate).toHaveBeenCalled();
        expect(mock.$state.go).toHaveBeenCalledWith(mock.StateConstants.ADMIN_ROLE_CREATE);
    });

    it('The roleManagement controller setRoleToBeDeleted function works', () => {
        spyOn(roleManagementController, "setRoleToBeDeleted").and.callThrough();

        roleManagementController.setRoleToBeDeleted(role);

        expect(roleManagementController.setRoleToBeDeleted).toHaveBeenCalled();
    });

    it('The roleManagement controller deleteRole function works - resolve path', () => {
        spyOn(roleManagementController, "deleteRole").and.callThrough();
        spyOn(roleManagementController.RoleService, "deleteRole").and.callFake(() => {
            return $.Deferred().resolve(role);
        });

        roleManagementController.roleToDelete = role;
        roleManagementController.deleteRole();

        expect(roleManagementController.deleteRole).toHaveBeenCalled();
        expect(roleManagementController.RoleService.deleteRole).toHaveBeenCalled();
    });

    it('The roleManagement controller deleteRole function works - reject path', () => {
        spyOn(roleManagementController, "deleteRole").and.callThrough();
        spyOn(roleManagementController.RoleService, "deleteRole").and.callFake(() => {
            return $.Deferred().reject();
        });

        roleManagementController.roleToDelete = role;
        roleManagementController.deleteRole();

        expect(roleManagementController.deleteRole).toHaveBeenCalled();
        expect(roleManagementController.RoleService.deleteRole).toHaveBeenCalled();
    });
});

