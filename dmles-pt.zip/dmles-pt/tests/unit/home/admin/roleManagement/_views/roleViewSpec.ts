import "../../../../../../src/module";
import "../../../../../../src/home/module";
import "../../../../../../src/home/admin/module";
import "../../../../../../src/home/admin/roleManagement/module";
import "../../../../../../src/home/admin/roleManagement/_services/module";
import "../../../../../../src/home/admin/roleManagement/_views/module";

describe('Admin RoleManagement _Views RoleView.Controller Tests', () => {
    var roleViewController;
    var mock;

    var role = {
        "id": "57801d01768bbb531abcd33b",
        "name": "JMAR",
        "assignedPermissions": [{
            "id": null,
            "name": "View JMAR Search",
            "allowed": true,
            "permission": {
                "id": "5780183b768bbb531eecd258",
                "name": "View JMAR Search",
                "functionalArea": "Other",
                "description": "View JMAR Search"
            }
        }],
        "roles": [],
        "functionalArea": "Other",
        "description": "Using DML-ES for coordination with JMAR",
        "$$hashKey": "object:255"
    };

    var myRoleManagementService;

    beforeEach(() => {
        module('DmlesModule');
        module('Dmles.Home.Module');
        module('Dmles.AdminModule');
        module('Dmles.Admin.RoleManagementModule');
        module('Dmles.Admin.RoleManagement.Views.Module');

        inject(($rootScope, $controller, $q, $state, StateConstants, RoleManagementService) => {

            spyOn(RoleManagementService, 'getRole').and.callFake(() => {
                return role;
            });
            myRoleManagementService = RoleManagementService;

            mock = {
                $scope: $rootScope.$new(),
                StateConstants: StateConstants,                
                RoleManagementService: myRoleManagementService,
                deferred: $q.defer(),
                skip: $q.defer(),
                $state: $state
            };

            roleViewController = $controller('Dmles.Admin.RoleManagement.Views.RoleViewController', mock);
        });
    });

    it('Has scope', () => {
        expect(mock.$scope).not.toEqual(undefined);
    });

    it('Has a roleView controller', () => {
        expect(roleViewController).toBeDefined();
    });

    it('Has an RoleManagement Service', () => {
        expect(roleViewController.RoleManagementService).toBeDefined();
    });

    it('The roleView controller goToRoleManagement function works', () => {
        spyOn(mock.$state, 'go');
        spyOn(roleViewController, "goToRoleManagement").and.callThrough();

        roleViewController.goToRoleManagement();

        expect(roleViewController.goToRoleManagement).toHaveBeenCalled();
        expect(mock.$state.go).toHaveBeenCalledWith(mock.StateConstants.ADMIN_ROLE_MNG);
    });

    it('The roleView controller goToEditRoleGeneralInfo function works', () => {
        spyOn(mock.$state, 'go');
        spyOn(roleViewController, "goToEditRoleGeneralInfo").and.callThrough();

        roleViewController.goToEditRoleGeneralInfo();

        expect(roleViewController.goToEditRoleGeneralInfo).toHaveBeenCalled();
        expect(mock.$state.go).toHaveBeenCalledWith(mock.StateConstants.ADMIN_ROLE_EDIT_GEN_INFO);
    });

    it('The roleView controller goToEditRolePermissions function works', () => {
        spyOn(mock.$state, 'go');
        spyOn(roleViewController, "goToEditRolePermissions").and.callThrough();

        roleViewController.goToEditRolePermissions();

        expect(roleViewController.goToEditRolePermissions).toHaveBeenCalled();
        expect(mock.$state.go).toHaveBeenCalledWith(mock.StateConstants.ADMIN_ROLE_EDIT_PERMS);
    });

    it('The roleView controller initializePermissions function works', () => {
        spyOn(roleViewController, "initializePermissions").and.callThrough();

        roleViewController.initializePermissions();

        expect(roleViewController.initializePermissions).toHaveBeenCalled();
    });   
});

