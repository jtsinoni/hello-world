import "../../../../../../src/module";
import "../../../../../../src/home/module";
import "../../../../../../src/home/admin/module";
import "../../../../../../src/home/admin/roleManagement/module";
import "../../../../../../src/home/admin/roleManagement/_services/module";
import "../../../../../../src/home/admin/roleManagement/_views/module";

describe('Admin RoleManagement _Views RoleEditGenInfo.Controller Tests', () => {
    var roleEditGenInfoController;
    var mock;

    var role = {
        "id": "57801d01768bbb531abcd33b",
        "name": "JMAR",
        "assignedPermissions": [{
            "id": null,
            "name": "View JMAR Search",
            "allowed": true,
            "permission": {
                "id": "5780183b768bbb531eecd258",
                "name": "View JMAR Search",
                "functionalArea": "Other",
                "description": "View JMAR Search"
            }
        }],
        "roles": [],
        "functionalArea": "Other",
        "description": "Using DML-ES for coordination with JMAR",
        "$$hashKey": "object:255"
    };

    var myRoleManagementService;

    beforeEach(() => {
        module('DmlesModule');
        module('Dmles.Home.Module');
        module('Dmles.AdminModule');
        module('Dmles.Admin.RoleManagementModule');
        module('Dmles.Admin.RoleManagement.Views.Module');

        inject(($rootScope, $controller, $q, $state, StateConstants, RoleService, RoleManagementService) => {

            spyOn(RoleManagementService, 'getRole').and.callFake(() => {
                return role;
            });
            myRoleManagementService = RoleManagementService;

            mock = {
                $scope: $rootScope.$new(),
                StateConstants: StateConstants,
                RoleService: RoleService,
                RoleManagementService: myRoleManagementService,
                deferred: $q.defer(),
                skip: $q.defer(),
                $state: $state
            };

            roleEditGenInfoController = $controller('Dmles.Admin.RoleManagement.Views.RoleEditGenInfoController', mock);
        });
    });

    it('Has scope', () => {
        expect(mock.$scope).not.toEqual(undefined);
    });

    it('Has a roleEditGenInfo controller', () => {
        expect(roleEditGenInfoController).toBeDefined();
    });    

    it('Has an Role Service', () => {
        expect(roleEditGenInfoController.RoleService).toBeDefined();
    });

    it('Has an RoleManagement Service', () => {
        expect(roleEditGenInfoController.RoleManagementService).toBeDefined();
    });

    it('The roleEditGenInfo controller onSubmit function works', () => {
        spyOn(mock.$state, 'go');
        spyOn(roleEditGenInfoController, "onSubmit").and.callThrough();

        roleEditGenInfoController.role = role;
        roleEditGenInfoController.onSubmit();

        expect(roleEditGenInfoController.onSubmit).toHaveBeenCalled();
        expect(mock.$state.go).toHaveBeenCalledWith(mock.StateConstants.ADMIN_ROLE_VIEW);
    });

    it('The roleEditGenInfo controller saveRoleGeneralInfo function works - resolve path', () => {
        spyOn(roleEditGenInfoController, "saveRoleGeneralInfo").and.callThrough();
        spyOn(roleEditGenInfoController.RoleService, "saveRoleData").and.callFake(() => {
            return $.Deferred().resolve(role);
        });

        roleEditGenInfoController.saveRoleGeneralInfo();

        expect(roleEditGenInfoController.saveRoleGeneralInfo).toHaveBeenCalled();
        expect(roleEditGenInfoController.RoleService.saveRoleData).toHaveBeenCalled();
    });

    it('The roleEditGenInfo controller createRole function works - reject path', () => {
        spyOn(roleEditGenInfoController, "saveRoleGeneralInfo").and.callThrough();
        spyOn(roleEditGenInfoController.RoleService, "saveRoleData").and.callFake(() => {
            return $.Deferred().reject();
        });

        roleEditGenInfoController.saveRoleGeneralInfo();

        expect(roleEditGenInfoController.saveRoleGeneralInfo).toHaveBeenCalled();
        expect(roleEditGenInfoController.RoleService.saveRoleData).toHaveBeenCalled();
    });
});

