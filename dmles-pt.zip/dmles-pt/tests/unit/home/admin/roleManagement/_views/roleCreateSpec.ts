import "../../../../../../src/module";
import "../../../../../../src/home/module";
import "../../../../../../src/home/admin/module";
import "../../../../../../src/home/admin/roleManagement/module";
import "../../../../../../src/home/admin/roleManagement/_services/module";
import "../../../../../../src/home/admin/roleManagement/_views/module";

describe('Admin RoleManagement _Views RoleCreate.Controller Tests', () => {
    var roleCreateController;
    var mock;

    var role = {
        "id": "57801d01768bbb531abcd33b",
        "name": "JMAR",
        "assignedPermissions": [{
            "id": null,
            "name": "View JMAR Search",
            "allowed": true,
            "permission": {
                "id": "5780183b768bbb531eecd258",
                "name": "View JMAR Search",
                "functionalArea": "Other",
                "description": "View JMAR Search"
            }
        }],
        "roles": [],
        "functionalArea": "Other",
        "description": "Using DML-ES for coordination with JMAR",
        "$$hashKey": "object:255"
    };

    var allPermissionsResponse = [{
        "functionalArea": "Administration",
        "permissions": [{
            "id": "57800a1e768bbb531eecd243",
            "name": "Manage User Profiles",
            "functionalArea": "Administration",
            "description": "Manage User Profiles"
        }, {
            "id": "57800c60768bbb531eecd245",
            "name": "Manage User Roles",
            "functionalArea": "Administration",
            "description": "Manage User Roles"
        }, {
            "id": "57ade6a1a8ac2ac9a4fdc8dd",
            "name": "Manage Permissions",
            "functionalArea": "Administration",
            "description": "Manage Permissions"
        }]
    }, {
        "functionalArea": "Equipment_Request",
        "permissions": [{
            "id": "57800e6f768bbb531eecd247",
            "name": "Submit Equipment Requests",
            "functionalArea": "Equipment_Request",
            "description": "Submit Equipment Requests"
        }, {
            "id": "57801183768bbb531eecd24f",
            "name": "Manage Equipment Requests",
            "functionalArea": "Equipment_Request",
            "description": "Manage Equipment Requests"
        }, {
            "id": "57801466768bbb531eecd251",
            "name": "Add Facility Weigh-Ins",
            "functionalArea": "Equipment_Request",
            "description": "Add Facility Weigh-Ins"
        }, {
            "id": "5780147e768bbb531eecd252",
            "name": "Add Maintenance Weigh-Ins",
            "functionalArea": "Equipment_Request",
            "description": "Add Maintenance Weigh-Ins"
        }, {
            "id": "57801498768bbb531eecd253",
            "name": "Add Technology Weigh-Ins",
            "functionalArea": "Equipment_Request",
            "description": "Add Technology Weigh-Ins"
        }, {
            "id": "578014b2768bbb531eecd254",
            "name": "Add Safety Weigh-Ins",
            "functionalArea": "Equipment_Request",
            "description": "Add Safety Weigh-Ins"
        }, {
            "id": "5780174e768bbb531eecd255",
            "name": "View Equipment Requests",
            "functionalArea": "Equipment_Request",
            "description": "View Equipment Requests"
        }, {
            "id": "5780177a768bbb531eecd256",
            "name": "View Equipment Catalog",
            "functionalArea": "Equipment_Request",
            "description": "View Equipment Catalog"
        }, {
            "id": "578017d5768bbb531eecd257",
            "name": "Create Equipment Requests From Catalog",
            "functionalArea": "Equipment_Request",
            "description": "Create Equipment Requests From Catalog"
        }, {
            "id": "57801870768bbb531eecd259",
            "name": "View Equipment Records",
            "functionalArea": "Equipment_Request",
            "description": "View Equipment Records"
        }]
    }, {
        "functionalArea": "Other",
        "permissions": [{
            "id": "57728d844c08ed9af7596da7",
            "name": "All Permissions",
            "functionalArea": "Other",
            "description": "All Permissions"
        }, {
            "id": "5780183b768bbb531eecd258",
            "name": "View JMAR Search",
            "functionalArea": "Other",
            "description": "View JMAR Search"
        }]
    }];
    var allPermissions = [{
        "id": "57800a1e768bbb531eecd243",
        "name": "Manage User Profiles",
        "functionalArea": "Administration",
        "description": "Manage User Profiles"
    }, {
        "id": "57800c60768bbb531eecd245",
        "name": "Manage User Roles",
        "functionalArea": "Administration",
        "description": "Manage User Roles"
    }, {"id": "57ade6a1a8ac2ac9a4fdc8dd", "name": "Manage Permissions", "functionalArea": "Administration", "description": "Manage Permissions"}, {
        "id": "57b21beeb6c6ace31a223cbe",
        "name": "View Equipment Records2asdf",
        "functionalArea": "ABC",
        "description": "View Equipment Recordsasdf"
    }, {"id": "57800e6f768bbb531eecd247", "name": "Submit Equipment Requests", "functionalArea": "Equipment_Request", "description": "Submit Equipment Requests"}, {
        "id": "57801183768bbb531eecd24f",
        "name": "Manage Equipment Requests",
        "functionalArea": "Equipment_Request",
        "description": "Manage Equipment Requests"
    }, {
        "id": "57801466768bbb531eecd251",
        "name": "Add Facility Weigh-Ins",
        "functionalArea": "Equipment_Request",
        "description": "Add Facility Weigh-Ins"
    }, {
        "id": "5780147e768bbb531eecd252",
        "name": "Add Maintenance Weigh-Ins",
        "functionalArea": "Equipment_Request",
        "description": "Add Maintenance Weigh-Ins"
    }, {
        "id": "57801498768bbb531eecd253",
        "name": "Add Technology Weigh-Ins",
        "functionalArea": "Equipment_Request",
        "description": "Add Technology Weigh-Ins"
    }, {
        "id": "578014b2768bbb531eecd254",
        "name": "Add Safety Weigh-Ins",
        "functionalArea": "Equipment_Request",
        "description": "Add Safety Weigh-Ins"
    }, {
        "id": "5780174e768bbb531eecd255",
        "name": "View Equipment Requests",
        "functionalArea": "Equipment_Request",
        "description": "View Equipment Requests"
    }, {
        "id": "5780177a768bbb531eecd256",
        "name": "View Equipment Catalog",
        "functionalArea": "Equipment_Request",
        "description": "View Equipment Catalog"
    }, {
        "id": "578017d5768bbb531eecd257",
        "name": "Create Equipment Requests From Catalog",
        "functionalArea": "Equipment_Request",
        "description": "Create Equipment Requests From Catalog"
    }, {
        "id": "57801870768bbb531eecd259",
        "name": "View Equipment Records",
        "functionalArea": "Equipment_Request",
        "description": "View Equipment Records"
    }, {
        "id": "57728d844c08ed9af7596da7",
        "name": "All Permissions",
        "functionalArea": "Other",
        "description": "All Permissions"
    }, {
        "id": "5780183b768bbb531eecd258",
        "name": "View JMAR Search",
        "functionalArea": "Other",
        "description": "View JMAR Search"
    }];

    var adminPermCollection = {
        "allPermOpts": [{
            "id": "57ade6a1a8ac2ac9a4fdc8dd",
            "name": "Manage Permissions",
            "allowed": false,
            "denied": false,
            "description": "Manage Permissions",
            "functionalArea": "Administration",
            "$$hashKey": "object:1827"
        }, {
            "id": "57800a1e768bbb531eecd243",
            "name": "Manage User Profiles",
            "allowed": false,
            "denied": false,
            "description": "Manage User Profiles",
            "functionalArea": "Administration",
            "$$hashKey": "object:1828"
        }, {
            "id": "57800c60768bbb531eecd245",
            "name": "Manage User Roles",
            "allowed": false,
            "denied": false,
            "description": "Manage User Roles",
            "functionalArea": "Administration",
            "$$hashKey": "object:1829"
        }], "displayName": "Admin"
    };
    var equipmentPermCollection = {
        "allPermOpts": [{
            "id": "57801466768bbb531eecd251",
            "name": "Add Facility Weigh-Ins",
            "allowed": false,
            "denied": false,
            "description": "Add Facility Weigh-Ins",
            "functionalArea": "Equipment_Request",
            "$$hashKey": "object:1836"
        }, {
            "id": "5780147e768bbb531eecd252",
            "name": "Add Maintenance Weigh-Ins",
            "allowed": false,
            "denied": false,
            "description": "Add Maintenance Weigh-Ins",
            "functionalArea": "Equipment_Request",
            "$$hashKey": "object:1837"
        }, {
            "id": "578014b2768bbb531eecd254",
            "name": "Add Safety Weigh-Ins",
            "allowed": false,
            "denied": false,
            "description": "Add Safety Weigh-Ins",
            "functionalArea": "Equipment_Request",
            "$$hashKey": "object:1838"
        }, {
            "id": "57801498768bbb531eecd253",
            "name": "Add Technology Weigh-Ins",
            "allowed": false,
            "denied": false,
            "description": "Add Technology Weigh-Ins",
            "functionalArea": "Equipment_Request",
            "$$hashKey": "object:1839"
        }, {
            "id": "578017d5768bbb531eecd257",
            "name": "Create Equipment Requests From Catalog",
            "allowed": false,
            "denied": false,
            "description": "Create Equipment Requests From Catalog",
            "functionalArea": "Equipment_Request",
            "$$hashKey": "object:1840"
        }, {
            "id": "57801183768bbb531eecd24f",
            "name": "Manage Equipment Requests",
            "allowed": false,
            "denied": false,
            "description": "Manage Equipment Requests",
            "functionalArea": "Equipment_Request",
            "$$hashKey": "object:1841"
        }, {
            "id": "57800e6f768bbb531eecd247",
            "name": "Submit Equipment Requests",
            "allowed": false,
            "denied": false,
            "description": "Submit Equipment Requests",
            "functionalArea": "Equipment_Request",
            "$$hashKey": "object:1842"
        }, {
            "id": "5780177a768bbb531eecd256",
            "name": "View Equipment Catalog",
            "allowed": false,
            "denied": false,
            "description": "View Equipment Catalog",
            "functionalArea": "Equipment_Request",
            "$$hashKey": "object:1843"
        }, {
            "id": "57801870768bbb531eecd259",
            "name": "View Equipment Records",
            "allowed": false,
            "denied": false,
            "description": "View Equipment Records",
            "functionalArea": "Equipment_Request",
            "$$hashKey": "object:1844"
        }, {
            "id": "5780174e768bbb531eecd255",
            "name": "View Equipment Requests",
            "allowed": false,
            "denied": false,
            "description": "View Equipment Requests",
            "functionalArea": "Equipment_Request",
            "$$hashKey": "object:1845"
        }], "displayName": "Equipment"
    };
    var otherPermCollection = {
        "allPermOpts": [{
            "id": "57728d844c08ed9af7596da7",
            "name": "All Permissions",
            "allowed": false,
            "denied": false,
            "description": "All Permissions",
            "functionalArea": "Other",
            "$$hashKey": "object:1856"
        }, {
            "id": "5780183b768bbb531eecd258",
            "name": "View JMAR Search",
            "allowed": false,
            "denied": true,
            "description": "View JMAR Search",
            "functionalArea": "Other",
            "$$hashKey": "object:1857"
        }], "displayName": "Other"
    };    

    var myRoleManagementService;

    beforeEach(() => {
        module('DmlesModule');
        module('Dmles.Home.Module');
        module('Dmles.AdminModule');
        module('Dmles.Admin.RoleManagementModule');
        module('Dmles.Admin.RoleManagement.Views.Module');

        inject(($rootScope, $controller, $q, $state, StateConstants, RoleService, RoleManagementService) => {

            spyOn(RoleManagementService, 'getRole').and.callFake(() => {
                return role;
            });
            spyOn(RoleManagementService, 'getAdminPermCollection').and.callFake(() => {
                return adminPermCollection;
            });
            spyOn(RoleManagementService, 'getEquipmentPermCollection').and.callFake(() => {
                return equipmentPermCollection;
            });
            spyOn(RoleManagementService, 'getOtherPermCollection').and.callFake(() => {
                return otherPermCollection;
            });
            myRoleManagementService = RoleManagementService;

            mock = {
                $scope: $rootScope.$new(),
                StateConstants: StateConstants,
                RoleService: RoleService,
                RoleManagementService: myRoleManagementService,
                deferred: $q.defer(),
                skip: $q.defer(),
                $state: $state
            };

            roleCreateController = $controller('Dmles.Admin.RoleManagement.Views.RoleCreateController', mock);
        });
    });

    it('Has scope', () => {
        expect(mock.$scope).not.toEqual(undefined);
    });

    it('Has a roleCreate controller', () => {
        expect(roleCreateController).toBeDefined();
    });

    it('Has an Role Service', () => {
        expect(roleCreateController.RoleService).toBeDefined();
    });

    it('Has an RoleManagement Service', () => {
        expect(roleCreateController.RoleManagementService).toBeDefined();
    });

    it('The roleCreate controller goToRoleManagement function works', () => {
        spyOn(mock.$state, 'go');
        spyOn(roleCreateController, "goToRoleManagement").and.callThrough();

        roleCreateController.goToRoleManagement();

        expect(roleCreateController.goToRoleManagement).toHaveBeenCalled();
        expect(mock.$state.go).toHaveBeenCalledWith(mock.StateConstants.ADMIN_ROLE_MNG);
    });

    it('The roleCreate controller getAllPermissionsAndBuildPermissionCollections function works - resolve path', () => {
        spyOn(roleCreateController, "getAllPermissionsAndBuildPermissionCollections").and.callThrough();
        spyOn(roleCreateController.RoleService, "getAllPermissions").and.callFake(() => {
            return $.Deferred().resolve(allPermissionsResponse);
        });

        roleCreateController.getAllPermissionsAndBuildPermissionCollections();

        expect(roleCreateController.getAllPermissionsAndBuildPermissionCollections).toHaveBeenCalled();
        expect(roleCreateController.RoleService.getAllPermissions).toHaveBeenCalled();
    });

    it('The roleCreate controller getAllPermissionsAndBuildPermissionCollections function works - reject path', () => {
        spyOn(roleCreateController, "getAllPermissionsAndBuildPermissionCollections").and.callThrough();
        spyOn(roleCreateController.RoleService, "getAllPermissions").and.callFake(() => {
            return $.Deferred().reject();
        });

        roleCreateController.getAllPermissionsAndBuildPermissionCollections();

        expect(roleCreateController.getAllPermissionsAndBuildPermissionCollections).toHaveBeenCalled();
        expect(roleCreateController.RoleService.getAllPermissions).toHaveBeenCalled();
    });

    it('The roleCreate controller onSubmit function works', () => {
        spyOn(roleCreateController, "onSubmit").and.callThrough();

        roleCreateController.role = role;
        roleCreateController.onSubmit();

        expect(roleCreateController.onSubmit).toHaveBeenCalled();
    });

    it('The roleCreate controller onSubmit function handles an incomplete role', () => {
        var incompleteRole = {
            "id": "57801d01768bbb531abcd33b",
            "name": "JMAR",
            "assignedPermissions": [{
                "id": null,
                "name": "View JMAR Search",
                "allowed": true,
                "permission": {
                    "id": "5780183b768bbb531eecd258",
                    "name": "View JMAR Search",
                    "functionalArea": "Other",
                    "description": "View JMAR Search"
                }
            }],
            "roles": [],
            "description": "Using DML-ES for coordination with JMAR",
            "$$hashKey": "object:255"
        };  // no functionalArea

        spyOn(roleCreateController, "onSubmit").and.callThrough();

        roleCreateController.role = incompleteRole;
        roleCreateController.onSubmit();

        expect(roleCreateController.onSubmit).toHaveBeenCalled();
    });

    it('The roleCreate controller isPermSelected function returns true when a permission has been selected', () => {
        spyOn(roleCreateController, "isPermSelected").and.callThrough();

        expect(roleCreateController.isPermSelected()).toBe(true);
    });

    it('The roleCreate controller isPermSelected function returns false when a permission has not been selected', () => {
        var otherPermCollectionWithNoPermsSelected = {
            "allPermOpts": [{
                "id": "57728d844c08ed9af7596da7",
                "name": "All Permissions",
                "allowed": false,
                "denied": false,
                "description": "All Permissions",
                "functionalArea": "Other",
                "$$hashKey": "object:1856"
            }, {
                "id": "5780183b768bbb531eecd258",
                "name": "View JMAR Search",
                "allowed": false,
                "denied": false,
                "description": "View JMAR Search",
                "functionalArea": "Other",
                "$$hashKey": "object:1857"
            }], "displayName": "Other"
        };

        // change the return value of the existing global spy - to "reset" it
        roleCreateController.RoleManagementService.getOtherPermCollection.and.callFake(() => {
            return otherPermCollectionWithNoPermsSelected;
        });

        expect(roleCreateController.isPermSelected()).toBe(false);
    });

    it('The roleCreate controller getSelectedPerms function works', () => {
        spyOn(roleCreateController, "getSelectedPerms").and.callThrough();

        roleCreateController.getSelectedPerms();

        expect(roleCreateController.getSelectedPerms).toHaveBeenCalled();
    });

    it('The roleCreate controller retrievePermissionFromAllPermissions function works', () => {
        spyOn(roleCreateController, "retrievePermissionFromAllPermissions").and.callThrough();

        roleCreateController.allPermissions = allPermissions;
        var returnValue = roleCreateController.retrievePermissionFromAllPermissions("57800a1e768bbb531eecd243");

        expect(roleCreateController.retrievePermissionFromAllPermissions).toHaveBeenCalled();
        expect(returnValue).toBeTruthy();
    });

    it('The roleCreate controller createRole function works - resolve path', () => {
        spyOn(mock.$state, 'go');
        spyOn(roleCreateController, "createRole").and.callThrough();
        spyOn(roleCreateController.RoleService, "createRole").and.callFake(() => {
            return $.Deferred().resolve(role);
        });
        
        roleCreateController.createRole(role);

        expect(roleCreateController.createRole).toHaveBeenCalled();
        expect(roleCreateController.RoleService.createRole).toHaveBeenCalled();
        expect(mock.$state.go).toHaveBeenCalledWith(mock.StateConstants.ADMIN_ROLE_MNG);
    });

    it('The roleCreate controller createRole function works - reject path', () => {
        spyOn(roleCreateController, "createRole").and.callThrough();
        spyOn(roleCreateController.RoleService, "createRole").and.callFake(() => {
            return $.Deferred().reject();
        });
       
        roleCreateController.createRole(role);

        expect(roleCreateController.createRole).toHaveBeenCalled();
        expect(roleCreateController.RoleService.createRole).toHaveBeenCalled();
    });
});

