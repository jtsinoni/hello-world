import "../../../../../../src/module";
import "../../../../../../src/home/module";
import "../../../../../../src/home/admin/module";
import "../../../../../../src/home/admin/roleManagement/module";
import "../../../../../../src/home/admin/roleManagement/_directives/module";
import "../../../../../../src/home/admin/roleManagement/_services/module";
import "../../../../../../src/home/admin/roleManagement/_views/module";

describe('Admin RoleManagement _Directives PermSelection Directive Tests', () => {

    var compile, scope, directiveElem;

    var adminPermCollection = {
        "allPermOpts": [{
            "id": "57ade6a1a8ac2ac9a4fdc8dd",
            "name": "Manage Permissions",
            "allowed": false,
            "denied": false,
            "description": "Manage Permissions",
            "functionalArea": "Administration",
            "$$hashKey": "object:1827"
        }, {
            "id": "57800a1e768bbb531eecd243",
            "name": "Manage User Profiles",
            "allowed": false,
            "denied": false,
            "description": "Manage User Profiles",
            "functionalArea": "Administration",
            "$$hashKey": "object:1828"
        }, {
            "id": "57800c60768bbb531eecd245",
            "name": "Manage User Roles",
            "allowed": false,
            "denied": false,
            "description": "Manage User Roles",
            "functionalArea": "Administration",
            "$$hashKey": "object:1829"
        }], "displayName": "Admin"
    };

    beforeEach(function(){
        module('DmlesModule');
        module('Dmles.Home.Module');
        module('Dmles.AdminModule');
        module('Dmles.Admin.RoleManagementModule');
        module('Dmles.Admin.UserManagement.Views.Module');
        module('Dmles.UserAdmin.RoleManagement.Services.Module');
        module('Dmles.UserAdmin.RoleManagement.DirectivesModule');

        inject(function($compile, $rootScope, RoleManagementService){
            compile = $compile;
            scope = $rootScope.$new();
            scope.collection = adminPermCollection;
            scope.controller = RoleManagementService;
            scope.viewOnly = true;
        });

        directiveElem = getCompiledElement();
    });

    function getCompiledElement(){
        var element = 
            angular.element('<dmles-perm-selection collection=adminPermCollection controller=RoleManagementService view-only=true></dmles-perm-selection>');
        var compiledElement = compile(element)(scope);
        scope.$digest();
        return compiledElement;
    }

});
