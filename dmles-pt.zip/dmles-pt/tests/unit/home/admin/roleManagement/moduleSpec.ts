import "../../../../../src/module";
import "../../../../../src/home/module";
import "../../../../../src/home/admin/module";
import "../../../../../src/home/admin/roleManagement/module";

describe('Admin Role Management Module Tests', () => {

    beforeEach(() => {
        module('DmlesModule');
        module('Dmles.Home.Module');
        module('Dmles.AdminModule');
        module('Dmles.Admin.RoleManagementModule');
    });

    var scope;

    beforeEach(inject(($rootScope) => {
        scope = $rootScope.$new();
    }));

    it('Has scope', () => {
        expect(scope).toBeDefined();
    });
});