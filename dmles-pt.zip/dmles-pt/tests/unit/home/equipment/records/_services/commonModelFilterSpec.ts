import "../../../../../../src/module";
import "../../../../../../src/home/module";
import "../../../../../../src/home/equipment/module";
import "../../../../../../src/home/equipment/records/module";
import "../../../../../../src/home/equipment/records/_services/module";
import "../../../../../../src/home/equipment/records/_views/module";

describe('Equipment Records _Services CommonModelFilter Service Tests', () => {

    beforeEach(() => {
        module('DmlesModule');
        module('Dmles.Home.Module');
        module('Dmles.Equipment.Module');
        module('Dmles.Home.Equipment.Records.RecordsModule');
        module('Dmles.Home.Equipment.Records.Views.Module');
        module('Dmles.Home.Equipment.Records.Services.Module');
    });

    it('Has an commonModelFilter Service', inject((CommonModelFilterService) => {
        expect( CommonModelFilterService ).toBeDefined();
    }));

    it('The commonModelFilter Service has a label', inject((CommonModelFilterService) => {
        expect(CommonModelFilterService.label).toBeDefined();
    }));

    it("The commonModelFilter Service label has the correct value", inject((CommonModelFilterService) => {
        expect(CommonModelFilterService.label).toMatch(" Common Model");
    }));

    it("The commonModelFilter Service reset function causes the initialize function to be called", inject((CommonModelFilterService) => {
        spyOn(CommonModelFilterService, 'initialize');
        CommonModelFilterService.reset();
        expect(CommonModelFilterService.initialize).toHaveBeenCalled();
    }));    
});

