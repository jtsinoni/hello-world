import "../../../../../../src/module";
import "../../../../../../src/home/module";
import "../../../../../../src/home/equipment/module";
import "../../../../../../src/home/equipment/records/module";
import "../../../../../../src/home/equipment/records/_services/module";
import "../../../../../../src/home/equipment/records/_views/module";

describe('Equipment Records _Services Module Tests', () => {
    var AcquisitionCostFilterService;
    var AcquisitionDateRangeFilterService;
    var CommonModelFilterService;
    var CustodianNameFilterService;
    var CustomerNameFilterService;
    var CustomerOrgIdFilterService;
    var DetailsPaginationService;
    var EcnFilterService;
    var EquipmentRecordService;
    var EquipmentStatusFilterService;
    var ItemIdFilterService;
    var ManufacturerFilterService;
    var NomenclatureFilterService;
    var OrgIdFilterService;
    var RecordsApi;

    var mock;

    beforeEach(() => {
        module('DmlesModule');
        module('Dmles.Home.Module');
        module('Dmles.Equipment.Module');
        module('Dmles.Home.Equipment.Records.RecordsModule');
        module('Dmles.Home.Equipment.Records.Services.Module');

    });

    beforeEach(inject((_AcquisitionCostFilterService_,
                       _AcquisitionDateRangeFilterService_,
                       _CommonModelFilterService_,
                       _CustodianNameFilterService_,
                       _CustomerNameFilterService_,
                       _CustomerOrgIdFilterService_,
                       _DetailsPaginationService_,
                       _EcnFilterService_,
                       _EquipmentRecordService_,
                       _EquipmentStatusFilterService_,
                       _ItemIdFilterService_,
                       _ManufacturerFilterService_,
                       _NomenclatureFilterService_,
                       _OrgIdFilterService_,
                       _RecordsApi_) => {

        AcquisitionCostFilterService = _AcquisitionCostFilterService_;
        AcquisitionDateRangeFilterService = _AcquisitionDateRangeFilterService_;
        CommonModelFilterService = _CommonModelFilterService_;
        CustodianNameFilterService = _CustodianNameFilterService_;
        CustomerNameFilterService = _CustomerNameFilterService_;
        CustomerOrgIdFilterService = _CustomerOrgIdFilterService_;
        DetailsPaginationService = _DetailsPaginationService_;
        EcnFilterService = _EcnFilterService_;
        EquipmentRecordService = _EquipmentRecordService_;
        EquipmentStatusFilterService = _EquipmentStatusFilterService_;
        ItemIdFilterService = _ItemIdFilterService_;
        ManufacturerFilterService = _ManufacturerFilterService_;
        NomenclatureFilterService = _NomenclatureFilterService_;
        OrgIdFilterService = _OrgIdFilterService_;
        RecordsApi = _RecordsApi_;

    }));

    it('Has an AcquisitionCostFilter Service', () => {
        expect(AcquisitionCostFilterService).toBeDefined();
    });

    it('Has an AcquisitionDateRangeFilter Service', () => {
        expect(AcquisitionDateRangeFilterService).toBeDefined();
    });

    it('Has an CommonModelFilter Service', () => {
        expect(CommonModelFilterService).toBeDefined();
    });

    it('Has an CustodianNameFilter Service', () => {
        expect(CustodianNameFilterService).toBeDefined();
    });

    it('Has an CustomerNameFilter Service', () => {
        expect(CustomerNameFilterService).toBeDefined();
    });

    it('Has an CustomerOrgIdFilter Service', () => {
        expect(CustomerOrgIdFilterService).toBeDefined();
    });

    it('Has an DetailsPagination Service', () => {
        expect(DetailsPaginationService).toBeDefined();
    });

    it('Has an EcnFilter Service', () => {
        expect(EcnFilterService).toBeDefined();
    });

    it('Has an EquipmentRecord Service', () => {
        expect(EquipmentRecordService).toBeDefined();
    });

    it('Has an EquipmentStatusFilter Service', () => {
        expect(EquipmentStatusFilterService).toBeDefined();
    });

    it('Has an ItemIdFilter Service', () => {
        expect(ItemIdFilterService).toBeDefined();
    });

    it('Has an ManufacturerFilter Service', () => {
        expect(ManufacturerFilterService).toBeDefined();
    });

    it('Has an NomenclatureFilter Service', () => {
        expect(NomenclatureFilterService).toBeDefined();
    });

    it('Has an OrgIdFilter Service', () => {
        expect(OrgIdFilterService).toBeDefined();
    });

    it('Has an RecordsApi service', () => {
        expect(RecordsApi).toBeDefined();
    });
});