import "../../../../../../src/module";
import "../../../../../../src/home/module";
import "../../../../../../src/home/equipment/module";
import "../../../../../../src/home/equipment/records/module";
import "../../../../../../src/home/equipment/records/_services/module";
import "../../../../../../src/home/equipment/records/_views/module";

describe('Equipment Records _Services CustomerOrgIdFilter Service Tests', () => {

    beforeEach(() => {
        module('DmlesModule');
        module('Dmles.Home.Module');
        module('Dmles.Equipment.Module');
        module('Dmles.Home.Equipment.Records.RecordsModule');
        module('Dmles.Home.Equipment.Records.Views.Module');
        module('Dmles.Home.Equipment.Records.Services.Module');
    });

    it('Has an customerOrgIdFilter Service', inject((CustomerOrgIdFilterService) => {
        expect( CustomerOrgIdFilterService ).toBeDefined();
    }));

    it('The customerOrgIdFilter Service has a label', inject((CustomerOrgIdFilterService) => {
        expect(CustomerOrgIdFilterService.label).toBeDefined();
    }));

    it("The customerOrgIdFilter Service label has the correct value", inject((CustomerOrgIdFilterService) => {
        expect(CustomerOrgIdFilterService.label).toMatch(" Customer Org ID");
    }));

    it("The customerOrgIdFilter Service reset function causes the initialize function to be called", inject((CustomerOrgIdFilterService) => {
        spyOn(CustomerOrgIdFilterService, 'initialize');
        CustomerOrgIdFilterService.reset();
        expect(CustomerOrgIdFilterService.initialize).toHaveBeenCalled();
    }));    
});

