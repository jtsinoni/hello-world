import "../../../../../../src/module";
import "../../../../../../src/home/module";
import "../../../../../../src/home/equipment/module";
import "../../../../../../src/home/equipment/records/module";
import "../../../../../../src/home/equipment/records/_services/module";
import "../../../../../../src/home/equipment/records/_views/module";

describe('Equipment Records _Services OrgIdFilter Service Tests', () => {

    beforeEach(() => {
        module('DmlesModule');
        module('Dmles.Home.Module');
        module('Dmles.Equipment.Module');
        module('Dmles.Home.Equipment.Records.RecordsModule');
        module('Dmles.Home.Equipment.Records.Views.Module');
        module('Dmles.Home.Equipment.Records.Services.Module');
    });

    it('Has an orgIdFilter Service', inject((OrgIdFilterService) => {
        expect( OrgIdFilterService ).toBeDefined();
    }));

    it('The orgIdFilter Service has a label', inject((OrgIdFilterService) => {
        expect(OrgIdFilterService.label).toBeDefined();
    }));

    it("The orgIdFilter Service label has the correct value", inject((OrgIdFilterService) => {
        expect(OrgIdFilterService.label).toMatch(" Org ID");
    }));

    it("The orgIdFilter Service reset function causes the initialize function to be called", inject((OrgIdFilterService) => {
        spyOn(OrgIdFilterService, 'initialize');
        OrgIdFilterService.reset();
        expect(OrgIdFilterService.initialize).toHaveBeenCalled();
    }));    
});

