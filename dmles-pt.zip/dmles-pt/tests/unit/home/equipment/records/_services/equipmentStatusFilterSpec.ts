import "../../../../../../src/module";
import "../../../../../../src/home/module";
import "../../../../../../src/home/equipment/module";
import "../../../../../../src/home/equipment/records/module";
import "../../../../../../src/home/equipment/records/_services/module";
import "../../../../../../src/home/equipment/records/_views/module";

describe('Equipment Records _Services EquipmentStatusFilter Service Tests', () => {

    beforeEach(() => {
        module('DmlesModule');
        module('Dmles.Home.Module');
        module('Dmles.Equipment.Module');
        module('Dmles.Home.Equipment.Records.RecordsModule');
        module('Dmles.Home.Equipment.Records.Views.Module');
        module('Dmles.Home.Equipment.Records.Services.Module');
    });

    it('Has an equipmentStatusFilter Service', inject((EquipmentStatusFilterService) => {
        expect( EquipmentStatusFilterService ).toBeDefined();
    }));

    it('The equipmentStatusFilter Service has a label', inject((EquipmentStatusFilterService) => {
        expect(EquipmentStatusFilterService.label).toBeDefined();
    }));

    it("The equipmentStatusFilter Service label has the correct value", inject((EquipmentStatusFilterService) => {
        expect(EquipmentStatusFilterService.label).toMatch(" Equipment Status");
    }));

    it("The equipmentStatusFilter Service reset function causes the initialize function to be called", inject((EquipmentStatusFilterService) => {
        spyOn(EquipmentStatusFilterService, 'initialize');
        EquipmentStatusFilterService.reset();
        expect(EquipmentStatusFilterService.initialize).toHaveBeenCalled();
    }));

    it("The equipmentStatusFilter Service reset then buildSearchClause function, when booleanValue = true, returns the expected value", inject((EquipmentStatusFilterService) => {
        EquipmentStatusFilterService.reset();
        expect(EquipmentStatusFilterService.buildSearchClause()).toEqual('(deleteInd:N)');
    }));

    it("The equipmentStatusFilter Service buildSearchClause function, when booleanValue = false, returns the expected value", inject((EquipmentStatusFilterService) => {
        EquipmentStatusFilterService.reset();
        EquipmentStatusFilterService. booleanValue = false;
        expect(EquipmentStatusFilterService.buildSearchClause()).toEqual('(deleteInd:Y)');
    }));   

    it("The equipmentStatusFilter Service process function, when booleanValue = true, returns the expected value", inject((EquipmentStatusFilterService) => {
        EquipmentStatusFilterService.reset();        
        EquipmentStatusFilterService.process();
        expect(EquipmentStatusFilterService.valueSelected).toEqual([{selValue: 'Active'}]);
    }));

    it("The equipmentStatusFilter Service process function, when booleanValue = false, returns the expected value", inject((EquipmentStatusFilterService) => {
        EquipmentStatusFilterService.reset();
        EquipmentStatusFilterService. booleanValue = false;
        EquipmentStatusFilterService.process();
        expect(EquipmentStatusFilterService.valueSelected).toEqual([{selValue: 'Inactive'}]);
    }));
});

