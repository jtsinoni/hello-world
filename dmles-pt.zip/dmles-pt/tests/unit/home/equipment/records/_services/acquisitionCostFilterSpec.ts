import "../../../../../../src/module";
import "../../../../../../src/home/module";
import "../../../../../../src/home/equipment/module";
import "../../../../../../src/home/equipment/records/module";
import "../../../../../../src/home/equipment/records/_services/module";
import "../../../../../../src/home/equipment/records/_views/module";

describe('Equipment Records _Services AcquisitionCostFilter.Service Tests', () => {

    beforeEach(module('Dmles.Home.Equipment.Records.Services.Module'));

    it('Has an acquisitionCostFilter Service', inject((AcquisitionCostFilterService) => {
        expect( AcquisitionCostFilterService ).toBeDefined();
    }));

    it('The acquisitionCostFilter Service has a label', inject((AcquisitionCostFilterService) => {
        expect(AcquisitionCostFilterService.label).toBeDefined();
    }));

    it("The acquisitionCostFilter Service label has the correct value", inject((AcquisitionCostFilterService) => {
        expect(AcquisitionCostFilterService.label).toMatch(" Acquisition Cost");
    }));

    it("The acquisitionCostFilter Service reset function causes the initialize function to be called", inject((AcquisitionCostFilterService) => {
        spyOn(AcquisitionCostFilterService, 'initialize');
        AcquisitionCostFilterService.reset();
        expect(AcquisitionCostFilterService.initialize).toHaveBeenCalled();
    }));

    it("The acquisitionCostFilter Service reset then buildSearchClause function returns the expected value", inject((AcquisitionCostFilterService) => {
        AcquisitionCostFilterService.reset();
        expect(AcquisitionCostFilterService.buildSearchClause()).toEqual("");
    }));

    it("The acquisitionCostFilter Service buildSearchClause function with 0 to hugeNumber input returns the expected value", inject((AcquisitionCostFilterService) => {
        AcquisitionCostFilterService.reset();
        AcquisitionCostFilterService.userMin = 0;
        AcquisitionCostFilterService.userMax = 100000000000;
        expect(AcquisitionCostFilterService.buildSearchClause()).toEqual('');
    }));

    it("The acquisitionCostFilter Service buildSearchClause function with 0 to 10 input returns the expected value", inject((AcquisitionCostFilterService) => {
        AcquisitionCostFilterService.reset();
        AcquisitionCostFilterService.userMin = 0;
        AcquisitionCostFilterService.userMax = 10;
        expect(AcquisitionCostFilterService.buildSearchClause()).toEqual('meAcqCostQty:[* TO 10]');
    }));

    it("The acquisitionCostFilter Service buildSearchClause function with 5 to hugeNumber input returns the expected value", inject((AcquisitionCostFilterService) => {
        AcquisitionCostFilterService.reset();
        AcquisitionCostFilterService.userMin = 5;
        AcquisitionCostFilterService.userMax = 100000000000;
        expect(AcquisitionCostFilterService.buildSearchClause()).toEqual('meAcqCostQty:[5 TO *]');
    }));

    it("The acquisitionCostFilter Service buildSearchClause function with 5 to 1000 input returns the expected value", inject((AcquisitionCostFilterService) => {
        AcquisitionCostFilterService.reset();
        AcquisitionCostFilterService.userMin = 5;
        AcquisitionCostFilterService.userMax = 1000;
        expect(AcquisitionCostFilterService.buildSearchClause()).toEqual('meAcqCostQty:[5 TO 1000]');
    }));

    it("The acquisitionCostFilter Service process function returns the expected value", inject((AcquisitionCostFilterService) => {
        AcquisitionCostFilterService.reset();
        AcquisitionCostFilterService.process();
        expect(AcquisitionCostFilterService.userMinValue).toEqual([{ selValue: 0 }]);
        expect(AcquisitionCostFilterService.userMaxValue).toEqual([{ selValue: 100000000000 }]);
    }));

    it("The acquisitionCostFilter Service processRange function with Any Cost input returns the expected value", inject((AcquisitionCostFilterService) => {
        AcquisitionCostFilterService.reset();
        AcquisitionCostFilterService.rangeValue = "Any Cost";
        AcquisitionCostFilterService.processRange();
        expect(AcquisitionCostFilterService.userMin).toEqual(0);
        expect(AcquisitionCostFilterService.userMax).toEqual(100000000000);
    }));

    it("The acquisitionCostFilter Service processRange function with $0 - $500 input returns the expected value", inject((AcquisitionCostFilterService) => {
        AcquisitionCostFilterService.reset();
        AcquisitionCostFilterService.rangeValue = "$0 - $500";
        AcquisitionCostFilterService.processRange();
        expect(AcquisitionCostFilterService.userMin).toEqual(0);
        expect(AcquisitionCostFilterService.userMax).toEqual(500);
    }));

    it("The acquisitionCostFilter Service processRange function with $0 - $2,500 input returns the expected value", inject((AcquisitionCostFilterService) => {
        AcquisitionCostFilterService.reset();
        AcquisitionCostFilterService.rangeValue = "$0 - $2,500";
        AcquisitionCostFilterService.processRange();
        expect(AcquisitionCostFilterService.userMin).toEqual(0);
        expect(AcquisitionCostFilterService.userMax).toEqual(2500);
    }));

    it("The acquisitionCostFilter Service processRange function with More than $2500 input returns the expected value", inject((AcquisitionCostFilterService) => {
        AcquisitionCostFilterService.reset();
        AcquisitionCostFilterService.rangeValue = "More than $2500";
        AcquisitionCostFilterService.processRange();
        expect(AcquisitionCostFilterService.userMin).toEqual(2500);
        expect(AcquisitionCostFilterService.userMax).toEqual(100000000000);
    }));

    it("The acquisitionCostFilter Service processRange function with user specified $1000 - $2,500,000 input returns the expected value", inject((AcquisitionCostFilterService) => {
        AcquisitionCostFilterService.reset();
        AcquisitionCostFilterService.rangeValue = "$1000 - $2500000";
        AcquisitionCostFilterService.rangeOptions[4] = "$1000 - $2500000";
        AcquisitionCostFilterService.userSpecifiedMin = 1000;
        AcquisitionCostFilterService.userSpecifiedMax = 2500000;
        AcquisitionCostFilterService.processRange();
        expect(AcquisitionCostFilterService.userMin).toEqual(1000);
        expect(AcquisitionCostFilterService.userMax).toEqual(2500000);
    }));

    it("The acquisitionCostFilter Service processRange function with user specified blank - $2,500,000 input returns the expected value", inject((AcquisitionCostFilterService) => {
        AcquisitionCostFilterService.reset();
        AcquisitionCostFilterService.rangeValue = " - $2500000";
        AcquisitionCostFilterService.rangeOptions[4] = " - $2500000";
        AcquisitionCostFilterService.userSpecifiedMin = null;
        AcquisitionCostFilterService.userSpecifiedMax = 2500000;
        AcquisitionCostFilterService.processRange();
        expect(AcquisitionCostFilterService.userMin).toEqual(0);
        expect(AcquisitionCostFilterService.userMax).toEqual(2500000);
    }));

    it("The acquisitionCostFilter Service processRange function with user specified $1000 - blank input returns the expected value", inject((AcquisitionCostFilterService) => {
        AcquisitionCostFilterService.reset();
        AcquisitionCostFilterService.rangeValue = "$1000 - ";
        AcquisitionCostFilterService.rangeOptions[4] = "$1000 - ";
        AcquisitionCostFilterService.userSpecifiedMin = 1000;
        AcquisitionCostFilterService.userSpecifiedMax = null;
        AcquisitionCostFilterService.processRange();
        expect(AcquisitionCostFilterService.userMin).toEqual(1000);
        expect(AcquisitionCostFilterService.userMax).toEqual(100000000000);
    }));
});

