import "../../../../../../src/module";
import "../../../../../../src/home/module";
import "../../../../../../src/home/equipment/module";
import "../../../../../../src/home/equipment/records/module";
import "../../../../../../src/home/equipment/records/_services/module";
import "../../../../../../src/home/equipment/records/_views/module";

describe('Equipment Records _Services NomenclatureFilter Service Tests', () => {

    beforeEach(() => {
        module('DmlesModule');
        module('Dmles.Home.Module');
        module('Dmles.Equipment.Module');
        module('Dmles.Home.Equipment.Records.RecordsModule');
        module('Dmles.Home.Equipment.Records.Views.Module');
        module('Dmles.Home.Equipment.Records.Services.Module');
    });

    it('Has an nomenclatureFilter Service', inject((NomenclatureFilterService) => {
        expect( NomenclatureFilterService ).toBeDefined();
    }));

    it('The nomenclatureFilter Service has a label', inject((NomenclatureFilterService) => {
        expect(NomenclatureFilterService.label).toBeDefined();
    }));

    it("The nomenclatureFilter Service label has the correct value", inject((NomenclatureFilterService) => {
        expect(NomenclatureFilterService.label).toMatch(" Nomenclature");
    }));

    it("The nomenclatureFilter Service reset function causes the initialize function to be called", inject((NomenclatureFilterService) => {
        spyOn(NomenclatureFilterService, 'initialize');
        NomenclatureFilterService.reset();
        expect(NomenclatureFilterService.initialize).toHaveBeenCalled();
    }));    
});

