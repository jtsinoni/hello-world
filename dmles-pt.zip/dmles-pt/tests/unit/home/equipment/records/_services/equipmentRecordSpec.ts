import "../../../../../../src/module";
import "../../../../../../src/home/module";
import "../../../../../../src/home/equipment/module";
import "../../../../../../src/home/equipment/records/module";
import "../../../../../../src/home/equipment/records/_services/module";
import "../../../../../../src/home/equipment/records/_views/module";

describe('Equipment Records _Services EquipmentRecord Service Tests', () => {

    beforeEach(() => {
        module('DmlesModule');
        module('Dmles.Home.Module');
        module('Dmles.Equipment.Module');
        module('Dmles.Home.Equipment.Records.RecordsModule');
        module('Dmles.Home.Equipment.Records.Views.Module');
        module('Dmles.Home.Equipment.Records.Services.Module');
    });

    it('Has an equipmentRecord Service', inject((EquipmentRecordService) => {
        expect(EquipmentRecordService).toBeDefined();
    }));

    it('The equipmentRecord Service has a serviceName', inject((EquipmentRecordService) => {
        expect(EquipmentRecordService.serviceName).toBeDefined();
    }));

    it("The equipmentRecord Service serviceName has the correct value", inject((EquipmentRecordService) => {
        expect(EquipmentRecordService.serviceName).toMatch("EquipmentRecord Service");
    }));

    it("The equipmentRecord Service getSearchStats function, with no result, returns the expected value", inject((EquipmentRecordService) => {
        var result = "";

        spyOn(EquipmentRecordService, "getSearchStats").and.callThrough();
        EquipmentRecordService.getSearchStats(result);

        expect(EquipmentRecordService.getSearchStats).toHaveBeenCalled();
        expect(EquipmentRecordService.getSearchStats).toHaveBeenCalledWith(result);
    }));

    it("The equipmentRecord Service getSummaryEquipmentRecords function, with valid input, returns the expected value", inject((EquipmentRecordService) => {
        var searchInput = "defib*";
        var userSpecifiedFilters = "(deleteInd:N)";

        spyOn(EquipmentRecordService, "getSummaryEquipmentRecords").and.callThrough();
        EquipmentRecordService.getSummaryEquipmentRecords(searchInput, userSpecifiedFilters);

        expect(EquipmentRecordService.getSummaryEquipmentRecords).toHaveBeenCalled();
        expect(EquipmentRecordService.getSummaryEquipmentRecords).toHaveBeenCalledWith(searchInput, userSpecifiedFilters);
    }));

    it("The equipmentRecord Service getSummaryEquipmentRecords function, with no searchInput, returns the expected value", inject((EquipmentRecordService) => {
        var searchInput = "";
        var userSpecifiedFilters = "(deleteInd:N)";

        spyOn(EquipmentRecordService, "getSummaryEquipmentRecords").and.callThrough();
        EquipmentRecordService.getSummaryEquipmentRecords(searchInput, userSpecifiedFilters);

        expect(EquipmentRecordService.getSummaryEquipmentRecords).toHaveBeenCalled();
        expect(EquipmentRecordService.getSummaryEquipmentRecords).toHaveBeenCalledWith(searchInput, userSpecifiedFilters);
    }));

    it("The equipmentRecord Service getSummaryEquipmentRecords function, with no searchInput or userSpecifiedFilters, returns the expected value", inject((EquipmentRecordService) => {
        var searchInput = "";
        var userSpecifiedFilters = "";

        spyOn(EquipmentRecordService, "getSummaryEquipmentRecords").and.callThrough();
        EquipmentRecordService.getSummaryEquipmentRecords(searchInput, userSpecifiedFilters);

        expect(EquipmentRecordService.getSummaryEquipmentRecords).toHaveBeenCalled();
        expect(EquipmentRecordService.getSummaryEquipmentRecords).toHaveBeenCalledWith(searchInput, userSpecifiedFilters);
    }));

    it("The equipmentRecord Service parseSummaryEquipmentRecordResults function, called with no input results, returns the expected value", inject((EquipmentRecordService) => {
        var results = "";

        spyOn(EquipmentRecordService, "parseSummaryEquipmentRecordResults").and.callThrough();
        expect(EquipmentRecordService.parseSummaryEquipmentRecordResults(results)).toEqual([]);

        expect(EquipmentRecordService.parseSummaryEquipmentRecordResults).toHaveBeenCalled();
        expect(EquipmentRecordService.parseSummaryEquipmentRecordResults).toHaveBeenCalledWith(results);
    }));

    it("The equipmentRecord Service parseSummaryEquipmentRecordAggregations function, called with input no results, returns the expected value", inject((EquipmentRecordService) => {
        var results = "";

        spyOn(EquipmentRecordService, "parseSummaryEquipmentRecordAggregations").and.callThrough();
        expect(EquipmentRecordService.parseSummaryEquipmentRecordAggregations(results)).toEqual({});

        expect(EquipmentRecordService.parseSummaryEquipmentRecordAggregations).toHaveBeenCalled();
        expect(EquipmentRecordService.parseSummaryEquipmentRecordAggregations).toHaveBeenCalledWith(results);
    }));

    it("The equipmentRecord Service parseDetailEquipmentRecordResults function, called with typical valid input, returns the expected value", inject((EquipmentRecordService) => {
        var result = {
            "data": {
                "id": "569feb82b6c67a887638a870",
                "assemblageCount": 0,
                "assmInstNum": null,
                "meAccumDeprtAmt": 0,
                "meAcqCostQty": 1594.97,
                "meDiscountAmt": 0,
                "meInstalltionAmt": 0,
                "meOtherMiscAmt": 0,
                "meTradeInAmt": 0,
                "meTransportAmt": 0,
                "meUpgradeCstAmt": 0,
                "totalAqcCost": 1594.97,
                "assemblyMtfSer": null,
                "commodClsSer": 9,
                "custOrgSerial": null,
                "custdnPocSer": 4712,
                "customerOrgSer": 3166,
                "devclfExpctnQty": 8,
                "eqpmtOwnerTypCd": 1,
                "equipBalanceId": 2899,
                "facilitySerial": null,
                "fundSerial": null,
                "itemSerial": 54867,
                "maSerial": 3012,
                "maintAssmntTyCd": 9,
                "maintSrcOrgSer": 3764,
                "manufMdlSerId": 2210,
                "manufOrgSerial": 11973,
                "meDepRecoveryMonths": 60,
                "meId": 30965,
                "meModificatnCd": 0,
                "meMrlcQty": 0,
                "meSystemId": null,
                "mfrDivSerial": 6695,
                "mtfEMSerial": 3709,
                "mtfOrgSerial": 1000,
                "networkConnectionTypeId": null,
                "otherGovtSosSer": null,
                "pltPermLocSer": null,
                "roomSerial": null,
                "schedFactorCd": 7,
                "sosSerial": 6244,
                "subCustdnPocSer": null,
                "swOpSysSer": null,
                "updateMarker": 14,
                "usmantSrcOrgSer": 3764,
                "acqCapitalEquip": "N",
                "acqCommodClsTx": "EQUIPMENT-EXPENSE MEDICAL",
                "acqFunctionId": "M",
                "acqFundCd": "WZ",
                "acqSpecialtyCode": "",
                "assemblyOrgID": "",
                "assemblyOrgNM": "",
                "assetTypeCd": "1750.20",
                "assmDescrDetail": "",
                "assmInstDescr": "",
                "assmNumDetail": "",
                "cfoAsstClsTyCd": "1",
                "csvcPoNumId": "",
                "custOrgNM": "TUTTLE ARMY HEALTH CLINIC HAAF",
                "custodianName": "ALLRED, DEVIN W.",
                "custodianPhone": "912-315-5661",
                "dateDuiiStatus": "12/31/2012  22:10:07",
                "deleteInd": "N",
                "deviceCd": "L0575",
                "deviceClsCode": "L0304",
                "deviceClsText": "MODULE PUMP",
                "deviceText": "MODULE PUMP",
                "duiiStatusCd": "N",
                "eiAccntblCd": "Y",
                "eiMaintReqrCd": "Y",
                "entityInd": "E",
                "eqpmtInvMthdCd": "W",
                "eqptInvReasonCd": "R",
                "equipAccountingStatusCd": "S",
                "ertReadinessCd": "",
                "itemId": "651501C707406",
                "localContractId": "",
                "meAccountingStatusDt": "10/26/2013  00:00:00",
                "meAcnId": "11-0079",
                "meAcqDt": "12/31/2012  11:26:35",
                "meApplicationEntityTitleTx": "",
                "meApprovalRefTx": "",
                "meAtoExpiresDt": "",
                "meAtoIssuedDt": "",
                "meAtsScannedByTx": "",
                "meAtsStatusCd": "",
                "meAtsStatusTx": "",
                "meClinAlarmInd": "N",
                "meContrctrIndCd": "N",
                "meCreateDocNum": "YMEEGK22584231",
                "meDownStatusCd": "N",
                "meDuidTypeCd": "",
                "meEcnId": "024868",
                "meEqpmtReqstId": "",
                "meFirmwareVerId": "",
                "meFyFundDate": "12/31/2012  11:26:36",
                "meGfeLoanInd": "N",
                "meInstallationDt": "12/31/2012  00:00:00",
                "meInvKeyInCd": "W",
                "meInvLocationTx": "",
                "meInvPerfrmNm": "packr",
                "meIpv4Address1Tx": "",
                "meIpv4Address2Tx": "",
                "meIpv6Address1Tx": "",
                "meIpv6Address2Tx": "",
                "meIuid": "",
                "meIuidAffixedDt": "",
                "meIuidAffixedInd": "N",
                "meIuidAffixedUserId": "",
                "meJmarTransmInd": "N",
                "meLastInvntryDt": "09/21/2015  15:49:37",
                "meLastSvcDt": "09/21/2015  00:00:00",
                "meLifeSafetyInd": "N",
                "meMacAddressTx": "",
                "meMachineNm": "",
                "meManufModelId": "12278595",
                "meManufacturedDt": "",
                "meMfgSerialId": "13781289",
                "meNetworkConnectionInd": "N",
                "meOnloanCd": "N",
                "mePatientDataInd": "N",
                "meReturnDt": "",
                "meRfLocTx": "",
                "meRfTime": "",
                "meRfid": "",
                "meRfidAffixedDt": "",
                "meSuspdSchedInd": "N",
                "meSuspdSchedWoReasonTx": "",
                "meTempLocTx": "",
                "meVendorSiteId": "",
                "meWarntyBegDt": "12/31/2012  00:00:00",
                "meWarntyLabrEdt": "12/30/2013  00:00:00",
                "meWarntyPartEdt": "12/30/2013  00:00:00",
                "meWirelessFrequencyTx": "",
                "meWrmPeactmCd": "N",
                "mtfOrgID": "W33DME",
                "mtfOrgNM": "WINN AHC, FT STEWART, GA",
                "orgID": "YMEEGK",
                "recvdFromDocnum": "",
                "siteDoDDAC": "W33DME",
                "sourceDodaac": "",
                "sourceMeId": null,
                "subCustodianName": "",
                "subCustodianPH": "",
                "supplyCond": "",
                "systemTypeCd": "I",
                "transCd": "EGI",
                "transReasTypeCd": "EGI",
                "uidTypeCd": "",
                "approval": [
                    {
                        "rankGrade": "",
                        "firstName": "",
                        "lastName": "",
                        "transReasTypeTx": "EQUIPMENT ISSUE GAIN",
                        "mtfSerial": 1000,
                        "equipBalanceRefTx": "AR 40-61",
                        "specialty": " - ",
                        "sos": "Z27 - CAREFUSION",
                        "cfoAsstClsTyTx": "GENERAL",
                        "duidTypeDesc": "",
                        "duiiStatusDesc": "NOT REQUIRED"
                    }
                ],
                "components": [
                    {
                        "ecn": "013376",
                        "itemId": "MEDICOR",
                        "nomenclature": "SERVER, FILE",
                        "manufacturer": "DELL INC",
                        "manufacturerSerialNumber": "31DK7C1",
                        "nameplateModel": "POWEREDGE 2950",
                        "commonModel": "132.15.15.139",
                        "acquisitionCost": "$66,909.00"
                    }
                ],
                "locationInventory": [
                    {
                        "building": "",
                        "roomFloorNum": "",
                        "room": "",
                        "pltPermntLocTx": "",
                        "onlnEquipLoanDt": "",
                        "onlnEquipDayQty": null,
                        "eqpmtInvMthdTx": "WORK ORDER",
                        "eqptInvReasonTx": "ROUTINE",
                        "inacctSerial": null,
                        "locID": "",
                        "subLocID": ""
                    }
                ],
                "maintCost": [
                    {
                        "mcFiscalYearTm": "2013-01-01 00:00:00",
                        "mcDownTime": 0,
                        "mcUnschdWoQty": 1,
                        "mcOPartCostAmt": 0,
                        "mcOUTimeQty": 2.2,
                        "mcOULabCstAmt": 114.4,
                        "mcOSTimeQty": 0.8,
                        "mcOSLabCstAmt": 41.6,
                        "mcCPartCostAmt": 0,
                        "mcCUTimeQty": 0,
                        "mcCULabCstAmt": 0,
                        "mcCSTimeQty": 0,
                        "mcCSLabCstAmt": 0
                    },
                    {
                        "mcFiscalYearTm": "2014-01-01 00:00:00",
                        "mcDownTime": 0,
                        "mcUnschdWoQty": 0,
                        "mcOPartCostAmt": 0,
                        "mcOUTimeQty": 0,
                        "mcOULabCstAmt": 0,
                        "mcOSTimeQty": 2,
                        "mcOSLabCstAmt": 108.84,
                        "mcCPartCostAmt": 0,
                        "mcCUTimeQty": 0,
                        "mcCULabCstAmt": 0,
                        "mcCSTimeQty": 0,
                        "mcCSLabCstAmt": 0
                    }
                ],
                "maintenance": [
                    {
                        "deviceCd": "L0575",
                        "ertReadinessCdAndText": " - ",
                        "meEcnId": "024868",
                        "maSerial": 3012,
                        "meId": 30965,
                        "mel": 985.93,
                        "mrlc": 1728.87,
                        "mpId": 4699,
                        "workOrderCount": 0,
                        "contractorNm": "",
                        "eiTmdeInd": "N",
                        "maintActivityOrgNm": "BIOMEDICAL EQUIP REPAIR FORT STEWART",
                        "maintAssmntTyTx": "GOOD",
                        "operationalStatus": "",
                        "operationalStatusTx": "In Use",
                        "otherGovtMaintSrc": "",
                        "rltDescTx": "NO SIGNIFICANT RISK",
                        "schedFactorTx": "CONTRACTOR",
                        "schedTeamOrgNm": "ROAD TEAM",
                        "unschedTeamOrgNm": "ROAD TEAM"
                    }
                ],
                "maintenanceType": [
                    {
                        "ME_ID": 30965,
                        "miTypeCode": 3,
                        "mdDueDt": "2016-09-27 00:00:00",
                        "mdLastSvcDt": "2015-09-21 00:00:00",
                        "miTypeDescText": "CALIBRATION",
                        "mpId": 4699,
                        "miInuseMonthQty": 12,
                        "miMobltyMnthQty": null,
                        "miStoredMnthQty": null,
                        "meId": null,
                        "operationalStatus": ""
                    },
                    {
                        "ME_ID": 30965,
                        "miTypeCode": 4,
                        "mdDueDt": "",
                        "mdLastSvcDt": "",
                        "miTypeDescText": "SCHEDULED PARTS REPLACEMENT",
                        "mpId": null,
                        "miInuseMonthQty": null,
                        "miMobltyMnthQty": null,
                        "miStoredMnthQty": null,
                        "meId": null,
                        "operationalStatus": ""
                    },
                    {
                        "ME_ID": 30965,
                        "miTypeCode": 1,
                        "mdDueDt": "2016-09-27 00:00:00",
                        "mdLastSvcDt": "2015-09-21 00:00:00",
                        "miTypeDescText": "INSPECTION",
                        "mpId": 4699,
                        "miInuseMonthQty": 12,
                        "miMobltyMnthQty": null,
                        "miStoredMnthQty": null,
                        "meId": null,
                        "operationalStatus": ""
                    },
                    {
                        "ME_ID": 30965,
                        "miTypeCode": 2,
                        "mdDueDt": "2016-09-27 00:00:00",
                        "mdLastSvcDt": "2015-09-21 00:00:00",
                        "miTypeDescText": "PREVENTIVE MAINTENANCE",
                        "mpId": 4699,
                        "miInuseMonthQty": 12,
                        "miMobltyMnthQty": null,
                        "miStoredMnthQty": null,
                        "meId": null,
                        "operationalStatus": ""
                    }
                ],
                "notes": [
                    {
                        "meId": 30965,
                        "meNotesID": 21210,
                        "meNoteAuthrNm": "DENNIS PANGBORN",
                        "meNotesDate": "2013-03-29 08:11:07",
                        "meNotesText": "INSPECTION date due changed from none to Aug 2013.",
                        "meNotesTypeCD": "S"
                    },
                    {
                        "meId": 30965,
                        "meNotesID": 21211,
                        "meNoteAuthrNm": "DENNIS PANGBORN",
                        "meNotesDate": "2013-03-29 08:11:07",
                        "meNotesText": "PREVENTIVE MAINTENANCE date due changed from none to Aug 2013.",
                        "meNotesTypeCD": "S"
                    },
                    {
                        "meId": 30965,
                        "meNotesID": 21212,
                        "meNoteAuthrNm": "DENNIS PANGBORN",
                        "meNotesDate": "2013-03-29 08:11:07",
                        "meNotesText": "CALIBRATION date due changed from none to Aug 2013.",
                        "meNotesTypeCD": "S"
                    },
                    {
                        "meId": 30965,
                        "meNotesID": 26806,
                        "meNoteAuthrNm": "IYALIANO SCOTT",
                        "meNotesDate": "2014-02-27 15:38:19",
                        "meNotesText": "CALIBRATION date due changed from Aug 2014 to Sep 2014.",
                        "meNotesTypeCD": "S"
                    },
                    {
                        "meId": 30965,
                        "meNotesID": 26807,
                        "meNoteAuthrNm": "IYALIANO SCOTT",
                        "meNotesDate": "2014-02-27 15:38:20",
                        "meNotesText": "PREVENTIVE MAINTENANCE date due changed from Aug 2014 to Sep 2014.",
                        "meNotesTypeCD": "S"
                    },
                    {
                        "meId": 30965,
                        "meNotesID": 26808,
                        "meNoteAuthrNm": "IYALIANO SCOTT",
                        "meNotesDate": "2014-02-27 15:38:20",
                        "meNotesText": "INSPECTION date due changed from Aug 2014 to Sep 2014.",
                        "meNotesTypeCD": "S"
                    }
                ]
            },
            "status": 200,
            "config": {
                "method": "GET",
                "transformRequest": [
                    null
                ],
                "transformResponse": [
                    null
                ],
                "headers": {
                    "Authorization": "Token eyJhbGciOiJIUzUxMiJ9.eyJqdGkiOiJjMWZjYTE4ZC1lMjUyLTQ5MDMtYmE5Yi03NWYyYzM1ZWM2ZjgiLCJpc3MiOiJkbWxlcyIsImlhdCI6MTQ3Mjc1MzkxNywic3ViIjoiYWxsLjEyMyIsImV4cCI6MTQ3Mjc2ODMxNywibmJmIjoxNDcyNzUzOTE3LCJJRCI6IjU3OTBjODdhNGMwOGIwMDAzZDk3ODJmMCIsIlBLSUROIjoiYWxsLjEyMyIsIkZJUlNUX05BTUUiOiJBbGwiLCJMQVNUX05BTUUiOiJQZXJtaXNzaW9ucyIsIlNFUlZJQ0VfQ09ERSI6IkRIQSIsIlVTRVJfVFlQRSI6IkdMT0JBTCIsIkVORFBPSU5UIjoiL1VzZXIvVjEvQXBpL3JlZ2lzdGVyIn0.0tkQI9jUxZ6BPMKQflyGbsW-bHVKUSiKvsw2KlH3Bc4FqPmfmwVKdegGO3jyjNZBwVAev3LA2DEMGgFUIzClKA",
                    "ClientId": "dmles",
                    "Accept": "application/json, text/plain, */*"
                },
                "url": "http://jw8dmles102:8080/Dmles.Equipment.Server/V1/getEquipmentRecord?dodaac=W33DME&meId=30965"
            },
            "statusText": "OK"
        };
        var inputEquipmentRecord = {
            "_id": "",
            "meId": 30965,
            "selected": true,
            "detailsRetrieved": false,
            "shortItemDesc": "MODULE PUMP",
            "longItemDesc": "",
            "equipmentStatus": "Active",
            "orgId": "W33DME",
            "ecn": "024868",
            "nomenclature": "MODULE PUMP",
            "itemId": "651501C707406",
            "deviceClass": "MODULE PUMP",
            "manufacturer": "ALARIS MEDICAL SYSTEMS INC",
            "division": "",
            "nameplateModel": "",
            "commonModel": "ALARIS PUMP 8100",
            "manufacturerSerialNumber": "13781289",
            "acquisitionCost": 1594.97,
            "lifeExpectancy": "",
            "assetControlNumber": "",
            "acquisitionCommodityClass": "",
            "equipmentType": "",
            "systemEcn": "",
            "accountingStatus": "",
            "isAccountableEquipment": true,
            "isMaintenanceRequired": true,
            "ownership": "ORGANIZATIONAL",
            "condition": "",
            "organization": "",
            "customerName": "TUTTLE ARMY HEALTH CLINIC HAAF",
            "customerId": "YMEEGK",
            "custodianName": "ALLRED, DEVIN W.",
            "custodianPhone": "",
            "subcustodianName": "",
            "subcustodianPhone": "",
            "assemblageOrganization": "",
            "assemblageDescription": "",
            "assemblageNumber": "",
            "isOnLoan": false,
            "building": "",
            "floor": "",
            "room": "",
            "equipmentLocation": "",
            "temporaryLocation": "",
            "locationId": "",
            "rfidTag": "",
            "rfLocation": "",
            "subLocation": "",
            "inventoryPerformedBy": "",
            "inventoryLocation": "",
            "inventoryEntryMethod": "",
            "inventoryReason": "",
            "approvalReference": "",
            "acquisitionSpeciality": "",
            "replacementRequestNumber": "",
            "transactionReason": "",
            "sourceOfSupply": "",
            "contractNumber": "",
            "documentNumber": "",
            "receivedFromDocumentNumber": "",
            "accumulatedDepreciation": 0,
            "cfoAssetClassification": "",
            "acquisitionFundCode": "",
            "iuid": "",
            "uiiType": "",
            "uiiStatus": "",
            "isUiiLabelAffixed": false,
            "userName": "",
            "maintenanceActivity": "BIOMEDICAL EQUIP REPAIR FORT STEWART",
            "scheduledTeam": "ROAD TEAM",
            "unscheduledTeam": "ROAD TEAM",
            "otherGovernmentAgency": "",
            "contractor": "",
            "siteId": "",
            "firmwareNumber": "",
            "riskLevel": "",
            "schedulingFactor": "",
            "equipmentReadinessCode": "",
            "maintenanceAssessment": "",
            "operationalStatus": "",
            "procedureNumber": "",
            "outstandingWorkOrders": 0,
            "modifications": 0,
            "maximumExpenditureLimit": 0,
            "maximumRepairLimitCumulative": 0,
            "containsPatientData": false,
            "clinicalAlarmIndicator": false,
            "lifeSafety": false,
            "suspendScheduledWorkOrders": false,
            "tmde": false,
            "downStatus": false,
            "suspendReason": "",
            "maintenancePlan": [],
            "maintenanceCostHistory": [],
            "totalSystemAcquisitionCost": 0,
            "totalMaintenanceCost": 0,
            "totalDownTime": 0,
            "totalMaintenanceUnscheduledWorkOrders": 0,
            "totalOrganizationalCosts": {
                "partsCost": 0,
                "unscheduledTime": 0,
                "unscheduledLaborCost": 0,
                "scheduledTime": 0,
                "scheduledLaborCost": 0,
                "totalCost": 0
            },
            "totalContractCosts": {
                "partsCost": 0,
                "unscheduledTime": 0,
                "unscheduledLaborCost": 0,
                "scheduledTime": 0,
                "scheduledLaborCost": 0,
                "totalCost": 0
            },
            "components": [],
            "notes": [],
            "deviceText": "",
            "manufacturerNm": "",
            "supplierNm": "",
            "acquisitionDate": "2012-12-31T16:26:35.000Z",
            "$$hashKey": "object:588"
        };

        spyOn(EquipmentRecordService, "parseDetailEquipmentRecordResults").and.callThrough();
        EquipmentRecordService.parseDetailEquipmentRecordResults(result, inputEquipmentRecord);

        expect(EquipmentRecordService.parseDetailEquipmentRecordResults).toHaveBeenCalled();
        expect(EquipmentRecordService.parseDetailEquipmentRecordResults).toHaveBeenCalledWith(result, inputEquipmentRecord);
    }));

    it("The equipmentRecord Service convertEquipmentTypeCodeToString function, called with all possible inputs, returns the expected values", inject((EquipmentRecordService) => {
        expect(EquipmentRecordService.convertEquipmentTypeCodeToString("S")).toEqual("SYSTEM");
        expect(EquipmentRecordService.convertEquipmentTypeCodeToString("C")).toEqual("COMPONENT");
        expect(EquipmentRecordService.convertEquipmentTypeCodeToString("I")).toEqual("INDIVIDUAL");
        expect(EquipmentRecordService.convertEquipmentTypeCodeToString("Z")).toEqual("Z");
    }));

    it("The equipmentRecord Service convertAccountingStatusCodeToString function, called with all possible inputs, returns the expected values", inject((EquipmentRecordService) => {
        expect(EquipmentRecordService.convertAccountingStatusCodeToString("R")).toEqual("RECEIVED");
        expect(EquipmentRecordService.convertAccountingStatusCodeToString("A")).toEqual("AWAITING ACCEPTANCE");
        expect(EquipmentRecordService.convertAccountingStatusCodeToString("I")).toEqual("AWATING INSTALLATION");
        expect(EquipmentRecordService.convertAccountingStatusCodeToString("S")).toEqual("IN SERVICE");
        expect(EquipmentRecordService.convertAccountingStatusCodeToString("M")).toEqual("REMOVED FROM SERVICE");
        expect(EquipmentRecordService.convertAccountingStatusCodeToString("D")).toEqual("TRANSFERRED TO DRMO");
        expect(EquipmentRecordService.convertAccountingStatusCodeToString("T")).toEqual("TRANSFERRED OUT");
        expect(EquipmentRecordService.convertAccountingStatusCodeToString("Z")).toEqual("Z");
    }));

    it("The equipmentRecord Service convertOwnershipCodeToString function, called with all possible inputs, returns the expected values", inject((EquipmentRecordService) => {
        expect(EquipmentRecordService.convertOwnershipCodeToString(1)).toEqual("ORGANIZATIONAL");
        expect(EquipmentRecordService.convertOwnershipCodeToString(2)).toEqual("OPERATING LEASED");
        expect(EquipmentRecordService.convertOwnershipCodeToString(3)).toEqual("OTHER GOV. OWNED");
        expect(EquipmentRecordService.convertOwnershipCodeToString(4)).toEqual("NON-GOV. OWNED");
        expect(EquipmentRecordService.convertOwnershipCodeToString(5)).toEqual("CAPITAL LEASED");
        expect(EquipmentRecordService.convertOwnershipCodeToString(9)).toEqual("9");
    }));

    it("The equipmentRecord Service convertConditionCodeToString function, called with all possible inputs, returns the expected values", inject((EquipmentRecordService) => {
        expect(EquipmentRecordService.convertConditionCodeToString("A")).toEqual("SERVICEABLE (ISSUABLE WITHOUT QUALIFICATION)");
        expect(EquipmentRecordService.convertConditionCodeToString("B")).toEqual("SERVICEABLE (ISSUABLE WITH QUALIFICATION)");
        expect(EquipmentRecordService.convertConditionCodeToString("C")).toEqual("SERVICEABLE (PRIORITY ISSUE)");
        expect(EquipmentRecordService.convertConditionCodeToString("D")).toEqual("SERVICEABLE (TEST/MODIFICATION)");
        expect(EquipmentRecordService.convertConditionCodeToString("E")).toEqual("UNSERVICEABLE (LIMITED RESTORATION)");
        expect(EquipmentRecordService.convertConditionCodeToString("F")).toEqual("UNSERVICEABLE (REPARABLE)");
        expect(EquipmentRecordService.convertConditionCodeToString("G")).toEqual("UNSERVICEABLE (INCOMPLETE)");
        expect(EquipmentRecordService.convertConditionCodeToString("H")).toEqual("UNSERVICEABLE (CONDEMNED)");
        expect(EquipmentRecordService.convertConditionCodeToString("J")).toEqual("SUSPENDED (IN STOCK)");
        expect(EquipmentRecordService.convertConditionCodeToString("K")).toEqual("SUSPENDED (RETURNS)");
        expect(EquipmentRecordService.convertConditionCodeToString("L")).toEqual("SUSPENDED (LITIGATION)");
        expect(EquipmentRecordService.convertConditionCodeToString("M")).toEqual("SUSPENDED (IN WORK)");
        expect(EquipmentRecordService.convertConditionCodeToString("N")).toEqual("SUSPENDED (AMMUNITION SUITABLE FOR EMERGENCY COMBAT USE ONLY)");
        expect(EquipmentRecordService.convertConditionCodeToString("P")).toEqual("UNSERVICEABLE (RECLAMATION)");
        expect(EquipmentRecordService.convertConditionCodeToString("Q")).toEqual("SUSPENDED (QUALITY DEFICIENT EXHIBITS)");
        expect(EquipmentRecordService.convertConditionCodeToString("R")).toEqual("SUSPENDED (RECLAIMED ITEMS AWAITING CONDITION DETERMINATION)");
        expect(EquipmentRecordService.convertConditionCodeToString("S")).toEqual("UNSERVICEABLE (SCRAP)");
        expect(EquipmentRecordService.convertConditionCodeToString("Z")).toEqual("Z");
    }));

});

