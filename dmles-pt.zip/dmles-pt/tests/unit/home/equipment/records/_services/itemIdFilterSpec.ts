import "../../../../../../src/module";
import "../../../../../../src/home/module";
import "../../../../../../src/home/equipment/module";
import "../../../../../../src/home/equipment/records/module";
import "../../../../../../src/home/equipment/records/_services/module";
import "../../../../../../src/home/equipment/records/_views/module";

describe('Equipment Records _Services ItemIdFilter Service Tests', () => {

    beforeEach(() => {
        module('DmlesModule');
        module('Dmles.Home.Module');
        module('Dmles.Equipment.Module');
        module('Dmles.Home.Equipment.Records.RecordsModule');
        module('Dmles.Home.Equipment.Records.Views.Module');
        module('Dmles.Home.Equipment.Records.Services.Module');
    });

    it('Has an itemIdFilter Service', inject((ItemIdFilterService) => {
        expect( ItemIdFilterService ).toBeDefined();
    }));

    it('The itemIdFilter Service has a label', inject((ItemIdFilterService) => {
        expect(ItemIdFilterService.label).toBeDefined();
    }));

    it("The itemIdFilter Service label has the correct value", inject((ItemIdFilterService) => {
        expect(ItemIdFilterService.label).toMatch(" Item ID");
    }));

    it("The itemIdFilter Service reset function causes the initialize function to be called", inject((ItemIdFilterService) => {
        spyOn(ItemIdFilterService, 'initialize');
        ItemIdFilterService.reset();
        expect(ItemIdFilterService.initialize).toHaveBeenCalled();
    }));

    it("The itemIdFilter Service reset then buildSearchClause function returns the expected value", inject((ItemIdFilterService) => {
        ItemIdFilterService.reset();
        expect(ItemIdFilterService.buildSearchClause()).toEqual("");
    }));

    it("The itemIdFilter Service buildSearchClause function with multi-value input returns the expected value", inject((ItemIdFilterService) => {
        ItemIdFilterService.reset();
        ItemIdFilterService.value = "01332, 00456, 374567";
        expect(ItemIdFilterService.buildSearchClause()).toEqual('((itemId:*01332*) OR (itemId:*00456*) OR (itemId:*374567*))');
    }));

    it("The itemIdFilter Service process function with multi-value input returns the expected value", inject((ItemIdFilterService) => {
        ItemIdFilterService.reset();
        ItemIdFilterService.value = "01332, 00456, 374567";
        ItemIdFilterService.process();
        expect(ItemIdFilterService.values).toEqual([ { selValue: '01332' }, { selValue: '00456' }, { selValue: '374567' } ]);
    }));
});

