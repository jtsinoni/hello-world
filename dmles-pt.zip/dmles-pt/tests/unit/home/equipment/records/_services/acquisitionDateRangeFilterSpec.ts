import "../../../../../../src/module";
import "../../../../../../src/home/module";
import "../../../../../../src/home/equipment/module";
import "../../../../../../src/home/equipment/records/module";
import "../../../../../../src/home/equipment/records/_services/module";
import "../../../../../../src/home/equipment/records/_views/module";

describe('Equipment Records _Services AcquisitionDateRangeFilter Service Tests', () => {

    beforeEach(() => {
        module('DmlesModule');
        module('Dmles.Home.Module');
        module('Dmles.Equipment.Module');
        module('Dmles.Home.Equipment.Records.RecordsModule');
        module('Dmles.Home.Equipment.Records.Views.Module');
        module('Dmles.Home.Equipment.Records.Services.Module');
    });

    it('Has an acquisitionDateRangeFilter Service', inject((AcquisitionDateRangeFilterService) => {
        expect( AcquisitionDateRangeFilterService ).toBeDefined();
    }));

    it('The acquisitionDateRangeFilter Service has a label', inject((AcquisitionDateRangeFilterService) => {
        expect(AcquisitionDateRangeFilterService.label).toBeDefined();
    }));

    it("The acquisitionDateRangeFilter Service label has the correct value", inject((AcquisitionDateRangeFilterService) => {
        expect(AcquisitionDateRangeFilterService.label).toMatch(" Acquisition Date Range");
    }));

    it("The acquisitionDateRangeFilter Service reset function causes the initialize function to be called", inject((AcquisitionDateRangeFilterService) => {
        spyOn(AcquisitionDateRangeFilterService, 'initialize');
        AcquisitionDateRangeFilterService.reset();
        expect(AcquisitionDateRangeFilterService.initialize).toHaveBeenCalled();
    }));    

    it("The acquisitionDateRangeFilter Service reset function causes the date to be set to the expected value", inject((AcquisitionDateRangeFilterService) => {
        AcquisitionDateRangeFilterService.reset();
        expect(AcquisitionDateRangeFilterService.datePicker.date).toEqual({ startDate: null, endDate: null });
    }));

    it("The acquisitionDateRangeFilter Service buildSearchClause function returns the expected value", inject((AcquisitionDateRangeFilterService) => {
        AcquisitionDateRangeFilterService.datePicker.date.startDate = "03/01/2014";
        AcquisitionDateRangeFilterService.datePicker.date.endDate = "09/01/2016";
        expect(AcquisitionDateRangeFilterService.buildSearchClause()).toEqual('(meAcqDt:>=03/01/2014 && meAcqDt:<=09/01/2016)');
    }));

    it("The acquisitionDateRangeFilter Service triggerSearch function causes doSearch to be set to true", inject((AcquisitionDateRangeFilterService) => {
        AcquisitionDateRangeFilterService.triggerSearch();
        expect(AcquisitionDateRangeFilterService.doSearch).toEqual(true);

    }));
});

