import "../../../../../../src/module";
import "../../../../../../src/home/module";
import "../../../../../../src/home/equipment/module";
import "../../../../../../src/home/equipment/records/module";
import "../../../../../../src/home/equipment/records/_services/module";
import "../../../../../../src/home/equipment/records/_views/module";

describe('Equipment Records _Services CustomerNameFilter Service Tests', () => {

    beforeEach(() => {
        module('DmlesModule');
        module('Dmles.Home.Module');
        module('Dmles.Equipment.Module');
        module('Dmles.Home.Equipment.Records.RecordsModule');
        module('Dmles.Home.Equipment.Records.Views.Module');
        module('Dmles.Home.Equipment.Records.Services.Module');
    });

    it('Has an customerNameFilter Service', inject((CustomerNameFilterService) => {
        expect( CustomerNameFilterService ).toBeDefined();
    }));

    it('The customerNameFilter Service has a label', inject((CustomerNameFilterService) => {
        expect(CustomerNameFilterService.label).toBeDefined();
    }));

    it("The customerNameFilter Service label has the correct value", inject((CustomerNameFilterService) => {
        expect(CustomerNameFilterService.label).toMatch(" Customer Name");
    }));

    it("The customerNameFilter Service reset function causes the initialize function to be called", inject((CustomerNameFilterService) => {
        spyOn(CustomerNameFilterService, 'initialize');
        CustomerNameFilterService.reset();
        expect(CustomerNameFilterService.initialize).toHaveBeenCalled();
    }));    
});

