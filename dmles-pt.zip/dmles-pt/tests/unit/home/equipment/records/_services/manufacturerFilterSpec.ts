import "../../../../../../src/module";
import "../../../../../../src/home/module";
import "../../../../../../src/home/equipment/module";
import "../../../../../../src/home/equipment/records/module";
import "../../../../../../src/home/equipment/records/_services/module";
import "../../../../../../src/home/equipment/records/_views/module";

describe('Equipment Records _Services ManufacturerFilter Service Tests', () => {

    beforeEach(() => {
        module('DmlesModule');
        module('Dmles.Home.Module');
        module('Dmles.Equipment.Module');
        module('Dmles.Home.Equipment.Records.RecordsModule');
        module('Dmles.Home.Equipment.Records.Views.Module');
        module('Dmles.Home.Equipment.Records.Services.Module');
    });

    it('Has an manufacturerFilter Service', inject((ManufacturerFilterService) => {
        expect( ManufacturerFilterService ).toBeDefined();
    }));

    it('The manufacturerFilter Service has a label', inject((ManufacturerFilterService) => {
        expect(ManufacturerFilterService.label).toBeDefined();
    }));

    it("The manufacturerFilter Service label has the correct value", inject((ManufacturerFilterService) => {
        expect(ManufacturerFilterService.label).toMatch(" Manufacturer");
    }));

    it("The manufacturerFilter Service reset function causes the initialize function to be called", inject((ManufacturerFilterService) => {
        spyOn(ManufacturerFilterService, 'initialize');
        ManufacturerFilterService.reset();
        expect(ManufacturerFilterService.initialize).toHaveBeenCalled();
    }));    
});

