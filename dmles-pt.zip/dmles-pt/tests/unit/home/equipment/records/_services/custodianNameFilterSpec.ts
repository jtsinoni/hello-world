import "../../../../../../src/module";
import "../../../../../../src/home/module";
import "../../../../../../src/home/equipment/module";
import "../../../../../../src/home/equipment/records/module";
import "../../../../../../src/home/equipment/records/_services/module";
import "../../../../../../src/home/equipment/records/_views/module";

describe('Equipment Records _Services CustodianNameFilter Service Tests', () => {

    beforeEach(() => {
        module('DmlesModule');
        module('Dmles.Home.Module');
        module('Dmles.Equipment.Module');
        module('Dmles.Home.Equipment.Records.RecordsModule');
        module('Dmles.Home.Equipment.Records.Views.Module');
        module('Dmles.Home.Equipment.Records.Services.Module');
    });

    it('Has an custodianNameFilter Service', inject((CustodianNameFilterService) => {
        expect( CustodianNameFilterService ).toBeDefined();
    }));

    it('The custodianNameFilter Service has a label', inject((CustodianNameFilterService) => {
        expect(CustodianNameFilterService.label).toBeDefined();
    }));

    it("The custodianNameFilter Service label has the correct value", inject((CustodianNameFilterService) => {
        expect(CustodianNameFilterService.label).toMatch(" Custodian Name");
    }));

    it("The custodianNameFilter Service reset function causes the initialize function to be called", inject((CustodianNameFilterService) => {
        spyOn(CustodianNameFilterService, 'initialize');
        CustodianNameFilterService.reset();
        expect(CustodianNameFilterService.initialize).toHaveBeenCalled();
    }));    
});

