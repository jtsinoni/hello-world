import "../../../../../../src/module";
import "../../../../../../src/home/module";
import "../../../../../../src/home/equipment/module";
import "../../../../../../src/home/equipment/records/module";
import "../../../../../../src/home/equipment/records/_services/module";
import "../../../../../../src/home/equipment/records/_views/module";

describe('Equipment Records _Services EcnFilter Service Tests', () => {

    beforeEach(() => {
        module('DmlesModule');
        module('Dmles.Home.Module');
        module('Dmles.Equipment.Module');
        module('Dmles.Home.Equipment.Records.RecordsModule');
        module('Dmles.Home.Equipment.Records.Views.Module');
        module('Dmles.Home.Equipment.Records.Services.Module');
    });

    it('Has an ecnFilter Service', inject((EcnFilterService) => {
        expect( EcnFilterService ).toBeDefined();
    }));

    it('The ecnFilter Service has a label', inject((EcnFilterService) => {
        expect(EcnFilterService.label).toBeDefined();
    }));

    it("The ecnFilter Service label has the correct value", inject((EcnFilterService) => {
        expect(EcnFilterService.label).toMatch(" ECN");
    }));

    it("The ecnFilter Service reset function causes the initialize function to be called", inject((EcnFilterService) => {
        spyOn(EcnFilterService, 'initialize');
        EcnFilterService.reset();
        expect(EcnFilterService.initialize).toHaveBeenCalled();
    }));

    it("The ecnFilter Service reset then buildSearchClause function returns the expected value", inject((EcnFilterService) => {
        EcnFilterService.reset();
        expect(EcnFilterService.buildSearchClause()).toEqual("");
    }));

    it("The ecnFilter Service buildSearchClause function with multi-value input returns the expected value", inject((EcnFilterService) => {
        EcnFilterService.reset();
        EcnFilterService.value = "01332, 00456, 374567";
        expect(EcnFilterService.buildSearchClause()).toEqual('((meECNId:*01332*) OR (meECNId:*00456*) OR (meECNId:*374567*))');
    }));

    it("The ecnFilter Service process function with multi-value input returns the expected value", inject((EcnFilterService) => {
        EcnFilterService.reset();
        EcnFilterService.value = "01332, 00456, 374567";
        EcnFilterService.process();
        expect(EcnFilterService.values).toEqual([ { selValue: '01332' }, { selValue: '00456' }, { selValue: '374567' } ]);
    }));
});

