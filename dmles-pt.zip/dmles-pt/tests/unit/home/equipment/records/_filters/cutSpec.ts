describe('Equipment Records _Filters Cut.Filter Tests', () => {
    'use strict';

    var $filter;

    beforeEach(() => {
        module('Dmles.Home.Equip.Record.Filters.Module');

        inject((_$filter_) => {
            $filter = _$filter_;
        });
    });

    it('should truncate a sentence after 30 characters on word boundaries (when workwise = true) and append "..."', () => {
        var value = 'There is a very long road ahead of us.';
        var wordwise = true;
        var max = 30;
        var tail = "...";
        var result = "";

        // Act.
        result = $filter('cut')(value, wordwise, max, tail);

        // Assert.
        expect(result).toEqual('There is a very long road...');
    });

    it('should truncate a sentence after 30 characters NOT on word boundaries (when workwise = false) and append "..."', () => {
        var value = 'There is a very long road ahead of us.';
        var wordwise = false;
        var max = 30;
        var tail = "...";
        var result = "";

        // Act.
        result = $filter('cut')(value, wordwise, max, tail);

        // Assert.
        expect(result).toEqual('There is a very long road ahea...');
    });

    it('should handle null value case', () => {
        var value = null;
        var wordwise = false;
        var max = 30;
        var tail = "...";
        var result = "";

        // Act.
        result = $filter('cut')(value, wordwise, max, tail);

        // Assert.
        expect(result).toEqual('');
    });

    it('should handle null max case', () => {
        var value = 'There is a very long road ahead of us.';
        var wordwise = false;
        var max = null;
        var tail = "...";
        var result = "";

        // Act.
        result = $filter('cut')(value, wordwise, max, tail);

        // Assert.
        expect(result).toEqual('There is a very long road ahead of us.');
    });

    it('should handle (value.length <= max) case', () => {
        var value = 'There is a short road ahead.';
        var wordwise = false;
        var max = 30;
        var tail = "...";
        var result = "";

        // Act.
        result = $filter('cut')(value, wordwise, max, tail);

        // Assert.
        expect(result).toEqual('There is a short road ahead.');
    });

    it('should handle the no tail provided case', () => {
        var value = 'There is a very long road ahead of us.';
        var wordwise = false;
        var max = 30;
        var result = "";

        // Act.
        result = $filter('cut')(value, wordwise, max);

        // Assert.
        expect(result).toEqual('There is a very long road ahea …');
    });

    it('should truncate a string after 20 characters even if there are no word boundaries (when workwise = true) and append "..."', () => {
        var value = 'ThereIsAVeryLongRoadAheadOfUs.';
        var wordwise = true;
        var max = 20;
        var tail = "...";
        var result = "";

        // Act.
        result = $filter('cut')(value, wordwise, max, tail);

        // Assert.
        expect(result).toEqual('ThereIsAVeryLongRoad...');
    });
});