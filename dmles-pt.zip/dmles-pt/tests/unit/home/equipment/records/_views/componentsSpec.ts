import "../../../../../../src/module";
import "../../../../../../src/home/module";
import "../../../../../../src/home/equipment/module";
import "../../../../../../src/home/equipment/records/module";
import "../../../../../../src/home/equipment/records/_services/module";
import "../../../../../../src/home/equipment/records/_views/module";

describe('Equipment Records _Views Components.Controller Tests', () => {
    var components = [{
            "ecn": "013376",
            "itemId": "MEDICOR",
            "nomenclature": "SERVER, FILE",
            "manufacturer": "DELL INC",
            "manufacturerSerialNumber": "31DK7C1",
            "nameplateModel": "POWEREDGE 2950",
            "commonModel": "132.15.15.139",
            "acquisitionCost": "$66,909.00"
        }];
    
    var componentsController;
    var mock;

    beforeEach(() => {
        module('DmlesModule');
        module('Dmles.Home.Module');
        module('Dmles.Equipment.Module');
        module('Dmles.Home.Equipment.Records.RecordsModule');
        module('Dmles.Home.Equipment.Records.Views.Module');

        inject(($rootScope, $controller, DetailsPaginationService) => {
            mock = {
                $scope: $rootScope.$new(),

                DetailsPaginationService: DetailsPaginationService                
            };

            componentsController = $controller('ComponentsController', mock);
        });

        // Equipment Record Search results from "information systems FM5270 013375"
        componentsController.DetailsPaginationService.selectedSearchResults = [{
            "_id": "",
            "meId": 6678,
            "selected": true,
            "detailsRetrieved": true,
            "shortItemDesc": "DDRS SYSTEM",
            "longItemDesc": "",
            "equipmentStatus": "Active",
            "orgId": "FM5270",
            "ecn": "013375",
            "nomenclature": "INFORMATION SYSTEM, PICTURE ARCHIVING AND COMMUNICATION",
            "itemId": "DDRSSYSTEM",
            "deviceClass": "INFORMATION SYSTEMS, PICTURE ARCHIVING AND COMMUNICATION",
            "manufacturer": "DELL INC",
            "division": 8330,
            "nameplateModel": "SERVER",
            "commonModel": "132.15.15.139",
            "manufacturerSerialNumber": "SERVER",
            "acquisitionCost": 91769,
            "lifeExpectancy": "6 YEARS",
            "assetControlNumber": "",
            "acquisitionCommodityClass": "EQUIPMENT-EXPENSE MEDICAL",
            "equipmentType": "SYSTEM",
            "systemEcn": null,
            "accountingStatus": "IN SERVICE",
            "isAccountableEquipment": true,
            "isMaintenanceRequired": true,
            "ownership": "ORGANIZATIONAL",
            "condition": "SERVICEABLE (ISSUABLE WITHOUT QUALIFICATION)",
            "organization": "18TH MEDICAL GROUP",
            "customerName": "DENTAL CLINIC",
            "customerId": "545511",
            "custodianName": "THOMPSON, XAVIER",
            "custodianPhone": "630-4857",
            "subcustodianName": "",
            "subcustodianPhone": "",
            "assemblageOrganization": "",
            "assemblageDescription": "",
            "assemblageNumber": "",
            "isOnLoan": false,
            "building": "00626 - MEDICAL/DENTAL CLINIC",
            "floor": "",
            "room": "",
            "equipmentLocation": "UG25",
            "temporaryLocation": "",
            "locationId": "",
            "rfidTag": "",
            "rfLocation": "",
            "subLocation": "",
            "inventoryPerformedBy": "SSGT PHAN BRIAN",
            "inventoryLocation": "",
            "inventoryEntryMethod": "WORK ORDER",
            "inventoryReason": "ROUTINE",
            "approvalReference": "",
            "acquisitionSpeciality": " - ",
            "replacementRequestNumber": "",
            "transactionReason": "ACCOUNTABILITY CHANGED TO REQUIRED",
            "sourceOfSupply": " - ",
            "contractNumber": "",
            "documentNumber": "FM527091259500",
            "receivedFromDocumentNumber": "",
            "accumulatedDepreciation": 0,
            "cfoAssetClassification": "GENERAL",
            "acquisitionFundCode": "2X",
            "iuid": "LDFM5270SERVERSERVER",
            "uiiType": "VIRTUAL",
            "uiiStatus": "REPORTED",
            "isUiiLabelAffixed": false,
            "userName": "",
            "maintenanceActivity": "MEDICAL EQUIPMENT REPAIR CENTER",
            "scheduledTeam": "CLINIC",
            "unscheduledTeam": "CLINIC",
            "otherGovernmentAgency": "",
            "contractor": "",
            "siteId": "",
            "firmwareNumber": "",
            "riskLevel": "NO SIGNIFICANT RISK",
            "schedulingFactor": "CUSTOMER",
            "equipmentReadinessCode": " - ",
            "maintenanceAssessment": "GOOD",
            "operationalStatus": "In Use",
            "procedureNumber": 3013,
            "outstandingWorkOrders": 0,
            "modifications": 0,
            "maximumExpenditureLimit": 9176.9,
            "maximumRepairLimitCumulative": 114518,
            "containsPatientData": true,
            "clinicalAlarmIndicator": false,
            "lifeSafety": false,
            "suspendScheduledWorkOrders": false,
            "tmde": false,
            "downStatus": false,
            "suspendReason": "",
            "maintenancePlan": [
                {
                    "maintenanceType": "INSPECTION",
                    "interval": "12 MONTHS",
                    "dateDue": "2016-07-01T00:00:00.000Z",
                    "dateLastServiced": "2015-07-07T00:00:00.000Z",
                    "$$hashKey": "object:5996"
                },
                {
                    "maintenanceType": "PREVENTIVE MAINTENANCE",
                    "interval": "",
                    "dateDue": null,
                    "dateLastServiced": null,
                    "$$hashKey": "object:5997"
                },
                {
                    "maintenanceType": "CALIBRATION",
                    "interval": "",
                    "dateDue": null,
                    "dateLastServiced": null,
                    "$$hashKey": "object:5998"
                },
                {
                    "maintenanceType": "SCHEDULED PARTS REPLACEMENT",
                    "interval": "",
                    "dateDue": null,
                    "dateLastServiced": null,
                    "$$hashKey": "object:5999"
                }
            ],
            "maintenanceCostHistory": [
                {
                    "fiscalYearDate": "FY 2009",
                    "downTime": 0,
                    "unscheduledWorkOrders": 1,
                    "organizationalPartsCost": "$0.00",
                    "organizationalUnscheduledTime": "1.00",
                    "organizationalUnscheduledLaborCost": "$34.04",
                    "organizationalScheduledTime": "0.50",
                    "organizationalScheduledLaborCost": "$17.02",
                    "totalOrganizationCost": "$51.06",
                    "contractPartsCost": "$0.00",
                    "contractUnscheduledTime": "0.00",
                    "contractUnscheduledLaborCost": "$0.00",
                    "contractScheduledTime": "0.00",
                    "contractScheduledLaborCost": "$0.00",
                    "totalContractCost": "$0.00",
                    "totalMaintenanceCost": "$51.06"
                },
                {
                    "fiscalYearDate": "FY 2010",
                    "downTime": 0,
                    "unscheduledWorkOrders": 0,
                    "organizationalPartsCost": "$0.00",
                    "organizationalUnscheduledTime": "0.00",
                    "organizationalUnscheduledLaborCost": "$0.00",
                    "organizationalScheduledTime": "0.50",
                    "organizationalScheduledLaborCost": "$18.47",
                    "totalOrganizationCost": "$18.47",
                    "contractPartsCost": "$0.00",
                    "contractUnscheduledTime": "0.00",
                    "contractUnscheduledLaborCost": "$0.00",
                    "contractScheduledTime": "0.00",
                    "contractScheduledLaborCost": "$0.00",
                    "totalContractCost": "$0.00",
                    "totalMaintenanceCost": "$18.47"
                },
                {
                    "fiscalYearDate": "FY 2011",
                    "downTime": 0,
                    "unscheduledWorkOrders": 0,
                    "organizationalPartsCost": "$0.00",
                    "organizationalUnscheduledTime": "0.00",
                    "organizationalUnscheduledLaborCost": "$0.00",
                    "organizationalScheduledTime": "1.00",
                    "organizationalScheduledLaborCost": "$37.73",
                    "totalOrganizationCost": "$37.73",
                    "contractPartsCost": "$0.00",
                    "contractUnscheduledTime": "0.00",
                    "contractUnscheduledLaborCost": "$0.00",
                    "contractScheduledTime": "0.00",
                    "contractScheduledLaborCost": "$0.00",
                    "totalContractCost": "$0.00",
                    "totalMaintenanceCost": "$37.73"
                },
                {
                    "fiscalYearDate": "FY 2012",
                    "downTime": 0,
                    "unscheduledWorkOrders": 0,
                    "organizationalPartsCost": "$0.00",
                    "organizationalUnscheduledTime": "0.00",
                    "organizationalUnscheduledLaborCost": "$0.00",
                    "organizationalScheduledTime": "0.50",
                    "organizationalScheduledLaborCost": "$19.50",
                    "totalOrganizationCost": "$19.50",
                    "contractPartsCost": "$0.00",
                    "contractUnscheduledTime": "0.00",
                    "contractUnscheduledLaborCost": "$0.00",
                    "contractScheduledTime": "0.00",
                    "contractScheduledLaborCost": "$0.00",
                    "totalContractCost": "$0.00",
                    "totalMaintenanceCost": "$19.50"
                },
                {
                    "fiscalYearDate": "FY 2013",
                    "downTime": 0,
                    "unscheduledWorkOrders": 0,
                    "organizationalPartsCost": "$0.00",
                    "organizationalUnscheduledTime": "0.00",
                    "organizationalUnscheduledLaborCost": "$0.00",
                    "organizationalScheduledTime": "1.00",
                    "organizationalScheduledLaborCost": "$38.80",
                    "totalOrganizationCost": "$38.80",
                    "contractPartsCost": "$0.00",
                    "contractUnscheduledTime": "0.00",
                    "contractUnscheduledLaborCost": "$0.00",
                    "contractScheduledTime": "0.00",
                    "contractScheduledLaborCost": "$0.00",
                    "totalContractCost": "$0.00",
                    "totalMaintenanceCost": "$38.80"
                },
                {
                    "fiscalYearDate": "FY 2014",
                    "downTime": 0,
                    "unscheduledWorkOrders": 0,
                    "organizationalPartsCost": "$0.00",
                    "organizationalUnscheduledTime": "0.00",
                    "organizationalUnscheduledLaborCost": "$0.00",
                    "organizationalScheduledTime": "0.50",
                    "organizationalScheduledLaborCost": "$19.67",
                    "totalOrganizationCost": "$19.67",
                    "contractPartsCost": "$0.00",
                    "contractUnscheduledTime": "0.00",
                    "contractUnscheduledLaborCost": "$0.00",
                    "contractScheduledTime": "0.00",
                    "contractScheduledLaborCost": "$0.00",
                    "totalContractCost": "$0.00",
                    "totalMaintenanceCost": "$19.67"
                },
                {
                    "fiscalYearDate": "FY 2015",
                    "downTime": 0,
                    "unscheduledWorkOrders": 0,
                    "organizationalPartsCost": "$0.00",
                    "organizationalUnscheduledTime": "0.00",
                    "organizationalUnscheduledLaborCost": "$0.00",
                    "organizationalScheduledTime": "0.20",
                    "organizationalScheduledLaborCost": "$8.02",
                    "totalOrganizationCost": "$8.02",
                    "contractPartsCost": "$0.00",
                    "contractUnscheduledTime": "0.00",
                    "contractUnscheduledLaborCost": "$0.00",
                    "contractScheduledTime": "0.00",
                    "contractScheduledLaborCost": "$0.00",
                    "totalContractCost": "$0.00",
                    "totalMaintenanceCost": "$8.02"
                },
                {
                    "fiscalYearDate": "FY 2016",
                    "downTime": 0,
                    "unscheduledWorkOrders": 0,
                    "organizationalPartsCost": "$0.00",
                    "organizationalUnscheduledTime": "0.00",
                    "organizationalUnscheduledLaborCost": "$0.00",
                    "organizationalScheduledTime": "0.00",
                    "organizationalScheduledLaborCost": "$0.00",
                    "totalOrganizationCost": "$0.00",
                    "contractPartsCost": "$0.00",
                    "contractUnscheduledTime": "0.00",
                    "contractUnscheduledLaborCost": "$0.00",
                    "contractScheduledTime": "0.00",
                    "contractScheduledLaborCost": "$0.00",
                    "totalContractCost": "$0.00",
                    "totalMaintenanceCost": "$0.00"
                }
            ],
            "totalSystemAcquisitionCost": 0,
            "totalMaintenanceCost": 386.50000000000006,
            "totalDownTime": 0,
            "totalMaintenanceUnscheduledWorkOrders": 2,
            "totalOrganizationalCosts": {
                "partsCost": 0,
                "unscheduledTime": 2,
                "unscheduledLaborCost": 68.08,
                "scheduledTime": 8.399999999999999,
                "scheduledLaborCost": 318.42,
                "totalCost": 386.50000000000006
            },
            "totalContractCosts": {
                "partsCost": 0,
                "unscheduledTime": 0,
                "unscheduledLaborCost": 0,
                "scheduledTime": 0,
                "scheduledLaborCost": 0,
                "totalCost": 0
            },
            "components": [
                {
                    "ecn": "013376",
                    "itemId": "MEDICOR",
                    "nomenclature": "SERVER, FILE",
                    "manufacturer": "DELL INC",
                    "manufacturerSerialNumber": "31DK7C1",
                    "nameplateModel": "POWEREDGE 2950",
                    "commonModel": "132.15.15.139",
                    "acquisitionCost": "$66,909.00"
                }
            ],
            "notes": [],
            "deviceText": "",
            "manufacturerNm": "",
            "supplierNm": "",
            "acquisitionDate": "2009-05-05T04:00:00.000Z",
            "$$hashKey": "object:4704",
            "detailsFound": true,
            "accountingStatusDate": "2013-10-26T04:00:00.000Z",
            "loanReturnDate": null,
            "equipmentReturnDate": null,
            "rfDate": "",
            "lastInventoryDate": "2015-07-07T19:13:57.000Z",
            "installationDate": null,
            "warrantyBeginDate": null,
            "warrantyEndDateLabor": null,
            "warrantyEndDateParts": null,
            "uiiStatusDate": "2014-05-31T02:40:39.000Z",
            "uiiAffixedDate": null,
            "dateLastServiced": "2015-07-07T04:00:00.000Z"
        }, {}];
        componentsController.DetailsPaginationService.currentPage = 1;
        componentsController.DetailsPaginationService.pageChanged();
    });

    it('Has scope', () => {
        expect(mock.$scope).not.toEqual(undefined);
    });

    it('Has an components controller', () => {
        expect(componentsController).toBeDefined();
    });

    it('The components controller has a service', () => {
        expect(componentsController.DetailsPaginationService).toBeDefined();
    });

    it('The components controller has a controllerName', () => {
        expect(componentsController.controllerName).toBeDefined();
    });    

    it("The components controller controllerName has the correct value", function() {        
        expect(componentsController.controllerName).toMatch("Equipment Record Details - Components Tab Controller");        
    });

    it('Has an DetailsPaginationService mock', () => {
        expect(mock.DetailsPaginationService).toBeDefined();
    });

    it('The components controller componentsDataGridOpts is defined', () => {
        expect(componentsController.componentsDataGridOpts).toBeDefined();
    });

    it('The components controller DetailsPaginationService.currentEquipmentRecord.components is defined', () => {
        expect(componentsController.DetailsPaginationService.currentEquipmentRecord.components).toBeDefined();
    });

    it('The components controller DetailsPaginationService.currentEquipmentRecord.components has the correct value', () => {
        expect(componentsController.DetailsPaginationService.currentEquipmentRecord.components).toEqual(components);
    });

    it('The components controller DetailsPaginationService.currentEquipmentRecord.components.ecn is defined', () => {
        expect(componentsController.DetailsPaginationService.currentEquipmentRecord.components[0].ecn).toBeDefined();
    });

    it('The components controller DetailsPaginationService.currentEquipmentRecord.components.ecn has the correct value', () => {
        expect(componentsController.DetailsPaginationService.currentEquipmentRecord.components[0].ecn).toBe("013376");
    });
    

    it('The components controller DetailsPaginationService.currentEquipmentRecord.components.itemId is defined', () => {
        expect(componentsController.DetailsPaginationService.currentEquipmentRecord.components[0].itemId).toBeDefined();
    });

    it('The components controller DetailsPaginationService.currentEquipmentRecord.components.itemId has the correct value', () => {
        expect(componentsController.DetailsPaginationService.currentEquipmentRecord.components[0].itemId).toBe("MEDICOR");
    });


    it('The components controller DetailsPaginationService.currentEquipmentRecord.components.nomenclature is defined', () => {
        expect(componentsController.DetailsPaginationService.currentEquipmentRecord.components[0].nomenclature).toBeDefined();
    });

    it('The components controller DetailsPaginationService.currentEquipmentRecord.components.nomenclature has the correct value', () => {
        expect(componentsController.DetailsPaginationService.currentEquipmentRecord.components[0].nomenclature).toBe("SERVER, FILE");
    });


    it('The components controller DetailsPaginationService.currentEquipmentRecord.components.manufacturer is defined', () => {
        expect(componentsController.DetailsPaginationService.currentEquipmentRecord.components[0].manufacturer).toBeDefined();
    });

    it('The components controller DetailsPaginationService.currentEquipmentRecord.components.manufacturer has the correct value', () => {
        expect(componentsController.DetailsPaginationService.currentEquipmentRecord.components[0].manufacturer).toBe("DELL INC");
    });


    it('The components controller DetailsPaginationService.currentEquipmentRecord.components.manufacturerSerialNumber is defined', () => {
        expect(componentsController.DetailsPaginationService.currentEquipmentRecord.components[0].manufacturerSerialNumber).toBeDefined();
    });

    it('The components controller DetailsPaginationService.currentEquipmentRecord.components.manufacturerSerialNumber has the correct value', () => {
        expect(componentsController.DetailsPaginationService.currentEquipmentRecord.components[0].manufacturerSerialNumber).toBe("31DK7C1");
    });


    it('The components controller DetailsPaginationService.currentEquipmentRecord.components.nameplateModel is defined', () => {
        expect(componentsController.DetailsPaginationService.currentEquipmentRecord.components[0].nameplateModel).toBeDefined();
    });

    it('The components controller DetailsPaginationService.currentEquipmentRecord.components.nameplateModel has the correct value', () => {
        expect(componentsController.DetailsPaginationService.currentEquipmentRecord.components[0].nameplateModel).toBe("POWEREDGE 2950");
    });


    it('The components controller DetailsPaginationService.currentEquipmentRecord.components.commonModel is defined', () => {
        expect(componentsController.DetailsPaginationService.currentEquipmentRecord.components[0].commonModel).toBeDefined();
    });

    it('The components controller DetailsPaginationService.currentEquipmentRecord.components.commonModel has the correct value', () => {
        expect(componentsController.DetailsPaginationService.currentEquipmentRecord.components[0].commonModel).toBe("132.15.15.139");
    });
    
    
    it('The components controller DetailsPaginationService.currentEquipmentRecord.components.acquisitionCost is defined', () => {
        expect(componentsController.DetailsPaginationService.currentEquipmentRecord.components[0].acquisitionCost).toBeDefined();
    });

    it('The components controller DetailsPaginationService.currentEquipmentRecord.components.acquisitionCost has the correct value', () => {
        expect(componentsController.DetailsPaginationService.currentEquipmentRecord.components[0].acquisitionCost).toBe("$66,909.00");
    });

    it('The components controller componentsDataGridOpts.displayName is defined', () => {
        expect(componentsController.componentsDataGridOpts.displayName).toBeDefined();
    });

    it('The components controller componentsDataGridOpts.displayName has the correct value', () => {
        expect(componentsController.componentsDataGridOpts.displayName).toBe("Components");
    });

    it('The components controller $watch function works', () => {
        componentsController.DetailsPaginationService.currentPage = 2;
        componentsController.$scope.$apply();
        componentsController.DetailsPaginationService.currentPage = 1;
        componentsController.$scope.$apply();
        expect(componentsController.DetailsPaginationService.currentEquipmentRecord.components).toEqual(components);
    });
});

