import "../../../../../../src/module";
import "../../../../../../src/home/module";
import "../../../../../../src/home/equipment/module";
import "../../../../../../src/home/equipment/records/module";
import "../../../../../../src/home/equipment/records/_services/module";
import "../../../../../../src/home/equipment/records/_views/module";

describe('Equipment Records _Views EquipmentRecordSearch.Controller Tests', () => {

    var equipmentRecordSearchController;
    var mock;

    beforeEach(() => {
        module('DmlesModule');
        module('Dmles.Home.Module');
        module('Dmles.Equipment.Module');
        module('Dmles.Home.Equipment.Records.RecordsModule');
        module('Dmles.Home.Equipment.Records.Views.Module');

        inject(($rootScope, $controller, $q, EquipmentRecordService, AcquisitionDateRangeFilterService, DetailsPaginationService) => {
            mock = {
                $scope: $rootScope.$new(),

                EquipmentRecordService: EquipmentRecordService,
                AcquisitionDateRangeFilterService: AcquisitionDateRangeFilterService,
                DetailsPaginationService: DetailsPaginationService,
                deferred: $q.defer(),
                skip: $q.defer()
            };

            equipmentRecordSearchController = $controller('EquipmentRecordSearchController', mock);
        });

    });

    it('Has scope', () => {
        expect(mock.$scope).not.toEqual(undefined);
    });

    it('Has an equipmentRecordSearch controller', () => {
        expect(equipmentRecordSearchController).toBeDefined();
    });

    it('The equipmentRecordSearch controller has a service', () => {
        expect(equipmentRecordSearchController.EquipmentRecordService).toBeDefined();
    });

    it('Has an EquipmentRecordService mock', () => {
        expect(mock.EquipmentRecordService).toBeDefined();
    });

    it('Calls getMagicNumber synchronously', () =>{
        equipmentRecordSearchController.searchInput = "Test";
        equipmentRecordSearchController.userSpecifiedFilters = [];

        spyOn(mock.EquipmentRecordService, "getMagicNumber").and.callThrough();

        equipmentRecordSearchController.executeSearch();

        expect(mock.EquipmentRecordService.getMagicNumber).toHaveBeenCalled();
        expect(equipmentRecordSearchController.magicNumber).toEqual(33);
    });


    it('Execute Search calls magic number async', () => {
        equipmentRecordSearchController.searchInput = "Test";
        equipmentRecordSearchController.userSpecifiedFilters = [];

        spyOn(mock.EquipmentRecordService, "getMagicNumberAsync").and.returnValue(mock.deferred.promise);
        spyOn(mock.EquipmentRecordService, "getSummaryEquipmentRecords").and.returnValue(mock.skip.promise);

        equipmentRecordSearchController.executeSearch();

        mock.deferred.resolve(44);
        mock.$scope.$apply();

        expect(mock.EquipmentRecordService.getMagicNumberAsync).toHaveBeenCalled();
        expect(equipmentRecordSearchController.asyncMagicNumber).toEqual(44);
    });

    it('Execute Search works with good input', () => {
        var searchInput = "isotemp freezer";
        equipmentRecordSearchController.searchInput = searchInput;
        equipmentRecordSearchController.userSpecifiedFilters = [];

        spyOn(mock.EquipmentRecordService, "getSummaryEquipmentRecords").and.returnValue(mock.deferred.promise);

        equipmentRecordSearchController.executeSearch();

        var mockResponse = {
            "data": {
                "took": 20,
                "timed_out": false,
                "_shards": {
                    "total": 291,
                    "successful": 291,
                    "failed": 0
                },
                "hits": {
                    "total": 2,
                    "max_score": 1.9067975,
                    "hits": [
                        {
                            "_index": "siteequipmentrecordsearch",
                            "_type": "Oracle-SiteEquipmentRecordSearch",
                            "_id": "AVUWny6jcdK1sxVHNHac",
                            "_score": 1.9067975,
                            "fields": {
                                "meDiscountAmt": [
                                    0
                                ],
                                "custOrgId": [
                                    "DBAK01"
                                ],
                                "unschedTeamName": [
                                    "EAST_CAMPUS"
                                ],
                                "meAcqCostQty": [
                                    1822
                                ],
                                "milServiceId": [
                                    "VA"
                                ],
                                "deviceCd": [
                                    "15145"
                                ],
                                "meMFGSerialId": [
                                    "1522080191861"
                                ],
                                "orgId": [
                                    "365121"
                                ],
                                "eiMaintReqrCd": [
                                    "Y"
                                ],
                                "mtfOrgId": [
                                    "365121"
                                ],
                                "schedTeamName": [
                                    "EAST_CAMPUS"
                                ],
                                "manufOrgSerial": [
                                    13901
                                ],
                                "meTransportAmt": [
                                    0
                                ],
                                "eiAccntblCd": [
                                    "Y"
                                ],
                                "maOrgNm": [
                                    "BIOMEDICAL ENGINEERING FHCC"
                                ],
                                "meTradeInAmt": [
                                    0
                                ],
                                "eqptOwnershipDesc": [
                                    "ORGANIZATIONAL"
                                ],
                                "manufOrgName": [
                                    "FISHER SCIENTIFIC CO"
                                ],
                                "meOtherMiscAmt": [
                                    0
                                ],
                                "deviceClsCode": [
                                    "15145"
                                ],
                                "custOrgNM": [
                                    "LAB / CLIN PATH 237"
                                ],
                                "meUpgradeCstAmt": [
                                    0
                                ],
                                "meECNId": [
                                    "051658"
                                ],
                                "meId": [
                                    22270
                                ],
                                "meAcqDt": [
                                    "2007-09-10T04:00:00.000Z"
                                ],
                                "deviceClsText": [
                                    "FREEZERS, LABORATORY"
                                ],
                                "systemTypeDescription": [
                                    "INDIVIDUAL"
                                ],
                                "custOrgSerial": [
                                    3170
                                ],
                                "deleteInd": [
                                    "N"
                                ],
                                "itemDesc": [
                                    "FREEZER, LABORATORY"
                                ],
                                "deviceText": [
                                    "FREEZER, LABORATORY"
                                ],
                                "pltPermntLocTx": [
                                    "LAB 237"
                                ],
                                "manufMdlComnId": [
                                    "ISOTEMP"
                                ],
                                "itemId": [
                                    "4110BM0015145"
                                ],
                                "custodianName": [
                                    "NORTON, SCOTT"
                                ],
                                "systemTypeCd": [
                                    "I"
                                ],
                                "orgNM": [
                                    "VA - FHCC"
                                ],
                                "meInstalltionAmt": [
                                    0
                                ],
                                "mtfSerial": [
                                    1000
                                ]
                            }
                        },
                        {
                            "_index": "siteequipmentrecordsearch",
                            "_type": "Oracle-SiteEquipmentRecordSearch",
                            "_id": "AVUWnx1mcdK1sxVHNFj3",
                            "_score": 1.777717,
                            "fields": {
                                "meDiscountAmt": [
                                    0
                                ],
                                "custOrgId": [
                                    "8H4418"
                                ],
                                "meAcqCostQty": [
                                    1163.09
                                ],
                                "milServiceId": [
                                    "AF"
                                ],
                                "deviceCd": [
                                    "15145"
                                ],
                                "meMFGSerialId": [
                                    "31-51656"
                                ],
                                "orgId": [
                                    "FM5270"
                                ],
                                "eiMaintReqrCd": [
                                    "Y"
                                ],
                                "mtfOrgId": [
                                    "FM5270"
                                ],
                                "manufOrgSerial": [
                                    13833
                                ],
                                "meTransportAmt": [
                                    0
                                ],
                                "eiAccntblCd": [
                                    "Y"
                                ],
                                "maOrgNm": [
                                    "MEDICAL EQUIPMENT REPAIR CENTER"
                                ],
                                "meTradeInAmt": [
                                    0
                                ],
                                "eqptOwnershipDesc": [
                                    "ORGANIZATIONAL"
                                ],
                                "manufOrgName": [
                                    "FISHER SCIENTIFIC CO"
                                ],
                                "meOtherMiscAmt": [
                                    0
                                ],
                                "deviceClsCode": [
                                    "15145"
                                ],
                                "custOrgNM": [
                                    "ENVIRONMENTAL SUPPLY - SGPB (NON-MFH)"
                                ],
                                "meUpgradeCstAmt": [
                                    0
                                ],
                                "meECNId": [
                                    "013168"
                                ],
                                "meId": [
                                    6471
                                ],
                                "meAcqDt": [
                                    "2008-11-25T05:00:00.000Z"
                                ],
                                "deviceClsText": [
                                    "FREEZERS, LABORATORY"
                                ],
                                "systemTypeDescription": [
                                    "INDIVIDUAL"
                                ],
                                "custOrgSerial": [
                                    3207
                                ],
                                "deleteInd": [
                                    "N"
                                ],
                                "itemDesc": [
                                    "FREEZER GENERAL PURPOSE UPRIGHT 29.2CF S"
                                ],
                                "deviceText": [
                                    "FREEZER, LABORATORY"
                                ],
                                "pltPermntLocTx": [
                                    "RM 162 H20 LAB"
                                ],
                                "manufMdlComnId": [
                                    "ISOTEMP FREEZER"
                                ],
                                "itemId": [
                                    "13986148"
                                ],
                                "custodianName": [
                                    "ROSARIO, JASMINE"
                                ],
                                "systemTypeCd": [
                                    "I"
                                ],
                                "orgNM": [
                                    "18TH MEDICAL GROUP"
                                ],
                                "meInstalltionAmt": [
                                    0
                                ],
                                "mtfSerial": [
                                    1000
                                ]
                            }
                        }
                    ]
                },
                "aggregations": {
                    "commonModels": {
                        "doc_count_error_upper_bound": 0,
                        "sum_other_doc_count": 0,
                        "buckets": [
                            {
                                "key": "ISOTEMP",
                                "doc_count": 1
                            },
                            {
                                "key": "ISOTEMP FREEZER",
                                "doc_count": 1
                            }
                        ]
                    },
                    "orgIds": {
                        "doc_count_error_upper_bound": 0,
                        "sum_other_doc_count": 0,
                        "buckets": [
                            {
                                "key": "365121",
                                "doc_count": 1
                            },
                            {
                                "key": "fm5270",
                                "doc_count": 1
                            }
                        ]
                    },
                    "manufacturers": {
                        "doc_count_error_upper_bound": 0,
                        "sum_other_doc_count": 0,
                        "buckets": [
                            {
                                "key": "FISHER SCIENTIFIC CO",
                                "doc_count": 2
                            }
                        ]
                    },
                    "custodianNames": {
                        "doc_count_error_upper_bound": 0,
                        "sum_other_doc_count": 0,
                        "buckets": [
                            {
                                "key": "NORTON, SCOTT",
                                "doc_count": 1
                            },
                            {
                                "key": "ROSARIO, JASMINE",
                                "doc_count": 1
                            }
                        ]
                    },
                    "nomenclatures": {
                        "doc_count_error_upper_bound": 0,
                        "sum_other_doc_count": 0,
                        "buckets": [
                            {
                                "key": "FREEZER, LABORATORY",
                                "doc_count": 2
                            }
                        ]
                    },
                    "customerNames": {
                        "doc_count_error_upper_bound": 0,
                        "sum_other_doc_count": 0,
                        "buckets": [
                            {
                                "key": "ENVIRONMENTAL SUPPLY - SGPB (NON-MFH)",
                                "doc_count": 1
                            },
                            {
                                "key": "LAB / CLIN PATH 237",
                                "doc_count": 1
                            }
                        ]
                    },
                    "custOrgIds": {
                        "doc_count_error_upper_bound": 0,
                        "sum_other_doc_count": 0,
                        "buckets": [
                            {
                                "key": "8h4418",
                                "doc_count": 1
                            },
                            {
                                "key": "dbak01",
                                "doc_count": 1
                            }
                        ]
                    }
                }
            },
            "status": 200,
            "config": {
                "method": "GET",
                "transformRequest": [
                    null
                ],
                "transformResponse": [
                    null
                ],
                "headers": {
                    "Authorization": "Token eyJ0eXAiOiJKV1QifQ.eyJqdGkiOiJmMDdlZWIwMS02MTI4LTQxYzYtODNmZC04YmU2ZWZjMDIxMmYiLCJpc3MiOiJkbWxlcyIsImlhdCI6MTQ3MTQ0NTY0Nywic3ViIjoiYWxsLjEyMyIsImV4cCI6MTQ3MTQ2MDA0NywibmJmIjoxNDcxNDQ1NjQ3LCJJRCI6IjU3OTBjODdhNGMwOGIwMDAzZDk3ODJmMCIsIlBLSUROIjoiYWxsLjEyMyIsIkZJUlNUX05BTUUiOiJBbGwiLCJMQVNUX05BTUUiOiJQZXJtaXNzaW9ucyIsIkVORFBPSU5UIjoiL1VzZXIvVjEvQXBpL3JlZ2lzdGVyIn0",
                    "Accept": "application/json, text/plain, */*"
                },
                "url": "http://localhost:8080/Dmles.Equipment.Server/V1/getEquipmentRecordSearchResults?searchValue=isotemp%20freezer%20(deleteInd%3AN)&aggregations=%7B%22aggregations%22%3A%20%5B%7B%22name%22%3A%22orgIds%22%2C%22field%22%3A%22orgId%22%2C%22size%22%3A%22300%22%7D%2C%7B%22name%22%3A%22nomenclatures%22%2C%22field%22%3A%22deviceText.raw%22%2C%22size%22%3A%225000%22%7D%7B%22name%22%3A%22manufacturers%22%2C%22field%22%3A%22manufOrgName.raw%22%2C%22size%22%3A%225500%22%7D%7B%22name%22%3A%22commonModels%22%2C%22field%22%3A%22manufMdlComnId.raw%22%2C%22size%22%3A%225000%22%7D%7B%22name%22%3A%22customerNames%22%2C%22field%22%3A%22custOrgNM.raw%22%2C%22size%22%3A%225000%22%7D%7B%22name%22%3A%22custOrgIds%22%2C%22field%22%3A%22custOrgId%22%2C%22size%22%3A%225000%22%7D%7B%22name%22%3A%22custodianNames%22%2C%22field%22%3A%22custodianName.raw%22%2C%22size%22%3A%225000%22%7D%5D%7D"
            },
            "statusText": "OK"
        };

        mock.deferred.resolve(mockResponse);
        mock.$scope.$apply();


        expect(mock.EquipmentRecordService.getSummaryEquipmentRecords).toHaveBeenCalled();
        expect(mock.EquipmentRecordService.getSummaryEquipmentRecords).toHaveBeenCalledWith(searchInput, "(deleteInd:N)");

        expect(equipmentRecordSearchController.equipmentRecordSummarySearchResults.length).toBeGreaterThan(0);
    });

    it('Execute Search returns nothing with bad input', () => {
        var searchInput = "something made up";
        equipmentRecordSearchController.searchInput = searchInput;
        equipmentRecordSearchController.userSpecifiedFilters = [];

        spyOn(mock.EquipmentRecordService, "getSummaryEquipmentRecords").and.returnValue(mock.deferred.promise);

        equipmentRecordSearchController.executeSearch();

        var mockResponse = {
            "data": {
                "took": 29,
                "timed_out": false,
                "_shards": {
                    "total": 291,
                    "successful": 291,
                    "failed": 0
                },
                "hits": {
                    "total": 0,
                    "max_score": null,
                    "hits": []
                },
                "aggregations": {
                    "commonModels": {
                        "doc_count_error_upper_bound": 0,
                        "sum_other_doc_count": 0,
                        "buckets": []
                    },
                    "orgIds": {
                        "doc_count_error_upper_bound": 0,
                        "sum_other_doc_count": 0,
                        "buckets": []
                    },
                    "manufacturers": {
                        "doc_count_error_upper_bound": 0,
                        "sum_other_doc_count": 0,
                        "buckets": []
                    },
                    "custodianNames": {
                        "doc_count_error_upper_bound": 0,
                        "sum_other_doc_count": 0,
                        "buckets": []
                    },
                    "nomenclatures": {
                        "doc_count_error_upper_bound": 0,
                        "sum_other_doc_count": 0,
                        "buckets": []
                    },
                    "customerNames": {
                        "doc_count_error_upper_bound": 0,
                        "sum_other_doc_count": 0,
                        "buckets": []
                    },
                    "custOrgIds": {
                        "doc_count_error_upper_bound": 0,
                        "sum_other_doc_count": 0,
                        "buckets": []
                    }
                }
            },
            "status": 200,
            "config": {
                "method": "GET",
                "transformRequest": [
                    null
                ],
                "transformResponse": [
                    null
                ],
                "headers": {
                    "Authorization": "Token eyJ0eXAiOiJKV1QifQ.eyJqdGkiOiJmMDdlZWIwMS02MTI4LTQxYzYtODNmZC04YmU2ZWZjMDIxMmYiLCJpc3MiOiJkbWxlcyIsImlhdCI6MTQ3MTQ0NTY0Nywic3ViIjoiYWxsLjEyMyIsImV4cCI6MTQ3MTQ2MDA0NywibmJmIjoxNDcxNDQ1NjQ3LCJJRCI6IjU3OTBjODdhNGMwOGIwMDAzZDk3ODJmMCIsIlBLSUROIjoiYWxsLjEyMyIsIkZJUlNUX05BTUUiOiJBbGwiLCJMQVNUX05BTUUiOiJQZXJtaXNzaW9ucyIsIkVORFBPSU5UIjoiL1VzZXIvVjEvQXBpL3JlZ2lzdGVyIn0",
                    "Accept": "application/json, text/plain, */*"
                },
                "url": "http://jw8dmles102:8080/Dmles.Equipment.Server/V1/getEquipmentRecordSearchResults?searchValue=something%20made%20up%20(deleteInd%3AN)&aggregations=%7B%22aggregations%22%3A%20%5B%7B%22name%22%3A%22orgIds%22%2C%22field%22%3A%22orgId%22%2C%22size%22%3A%22300%22%7D%2C%7B%22name%22%3A%22nomenclatures%22%2C%22field%22%3A%22deviceText.raw%22%2C%22size%22%3A%225000%22%7D%7B%22name%22%3A%22manufacturers%22%2C%22field%22%3A%22manufOrgName.raw%22%2C%22size%22%3A%225500%22%7D%7B%22name%22%3A%22commonModels%22%2C%22field%22%3A%22manufMdlComnId.raw%22%2C%22size%22%3A%225000%22%7D%7B%22name%22%3A%22customerNames%22%2C%22field%22%3A%22custOrgNM.raw%22%2C%22size%22%3A%225000%22%7D%7B%22name%22%3A%22custOrgIds%22%2C%22field%22%3A%22custOrgId%22%2C%22size%22%3A%225000%22%7D%7B%22name%22%3A%22custodianNames%22%2C%22field%22%3A%22custodianName.raw%22%2C%22size%22%3A%225000%22%7D%5D%7D"
            },
            "statusText": "OK"
        };

        mock.deferred.resolve(mockResponse);
        mock.$scope.$apply();


        expect(mock.EquipmentRecordService.getSummaryEquipmentRecords).toHaveBeenCalled();
        expect(mock.EquipmentRecordService.getSummaryEquipmentRecords).toHaveBeenCalledWith(searchInput, "(deleteInd:N)");

        expect(equipmentRecordSearchController.equipmentRecordSummarySearchResults.length).toBe(0);
    });

    it('The equipmentRecordSearch controller AcquisitionDateRangeFilterWatcher function gets called', () => {
        spyOn(equipmentRecordSearchController, "executeSearch").and.returnValue(mock.deferred.promise);
        equipmentRecordSearchController.AcquisitionDateRangeFilterService.doSearch = false;
        equipmentRecordSearchController.$scope.$apply();
        equipmentRecordSearchController.AcquisitionDateRangeFilterService.doSearch = true;
        equipmentRecordSearchController.$scope.$apply();
        expect(equipmentRecordSearchController.executeSearch).toHaveBeenCalled();
    });

    it('The equipmentRecordSearch controller resetFilters function works', () => {
        spyOn(equipmentRecordSearchController, "resetFilters").and.callThrough();
        equipmentRecordSearchController.resetFilters();
        expect(equipmentRecordSearchController.resetFilters).toHaveBeenCalled();
    });

    it('The equipmentRecordSearch controller retrieveDetailsForSelectedRecords function works', () => {
        equipmentRecordSearchController.DetailsPaginationService.selectedSearchResults = [{
            "_id": "",
            "meId": 6678,
            "selected": true,
            "detailsRetrieved": false,
            "shortItemDesc": "DDRS SYSTEM",
            "longItemDesc": "",
            "equipmentStatus": "Active",
            "orgId": "FM5270",
            "ecn": "013375",
            "nomenclature": "INFORMATION SYSTEM, PICTURE ARCHIVING AND COMMUNICATION",
            "itemId": "DDRSSYSTEM",
            "deviceClass": "INFORMATION SYSTEMS, PICTURE ARCHIVING AND COMMUNICATION",
            "manufacturer": "DELL INC",
            "division": 8330,
            "nameplateModel": "SERVER",
            "commonModel": "132.15.15.139",
            "manufacturerSerialNumber": "SERVER",
            "acquisitionCost": 91769,
            "lifeExpectancy": "6 YEARS",
            "assetControlNumber": "",
            "acquisitionCommodityClass": "EQUIPMENT-EXPENSE MEDICAL",
            "equipmentType": "SYSTEM",
            "systemEcn": null,
            "accountingStatus": "IN SERVICE",
            "isAccountableEquipment": true,
            "isMaintenanceRequired": true,
            "ownership": "ORGANIZATIONAL",
            "condition": "SERVICEABLE (ISSUABLE WITHOUT QUALIFICATION)",
            "organization": "18TH MEDICAL GROUP",
            "customerName": "DENTAL CLINIC",
            "customerId": "545511",
            "custodianName": "THOMPSON, XAVIER",
            "custodianPhone": "630-4857",
            "subcustodianName": "",
            "subcustodianPhone": "",
            "assemblageOrganization": "",
            "assemblageDescription": "",
            "assemblageNumber": "",
            "isOnLoan": false,
            "building": "00626 - MEDICAL/DENTAL CLINIC",
            "floor": "",
            "room": "",
            "equipmentLocation": "UG25",
            "temporaryLocation": "",
            "locationId": "",
            "rfidTag": "",
            "rfLocation": "",
            "subLocation": "",
            "inventoryPerformedBy": "SSGT PHAN BRIAN",
            "inventoryLocation": "",
            "inventoryEntryMethod": "WORK ORDER",
            "inventoryReason": "ROUTINE",
            "approvalReference": "",
            "acquisitionSpeciality": " - ",
            "replacementRequestNumber": "",
            "transactionReason": "ACCOUNTABILITY CHANGED TO REQUIRED",
            "sourceOfSupply": " - ",
            "contractNumber": "",
            "documentNumber": "FM527091259500",
            "receivedFromDocumentNumber": "",
            "accumulatedDepreciation": 0,
            "cfoAssetClassification": "GENERAL",
            "acquisitionFundCode": "2X",
            "iuid": "LDFM5270SERVERSERVER",
            "uiiType": "VIRTUAL",
            "uiiStatus": "REPORTED",
            "isUiiLabelAffixed": false,
            "userName": "",
            "maintenanceActivity": "MEDICAL EQUIPMENT REPAIR CENTER",
            "scheduledTeam": "CLINIC",
            "unscheduledTeam": "CLINIC",
            "otherGovernmentAgency": "",
            "contractor": "",
            "siteId": "",
            "firmwareNumber": "",
            "riskLevel": "NO SIGNIFICANT RISK",
            "schedulingFactor": "CUSTOMER",
            "equipmentReadinessCode": " - ",
            "maintenanceAssessment": "GOOD",
            "operationalStatus": "In Use",
            "procedureNumber": 3013,
            "outstandingWorkOrders": 0,
            "modifications": 0,
            "maximumExpenditureLimit": 9176.9,
            "maximumRepairLimitCumulative": 114518,
            "containsPatientData": true,
            "clinicalAlarmIndicator": false,
            "lifeSafety": false,
            "suspendScheduledWorkOrders": false,
            "tmde": false,
            "downStatus": false,
            "suspendReason": "",
            "maintenancePlan": [
                {
                    "maintenanceType": "INSPECTION",
                    "interval": "12 MONTHS",
                    "dateDue": "2016-07-01T00:00:00.000Z",
                    "dateLastServiced": "2015-07-07T00:00:00.000Z",
                    "$$hashKey": "object:5996"
                },
                {
                    "maintenanceType": "PREVENTIVE MAINTENANCE",
                    "interval": "",
                    "dateDue": null,
                    "dateLastServiced": null,
                    "$$hashKey": "object:5997"
                },
                {
                    "maintenanceType": "CALIBRATION",
                    "interval": "",
                    "dateDue": null,
                    "dateLastServiced": null,
                    "$$hashKey": "object:5998"
                },
                {
                    "maintenanceType": "SCHEDULED PARTS REPLACEMENT",
                    "interval": "",
                    "dateDue": null,
                    "dateLastServiced": null,
                    "$$hashKey": "object:5999"
                }
            ],
            "maintenanceCostHistory": [
                {
                    "fiscalYearDate": "FY 2009",
                    "downTime": 0,
                    "unscheduledWorkOrders": 1,
                    "organizationalPartsCost": "$0.00",
                    "organizationalUnscheduledTime": "1.00",
                    "organizationalUnscheduledLaborCost": "$34.04",
                    "organizationalScheduledTime": "0.50",
                    "organizationalScheduledLaborCost": "$17.02",
                    "totalOrganizationCost": "$51.06",
                    "contractPartsCost": "$0.00",
                    "contractUnscheduledTime": "0.00",
                    "contractUnscheduledLaborCost": "$0.00",
                    "contractScheduledTime": "0.00",
                    "contractScheduledLaborCost": "$0.00",
                    "totalContractCost": "$0.00",
                    "totalMaintenanceCost": "$51.06"
                },
                {
                    "fiscalYearDate": "FY 2010",
                    "downTime": 0,
                    "unscheduledWorkOrders": 0,
                    "organizationalPartsCost": "$0.00",
                    "organizationalUnscheduledTime": "0.00",
                    "organizationalUnscheduledLaborCost": "$0.00",
                    "organizationalScheduledTime": "0.50",
                    "organizationalScheduledLaborCost": "$18.47",
                    "totalOrganizationCost": "$18.47",
                    "contractPartsCost": "$0.00",
                    "contractUnscheduledTime": "0.00",
                    "contractUnscheduledLaborCost": "$0.00",
                    "contractScheduledTime": "0.00",
                    "contractScheduledLaborCost": "$0.00",
                    "totalContractCost": "$0.00",
                    "totalMaintenanceCost": "$18.47"
                },
                {
                    "fiscalYearDate": "FY 2011",
                    "downTime": 0,
                    "unscheduledWorkOrders": 0,
                    "organizationalPartsCost": "$0.00",
                    "organizationalUnscheduledTime": "0.00",
                    "organizationalUnscheduledLaborCost": "$0.00",
                    "organizationalScheduledTime": "1.00",
                    "organizationalScheduledLaborCost": "$37.73",
                    "totalOrganizationCost": "$37.73",
                    "contractPartsCost": "$0.00",
                    "contractUnscheduledTime": "0.00",
                    "contractUnscheduledLaborCost": "$0.00",
                    "contractScheduledTime": "0.00",
                    "contractScheduledLaborCost": "$0.00",
                    "totalContractCost": "$0.00",
                    "totalMaintenanceCost": "$37.73"
                },
                {
                    "fiscalYearDate": "FY 2012",
                    "downTime": 0,
                    "unscheduledWorkOrders": 0,
                    "organizationalPartsCost": "$0.00",
                    "organizationalUnscheduledTime": "0.00",
                    "organizationalUnscheduledLaborCost": "$0.00",
                    "organizationalScheduledTime": "0.50",
                    "organizationalScheduledLaborCost": "$19.50",
                    "totalOrganizationCost": "$19.50",
                    "contractPartsCost": "$0.00",
                    "contractUnscheduledTime": "0.00",
                    "contractUnscheduledLaborCost": "$0.00",
                    "contractScheduledTime": "0.00",
                    "contractScheduledLaborCost": "$0.00",
                    "totalContractCost": "$0.00",
                    "totalMaintenanceCost": "$19.50"
                },
                {
                    "fiscalYearDate": "FY 2013",
                    "downTime": 0,
                    "unscheduledWorkOrders": 0,
                    "organizationalPartsCost": "$0.00",
                    "organizationalUnscheduledTime": "0.00",
                    "organizationalUnscheduledLaborCost": "$0.00",
                    "organizationalScheduledTime": "1.00",
                    "organizationalScheduledLaborCost": "$38.80",
                    "totalOrganizationCost": "$38.80",
                    "contractPartsCost": "$0.00",
                    "contractUnscheduledTime": "0.00",
                    "contractUnscheduledLaborCost": "$0.00",
                    "contractScheduledTime": "0.00",
                    "contractScheduledLaborCost": "$0.00",
                    "totalContractCost": "$0.00",
                    "totalMaintenanceCost": "$38.80"
                },
                {
                    "fiscalYearDate": "FY 2014",
                    "downTime": 0,
                    "unscheduledWorkOrders": 0,
                    "organizationalPartsCost": "$0.00",
                    "organizationalUnscheduledTime": "0.00",
                    "organizationalUnscheduledLaborCost": "$0.00",
                    "organizationalScheduledTime": "0.50",
                    "organizationalScheduledLaborCost": "$19.67",
                    "totalOrganizationCost": "$19.67",
                    "contractPartsCost": "$0.00",
                    "contractUnscheduledTime": "0.00",
                    "contractUnscheduledLaborCost": "$0.00",
                    "contractScheduledTime": "0.00",
                    "contractScheduledLaborCost": "$0.00",
                    "totalContractCost": "$0.00",
                    "totalMaintenanceCost": "$19.67"
                },
                {
                    "fiscalYearDate": "FY 2015",
                    "downTime": 0,
                    "unscheduledWorkOrders": 0,
                    "organizationalPartsCost": "$0.00",
                    "organizationalUnscheduledTime": "0.00",
                    "organizationalUnscheduledLaborCost": "$0.00",
                    "organizationalScheduledTime": "0.20",
                    "organizationalScheduledLaborCost": "$8.02",
                    "totalOrganizationCost": "$8.02",
                    "contractPartsCost": "$0.00",
                    "contractUnscheduledTime": "0.00",
                    "contractUnscheduledLaborCost": "$0.00",
                    "contractScheduledTime": "0.00",
                    "contractScheduledLaborCost": "$0.00",
                    "totalContractCost": "$0.00",
                    "totalMaintenanceCost": "$8.02"
                },
                {
                    "fiscalYearDate": "FY 2016",
                    "downTime": 0,
                    "unscheduledWorkOrders": 0,
                    "organizationalPartsCost": "$0.00",
                    "organizationalUnscheduledTime": "0.00",
                    "organizationalUnscheduledLaborCost": "$0.00",
                    "organizationalScheduledTime": "0.00",
                    "organizationalScheduledLaborCost": "$0.00",
                    "totalOrganizationCost": "$0.00",
                    "contractPartsCost": "$0.00",
                    "contractUnscheduledTime": "0.00",
                    "contractUnscheduledLaborCost": "$0.00",
                    "contractScheduledTime": "0.00",
                    "contractScheduledLaborCost": "$0.00",
                    "totalContractCost": "$0.00",
                    "totalMaintenanceCost": "$0.00"
                }
            ],
            "totalSystemAcquisitionCost": 0,
            "totalMaintenanceCost": 386.50000000000006,
            "totalDownTime": 0,
            "totalMaintenanceUnscheduledWorkOrders": 2,
            "totalOrganizationalCosts": {
                "partsCost": 0,
                "unscheduledTime": 2,
                "unscheduledLaborCost": 68.08,
                "scheduledTime": 8.399999999999999,
                "scheduledLaborCost": 318.42,
                "totalCost": 386.50000000000006
            },
            "totalContractCosts": {
                "partsCost": 0,
                "unscheduledTime": 0,
                "unscheduledLaborCost": 0,
                "scheduledTime": 0,
                "scheduledLaborCost": 0,
                "totalCost": 0
            },
            "components": [
                {
                    "ecn": "013376",
                    "itemId": "MEDICOR",
                    "nomenclature": "SERVER, FILE",
                    "manufacturer": "DELL INC",
                    "manufacturerSerialNumber": "31DK7C1",
                    "nameplateModel": "POWEREDGE 2950",
                    "commonModel": "132.15.15.139",
                    "acquisitionCost": "$66,909.00"
                }
            ],
            "notes": [],
            "deviceText": "",
            "manufacturerNm": "",
            "supplierNm": "",
            "acquisitionDate": "2009-05-05T04:00:00.000Z",
            "$$hashKey": "object:4704",
            "detailsFound": true,
            "accountingStatusDate": "2013-10-26T04:00:00.000Z",
            "loanReturnDate": null,
            "equipmentReturnDate": null,
            "rfDate": "",
            "lastInventoryDate": "2015-07-07T19:13:57.000Z",
            "installationDate": null,
            "warrantyBeginDate": null,
            "warrantyEndDateLabor": null,
            "warrantyEndDateParts": null,
            "uiiStatusDate": "2014-05-31T02:40:39.000Z",
            "uiiAffixedDate": null,
            "dateLastServiced": "2015-07-07T04:00:00.000Z"
        }];
        spyOn(equipmentRecordSearchController, "retrieveDetailsForSelectedRecords").and.callThrough();
        equipmentRecordSearchController.retrieveDetailsForSelectedRecords();
        expect(equipmentRecordSearchController.retrieveDetailsForSelectedRecords).toHaveBeenCalled();
    });

    it('The equipmentRecordSearch controller goToEquipmentRecordDetails function, with equipmentRecord.selected = false, works', () => {
        var equipmentRecord = {
            "_id": "",
            "meId": 6678,
            "selected": false,
            "detailsRetrieved": false,
            "shortItemDesc": "DDRS SYSTEM",
            "longItemDesc": "",
            "equipmentStatus": "Active",
            "orgId": "FM5270",
            "ecn": "013375",
            "nomenclature": "INFORMATION SYSTEM, PICTURE ARCHIVING AND COMMUNICATION",
            "itemId": "DDRSSYSTEM",
            "deviceClass": "INFORMATION SYSTEMS, PICTURE ARCHIVING AND COMMUNICATION",
            "manufacturer": "DELL INC",
            "division": 8330,
            "nameplateModel": "SERVER",
            "commonModel": "132.15.15.139",
            "manufacturerSerialNumber": "SERVER",
            "acquisitionCost": 91769,
            "lifeExpectancy": "6 YEARS",
            "assetControlNumber": "",
            "acquisitionCommodityClass": "EQUIPMENT-EXPENSE MEDICAL",
            "equipmentType": "SYSTEM",
            "systemEcn": null,
            "accountingStatus": "IN SERVICE",
            "isAccountableEquipment": true,
            "isMaintenanceRequired": true,
            "ownership": "ORGANIZATIONAL",
            "condition": "SERVICEABLE (ISSUABLE WITHOUT QUALIFICATION)",
            "organization": "18TH MEDICAL GROUP",
            "customerName": "DENTAL CLINIC",
            "customerId": "545511",
            "custodianName": "THOMPSON, XAVIER",
            "custodianPhone": "630-4857",
            "subcustodianName": "",
            "subcustodianPhone": "",
            "assemblageOrganization": "",
            "assemblageDescription": "",
            "assemblageNumber": "",
            "isOnLoan": false,
            "building": "00626 - MEDICAL/DENTAL CLINIC",
            "floor": "",
            "room": "",
            "equipmentLocation": "UG25",
            "temporaryLocation": "",
            "locationId": "",
            "rfidTag": "",
            "rfLocation": "",
            "subLocation": "",
            "inventoryPerformedBy": "SSGT PHAN BRIAN",
            "inventoryLocation": "",
            "inventoryEntryMethod": "WORK ORDER",
            "inventoryReason": "ROUTINE",
            "approvalReference": "",
            "acquisitionSpeciality": " - ",
            "replacementRequestNumber": "",
            "transactionReason": "ACCOUNTABILITY CHANGED TO REQUIRED",
            "sourceOfSupply": " - ",
            "contractNumber": "",
            "documentNumber": "FM527091259500",
            "receivedFromDocumentNumber": "",
            "accumulatedDepreciation": 0,
            "cfoAssetClassification": "GENERAL",
            "acquisitionFundCode": "2X",
            "iuid": "LDFM5270SERVERSERVER",
            "uiiType": "VIRTUAL",
            "uiiStatus": "REPORTED",
            "isUiiLabelAffixed": false,
            "userName": "",
            "maintenanceActivity": "MEDICAL EQUIPMENT REPAIR CENTER",
            "scheduledTeam": "CLINIC",
            "unscheduledTeam": "CLINIC",
            "otherGovernmentAgency": "",
            "contractor": "",
            "siteId": "",
            "firmwareNumber": "",
            "riskLevel": "NO SIGNIFICANT RISK",
            "schedulingFactor": "CUSTOMER",
            "equipmentReadinessCode": " - ",
            "maintenanceAssessment": "GOOD",
            "operationalStatus": "In Use",
            "procedureNumber": 3013,
            "outstandingWorkOrders": 0,
            "modifications": 0,
            "maximumExpenditureLimit": 9176.9,
            "maximumRepairLimitCumulative": 114518,
            "containsPatientData": true,
            "clinicalAlarmIndicator": false,
            "lifeSafety": false,
            "suspendScheduledWorkOrders": false,
            "tmde": false,
            "downStatus": false,
            "suspendReason": "",
            "maintenancePlan": [
                {
                    "maintenanceType": "INSPECTION",
                    "interval": "12 MONTHS",
                    "dateDue": "2016-07-01T00:00:00.000Z",
                    "dateLastServiced": "2015-07-07T00:00:00.000Z",
                    "$$hashKey": "object:5996"
                },
                {
                    "maintenanceType": "PREVENTIVE MAINTENANCE",
                    "interval": "",
                    "dateDue": null,
                    "dateLastServiced": null,
                    "$$hashKey": "object:5997"
                },
                {
                    "maintenanceType": "CALIBRATION",
                    "interval": "",
                    "dateDue": null,
                    "dateLastServiced": null,
                    "$$hashKey": "object:5998"
                },
                {
                    "maintenanceType": "SCHEDULED PARTS REPLACEMENT",
                    "interval": "",
                    "dateDue": null,
                    "dateLastServiced": null,
                    "$$hashKey": "object:5999"
                }
            ],
            "maintenanceCostHistory": [
                {
                    "fiscalYearDate": "FY 2009",
                    "downTime": 0,
                    "unscheduledWorkOrders": 1,
                    "organizationalPartsCost": "$0.00",
                    "organizationalUnscheduledTime": "1.00",
                    "organizationalUnscheduledLaborCost": "$34.04",
                    "organizationalScheduledTime": "0.50",
                    "organizationalScheduledLaborCost": "$17.02",
                    "totalOrganizationCost": "$51.06",
                    "contractPartsCost": "$0.00",
                    "contractUnscheduledTime": "0.00",
                    "contractUnscheduledLaborCost": "$0.00",
                    "contractScheduledTime": "0.00",
                    "contractScheduledLaborCost": "$0.00",
                    "totalContractCost": "$0.00",
                    "totalMaintenanceCost": "$51.06"
                },
                {
                    "fiscalYearDate": "FY 2010",
                    "downTime": 0,
                    "unscheduledWorkOrders": 0,
                    "organizationalPartsCost": "$0.00",
                    "organizationalUnscheduledTime": "0.00",
                    "organizationalUnscheduledLaborCost": "$0.00",
                    "organizationalScheduledTime": "0.50",
                    "organizationalScheduledLaborCost": "$18.47",
                    "totalOrganizationCost": "$18.47",
                    "contractPartsCost": "$0.00",
                    "contractUnscheduledTime": "0.00",
                    "contractUnscheduledLaborCost": "$0.00",
                    "contractScheduledTime": "0.00",
                    "contractScheduledLaborCost": "$0.00",
                    "totalContractCost": "$0.00",
                    "totalMaintenanceCost": "$18.47"
                },
                {
                    "fiscalYearDate": "FY 2011",
                    "downTime": 0,
                    "unscheduledWorkOrders": 0,
                    "organizationalPartsCost": "$0.00",
                    "organizationalUnscheduledTime": "0.00",
                    "organizationalUnscheduledLaborCost": "$0.00",
                    "organizationalScheduledTime": "1.00",
                    "organizationalScheduledLaborCost": "$37.73",
                    "totalOrganizationCost": "$37.73",
                    "contractPartsCost": "$0.00",
                    "contractUnscheduledTime": "0.00",
                    "contractUnscheduledLaborCost": "$0.00",
                    "contractScheduledTime": "0.00",
                    "contractScheduledLaborCost": "$0.00",
                    "totalContractCost": "$0.00",
                    "totalMaintenanceCost": "$37.73"
                },
                {
                    "fiscalYearDate": "FY 2012",
                    "downTime": 0,
                    "unscheduledWorkOrders": 0,
                    "organizationalPartsCost": "$0.00",
                    "organizationalUnscheduledTime": "0.00",
                    "organizationalUnscheduledLaborCost": "$0.00",
                    "organizationalScheduledTime": "0.50",
                    "organizationalScheduledLaborCost": "$19.50",
                    "totalOrganizationCost": "$19.50",
                    "contractPartsCost": "$0.00",
                    "contractUnscheduledTime": "0.00",
                    "contractUnscheduledLaborCost": "$0.00",
                    "contractScheduledTime": "0.00",
                    "contractScheduledLaborCost": "$0.00",
                    "totalContractCost": "$0.00",
                    "totalMaintenanceCost": "$19.50"
                },
                {
                    "fiscalYearDate": "FY 2013",
                    "downTime": 0,
                    "unscheduledWorkOrders": 0,
                    "organizationalPartsCost": "$0.00",
                    "organizationalUnscheduledTime": "0.00",
                    "organizationalUnscheduledLaborCost": "$0.00",
                    "organizationalScheduledTime": "1.00",
                    "organizationalScheduledLaborCost": "$38.80",
                    "totalOrganizationCost": "$38.80",
                    "contractPartsCost": "$0.00",
                    "contractUnscheduledTime": "0.00",
                    "contractUnscheduledLaborCost": "$0.00",
                    "contractScheduledTime": "0.00",
                    "contractScheduledLaborCost": "$0.00",
                    "totalContractCost": "$0.00",
                    "totalMaintenanceCost": "$38.80"
                },
                {
                    "fiscalYearDate": "FY 2014",
                    "downTime": 0,
                    "unscheduledWorkOrders": 0,
                    "organizationalPartsCost": "$0.00",
                    "organizationalUnscheduledTime": "0.00",
                    "organizationalUnscheduledLaborCost": "$0.00",
                    "organizationalScheduledTime": "0.50",
                    "organizationalScheduledLaborCost": "$19.67",
                    "totalOrganizationCost": "$19.67",
                    "contractPartsCost": "$0.00",
                    "contractUnscheduledTime": "0.00",
                    "contractUnscheduledLaborCost": "$0.00",
                    "contractScheduledTime": "0.00",
                    "contractScheduledLaborCost": "$0.00",
                    "totalContractCost": "$0.00",
                    "totalMaintenanceCost": "$19.67"
                },
                {
                    "fiscalYearDate": "FY 2015",
                    "downTime": 0,
                    "unscheduledWorkOrders": 0,
                    "organizationalPartsCost": "$0.00",
                    "organizationalUnscheduledTime": "0.00",
                    "organizationalUnscheduledLaborCost": "$0.00",
                    "organizationalScheduledTime": "0.20",
                    "organizationalScheduledLaborCost": "$8.02",
                    "totalOrganizationCost": "$8.02",
                    "contractPartsCost": "$0.00",
                    "contractUnscheduledTime": "0.00",
                    "contractUnscheduledLaborCost": "$0.00",
                    "contractScheduledTime": "0.00",
                    "contractScheduledLaborCost": "$0.00",
                    "totalContractCost": "$0.00",
                    "totalMaintenanceCost": "$8.02"
                },
                {
                    "fiscalYearDate": "FY 2016",
                    "downTime": 0,
                    "unscheduledWorkOrders": 0,
                    "organizationalPartsCost": "$0.00",
                    "organizationalUnscheduledTime": "0.00",
                    "organizationalUnscheduledLaborCost": "$0.00",
                    "organizationalScheduledTime": "0.00",
                    "organizationalScheduledLaborCost": "$0.00",
                    "totalOrganizationCost": "$0.00",
                    "contractPartsCost": "$0.00",
                    "contractUnscheduledTime": "0.00",
                    "contractUnscheduledLaborCost": "$0.00",
                    "contractScheduledTime": "0.00",
                    "contractScheduledLaborCost": "$0.00",
                    "totalContractCost": "$0.00",
                    "totalMaintenanceCost": "$0.00"
                }
            ],
            "totalSystemAcquisitionCost": 0,
            "totalMaintenanceCost": 386.50000000000006,
            "totalDownTime": 0,
            "totalMaintenanceUnscheduledWorkOrders": 2,
            "totalOrganizationalCosts": {
                "partsCost": 0,
                "unscheduledTime": 2,
                "unscheduledLaborCost": 68.08,
                "scheduledTime": 8.399999999999999,
                "scheduledLaborCost": 318.42,
                "totalCost": 386.50000000000006
            },
            "totalContractCosts": {
                "partsCost": 0,
                "unscheduledTime": 0,
                "unscheduledLaborCost": 0,
                "scheduledTime": 0,
                "scheduledLaborCost": 0,
                "totalCost": 0
            },
            "components": [
                {
                    "ecn": "013376",
                    "itemId": "MEDICOR",
                    "nomenclature": "SERVER, FILE",
                    "manufacturer": "DELL INC",
                    "manufacturerSerialNumber": "31DK7C1",
                    "nameplateModel": "POWEREDGE 2950",
                    "commonModel": "132.15.15.139",
                    "acquisitionCost": "$66,909.00"
                }
            ],
            "notes": [],
            "deviceText": "",
            "manufacturerNm": "",
            "supplierNm": "",
            "acquisitionDate": "2009-05-05T04:00:00.000Z",
            "$$hashKey": "object:4704",
            "detailsFound": true,
            "accountingStatusDate": "2013-10-26T04:00:00.000Z",
            "loanReturnDate": null,
            "equipmentReturnDate": null,
            "rfDate": "",
            "lastInventoryDate": "2015-07-07T19:13:57.000Z",
            "installationDate": null,
            "warrantyBeginDate": null,
            "warrantyEndDateLabor": null,
            "warrantyEndDateParts": null,
            "uiiStatusDate": "2014-05-31T02:40:39.000Z",
            "uiiAffixedDate": null,
            "dateLastServiced": "2015-07-07T04:00:00.000Z"
        };
        spyOn(equipmentRecordSearchController, "goToEquipmentRecordDetails").and.callThrough();
        equipmentRecordSearchController.goToEquipmentRecordDetails(equipmentRecord);
        expect(equipmentRecordSearchController.goToEquipmentRecordDetails).toHaveBeenCalled();
    });
});

