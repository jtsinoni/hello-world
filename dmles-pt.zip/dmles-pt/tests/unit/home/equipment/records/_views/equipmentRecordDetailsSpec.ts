import "../../../../../../src/module";
import "../../../../../../src/home/module";
import "../../../../../../src/home/equipment/module";
import "../../../../../../src/home/equipment/records/module";
import "../../../../../../src/home/equipment/records/_services/module";
import "../../../../../../src/home/equipment/records/_views/module";

describe('Equipment Records _Views EquipmentRecordDetails.Controller Tests', () => {
    var equipmentRecordDetailsController;
    var mock;
    var myDetailsPaginationService;

    beforeEach(() => {
        module('DmlesModule');
        module('Dmles.Home.Module');
        module('Dmles.Equipment.Module');
        module('Dmles.Home.Equipment.Records.RecordsModule');
        module('Dmles.Home.Equipment.Records.Views.Module');

        inject(($rootScope, $controller, DetailsPaginationService) => {

            spyOn(DetailsPaginationService, 'checkDetailsFound').and.callFake(() => {
                return true;
            });
            myDetailsPaginationService = DetailsPaginationService;

            mock = {
                $scope: $rootScope.$new(),

                DetailsPaginationService: myDetailsPaginationService,
            };

            equipmentRecordDetailsController = $controller('EquipmentRecordDetailsController', mock);
        });
    });

    it('Has scope', () => {
        expect(mock.$scope).not.toEqual(undefined);
    });

    it('Has an DetailsPaginationService mock', () => {
        expect(mock.DetailsPaginationService).toBeDefined();
    });

    it('Has an equipmentRecordDetails controller', () => {
        expect(equipmentRecordDetailsController).toBeDefined();
    });

    it('The equipmentRecordDetails controller has a DetailsPaginationService service', () => {
        expect(equipmentRecordDetailsController.DetailsPaginationService).toBeDefined();
    });
});


