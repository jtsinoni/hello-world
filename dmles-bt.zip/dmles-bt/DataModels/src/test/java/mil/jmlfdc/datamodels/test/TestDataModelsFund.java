package mil.jmlfdc.datamodels.test;

import mil.jmlfdc.common.utils.MiscUtils;
import mil.jmlfdc.datamodels.fund.FundData;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;

public class TestDataModelsFund {
    
    private final Logger logger = LoggerFactory.getLogger(TestDataModelsFund.class);
    
    @Test
    public void getterSetterTest() {
        
        /* datamodels fund tests */
        MiscUtils.getterSetterTest(FundData.class, new ArrayList<String>() );
        
    }
    
    @Test
    public void fundDataTest() {
        
        FundData testFundData = new FundData();

        testFundData.setFundTypeCode("testcode");
        String fCodeRet = testFundData.getFundTypeCode();
        testFundData.setBudgetFiscalYear(0x7df);

    }
}
