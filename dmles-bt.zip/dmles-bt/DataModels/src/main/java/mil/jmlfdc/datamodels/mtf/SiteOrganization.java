package mil.jmlfdc.datamodels.mtf;

import java.util.ArrayList;
import java.util.List;

import org.mongodb.morphia.annotations.Embedded;
import org.mongodb.morphia.annotations.Entity;
import mil.jmlfdc.common.datamodel.MorphiaEntity;
import mil.jmlfdc.datamodels.mtf.EmAssociatedOrgId;

@Entity("SiteEquipOrganizations")
public class SiteOrganization extends MorphiaEntity {
    @Embedded
    private List<EmAssociatedOrgId> emAssociatedORGIDS = new ArrayList<>();
    private String emOrgID;
    private String emOrgName;
    private String emOrgSerial;
    private String siteDodaac;
    private String siteName;

    public SiteOrganization() { }

	public SiteOrganization(List<EmAssociatedOrgId> emAssociatedORGIDS) {
		this.emAssociatedORGIDS = emAssociatedORGIDS;
	}

    public String getEmOrgID() {
        return emOrgID;
    }

    public String getEmOrgName() {
        return emOrgName;
    }

    public String getEmOrgSerial() {
        return emOrgSerial;
    }

    public String getSiteDodaac() {
        return siteDodaac;
    }

    public String getSiteName() {
        return siteName;
    }

    public void setEmOrgID(String emOrgID) {
        this.emOrgID = emOrgID;
    }

    public void setEmOrgName(String emOrgName) {
        this.emOrgName = emOrgName;
    }

    public void setEmOrgSerial(String emOrgSerial) {
        this.emOrgSerial = emOrgSerial;
    }

    public void setSiteDodaac(String siteDodaac) {
        this.siteDodaac = siteDodaac;
    }

    public void setSiteName(String siteName) {
        this.siteName = siteName;
    }

    public List<EmAssociatedOrgId> getEmAssociatedORGIDS() {
	return emAssociatedORGIDS;
    }

    public void setEmAssociatedORGIDS(List<EmAssociatedOrgId> emAssociatedORGIDS) {
	this.emAssociatedORGIDS = emAssociatedORGIDS;
    }

}
