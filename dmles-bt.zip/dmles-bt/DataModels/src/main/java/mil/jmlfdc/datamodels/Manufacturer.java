package mil.jmlfdc.datamodels;

import org.mongodb.morphia.annotations.Embedded;

public class Manufacturer {

    public String name;
    @Embedded
    public Address corporateAddress = new Address();
}
