package mil.jmlfdc.datamodels.mtf;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.ElementCollection;

import org.mongodb.morphia.annotations.Embedded;

@Embedded
public class EmAssociatedOrgId implements Serializable {
    private static final long serialVersionUID = 1L;        

    @ElementCollection
    private List<CustomerId> customerIDs = new ArrayList<>();
    private String organizationID;
    private String organizationOrgName;
    private String organizationSerial;

    public List<CustomerId> getCustomerIDs() {
        return customerIDs;
    }
    public String getOrganizationID() {
        return organizationID;
    }

    public String getOrganizationOrgName() {
        return organizationOrgName;
    }

    public String getOrganizationSerial() {
        return organizationSerial;
    }

    public void setCustomerIds(List<CustomerId> customerIDs) {
        this.customerIDs = customerIDs;
    }
    public void setOrganizationID(String organizationID) {
        this.organizationID = organizationID;
    }

    public void setOrganizationOrgName(String organizationOrgName) {
        this.organizationOrgName = organizationOrgName;
    }

    public void setOrganizationSerial(String organizationSerial) {
        this.organizationSerial = organizationSerial;
    }

}
