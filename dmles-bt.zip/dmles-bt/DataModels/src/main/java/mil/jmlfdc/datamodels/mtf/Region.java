package mil.jmlfdc.datamodels.mtf;

import org.mongodb.morphia.annotations.Entity;
import mil.jmlfdc.common.datamodel.MorphiaEntity;

@Entity("Regions")
public class Region extends MorphiaEntity {

    private String regionID;
    private String regionName;

    public String getRegionID() {
        return regionID;
    }

    public String getRegionName() {
        return regionName;
    }

    public void setRegionID(String regionID) {
        this.regionID = regionID;
    }

    public void setRegionName(String regionName) {
        this.regionName = regionName;
    }

}
