package mil.jmlfdc.datamodels.mtf;

import java.io.Serializable;

import org.mongodb.morphia.annotations.Embedded;

@Embedded
public class CustomerId implements Serializable {
    private static final long serialVersionUID = 1L;     

    private String custodianFirstName;
    private String custodianLastName;
    private String custodianPhoneNum;
    private String customerID;
    private String customerName;
    private String customerSerial;

    public String getCustomerID() {
        return customerID;
    }

    public String getCustomerName() {
        return customerName;
    }

    public String getCustomerSerial() {
        return customerSerial;
    }

    public String getCustodianFirstName() {
        return custodianFirstName;
    }

    public String getCustodianLastName() {
        return custodianLastName;
    }

    public String getCustodianPhoneNum() {
        return custodianPhoneNum;
    }

    public void setCustomerID(String customerID) {
        this.customerID = customerID;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public void setCustomerSerial(String customerSerial) {
        this.customerSerial = customerSerial;
    }

    public void setCustodianFirstName(String custodianFirstName) {
        this.custodianFirstName = custodianFirstName;
    }

    public void setCustidianLastName(String custodianLastName) {
        this.custodianLastName = custodianLastName;
    }

    public void setCustodianPhoneNum(String custodianPhoneNum) {
        this.custodianPhoneNum = custodianPhoneNum;
    }

}
