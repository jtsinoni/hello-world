package mil.jmlfdc.datamodels.fund;

import java.io.Serializable;

import org.mongodb.morphia.annotations.Embedded;

@Embedded
public class FundData implements Serializable {
    private static final long serialVersionUID = 1L;         

    private String fundTypeCode;
    private Integer budgetFiscalYear;
    private String blockLineItemCode;
    private String acn;

    public String getFundTypeCode() {
        return fundTypeCode;
    }

    public void setFundTypeCode(String fundTypeCode) {
        this.fundTypeCode = fundTypeCode;
    }

    public Integer getBudgetFiscalYear() {
        return budgetFiscalYear;
    }

    public void setBudgetFiscalYear(Integer budgetFiscalYear) {
        this.budgetFiscalYear = budgetFiscalYear;
    }

    public String getBlockLineItemCode() {
        return blockLineItemCode;
    }

    public void setBlockLineItemCode(String blockLineItemCode) {
        this.blockLineItemCode = blockLineItemCode;
    }

    public String getAcn() {
        return acn;
    }

    public void setAcn(String acn) {
        this.acn = acn;
    }
    
}