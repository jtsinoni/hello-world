package mil.jmlfdc.datamodels;

public class LogicalResponse<T> {

    private T returnRequest;
    private String response;

    public LogicalResponse() {}
    
    public LogicalResponse(Boolean isLevelCompleted, T returnRequest, String response) {
        this.returnRequest = returnRequest;
        this.response = response;
    }

    public LogicalResponse(T returnRequest, String response) {
        this.returnRequest = returnRequest;
        this.response = response;
    }

    public T getReturnRequest() {
        return returnRequest;
    }

    public void setReturnRequest(T returnRequest) {
        this.returnRequest = returnRequest;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }
}
