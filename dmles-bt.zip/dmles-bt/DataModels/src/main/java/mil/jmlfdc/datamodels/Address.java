package mil.jmlfdc.datamodels;

public class Address {

    public String addressLine1;
    public String addressLine2;
    public String city;
    public String state;
    public String country;
    public String zipCode;
}
