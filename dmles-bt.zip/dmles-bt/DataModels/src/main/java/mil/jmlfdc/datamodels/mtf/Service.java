package mil.jmlfdc.datamodels.mtf;

import org.mongodb.morphia.annotations.Entity;
import mil.jmlfdc.common.datamodel.MorphiaEntity;

@Entity("Services")
public class Service extends MorphiaEntity {

    private String serviceID;
    private String serviceName;
    private String serviceBranch;
    private String serviceDESIG;

    public String getServiceID() {
        return serviceID;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceID(String serviceID) {
        this.serviceID = serviceID;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public String getServiceBranch() {
        return serviceBranch;
    }

    public void setServiceBranch(String serviceBranch) {
        this.serviceBranch = serviceBranch;
    }

    public String getServiceDESIG() {
        return serviceDESIG;
    }

    public void setServiceDESIG(String serviceDESIG) {
        this.serviceDESIG = serviceDESIG;
    }
}
