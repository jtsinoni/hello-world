package mil.jmlfdc.datamodels.mtf;

import org.mongodb.morphia.annotations.Entity;
import mil.jmlfdc.common.datamodel.MorphiaEntity;

@Entity("SiteRegions")
public class SiteRegion extends MorphiaEntity {

    private String description;
    private boolean dmlesEnabled;
    private String hostName;
    private String region;
    private String serviceBranch;
    private String serviceID;
    private String siteDodaac;
    private String siteName;

    public String getDescription() {
        return description;
    }

    public String getHostName() {
        return hostName;
    }

    public String getRegion() {
        return region;
    }

    public String getServiceBranch() {
        return serviceBranch;
    }

    public String getServiceID() {
        return serviceID;
    }

    public String getSiteDodaac() {
        return siteDodaac;
    }

    public String getSiteName() {
        return siteName;
    }

    public boolean isDmlesEnabled() {
        return dmlesEnabled;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setDmlesEnabled(boolean dmlesEnabled) {
        this.dmlesEnabled = dmlesEnabled;
    }

    public void setHostName(String hostName) {
        this.hostName = hostName;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public void setServiceBranch(String serviceBranch) {
        this.serviceBranch = serviceBranch;
    }

    public void setServiceID(String serviceID) {
        this.serviceID = serviceID;
    }

    public void setSiteDodaac(String siteDodaac) {
        this.siteDodaac = siteDodaac;
    }

    public void setSiteName(String siteName) {
        this.siteName = siteName;
    }
}
