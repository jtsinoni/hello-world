package dmles.assetmaintenance.client;

import dmles.assetmaintenance.core.IAssetMaintenanceService;
import mil.jmlfdc.common.business.RestClientFactory;
import javax.enterprise.context.Dependent;

@Dependent
public class AssetMaintenanceClientFactory extends RestClientFactory<IAssetMaintenanceService> {

    public AssetMaintenanceClientFactory(){
        super(IAssetMaintenanceService.class, "Dmles.AssetMaintenance.Server");
    }
}
