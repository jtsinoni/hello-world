package dmles.assetmaintenance.core.datamodels;

import com.fasterxml.jackson.annotation.JsonFormat;
import mil.jmlfdc.common.constants.DateAndTime;

import java.util.Date;

public class Ping {
    public String test;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateAndTime.DATE_TIME_PATTERN)
    public Date created = new Date();
} 
