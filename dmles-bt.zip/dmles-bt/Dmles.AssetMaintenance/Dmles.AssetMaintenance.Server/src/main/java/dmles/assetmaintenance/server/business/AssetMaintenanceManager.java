package dmles.assetmaintenance.server.business;

import mil.jmlfdc.common.datamodel.CurrentUserBT;
import dmles.assetmaintenance.core.datamodels.Ping;
import dmles.assetmaintenance.server.datamodels.PingDO;
import mil.jmlfdc.common.business.BusinessManager;
import mil.jmlfdc.common.utils.ObjectMapper;
import org.slf4j.Logger;

import javax.ejb.Stateless;
import javax.inject.Inject;

@Stateless
public class AssetMaintenanceManager extends BusinessManager {

    @Inject
    private Logger log;

    @Inject
    private ObjectMapper objectMapper;

    public Ping getPing(){
        log.info("Pinged the BT Manager!");
        log.info("User: {}", currentUserBt.getPkiDn());
        PingDO pingDo = new PingDO();
        return objectMapper.getObject(Ping.class, pingDo);
    }

}
