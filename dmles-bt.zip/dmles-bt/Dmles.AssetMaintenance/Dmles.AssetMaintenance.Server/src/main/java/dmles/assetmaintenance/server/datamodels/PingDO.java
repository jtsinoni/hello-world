package dmles.assetmaintenance.server.datamodels;

import com.fasterxml.jackson.annotation.JsonFormat;
import mil.jmlfdc.common.constants.DateAndTime;

import java.util.Date;

public class PingDO {

    private String test = "Ping!";
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateAndTime.DATE_TIME_PATTERN)
    private Date created = new Date();

    public PingDO() {
    }

    public String getTest() {
        return test;
    }

    public void setTest(String test) {
        this.test = test;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

}
