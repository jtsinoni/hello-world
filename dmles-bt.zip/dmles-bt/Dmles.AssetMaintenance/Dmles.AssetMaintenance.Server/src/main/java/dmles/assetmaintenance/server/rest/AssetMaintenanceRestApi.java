package dmles.assetmaintenance.server.rest;


import dmles.assetmaintenance.core.IAssetMaintenanceService;
import dmles.assetmaintenance.core.datamodels.Ping;
import dmles.assetmaintenance.server.business.AssetMaintenanceManager;
import mil.jmlfdc.common.rest.RestApiBase;

import io.swagger.annotations.Api;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

@Api(value = "AssetMaintenanceRestApi", description = "Asset Maintenance API")
@ApplicationScoped
public class AssetMaintenanceRestApi extends RestApiBase implements IAssetMaintenanceService {

    @Inject
    private AssetMaintenanceManager assetManager;

    @Override
    public Ping getPing() {
        return assetManager.getPing();
    }
}
