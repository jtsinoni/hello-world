package dmles.catalog.core.datamodel;

import java.util.ArrayList;
import java.util.List;

public class Packaging {
    public String ipPackCd;
    public Integer ipPackQty;
    public Double packPriceAmt;
    public Double burdenedPriceAmt;
    public Double taxAmt;
    public String ipGtin;
    public String nsn;
    public String priceEffDt;
    public String priceExpDt;
    public Integer ecatItemId;
    public Integer maximumOrderQty;
    public Integer minimumOrderQty;
    public Integer multipleOrderQty;
    public List<String> barcodes = new ArrayList<>();
}
