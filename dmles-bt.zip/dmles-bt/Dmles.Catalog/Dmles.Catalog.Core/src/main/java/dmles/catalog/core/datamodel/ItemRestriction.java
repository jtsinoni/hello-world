package dmles.catalog.core.datamodel;

public class ItemRestriction {
    public String restrictCd;
    public String restrictDescription;
    public String restrictType;
}
