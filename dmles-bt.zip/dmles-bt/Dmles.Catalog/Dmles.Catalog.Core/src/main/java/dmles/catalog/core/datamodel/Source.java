package dmles.catalog.core.datamodel;

import java.util.ArrayList;
import java.util.List;

public class Source {
    public Integer sosSerial;
    public String sosCd;
    public String sosTypeCd;
    public String supplierNm;
    public String typeItemId;
    public String vendItemNum;
    public Integer ipPackSerial;
    public String dropShipFeeInd;
    public String dropShipOnlyInd;

    // Embedded object arrays
    public List<Packaging> packaging = new ArrayList<>();
}
