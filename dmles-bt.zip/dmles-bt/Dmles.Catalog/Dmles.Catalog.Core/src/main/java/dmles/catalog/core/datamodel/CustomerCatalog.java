package dmles.catalog.core.datamodel;

public class CustomerCatalog {
    public String catalogName;
    public String orgId;
    public String orgNm;
}
