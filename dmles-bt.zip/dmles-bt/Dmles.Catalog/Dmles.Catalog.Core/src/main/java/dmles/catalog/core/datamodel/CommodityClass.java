package dmles.catalog.core.datamodel;

public class CommodityClass {
    public String commodityClassName;
    public String commodityType;
    public String militaryServiceCode;
}
