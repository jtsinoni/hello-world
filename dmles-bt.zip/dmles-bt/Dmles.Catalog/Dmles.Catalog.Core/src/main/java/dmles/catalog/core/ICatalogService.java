package dmles.catalog.core;

import dmles.catalog.core.datamodel.*;

import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

@Path("/V1/catalog")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public interface ICatalogService {

    @GET
    @Path("/getPing")
    PingData getPing();

    @GET
    @Path("/getSiteCatalogByEnterpriseId")
    List<SiteCatalogRecord> getSiteCatalogByEnterpriseId(@QueryParam("siteId") String siteId, @QueryParam("enterpriseProductIdentifier") String enterpriseProductIdentifier);

    @GET
    @Path("/getSiteCatalogByProductId")
    List<SiteCatalogRecord> getSiteCatalogByProductId(@QueryParam("siteId") String siteId, @QueryParam("productSeqId") Integer productSeqId);

    @GET
    @Path("/getSiteCatalogByItemId")
    List<SiteCatalogRecord> getSiteCatalogByItemId(@QueryParam("siteId") String siteId, @QueryParam("itemId") String itemId);

    @GET
    @Path("/getSiteCatalogByBarcode")
    List<SiteCatalogRecord> getSiteCatalogByBarcode(@QueryParam("siteId") String siteId, @QueryParam("barcode") String barcode);

    @GET
    @Path("/getCustomerCatalog")
    List<SiteCatalogRecord> getCustomerCatalog(@QueryParam("siteId") String siteId, @QueryParam("customerId") String customerId);

    @GET
    @Path("/getSupplierCatalog")
    List<SiteCatalogRecord> getSupplierCatalog(@QueryParam("siteId") String siteId, @QueryParam("supplierNm") String supplierNm);

    @GET
    @Path("/getCommodityClassList")
    List<CommodityClass> getCommodityClassList(@QueryParam("militaryServiceCode") String militaryServiceCode);

}