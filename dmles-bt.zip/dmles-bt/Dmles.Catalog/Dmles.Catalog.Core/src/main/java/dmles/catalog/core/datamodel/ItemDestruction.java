package dmles.catalog.core.datamodel;

public class ItemDestruction {
    public String destructCd;
    public String destructDesc;
}
