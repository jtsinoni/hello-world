package dmles.catalog.core.datamodel;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.util.Date;
import mil.jmlfdc.common.constants.DateAndTime;

public class Example {
    public Long id;
    public String firstName;
    public String lastName;
    public String comment;
    public String userId;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateAndTime.DATE_TIME_PATTERN)
    public Date created = new Date();
}