package dmles.catalog.core.datamodels;

import dmles.catalog.core.datamodel.Example;
import dmles.catalog.core.datamodel.PingData;
import mil.jmlfdc.common.utils.MiscUtils;

import org.junit.Test;

import java.util.ArrayList;

public class TestDataModels {

    @Test
    public void getterSetterTest() {
        MiscUtils.getterSetterTest(Example.class, new ArrayList<>());
        MiscUtils.getterSetterTest(PingData.class, new ArrayList<>());
    }
}
