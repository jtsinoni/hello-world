package dmles.catalog.server.datamodels;

import dmles.catalog.server.datamodel.ExampleDO;
import dmles.catalog.server.datamodel.PingDataDO;
import java.util.ArrayList;
import mil.jmlfdc.common.utils.MiscUtils;
import org.junit.Test;

public class TestDataModels {

    @Test
    public void getterSetterTest() {
        MiscUtils.getterSetterTest(ExampleDO.class, new ArrayList<>());
        MiscUtils.getterSetterTest(PingDataDO.class, new ArrayList<>());
    }

}