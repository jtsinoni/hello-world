package dmles.catalog.server.business;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dmles.catalog.core.datamodel.SiteCatalogRecord;
import dmles.catalog.server.dao.SiteCatalogRecordDao;
import dmles.catalog.server.datamodel.SiteCatalogRecordDO;
import dmles.catalog.core.datamodel.CommodityClass;
import dmles.catalog.server.dao.CommodityClassDao;
import dmles.catalog.server.datamodel.CommodityClassDO;
import mil.jmlfdc.common.utils.ObjectMapper;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;

public class CatalogManagerTest {

    @Mock
    private SiteCatalogRecordDao recordDao;
    @Mock
    private SiteCatalogRecordDO recordDO;
    @Mock
    private SiteCatalogRecord record;
    @Mock
    private CommodityClassDao commodityClassDao;
    @Mock
    private CommodityClassDO commodityClassDO;
    @Mock
    private CommodityClass commodityClass;
    @Mock
    private ObjectMapper mapper;
    @InjectMocks
    private CatalogManager manager;

    @Before
    public void setup() {
        manager = new CatalogManager();
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetSiteCatalogByItemId() {
        String siteId = "FM3029";
        String itemId = "6505001067397";
        List<SiteCatalogRecordDO> recordList = new ArrayList<>();

        recordList.add(recordDO);
        when(recordDao.getByItemId(siteId, itemId)).thenReturn(recordList);

        manager.getSiteCatalogByItemId(siteId, itemId);

        verify(recordDao).getByItemId(siteId, itemId);
        verify(mapper).getList(SiteCatalogRecord[].class, recordList);
    }

    @Test
    public void testGetSiteCatalogByEnterpriseId() {
        String siteId = "FM3029";
        String enterpriseProductId = "6505001067397";
        List<SiteCatalogRecordDO> recordList = new ArrayList<>();

        recordList.add(recordDO);
        when(recordDao.getByEnterpriseId(siteId, enterpriseProductId)).thenReturn(recordList);

        manager.getSiteCatalogByEnterpriseId(siteId, enterpriseProductId);

        verify(recordDao).getByEnterpriseId(siteId, enterpriseProductId);
        verify(mapper).getList(SiteCatalogRecord[].class, recordList);
    }

    @Test
    public void testGetSiteCatalogByProductId() {
        String siteId = "FM3029";
        Integer productSeqId = 3;
        List<SiteCatalogRecordDO> recordList = new ArrayList<>();

        recordList.add(recordDO);
        when(recordDao.getByProductSeqId(siteId, productSeqId)).thenReturn(recordList);

        manager.getSiteCatalogByProductId(siteId, productSeqId);

        verify(recordDao).getByProductSeqId(siteId, productSeqId);
        verify(mapper).getList(SiteCatalogRecord[].class, recordList);
    }

    @Test
    public void testGetSiteCatalogByBarcode() {
        String siteId = "FM3029";
        String barcode = "2 6505001067397 9";
        List<SiteCatalogRecordDO> recordList = new ArrayList<>();

        recordList.add(recordDO);
        when(recordDao.getByBarcode(siteId, barcode)).thenReturn(recordList);

        manager.getSiteCatalogByBarcode(siteId, barcode);

        verify(recordDao).getByBarcode(siteId, barcode);
        verify(mapper).getList(SiteCatalogRecord[].class, recordList);
    }

    @Test
    public void testGetSupplierCatalog() {
        String siteId = "FM3029";
        String supplierNm = "AMERISOURCE BERGEN";
        List<SiteCatalogRecordDO> recordList = new ArrayList<>();

        recordList.add(recordDO);
        when(recordDao.getBySupplier(siteId, supplierNm)).thenReturn(recordList);

        manager.getSupplierCatalog(siteId, supplierNm);

        verify(recordDao).getBySupplier(siteId, supplierNm);
        verify(mapper).getList(SiteCatalogRecord[].class, recordList);
    }

    @Test
    public void testGetCustomerCatalog() {
        String siteId = "FM3029";
        String customerId = "255610";
        List<SiteCatalogRecordDO> recordList = new ArrayList<>();

        recordList.add(recordDO);
        when(recordDao.getByCustomer(siteId, customerId)).thenReturn(recordList);

        manager.getCustomerCatalog(siteId, customerId);

        verify(recordDao).getByCustomer(siteId, customerId);
        verify(mapper).getList(SiteCatalogRecord[].class, recordList);
    }

    @Test
    public void testGetCommodityClassList() {
        String militaryServiceCode = "DF";
        List<CommodityClassDO> recordList = new ArrayList<>();

        recordList.add(commodityClassDO);
        when(commodityClassDao.getCommodityClasses(militaryServiceCode)).thenReturn(recordList);

        manager.getCommodityClassList(militaryServiceCode);

        verify(commodityClassDao).getCommodityClasses(militaryServiceCode);
        verify(mapper).getList(CommodityClass[].class, recordList);
    }

}
