package dmles.catalog.server.datamodel;

import org.mongodb.morphia.annotations.Embedded;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Embedded
public class PackagingDO implements Serializable {

    private static final long serialVersionUID = 1L;

    private String ipPackCd;
    private Integer ipPackQty;
    private Double packPriceAmt;
    private Double burdenedPriceAmt;
    private Double taxAmt;
    private String ipGtin;
    private String nsn;
    private String priceEffDt;
    private String priceExpDt;
    private Integer ecatItemId;
    private Integer maximumOrderQty;
    private Integer minimumOrderQty;
    private Integer multipleOrderQty;
    public List<String> barcodes = new ArrayList<>();

    public PackagingDO() {
    }

    public String getIpPackCd() {
        return ipPackCd;
    }

    public void setIpPackCd(String ipPackCd) {
        this.ipPackCd = ipPackCd;
    }

    public Integer getIpPackQty() {
        return ipPackQty;
    }

    public void setIpPackQty(Integer ipPackQty) {
        this.ipPackQty = ipPackQty;
    }

    public Double getPackPriceAmt() {
        return packPriceAmt;
    }

    public void setPackPriceAmt(Double packPriceAmt) {
        this.packPriceAmt = packPriceAmt;
    }

    public Double getBurdenedPriceAmt() {
        return burdenedPriceAmt;
    }

    public void setBurdenedPriceAmt(Double burdenedPriceAmt) {
        this.burdenedPriceAmt = burdenedPriceAmt;
    }

    public Double getTaxAmt() {
        return taxAmt;
    }

    public void setTaxAmt(Double taxAmt) {
        this.taxAmt = taxAmt;
    }

    public String getIpGtin() {
        return ipGtin;
    }

    public void setIpGtin(String ipGtin) {
        this.ipGtin = ipGtin;
    }

    public String getNsn() {
        return nsn;
    }

    public void setNsn(String nsn) {
        this.nsn = nsn;
    }

    public String getPriceEffDt() {
        return priceEffDt;
    }

    public void setPriceEffDt(String priceEffDt) {
        this.priceEffDt = priceEffDt;
    }

    public String getPriceExpDt() {
        return priceExpDt;
    }

    public void setPriceExpDt(String priceExpDt) {
        this.priceExpDt = priceExpDt;
    }

    public Integer getEcatItemId() {
        return ecatItemId;
    }

    public void setEcatItemId(Integer ecatItemId) {
        this.ecatItemId = ecatItemId;
    }

    public Integer getMaximumOrderQty() {
        return maximumOrderQty;
    }

    public void setMaximumOrderQty(Integer maximumOrderQty) {
        this.maximumOrderQty = maximumOrderQty;
    }

    public Integer getMinimumOrderQty() {
        return minimumOrderQty;
    }

    public void setMinimumOrderQty(Integer minimumOrderQty) {
        this.minimumOrderQty = minimumOrderQty;
    }

    public Integer getMultipleOrderQty() {
        return multipleOrderQty;
    }

    public void setMultipleOrderQty(Integer multipleOrderQty) {
        this.multipleOrderQty = multipleOrderQty;
    }

    public List<String> getBarcodes() {
        return barcodes;
    }

    public void setBarcodes(List<String> barcodes) {
        this.barcodes = barcodes;
    }
}
