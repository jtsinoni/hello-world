package dmles.catalog.server.dao;

import dmles.catalog.server.datamodel.PingDataDO;
import java.util.Date;
import javax.enterprise.context.Dependent;
import mil.jmlfdc.common.dao.BaseDao;

@Dependent
public class PingDataDao extends BaseDao<PingDataDO, String> {
    
    public PingDataDao() {
        super(PingDataDO.class);
    }
    
    public PingDataDO getPingData(String message) {
        PingDataDO test = new PingDataDO();
        test.setMessage(message);
        test.setCreatedDate(new Date());
        return test;
    }
    
}
