package dmles.catalog.server.utils;

import org.apache.deltaspike.core.api.config.PropertyFileConfig;

import javax.ejb.Singleton;
import javax.ejb.Startup;

@Singleton
@Startup
public class CatalogPropertyFileConfig implements PropertyFileConfig {

    private static final long serialVersionUID = -7762380573887097591L;

    @Override
    public String getPropertyFileName() {
        return "catalog.properties";
    }

}