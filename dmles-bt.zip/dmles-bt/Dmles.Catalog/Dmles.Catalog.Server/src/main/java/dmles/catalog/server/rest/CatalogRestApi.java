package dmles.catalog.server.rest;

import dmles.catalog.core.ICatalogService;
import dmles.catalog.core.datamodel.PingData;
import dmles.catalog.core.datamodel.CommodityClass;
import dmles.catalog.core.datamodel.SiteCatalogRecord;
import dmles.catalog.server.business.CatalogManager;
import io.swagger.annotations.Api;

import mil.jmlfdc.common.rest.RestApiBase;

import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.QueryParam;

@Api(value="CatalogRestApi", description="Catalog REST API")
@ApplicationScoped
public class CatalogRestApi extends RestApiBase implements ICatalogService {

    @Inject
    private CatalogManager CatalogManager;

    @Override
    public PingData getPing() {
        return CatalogManager.getPing();
    }

    @Override
    public List<SiteCatalogRecord> getSiteCatalogByEnterpriseId(@QueryParam("siteId") String siteId, @QueryParam("enterpriseProductIdentifier") String enterpriseProductIdentifier) {
        List<SiteCatalogRecord> recordList = CatalogManager.getSiteCatalogByEnterpriseId(siteId, enterpriseProductIdentifier);
        return recordList;
    }

    @Override
    public List<SiteCatalogRecord> getSiteCatalogByProductId(@QueryParam("siteId") String siteId, @QueryParam("productSeqId") Integer productSeqId) {
        List<SiteCatalogRecord> recordList = CatalogManager.getSiteCatalogByProductId(siteId, productSeqId);
        return recordList;
    }

    @Override
    public List<SiteCatalogRecord> getSiteCatalogByItemId(@QueryParam("siteId") String siteId, @QueryParam("itemId") String itemId) {
        List<SiteCatalogRecord> recordList = CatalogManager.getSiteCatalogByItemId(siteId, itemId);
        return recordList;
    }

    @Override
    public List<SiteCatalogRecord> getSiteCatalogByBarcode(@QueryParam("siteId") String siteId, @QueryParam("barcode") String barcode) {
        List<SiteCatalogRecord> recordList = CatalogManager.getSiteCatalogByBarcode(siteId, barcode);
        return recordList;
    }

    @Override
    public List<SiteCatalogRecord> getCustomerCatalog(@QueryParam("siteId") String siteId, @QueryParam("customerId") String customerId) {
        List<SiteCatalogRecord> recordList = CatalogManager.getCustomerCatalog(siteId, customerId);
        return recordList;
    }

    @Override
    public List<SiteCatalogRecord> getSupplierCatalog(@QueryParam("siteId") String siteId, @QueryParam("supplierNm") String supplierNm) {
        List<SiteCatalogRecord> recordList = CatalogManager.getSupplierCatalog(siteId, supplierNm);
        return recordList;
    }

    @Override
    public List<CommodityClass> getCommodityClassList(@QueryParam("militaryServiceCode") String militaryServiceCode) {
        List<CommodityClass> recordList = CatalogManager.getCommodityClassList(militaryServiceCode);
        return recordList;
    }

}
