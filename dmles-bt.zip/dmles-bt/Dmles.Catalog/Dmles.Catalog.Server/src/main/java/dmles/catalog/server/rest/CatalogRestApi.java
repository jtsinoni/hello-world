package dmles.catalog.server.rest;

import dmles.catalog.core.ICatalogService;
import dmles.catalog.core.datamodel.PingData;
import dmles.catalog.server.business.CatalogManager;
import io.swagger.annotations.Api;

import mil.jmlfdc.common.rest.RestApiBase;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

@Api
@ApplicationScoped
public class CatalogRestApi extends RestApiBase implements ICatalogService {

    @Inject
    private CatalogManager catalogManager;

    @Override
    public PingData getPing() {
        return catalogManager.getPing();
    }
}
