package dmles.catalog.server.dao;

import dmles.catalog.server.datamodel.SiteCatalogRecordDO;

import java.util.List;
import javax.enterprise.context.Dependent;
import javax.inject.Inject;

import mil.jmlfdc.common.dao.BaseDao;
import org.mongodb.morphia.query.Query;
import org.slf4j.Logger;

@Dependent
public class SiteCatalogRecordDao extends BaseDao<SiteCatalogRecordDO, String> {
    @Inject
    private Logger logger;

    public SiteCatalogRecordDao() {
        super(SiteCatalogRecordDO.class);
    }

    public List<SiteCatalogRecordDO> getByProductSeqId(String siteId, Integer productSeqId) {
        Query<SiteCatalogRecordDO> query = getQuery(SiteCatalogRecordDO.class);
        query.field("siteDodaac").equal(siteId);
        query.field("productSeqId").equal(productSeqId);
        return query.asList();
    }

    public List<SiteCatalogRecordDO> getByEnterpriseId(String siteId, String enterpriseProductIdentifier) {
        Query<SiteCatalogRecordDO> query = getQuery(SiteCatalogRecordDO.class);
        query.field("siteDodaac").equal(siteId);
        query.field("enterpriseProductIdentifier").equal(enterpriseProductIdentifier);
        return query.asList();
    }

    public List<SiteCatalogRecordDO> getByItemId(String siteId, String itemId) {
        Query<SiteCatalogRecordDO> query = getQuery(SiteCatalogRecordDO.class);
        query.field("siteDodaac").equal(siteId);
        query.field("itemId").equal(itemId);
        return query.asList();
    }

    public List<SiteCatalogRecordDO> getByBarcode(String siteId, String barcode) {
        Query<SiteCatalogRecordDO> query = getQuery(SiteCatalogRecordDO.class);
        query.field("siteDodaac").equal(siteId);
        query.field("sources.packaging.barcodes").equal(barcode);
        return query.asList();
    }

    public List<SiteCatalogRecordDO> getByCustomer(String siteId, String customerId) {
        Query<SiteCatalogRecordDO> query = getQuery(SiteCatalogRecordDO.class);
        query.field("siteDodaac").equal(siteId);
        query.field("customerCatalogs.orgId").equal(customerId);
        return query.asList();
    }

    public List<SiteCatalogRecordDO> getBySupplier(String siteId, String supplierNm) {
        Query<SiteCatalogRecordDO> query = getQuery(SiteCatalogRecordDO.class);
        query.field("siteDodaac").equal(siteId);
        query.field("sources.supplierNm").equal(supplierNm);
        return query.asList();
    }

}
