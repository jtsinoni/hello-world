package dmles.catalog.server.dao;

import dmles.catalog.server.datamodel.ExampleDO;
import javax.enterprise.context.Dependent;
import mil.jmlfdc.common.dao.BaseDao;

@Dependent
public class ExampleDao extends BaseDao<ExampleDO, String>{
    
    public ExampleDao() {
        super(ExampleDO.class);
    }
    
}
