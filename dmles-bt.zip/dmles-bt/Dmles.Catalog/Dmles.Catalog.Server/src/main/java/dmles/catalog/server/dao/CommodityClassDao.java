package dmles.catalog.server.dao;

import dmles.catalog.server.datamodel.CommodityClassDO;
import mil.jmlfdc.common.dao.BaseDao;
import org.mongodb.morphia.query.Query;

import java.util.List;
import javax.enterprise.context.Dependent;

@Dependent
public class CommodityClassDao extends BaseDao<CommodityClassDO, String> {

    public CommodityClassDao() {
        super(CommodityClassDO.class);
    }

    public List<CommodityClassDO> getCommodityClasses(String militaryServiceCode) {
        Query<CommodityClassDO> query = getQuery(CommodityClassDO.class);
        query.field("militaryServiceCode").equal(militaryServiceCode);
        return query.asList();
    }

}

