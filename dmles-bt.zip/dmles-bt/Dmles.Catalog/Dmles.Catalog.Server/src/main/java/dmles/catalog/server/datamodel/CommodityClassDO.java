package dmles.catalog.server.datamodel;

import mil.jmlfdc.common.datamodel.MorphiaEntity;
import org.mongodb.morphia.annotations.Entity;

import java.io.Serializable;

@Entity(value = "commodityClass", noClassnameStored = true)
public class CommodityClassDO extends MorphiaEntity implements Serializable {
    private static final long serialVersionUID = 1L;
    private String commodityClassName;
    private String commodityType;
    private String militaryServiceCode;

    public CommodityClassDO() {
    }

    public String getCommodityClassName() {
        return commodityClassName;
    }

    public void setCommodityClassName(String commodityClassName) {
        this.commodityClassName = commodityClassName;
    }

    public String getCommodityType() {
        return commodityType;
    }

    public void setCommodityType(String commodityType) {
        this.commodityType = commodityType;
    }

    public String getMilitaryServiceCode() {
        return militaryServiceCode;
    }

    public void setMilitaryServiceCode(String militaryServiceCode) {
        this.militaryServiceCode = militaryServiceCode;
    }
}
