package dmles.catalog.server.datamodel;

import org.mongodb.morphia.annotations.Embedded;

import java.io.Serializable;

@Embedded
public class CustomerCatalogDO implements Serializable {
    private static final long serialVersionUID = 1L;
    private String catalogName;
    private String orgId;
    private String orgNm;

    public CustomerCatalogDO() {
    }

    public String getCatalogName() {
        return catalogName;
    }

    public void setCatalogName(String catalogName) {
        this.catalogName = catalogName;
    }

    public String getOrgId() {
        return orgId;
    }

    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    public String getOrgNm() {
        return orgNm;
    }

    public void setOrgNm(String orgNm) {
        this.orgNm = orgNm;
    }
}
