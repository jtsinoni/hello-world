package dmles.catalog.server.datamodel;

import org.mongodb.morphia.annotations.Embedded;

import java.io.Serializable;

@Embedded
public class ItemDestructionDO implements Serializable {
    private static final long serialVersionUID = 1L;
    private String destructCd;
    private String destructDesc;

    public ItemDestructionDO() {
    }

    public String getDestructCd() {
        return destructCd;
    }

    public void setDestructCd(String destructCd) {
        this.destructCd = destructCd;
    }

    public String getDestructDesc() {
        return destructDesc;
    }

    public void setDestructDesc(String destructDesc) {
        this.destructDesc = destructDesc;
    }
}
