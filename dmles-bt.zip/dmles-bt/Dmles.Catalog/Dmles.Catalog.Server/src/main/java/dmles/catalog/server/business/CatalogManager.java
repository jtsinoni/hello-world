package dmles.catalog.server.business;

import dmles.catalog.core.datamodel.PingData;
import dmles.catalog.server.dao.PingDataDao;
import dmles.catalog.server.datamodel.PingDataDO;
import mil.jmlfdc.common.business.BusinessManager;

import mil.jmlfdc.common.datamodel.CurrentUserBT;

import javax.ejb.Stateless;
import javax.inject.Inject;
import mil.jmlfdc.common.utils.ObjectMapper;
import org.slf4j.Logger;

@Stateless
public class CatalogManager extends BusinessManager {

    @Inject
    private Logger log;

    // need a ping dao here
    @Inject
    private PingDataDao pingDataDao;

    @Inject
    private ObjectMapper objectMapper;

    public PingData getPing() {
        log.info("Pinged the BT ABi Catalog Manager!");
        log.info("User: {}", this.currentUserBt.getPkiDn());
        PingDataDO pingDo = pingDataDao.getPingData("Hello from the ABi Catalog Manager...");
        return objectMapper.getObject(PingData.class, pingDo);
    }
    
}
