package dmles.catalog.server.business;

import dmles.catalog.core.datamodel.PingData;
import dmles.catalog.core.datamodel.SiteCatalogRecord;
import dmles.catalog.core.datamodel.CommodityClass;
import dmles.catalog.server.dao.PingDataDao;
import dmles.catalog.server.dao.SiteCatalogRecordDao;
import dmles.catalog.server.dao.CommodityClassDao;
import dmles.catalog.server.datamodel.PingDataDO;
import dmles.catalog.server.datamodel.SiteCatalogRecordDO;
import dmles.catalog.server.datamodel.CommodityClassDO;
import mil.jmlfdc.common.business.BusinessManager;
import mil.jmlfdc.common.utils.ObjectMapper;

import java.util.List;
import javax.ejb.Stateless;
import javax.inject.Inject;

import org.slf4j.Logger;

@Stateless
public class CatalogManager extends BusinessManager {

    @Inject
    private Logger log;

    @Inject
    private PingDataDao pingDataDao;

    @Inject
    private SiteCatalogRecordDao SiteCatalogRecordDao;

    @Inject
    private CommodityClassDao CommodityClassDao;

    @Inject
    private ObjectMapper objectMapper;

    public PingData getPing() {
        log.info("Pinged the BT Catalog Manager!");
        log.info("User: {}", this.currentUserBt.getPkiDn());
        PingDataDO pingDo = pingDataDao.getPingData("Hello from the Catalog Manager...");
        return objectMapper.getObject(PingData.class, pingDo);
    }

    public List<SiteCatalogRecord> getSiteCatalogByProductId(String siteId, Integer productSeqId) {
        List<SiteCatalogRecordDO> dbRecords = SiteCatalogRecordDao.getByProductSeqId(siteId, productSeqId);
        List<SiteCatalogRecord> recordList = objectMapper.getList(SiteCatalogRecord[].class, dbRecords);
        return recordList;
    }

    public List<SiteCatalogRecord> getSiteCatalogByEnterpriseId(String siteId, String enterpriseProductIdentifier) {
        List<SiteCatalogRecordDO> dbRecords = SiteCatalogRecordDao.getByEnterpriseId(siteId, enterpriseProductIdentifier);
        List<SiteCatalogRecord> recordList = objectMapper.getList(SiteCatalogRecord[].class, dbRecords);
        return recordList;
    }

    public List<SiteCatalogRecord> getSiteCatalogByItemId(String siteId, String itemId) {
        List<SiteCatalogRecordDO> dbRecords = SiteCatalogRecordDao.getByItemId(siteId, itemId);
        List<SiteCatalogRecord> recordList = objectMapper.getList(SiteCatalogRecord[].class, dbRecords);
        return recordList;
    }

    public List<SiteCatalogRecord> getSiteCatalogByBarcode(String siteId, String barcode) {
        List<SiteCatalogRecordDO> dbRecords = SiteCatalogRecordDao.getByBarcode(siteId, barcode);
        List<SiteCatalogRecord> recordList = objectMapper.getList(SiteCatalogRecord[].class, dbRecords);
        return recordList;
    }

    public List<SiteCatalogRecord> getCustomerCatalog(String siteId, String customerId) {
        List<SiteCatalogRecordDO> dbRecords = SiteCatalogRecordDao.getByCustomer(siteId, customerId);
        List<SiteCatalogRecord> recordList = objectMapper.getList(SiteCatalogRecord[].class, dbRecords);
        return recordList;
    }

    public List<SiteCatalogRecord> getSupplierCatalog(String siteId, String supplierNm) {
        List<SiteCatalogRecordDO> dbRecords = SiteCatalogRecordDao.getBySupplier(siteId, supplierNm);
        List<SiteCatalogRecord> recordList = objectMapper.getList(SiteCatalogRecord[].class, dbRecords);
        return recordList;
    }

    public List<CommodityClass> getCommodityClassList(String militaryServiceCode) {
        List<CommodityClassDO> dbRecords = CommodityClassDao.getCommodityClasses(militaryServiceCode);
        List<CommodityClass> recordList = objectMapper.getList(CommodityClass[].class, dbRecords);
        return recordList;
    }

}
