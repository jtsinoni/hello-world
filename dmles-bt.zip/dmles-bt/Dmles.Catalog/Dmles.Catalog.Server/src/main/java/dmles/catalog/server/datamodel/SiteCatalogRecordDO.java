package dmles.catalog.server.datamodel;

import java.io.Serializable;
import java.util.ArrayList;

import mil.jmlfdc.common.datamodel.MorphiaEntity;
import org.mongodb.morphia.annotations.*;

import java.util.List;

@Entity(value = "siteCatalog", noClassnameStored = true)
public class SiteCatalogRecordDO extends MorphiaEntity implements Serializable {

    private static long serialVersionUID = 1L;

    private String siteDodaac;
    private Integer itemSerial;
    private String itemId;
    private String shortItemDesc;
    private String longItemDesc;
    private String manufacturerNm;
    private String manufCatNum;
    private String nsn;
    private String ndc;
    private String enterpriseProductIdentifier;
    private Integer productSeqId;
    private String natlMotorFreightClassCd;
    private String locField1;
    private String webSite;
    private String hazardousMaterialInd;
    private String coldChainMgmtInd;
    private String greenProductInd;
    private String latexFreeProductInd;
    private String specialHandlingCd;
    private String ciiCd;
    private String standardized;
    private String pocsItemInd;
    private String deleteInd;
    private String locField2;
    private String locField3;
    private String ricc;
    private String demilCd;
    private String acqAdvCd;
    private String matCatStructCd;
    private String cogCd;
    private String preciousMetalCd;
    private Integer tlammCatalogSeqId;
    private String longItemChgInd;
    private String shortItemChgInd;
    private String addedToBsm;
    private String last832Dt;
    private String deferSyncUntilDt;
    private String createDt;
    private String createUserId;
    private String lastUpdateDt;
    private String lastUpdateUserId;
    private Integer logSosSerial;
    private String critItemInd;
    private Integer legacySosSerial;
    private String computationMethod;
    private String commType;
    private String commodityClsNm;
    private String expirationTypeCd;
    private String shelfLifeCd;
    private String dosageFormCd;
    private String drugStrDesc;
    private Integer drugStrNum;
    private String drugStrUnit;
    private Integer drugStrVolNum;
    private String drugStrVolUnit;
    private String durableItemInd;
    private String genSeqNum;
    private String hospFormularyInd;
    private String slClassificatnCd;
    private String slProductCd;
    private String routeCd;
    private String slRefNum;
    private String deaCd;
    private Integer drugPackQty;
    private String orangeBookCd;
    private String ahfsTherClassCd;
    private String deviceCd;
    private String eiAccntblCd;
    private String eiMaintReqrCd;
    private String systemTypeCd;
    private String eiVoltageRate;
    private String eiHertzRate;
    private String eiPhaseRate;
    private String eiLogsControl_cd;
    private String eiLineItemNum;
    private String eiEqpmtSrc;
    private String endItemCd;
    private String eqpmtCategoryCd;
    private String eqpmtModelNum;
    private String eiTmdeInd;
    private String piExchngItemCd;
    private Integer manufOrgSerial;
    private Integer manufMdlSerId;
    private String piLitrPageNo;
    private String piMmdlLitRefTx;
    private Integer orderingPoints;
    private Integer orderCount;
    private Integer orderCost;
    private Integer equipmentCount;
    private String deviceClassCode;
    private String deviceClassText;
    private String deviceText;
    private String federalSupplyClass;
    @Embedded
    private List<CustomerCatalogDO> customerCatalogs = new ArrayList<>();
    @Embedded
    private List<ItemRestrictionDO> itemRestrictions = new ArrayList<>();
    @Embedded
    private List<ItemDestructionDO> itemDestruction = new ArrayList<>();
    @Embedded
    private List<SourceDO> sources = new ArrayList<>();

    public SiteCatalogRecordDO() {
    }

    public String getSiteDodaac() {
        return siteDodaac;
    }

    public void setSiteDodaac(String siteDodaac) {
        this.siteDodaac = siteDodaac;
    }

    public Integer getItemSerial() {
        return itemSerial;
    }

    public void setItemSerial(Integer itemSerial) {
        this.itemSerial = itemSerial;
    }

    public String getItemId() {
        return itemId;
    }

    public void setItemId(String itemId) {
        this.itemId = itemId;
    }

    public String getShortItemDesc() {
        return shortItemDesc;
    }

    public void setShortItemDesc(String shortItemDesc) {
        this.shortItemDesc = shortItemDesc;
    }

    public String getLongItemDesc() {
        return longItemDesc;
    }

    public void setLongItemDesc(String longItemDesc) {
        this.longItemDesc = longItemDesc;
    }

    public String getManufacturerNm() {
        return manufacturerNm;
    }

    public void setManufacturerNm(String manufacturerNm) {
        this.manufacturerNm = manufacturerNm;
    }

    public String getManufCatNum() {
        return manufCatNum;
    }

    public void setManufCatNum(String manufCatNum) {
        this.manufCatNum = manufCatNum;
    }

    public String getNsn() {
        return nsn;
    }

    public void setNsn(String nsn) {
        this.nsn = nsn;
    }

    public String getNdc() {
        return ndc;
    }

    public void setNdc(String ndc) {
        this.ndc = ndc;
    }

    public String getEnterpriseProductIdentifier() {
        return enterpriseProductIdentifier;
    }

    public void setEnterpriseProductIdentifier(String enterpriseProductIdentifier) {
        this.enterpriseProductIdentifier = enterpriseProductIdentifier;
    }

    public Integer getProductSeqId() {
        return productSeqId;
    }

    public void setProductSeqId(Integer productSeqId) {
        this.productSeqId = productSeqId;
    }

    public String getNatlMotorFreightClassCd() {
        return natlMotorFreightClassCd;
    }

    public void setNatlMotorFreightClassCd(String natlMotorFreightClassCd) {
        this.natlMotorFreightClassCd = natlMotorFreightClassCd;
    }

    public String getLocField1() {
        return locField1;
    }

    public void setLocField1(String locField1) {
        this.locField1 = locField1;
    }

    public String getWebSite() {
        return webSite;
    }

    public void setWebSite(String webSite) {
        this.webSite = webSite;
    }

    public String getHazardousMaterialInd() {
        return hazardousMaterialInd;
    }

    public void setHazardousMaterialInd(String hazardousMaterialInd) {
        this.hazardousMaterialInd = hazardousMaterialInd;
    }

    public String getColdChainMgmtInd() {
        return coldChainMgmtInd;
    }

    public void setColdChainMgmtInd(String coldChainMgmtInd) {
        this.coldChainMgmtInd = coldChainMgmtInd;
    }

    public String getGreenProductInd() {
        return greenProductInd;
    }

    public void setGreenProductInd(String greenProductInd) {
        this.greenProductInd = greenProductInd;
    }

    public String getLatexFreeProductInd() {
        return latexFreeProductInd;
    }

    public void setLatexFreeProductInd(String latexFreeProductInd) {
        this.latexFreeProductInd = latexFreeProductInd;
    }

    public String getSpecialHandlingCd() {
        return specialHandlingCd;
    }

    public void setSpecialHandlingCd(String specialHandlingCd) {
        this.specialHandlingCd = specialHandlingCd;
    }

    public String getCiiCd() {
        return ciiCd;
    }

    public void setCiiCd(String ciiCd) {
        this.ciiCd = ciiCd;
    }

    public String getStandardized() {
        return standardized;
    }

    public void setStandardized(String standardized) {
        this.standardized = standardized;
    }

    public String getPocsItemInd() {
        return pocsItemInd;
    }

    public void setPocsItemInd(String pocsItemInd) {
        this.pocsItemInd = pocsItemInd;
    }

    public String getDeleteInd() {
        return deleteInd;
    }

    public void setDeleteInd(String deleteInd) {
        this.deleteInd = deleteInd;
    }

    public String getLocField2() {
        return locField2;
    }

    public void setLocField2(String locField2) {
        this.locField2 = locField2;
    }

    public String getLocField3() {
        return locField3;
    }

    public void setLocField3(String locField3) {
        this.locField3 = locField3;
    }

    public String getRicc() {
        return ricc;
    }

    public void setRicc(String ricc) {
        this.ricc = ricc;
    }

    public String getDemilCd() {
        return demilCd;
    }

    public void setDemilCd(String demilCd) {
        this.demilCd = demilCd;
    }

    public String getAcqAdvCd() {
        return acqAdvCd;
    }

    public void setAcqAdvCd(String acqAdvCd) {
        this.acqAdvCd = acqAdvCd;
    }

    public String getMatCatStructCd() {
        return matCatStructCd;
    }

    public void setMatCatStructCd(String matCatStructCd) {
        this.matCatStructCd = matCatStructCd;
    }

    public String getCogCd() {
        return cogCd;
    }

    public void setCogCd(String cogCd) {
        this.cogCd = cogCd;
    }

    public String getPreciousMetalCd() {
        return preciousMetalCd;
    }

    public void setPreciousMetalCd(String preciousMetalCd) {
        this.preciousMetalCd = preciousMetalCd;
    }

    public Integer getTlammCatalogSeqId() {
        return tlammCatalogSeqId;
    }

    public void setTlammCatalogSeqId(Integer tlammCatalogSeqId) {
        this.tlammCatalogSeqId = tlammCatalogSeqId;
    }

    public String getLongItemChgInd() {
        return longItemChgInd;
    }

    public void setLongItemChgInd(String longItemChgInd) {
        this.longItemChgInd = longItemChgInd;
    }

    public String getShortItemChgInd() {
        return shortItemChgInd;
    }

    public void setShortItemChgInd(String shortItemChgInd) {
        this.shortItemChgInd = shortItemChgInd;
    }

    public String getAddedToBsm() {
        return addedToBsm;
    }

    public void setAddedToBsm(String addedToBsm) {
        this.addedToBsm = addedToBsm;
    }

    public String getLast832Dt() {
        return last832Dt;
    }

    public void setLast832Dt(String last832Dt) {
        this.last832Dt = last832Dt;
    }

    public String getDeferSyncUntilDt() {
        return deferSyncUntilDt;
    }

    public void setDeferSyncUntilDt(String deferSyncUntilDt) {
        this.deferSyncUntilDt = deferSyncUntilDt;
    }

    public String getCreateDt() {
        return createDt;
    }

    public void setCreateDt(String createDt) {
        this.createDt = createDt;
    }

    public String getCreateUserId() {
        return createUserId;
    }

    public void setCreateUserId(String createUserId) {
        this.createUserId = createUserId;
    }

    public String getLastUpdateDt() {
        return lastUpdateDt;
    }

    public void setLastUpdateDt(String lastUpdateDt) {
        this.lastUpdateDt = lastUpdateDt;
    }

    public String getLastUpdateUserId() {
        return lastUpdateUserId;
    }

    public void setLastUpdateUserId(String lastUpdateUserId) {
        this.lastUpdateUserId = lastUpdateUserId;
    }

    public Integer getLogSosSerial() {
        return logSosSerial;
    }

    public void setLogSosSerial(Integer logSosSerial) {
        this.logSosSerial = logSosSerial;
    }

    public String getCritItemInd() {
        return critItemInd;
    }

    public void setCritItemInd(String critItemInd) {
        this.critItemInd = critItemInd;
    }

    public Integer getLegacySosSerial() {
        return legacySosSerial;
    }

    public void setLegacySosSerial(Integer legacySosSerial) {
        this.legacySosSerial = legacySosSerial;
    }

    public String getComputationMethod() {
        return computationMethod;
    }

    public void setComputationMethod(String computationMethod) {
        this.computationMethod = computationMethod;
    }

    public String getCommType() {
        return commType;
    }

    public void setCommType(String commType) {
        this.commType = commType;
    }

    public String getCommodityClsNm() {
        return commodityClsNm;
    }

    public void setCommodityClsNm(String commodityClsNm) {
        this.commodityClsNm = commodityClsNm;
    }

    public String getExpirationTypeCd() {
        return expirationTypeCd;
    }

    public void setExpirationTypeCd(String expirationTypeCd) {
        this.expirationTypeCd = expirationTypeCd;
    }

    public String getShelfLifeCd() {
        return shelfLifeCd;
    }

    public void setShelfLifeCd(String shelfLifeCd) {
        this.shelfLifeCd = shelfLifeCd;
    }

    public String getDosageFormCd() {
        return dosageFormCd;
    }

    public void setDosageFormCd(String dosageFormCd) {
        this.dosageFormCd = dosageFormCd;
    }

    public String getDrugStrDesc() {
        return drugStrDesc;
    }

    public void setDrugStrDesc(String drugStrDesc) {
        this.drugStrDesc = drugStrDesc;
    }

    public Integer getDrugStrNum() {
        return drugStrNum;
    }

    public void setDrugStrNum(Integer drugStrNum) {
        this.drugStrNum = drugStrNum;
    }

    public String getDrugStrUnit() {
        return drugStrUnit;
    }

    public void setDrugStrUnit(String drugStrUnit) {
        this.drugStrUnit = drugStrUnit;
    }

    public Integer getDrugStrVolNum() {
        return drugStrVolNum;
    }

    public void setDrugStrVolNum(Integer drugStrVolNum) {
        this.drugStrVolNum = drugStrVolNum;
    }

    public String getDrugStrVolUnit() {
        return drugStrVolUnit;
    }

    public void setDrugStrVolUnit(String drugStrVolUnit) {
        this.drugStrVolUnit = drugStrVolUnit;
    }

    public String getDurableItemInd() {
        return durableItemInd;
    }

    public void setDurableItemInd(String durableItemInd) {
        this.durableItemInd = durableItemInd;
    }

    public String getGenSeqNum() {
        return genSeqNum;
    }

    public void setGenSeqNum(String genSeqNum) {
        this.genSeqNum = genSeqNum;
    }

    public String getHospFormularyInd() {
        return hospFormularyInd;
    }

    public void setHospFormularyInd(String hospFormularyInd) {
        this.hospFormularyInd = hospFormularyInd;
    }

    public String getSlClassificatnCd() {
        return slClassificatnCd;
    }

    public void setSlClassificatnCd(String slClassificatnCd) {
        this.slClassificatnCd = slClassificatnCd;
    }

    public String getSlProductCd() {
        return slProductCd;
    }

    public void setSlProductCd(String slProductCd) {
        this.slProductCd = slProductCd;
    }

    public String getRouteCd() {
        return routeCd;
    }

    public void setRouteCd(String routeCd) {
        this.routeCd = routeCd;
    }

    public String getSlRefNum() {
        return slRefNum;
    }

    public void setSlRefNum(String slRefNum) {
        this.slRefNum = slRefNum;
    }

    public String getDeaCd() {
        return deaCd;
    }

    public void setDeaCd(String deaCd) {
        this.deaCd = deaCd;
    }

    public Integer getDrugPackQty() {
        return drugPackQty;
    }

    public void setDrugPackQty(Integer drugPackQty) {
        this.drugPackQty = drugPackQty;
    }

    public String getOrangeBookCd() {
        return orangeBookCd;
    }

    public void setOrangeBookCd(String orangeBookCd) {
        this.orangeBookCd = orangeBookCd;
    }

    public String getAhfsTherClassCd() {
        return ahfsTherClassCd;
    }

    public void setAhfsTherClassCd(String ahfsTherClassCd) {
        this.ahfsTherClassCd = ahfsTherClassCd;
    }

    public String getDeviceCd() {
        return deviceCd;
    }

    public void setDeviceCd(String deviceCd) {
        this.deviceCd = deviceCd;
    }

    public String getEiAccntblCd() {
        return eiAccntblCd;
    }

    public void setEiAccntblCd(String eiAccntblCd) {
        this.eiAccntblCd = eiAccntblCd;
    }

    public String getEiMaintReqrCd() {
        return eiMaintReqrCd;
    }

    public void setEiMaintReqrCd(String eiMaintReqrCd) {
        this.eiMaintReqrCd = eiMaintReqrCd;
    }

    public String getSystemTypeCd() {
        return systemTypeCd;
    }

    public void setSystemTypeCd(String systemTypeCd) {
        this.systemTypeCd = systemTypeCd;
    }

    public String getEiVoltageRate() {
        return eiVoltageRate;
    }

    public void setEiVoltageRate(String eiVoltageRate) {
        this.eiVoltageRate = eiVoltageRate;
    }

    public String getEiHertzRate() {
        return eiHertzRate;
    }

    public void setEiHertzRate(String eiHertzRate) {
        this.eiHertzRate = eiHertzRate;
    }

    public String getEiPhaseRate() {
        return eiPhaseRate;
    }

    public void setEiPhaseRate(String eiPhaseRate) {
        this.eiPhaseRate = eiPhaseRate;
    }

    public String getEiLogsControl_cd() {
        return eiLogsControl_cd;
    }

    public void setEiLogsControl_cd(String eiLogsControl_cd) {
        this.eiLogsControl_cd = eiLogsControl_cd;
    }

    public String getEiLineItemNum() {
        return eiLineItemNum;
    }

    public void setEiLineItemNum(String eiLineItemNum) {
        this.eiLineItemNum = eiLineItemNum;
    }

    public String getEiEqpmtSrc() {
        return eiEqpmtSrc;
    }

    public void setEiEqpmtSrc(String eiEqpmtSrc) {
        this.eiEqpmtSrc = eiEqpmtSrc;
    }

    public String getEndItemCd() {
        return endItemCd;
    }

    public void setEndItemCd(String endItemCd) {
        this.endItemCd = endItemCd;
    }

    public String getEqpmtCategoryCd() {
        return eqpmtCategoryCd;
    }

    public void setEqpmtCategoryCd(String eqpmtCategoryCd) {
        this.eqpmtCategoryCd = eqpmtCategoryCd;
    }

    public String getEqpmtModelNum() {
        return eqpmtModelNum;
    }

    public void setEqpmtModelNum(String eqpmtModelNum) {
        this.eqpmtModelNum = eqpmtModelNum;
    }

    public String getEiTmdeInd() {
        return eiTmdeInd;
    }

    public void setEiTmdeInd(String eiTmdeInd) {
        this.eiTmdeInd = eiTmdeInd;
    }

    public String getPiExchngItemCd() {
        return piExchngItemCd;
    }

    public void setPiExchngItemCd(String piExchngItemCd) {
        this.piExchngItemCd = piExchngItemCd;
    }

    public Integer getManufOrgSerial() {
        return manufOrgSerial;
    }

    public void setManufOrgSerial(Integer manufOrgSerial) {
        this.manufOrgSerial = manufOrgSerial;
    }

    public Integer getManufMdlSerId() {
        return manufMdlSerId;
    }

    public void setManufMdlSerId(Integer manufMdlSerId) {
        this.manufMdlSerId = manufMdlSerId;
    }

    public String getPiLitrPageNo() {
        return piLitrPageNo;
    }

    public void setPiLitrPageNo(String piLitrPageNo) {
        this.piLitrPageNo = piLitrPageNo;
    }

    public String getPiMmdlLitRefTx() {
        return piMmdlLitRefTx;
    }

    public void setPiMmdlLitRefTx(String piMmdlLitRefTx) {
        this.piMmdlLitRefTx = piMmdlLitRefTx;
    }

    public Integer getOrderingPoints() {
        return orderingPoints;
    }

    public void setOrderingPoints(Integer orderingPoints) {
        this.orderingPoints = orderingPoints;
    }

    public Integer getOrderCount() {
        return orderCount;
    }

    public void setOrderCount(Integer orderCount) {
        this.orderCount = orderCount;
    }

    public Integer getOrderCost() {
        return orderCost;
    }

    public void setOrderCost(Integer orderCost) {
        this.orderCost = orderCost;
    }

    public Integer getEquipmentCount() {
        return equipmentCount;
    }

    public void setEquipmentCount(Integer equipmentCount) {
        this.equipmentCount = equipmentCount;
    }

    public String getDeviceClassCode() {
        return deviceClassCode;
    }

    public void setDeviceClassCode(String deviceClassCode) {
        this.deviceClassCode = deviceClassCode;
    }

    public String getDeviceClassText() {
        return deviceClassText;
    }

    public void setDeviceClassText(String deviceClassText) {
        this.deviceClassText = deviceClassText;
    }

    public String getDeviceText() {
        return deviceText;
    }

    public void setDeviceText(String deviceText) {
        this.deviceText = deviceText;
    }

    public String getFederalSupplyClass() {
        return federalSupplyClass;
    }

    public void setFederalSupplyClass(String federalSupplyClass) {
        this.federalSupplyClass = federalSupplyClass;
    }

    public List<CustomerCatalogDO> getCustomerCatalogs() {
        return customerCatalogs;
    }

    public void setCustomerCatalogs(List<CustomerCatalogDO> customerCatalogs) {
        this.customerCatalogs = customerCatalogs;
    }

    public List<ItemRestrictionDO> getItemRestrictions() {
        return itemRestrictions;
    }

    public void setItemRestrictions(List<ItemRestrictionDO> itemRestrictions) {
        this.itemRestrictions = itemRestrictions;
    }

    public List<ItemDestructionDO> getItemDestruction() {
        return itemDestruction;
    }

    public void setItemDestruction(List<ItemDestructionDO> itemDestruction) {
        this.itemDestruction = itemDestruction;
    }

    public List<SourceDO> getSources() {
        return sources;
    }

    public void setSources(List<SourceDO> sources) {
        this.sources = sources;
    }
}
