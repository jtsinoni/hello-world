package dmles.catalog.client;

import dmles.catalog.core.ICatalogService;
import dmles.oauth.core.rest.SecuredRestClientFactory;
import mil.jmlfdc.common.business.RestClientFactory;

import javax.enterprise.context.Dependent;
import javax.enterprise.inject.Produces;

@Dependent
//SecuredRestClientFactory
//public class CatalogClientFactory extends RestClientFactory<ICatalogService> {
public class CatalogClientFactory extends SecuredRestClientFactory<ICatalogService> {
 
    public CatalogClientFactory(){
        super(ICatalogService.class, "Dmles.Catalog.Server");
    }

    @Produces
    public  ICatalogService getICatalogService(){return createClient();}

}
