package dmles.catalog.client;

import dmles.catalog.core.ICatalogService;
import mil.jmlfdc.common.business.RestClientFactory;

import javax.enterprise.context.Dependent;

@Dependent
public class CatalogClientFactory extends RestClientFactory<ICatalogService> {
 
    public CatalogClientFactory(){
        super(ICatalogService.class, "Dmles.Catalog.Server");
    }
}
