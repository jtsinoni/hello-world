package dmles.common.general.jms;

import dmles.common.general.logging.Logger;


import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.jms.*;

@ApplicationScoped
public class JmsClient {
    @Inject
    JMSContext jmsContext;

    @Inject
    Logger logger;

    public void sendRequest(String request, String destination) {
            Queue queue = jmsContext.createQueue(destination);
            JMSProducer send = jmsContext.createProducer().send(queue, request);
    }
}

