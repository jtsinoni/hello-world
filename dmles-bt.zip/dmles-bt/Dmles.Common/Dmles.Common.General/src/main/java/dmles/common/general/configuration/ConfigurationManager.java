package dmles.common.general.configuration;

import com.netflix.config.DynamicIntProperty;
import com.netflix.config.DynamicPropertyFactory;
import com.netflix.config.DynamicStringProperty;
import dmles.common.general.CommonBase;

import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class ConfigurationManager extends CommonBase {

    private String getDynamicString(String key) {
        DynamicStringProperty property = DynamicPropertyFactory.getInstance().getStringProperty(key, "");
        String val = property.get();
        this.logger.debug(String.format("retrieved value %s for key %s", key, val));
        return val;
    }

    private int getDynamicInt(String key) {
        DynamicIntProperty property = DynamicPropertyFactory.getInstance().getIntProperty(key, 0);
        return property.get();
    }

    public String getProjectVersion() {
        DynamicStringProperty property = DynamicPropertyFactory.getInstance().getStringProperty("project.version", "1.0-SNAPSHOT");
        return property.get();
    }

    public String getSwaggerHost() {
        DynamicStringProperty property = DynamicPropertyFactory.getInstance().getStringProperty("swagger.host", "localhost");
        return property.get();
    }

    public String getSwaggerPort(){
        DynamicStringProperty property = DynamicPropertyFactory.getInstance().getStringProperty("swagger.port", "8080");
        return property.get();
    }

    public String getSwaggerSchemes() {
        DynamicStringProperty property = DynamicPropertyFactory.getInstance().getStringProperty("swagger.schemes", "http,https");
        return property.get();
    }

    public String getMongoHosts() {
        return getDynamicString("dmles.mongo.hosts");
    }

    public String getMongoRepSet() {
        return getDynamicString("dmles.mongo.repset");
    }

    public String getMongoUserId() {
        return getDynamicString("dmles.mongo.user.id");
    }

    public String getMongoUserPassword() {
        return getDynamicString("dmles.mongo.user.pw");
    }

    public String getDmlesAppHost() {
        return getDynamicString("dmles.app.host");
    }

    public int getEsPort() {
        return getDynamicInt("dmles.es.db.port");
    }

    public String getEsHost() {
        return getDynamicString("dmles.es.db.host");
    }

    public String getEsVersion() {
        return getDynamicString("dmles.es.db.version");
    }

}