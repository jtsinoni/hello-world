package dmles.common.general.logging;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;

@ApplicationScoped
public class LogManager {

    public static Logger getLogger(){
        return new LogManager().getDevelopmentLogger();
    }

    private Logger getDevelopmentLogger(){
        Logger logger = new Logger("developerLogger");
        return logger;
    }

    @Produces
    @BusinessTierLog
    Logger getBusinessTierLogger(InjectionPoint ip){
        Logger logger = new Logger("appHistoryLogger");
        return logger;
    }


    @Produces
    Logger getDevelopmentLogger(InjectionPoint ip){
        String category = ip.getMember()
                .getDeclaringClass()
                .getName();

//        Logger logger = new Logger(category);
        Logger logger = new Logger("developerLogger");

        return logger;
    }

}
