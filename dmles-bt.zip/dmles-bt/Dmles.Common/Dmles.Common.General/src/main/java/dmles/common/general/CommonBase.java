package dmles.common.general;

import dmles.common.general.logging.Logger;

import javax.enterprise.context.Dependent;
import javax.inject.Inject;

@Dependent
public class CommonBase {
    @Inject
    protected Logger logger;
}
