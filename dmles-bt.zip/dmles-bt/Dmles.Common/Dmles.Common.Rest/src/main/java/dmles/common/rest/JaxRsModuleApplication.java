package dmles.common.rest;

import dmles.common.general.configuration.ConfigurationManager;
import io.swagger.jaxrs.config.BeanConfig;

import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.context.Dependent;
import javax.inject.Inject;
import javax.ws.rs.core.Application;
import java.util.HashSet;
import java.util.Set;

@Dependent
public class JaxRsModuleApplication extends Application {

    private final String moduleName;

    @Inject
    private ConfigurationManager configurationManager;

    protected final Set<Class<?>> moduleResources = new HashSet<Class<?>>();

    private JaxRsModuleApplication() {this.moduleName = null;}

    public JaxRsModuleApplication(String moduleName) {
        this.moduleName = moduleName;
    }

    private String[] getSchemes() {
        String swaggerSchemes = configurationManager.getSwaggerSchemes();
        return swaggerSchemes.split(",");
    }

    private void initSwagger() {
        String projectVersion = configurationManager.getProjectVersion();

        String swaggerHost = configurationManager.getSwaggerHost();
        String swaggerPort = configurationManager.getSwaggerPort();
        String basePath = String.format("Dmles.%s.Server", moduleName);
        String resourcePackage = String.format("dmles.%s.server.rest", moduleName.toLowerCase());

        BeanConfig beanConfig = new BeanConfig();
        beanConfig.setVersion(projectVersion);
        beanConfig.setSchemes(getSchemes());
        beanConfig.setHost(String.format("%s:%s", swaggerHost, swaggerPort));
        beanConfig.setBasePath(basePath);
        beanConfig.setResourcePackage(resourcePackage);
        beanConfig.setPrettyPrint(true);
        beanConfig.setScan(true);
    }

    @PostConstruct
    public void init() {
        initSwagger();
    }

    @Override
    public Set<Class<?>> getClasses() {
        Set<Class<?>> resources = new HashSet<Class<?>>();

        resources.add(io.swagger.jaxrs.listing.ApiListingResource.class);
        resources.add(io.swagger.jaxrs.listing.SwaggerSerializers.class);

        resources.addAll(moduleResources);
        resources.add(CorsFilter.class);
        return resources;
    }
}
