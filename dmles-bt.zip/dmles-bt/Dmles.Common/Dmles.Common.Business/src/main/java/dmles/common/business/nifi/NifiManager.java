package dmles.common.business.nifi;

import dmles.common.general.jms.JmsClient;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;


@ApplicationScoped
public class NifiManager {

    private String equipmentRequestRequestQueue  = "EquipmentRequest_Request";
    private String equipmentRecordRequestQueue ="EquipmentRecord_Request";


    @Inject
    JmsClient jmsClient;


    public void sendEquipmentRequestToDmlss(String request){
        jmsClient.sendRequest(request, equipmentRequestRequestQueue);
    }

    public void getEquipmentRecordFromDmlss(String request){
        jmsClient.sendRequest(request,equipmentRecordRequestQueue);
    }
}
