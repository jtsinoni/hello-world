package dmles.equipment.core.datamodels.request.workflow.process;


import org.junit.Assert;
import org.junit.Test;

public class LevelCriteriaNeededTest {

    @Test
    public void testCost() {
        LevelCriteriaNeeded lcn = new LevelCriteriaNeeded();

        lcn.costCriteriaMet = true;

        Assert.assertTrue(lcn.isCriteriaSet());

    }

    @Test
    public void testDevice() {
        LevelCriteriaNeeded lcn = new LevelCriteriaNeeded();

        lcn.deviceCriteriaMet = true;

        Assert.assertTrue(lcn.isCriteriaSet());

    }

    @Test
    public void testCat() {
        LevelCriteriaNeeded lcn = new LevelCriteriaNeeded();

        lcn.catalogCriteriaMet = true;

        Assert.assertTrue(lcn.isCriteriaSet());

    }

    @Test
    public void testNone() {
        LevelCriteriaNeeded lcn = new LevelCriteriaNeeded();

        Assert.assertFalse(lcn.isCriteriaSet());

    }
}
