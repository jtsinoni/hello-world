package dmles.equipment.core.datamodels;

//import mil.jmlfdc.datamodels.Manufacturer;
import dmles.equipment.core.datamodels.Customer;
import dmles.equipment.core.datamodels.Organization;
//import mil.jmlfdc.datamodels.LogicalResponse;
import dmles.equipment.core.datamodels.Person;
//import mil.jmlfdc.datamodels.Address;
import dmles.equipment.core.datamodels.Comment;
import mil.jmlfdc.common.utils.MiscUtils;
//import mil.jmlfdc.datamodels.*;


import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class TestDataModels {
    
    private final Logger logger = LoggerFactory.getLogger(TestDataModels.class);
    
    @Test
    public void getterSetterTest() {
        
        List<String> noTest = Arrays.asList("");
        
        /* datamodels tests */
//        MiscUtils.getterSetterTest(Address.class, new ArrayList<String>());
        MiscUtils.getterSetterTest(Comment.class, new ArrayList<String>());
        MiscUtils.getterSetterTest(Customer.class, new ArrayList<String>());
//        MiscUtils.getterSetterTest(LogicalResponse.class, new ArrayList<String>());
//        MiscUtils.getterSetterTest(Manufacturer.class, new ArrayList<String>());
        MiscUtils.getterSetterTest(Organization.class, new ArrayList<String>());
        MiscUtils.getterSetterTest(Person.class, new ArrayList<String>()); 
        
    }
    
    @Test
    public void dataModelsTest(){
        
        Object testObj = new Object();
        boolean testBool = true;
        Long lng1 = 1234L;
        
        
        
        /* datamodels tests not covered with getter setter */
        Comment testCom = new Comment();
        testCom.setId(lng1);
        testCom.setNameFirst("testFname");
        testCom.setNameLast("testLname");
        String ret = testCom.getNameFirst();
        String ret2 = testCom.getNameLast();
        Customer testCust = new Customer("CustodianFN","CustodianLN","phone","custId","custName","custser");
//        LogicalResponse testResp = new LogicalResponse(testBool,testObj,"response");
//        LogicalResponse testResp2 = new LogicalResponse(testObj,"response");
        Organization testOrg = new Organization("orgid","orgName","orgserial");
        
    }
   
}
