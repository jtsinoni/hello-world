package dmles.equipment.core.datamodels.request;

import dmles.equipment.core.datamodels.request.*;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.Date;

public class CriticalCodeTest {
    
    private final Logger logger = LoggerFactory.getLogger(CriticalCodeTest.class);
    
    @Test
    public void critcalCodeUnitTest() {
        
        CriticalCode testCriticalCode = new CriticalCode();
        
    }
}
