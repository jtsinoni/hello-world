package dmles.equipment.core.datamodels.request;

import org.junit.Test;


public class CriticalCodeTest {
    
    @Test
    public void critcalCodeUnitTest() {
        
        RequestCriticality testCriticalCode = new RequestCriticality();
        
    }
}
