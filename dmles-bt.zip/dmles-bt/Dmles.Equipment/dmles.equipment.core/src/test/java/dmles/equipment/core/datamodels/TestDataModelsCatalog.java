package dmles.equipment.core.datamodels;

import dmles.equipment.core.datamodels.catalog.SuggestedSourceItem;
import dmles.equipment.core.datamodels.catalog.CatalogItem;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import mil.jmlfdc.common.utils.MiscUtils;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TestDataModelsCatalog {
    
    private final Logger logger = LoggerFactory.getLogger(TestDataModelsCatalog.class);
    
    @Test
    public void getterSetterTest() {
        
        List<String> noTest = Arrays.asList("");
        
        /* datamodels.catalog tests */
        MiscUtils.getterSetterTest(CatalogItem.class, new ArrayList<String>());
        MiscUtils.getterSetterTest(SuggestedSourceItem.class, new ArrayList<String>());
        
        
    }
      
    @Test
    public void dmCatalogTest(){
        
        /*
        Object testObj = new Object();
        Date testDate = new Date();
        boolean testBool = true;
        String retStr = "";
        String inpStr = "test string";
        
        CatalogItem testCatalog = new CatalogItem(); 
        */

        /* datamodels.catalog tests missed in getter setter */
        
        /*
        List<SuggestedSourceItem> suggestedSources = new ArrayList<>();
        
        
        testCatalog.setIsItemVerified(testBool);
        retStr = testCatalog.getShortDescription();
        testCatalog.setShortDescription(inpStr);
        testCatalog.setSuggestedSources(suggestedSources);
        List<SuggestedSourceItem> emptySuggestedSources = new ArrayList<>();
        testCatalog.setSuggestedSources(emptySuggestedSources);
        emptySuggestedSources = null;
        testCatalog.setSuggestedSources(emptySuggestedSources);
        suggestedSources = testCatalog.getSuggestedSources();
        testCatalog.setUnitCost(1.12f);
        float testFloat = testCatalog.getUnitCost();
        testCatalog.setUnitCost(testFloat);
        testCatalog.setManufacturer(inpStr);
        retStr = testCatalog.getManufacturer();
        testCatalog.setItemId(inpStr);
        retStr = testCatalog.getItemId();
        testCatalog.setItemName(inpStr);
        
        SuggestedSourceItem testSrc = new SuggestedSourceItem() ;
        testCatalog.setSuggestedSource(testSrc);
        testSrc = testCatalog.getSuggestedSource();
        testSrc.setSourceName(inpStr);
        suggestedSources.add(0,testSrc);        
        retStr = testCatalog.getItemName();
        testSrc.setSourceDivision(inpStr);
        retStr = testSrc.getSourceDivision();
        retStr = testSrc.getSourceName();
        testSrc.setPrimarySource(testBool);
        testSrc.setSoleSource(testBool);
        testSrc.setCreditCard(testBool);
        testSrc.setSupplierCatalogDate(testDate);
        testSrc.setPocEmail(inpStr);
        testSrc.setPocPhone1(inpStr);
        testSrc.setPocPhone2(inpStr);
        testSrc.setPocName(inpStr);
        testSrc.setPocTitle(inpStr);
        testSrc.setSupplierCatalogNumber(inpStr);
        testSrc.setSupplierCatalogReference(inpStr);
        testSrc.setSupplierAddress1(inpStr);
        testSrc.setSupplierAddress2(inpStr);
        testSrc.setSupplierCity(inpStr);
        testSrc.setSupplierCountry(inpStr);
        testSrc.setSupplierState(inpStr);
        testSrc.setSupplierZip(inpStr);
        testSrc.setUrl(inpStr);
        testDate = testSrc.getSupplierCatalogDate();
        retStr = testSrc.getPocEmail();
        retStr = testSrc.getPocPhone1();
        retStr = testSrc.getPocPhone2();
        retStr = testSrc.getPocName();
        retStr = testSrc.getPocTitle();
        retStr = testSrc.getSupplierCatalogNumber();
        retStr = testSrc.getSupplierCatalogReference();
        retStr = testSrc.getSupplierAddress1();
        retStr = testSrc.getSupplierAddress2();
        retStr = testSrc.getSupplierCity();
        retStr = testSrc.getSupplierCountry();
        retStr = testSrc.getSupplierState();
        retStr = testSrc.getSupplierZip();
        retStr = testSrc.getUrl();
        testBool = testSrc.getPrimarySource();
        testBool = testSrc.getSoleSource();
    */
    }
    
}
