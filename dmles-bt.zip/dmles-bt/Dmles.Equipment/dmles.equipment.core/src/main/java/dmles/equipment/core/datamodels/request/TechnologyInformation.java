package dmles.equipment.core.datamodels.request;

import java.util.ArrayList;
import java.util.List;

public class TechnologyInformation {
    public List<TechnologyRequirements> technologyRequirements = new ArrayList<>();
    public List<Software> software = new ArrayList<>();
}
