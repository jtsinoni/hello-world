package dmles.equipment.core.datamodels.request;

public class EquipmentMountingType {
    public Integer equipMountingTypeCd;
    public String equipMountingTypeTx;
}
