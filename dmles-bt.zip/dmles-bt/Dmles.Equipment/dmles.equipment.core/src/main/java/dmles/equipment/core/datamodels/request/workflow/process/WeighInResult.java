package dmles.equipment.core.datamodels.request.workflow.process;

public enum WeighInResult {

    APPROVE("Approve"),
    RECOMMEND_APPROVE("Recommend Approve"),
    NEUTRAL("Neutral"),
    RECOMMEND_REJECT("Recommend Reject"),
    REJECT("Reject");

    private final String name;

    private WeighInResult(String s) {
        this.name = s;
    }

    public boolean equalsName(String otherName) {
        return (otherName == null) ? false : name.equals(otherName);
    }

    @Override
    public String toString() {
        return this.name;
    }

}
