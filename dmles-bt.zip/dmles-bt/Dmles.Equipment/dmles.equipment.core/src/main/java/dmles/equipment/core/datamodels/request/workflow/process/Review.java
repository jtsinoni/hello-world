package dmles.equipment.core.datamodels.request.workflow.process;

import dmles.equipment.core.datamodels.Comment;

import java.util.ArrayList;
import java.util.List;

public class Review {
    public String roleId;
    public String reviewDisplayName;
    public String reviewStatus;
    public String elementName;
    public String reviewResult;
    public String selectedUserId;
    public List<ReviewUser> reviewUsers = new ArrayList<>();
    public List<Comment> comments = new ArrayList<>();
}