package dmles.equipment.core.datamodels.request;

public class InstallRequirement {
    public String description;
    public Float cost;
}
