package dmles.equipment.core.datamodels.request;

public class SafetyConcern {
    
    public String name;
    public Boolean required;
    public Boolean na;
    public String comments;

}