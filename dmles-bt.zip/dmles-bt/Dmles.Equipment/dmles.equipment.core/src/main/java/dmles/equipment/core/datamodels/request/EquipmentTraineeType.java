package dmles.equipment.core.datamodels.request;

public class EquipmentTraineeType {
    public String equipTraineeTypeCd;
    public String equipTraineeTypeTx;
}
