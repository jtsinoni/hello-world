package dmles.equipment.core.datamodels.request.workflow.definition;

import java.util.List;

public class WorkflowLevelDefinition {
    public Integer levelId;
    public String name;
    public String userType;
    public String ownerRoleId;
    public Rules rules;
    public List<LevelDefinitionReview> levelDefinitionReviews;
    public LevelCriteria levelCriteria;

}
