package dmles.equipment.core.datamodels.request;

public class Device {

//    public Boolean centrallyManagedInd;
//    public Boolean deleteInd;
//    public Boolean deviceAccountableCd;
//    public Boolean maintRequiredCd;   
//    public Integer federalSupplyCd;
//    public Integer lifeExpectancyQty;
//    public Integer relativeRiskLevelCd;
    public String deviceCode;
//    public String deviceClassCd;
//    public String deviceDefinitionTx;
    public String nomenclature;
//    public String retiredInd;
//    public String specialtyCd;

}
