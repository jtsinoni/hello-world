package dmles.equipment.core.datamodels.request;

import java.util.ArrayList;
import java.util.List;

public class SafetyInformation {

    public List<EnvironmentalConcern> environmentalConcerns = new ArrayList<>();    
    public List<SafetyConcern> safetyConcerns = new ArrayList<>();
}
