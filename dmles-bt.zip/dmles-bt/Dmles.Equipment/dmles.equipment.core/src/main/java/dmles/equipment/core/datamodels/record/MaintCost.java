package dmles.equipment.core.datamodels.record;

public class MaintCost {
    public String mcFiscalYearTm;
    public Integer mcDownTime;
    public Integer mcUnschdWoQty;
    public Float mcOPartCostAmt;
    public Float mcOUTimeQty;
    public Float mcOULabCstAmt;
    public Float mcOSTimeQty;
    public Float mcOSLabCstAmt;
    public Float mcCPartCostAmt;
    public Integer mcCUTimeQty;
    public Float mcCULabCstAmt;
    public Integer mcCSTimeQty;
    public Float mcCSLabCstAmt;
}