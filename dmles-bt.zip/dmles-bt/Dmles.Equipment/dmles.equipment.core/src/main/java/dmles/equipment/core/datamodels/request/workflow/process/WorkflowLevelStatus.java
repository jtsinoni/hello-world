package dmles.equipment.core.datamodels.request.workflow.process;

public enum WorkflowLevelStatus {
    NEW("New"), 
    ACTIVE("Active"), 
    APPROVED("Approved"), 
    CANCELLED("Cancelled"),
    COMPLETED("Completed"),
    RETRACTED("Retracted"),
    FORCEDUP("ForcedUp"),
    HOLD("Hold"), 
    REJECTED("Rejected"),
    REWORK("Rework"),
    SKIPPED("Skipped");

    private final String name;  
    
    private WorkflowLevelStatus(String s) {
        name = s;
    }

    public boolean equalsName(String otherName) {
        return (otherName == null) ? false : name.equals(otherName);
    }

    public String toString() {
       return this.name;
    }    
}