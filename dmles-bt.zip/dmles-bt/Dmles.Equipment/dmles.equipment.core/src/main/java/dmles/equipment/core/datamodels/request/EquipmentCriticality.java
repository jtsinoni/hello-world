package dmles.equipment.core.datamodels.request;

public class EquipmentCriticality {
    public Integer equipCriticalityCd;
    public String equipCriticalityTx;
    public String serviceAgencyCd;

}
