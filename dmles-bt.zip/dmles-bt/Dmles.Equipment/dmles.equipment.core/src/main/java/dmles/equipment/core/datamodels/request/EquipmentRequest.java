package dmles.equipment.core.datamodels.request;

import mil.jmlfdc.common.datamodel.Attachment;
import mil.jmlfdc.common.datamodel.Note;
import dmles.equipment.core.datamodels.catalog.CatalogItem;
import dmles.equipment.core.datamodels.request.workflow.process.WorkflowProcessing;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class EquipmentRequest {
    
    public String id;
    public Boolean itemIdProvided;
    
    public String updatedBy;
    public Date updatedDate;
    public Float totalOtherCost;
    public Float totalRequisitionCost;
    public List<Attachment> attachments = new ArrayList<>(); // TODO: Item variables needed
    public CatalogItem catalogItem = new CatalogItem();
    public RequestInformation requestInformation;
    public FacilityInformation facilityInformation = new FacilityInformation();
    public SafetyInformation safetyInformation = new SafetyInformation();
    public MaintenanceInformation maintenanceInformation = new MaintenanceInformation();
    public TechnologyInformation technologyInformation = new TechnologyInformation();
    public WorkflowProcessing wfProcessing;
    public List<Note> notes = new ArrayList<>(); // TODO: Item variables needed

}
