package dmles.equipment.core.datamodels.request.workflow.definition;

public class CriteriaDevice {
    public String deviceCode;
    public String deviceName;
}
