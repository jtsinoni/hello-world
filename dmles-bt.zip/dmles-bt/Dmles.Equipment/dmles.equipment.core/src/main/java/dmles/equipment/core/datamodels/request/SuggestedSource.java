package dmles.equipment.core.datamodels.request;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.util.Date;
import mil.jmlfdc.common.constants.DateAndTime;
import mil.jmlfdc.common.datamodel.Attachment;

public class SuggestedSource {
    public Boolean creditCard;
    public Boolean primarySource;
    public Boolean soleSource;
    public String contract;
    public Attachment justificationLetter;
    public String pocEmail;
    public String pocFirstName;
    public String pocLastName;
    public String pocPhone1;
    public String pocPhone2;
    public String pocTitle;
    public String sourceName;
    public String supplierCatalogNumber;
    public String supplierCatalogReference;
    public String supplierAddress1;
    public String supplierAddress2;
    public String supplierCity;
    public String supplierState;
    public String supplierZip;
    public String supplierCountry;
    public String url;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateAndTime.DATE_TIME_PATTERN)
    public Date contractExpDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateAndTime.DATE_TIME_PATTERN)
    public Date supplierCatalogDate;
}
