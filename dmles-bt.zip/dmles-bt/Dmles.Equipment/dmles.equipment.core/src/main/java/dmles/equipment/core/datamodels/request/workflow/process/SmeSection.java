package dmles.equipment.core.datamodels.request.workflow.process;

public enum SmeSection {

    REQUEST("Request"),
    MAINTENANCE("Maintenance"),
    FACILITIES("Facilities"),
    TECHNOLOGY("Technology"),
    SAFETY("Safety");

    private final String name;

    private SmeSection(String s) {
        this.name = s;
    }

    public boolean equalsName(String otherName) {
        return (otherName == null) ? false : name.equals(otherName);
    }

    @Override
    public String toString() {
        return this.name;
    }

}
