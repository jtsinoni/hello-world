package dmles.equipment.core.datamodels.request;

public class EquipmentRequestType {
    public String code;
    public String name;
    public EquipmentRequestType() {}
    public EquipmentRequestType(String code, String name) {
        this.code = code;
        this.name = name;
    }
}
