package dmles.equipment.core.datamodels.request.workflow.process;

public class WeighInUser {
    public String id;
    public String profileName;
    public String pkiDn;
    public String dodaac;
    public String email;
    public String firstName;
    public String lastName;
    public String userType;
    public String serviceCode;
    public String regionCode;       
}
