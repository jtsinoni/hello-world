package dmles.equipment.core.datamodels.request;

public class EnvironmentalConcern {
    
    public String name;
    public Boolean generates;
    public Boolean uses;
    public Boolean na;
    public String comments;

}
