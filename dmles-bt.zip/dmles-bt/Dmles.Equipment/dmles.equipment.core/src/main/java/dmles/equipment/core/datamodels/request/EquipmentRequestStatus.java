package dmles.equipment.core.datamodels.request;

import java.util.Date;

public class EquipmentRequestStatus {

    public String notes;
    public String state; 
    public Date updateDate;

}
