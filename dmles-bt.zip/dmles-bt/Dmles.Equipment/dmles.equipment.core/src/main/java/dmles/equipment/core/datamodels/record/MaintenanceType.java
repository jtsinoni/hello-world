package dmles.equipment.core.datamodels.record;

public class MaintenanceType {
    public static final long serialVersionUID = 1L;
    public Integer ME_ID;
    public Integer miTypeCode;
    public String mdDueDt;
    public String mdLastSvcDt;
    public String miTypeDescText;
    public Integer mpId;
    public Integer miInuseMonthQty;
    public Integer miMobltyMnthQty;
    public Integer miStoredMnthQty;
    public Integer meId;
    public String operationalStatus;

}