package dmles.equipment.core.datamodels.request.workflow.definition;

public class LevelDefinitionReview {
    public String elementName;
    public String roleId;
    public String reviewDisplayName;
}
