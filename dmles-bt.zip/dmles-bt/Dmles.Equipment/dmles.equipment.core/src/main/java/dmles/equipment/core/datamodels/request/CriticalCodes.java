package dmles.equipment.core.datamodels.request;

public class CriticalCodes {

    public String code;
    public String description;

}
