package dmles.equipment.core.datamodels.request;

import java.util.Date;

public class EquipmentRequestHistory {
    
    public String action;
    public String performedBy;
    public Date performedDate;

}
