package dmles.equipment.core.datamodels.record;

public class Software {
    public Integer controlNum;
    public String nomenclature;
    public String company;
    public String version;
    public String type;
    public String operatingSystem;
}