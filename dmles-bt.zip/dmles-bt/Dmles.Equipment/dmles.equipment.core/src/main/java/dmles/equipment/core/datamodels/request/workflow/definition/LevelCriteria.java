package dmles.equipment.core.datamodels.request.workflow.definition;

import java.util.ArrayList;
import java.util.List;

public class LevelCriteria {
    public Float totalCostThreshold;
    public Float totalDeviceThreshold;
    public List<CriteriaCatalogItem> catalogItems = new ArrayList<>();
    public List<CriteriaDevice> devices = new ArrayList<>();
}
