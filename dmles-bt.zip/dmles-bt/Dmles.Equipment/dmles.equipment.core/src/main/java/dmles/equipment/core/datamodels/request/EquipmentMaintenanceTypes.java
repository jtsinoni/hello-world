package dmles.equipment.core.datamodels.request;

import java.util.ArrayList;
import java.util.List;

public class EquipmentMaintenanceTypes {

    public ServiceAgency serviceAgency = new ServiceAgency();
    public List<String> types = new ArrayList<>();
}
