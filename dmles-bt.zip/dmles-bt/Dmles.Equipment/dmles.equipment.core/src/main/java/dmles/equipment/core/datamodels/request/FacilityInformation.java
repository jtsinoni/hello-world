package dmles.equipment.core.datamodels.request;

import java.util.ArrayList;
import java.util.List;

public class FacilityInformation {

    public Float facilityModificationCost;
    public String facilityModifications;
    public List<Utility> utilities = new ArrayList<>();
    public Boolean includedCost;

}
