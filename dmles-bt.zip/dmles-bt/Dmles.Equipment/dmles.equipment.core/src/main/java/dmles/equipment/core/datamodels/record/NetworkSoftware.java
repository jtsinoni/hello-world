package dmles.equipment.core.datamodels.record;

public class NetworkSoftware {
    public String softwareTitle;
    public String version;
    public String installedBy;
    public String dateInstalled;
}