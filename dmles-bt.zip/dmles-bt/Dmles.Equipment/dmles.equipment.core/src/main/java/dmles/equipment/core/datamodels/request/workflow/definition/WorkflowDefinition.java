package dmles.equipment.core.datamodels.request.workflow.definition;

import dmles.equipment.core.datamodels.request.workflow.process.ReviewResult;
import java.util.Date;
import java.util.List;

public class WorkflowDefinition {
    public String id;
    public String name;
    public String service;
    public List<WorkflowLevelDefinition> levelDefinitions;
    public String version;
    public Date dateCreated;
    public Date dateUpdated;
    public Date effectiveDate;
    public List<ReviewResult> reviewResponses;
    public String updatedBy;
    public boolean active;
}