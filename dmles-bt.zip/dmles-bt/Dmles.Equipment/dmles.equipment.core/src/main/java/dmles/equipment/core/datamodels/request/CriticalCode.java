package dmles.equipment.core.datamodels.request;

import java.util.ArrayList;
import java.util.List;

public class CriticalCode {

    public ServiceAgency serviceAgency = new ServiceAgency();
    public List<CriticalCodes> criticalCodes = new ArrayList<>();
}
