package dmles.equipment.core.datamodels.request;

public class EquipmentRequirement {
    public String category; 
    public String requirement;
    public String specification;    
}
