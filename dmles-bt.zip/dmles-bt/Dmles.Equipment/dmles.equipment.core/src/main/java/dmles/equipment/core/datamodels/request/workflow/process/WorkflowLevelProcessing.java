package dmles.equipment.core.datamodels.request.workflow.process;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import dmles.equipment.core.datamodels.Comment;

public class WorkflowLevelProcessing {

    public Boolean autoApproveAfterWeighins;
    public Integer levelId;
    public String levelName;
    public String status;
    public List<Comment> comments = new ArrayList<>();
    public List<WeighIn> weighIns = new ArrayList<>();
    public String updatedBy;
    public Date updatedDate;

}
