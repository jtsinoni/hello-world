package dmles.equipment.core.datamodels;

public class Person {
    public String userId;
    public String firstName;
    public String lastName;
    public String phoneNumber;
    public String email;
    public String defaultDodaac;
}
