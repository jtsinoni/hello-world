package dmles.equipment.core.datamodels.request;

public class Requestor {
    public String userId;
    public String firstName;
    public String lastName;
    public String phoneNumber;
    public String email;
    public String defaultDodaac;
}
