package dmles.equipment.core.datamodels.request.workflow.process;

import dmles.equipment.core.datamodels.Comment;

import java.util.ArrayList;
import java.util.List;

public class WeighIn {
    public String roleId;
    public String weighInDisplayName;
    public String weighInStatus;
    public String elementName;
    public String weighInResult;
    public String selectedUserId;
    public List<WeighInUser> weighInUsers = new ArrayList<>();
    public List<Comment> comments = new ArrayList<>();
}