package dmles.equipment.core.datamodels.request;

import dmles.equipment.core.datamodels.Customer;
import dmles.equipment.core.datamodels.Organization;
import dmles.equipment.core.datamodels.Person;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class RequestInformation {

    public String criticalCode;
    public Submitter submitter = new Submitter();
    public Customer customer;
    public String description;
    public RequestedEquipment equipment = new RequestedEquipment();
    public List<ExtraItem> extraItems = new ArrayList<>();
    public String missionImpact;
    public String missionImpactDoc;
    public Organization organization;
    public Integer quantityRequested;
    public List<ReplacementItem> replacedItems = new ArrayList<>();
    public Date requestedDeliveryDate;
    public String requestedDeliveryDateReason;
    public Person requestor = new Person();
    public String requestedItemId;
    public String requestNumber;
    public String requestTitle;
    public EquipmentRequestReason requestReason;    
    public EquipmentRequestType requestType;
    public List<SuggestedSource> suggestedSources = new ArrayList<>();
    // TODO: Move into a Cost Summary model, GUI Model too
    public Float totalCompAccSupplies;
    public Float totalIncludedTrainingCost;
    public Float totalTDYCost;
    public List<TrainingItem> training = new ArrayList<>();
    public List<EquipmentRequirement> equipmentRequirements = new ArrayList<>();    
    
}