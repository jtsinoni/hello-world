package dmles.equipment.core.datamodels.request;

public class TechnologyRequirements {

    public String name;
    public Boolean required;
    public Boolean available;
    public Boolean na;
    public String comments;
    public String specifications;

}
