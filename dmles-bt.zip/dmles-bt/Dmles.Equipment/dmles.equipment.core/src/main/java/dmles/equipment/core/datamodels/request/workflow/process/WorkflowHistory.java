package dmles.equipment.core.datamodels.request.workflow.process;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.util.Date;
import mil.jmlfdc.common.constants.DateAndTime;

public class WorkflowHistory {
    
    public Long id;
    public String level;
    public String user;
    public String action;
    public String section;
    
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateAndTime.DATE_TIME_PATTERN)
    public Date when;
}
