package dmles.equipment.core.datamodels.request.workflow.process;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class LevelCriteriaNeeded {
    public String levelName;
    public boolean deviceCriteriaMet;
    public boolean deviceUnitCostCriteriaMet;
    public boolean catalogCriteriaMet;
    public boolean costCriteriaMet;

    @JsonIgnore
    public boolean isCriteriaSet() {
        return deviceCriteriaMet || catalogCriteriaMet || costCriteriaMet || deviceUnitCostCriteriaMet;
    }
}
