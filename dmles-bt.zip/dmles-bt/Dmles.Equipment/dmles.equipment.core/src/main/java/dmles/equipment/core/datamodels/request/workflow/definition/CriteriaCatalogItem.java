package dmles.equipment.core.datamodels.request.workflow.definition;

public class CriteriaCatalogItem {
    public String catalogID;
    public String catalogName;
    public Float totalCost;
}
