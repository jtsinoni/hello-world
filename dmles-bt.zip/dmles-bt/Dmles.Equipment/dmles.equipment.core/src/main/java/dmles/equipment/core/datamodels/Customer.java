package dmles.equipment.core.datamodels;

public class Customer {
    public String id;
    public String custodianFirstName;
    public String custodianLastName;
    public String custodianPhoneNum;
    public String customerID;
    public String customerName;
    public String customerSerial;    
}