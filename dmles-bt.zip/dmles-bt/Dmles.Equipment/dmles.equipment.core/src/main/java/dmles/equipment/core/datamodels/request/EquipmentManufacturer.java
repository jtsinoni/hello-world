package dmles.equipment.core.datamodels.request;

public class EquipmentManufacturer {
    public String organizationNm;
}
