package dmles.equipment.core.datamodels.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.util.Date;

public class NoteItem {
    public Long id;
    public String noteText;
    public String section;
    public String enteredBy;
    
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSX")
    public Date dateCreated;
}