package dmles.equipment.core.datamodels.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.util.Date;
import mil.jmlfdc.common.constants.DateAndTime;

public class NoteItem {
    public Long id;
    public String noteText;
    public String section;
    public String firstName;
    public String lastName;
    public String userId;
    
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateAndTime.DATE_TIME_PATTERN)
    public Date dateCreated;
}