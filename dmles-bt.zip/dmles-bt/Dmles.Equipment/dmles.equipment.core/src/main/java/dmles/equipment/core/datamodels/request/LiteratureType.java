package dmles.equipment.core.datamodels.request;

public class LiteratureType {
    public String literatureTypeCd;
    public String literatureTypeTx;
}
