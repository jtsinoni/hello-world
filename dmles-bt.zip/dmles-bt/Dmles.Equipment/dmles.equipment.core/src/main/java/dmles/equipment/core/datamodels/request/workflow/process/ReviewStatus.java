package dmles.equipment.core.datamodels.request.workflow.process;

public enum ReviewStatus {
    NEW("New"),
    PENDING("Pending"),
    HOLD("On Hold"),
    RECALLED("Recalled"),
    REWORK("Rework"),
    SKIPPED("Skipped"),
    SUBMITTED("Submitted");

    private final String name;

    private ReviewStatus(String s) {
        name = s;
    }

    public boolean equalsName(String otherName) {
        return (otherName == null) ? false : name.equals(otherName);
    }

    @Override
    public String toString() {
        return this.name;
    }
}