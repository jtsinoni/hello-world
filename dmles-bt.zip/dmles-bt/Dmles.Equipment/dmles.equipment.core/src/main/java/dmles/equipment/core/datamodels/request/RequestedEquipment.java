package dmles.equipment.core.datamodels.request;

public class RequestedEquipment {
    public String catalogId;
    public String description;
    public Boolean isFoundInCatalog;
    public String manufacturer;
    public String model;
    public String nomenclature;
    public String deviceCode;
    public String otherSystemRequired;
    public Float unitCost;   
}
