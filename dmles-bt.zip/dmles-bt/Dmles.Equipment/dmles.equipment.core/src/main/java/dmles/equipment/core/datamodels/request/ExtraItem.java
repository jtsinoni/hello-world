package dmles.equipment.core.datamodels.request;

public class ExtraItem {
    public String itemDescription;
    public String catalogNumber;
    public String unitOfPurchase;    
    public Float unitCost;
    public Integer quantity;
    public String type;       
}