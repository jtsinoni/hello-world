package dmles.equipment.core.datamodels.request.workflow.process;

public class ReviewResult {

    public Integer code;
    public String text;

}
