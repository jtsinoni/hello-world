package dmles.equipment.core.datamodels.request.workflow.process;

public enum ReviewResult {

    APPROVE("Approve"),
    RECOMMEND_APPROVE("Recommend Approve"),
    NOT_APPLICABLE("Not Applicable"),
    RECOMMEND_DISAPPROVE("Recommend Disapprove"),
    NOTE_CONCERN("Note Concern"),
    NEUTRAL("Neutral"),
    DISAPPROVE("Disapprove");

    private final String name;

    private ReviewResult(String s) {
        this.name = s;
    }

    public boolean equalsName(String otherName) {
        return (otherName == null) ? false : name.equals(otherName);
    }

    @Override
    public String toString() {
        return this.name;
    }

}
