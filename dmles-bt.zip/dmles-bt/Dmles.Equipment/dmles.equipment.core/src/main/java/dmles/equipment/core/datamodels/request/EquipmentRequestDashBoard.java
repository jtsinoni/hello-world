package dmles.equipment.core.datamodels.request;

/**
 * Created by tom.krotz on 11/17/2016.
 */
public class EquipmentRequestDashBoard {
    public Integer activeRequests;
    public Integer pendingActions;
    public Integer newRequests;
}
