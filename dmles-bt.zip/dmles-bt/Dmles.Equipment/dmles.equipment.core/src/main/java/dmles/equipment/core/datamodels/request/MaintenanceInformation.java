package dmles.equipment.core.datamodels.request;

import java.util.ArrayList;
import java.util.List;


public class MaintenanceInformation {

    public String acceptanceInspection;
    public Float estimatedAnnualServiceCost;
    public String installationRequired;
    public List<InstallRequirement> installationRequirements = new ArrayList<>();
    public List<Literature> literature = new ArrayList<>();
    public String maintenanceActivity;
    public Boolean maintenanceByOrg;
    public Boolean maintenanceByService;
    public Boolean maintenanceByOGA;
    public String maintenanceExplanation;
    public String tmdeRequired;
    public Float totalInstallationCosts;
    public Float totalLiteratureCosts;
    
}
