package dmles.equipment.core.datamodels.request;

import java.util.ArrayList;
import java.util.List;


public class MaintenanceInformation {
    public Boolean acceptanceInspection;
    public Float estimatedAnnualServiceCost;
    public String installationRequired;
    public String maintenanceActivity;
    public String maintenanceProvidedBy;
    public String maintenanceExplanation;
    public String tmdeRequired;
    public Float totalIncludedInstallationCosts;
    public Float totalOtherInstallationCosts;
    public Float totalLiteratureCosts;
    public List<InstallRequirement> installationRequirements = new ArrayList<>();
    public List<Literature> literature = new ArrayList<>();    
}
