package dmles.equipment.core.datamodels.request.workflow.definition;

public class LevelDefinitionWeighIn {
    public String elementName;
    public String roleId;
    public String weighInDisplayName;
}
