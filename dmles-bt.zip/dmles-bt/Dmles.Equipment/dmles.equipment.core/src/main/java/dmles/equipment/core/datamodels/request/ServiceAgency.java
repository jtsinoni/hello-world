package dmles.equipment.core.datamodels.request;

public class ServiceAgency {

    public String code;
    public String name;

}
