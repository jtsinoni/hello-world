package dmles.equipment.core.datamodels.request;

public class TrainingItem {
    public String trainees;
    public Integer people;
    public Boolean includedCost;
    public String location;
    public Float registrationCost;
    public Float travelCost;
    public Float perDiem;
    public Integer days;
    public Float total;
    public String comments;    
}
