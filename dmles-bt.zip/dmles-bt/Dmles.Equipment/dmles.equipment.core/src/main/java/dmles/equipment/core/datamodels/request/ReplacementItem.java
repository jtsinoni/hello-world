package dmles.equipment.core.datamodels.request;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.util.Date;

public class ReplacementItem {
    public String ecn;
    public String name;
    public String lifeExpectancy;
    public String condition;
    public String disposal;
    public String comment;
    
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSX")
    public Date acquisitionDate;
}
