package dmles.equipment.core.datamodels.request;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.util.Date;
import mil.jmlfdc.common.constants.DateAndTime;

public class ReplacementItem {
    public String ecn;
    public String name;
    public String lifeExpectancy;
    public String condition;
    public String disposal;
    public String comment;
    
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateAndTime.DATE_TIME_PATTERN)
    public Date acquisitionDate;
}
