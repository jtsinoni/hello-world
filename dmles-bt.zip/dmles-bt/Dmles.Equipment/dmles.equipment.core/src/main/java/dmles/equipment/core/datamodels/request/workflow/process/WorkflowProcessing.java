package dmles.equipment.core.datamodels.request.workflow.process;

import com.fasterxml.jackson.annotation.JsonFormat;
import dmles.equipment.core.datamodels.request.workflow.definition.WorkflowDefinition;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class WorkflowProcessing {
    public String id;
    public String requestId;
    public Integer currentLevelId;
    public String currentStatus;
    public String currentOwnerRole;
    public Boolean isCompleted;
    public WorkflowDefinition wfDefinition;
    public Map<Integer, WorkflowLevelProcessing> levels = new HashMap<>();
    public List<WorkflowComment> comments = new ArrayList<>();
    public List<WorkflowHistory> history = new ArrayList<>();
    public String updatedBy;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSX")
    public Date updatedDate;
}
