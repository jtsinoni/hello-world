package dmles.equipment.core.datamodels.request.workflow.definition;

public class Rules {
    public Boolean allowReviewBypassOnApprove;
    public Boolean allowReviewSelection;
    public Boolean allowForceUp;
    public Boolean allowAutoApproveAfterReview;
    public Boolean allowModify;
    public Boolean allowReject;
    public Boolean allowHold;
    public Boolean allowRework;
    public Boolean allowRequestCancel;
    public Boolean allowCancel;
    public Boolean allowOwnerOverrideNegativeReviews;
    public Boolean allowRetract;
    public Boolean allowNoteConcern;
}
