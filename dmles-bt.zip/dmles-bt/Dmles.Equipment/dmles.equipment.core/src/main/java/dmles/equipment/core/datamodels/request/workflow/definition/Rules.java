package dmles.equipment.core.datamodels.request.workflow.definition;

public class Rules {
    public Boolean allowWeighInBypassOnApprove;
    public Boolean allowWeighInSelection;
    public Boolean allowForceUp;
    public Boolean allowAutoApproveAfterWeighIn;
    public Boolean allowModify;
    public Boolean allowReject;
    public Boolean allowHold;
    public Boolean allowRework;
    public Boolean allowRequestCancel;
    public Boolean allowCancel;
    public Boolean allowOwnerOverrideNegativeWeighIns;
    public Boolean allowRetract;
    public Boolean allowNoteConcern;
}
