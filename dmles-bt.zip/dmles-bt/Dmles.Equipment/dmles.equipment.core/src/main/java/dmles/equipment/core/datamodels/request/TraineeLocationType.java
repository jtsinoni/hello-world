package dmles.equipment.core.datamodels.request;

public class TraineeLocationType {
    public String trainingLocationTypeCd;
    public String trainingLocationTypeTx;
}
