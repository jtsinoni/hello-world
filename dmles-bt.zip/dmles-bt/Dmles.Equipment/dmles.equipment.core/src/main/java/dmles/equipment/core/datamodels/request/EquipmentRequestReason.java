package dmles.equipment.core.datamodels.request;

public class EquipmentRequestReason {
    
    public String code;
    public String mask;
    public String name;    

}
