package dmles.equipment.core.datamodels.request;

public class Submitter {

    public String userId;
    public String nameFirst;
    public String nameLast;
    public String phoneNumber;
    public String email;
    public String dodaac;
    public String serviceCode;
    public String regionCode;
}
