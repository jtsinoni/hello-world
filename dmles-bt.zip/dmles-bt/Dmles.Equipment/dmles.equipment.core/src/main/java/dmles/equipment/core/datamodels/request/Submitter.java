package dmles.equipment.core.datamodels.request;

public class Submitter {

    public String userId;
    public String firstName;
    public String lastName;
    public String phoneNumber;
    public String email;
    public String dodaac;
    public String serviceCode;
    public String regionCode;
}
