package dmles.equipment.core.datamodels.record;

public class Approval {
    public String rankGrade;
    public String firstName;
    public String lastName;
    public String transReasTypeTx;
    public Integer mtfSerial;
    public String equipBalanceRefTx;
    public String specialty;
    public String sos;
    public String cfoAsstClsTyTx;
    public String duidTypeDesc;
    public String duiiStatusDesc;
}