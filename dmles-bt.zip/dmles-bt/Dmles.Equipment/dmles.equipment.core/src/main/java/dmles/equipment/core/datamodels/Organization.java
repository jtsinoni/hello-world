package dmles.equipment.core.datamodels;

public class Organization {
    public String id;
    public String organizationID;
    public String organizationOrgName;
    public String organizationSerial;    
}
