package dmles.equipment.core.datamodels.request;

public class Literature {
    
    public String type;
    public Float cost;
    public Integer quantity;
    public Float totalCost;

}
