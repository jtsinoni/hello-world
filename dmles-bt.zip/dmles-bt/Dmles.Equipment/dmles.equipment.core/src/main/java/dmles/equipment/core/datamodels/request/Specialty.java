package dmles.equipment.core.datamodels.request;

public class Specialty {
    private String code;
    private String description;
}
