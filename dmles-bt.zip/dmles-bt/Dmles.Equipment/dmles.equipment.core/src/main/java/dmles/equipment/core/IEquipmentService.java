package dmles.equipment.core;

import dmles.equipment.core.datamodels.record.EquipmentRecord;
import dmles.equipment.core.datamodels.request.*;
import dmles.equipment.core.datamodels.request.workflow.definition.LevelCriteria;
import dmles.equipment.core.datamodels.request.workflow.definition.WorkflowDefinition;
import dmles.equipment.core.datamodels.request.workflow.process.LevelCriteriaNeeded;
import dmles.equipment.core.datamodels.request.workflow.process.WorkflowProcessing;
import dmles.equipment.core.datamodels.request.workflow.process.ReviewResult;
import mil.jmlfdc.common.datamodel.Attachment;
import mil.jmlfdc.common.exception.InvalidDataException;
import mil.jmlfdc.common.exception.ObjectNotFoundException;
import mil.jmlfdc.common.exception.ValidationException;

import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import java.util.Date;
import java.util.List;

@Path("/V1")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public interface IEquipmentService {

    @GET
    @Path("/getAllEquipmentRequests")
    List<EquipmentRequest> getAllEquipmentRequests();

    @GET
    @Path("/getEquipmentRecordsCount")
    long getEquipmentRecordsCount();

    @GET
    @Path("/getCatalogSearchResults")
    Response getCatalogSearchResults(@QueryParam("searchValue") String searchValue,
                                     @QueryParam("dodaac") String dodaac);

    @GET
    @Path("/getEquipmentMaintenanceTypes")
    List<String> getEquipmentMaintenanceTypes(@QueryParam("serviceAgency") String serviceAgencyName);

    @GET
    @Path("/getCriticalCodes")
    List<RequestCriticality> getCriticalCodes(@QueryParam("serviceAgency") String serviceAgencyCode);

    @GET
    @Path("/getCriticalCodesByServiceAgencyCode")
    List<CriticalCodes> getCriticalCodesByServiceAgencyCodes(@QueryParam("serviceAgency") String serviceAgencyCode);

    @GET
    @Path("/getDevices")
    List<Device> getDevices();

    @GET
    @Path("/getEquipmentCriticalities")
    List<EquipmentCriticality> getEquipmentCriticalities();

    @GET
    @Path("/getEquipmentManufacturers")
    List<EquipmentManufacturer> getEquipmentManufacturers();

    @GET
    @Path("/getEquipmentMountingTypes")
    List<EquipmentMountingType> getEquipmentMountingTypes();

    @GET
    @Path("/getEquipmentRecord")
    EquipmentRecord getEquipmentRecord(@QueryParam("dodaac") String dodaac, @QueryParam("meId") int meId);

    @GET
    @Path("/getEquipmentRecordSearchResults")
    Response getEquipmentRecordSearchResults(@QueryParam("searchValue") String searchValue,
                                             @QueryParam("aggregations") String aggregations);

    @GET
    @Path("/getEquipmentSearchResults")
    Response getEquipmentSearchResults(@QueryParam("queryString") String queryString,
                                     @QueryParam("aggregations") String aggregations);
            
    @GET
    @Path("/getEquipmentRecords")
    List<EquipmentRecord> getEquipmentRecords(@QueryParam("dodaac") String dodaac,
                                              @QueryParam("meId") int meId);

    @GET
    @Path("/getEquipmentRequest")
    EquipmentRequest getEquipmentRequest(@QueryParam("id") String id);

    @GET
    @Path("/getEquipmentRequests")
    List<EquipmentRequest> getEquipmentRequests();

    @GET
    @Path("/getEquipmentRequestReasons")
    List<EquipmentRequestReason> getEquipmentRequestReasons();

    @GET
    @Path("/getEquipmentRequestTypes")
    List<EquipmentRequestType> getEquipmentRequestTypes();

    @GET
    @Path("/getEquipmentTraineeTypes")
    List<EquipmentTraineeType> getEquipmentTraineeTypes();

    @GET
    @Path("/getLiteratureTypes")
    List<LiteratureType> getLiteratureTypes();

    @GET
    @Path("/getEquipmentRequestDashBoard")
    EquipmentRequestDashBoard getEquipmentRequestDashBoard() throws ObjectNotFoundException;

    @GET
    @Path("/getSpecialties")
    List<Specialty> getSpecialties();

    @GET
    @Path("/getTraineeLocationTypes")
    List<TraineeLocationType> getTraineeLocationTypes();

    @GET
    @Path("/request/addProcessComment")
    EquipmentRequest addProcessComment(@QueryParam("requestId") String requestId, @QueryParam("comment") String comment) throws ObjectNotFoundException;

    @GET
    @Path("/request/removeProcessComment")
    EquipmentRequest removeProcessComment(@QueryParam("requestId") String requestId, @QueryParam("commentId") String commentId) throws ObjectNotFoundException;

    @GET
    @Path("/request/addReviewComment")
    EquipmentRequest addReviewComment(@QueryParam("requestId") String requestId,
                                      @QueryParam("reviewDisplayName") String reviewDisplayName,
                                      @QueryParam("comment") String comment) throws ObjectNotFoundException;

    @GET
    @Path("/request/removeReviewComment")
    EquipmentRequest removeReviewComment(@QueryParam("requestId") String requestId,
                                         @QueryParam("reviewDisplayName") String reviewDisplayName,
                                         @QueryParam("commentId") String commentId) throws ObjectNotFoundException;

    @GET
    @Path("/request/approve")
    EquipmentRequest approveRequest(@QueryParam("requestId") String requestId) throws ObjectNotFoundException;

    @GET
    @Path("/request/cancel")
    EquipmentRequest cancelRequest(@QueryParam("requestId") String requestId) throws ObjectNotFoundException;

    @GET
    @Path("/request/retract")
    EquipmentRequest retractRequest(@QueryParam("requestId") String requestId) throws ObjectNotFoundException, InvalidDataException;

    @GET
    @Path("/request/forceUp")
    EquipmentRequest forceUpRequest(@QueryParam("requestId") String requestId) throws ObjectNotFoundException;

    @GET
    @Path("/request/hold")
    EquipmentRequest holdRequest(@QueryParam("requestId") String requestId) throws ObjectNotFoundException;

    @GET
    @Path("/request/reactivate")
    EquipmentRequest reactivateRequest(@QueryParam("requestId") String requestId) throws ObjectNotFoundException;

    @GET
    @Path("/request/reject")
    EquipmentRequest rejectRequest(@QueryParam("requestId") String requestId) throws ObjectNotFoundException;

    @GET
    @Path("/request/rework")
    EquipmentRequest reworkRequest(@QueryParam("requestId") String requestId) throws ObjectNotFoundException;

    @POST
    @Path("/request/save")
    EquipmentRequest saveRequest(EquipmentRequest request) throws ObjectNotFoundException;

    @POST
    @Path("/request/saveAttachments")
    EquipmentRequest saveAttachments(@QueryParam("requestId") String requestId, List<Attachment> attachments) throws ObjectNotFoundException;

    @POST
    @Path("/request/saveRequestInfo")
    EquipmentRequest saveRequestInfo(EquipmentRequest request) throws ObjectNotFoundException;

    @POST
    @Path("/request/saveRequestCustomerInfo")
    EquipmentRequest saveRequestCustomerInfo(EquipmentRequest request) throws ObjectNotFoundException;

    @POST
    @Path("/request/saveRequestEquipmentInfo")
    EquipmentRequest saveRequestEquipmentInfo(EquipmentRequest request) throws ObjectNotFoundException;

    @POST
    @Path("/request/saveRequestExtraItems")
    EquipmentRequest saveRequestExtraItems(EquipmentRequest request) throws ObjectNotFoundException;

    @POST
    @Path("/request/saveRequestSourceOfSupply")
    EquipmentRequest saveRequestSourceOfSupply(EquipmentRequest request) throws ObjectNotFoundException;

    @POST
    @Path("/request/saveRequestTraining")
    EquipmentRequest saveRequestTraining(EquipmentRequest request) throws ObjectNotFoundException;

    @POST
    @Path("/request/saveFacilities")
    EquipmentRequest saveRequestFacilities(EquipmentRequest request) throws ObjectNotFoundException;

    @POST
    @Path("/request/saveMaintenance")
    EquipmentRequest saveRequestMaintenance(EquipmentRequest request) throws ObjectNotFoundException;

    @POST
    @Path("/request/saveTechnology")
    EquipmentRequest saveRequestTechnology(EquipmentRequest request) throws ObjectNotFoundException;

    @POST
    @Path("/request/saveSafety")
    EquipmentRequest saveRequestSafety(EquipmentRequest request) throws ObjectNotFoundException;

    @GET
    @Path("/request/submitForReview")
    EquipmentRequest submitForReview(@QueryParam("requestId") String requestId,
                                     @QueryParam("reviewRole") String reviewRole,
                                     @QueryParam("reviewDisplayName") String reviewDisplayName) throws ObjectNotFoundException;

    @POST
    @Path("/request/submitForProcessing")
    EquipmentRequest submitForProcessing(EquipmentRequest request) throws ObjectNotFoundException, ValidationException;

    @GET
    @Path("request/buildReviews")
    EquipmentRequest buildReviews(@QueryParam("requestId") String requestId) throws ObjectNotFoundException;

    @POST
    @Path("/request/submitReviewResult")
    EquipmentRequest submitReviewResult(@QueryParam("requestId") String requestId,
                                        @QueryParam("resultCode") Integer resultCode,
                                        @QueryParam("resultText") String resultText,
                                        @QueryParam("reviewDisplayName") String reviewDisplayName,
                                        @QueryParam("comment") String comment,
                                        EquipmentRequest request) throws ObjectNotFoundException;

    @POST
    @Path("/request/submitReviewStatus")
    EquipmentRequest submitReviewStatus(@QueryParam("requestId") String requestId,
                                        @QueryParam("status") String status,
                                        @QueryParam("reviewDisplayName") String reviewDisplayName,
                                        @QueryParam("comment") String comment,
                                        EquipmentRequest request) throws ObjectNotFoundException;

    @GET
    @Path("request/getReviewResults")
    List<ReviewResult> getReviewResults();

    @GET
    @Path("request/getReviewStatuses")
    List<String> getReviewStatuses();

    @GET
    @Path("/request/workflowDefinition/getDefinition")
    WorkflowDefinition getWorkflowDefinition(@QueryParam("service") String service) throws ObjectNotFoundException;

    @POST
    @Path("/request/workflowDefinition/createDefinition")
    WorkflowDefinition createWorkflowDefinition(WorkflowDefinition wfd) throws ObjectNotFoundException;

    @GET
    @Path("/request/workflowDefinition/addCatalogCriteria")
    WorkflowDefinition addWorkflowDefCatalogCriteria(@QueryParam("serviceName") String serviceName,
                                                     @QueryParam("levelID") String levelID,
                                                     @QueryParam("catalogID") String catalogID,
                                                     @QueryParam("catalogName") String catalogName) throws ObjectNotFoundException;

    @GET
    @Path("/request/workflowDefinition/removeCatalogCriteria")
    WorkflowDefinition removeWorkflowDefCatalogCriteria(@QueryParam("serviceName") String serviceName,
                                                        @QueryParam("levelID") String levelID,
                                                        @QueryParam("catalogID") String catalogID) throws ObjectNotFoundException;

    @GET
    @Path("/request/workflowDefinition/addDeviceCriteria")
    WorkflowDefinition addWorkflowDefDeviceCriteria(@QueryParam("serviceName") String serviceName,
                                                    @QueryParam("levelID") String levelID,
                                                    @QueryParam("deviceCode") String catalogID,
                                                    @QueryParam("deviceName") String catalogName) throws ObjectNotFoundException;

    @GET
    @Path("/request/workflowDefinition/removeDeviceCriteria")
    WorkflowDefinition removeWorkflowDefDeviceCriteria(@QueryParam("serviceName") String serviceName,
                                                       @QueryParam("levelID") String levelID,
                                                       @QueryParam("deviceCode") String catalogID) throws ObjectNotFoundException;

    @GET
    @Path("/request/workflowDefinition/updateCostCriteria")
    WorkflowDefinition updateWorkflowDefCostCriteria(@QueryParam("serviceName") String serviceName,
                                                     @QueryParam("levelID") String levelID,
                                                     @QueryParam("totalCost") String totalCost) throws ObjectNotFoundException;

    @GET
    @Path("/request/workflowDefinition/getWorkflowDefCriteria")
    LevelCriteria getWorkflowDefCriteria(@QueryParam("serviceName") String serviceName,
                                         @QueryParam("levelID") String levelID) throws ObjectNotFoundException;

    @POST
    @Path("/request/saveWorkflowProcess")
    EquipmentRequest saveWorkflowProcess(EquipmentRequest request) throws ObjectNotFoundException;

    @GET
    @Path("/getLevelsCriteriaNeeded")
    List<LevelCriteriaNeeded> getLevelsCriteriaNeeded(
            @QueryParam("requestId") String requestId) throws ObjectNotFoundException;

    @POST
    @Path("/getLevelsCriteriaNeeded")
    List<LevelCriteriaNeeded> getLevelsCriteriaNeeded(EquipmentRequest request) throws ObjectNotFoundException;

    @GET
    @Path("/request/getWorkflowProcessing")
    WorkflowProcessing getWorkflowProcessing(@QueryParam("id") String id) throws ObjectNotFoundException;

    @GET
    @Path("/request/getWorkflowProcessingByRequestId")
    WorkflowProcessing getWorkflowProcessingByRequestId(@QueryParam("requestId") String requestId) throws ObjectNotFoundException;


    @GET
    @Path("/sendEquipmentRequesToDMLSSById")
    EquipmentRequest sendEquipmentRequesToDMLSSById(@QueryParam("requestId") String requestId);

    @GET
    @Path("/getSiteEquipmentRecordByMeId")
    Long getSiteEquipmentRecordByMeId(@QueryParam("siteDoDAAC") String siteDoDAAC, @QueryParam("meId") String meId);

    @GET
    @Path("/getSiteEquipmentRecordByItemId")
    Long getSiteEquipmentRecordByItemId(@QueryParam("siteDoDAAC") String siteDoDAAC, @QueryParam("itemId") String itemId);

    @GET
    @Path("/getSiteEquipmentRecordAfterDate")
    Long getSiteEquipmentRecordAfterDate(@QueryParam("siteDoDAAC") String siteDoDAAC, @QueryParam("modifiedDate") Date modifiedDate);

    @GET
    @Path("/getSiteEquipmentRecordAll")
    Long getSiteEquipmentRecordAll(@QueryParam("siteDoDAAC") String siteDoDAAC);



    @POST
    @Path("/saveWorkflowDefinition")
    WorkflowDefinition saveWorkflowDefinition(
            WorkflowDefinition workflowDefinition);

    @POST
    @Path("/updateWorkflowLevel")
    WorkflowDefinition updateWorkflowLevel(
            WorkflowDefinition workflowDefinition);

    @POST
    @Path("/updateWorkflowDefLevelCriteria")
    WorkflowDefinition updateWorkflowDefLevelCriteria(
            WorkflowDefinition workflowDefinition);

    @POST
    @Path("/updateWorkflowDefReviewElements")
    WorkflowDefinition updateWorkflowDefReviewElements(
            WorkflowDefinition workflowDefinition);

    @POST
    @Path("/updateWorkflowDefRules")
    WorkflowDefinition updateWorkflowDefRules(
            WorkflowDefinition workflowDefinition);
}