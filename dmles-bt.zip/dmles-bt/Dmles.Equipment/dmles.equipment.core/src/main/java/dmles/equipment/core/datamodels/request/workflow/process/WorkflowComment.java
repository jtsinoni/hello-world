package dmles.equipment.core.datamodels.request.workflow.process;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.util.Date;

public class WorkflowComment {
    public Long id;
    public String firstName;
    public String lastName;
    public String comment;
    public String levelName;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSX")
    public Date created = new Date();
}