package dmles.equipment.core.datamodels.request.workflow.process;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.util.Date;

import mil.jmlfdc.common.constants.DateAndTime;

public class WorkflowComment {
    public Long id;
    public String firstName;
    public String lastName;
    public String comment;
    public String levelName;
    public String userId;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateAndTime.DATE_TIME_PATTERN)
    public Date created = new Date();
}