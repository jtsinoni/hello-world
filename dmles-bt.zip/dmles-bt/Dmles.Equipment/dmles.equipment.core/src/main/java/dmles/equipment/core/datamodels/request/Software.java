package dmles.equipment.core.datamodels.request;

public class Software {
    public String title;
    public String type;
    public String version;
}
