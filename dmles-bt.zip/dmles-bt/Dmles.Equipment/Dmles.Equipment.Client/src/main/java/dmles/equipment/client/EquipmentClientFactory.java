/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dmles.equipment.client;

import dmles.equipment.core.IEquipmentService;
import mil.jmlfdc.common.business.RestClientFactory;

import javax.enterprise.context.Dependent;

@Dependent
public class EquipmentClientFactory extends RestClientFactory<IEquipmentService> {
 
    public EquipmentClientFactory(){
        super(IEquipmentService.class, "Dmles.Equipment.Server");
    }
}
