package dmles.equipment.client;

import dmles.equipment.core.IEquipmentService;
import mil.jmlfdc.common.business.RestClientFactory;

import javax.enterprise.context.Dependent;

@Dependent
public class EquipmentClientFactory extends RestClientFactory<IEquipmentService> {
 
    public EquipmentClientFactory(){
        super(IEquipmentService.class, "Dmles.Equipment.Server");
    }
}