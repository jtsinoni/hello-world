package dmles.equipment.server.business;

import dmles.equipment.core.datamodels.request.workflow.process.LevelCriteriaNeeded;
import dmles.equipment.server.datamodels.request.EquipmentRequestDO;
import dmles.equipment.server.datamodels.request.workflow.definition.WorkflowLevelDefinitionDO;
import dmles.equipment.server.utils.RequestExtension;

class TotalCostCriteriaNeededEvaluator implements ICriteriaEvaluator {
    @Override
    public LevelCriteriaNeeded evaluateCriteria(LevelCriteriaNeeded lcn, EquipmentRequestDO request, WorkflowLevelDefinitionDO levelDef) {
        RequestExtension rex = new RequestExtension(request);

        Float totalFloat = levelDef.getLevelCriteria().getTotalCostThreshold();
        Double totalCostCriteria = null;
        if (totalFloat != null) {
            totalCostCriteria = new Double(totalFloat);
        }
        Double totalRequisitionCost = rex.getTotalCostAsDouble();
        if (null != totalRequisitionCost && null != totalCostCriteria) {
            lcn.costCriteriaMet = rex.meetsCostCriteria(totalRequisitionCost, totalCostCriteria);
        }
        return lcn;
    }

}
