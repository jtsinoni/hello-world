package dmles.equipment.server.business;

import dmles.common.general.logging.Logger;
import dmles.equipment.core.datamodels.request.EquipmentRequest;
import dmles.equipment.server.dao.EquipmentRequestDao;
import dmles.equipment.server.dao.WorkflowProcessingDao;
import dmles.equipment.server.datamodels.request.EquipmentRequestDO;
import dmles.equipment.server.datamodels.request.workflow.process.WorkflowProcessingDO;
import mil.jmlfdc.common.datamodel.CurrentUserBT;
import mil.jmlfdc.common.exception.ObjectNotFoundException;
import mil.jmlfdc.common.utils.ObjectMapper;

import java.util.Date;
import javax.enterprise.context.Dependent;
import javax.inject.Inject;
import javax.validation.constraints.NotNull;

@Dependent
public class EquipmentRequestPersistenceHelper {

    @Inject
    private Logger logger;
    @Inject
    private CurrentUserBT user;
    @Inject
    private ObjectMapper objectMapper;
    @Inject
    private EquipmentRequestDao equipReqDao;
    @Inject
    private WorkflowProcessingDao wfProcessingDao;

    public EquipmentRequestDO getRequest(@NotNull String id) {
        return equipReqDao.findById(id);
    }

    public EquipmentRequest saveRequest(@NotNull EquipmentRequest request) throws ObjectNotFoundException {
        EquipmentRequestDO erDo = objectMapper.getObject(EquipmentRequestDO.class, request);
        erDo = saveRequest(erDo, null);
        return objectMapper.getObject(EquipmentRequest.class, erDo);
    }

    public EquipmentRequestDO saveRequest(@NotNull EquipmentRequestDO request, WorkflowLogic wfLogic) throws ObjectNotFoundException {
        String fullName = user.getFirstName() + " " + user.getLastName();
        request.setUpdatedBy(fullName);
        request.setUpdatedDate(new Date());
        equipReqDao.upsert(request);
        
        if (null != wfLogic) {
            saveProcessing(wfLogic);
        }

        return equipReqDao.findById(request.getId());
    }
    
    public void saveProcessing(WorkflowLogic wfLogic){
        WorkflowProcessingDO wfProcessing = wfLogic.getRequest().getWfProcessing();
        wfLogic.saveWfProcessing();
        wfProcessingDao.update(wfProcessing);
    }
    
}
