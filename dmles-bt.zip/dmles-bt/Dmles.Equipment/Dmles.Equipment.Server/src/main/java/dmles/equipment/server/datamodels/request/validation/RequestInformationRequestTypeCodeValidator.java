package dmles.equipment.server.datamodels.request.validation;

import dmles.equipment.server.datamodels.request.EquipmentRequestTypeDO;
import dmles.equipment.server.datamodels.request.ReplacementItemDO;
import dmles.equipment.server.datamodels.request.RequestInformationDO;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class RequestInformationRequestTypeCodeValidator implements ConstraintValidator<RequestInformationRequestTypeCode, RequestInformationDO> {

   private static final List<String> TYPE_CODES_VALIDATION = new ArrayList<String>(Arrays.asList("N", "U", "A"));

   public void initialize(RequestInformationRequestTypeCode constraint) {
   }

   public boolean isValid(RequestInformationDO obj, ConstraintValidatorContext context) {
      boolean isValid = false;

      EquipmentRequestTypeDO type = obj.getRequestType();
      if (type == null || type.getCode() == null) {
         isValid = true;
      } else {
         String code = type.getCode();
         List<ReplacementItemDO> replacedItems = obj.getReplacedItems();

         if (TYPE_CODES_VALIDATION.contains(code) && (replacedItems == null || replacedItems.isEmpty())){
            isValid = false;
         } else {
            isValid = true;
         }
      }

      return isValid;
   }
}
