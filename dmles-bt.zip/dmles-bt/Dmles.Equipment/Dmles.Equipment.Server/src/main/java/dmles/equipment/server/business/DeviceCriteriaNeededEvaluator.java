package dmles.equipment.server.business;

import dmles.equipment.core.datamodels.request.workflow.process.LevelCriteriaNeeded;
import dmles.equipment.server.datamodels.request.EquipmentRequestDO;
import dmles.equipment.server.datamodels.request.RequestInformationDO;
import dmles.equipment.server.datamodels.request.workflow.definition.CriteriaDeviceDO;
import dmles.equipment.server.datamodels.request.workflow.definition.LevelCriteriaDO;
import dmles.equipment.server.datamodels.request.workflow.definition.WorkflowLevelDefinitionDO;
import dmles.equipment.server.utils.RequestExtension;

import java.util.List;

class DeviceCriteriaNeededEvaluator implements ICriteriaEvaluator {
    @Override
    public LevelCriteriaNeeded evaluateCriteria(LevelCriteriaNeeded lcn, EquipmentRequestDO request,
                                                WorkflowLevelDefinitionDO levelDef) {

        RequestExtension reqEx = new RequestExtension(request);
        Double totalCost = reqEx.getTotalCostAsDouble();

        LevelCriteriaDO levelCriteria = levelDef.getLevelCriteria();
        Float deviceCostThresholdFloat = levelCriteria.getDeviceCostThreshold();
        Double deviceCostThreshold = null;
        if (deviceCostThresholdFloat != null) {
            deviceCostThreshold = new Double(deviceCostThresholdFloat);
        }

        boolean meetsCriteria = reqEx.meetsCostCriteria(totalCost, deviceCostThreshold);

        List<CriteriaDeviceDO> deviceCriteriaList = levelCriteria.getDevices();
        RequestInformationDO reqInfo = request.getRequestInformation();
         if (meetsCriteria && deviceCriteriaList != null &&  reqInfo != null
                    && reqInfo.getEquipment() != null) {
            String deviceCode = reqInfo.getEquipment().getDeviceCode();
            if (deviceCode != null) {
                lcn.deviceCriteriaMet = meetsDeviceCriteria(deviceCode, deviceCriteriaList);
            }
        }
        return lcn;
    }

    private boolean meetsDeviceCriteria(String deviceCode, List<CriteriaDeviceDO> devicesCriteria) {
        boolean isFound = false;
        for (CriteriaDeviceDO deviceCriteria : devicesCriteria) {
            String deviceCritLower = deviceCriteria.getDeviceCode().toLowerCase();
            String deviceCodeLower = deviceCode.toLowerCase();
            if (deviceCritLower.equals(deviceCodeLower)) {
                isFound = true;
                break;
            }
        }
        return isFound;
    }


}
