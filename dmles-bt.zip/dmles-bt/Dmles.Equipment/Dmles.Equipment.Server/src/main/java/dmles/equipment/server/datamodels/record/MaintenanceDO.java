package dmles.equipment.server.datamodels.record;

import org.mongodb.morphia.annotations.Embedded;
import org.mongodb.morphia.annotations.Property;

import java.io.Serializable;

@Embedded
public class MaintenanceDO implements Serializable {

    private static final long serialVersionUID = 1L;

    @Property("DEVICE_CD")
    private String deviceCd;

    @Property("ert_readiness_cd_and_text")
    private String ertReadinessCdAndText;

    @Property("ME_ECN_ID")
    private String meEcnId;

    @Property("MA_SERIAL")
    private Integer maSerial;

    @Property("ME_ID")
    private Integer meId;   

    private Float mel;
    private Float mrlc;
    private Integer mpId;
    private Integer workOrderCount;
    private String contractorNm;
    private String eiTmdeInd;
    private String maintActivityOrgNm;
    private String maintAssmntTyTx;
    private String operationalStatus;
    private String operationalStatusTx;
    private String otherGovtMaintSrc;
    private String rltDescTx;
    private String schedFactorTx;
    private String schedTeamOrgNm;
    private String unschedTeamOrgNm;

    public String getDeviceCd() {
        return deviceCd;
    }

    public void setDeviceCd(String deviceCd) {
        this.deviceCd = deviceCd;
    }

    public String getErtReadinessCdAndText() {
        return ertReadinessCdAndText;
    }

    public void setErtReadinessCdAndText(String ertReadinessCdAndText) {
        this.ertReadinessCdAndText = ertReadinessCdAndText;
    }

    public String getMeEcnId() {
        return meEcnId;
    }

    public void setMeEcnId(String meEcnId) {
        this.meEcnId = meEcnId;
    }

    public Integer getMaSerial() {
        return maSerial;
    }

    public void setMaSerial(Integer maSerial) {
        this.maSerial = maSerial;
    }

    public Integer getMeId() {
        return meId;
    }

    public void setMeId(Integer meId) {
        this.meId = meId;
    }

    public Float getMel() {
        return mel;
    }

    public void setMel(Float mel) {
        this.mel = mel;
    }

    public Float getMrlc() {
        return mrlc;
    }

    public void setMrlc(Float mrlc) {
        this.mrlc = mrlc;
    }

    public Integer getMpId() {
        return mpId;
    }

    public void setMpId(Integer mpId) {
        this.mpId = mpId;
    }

    public Integer getWorkOrderCount() {
        return workOrderCount;
    }

    public void setWorkOrderCount(Integer workOrderCount) {
        this.workOrderCount = workOrderCount;
    }

    public String getContractorNm() {
        return contractorNm;
    }

    public void setContractorNm(String contractorNm) {
        this.contractorNm = contractorNm;
    }

    public String getEiTmdeInd() {
        return eiTmdeInd;
    }

    public void setEiTmdeInd(String eiTmdeInd) {
        this.eiTmdeInd = eiTmdeInd;
    }

    public String getMaintActivityOrgNm() {
        return maintActivityOrgNm;
    }

    public void setMaintActivityOrgNm(String maintActivityOrgNm) {
        this.maintActivityOrgNm = maintActivityOrgNm;
    }

    public String getMaintAssmntTyTx() {
        return maintAssmntTyTx;
    }

    public void setMaintAssmntTyTx(String maintAssmntTyTx) {
        this.maintAssmntTyTx = maintAssmntTyTx;
    }

    public String getOperationalStatus() {
        return operationalStatus;
    }

    public void setOperationalStatus(String operationalStatus) {
        this.operationalStatus = operationalStatus;
    }

    public String getOperationalStatusTx() {
        return operationalStatusTx;
    }

    public void setOperationalStatusTx(String operationalStatusTx) {
        this.operationalStatusTx = operationalStatusTx;
    }

    public String getOtherGovtMaintSrc() {
        return otherGovtMaintSrc;
    }

    public void setOtherGovtMaintSrc(String otherGovtMaintSrc) {
        this.otherGovtMaintSrc = otherGovtMaintSrc;
    }

    public String getRltDescTx() {
        return rltDescTx;
    }

    public void setRltDescTx(String rltDescTx) {
        this.rltDescTx = rltDescTx;
    }

    public String getSchedFactorTx() {
        return schedFactorTx;
    }

    public void setSchedFactorTx(String schedFactorTx) {
        this.schedFactorTx = schedFactorTx;
    }

    public String getSchedTeamOrgNm() {
        return schedTeamOrgNm;
    }

    public void setSchedTeamOrgNm(String schedTeamOrgNm) {
        this.schedTeamOrgNm = schedTeamOrgNm;
    }

    public String getUnschedTeamOrgNm() {
        return unschedTeamOrgNm;
    }

    public void setUnschedTeamOrgNm(String unschedTeamOrgNm) {
        this.unschedTeamOrgNm = unschedTeamOrgNm;
    }
}