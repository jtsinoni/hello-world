package dmles.equipment.server.datamodels.record;

import mil.jmlfdc.common.datamodel.MorphiaEntity;

import org.mongodb.morphia.annotations.Embedded;
import org.mongodb.morphia.annotations.Entity;
import org.mongodb.morphia.annotations.Property;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Entity("EquipmentRecords")
public class EquipmentRecordDO extends MorphiaEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Embedded
    private List<ApprovalDO> approval = new ArrayList<>();

    @Embedded
    private List<ComponentsDO> components = new ArrayList<>();

    @Embedded
    private List<LocationInventoryDO> locationInventory = new ArrayList<>();

    @Embedded
    private List<MaintCostDO> maintCost = new ArrayList<>();

    @Embedded
    private List<MaintenanceDO> maintenance = new ArrayList<>();

    @Embedded
    private List<MaintenanceTypeDO> maintenanceType = new ArrayList<>();

    @Embedded
    private List<NotesDO> notes = new ArrayList<>();

    public EquipmentRecordDO() {}

    public EquipmentRecordDO(List<ApprovalDO> approval, List<ComponentsDO> components, 
        List<LocationInventoryDO> locationInventory, List<MaintCostDO> maintCost, List<MaintenanceDO> maintenance, 
        List<MaintenanceTypeDO> maintenanceType, List<NotesDO> notes) {
        this.approval = approval;
        this.components = components;
        this.locationInventory = locationInventory;
        this.maintCost = maintCost;
        this.maintenance = maintenance;
        this.maintenanceType = maintenanceType;
        this.notes = notes;
    }

    @Property("assemblage_count")
    private Integer assemblageCount;

    @Property("assm_inst_num")
    private Integer assmInstNum;

    private Float meAccumDeprtAmt;
    private Float meAcqCostQty;
    private Float meDiscountAmt;
    private Float meInstalltionAmt;
    private Float meOtherMiscAmt;
    private Float meTradeInAmt;
    private Float meTransportAmt;
    private Float meUpgradeCstAmt;
    private Float totalAqcCost;
    private Integer assemblyMtfSer;
    private Integer commodClsSer;
    private Integer custOrgSerial;
    private Integer custdnPocSer;
    private Integer customerOrgSer;
    private Integer devclfExpctnQty;
    private Integer eqpmtOwnerTypCd;
    private Integer equipBalanceId;
    private Integer facilitySerial;
    private Integer fundSerial;
    private Integer itemSerial;
    private Integer maSerial;
    private Integer maintAssmntTyCd;
    private Integer maintSrcOrgSer;
    private Integer manufMdlSerId;
    private Integer manufOrgSerial;
    private Integer meDepRecoveryMonths;
    private Integer meId;
    private Integer meModificatnCd;
    private Integer meMrlcQty;
    private Integer meSystemId;
    private Integer mfrDivSerial;
    private Integer mtfEMSerial;
    private Integer mtfOrgSerial;
    private Integer networkConnectionTypeId;
    private Integer otherGovtSosSer;
    private Integer pltPermLocSer;
    private Integer roomSerial;
    private Integer schedFactorCd;
    private Integer sosSerial;
    private Integer subCustdnPocSer;
    private Integer swOpSysSer;
    private Integer updateMarker;
    private Integer usmantSrcOrgSer;
    private String acqCapitalEquip;
    private String acqCommodClsTx;
    private String acqFunctionId;
    private String acqFundCd;
    private String acqSpecialtyCode;
    private String assemblyOrgID;
    private String assemblyOrgNM;
    private String assetTypeCd;
    private String assmDescrDetail;
    private String assmInstDescr;
    private String assmNumDetail;
    private String cfoAsstClsTyCd;
    private String csvcPoNumId;
    private String custOrgNM;
    private String custodianName;
    private String custodianPhone;
    private String dateDuiiStatus;
    private String deleteInd;
    private String deviceCd;
    private String deviceClsCode;
    private String deviceClsText;
    private String deviceText;
    private String duiiStatusCd;
    private String eiAccntblCd;
    private String eiMaintReqrCd;
    private String entityInd;
    private String eqpmtInvMthdCd;
    private String eqptInvReasonCd;
    private String equipAccountingStatusCd;
    private String ertReadinessCd;
    private String itemId;
    private String localContractId;
    private String meAccountingStatusDt;
    private String meAcnId;
    private String meAcqDt;
    private String meApplicationEntityTitleTx;
    private String meApprovalRefTx;
    private String meAtoExpiresDt;
    private String meAtoIssuedDt;
    private String meAtsScannedByTx;
    private String meAtsStatusCd;
    private String meAtsStatusTx;
    private String meClinAlarmInd;
    private String meContrctrIndCd;
    private String meCreateDocNum;
    private String meDownStatusCd;
    private String meDuidTypeCd;
    private String meEcnId;
    private String meEqpmtReqstId;
    private String meFirmwareVerId;
    private String meFyFundDate;
    private String meGfeLoanInd;
    private String meInstallationDt;
    private String meInvKeyInCd;
    private String meInvLocationTx;
    private String meInvPerfrmNm;
    private String meIpv4Address1Tx;
    private String meIpv4Address2Tx;
    private String meIpv6Address1Tx;
    private String meIpv6Address2Tx;
    private String meIuid;
    private String meIuidAffixedDt;
    private String meIuidAffixedInd;
    private String meIuidAffixedUserId;
    private String meJmarTransmInd;
    private String meLastInvntryDt;
    private String meLastSvcDt;
    private String meLifeSafetyInd;
    private String meMacAddressTx;
    private String meMachineNm;
    private String meManufModelId;
    private String meManufacturedDt;
    private String meMfgSerialId;
    private String meNetworkConnectionInd;
    private String meOnloanCd;
    private String mePatientDataInd;
    private String meReturnDt;
    private String meRfLocTx;
    private String meRfTime;
    private String meRfid;
    private String meRfidAffixedDt;
    private String meSuspdSchedInd;
    private String meSuspdSchedWoReasonTx;
    private String meTempLocTx;
    private String meVendorSiteId;
    private String meWarntyBegDt;
    private String meWarntyLabrEdt;
    private String meWarntyPartEdt;
    private String meWirelessFrequencyTx;
    private String meWrmPeactmCd;
    private String mtfOrgID;
    private String mtfOrgNM;
    private String orgID;
    private String recvdFromDocnum;
    private String siteDoDDAC;
    private String sourceDodaac;
    private String sourceMeId;
    private String subCustodianName;
    private String subCustodianPH;
    private String supplyCond;
    private String systemTypeCd;
    private String transCd;
    private String transReasTypeCd;
    private String uidTypeCd;

    public List<ApprovalDO> getApproval() {
        return approval;
    }

    public void setApproval(List<ApprovalDO> approval) {
        this.approval = approval;
    }

    public List<ComponentsDO> getComponents() {
        return components;
    }

    public void setComponents(List<ComponentsDO> components) {
        this.components = components;
    }

    public List<LocationInventoryDO> getLocationInventory() {
        return locationInventory;
    }

    public void setLocationInventory(List<LocationInventoryDO> locationInventory) {
        this.locationInventory = locationInventory;
    }

    public List<MaintCostDO> getMaintCost() {
        return maintCost;
    }

    public void setMaintCost(List<MaintCostDO> maintCost) {
        this.maintCost = maintCost;
    }

    public List<MaintenanceDO> getMaintenance() {
        return maintenance;
    }

    public void setMaintenance(List<MaintenanceDO> maintenance) {
        this.maintenance = maintenance;
    }

    public List<MaintenanceTypeDO> getMaintenanceType() {
        return maintenanceType;
    }

    public void setMaintenanceType(List<MaintenanceTypeDO> maintenanceType) {
        this.maintenanceType = maintenanceType;
    }

    public List<NotesDO> getNotes() {
        return notes;
    }

    public void setNotes(List<NotesDO> notes) {
        this.notes = notes;
    }

    public Integer getAssemblageCount() {
        return assemblageCount;
    }

    public void setAssemblageCount(Integer assemblageCount) {
        this.assemblageCount = assemblageCount;
    }

    public Integer getAssmInstNum() {
        return assmInstNum;
    }

    public void setAssmInstNum(Integer assmInstNum) {
        this.assmInstNum = assmInstNum;
    }

    public Float getMeAccumDeprtAmt() {
        return meAccumDeprtAmt;
    }

    public void setMeAccumDeprtAmt(Float meAccumDeprtAmt) {
        this.meAccumDeprtAmt = meAccumDeprtAmt;
    }

    public Float getMeAcqCostQty() {
        return meAcqCostQty;
    }

    public void setMeAcqCostQty(Float meAcqCostQty) {
        this.meAcqCostQty = meAcqCostQty;
    }

    public Float getMeDiscountAmt() {
        return meDiscountAmt;
    }

    public void setMeDiscountAmt(Float meDiscountAmt) {
        this.meDiscountAmt = meDiscountAmt;
    }

    public Float getMeInstalltionAmt() {
        return meInstalltionAmt;
    }

    public void setMeInstalltionAmt(Float meInstalltionAmt) {
        this.meInstalltionAmt = meInstalltionAmt;
    }

    public Float getMeOtherMiscAmt() {
        return meOtherMiscAmt;
    }

    public void setMeOtherMiscAmt(Float meOtherMiscAmt) {
        this.meOtherMiscAmt = meOtherMiscAmt;
    }

    public Float getMeTradeInAmt() {
        return meTradeInAmt;
    }

    public void setMeTradeInAmt(Float meTradeInAmt) {
        this.meTradeInAmt = meTradeInAmt;
    }

    public Float getMeTransportAmt() {
        return meTransportAmt;
    }

    public void setMeTransportAmt(Float meTransportAmt) {
        this.meTransportAmt = meTransportAmt;
    }

    public Float getMeUpgradeCstAmt() {
        return meUpgradeCstAmt;
    }

    public void setMeUpgradeCstAmt(Float meUpgradeCstAmt) {
        this.meUpgradeCstAmt = meUpgradeCstAmt;
    }

    public Float getTotalAqcCost() {
        return totalAqcCost;
    }

    public void setTotalAqcCost(Float totalAqcCost) {
        this.totalAqcCost = totalAqcCost;
    }

    public Integer getAssemblyMtfSer() {
        return assemblyMtfSer;
    }

    public void setAssemblyMtfSer(Integer assemblyMtfSer) {
        this.assemblyMtfSer = assemblyMtfSer;
    }

    public Integer getCommodClsSer() {
        return commodClsSer;
    }

    public void setCommodClsSer(Integer commodClsSer) {
        this.commodClsSer = commodClsSer;
    }

    public Integer getCustOrgSerial() {
        return custOrgSerial;
    }

    public void setCustOrgSerial(Integer custOrgSerial) {
        this.custOrgSerial = custOrgSerial;
    }

    public Integer getCustdnPocSer() {
        return custdnPocSer;
    }

    public void setCustdnPocSer(Integer custdnPocSer) {
        this.custdnPocSer = custdnPocSer;
    }

    public Integer getCustomerOrgSer() {
        return customerOrgSer;
    }

    public void setCustomerOrgSer(Integer customerOrgSer) {
        this.customerOrgSer = customerOrgSer;
    }

    public Integer getDevclfExpctnQty() {
        return devclfExpctnQty;
    }

    public void setDevclfExpctnQty(Integer devclfExpctnQty) {
        this.devclfExpctnQty = devclfExpctnQty;
    }

    public Integer getEqpmtOwnerTypCd() {
        return eqpmtOwnerTypCd;
    }

    public void setEqpmtOwnerTypCd(Integer eqpmtOwnerTypCd) {
        this.eqpmtOwnerTypCd = eqpmtOwnerTypCd;
    }

    public Integer getEquipBalanceId() {
        return equipBalanceId;
    }

    public void setEquipBalanceId(Integer equipBalanceId) {
        this.equipBalanceId = equipBalanceId;
    }

    public Integer getFacilitySerial() {
        return facilitySerial;
    }

    public void setFacilitySerial(Integer facilitySerial) {
        this.facilitySerial = facilitySerial;
    }

    public Integer getFundSerial() {
        return fundSerial;
    }

    public void setFundSerial(Integer fundSerial) {
        this.fundSerial = fundSerial;
    }

    public Integer getItemSerial() {
        return itemSerial;
    }

    public void setItemSerial(Integer itemSerial) {
        this.itemSerial = itemSerial;
    }

    public Integer getMaSerial() {
        return maSerial;
    }

    public void setMaSerial(Integer maSerial) {
        this.maSerial = maSerial;
    }

    public Integer getMaintAssmntTyCd() {
        return maintAssmntTyCd;
    }

    public void setMaintAssmntTyCd(Integer maintAssmntTyCd) {
        this.maintAssmntTyCd = maintAssmntTyCd;
    }

    public Integer getMaintSrcOrgSer() {
        return maintSrcOrgSer;
    }

    public void setMaintSrcOrgSer(Integer maintSrcOrgSer) {
        this.maintSrcOrgSer = maintSrcOrgSer;
    }

    public Integer getManufMdlSerId() {
        return manufMdlSerId;
    }

    public void setManufMdlSerId(Integer manufMdlSerId) {
        this.manufMdlSerId = manufMdlSerId;
    }

    public Integer getManufOrgSerial() {
        return manufOrgSerial;
    }

    public void setManufOrgSerial(Integer manufOrgSerial) {
        this.manufOrgSerial = manufOrgSerial;
    }

    public Integer getMeDepRecoveryMonths() {
        return meDepRecoveryMonths;
    }

    public void setMeDepRecoveryMonths(Integer meDepRecoveryMonths) {
        this.meDepRecoveryMonths = meDepRecoveryMonths;
    }

    public Integer getMeId() {
        return meId;
    }

    public void setMeId(Integer meId) {
        this.meId = meId;
    }

    public Integer getMeModificatnCd() {
        return meModificatnCd;
    }

    public void setMeModificatnCd(Integer meModificatnCd) {
        this.meModificatnCd = meModificatnCd;
    }

    public Integer getMeMrlcQty() {
        return meMrlcQty;
    }

    public void setMeMrlcQty(Integer meMrlcQty) {
        this.meMrlcQty = meMrlcQty;
    }

    public Integer getMeSystemId() {
        return meSystemId;
    }

    public void setMeSystemId(Integer meSystemId) {
        this.meSystemId = meSystemId;
    }

    public Integer getMfrDivSerial() {
        return mfrDivSerial;
    }

    public void setMfrDivSerial(Integer mfrDivSerial) {
        this.mfrDivSerial = mfrDivSerial;
    }

    public Integer getMtfEMSerial() {
        return mtfEMSerial;
    }

    public void setMtfEMSerial(Integer mtfEMSerial) {
        this.mtfEMSerial = mtfEMSerial;
    }

    public Integer getMtfOrgSerial() {
        return mtfOrgSerial;
    }

    public void setMtfOrgSerial(Integer mtfOrgSerial) {
        this.mtfOrgSerial = mtfOrgSerial;
    }

    public Integer getNetworkConnectionTypeId() {
        return networkConnectionTypeId;
    }

    public void setNetworkConnectionTypeId(Integer networkConnectionTypeId) {
        this.networkConnectionTypeId = networkConnectionTypeId;
    }

    public Integer getOtherGovtSosSer() {
        return otherGovtSosSer;
    }

    public void setOtherGovtSosSer(Integer otherGovtSosSer) {
        this.otherGovtSosSer = otherGovtSosSer;
    }

    public Integer getPltPermLocSer() {
        return pltPermLocSer;
    }

    public void setPltPermLocSer(Integer pltPermLocSer) {
        this.pltPermLocSer = pltPermLocSer;
    }

    public Integer getRoomSerial() {
        return roomSerial;
    }

    public void setRoomSerial(Integer roomSerial) {
        this.roomSerial = roomSerial;
    }

    public Integer getSchedFactorCd() {
        return schedFactorCd;
    }

    public void setSchedFactorCd(Integer schedFactorCd) {
        this.schedFactorCd = schedFactorCd;
    }

    public Integer getSosSerial() {
        return sosSerial;
    }

    public void setSosSerial(Integer sosSerial) {
        this.sosSerial = sosSerial;
    }

    public Integer getSubCustdnPocSer() {
        return subCustdnPocSer;
    }

    public void setSubCustdnPocSer(Integer subCustdnPocSer) {
        this.subCustdnPocSer = subCustdnPocSer;
    }

    public Integer getSwOpSysSer() {
        return swOpSysSer;
    }

    public void setSwOpSysSer(Integer swOpSysSer) {
        this.swOpSysSer = swOpSysSer;
    }

    public Integer getUpdateMarker() {
        return updateMarker;
    }

    public void setUpdateMarker(Integer updateMarker) {
        this.updateMarker = updateMarker;
    }

    public Integer getUsmantSrcOrgSer() {
        return usmantSrcOrgSer;
    }

    public void setUsmantSrcOrgSer(Integer usmantSrcOrgSer) {
        this.usmantSrcOrgSer = usmantSrcOrgSer;
    }

    public String getAcqCapitalEquip() {
        return acqCapitalEquip;
    }

    public void setAcqCapitalEquip(String acqCapitalEquip) {
        this.acqCapitalEquip = acqCapitalEquip;
    }

    public String getAcqCommodClsTx() {
        return acqCommodClsTx;
    }

    public void setAcqCommodClsTx(String acqCommodClsTx) {
        this.acqCommodClsTx = acqCommodClsTx;
    }

    public String getAcqFunctionId() {
        return acqFunctionId;
    }

    public void setAcqFunctionId(String acqFunctionId) {
        this.acqFunctionId = acqFunctionId;
    }

    public String getAcqFundCd() {
        return acqFundCd;
    }

    public void setAcqFundCd(String acqFundCd) {
        this.acqFundCd = acqFundCd;
    }

    public String getAcqSpecialtyCode() {
        return acqSpecialtyCode;
    }

    public void setAcqSpecialtyCode(String acqSpecialtyCode) {
        this.acqSpecialtyCode = acqSpecialtyCode;
    }

    public String getAssemblyOrgID() {
        return assemblyOrgID;
    }

    public void setAssemblyOrgID(String assemblyOrgID) {
        this.assemblyOrgID = assemblyOrgID;
    }

    public String getAssemblyOrgNM() {
        return assemblyOrgNM;
    }

    public void setAssemblyOrgNM(String assemblyOrgNM) {
        this.assemblyOrgNM = assemblyOrgNM;
    }

    public String getAssetTypeCd() {
        return assetTypeCd;
    }

    public void setAssetTypeCd(String assetTypeCd) {
        this.assetTypeCd = assetTypeCd;
    }

    public String getAssmDescrDetail() {
        return assmDescrDetail;
    }

    public void setAssmDescrDetail(String assmDescrDetail) {
        this.assmDescrDetail = assmDescrDetail;
    }

    public String getAssmInstDescr() {
        return assmInstDescr;
    }

    public void setAssmInstDescr(String assmInstDescr) {
        this.assmInstDescr = assmInstDescr;
    }

    public String getAssmNumDetail() {
        return assmNumDetail;
    }

    public void setAssmNumDetail(String assmNumDetail) {
        this.assmNumDetail = assmNumDetail;
    }

    public String getCfoAsstClsTyCd() {
        return cfoAsstClsTyCd;
    }

    public void setCfoAsstClsTyCd(String cfoAsstClsTyCd) {
        this.cfoAsstClsTyCd = cfoAsstClsTyCd;
    }

    public String getCsvcPoNumId() {
        return csvcPoNumId;
    }

    public void setCsvcPoNumId(String csvcPoNumId) {
        this.csvcPoNumId = csvcPoNumId;
    }

    public String getCustOrgNM() {
        return custOrgNM;
    }

    public void setCustOrgNM(String custOrgNM) {
        this.custOrgNM = custOrgNM;
    }

    public String getCustodianName() {
        return custodianName;
    }

    public void setCustodianName(String custodianName) {
        this.custodianName = custodianName;
    }

    public String getCustodianPhone() {
        return custodianPhone;
    }

    public void setCustodianPhone(String custodianPhone) {
        this.custodianPhone = custodianPhone;
    }

    public String getDateDuiiStatus() {
        return dateDuiiStatus;
    }

    public void setDateDuiiStatus(String dateDuiiStatus) {
        this.dateDuiiStatus = dateDuiiStatus;
    }

    public String getDeleteInd() {
        return deleteInd;
    }

    public void setDeleteInd(String deleteInd) {
        this.deleteInd = deleteInd;
    }

    public String getDeviceCd() {
        return deviceCd;
    }

    public void setDeviceCd(String deviceCd) {
        this.deviceCd = deviceCd;
    }

    public String getDeviceClsCode() {
        return deviceClsCode;
    }

    public void setDeviceClsCode(String deviceClsCode) {
        this.deviceClsCode = deviceClsCode;
    }

    public String getDeviceClsText() {
        return deviceClsText;
    }

    public void setDeviceClsText(String deviceClsText) {
        this.deviceClsText = deviceClsText;
    }

    public String getDeviceText() {
        return deviceText;
    }

    public void setDeviceText(String deviceText) {
        this.deviceText = deviceText;
    }

    public String getDuiiStatusCd() {
        return duiiStatusCd;
    }

    public void setDuiiStatusCd(String duiiStatusCd) {
        this.duiiStatusCd = duiiStatusCd;
    }

    public String getEiAccntblCd() {
        return eiAccntblCd;
    }

    public void setEiAccntblCd(String eiAccntblCd) {
        this.eiAccntblCd = eiAccntblCd;
    }

    public String getEiMaintReqrCd() {
        return eiMaintReqrCd;
    }

    public void setEiMaintReqrCd(String eiMaintReqrCd) {
        this.eiMaintReqrCd = eiMaintReqrCd;
    }

    public String getEntityInd() {
        return entityInd;
    }

    public void setEntityInd(String entityInd) {
        this.entityInd = entityInd;
    }

    public String getEqpmtInvMthdCd() {
        return eqpmtInvMthdCd;
    }

    public void setEqpmtInvMthdCd(String eqpmtInvMthdCd) {
        this.eqpmtInvMthdCd = eqpmtInvMthdCd;
    }

    public String getEqptInvReasonCd() {
        return eqptInvReasonCd;
    }

    public void setEqptInvReasonCd(String eqptInvReasonCd) {
        this.eqptInvReasonCd = eqptInvReasonCd;
    }

    public String getEquipAccountingStatusCd() {
        return equipAccountingStatusCd;
    }

    public void setEquipAccountingStatusCd(String equipAccountingStatusCd) {
        this.equipAccountingStatusCd = equipAccountingStatusCd;
    }

    public String getErtReadinessCd() {
        return ertReadinessCd;
    }

    public void setErtReadinessCd(String ertReadinessCd) {
        this.ertReadinessCd = ertReadinessCd;
    }

    public String getItemId() {
        return itemId;
    }

    public void setItemId(String itemId) {
        this.itemId = itemId;
    }

    public String getLocalContractId() {
        return localContractId;
    }

    public void setLocalContractId(String localContractId) {
        this.localContractId = localContractId;
    }

    public String getMeAccountingStatusDt() {
        return meAccountingStatusDt;
    }

    public void setMeAccountingStatusDt(String meAccountingStatusDt) {
        this.meAccountingStatusDt = meAccountingStatusDt;
    }

    public String getMeAcnId() {
        return meAcnId;
    }

    public void setMeAcnId(String meAcnId) {
        this.meAcnId = meAcnId;
    }

    public String getMeAcqDt() {
        return meAcqDt;
    }

    public void setMeAcqDt(String meAcqDt) {
        this.meAcqDt = meAcqDt;
    }

    public String getMeApplicationEntityTitleTx() {
        return meApplicationEntityTitleTx;
    }

    public void setMeApplicationEntityTitleTx(String meApplicationEntityTitleTx) {
        this.meApplicationEntityTitleTx = meApplicationEntityTitleTx;
    }

    public String getMeApprovalRefTx() {
        return meApprovalRefTx;
    }

    public void setMeApprovalRefTx(String meApprovalRefTx) {
        this.meApprovalRefTx = meApprovalRefTx;
    }

    public String getMeAtoExpiresDt() {
        return meAtoExpiresDt;
    }

    public void setMeAtoExpiresDt(String meAtoExpiresDt) {
        this.meAtoExpiresDt = meAtoExpiresDt;
    }

    public String getMeAtoIssuedDt() {
        return meAtoIssuedDt;
    }

    public void setMeAtoIssuedDt(String meAtoIssuedDt) {
        this.meAtoIssuedDt = meAtoIssuedDt;
    }

    public String getMeAtsScannedByTx() {
        return meAtsScannedByTx;
    }

    public void setMeAtsScannedByTx(String meAtsScannedByTx) {
        this.meAtsScannedByTx = meAtsScannedByTx;
    }

    public String getMeAtsStatusCd() {
        return meAtsStatusCd;
    }

    public void setMeAtsStatusCd(String meAtsStatusCd) {
        this.meAtsStatusCd = meAtsStatusCd;
    }

    public String getMeAtsStatusTx() {
        return meAtsStatusTx;
    }

    public void setMeAtsStatusTx(String meAtsStatusTx) {
        this.meAtsStatusTx = meAtsStatusTx;
    }

    public String getMeClinAlarmInd() {
        return meClinAlarmInd;
    }

    public void setMeClinAlarmInd(String meClinAlarmInd) {
        this.meClinAlarmInd = meClinAlarmInd;
    }

    public String getMeContrctrIndCd() {
        return meContrctrIndCd;
    }

    public void setMeContrctrIndCd(String meContrctrIndCd) {
        this.meContrctrIndCd = meContrctrIndCd;
    }

    public String getMeCreateDocNum() {
        return meCreateDocNum;
    }

    public void setMeCreateDocNum(String meCreateDocNum) {
        this.meCreateDocNum = meCreateDocNum;
    }

    public String getMeDownStatusCd() {
        return meDownStatusCd;
    }

    public void setMeDownStatusCd(String meDownStatusCd) {
        this.meDownStatusCd = meDownStatusCd;
    }

    public String getMeDuidTypeCd() {
        return meDuidTypeCd;
    }

    public void setMeDuidTypeCd(String meDuidTypeCd) {
        this.meDuidTypeCd = meDuidTypeCd;
    }

    public String getMeEcnId() {
        return meEcnId;
    }

    public void setMeEcnId(String meEcnId) {
        this.meEcnId = meEcnId;
    }

    public String getMeEqpmtReqstId() {
        return meEqpmtReqstId;
    }

    public void setMeEqpmtReqstId(String meEqpmtReqstId) {
        this.meEqpmtReqstId = meEqpmtReqstId;
    }

    public String getMeFirmwareVerId() {
        return meFirmwareVerId;
    }

    public void setMeFirmwareVerId(String meFirmwareVerId) {
        this.meFirmwareVerId = meFirmwareVerId;
    }

    public String getMeFyFundDate() {
        return meFyFundDate;
    }

    public void setMeFyFundDate(String meFyFundDate) {
        this.meFyFundDate = meFyFundDate;
    }

    public String getMeGfeLoanInd() {
        return meGfeLoanInd;
    }

    public void setMeGfeLoanInd(String meGfeLoanInd) {
        this.meGfeLoanInd = meGfeLoanInd;
    }

    public String getMeInstallationDt() {
        return meInstallationDt;
    }

    public void setMeInstallationDt(String meInstallationDt) {
        this.meInstallationDt = meInstallationDt;
    }

    public String getMeInvKeyInCd() {
        return meInvKeyInCd;
    }

    public void setMeInvKeyInCd(String meInvKeyInCd) {
        this.meInvKeyInCd = meInvKeyInCd;
    }

    public String getMeInvLocationTx() {
        return meInvLocationTx;
    }

    public void setMeInvLocationTx(String meInvLocationTx) {
        this.meInvLocationTx = meInvLocationTx;
    }

    public String getMeInvPerfrmNm() {
        return meInvPerfrmNm;
    }

    public void setMeInvPerfrmNm(String meInvPerfrmNm) {
        this.meInvPerfrmNm = meInvPerfrmNm;
    }

    public String getMeIpv4Address1Tx() {
        return meIpv4Address1Tx;
    }

    public void setMeIpv4Address1Tx(String meIpv4Address1Tx) {
        this.meIpv4Address1Tx = meIpv4Address1Tx;
    }

    public String getMeIpv4Address2Tx() {
        return meIpv4Address2Tx;
    }

    public void setMeIpv4Address2Tx(String meIpv4Address2Tx) {
        this.meIpv4Address2Tx = meIpv4Address2Tx;
    }

    public String getMeIpv6Address1Tx() {
        return meIpv6Address1Tx;
    }

    public void setMeIpv6Address1Tx(String meIpv6Address1Tx) {
        this.meIpv6Address1Tx = meIpv6Address1Tx;
    }

    public String getMeIpv6Address2Tx() {
        return meIpv6Address2Tx;
    }

    public void setMeIpv6Address2Tx(String meIpv6Address2Tx) {
        this.meIpv6Address2Tx = meIpv6Address2Tx;
    }

    public String getMeIuid() {
        return meIuid;
    }

    public void setMeIuid(String meIuid) {
        this.meIuid = meIuid;
    }

    public String getMeIuidAffixedDt() {
        return meIuidAffixedDt;
    }

    public void setMeIuidAffixedDt(String meIuidAffixedDt) {
        this.meIuidAffixedDt = meIuidAffixedDt;
    }

    public String getMeIuidAffixedInd() {
        return meIuidAffixedInd;
    }

    public void setMeIuidAffixedInd(String meIuidAffixedInd) {
        this.meIuidAffixedInd = meIuidAffixedInd;
    }

    public String getMeIuidAffixedUserId() {
        return meIuidAffixedUserId;
    }

    public void setMeIuidAffixedUserId(String meIuidAffixedUserId) {
        this.meIuidAffixedUserId = meIuidAffixedUserId;
    }

    public String getMeJmarTransmInd() {
        return meJmarTransmInd;
    }

    public void setMeJmarTransmInd(String meJmarTransmInd) {
        this.meJmarTransmInd = meJmarTransmInd;
    }

    public String getMeLastInvntryDt() {
        return meLastInvntryDt;
    }

    public void setMeLastInvntryDt(String meLastInvntryDt) {
        this.meLastInvntryDt = meLastInvntryDt;
    }

    public String getMeLastSvcDt() {
        return meLastSvcDt;
    }

    public void setMeLastSvcDt(String meLastSvcDt) {
        this.meLastSvcDt = meLastSvcDt;
    }

    public String getMeLifeSafetyInd() {
        return meLifeSafetyInd;
    }

    public void setMeLifeSafetyInd(String meLifeSafetyInd) {
        this.meLifeSafetyInd = meLifeSafetyInd;
    }

    public String getMeMacAddressTx() {
        return meMacAddressTx;
    }

    public void setMeMacAddressTx(String meMacAddressTx) {
        this.meMacAddressTx = meMacAddressTx;
    }

    public String getMeMachineNm() {
        return meMachineNm;
    }

    public void setMeMachineNm(String meMachineNm) {
        this.meMachineNm = meMachineNm;
    }

    public String getMeManufModelId() {
        return meManufModelId;
    }

    public void setMeManufModelId(String meManufModelId) {
        this.meManufModelId = meManufModelId;
    }

    public String getMeManufacturedDt() {
        return meManufacturedDt;
    }

    public void setMeManufacturedDt(String meManufacturedDt) {
        this.meManufacturedDt = meManufacturedDt;
    }

    public String getMeMfgSerialId() {
        return meMfgSerialId;
    }

    public void setMeMfgSerialId(String meMfgSerialId) {
        this.meMfgSerialId = meMfgSerialId;
    }

    public String getMeNetworkConnectionInd() {
        return meNetworkConnectionInd;
    }

    public void setMeNetworkConnectionInd(String meNetworkConnectionInd) {
        this.meNetworkConnectionInd = meNetworkConnectionInd;
    }

    public String getMeOnloanCd() {
        return meOnloanCd;
    }

    public void setMeOnloanCd(String meOnloanCd) {
        this.meOnloanCd = meOnloanCd;
    }

    public String getMePatientDataInd() {
        return mePatientDataInd;
    }

    public void setMePatientDataInd(String mePatientDataInd) {
        this.mePatientDataInd = mePatientDataInd;
    }

    public String getMeReturnDt() {
        return meReturnDt;
    }

    public void setMeReturnDt(String meReturnDt) {
        this.meReturnDt = meReturnDt;
    }

    public String getMeRfLocTx() {
        return meRfLocTx;
    }

    public void setMeRfLocTx(String meRfLocTx) {
        this.meRfLocTx = meRfLocTx;
    }

    public String getMeRfTime() {
        return meRfTime;
    }

    public void setMeRfTime(String meRfTime) {
        this.meRfTime = meRfTime;
    }

    public String getMeRfid() {
        return meRfid;
    }

    public void setMeRfid(String meRfid) {
        this.meRfid = meRfid;
    }

    public String getMeRfidAffixedDt() {
        return meRfidAffixedDt;
    }

    public void setMeRfidAffixedDt(String meRfidAffixedDt) {
        this.meRfidAffixedDt = meRfidAffixedDt;
    }

    public String getMeSuspdSchedInd() {
        return meSuspdSchedInd;
    }

    public void setMeSuspdSchedInd(String meSuspdSchedInd) {
        this.meSuspdSchedInd = meSuspdSchedInd;
    }

    public String getMeSuspdSchedWoReasonTx() {
        return meSuspdSchedWoReasonTx;
    }

    public void setMeSuspdSchedWoReasonTx(String meSuspdSchedWoReasonTx) {
        this.meSuspdSchedWoReasonTx = meSuspdSchedWoReasonTx;
    }

    public String getMeTempLocTx() {
        return meTempLocTx;
    }

    public void setMeTempLocTx(String meTempLocTx) {
        this.meTempLocTx = meTempLocTx;
    }

    public String getMeVendorSiteId() {
        return meVendorSiteId;
    }

    public void setMeVendorSiteId(String meVendorSiteId) {
        this.meVendorSiteId = meVendorSiteId;
    }

    public String getMeWarntyBegDt() {
        return meWarntyBegDt;
    }

    public void setMeWarntyBegDt(String meWarntyBegDt) {
        this.meWarntyBegDt = meWarntyBegDt;
    }

    public String getMeWarntyLabrEdt() {
        return meWarntyLabrEdt;
    }

    public void setMeWarntyLabrEdt(String meWarntyLabrEdt) {
        this.meWarntyLabrEdt = meWarntyLabrEdt;
    }

    public String getMeWarntyPartEdt() {
        return meWarntyPartEdt;
    }

    public void setMeWarntyPartEdt(String meWarntyPartEdt) {
        this.meWarntyPartEdt = meWarntyPartEdt;
    }

    public String getMeWirelessFrequencyTx() {
        return meWirelessFrequencyTx;
    }

    public void setMeWirelessFrequencyTx(String meWirelessFrequencyTx) {
        this.meWirelessFrequencyTx = meWirelessFrequencyTx;
    }

    public String getMeWrmPeactmCd() {
        return meWrmPeactmCd;
    }

    public void setMeWrmPeactmCd(String meWrmPeactmCd) {
        this.meWrmPeactmCd = meWrmPeactmCd;
    }

    public String getMtfOrgID() {
        return mtfOrgID;
    }

    public void setMtfOrgID(String mtfOrgID) {
        this.mtfOrgID = mtfOrgID;
    }

    public String getMtfOrgNM() {
        return mtfOrgNM;
    }

    public void setMtfOrgNM(String mtfOrgNM) {
        this.mtfOrgNM = mtfOrgNM;
    }

    public String getOrgID() {
        return orgID;
    }

    public void setOrgID(String orgID) {
        this.orgID = orgID;
    }

    public String getRecvdFromDocnum() {
        return recvdFromDocnum;
    }

    public void setRecvdFromDocnum(String recvdFromDocnum) {
        this.recvdFromDocnum = recvdFromDocnum;
    }

    public String getSiteDoDDAC() {
        return siteDoDDAC;
    }

    public void setSiteDoDDAC(String siteDoDDAC) {
        this.siteDoDDAC = siteDoDDAC;
    }

    public String getSourceDodaac() {
        return sourceDodaac;
    }

    public void setSourceDodaac(String sourceDodaac) {
        this.sourceDodaac = sourceDodaac;
    }

    public String getSourceMeId() {
        return sourceMeId;
    }

    public void setSourceMeId(String sourceMeId) {
        this.sourceMeId = sourceMeId;
    }

    public String getSubCustodianName() {
        return subCustodianName;
    }

    public void setSubCustodianName(String subCustodianName) {
        this.subCustodianName = subCustodianName;
    }

    public String getSubCustodianPH() {
        return subCustodianPH;
    }

    public void setSubCustodianPH(String subCustodianPH) {
        this.subCustodianPH = subCustodianPH;
    }

    public String getSupplyCond() {
        return supplyCond;
    }

    public void setSupplyCond(String supplyCond) {
        this.supplyCond = supplyCond;
    }

    public String getSystemTypeCd() {
        return systemTypeCd;
    }

    public void setSystemTypeCd(String systemTypeCd) {
        this.systemTypeCd = systemTypeCd;
    }

    public String getTransCd() {
        return transCd;
    }

    public void setTransCd(String transCd) {
        this.transCd = transCd;
    }

    public String getTransReasTypeCd() {
        return transReasTypeCd;
    }

    public void setTransReasTypeCd(String transReasTypeCd) {
        this.transReasTypeCd = transReasTypeCd;
    }

    public String getUidTypeCd() {
        return uidTypeCd;
    }

    public void setUidTypeCd(String uidTypeCd) {
        this.uidTypeCd = uidTypeCd;
    }
}