package dmles.equipment.server.datamodels.request;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.mongodb.morphia.annotations.Embedded;

public class FacilityInformationDO implements Serializable {
    private static final long serialVersionUID = 1L;    

    private Float facilityModificationCost;
    private String facilityModifications;
    public Boolean includedCost;
    
    @Embedded
    private List<UtilityDO> utilities = new ArrayList<>();

    public String getFacilityModifications() {
        return facilityModifications;
    }

    public void setFacilityModifications(String facilityModifications) {
        this.facilityModifications = facilityModifications;
    }

    public List<UtilityDO> getUtilities() {
        return utilities;
    }

    public void setUtilities(List<UtilityDO> utilities) {
        this.utilities = utilities;
    }
    
    public Float getFacilityModificationCost() {
        return facilityModificationCost;
    }

    public void setFacilityModificationCost(Float facilityModificationCost) {
        this.facilityModificationCost = facilityModificationCost;
    }

    public Boolean getIncludedCost() {
        return includedCost;
    }

    public void setIncludedCost(Boolean includedCost) {
        this.includedCost = includedCost;
    }
}