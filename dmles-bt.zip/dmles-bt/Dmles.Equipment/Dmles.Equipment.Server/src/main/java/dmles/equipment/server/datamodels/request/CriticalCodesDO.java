package dmles.equipment.server.datamodels.request;

// TODO: Should be singular
public class CriticalCodesDO {

    public String code;
    public String description;
 
    public String getCode() {
        return code;
    }

    public String getDescription() {
        return description;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public void setDescription(String description ) {
        this.description = description;
    }

}
