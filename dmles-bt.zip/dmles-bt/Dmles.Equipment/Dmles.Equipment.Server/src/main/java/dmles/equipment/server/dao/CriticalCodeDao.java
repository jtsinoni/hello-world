package dmles.equipment.server.dao;

import javax.enterprise.context.Dependent;
import mil.jmlfdc.common.dao.BaseDao;
import dmles.equipment.server.datamodels.request.CriticalCodeDO;
import dmles.equipment.server.datamodels.request.CriticalCodesDO;
import java.util.ArrayList;
import java.util.List;

@Dependent
public class CriticalCodeDao extends BaseDao<CriticalCodeDO, String>{
    
    public CriticalCodeDao() {
        super(CriticalCodeDO.class);
    }
    
    public List<CriticalCodeDO> findByServiceAgencyCode(String serviceAgencyCode) {
        return this.query(String.format("serviceAgency.code=%s", serviceAgencyCode));
    }

    public List<CriticalCodesDO> findCodesByServiceAgencyCode(String serviceAgencyCode) {
        List<CriticalCodeDO> codes = new ArrayList<>();
        CriticalCodeDO code = new CriticalCodeDO();
        List<CriticalCodesDO> noCodes = new ArrayList<>();
        codes = this.query(String.format("serviceAgency.code=%s", serviceAgencyCode));
        if ( codes.isEmpty()) {
            return noCodes;
        }
        else {
            code = codes.get(0);
            return code.getCriticalCodes();
        }
    }
}
