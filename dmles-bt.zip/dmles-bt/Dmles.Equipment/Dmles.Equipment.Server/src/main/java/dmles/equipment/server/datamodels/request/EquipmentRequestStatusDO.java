package dmles.equipment.server.datamodels.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import dmles.equipment.core.datamodels.request.workflow.process.WorkflowLevelStatus;
import java.io.Serializable;
import java.util.Date;
import mil.jmlfdc.common.constants.DateAndTime;

public class EquipmentRequestStatusDO implements Serializable {

    private static final long serialVersionUID = 1L;
    private String notes;
    private String state; 
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateAndTime.DATE_TIME_PATTERN)
    private Date updateDate;

    public EquipmentRequestStatusDO() {
        updateDate = new Date();
    }

    public EquipmentRequestStatusDO(WorkflowLevelStatus state) {
        this(state, null);
    }

    public EquipmentRequestStatusDO(WorkflowLevelStatus state, String notes) {
        this();
        this.state = state.toString();
        this.notes = notes;
    }

    public String getNotes() {
        return notes;
    }

    public String getState() {
        return state;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public void setState(WorkflowLevelStatus state) {
        this.state = state.toString();
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

}
