package dmles.equipment.server.datamodels.request.validation;

import dmles.equipment.core.datamodels.catalog.SuggestedSourceItem;
import dmles.equipment.server.datamodels.request.RequestInformationDO;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.util.List;

public class RequestInformationSuggestedSourceValidator implements ConstraintValidator<RequestInformationSuggestedSource, RequestInformationDO> {

   public void initialize(RequestInformationSuggestedSource constraint) {
   }

   public boolean isValid(RequestInformationDO obj, ConstraintValidatorContext context) {
      boolean isValid = false;

      List<SuggestedSourceItem> suggestedSources = obj.getSuggestedSources();

      if (suggestedSources != null && !suggestedSources.isEmpty()) {
         for(SuggestedSourceItem ssi : suggestedSources) {
            if (ssi.getPrimarySource() != null && Boolean.TRUE.compareTo(ssi.getPrimarySource()) == 0 ) {
               isValid = true;
               break;
            }
         }
      }

      return isValid;
   }
}
