package dmles.equipment.server.datamodels.request.workflow.process;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import org.mongodb.morphia.annotations.Embedded;

public class WorkflowLevelProcessingDO {

    private Integer levelId;
    private String levelName;
    private String status;
    private Boolean autoApproveAfterReviews;

    @Embedded
    private List<ReviewDO> reviews = new ArrayList<>();

    private String updatedBy;
    private Date updatedDate;

    public WorkflowLevelProcessingDO() {
    }

    public Boolean getAutoApproveAfterReviews() {
        return autoApproveAfterReviews;
    }

    public void setAutoApproveAfterReviewss(Boolean autoApproveAfterReviews) {
        this.autoApproveAfterReviews = autoApproveAfterReviews;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public Integer getLevelId() {
        return levelId;
    }

    public void setLevelId(Integer levelId) {
        this.levelId = levelId;
    }

    public String getLevelName() {
        return levelName;
    }

    public void setLevelName(String levelName) {
        this.levelName = levelName;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public List<ReviewDO> getReviews() {
        return reviews;
    }

    public void setReviews(List<ReviewDO> reviews) {
        this.reviews = reviews;
    }

    public void updateStatus(String status, String updatedBy) {
        setStatus(status);
        setUpdatedBy(updatedBy);
        setUpdatedDate(new Date());
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof WorkflowLevelProcessingDO)) return false;
        WorkflowLevelProcessingDO that = (WorkflowLevelProcessingDO) o;
        return Objects.equals(levelId, that.levelId) &&
                Objects.equals(levelName, that.levelName) &&
                Objects.equals(status, that.status) &&
                Objects.equals(reviews, that.reviews) &&
                Objects.equals(updatedBy, that.updatedBy) &&
                Objects.equals(updatedDate, that.updatedDate);
    }

    @Override
    public int hashCode() {
        return Objects.hash(levelId, levelName, status, reviews, autoApproveAfterReviews, updatedBy, updatedDate);
    }

}
