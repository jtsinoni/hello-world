package dmles.equipment.server.datamodels;

import java.io.Serializable;

public class CustomerDO implements Serializable {
    private static final long serialVersionUID = 1L;
    private String id;
    private String custodianFirstName;
    private String custodianLastName;
    private String custodianPhoneNum;
    private String customerID;
    private String customerName;
    private String customerSerial;    

    public CustomerDO() {
    }

    public CustomerDO(String custodianFirstName, String custodianLastName, String custodianPhoneNum, String customerID, String customerName, String customerSerial) {
        this.custodianFirstName = custodianFirstName;
        this.custodianLastName = custodianLastName;
        this.custodianPhoneNum = custodianPhoneNum;
        this.customerID = customerID;
        this.customerName = customerName;
        this.customerSerial = customerSerial;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
    
    public String getCustodianFirstName() {
        return custodianFirstName;
    }

    public void setCustodianFirstName(String custodianFirstName) {
        this.custodianFirstName = custodianFirstName;
    }

    public String getCustodianLastName() {
        return custodianLastName;
    }

    public void setCustodianLastName(String custodianLastName) {
        this.custodianLastName = custodianLastName;
    }

    public String getCustodianPhoneNum() {
        return custodianPhoneNum;
    }

    public void setCustodianPhoneNum(String custodianPhoneNum) {
        this.custodianPhoneNum = custodianPhoneNum;
    }

    public String getCustomerID() {
        return customerID;
    }

    public void setCustomerID(String customerID) {
        this.customerID = customerID;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerSerial() {
        return customerSerial;
    }

    public void setCustomerSerial(String customerSerial) {
        this.customerSerial = customerSerial;
    }
        
}
