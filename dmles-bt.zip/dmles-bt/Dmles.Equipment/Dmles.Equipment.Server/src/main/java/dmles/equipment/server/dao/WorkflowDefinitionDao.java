package dmles.equipment.server.dao;

import dmles.equipment.server.datamodels.request.workflow.definition.WorkflowDefinitionDO;
import mil.jmlfdc.common.dao.BaseDao;
import mil.jmlfdc.common.utils.ListUtil;
import org.mongodb.morphia.query.Query;

import java.util.Date;
import java.util.List;
import javax.enterprise.context.Dependent;

@Dependent
public class WorkflowDefinitionDao extends BaseDao<WorkflowDefinitionDO, String> {

    public WorkflowDefinitionDao() {
        super(WorkflowDefinitionDO.class);
    }

    public WorkflowDefinitionDO findByServiceName(String serviceName) {
        
        Query query = this.getQuery(WorkflowDefinitionDO.class);
        query.filter("service", serviceName);
        query.filter("effectiveDate <=", new Date());
        query.order("-version");
        
        List<WorkflowDefinitionDO> list = query.asList();
        WorkflowDefinitionDO wfdo;

        if (ListUtil.isEmpty(list)) {
            wfdo = null;
        } else {
            wfdo = list.get(0);
        }
        return wfdo;
    }
    
    public WorkflowDefinitionDO addWorkflowDefinition(WorkflowDefinitionDO wfd){
        upsert(wfd);
        return wfd;        
    }
}
