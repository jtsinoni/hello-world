package dmles.equipment.server.datamodels.request;

import java.io.Serializable;

public class ExtraItemDO implements Serializable {
    
    private static final long serialVersionUID = 1L; 
    private String itemDescription;
    private String catalogNumber;
    private String unitOfPurchase;
    private Float unitCost;
    private Integer quantity;
    private String type;

    public ExtraItemDO() {
    }

    public String getItemDescription() {
        return itemDescription;
    }

    public void setItemDescription(String itemDescription) {
        this.itemDescription = itemDescription;
    }

    public String getCatalogNumber() {
        return catalogNumber;
    }

    public void setCatalogNumber(String catalogNumber) {
        this.catalogNumber = catalogNumber;
    }

    public String getUnitOfPurchase() {
        return unitOfPurchase;
    }

    public void setUnitOfPurchase(String unitOfPurchase) {
        this.unitOfPurchase = unitOfPurchase;
    }

    public Float getUnitCost() {
        return unitCost;
    }

    public void setUnitCost(Float unitCost) {
        this.unitCost = unitCost;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
    
}
