package dmles.equipment.server.datamodels.record;

import org.mongodb.morphia.annotations.Embedded;

import java.io.Serializable;

@Embedded
public class LocationInventoryDO implements Serializable {
    private static final long serialVersionUID = 1L;
    private String building;
    private String roomFloorNum;
    private String room;
    private String pltPermntLocTx;
    private String onlnEquipLoanDt;
    private String onlnEquipDayQty;
    private String eqpmtInvMthdTx;
    private String eqptInvReasonTx;
    private String inacctSerial;
    private String locID;
    private String subLocID;

    public String getBuilding() {
        return building;
    }

    public void setBuilding(String building) {
        this.building = building;
    }

    public String getRoomFloorNum() {
        return roomFloorNum;
    }

    public void setRoomFloorNum(String roomFloorNum) {
        this.roomFloorNum = roomFloorNum;
    }

    public String getRoom() {
        return room;
    }

    public void setRoom(String room) {
        this.room = room;
    }

    public String getPltPermntLocTx() {
        return pltPermntLocTx;
    }

    public void setPltPermntLocTx(String pltPermntLocTx) {
        this.pltPermntLocTx = pltPermntLocTx;
    }

    public String getOnlnEquipLoanDt() {
        return onlnEquipLoanDt;
    }

    public void setOnlnEquipLoanDt(String onlnEquipLoanDt) {
        this.onlnEquipLoanDt = onlnEquipLoanDt;
    }

    public String getOnlnEquipDayQty() {
        return onlnEquipDayQty;
    }

    public void setOnlnEquipDayQty(String onlnEquipDayQty) {
        this.onlnEquipDayQty = onlnEquipDayQty;
    }

    public String getEqpmtInvMthdTx() {
        return eqpmtInvMthdTx;
    }

    public void setEqpmtInvMthdTx(String eqpmtInvMthdTx) {
        this.eqpmtInvMthdTx = eqpmtInvMthdTx;
    }

    public String getEqptInvReasonTx() {
        return eqptInvReasonTx;
    }

    public void setEqptInvReasonTx(String eqptInvReasonTx) {
        this.eqptInvReasonTx = eqptInvReasonTx;
    }

    public String getInacctSerial() {
        return inacctSerial;
    }

    public void setInacctSerial(String inacctSerial) {
        this.inacctSerial = inacctSerial;
    }

    public String getLocID() {
        return locID;
    }

    public void setLocID(String locID) {
        this.locID = locID;
    }

    public String getSubLocID() {
        return subLocID;
    }

    public void setSubLocID(String subLocID) {
        this.subLocID = subLocID;
    }
}