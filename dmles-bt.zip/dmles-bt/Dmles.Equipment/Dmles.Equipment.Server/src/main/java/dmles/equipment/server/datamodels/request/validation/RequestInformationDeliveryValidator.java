package dmles.equipment.server.datamodels.request.validation;

import dmles.equipment.server.datamodels.request.EquipmentRequestTypeDO;
import dmles.equipment.server.datamodels.request.ReplacementItemDO;
import dmles.equipment.server.datamodels.request.RequestInformationDO;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class RequestInformationDeliveryValidator implements ConstraintValidator<RequestInformationDelivery, RequestInformationDO> {

   public void initialize(RequestInformationDelivery constraint) {
   }

   public boolean isValid(RequestInformationDO obj, ConstraintValidatorContext context) {
      boolean isValid;


      if (obj.getRequestedDeliveryDate() != null && obj.getRequestedDeliveryDateReason() == null) {
         isValid = false;
      } else {
         isValid = true;
      }

      return isValid;
   }
}
