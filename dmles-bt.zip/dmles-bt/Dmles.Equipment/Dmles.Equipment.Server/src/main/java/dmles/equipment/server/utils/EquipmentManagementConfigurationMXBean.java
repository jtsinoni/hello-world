package dmles.equipment.server.utils;

public interface EquipmentManagementConfigurationMXBean {

    public void setTest(String test);

    public String getTest();
}
