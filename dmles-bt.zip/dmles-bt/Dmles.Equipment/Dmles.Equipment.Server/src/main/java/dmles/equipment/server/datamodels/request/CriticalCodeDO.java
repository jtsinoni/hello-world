package dmles.equipment.server.datamodels.request;

import java.util.ArrayList;
import java.util.List;
import org.mongodb.morphia.annotations.Entity;
import mil.jmlfdc.common.datamodel.MorphiaEntity;
import org.mongodb.morphia.annotations.Embedded;

@Entity("CriticalCodes")  // TODO: Change to RequestCriticality
public class CriticalCodeDO extends MorphiaEntity {

    private ServiceAgencyDO serviceAgency;
    @Embedded
    private List<CriticalCodesDO> criticalCodes = new ArrayList<>();

    public ServiceAgencyDO getServiceAgency() {
        return serviceAgency;
    }
    
    public List<CriticalCodesDO> getCriticalCodes() {
        return criticalCodes;
    }

    public void setServiceAgency(ServiceAgencyDO serviceAgency) {
        this.serviceAgency = serviceAgency;
    }

    public void setCriticalCodes(List<CriticalCodesDO> criticalCodes) {
        this.criticalCodes = criticalCodes;
    }

}
