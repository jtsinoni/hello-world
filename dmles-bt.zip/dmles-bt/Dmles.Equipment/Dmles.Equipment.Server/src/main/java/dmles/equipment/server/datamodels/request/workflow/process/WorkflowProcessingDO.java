package dmles.equipment.server.datamodels.request.workflow.process;

import com.fasterxml.jackson.annotation.JsonFormat;
import dmles.equipment.server.datamodels.request.workflow.definition.WorkflowDefinitionDO;
import mil.jmlfdc.common.datamodel.MorphiaEntity;
import org.mongodb.morphia.annotations.Embedded;
import org.mongodb.morphia.annotations.Entity;
import org.mongodb.morphia.annotations.Reference;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Entity("EquipmentRequestWorkflowProcess")
public class WorkflowProcessingDO extends MorphiaEntity implements Serializable {

    private static final long serialVersionUID = 1L;
    private String requestId;
    private Integer currentLevelId;
    private String currentStatus;
    private String currentOwnerRole;
    private Boolean isCompleted;

    @Reference
    private WorkflowDefinitionDO wfDefinition;
    
    @Embedded
    private Map<Integer, WorkflowLevelProcessingDO> levels = new HashMap<>();
    
    @Embedded
    private List<WorkflowCommentDO> comments = new ArrayList<>();
    
    @Embedded
    private List<WorkflowHistoryDO> history = new ArrayList<>();      

    private String updatedBy;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'hh:mm:ss.SSSX")
    private Date updatedDate;

    public WorkflowProcessingDO() {
    }

    public WorkflowDefinitionDO getWfDefinition() {
        return wfDefinition;
    }

    public void setWfDefinition(WorkflowDefinitionDO wfDefinition) {
        this.wfDefinition = wfDefinition;
    }
    
    public List<WorkflowHistoryDO> getHistory() {
        if(null == history){
            history = new ArrayList<>();
        }
        return history;
    }

    public void setHistory(List<WorkflowHistoryDO> history) {
        this.history = history;
    }
    
    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getCurrentOwnerRole() {
        return currentOwnerRole;
    }

    public void setCurrentOwnerRole(String currentOwnerRole) {
        this.currentOwnerRole = currentOwnerRole;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public Boolean getIsCompleted() {
        return isCompleted;
    }

    public void setIsCompleted(Boolean isCompleted) {
        this.isCompleted = isCompleted;
    }

    public Integer getCurrentLevelId() {
        return currentLevelId;
    }

    public Boolean isCurrentLevel(int levelId) {
        return (levelId == currentLevelId);
    }
    public WorkflowLevelProcessingDO getCurrentLevel() {
        return getLevel(currentLevelId);
    }
    
    public WorkflowLevelProcessingDO getPreviousLevel() {
        return getLevel(currentLevelId - 1);
    }
    
    public WorkflowLevelProcessingDO getNextLevel() {
        return getLevel(currentLevelId + 1);
    }
    
    public WorkflowLevelProcessingDO getLevel(Integer level) {
        WorkflowLevelProcessingDO value = null;
        if (levels.containsKey(level)) {
            value = levels.get(level);
        }
        return value;
    }

    public void setCurrentLevelId(Integer currentLevelId) {
        this.currentLevelId = currentLevelId;
    }

    public String getCurrentStatus() {
        return currentStatus;
    }

    public void setCurrentStatus(String currentStatus) {
        this.currentStatus = currentStatus;
    }

    public Map<Integer, WorkflowLevelProcessingDO> getLevels() {
        return levels;
    }

    public void setLevels(Map<Integer, WorkflowLevelProcessingDO> levels) {
        this.levels = levels;
    }

    public List<WorkflowCommentDO> getComments() {
        return comments;
    }

    public void setComments(List<WorkflowCommentDO> comments) {
        this.comments = comments;
    }

    public boolean isEndOfWorkflow() {
        return currentLevelId >= levels.size() - 1;
    }

}
