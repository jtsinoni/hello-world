package dmles.equipment.server.dao;

import dmles.equipment.server.datamodels.request.EquipmentCriticalityDO;
import mil.jmlfdc.common.dao.BaseDao;

import javax.enterprise.context.Dependent;

@Dependent
public class EquipmentCriticalityDao extends BaseDao<EquipmentCriticalityDO, String> {
    
    public EquipmentCriticalityDao(){
        super(EquipmentCriticalityDO.class);
    }
    
}