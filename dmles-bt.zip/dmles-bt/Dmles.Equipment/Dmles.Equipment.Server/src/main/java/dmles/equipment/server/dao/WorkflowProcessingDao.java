package dmles.equipment.server.dao;

import dmles.equipment.server.datamodels.request.workflow.process.WorkflowProcessingDO;
import mil.jmlfdc.common.dao.BaseDao;

import java.util.List;
import javax.enterprise.context.Dependent;

@Dependent
public class WorkflowProcessingDao extends BaseDao<WorkflowProcessingDO, String> {

    public WorkflowProcessingDao() {
        super(WorkflowProcessingDO.class);
    }

    public WorkflowProcessingDO findWorkflowProcessingByRequestId(String requestId) {
        List<WorkflowProcessingDO> list = this.query(String.format("requestId=%s", requestId));
        WorkflowProcessingDO wfp = new WorkflowProcessingDO();
        if (list.size() > 0) {
            wfp = list.get(0);
        }
        return wfp;
    }    

    
}
