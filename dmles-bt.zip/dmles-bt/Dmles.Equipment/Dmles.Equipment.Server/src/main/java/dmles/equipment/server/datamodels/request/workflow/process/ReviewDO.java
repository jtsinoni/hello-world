package dmles.equipment.server.datamodels.request.workflow.process;

import dmles.equipment.server.datamodels.CommentDO;
import org.mongodb.morphia.annotations.Embedded;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class ReviewDO {
    private static final Integer CURRENT_VERSION = 1;
    
    private String reviewDisplayName;
    private String elementName;
    private String reviewStatus;
    private String reviewResult;
    private String selectedUserId;
    private String roleId;
    
    @Embedded
    private List<ReviewUserDO> reviewUsers = new ArrayList<>();

    @Embedded
    private List<CommentDO> comments = new ArrayList<>();

    public String getSelectedUserId() {
        return selectedUserId;
    }

    public void setSelectedUserId(String selectedUserId) {
        this.selectedUserId = selectedUserId;
    }
    
    public String getReviewDisplayName() {
        return reviewDisplayName;
    }

    public void setReviewDisplayName(String reviewDisplayName) {
        this.reviewDisplayName = reviewDisplayName;
    }

    public String getElementName() {
        return elementName;
    }

    public void setElementName(String elementName) {
        this.elementName = elementName;
    }

    public List<ReviewUserDO> getReviewUsers() {
        return reviewUsers;
    }

    public void setReviewUsers(List<ReviewUserDO> reviewUsers) {
        this.reviewUsers = reviewUsers;
    }

    public List<CommentDO> getComments() {
        return comments;
    }

    public void setComments(List<CommentDO> comments) {
        this.comments = comments;
    }

    public String getReviewStatus() {
        return reviewStatus;
    }

    public void setReviewStatus(String reviewStatus) {
        this.reviewStatus = reviewStatus;
    }

    public String getReviewResult() {
        return reviewResult;
    }

    public void setReviewResult(String reviewResult) {
        this.reviewResult = reviewResult;
    }

    public List<ReviewUserDO> getReviewUsersDO() {
        return reviewUsers;
    }

    public void setReviewUsersDO(List<ReviewUserDO> reviewUsers) {
        this.reviewUsers = reviewUsers;
    }
    
    public String getRoleId() {
        return roleId;
    }
    
    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    public boolean equalsStatus(Object o) {
        if (this == o) return true;
        if (!(o instanceof ReviewDO)) return false;
        ReviewDO reviewDO = (ReviewDO) o;
        return Objects.equals(reviewDisplayName, reviewDO.reviewDisplayName) &&
                Objects.equals(reviewStatus, reviewDO.reviewStatus) &&
                Objects.equals(selectedUserId, reviewDO.selectedUserId) &&
                Objects.equals(roleId, reviewDO.roleId);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ReviewDO)) return false;
        ReviewDO reviewDO = (ReviewDO) o;
        return Objects.equals(reviewDisplayName, reviewDO.reviewDisplayName) &&
                Objects.equals(elementName, reviewDO.elementName) &&
                Objects.equals(reviewStatus, reviewDO.reviewStatus) &&
                Objects.equals(reviewResult, reviewDO.reviewResult) &&
                Objects.equals(selectedUserId, reviewDO.selectedUserId) &&
                Objects.equals(roleId, reviewDO.roleId) &&
                Objects.equals(reviewUsers, reviewDO.reviewUsers) &&
                Objects.equals(comments, reviewDO.comments);
    }

    @Override
    public int hashCode() {
        return Objects.hash(reviewDisplayName, elementName, reviewStatus, reviewResult, selectedUserId, roleId, reviewUsers, comments);
    }
}
