package dmles.equipment.server.datamodels.request;

import java.util.ArrayList;
import java.util.List;
import mil.jmlfdc.common.datamodel.MorphiaEntity;
import org.mongodb.morphia.annotations.Entity;

@Entity("MaintenanceType")
public class EquipmentMaintenanceTypesDO extends MorphiaEntity {
    
    private static final long serialVersionUID = 1L;
    private ServiceAgencyDO serviceAgency;
    private List<String> types = new ArrayList<>();

    public ServiceAgencyDO getServiceAgency() {
        return serviceAgency;
    }
    
    public List<String> getMaintenanceCodes() {
        return types;
    }

    public void setServiceAgency(ServiceAgencyDO serviceAgency) {
        this.serviceAgency = serviceAgency;
    }

    public void setCriticalCodes(List<String> maintenanceTypes) {
        this.types = maintenanceTypes;
    }
}
