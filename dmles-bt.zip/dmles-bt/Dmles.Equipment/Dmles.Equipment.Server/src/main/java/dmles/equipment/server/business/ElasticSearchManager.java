package dmles.equipment.server.business;

import dmles.search.client.SearchService;
import dmles.search.core.ISearchService;
import dmles.search.core.request.DmlesSearchRequest;
import dmles.search.core.request.DmlesSearchSource;
import dmles.search.dao.ElasticSearchDao;
import mil.jmlfdc.common.business.BusinessManager;
import mil.jmlfdc.common.datamodel.UserType;
import org.slf4j.Logger;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.ws.rs.core.Response;
import java.util.HashMap;
import java.util.Map;

@Stateless
public class ElasticSearchManager extends BusinessManager {

    @Inject
    private Logger logger;
    @Inject
    private ElasticSearchDao esDao;
    @Inject
    private ElasticSearchAggregations esAggregations;
    @Inject
    @SearchService
    private ISearchService searchService;
    protected static final String CATALOG_SEARCH_TEMP = "siteEquipItemList_qs";
    protected static final String EQUIP_REC_SEARCH_TEMP = "siteEquipRecordSearch_qs";

    /**
     * Builds and executes a catalog search query against the elasticsearch
     * database based on the given information.
     *
     * @param searchValue the query information given by the user
     * @param dodaac an optional parameter to execute the search only against a
     * certain dodaac
     *
     * @return a string representing the elasticsearch json
     */
    public String getCatalogSearchResults(String searchValue, String dodaac) {
        String searchVal = (searchValue == null || searchValue.isEmpty()) ? "*" : searchValue;

        Map<String, Object> templateParams = new HashMap<>();
        templateParams.put("searchValue", searchVal);
        if (dodaac != null && !dodaac.isEmpty()) {
            templateParams.put("dodaac", dodaac);
        }
        String responseString = esDao.getSearchResults(templateParams, CATALOG_SEARCH_TEMP);

        return responseString;
    }

    /**
     * Builds and executes an equipment records search query against the
     * elasticsearch database based on the given information.
     *
     * @param searchValue the query string given by the user, may include
     * filters
     * @param aggregations the aggregations provided by the user, may include
     * filters
     *
     * @return a string representing the elasticsearch json
     */
    public String getEquipmentRecordSearchResults(String searchValue, String aggregations) {

        String searchVal = (searchValue == null || searchValue.isEmpty()) ? "*" : searchValue;
        String aggs = (aggregations == null || aggregations.isEmpty()) ? "{}" : aggregations;
        logger.info("generic aggs - from PT = " + aggs);

        // Global/Service/ServiceRegion users can see all results,
        // but Site-level users should only see data based on their DODAAC

        UserType userType = UserType.valueOf(currentUserBt.getUserType().toString());
        if (userType == UserType.SITE) {
            // limit the results to the DODAAC set for this site user
            if (searchVal.indexOf("orgId:") > 0) {
                // replace any orgId search value that may be there
                int firstQuote = searchVal.indexOf("orgId:") + 7;
                int secondQuote = searchVal.indexOf("\"", firstQuote);
                searchVal = searchVal.substring(0,firstQuote) + currentUserBt.getDodaac() + searchVal.substring(secondQuote);
            } else {
                // there is no search clause for orgId, append one
                searchVal += " (orgId:\"" + currentUserBt.getDodaac() + "\")";
            }

        }

        Map<String, Object> templateParams = new HashMap<>();
        templateParams.put("searchValue", searchVal);
        templateParams.put("aggregations", esAggregations.processAggregations(aggs));
        String responseString = esDao.getSearchResults(templateParams, EQUIP_REC_SEARCH_TEMP);

        return responseString;
    }
    public String getEquipmentSearchResults(String queryString, String aggregations) {

        /* Create search request with PT parameters */
        DmlesSearchRequest searchRequest = new DmlesSearchRequest(queryString, aggregations);

        /* Populate search request properties specific to this manager. */
        searchRequest.source = new DmlesSearchSource("siteequipmentrecordsearch", "Oracle-SiteEquipmentRecordSearch");
        searchRequest.selectFields = new String[]{"orgId", "milServiceId", "meId", "meECNId", "deviceClsCode", "deviceCd", "deviceText", "manufOrgSerial", "custOrgId"};
        searchRequest.resultSetOffset = 0;
        searchRequest.resultSetSize = 300;

        /* Call the search service */
        Response response = searchService.getSearchResults(searchRequest);
        String entityStr = null;
        if (response.hasEntity()) {

            entityStr = response.readEntity(String.class);
        }
        return entityStr;
    }
}
