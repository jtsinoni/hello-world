package dmles.equipment.server.business;

import dmles.oauth.core.datamodel.CurrentUserBT;
import dmles.search.dao.ElasticSearchDao;
import mil.jmlfdc.common.business.BusinessManager; 
import org.slf4j.Logger;

import java.util.HashMap;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.ws.rs.QueryParam;

@Stateless
public class ElasticSearchManager extends BusinessManager {
    
    @Inject
    private Logger logger;
    @Inject 
    private ElasticSearchDao esDao;
    @Inject 
    private ElasticSearchAggregations esAggregations;
    @Inject
    private CurrentUserBT currentUser;
    
    protected static final String CATALOG_SEARCH_TEMP = "siteEquipItemList_qs";
    protected static final String EQUIP_REC_SEARCH_TEMP = "siteEquipRecordSearch_qs";
    protected static final String JMAR_SEARCH_TEMP = "jmarSiteCatalog_qs";

    /**
     * Builds and executes a catalog search query against the elasticsearch
     * database based on the given information.
     *
     * @param searchValue the query information given by the user
     * @param dodaac an optional parameter to execute the search only against a
     * certain dodaac
     *
     * @return a string representing the elasticsearch json
     */
    public String getCatalogSearchResults(String searchValue, String dodaac) {
        String searchVal = (searchValue == null || searchValue.isEmpty()) ? "*" : searchValue;

        Map<String, Object> templateParams = new HashMap<>();
        templateParams.put("searchValue", searchVal);
        if (dodaac != null && !dodaac.isEmpty()) {
            templateParams.put("dodaac", dodaac);
        }
        String responseString = esDao.getSearchResults(templateParams, CATALOG_SEARCH_TEMP);

        return responseString;
    }

    /**
     * Builds and executes an equipment records search query against the
     * elasticsearch database based on the given information.
     *
     * @param searchValue the query string given by the user, may include
     * filters
     * @param aggregations the aggregations provided by the user, may include
     * filters
     *
     * @return a string representing the elasticsearch json
     */
    public String getEquipmentRecordSearchResults(String searchValue, String aggregations) {

        String searchVal = (searchValue == null || searchValue.isEmpty()) ? "*" : searchValue;
        String aggs = (aggregations == null || aggregations.isEmpty()) ? "{}" : aggregations;
        logger.info("generic aggs - from PT = " + aggs);

        Map<String, Object> templateParams = new HashMap<>();
        templateParams.put("searchValue", searchVal);
        templateParams.put("aggregations", esAggregations.processAggregations(aggs));
        String responseString = esDao.getSearchResults(templateParams, EQUIP_REC_SEARCH_TEMP);

        return responseString;
    }

    /**
     * Builds and executes a JMAR search query against the elasticsearch
     * database based on the given information.
     *
     * @param searchValue the query string given by the user, may include
     * filters
     *
     * @return a string representing the elasticsearch json
     */
    public String getJmarSearchResults(@QueryParam("searchValue") String searchValue) {
        String searchVal = (searchValue == null || searchValue.isEmpty()) ? "*" : searchValue;

        Map<String, Object> templateParams = new HashMap<>();
        templateParams.put("searchValue", searchVal);
        String responseString = esDao.getSearchResults(templateParams, JMAR_SEARCH_TEMP);

        return responseString;
    }

    @Override
    public String getRequestorId() {
        String id;
        if (currentUser != null && currentUser.getProfileId() != null) {
            id = currentUser.getProfileId();
        } else {
            id = "test";
        }
        return id;
    }

    @Override
    public String getRequestorName() {
        String name;
        if (currentUser != null && currentUser.getFullName() != null) {
            name = currentUser.getFullName();
        } else {
            name = "test";
        }
        return name;
    }

}
