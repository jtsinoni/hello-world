package dmles.equipment.server.dao;

import dmles.equipment.server.datamodels.request.EquipmentRequestDO;
import mil.jmlfdc.common.dao.BaseDao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.enterprise.context.Dependent;

@Dependent
public class EquipmentRequestDao extends BaseDao<EquipmentRequestDO, String> {

    public EquipmentRequestDao() {
        super(EquipmentRequestDO.class);
    }

    public <T> List<EquipmentRequestDO> findByOrganizationId(T organizationID) {
    	Map<String, T> fieldFilter = new HashMap<>();
    	fieldFilter.put("requestInformation.organization.organizationID", organizationID);
        return this.query(fieldFilter);        
    }

    public List<EquipmentRequestDO> findRequestsByCustomerId(String custId) {
        return this.query(String.format("requestInformation.customer.customerID=%s", custId));
    }    
    
    public List<EquipmentRequestDO> findRequestsByCustodianId(String userId) {
        return this.query(String.format("requestInformation.submitter.userId=%s", userId));
    }    

    public <T> List<EquipmentRequestDO> findByService(T serviceCode) {
    	Map<String, T> fieldFilter = new HashMap<>();
    	fieldFilter.put("requestInformation.submitter.serviceCode", serviceCode);
        return this.query(fieldFilter); 
    }

    public <T> List<EquipmentRequestDO> findBySite(T dodaac) {
    	Map<String, T> fieldFilter = new HashMap<>();
    	fieldFilter.put("requestInformation.submitter.dodaac", dodaac);
        return this.query(fieldFilter);
    }

    public <T> List<EquipmentRequestDO> findByServiceAndRegion(T serviceCode, T regionCode) {
    	Map<String, T> fieldFilter = new HashMap<>();
    	fieldFilter.put("requestInformation.submitter.serviceCode", serviceCode);
    	fieldFilter.put("requestInformation.submitter.regionCode", regionCode);
        return this.query(fieldFilter); 
    }
}
