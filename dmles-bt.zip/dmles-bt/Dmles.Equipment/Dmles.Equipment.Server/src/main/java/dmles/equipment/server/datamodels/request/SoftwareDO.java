package dmles.equipment.server.datamodels.request;

public class SoftwareDO {
    public String title;
    public String type;
    public String version;
}
