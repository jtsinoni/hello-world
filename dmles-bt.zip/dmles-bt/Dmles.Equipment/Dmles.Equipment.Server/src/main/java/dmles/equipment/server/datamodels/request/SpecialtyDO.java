package dmles.equipment.server.datamodels.request;

import java.io.Serializable;
import mil.jmlfdc.common.datamodel.MorphiaEntity;
import org.mongodb.morphia.annotations.Entity;

@Entity("Specialty")
public class SpecialtyDO extends MorphiaEntity implements Serializable {
    private static final long serialVersionUID = 1L;
    private String code;
    private String description;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
