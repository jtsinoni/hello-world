package dmles.equipment.server.business;

import dmles.equipment.core.datamodels.catalog.CatalogItem;
import dmles.equipment.core.datamodels.request.workflow.process.LevelCriteriaNeeded;
import dmles.equipment.server.datamodels.request.EquipmentRequestDO;
import dmles.equipment.server.datamodels.request.workflow.definition.CriteriaCatalogItemDO;
import dmles.equipment.server.datamodels.request.workflow.definition.WorkflowLevelDefinitionDO;

import java.util.List;

class CatalogCriteriaNeededEvaluator implements ICriteriaEvaluator {
    @Override
    public LevelCriteriaNeeded evaluateCriteria(LevelCriteriaNeeded lcn, EquipmentRequestDO request, WorkflowLevelDefinitionDO levelDef) {
        List<CriteriaCatalogItemDO> catalogItemsCriteria = levelDef.getLevelCriteria().getCatalogItems();


        if (null != request.getCatalogItem() && null != catalogItemsCriteria) {
            if (null != request.getCatalogItem().itemId) {
                CatalogItem item = request.getCatalogItem();
                String catalogID = item.itemId;
                Float amount = request.getTotalRequisitionCost();
                lcn.deviceCriteriaMet = meetsCatalogCriteria(catalogID, amount,
                        catalogItemsCriteria);
            }
        }
        return lcn;
    }

    private boolean meetsCatalogCriteria(String catalogID, Float amountLimit, List<CriteriaCatalogItemDO> catalogItemsCriteria){
        boolean isFound = false;
        for(CriteriaCatalogItemDO catalogCriteria: catalogItemsCriteria){
            String catalogCritLower = catalogCriteria.getCatalogID().toLowerCase();
            String catalogIDLower = catalogID.toLowerCase();
            if(catalogCritLower.equals(catalogIDLower) && catalogCriteria.getTotalCost() >= amountLimit){
                isFound = true;
                break;
            }
        }
        return isFound;
    }


}
