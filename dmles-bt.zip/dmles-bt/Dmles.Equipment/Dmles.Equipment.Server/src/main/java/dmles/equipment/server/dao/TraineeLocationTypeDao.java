/*
    // ==========================================================================
    //       NOTICE:  THIS SOFTWARE WAS DEVELOPED UNDER CONTRACT
    //        TO THE U.S. GOVERNMENT, WHICH RESERVES ALL SOURCE
    //             RIGHTS AND FULL TECHNICAL DATA RIGHTS.
    // ==========================================================================
    //
 */

package dmles.equipment.server.dao;

import javax.enterprise.context.Dependent;
import mil.jmlfdc.common.dao.BaseDao;
import dmles.equipment.server.datamodels.request.TraineeLocationTypeDO;

@Dependent
public class TraineeLocationTypeDao extends BaseDao<TraineeLocationTypeDO, String> {
    
    public TraineeLocationTypeDao(){
        super(TraineeLocationTypeDO.class);
    }
    
}