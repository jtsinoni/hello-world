package dmles.equipment.server.datamodels.request;

import org.mongodb.morphia.annotations.Embedded;

import java.io.Serializable;

@Embedded
public class ServiceAgencyDO implements Serializable {

    public String code;
    public String name;

    public String getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public void setName(String name) {
        this.name = name;
    }

}
