package dmles.equipment.server.datamodels.request;

import java.io.Serializable;
import mil.jmlfdc.common.datamodel.MorphiaEntity;
import org.mongodb.morphia.annotations.Entity;

@Entity("EquipMountingType")
public class EquipmentMountingTypeDO extends MorphiaEntity implements Serializable {
    private static final long serialVersionUID = 1L;
    private Integer equipMountingTypeCd;
    private String equipMountingTypeTx;

    public Integer getEquipMountingTypeCd() {
        return equipMountingTypeCd;
    }

    public void setEquipMountingTypeCd(Integer equipMountingTypeCd) {
        this.equipMountingTypeCd = equipMountingTypeCd;
    }

    public String getEquipMountingTypeTx() {
        return equipMountingTypeTx;
    }

    public void setEquipMountingTypeTx(String equipMountingTypeTx) {
        this.equipMountingTypeTx = equipMountingTypeTx;
    }
    
    
}
