package dmles.equipment.server.business;

import dmles.equipment.core.datamodels.request.workflow.process.LevelCriteriaNeeded;
import dmles.equipment.server.datamodels.request.EquipmentRequestDO;
import dmles.equipment.server.datamodels.request.workflow.definition.WorkflowLevelDefinitionDO;

public interface ICriteriaEvaluator {

    LevelCriteriaNeeded evaluateCriteria(LevelCriteriaNeeded lcn, EquipmentRequestDO request, WorkflowLevelDefinitionDO levelDef);
}
