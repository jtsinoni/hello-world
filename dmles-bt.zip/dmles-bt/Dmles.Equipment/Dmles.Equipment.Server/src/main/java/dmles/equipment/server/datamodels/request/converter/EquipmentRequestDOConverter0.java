package dmles.equipment.server.datamodels.request.converter;

import com.mongodb.DBObject;
import mil.jmlfdc.common.datamodel.version.DmlesDataConverter;
import mil.jmlfdc.common.datamodel.version.DmlesDbObject;

import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class EquipmentRequestDOConverter0 extends DmlesDataConverter {

    private static final Integer VERSION = 1;

    @Override
    public void convertObject(DBObject object) {
        DmlesDbObject dbobj = new DmlesDbObject(object);
        convertMaintenanceInformationDO(dbobj);
        convertFacilityInfo(dbobj);
        convertRequestInformation(dbobj);
        System.out.println(object.toString());
    }

    @Override
    public Integer getConvertVersion() {
        return VERSION;
    }

    private void convertMaintenanceInformationDO(DmlesDbObject dbobj) {
        
        dbobj.move("acceptanceInspection", "maintenanceInformation/acceptanceInspection");
        dbobj.move("estimatedAnnualServiceCost", "maintenanceInformation/estimatedAnnualServiceCost");
        dbobj.move("installationRequired", "maintenanceInformation/installationRequired");
        dbobj.move("installationRequirements", "maintenanceInformation/installationRequirements");
        dbobj.move("literature", "maintenanceInformation/literature");
        dbobj.move("maintenanceActivity", "maintenanceInformation/maintenanceActivity");
        dbobj.move("maintenanceByOGA", "maintenanceInformation/maintenanceByOGA");
        dbobj.move("maintenanceByOrg", "maintenanceInformation/maintenanceByOrg");
        dbobj.move("maintenanceByService", "maintenanceInformation/maintenanceByService");
        dbobj.move("maintenanceExplanation", "maintenanceInformation/maintenanceExplanation");
        dbobj.move("tmdeRequired", "maintenanceInformation/tmdeRequired");
        dbobj.move("totalInstallationCosts", "maintenanceInformation/totalInstallationCosts");
        dbobj.move("maintenanceExplanation", "maintenanceInformation/maintenanceExplanation");
        dbobj.move("totalLiteratureCosts", "maintenanceInformation/totalLiteratureCosts");
        
    }

    private void convertFacilityInfo(DmlesDbObject dbobj) {

        dbobj.move("facilityModifications", "facilityInformation/facilityModifications");
        dbobj.move("facilityModificationCost", "facilityInformation/facilityModificationCost");

    }

    private void convertRequestInformation(DmlesDbObject dbobj) {

        dbobj.move("criticalCode", "requestInformation/criticalCode");
        dbobj.move("submitter", "requestInformation/submitter");
        dbobj.move("customer", "requestInformation/customer");
        dbobj.move("description", "requestInformation/description");
        dbobj.move("equipment", "requestInformation/equipment");
        dbobj.move("extraItems", "requestInformation/extraItems");
        dbobj.move("missionImpact", "requestInformation/missionImpact");
        dbobj.move("missionImpactDoc", "requestInformation/missionImpactDoc");
        dbobj.move("organization", "requestInformation/organization");
        dbobj.move("quantityRequested", "requestInformation/quantityRequested");
        dbobj.move("replacedItems", "requestInformation/replacedItems");
        dbobj.move("requestedDeliveryDate", "requestInformation/requestedDeliveryDate");
        dbobj.move("requestedDeliveryDateReason", "requestInformation/requestedDeliveryDateReason");
        dbobj.move("requester", "requestInformation/requester");
        dbobj.move("requestedItemId", "requestInformation/requestedItemId");
        dbobj.move("requestNumber", "requestInformation/requestNumber");
        dbobj.move("requestTitle", "requestInformation/requestTitle");
        dbobj.move("requestReason", "requestInformation/requestReason");
        dbobj.move("requestType", "requestInformation/requestType");
        dbobj.move("suggestedSources", "requestInformation/suggestedSources");

        dbobj.move("totalCompAccSupplies", "requestInformation/totalCompAccSupplies");
        dbobj.move("totalTrainingCost", "requestInformation/totalTrainingCost");
        dbobj.move("training", "requestInformation/training");
        dbobj.move("equipmentRequirements", "requestInformation/equipmentRequirements");

    }

}
