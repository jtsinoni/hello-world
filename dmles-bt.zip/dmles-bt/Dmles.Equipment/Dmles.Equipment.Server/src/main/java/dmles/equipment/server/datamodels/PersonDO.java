package dmles.equipment.server.datamodels;

import java.io.Serializable;

public class PersonDO implements Serializable {

    private static final long serialVersionUID = 1L;
    private String userId;
    private String nameFirst;
    private String nameLast;
    private String phoneNumber;
    private String email;
    private String defaultDodaac;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getNameFirst() {
        return nameFirst;
    }

    public void setNameFirst(String nameFirst) {
        this.nameFirst = nameFirst;
    }

    public String getNameLast() {
        return nameLast;
    }

    public void setNameLast(String nameLast) {
        this.nameLast = nameLast;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDefaultDodaac() {
        return defaultDodaac;
    }

    public void setDefaultDodaac(String defaultDodaac) {
        this.defaultDodaac = defaultDodaac;
    }

}
