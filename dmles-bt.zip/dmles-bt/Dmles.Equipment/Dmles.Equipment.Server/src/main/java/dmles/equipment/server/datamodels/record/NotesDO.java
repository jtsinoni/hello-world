package dmles.equipment.server.datamodels.record;

import org.mongodb.morphia.annotations.Embedded;

import java.io.Serializable;

@Embedded
public class NotesDO implements Serializable {
    private static final long serialVersionUID = 1L;
    private Integer meId;
    private Integer meNotesID;
    private String meNoteAuthrNm;
    private String meNotesDate;
    private String meNotesText;
    private String meNotesTypeCD;

    public Integer getMeId() {
        return meId;
    }

    public void setMeId(Integer meId) {
        this.meId = meId;
    }

    public Integer getMeNotesID() {
        return meNotesID;
    }

    public void setMeNotesID(Integer meNotesID) {
        this.meNotesID = meNotesID;
    }

    public String getMeNoteAuthrNm() {
        return meNoteAuthrNm;
    }

    public void setMeNoteAuthrNm(String meNoteAuthrNm) {
        this.meNoteAuthrNm = meNoteAuthrNm;
    }

    public String getMeNotesDate() {
        return meNotesDate;
    }

    public void setMeNotesDate(String meNotesDate) {
        this.meNotesDate = meNotesDate;
    }

    public String getMeNotesText() {
        return meNotesText;
    }

    public void setMeNotesText(String meNotesText) {
        this.meNotesText = meNotesText;
    }

    public String getMeNotesTypeCD() {
        return meNotesTypeCD;
    }

    public void setMeNotesTypeCD(String meNotesTypeCD) {
        this.meNotesTypeCD = meNotesTypeCD;
    }
}