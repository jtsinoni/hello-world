/*
 * JBoss, Home of Professional Open Source
 * Copyright 2013, Red Hat, Inc. and/or its affiliates, and individual
 * contributors by the @authors tag. See the copyright.txt in the
 * distribution for a full listing of individual contributors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package dmles.equipment.server.rest;

import dmles.equipment.server.utils.AnnotationUtils;
import io.swagger.annotations.Api;
import io.swagger.jaxrs.config.BeanConfig;
import java.util.HashSet;
import java.util.Set;
import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;
import mil.jmlfdc.common.rest.CorsFilter;
import mil.jmlfdc.common.utils.PropertyUtils;

/**
 * A class extending {@link Application} and annotated with @ApplicationPath is
 * the Java EE 7 "no XML" approach to activating JAX-RS.
 *
 * <p>
 * Resources are served relative to the servlet path specified in the
 * {@link ApplicationPath} annotation.
 * </p>
 */
@ApplicationPath("/")
@ApplicationScoped
public class JaxRsActivator extends Application {

    @Inject
    private PropertyUtils propertyUtils;
    private Boolean hideApi;

    /**
     * @return http or http and https
     */
    private String[] getSchemes() {
        String swaggerSchemes = propertyUtils.getProperty("swagger.schemes");
        return swaggerSchemes.split(",");
    }

    private void initSwagger() {
        if (!hideApi) {
            BeanConfig beanConfig = new BeanConfig();
            beanConfig.setVersion(propertyUtils.getProperty("project.version"));
            beanConfig.setSchemes(getSchemes());

            String host = propertyUtils.getProperty("swagger.host") + ":" + propertyUtils.getProperty("swagger.port");
            beanConfig.setHost(host);

            beanConfig.setBasePath(propertyUtils.getProperty("swagger.base.path"));
            beanConfig.setResourcePackage(propertyUtils.getProperty("swagger.resource.package"));
            beanConfig.setPrettyPrint(true);
            beanConfig.setScan(true);
        }
    }

    public JaxRsActivator() {
    }

    @PostConstruct
    public void init() {
        hideApi = Boolean.valueOf(propertyUtils.getProperty("swagger.hide.api"));

        initSwagger();
    }

    /**
     * swagger-core's providers
     */
    @Override
    public Set<Class<?>> getClasses() {
        Set<Class<?>> resources = new HashSet<Class<?>>();

        if (!hideApi) {
            Api annotation = EquipmentManagementRestApi.class.getAnnotation(Api.class);
            AnnotationUtils.changeAnnotationValue(annotation, "hidden", hideApi);

            resources.add(io.swagger.jaxrs.listing.ApiListingResource.class);
            resources.add(io.swagger.jaxrs.listing.SwaggerSerializers.class);
        }

        resources.add(EquipmentManagementRestApi.class);
        resources.add(CorsFilter.class);
        return resources;
    }
}
