package dmles.equipment.server.datamodels.request.workflow.definition;

public class LevelDefinitionReview {
    
    private String elementName;
    private String roleId;
    private String reviewDisplayName;

    public String getElementName() {
        return elementName;
    }

    public void setElementName(String elementName) {
        this.elementName = elementName;
    }

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    public String getReviewDisplayName() {
        return reviewDisplayName;
    }
    
    public void setReviewDisplayName(String reviewDisplayName) {
        this.reviewDisplayName = reviewDisplayName;
    }
    
}
