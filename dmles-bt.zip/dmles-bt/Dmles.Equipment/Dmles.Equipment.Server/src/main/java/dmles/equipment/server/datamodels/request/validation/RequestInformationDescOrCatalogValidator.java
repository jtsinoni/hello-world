package dmles.equipment.server.datamodels.request.validation;

import dmles.equipment.server.datamodels.request.RequestInformationDO;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class RequestInformationDescOrCatalogValidator implements ConstraintValidator<RequestInformationDescOrCatalog, RequestInformationDO> {

   public void initialize(RequestInformationDescOrCatalog constraint) {
   }

   public boolean isValid(RequestInformationDO obj, ConstraintValidatorContext context) {
      boolean isValid;

      if ((obj.getDescription() == null && obj.getCatalogItem() == null) ||
              (obj.getDescription() != null && obj.getCatalogItem() != null)) {
         isValid = false;
      } else {
         isValid = true;
      }

      return isValid;
   }
}
