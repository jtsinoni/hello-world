package dmles.equipment.server.datamodels.request.workflow.definition;

import java.util.List;
import org.mongodb.morphia.annotations.Embedded;

public class LevelCriteriaDO {

    private Float totalCostThreshold;
    private Float deviceCostThreshold;
    @Embedded
    private List<CriteriaCatalogItemDO> catalogItems;
    @Embedded
    private List<CriteriaDeviceDO> devices;

    public LevelCriteriaDO() {
    }

    public List<CriteriaCatalogItemDO> getCatalogItems() {
        return catalogItems;
    }

    public void setCatalogItems(List<CriteriaCatalogItemDO> catalogItems) {
        this.catalogItems = catalogItems;
    }

    public List<CriteriaDeviceDO> getDevices() {
        return devices;
    }

    public void setDevices(List<CriteriaDeviceDO> devices) {
        this.devices = devices;
    }

    public Float getTotalCostThreshold() {
        return totalCostThreshold;
    }

    public void setTotalCostThreshold(Float totalCostThreshold) {
        this.totalCostThreshold = totalCostThreshold;
    }

    public Float getDeviceCostThreshold() {
        return deviceCostThreshold;
    }

    public void setDeviceCostThreshold(Float deviceCostThreshold) {
        this.deviceCostThreshold = deviceCostThreshold;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        LevelCriteriaDO that = (LevelCriteriaDO) o;

        if (!(totalCostThreshold == null && that.totalCostThreshold == null) ||
                (totalCostThreshold != null && !totalCostThreshold.equals(that.totalCostThreshold)))
            return false;
        if (!(deviceCostThreshold == null && that.deviceCostThreshold == null) ||
                (deviceCostThreshold != null && !deviceCostThreshold.equals(that.deviceCostThreshold)))
            return false;
        if (!(catalogItems == null && that.catalogItems == null) ||
                catalogItems != null && !catalogItems.equals(that.catalogItems))
            return false;
        if (!(devices == null && that.devices == null) ||
                (devices != null && devices.equals(that.devices)))
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = (totalCostThreshold != null ? totalCostThreshold.hashCode() : 0);
        result = 31 * result + (deviceCostThreshold != null ? deviceCostThreshold.hashCode() : 0);
        result = 31 * result + (catalogItems != null ? catalogItems.hashCode() : 0);
        result = 31 * result + (devices != null ? devices.hashCode() : 0);
        return result;
    }
}
