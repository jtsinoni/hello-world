package dmles.equipment.server.business;

import dmles.equipment.core.datamodels.request.EquipmentRequest;
import dmles.equipment.core.datamodels.request.workflow.process.*;
import dmles.equipment.server.dao.EquipmentRequestDao;
import dmles.equipment.server.dao.WorkflowProcessingDao;
import dmles.equipment.server.datamodels.request.EquipmentRequestDO;
import dmles.equipment.server.datamodels.request.validation.RequestValidator;
import dmles.equipment.server.datamodels.request.workflow.process.WorkflowProcessingDO;
import mil.jmlfdc.common.datamodel.CurrentUserBT;
import dmles.equipment.server.datamodels.request.workflow.process.ReviewDO;import mil.jmlfdc.common.business.BusinessManager;
import mil.jmlfdc.common.exception.InvalidDataException;
import mil.jmlfdc.common.exception.ObjectNotFoundException;
import mil.jmlfdc.common.exception.ValidationException;
import mil.jmlfdc.common.utils.ObjectMapper;
import org.slf4j.Logger;

import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@Stateless
public class WorkflowProcessingManager extends BusinessManager {
    @Inject
    private Logger logger;          
    @Inject
    private EquipmentRequestDao equipReqDao;    
    @Inject
    private EquipmentRequestPersistenceHelper persistHelper;
    @Inject
    private WorkflowLogicFactory wfFactory;
    @Inject
    private WorkflowProcessingDao wfProcessingDao;
    @Inject
    private ReviewUserBuilder reviewUserBuilder;
    @Inject
    private ObjectMapper objectMapper;

    @Inject
    private RequestValidator requestValidator;
    @Inject
    private WorkflowHistoryManager history;
    @Inject
    private EquipmentRequestManager equipRequestManager;

    public WorkflowProcessing getWorkflowProcessing(@NotNull String processId) throws ObjectNotFoundException {
        WorkflowProcessingDO wfpDo = wfProcessingDao.findById(processId);
        return objectMapper.getObject(WorkflowProcessing.class, wfpDo);
    }

    public WorkflowProcessing getWorkflowProcessingByRequestId(@NotNull String requestId) throws ObjectNotFoundException {
        WorkflowProcessingDO wfpDo = wfProcessingDao.findWorkflowProcessingByRequestId(requestId);
        return objectMapper.getObject(WorkflowProcessing.class, wfpDo);
    }    

    public List<String> getReviewStatuses() {
        List<String> statusList = new ArrayList<>();
        for (ReviewStatus statusObj : ReviewStatus.values()) {
            statusList.add(statusObj.toString());
        }
        return statusList;
    }

    public List<String> getReviewResults() {
        List<String> resultList = new ArrayList<>();
        for (ReviewResult statusObj : ReviewResult.values()) {
            resultList.add(statusObj.toString());
        }
        return resultList;
    }    
    
    public EquipmentRequest addProcessComment(@NotNull String requestId, @NotNull String comment) throws ObjectNotFoundException {
        WorkflowLogic wfLogic = wfFactory.rebuildLogic(requestId);
        wfLogic.addProcessComment(comment);

        EquipmentRequestDO ereqDo = persistHelper.saveRequest(wfLogic.getRequest(), wfLogic);
        return objectMapper.getObject(EquipmentRequest.class, ereqDo);
    }
    
    public EquipmentRequest removeProcessComment(@NotNull String requestId, @NotNull String commentId) throws ObjectNotFoundException {
        WorkflowLogic wfLogic = wfFactory.rebuildLogic(requestId);
        wfLogic.removeProcessComment(commentId);
        
        EquipmentRequestDO ereqDo = persistHelper.saveRequest(wfLogic.getRequest(), wfLogic);
        return objectMapper.getObject(EquipmentRequest.class, ereqDo);
    }    

    public EquipmentRequest addReviewComment(@NotNull String requestId,
            @NotNull String reviewRole,
            @NotNull String comment) throws ObjectNotFoundException {

        WorkflowLogic wfLogic = wfFactory.rebuildLogic(requestId);
        wfLogic.addReviewComment(reviewRole, comment);

        EquipmentRequestDO ereqDo = persistHelper.saveRequest(wfLogic.getRequest(), wfLogic);
        return objectMapper.getObject(EquipmentRequest.class, ereqDo);
    }

    public EquipmentRequest removeReviewComment(@NotNull String requestId,
                                                @NotNull String reviewRole,
                                                @NotNull String commentId) throws ObjectNotFoundException {

        WorkflowLogic wfLogic = wfFactory.rebuildLogic(requestId);
        wfLogic.removeReviewComment(reviewRole, commentId);

        EquipmentRequestDO ereqDo = persistHelper.saveRequest(wfLogic.getRequest(), wfLogic);
        return objectMapper.getObject(EquipmentRequest.class, ereqDo);
    }

    public EquipmentRequest approveRequest(@NotNull String requestId) throws ObjectNotFoundException {
        WorkflowLogic wfLogic = wfFactory.rebuildLogic(requestId);
        wfLogic.approve();

        EquipmentRequestDO ereqDo = persistHelper.saveRequest(wfLogic.getRequest(), wfLogic);
        return objectMapper.getObject(EquipmentRequest.class, ereqDo);
    }

    public EquipmentRequest cancelRequest(@NotNull String requestId) throws ObjectNotFoundException {
        WorkflowLogic wfLogic = wfFactory.rebuildLogic(requestId);
        wfLogic.cancel();

        EquipmentRequestDO ereqDo = persistHelper.saveRequest(wfLogic.getRequest(), wfLogic);
        return objectMapper.getObject(EquipmentRequest.class, ereqDo);
    }


    public EquipmentRequest retractRequest(String requestId) throws ObjectNotFoundException, InvalidDataException {
        WorkflowLogic wfLogic = wfFactory.rebuildLogic(requestId);
        wfLogic.retract();

        EquipmentRequestDO ereqDo = persistHelper.saveRequest(wfLogic.getRequest(), wfLogic);
        return objectMapper.getObject(EquipmentRequest.class, ereqDo);
    }

    public EquipmentRequest forceUpRequest(@NotNull String requestId) throws ObjectNotFoundException {
        WorkflowLogic wfLogic = wfFactory.rebuildLogic(requestId);
        wfLogic.forceUp();

        EquipmentRequestDO ereqDo = persistHelper.saveRequest(wfLogic.getRequest(), wfLogic);
        return objectMapper.getObject(EquipmentRequest.class, ereqDo);
    }

    public EquipmentRequest holdRequest(@NotNull String requestId) throws ObjectNotFoundException {
        WorkflowLogic wfLogic = wfFactory.rebuildLogic(requestId);
        wfLogic.hold();

        EquipmentRequestDO ereqDo = persistHelper.saveRequest(wfLogic.getRequest(), wfLogic);
        return objectMapper.getObject(EquipmentRequest.class, ereqDo);
    }

    public EquipmentRequest reactivateRequest(@NotNull String requestId) throws ObjectNotFoundException {
        WorkflowLogic wfLogic = wfFactory.rebuildLogic(requestId);
        wfLogic.reactivate();

        EquipmentRequestDO ereqDo = persistHelper.saveRequest(wfLogic.getRequest(), wfLogic);
        return objectMapper.getObject(EquipmentRequest.class, ereqDo);
    }   

    public EquipmentRequest rejectRequest(@NotNull String requestId) throws ObjectNotFoundException {
        WorkflowLogic wfLogic = wfFactory.rebuildLogic(requestId);
        wfLogic.reject();

        EquipmentRequestDO ereqDo = persistHelper.saveRequest(wfLogic.getRequest(), wfLogic);
        return objectMapper.getObject(EquipmentRequest.class, ereqDo);
    }

    public EquipmentRequest reworkRequest(@NotNull String requestId) throws ObjectNotFoundException {
        WorkflowLogic wfLogic = wfFactory.rebuildLogic(requestId);
        wfLogic.rework();
        
        EquipmentRequestDO ereqDo = persistHelper.saveRequest(wfLogic.getRequest(), wfLogic);                
        return objectMapper.getObject(EquipmentRequest.class, ereqDo);
    }

    private EquipmentRequestDO saveWithProcessing(@NotNull EquipmentRequestDO equipReqDO, String section) throws ObjectNotFoundException {
        WorkflowLogic wfLogic = wfFactory.rebuildLogic(equipReqDO);
        history.addHistory(equipReqDO, wfLogic.getCurrentLevelName(), section, "Data updated");
        equipReqDO = persistHelper.saveRequest(wfLogic.getRequest(), wfLogic);         
        return equipReqDO;
    }
    
    public EquipmentRequest buildReviews(@NotNull String requestId) throws ObjectNotFoundException {
        EquipmentRequestDO equipRequestIn = equipReqDao.findById(requestId);
        WorkflowProcessingDO wfProcessing = equipRequestIn.getWfProcessing();
        if (null != wfProcessing && !wfProcessing.getIsCompleted()){
            reviewUserBuilder.buildReviewUsers(wfProcessing);
            wfProcessingDao.upsert(wfProcessing);
        }
        EquipmentRequestDO equipRequestOut = equipReqDao.findById(requestId);
        return objectMapper.getObject(EquipmentRequest.class, equipRequestOut);
    }    
    
    public EquipmentRequest submitForReviews(@NotNull String requestId,
                                             String reviewRole, String reviewDisplayName) throws ObjectNotFoundException {
        WorkflowLogic wfLogic = wfFactory.rebuildLogic(requestId);
        wfLogic.beginReviews(reviewRole, reviewDisplayName);
        
        EquipmentRequestDO ereqDo = persistHelper.saveRequest(wfLogic.getRequest(), wfLogic);                
        return objectMapper.getObject(EquipmentRequest.class, ereqDo);
    }

    public EquipmentRequest submitReviewResult(@NotNull String requestId,
            @NotNull String reviewResult, @NotNull String reviewDisplayName) throws ObjectNotFoundException {
        
        WorkflowLogic wfLogic = wfFactory.rebuildLogic(requestId);
        wfLogic.addReviewResult(reviewResult, reviewDisplayName);

        EquipmentRequestDO ereqDo = persistHelper.saveRequest(wfLogic.getRequest(), wfLogic);                
        return objectMapper.getObject(EquipmentRequest.class, ereqDo);
    }

    public EquipmentRequest submitReviewStatus(EquipmentRequest request) throws ObjectNotFoundException {
        EquipmentRequestDO requestDoIn = objectMapper.getObject(EquipmentRequestDO.class, request);
        EquipmentRequestDO dbRequest = persistHelper.getRequest(requestDoIn.getId());

        WorkflowLogic wfLogic = wfFactory.rebuildLogic(requestDoIn);
        WorkflowProcessingDO wfProcessingIn = requestDoIn.getWfProcessing();
        WorkflowProcessingDO wfProcessingDb = dbRequest.getWfProcessing();

        wfLogic.addReviewStatus(wfProcessingIn, wfProcessingDb);

        EquipmentRequestDO ereqDo = persistHelper.saveRequest(wfLogic.getRequest(), wfLogic);                
        return objectMapper.getObject(EquipmentRequest.class, ereqDo);
    }
    
    public EquipmentRequest submitForProcessing(@NotNull @Valid EquipmentRequest request) throws ObjectNotFoundException, ValidationException {
        equipRequestManager.generateRequestSequenceNumber(request);
        EquipmentRequestDO requestDoIn = objectMapper.getObject(EquipmentRequestDO.class, request);

        requestValidator.validate(requestDoIn);
        persistHelper.saveRequest(requestDoIn, null);
               
        // Create Workflow
        WorkflowLogic wfLogic = wfFactory.buildLogic(requestDoIn);
        WorkflowProcessingDO wfpDO = wfLogic.submit();
        
        wfProcessingDao.insert(wfpDO);
        wfpDO = wfProcessingDao.findById(wfpDO.getId());
        
        // Add Workflow Processing to the request as a reference object
        wfLogic.getRequest().setWfProcessing(wfpDO);
        history.addHistory(requestDoIn, wfLogic.getCurrentLevelName(), "Request", "Request submitted for processing");

        // Save Deltas
        EquipmentRequestDO ereqDo = persistHelper.saveRequest(wfLogic.getRequest(), wfLogic);                
        return objectMapper.getObject(EquipmentRequest.class, ereqDo);
    }

    public List<LevelCriteriaNeeded> getLevelsCriteriaNeeded(String  requestId) throws ObjectNotFoundException {
        WorkflowLogic wfLogic = wfFactory.rebuildLogic(requestId);
        List<LevelCriteriaNeeded> list = null;
        if (wfLogic != null) {
            list = wfLogic.getLevelsCriteriaNeeded();
        }
        return list;
    }

    public List<LevelCriteriaNeeded> getLevelsCriteriaNeeded(EquipmentRequest request) throws ObjectNotFoundException {
        List<LevelCriteriaNeeded> list;

        EquipmentRequestDO erDo = objectMapper.getObject(EquipmentRequestDO.class, request);

        WorkflowLogic wfLogic;
        // if the request is not in workflow we get a temporary workflow and use it to build the resposne
        if ( erDo.getWfProcessing() == null) {
            wfLogic = wfFactory.buildLogic(erDo);
        } else {
            wfLogic = wfFactory.rebuildLogic(erDo);
        }
        WorkflowProcessingDO wfpDO = wfLogic.submit(); // this will build the levels but not save
        erDo.setWfProcessing(wfpDO);

        list = wfLogic.getLevelsCriteriaNeeded();

        return list;
    }

}
