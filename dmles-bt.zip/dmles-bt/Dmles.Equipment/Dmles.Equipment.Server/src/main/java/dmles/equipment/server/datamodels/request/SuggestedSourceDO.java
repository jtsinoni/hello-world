package dmles.equipment.server.datamodels.request;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.io.Serializable;
import java.util.Date;
import mil.jmlfdc.common.constants.DateAndTime;

public class SuggestedSourceDO implements Serializable {
    private static final long serialVersionUID = 1L;

    private Boolean creditCard;
    private Boolean primarySource;
    private Boolean soleSource;

    private String contract;
    private String pocEmail;
    private String pocFirstName;
    private String pocLastName;
    private String pocPhone1;
    private String pocPhone2;
    private String pocTitle;
    private String sourceName;
    private String supplierCatalogNumber;
    private String supplierCatalogReference;
    private String supplierAddress1;
    private String supplierAddress2;
    private String supplierCity;
    private String supplierState;
    private String supplierZip;
    private String supplierCountry;
    private String url;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateAndTime.DATE_TIME_PATTERN)
    private Date contractExpDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateAndTime.DATE_TIME_PATTERN)
    private Date supplierCatalogDate;

    public Boolean getCreditCard() {
        return creditCard;
    }

    public void setCreditCard(Boolean creditCard) {
        this.creditCard = creditCard;
    }

    public Boolean getPrimarySource() {
        return primarySource;
    }

    public void setPrimarySource(Boolean primarySource) {
        this.primarySource = primarySource;
    }

    public Boolean getSoleSource() {
        return soleSource;
    }

    public void setSoleSource(Boolean soleSource) {
        this.soleSource = soleSource;
    }

    public String getContract() {
        return contract;
    }

    public void setContract(String contract) {
        this.contract = contract;
    }

    public String getPocEmail() {
        return pocEmail;
    }

    public void setPocEmail(String pocEmail) {
        this.pocEmail = pocEmail;
    }

    public String getPocFirstName() {
        return pocFirstName;
    }

    public void setPocFirstName(String pocFirstName) {
        this.pocFirstName = pocFirstName;
    }

    public String getPocLastName() {
        return pocLastName;
    }

    public void setPocLastName(String pocLastName) {
        this.pocLastName = pocLastName;
    }
    
    public String getPocPhone1() {
        return pocPhone1;
    }

    public void setPocPhone1(String pocPhone1) {
        this.pocPhone1 = pocPhone1;
    }

    public String getPocPhone2() {
        return pocPhone2;
    }

    public void setPocPhone2(String pocPhone2) {
        this.pocPhone2 = pocPhone2;
    }

    public String getPocTitle() {
        return pocTitle;
    }

    public void setPocTitle(String pocTitle) {
        this.pocTitle = pocTitle;
    }

    public String getSourceName() {
        return sourceName;
    }

    public void setSourceName(String sourceName) {
        this.sourceName = sourceName;
    }

    public String getSupplierCatalogNumber() {
        return supplierCatalogNumber;
    }

    public void setSupplierCatalogNumber(String supplierCatalogNumber) {
        this.supplierCatalogNumber = supplierCatalogNumber;
    }

    public String getSupplierCatalogReference() {
        return supplierCatalogReference;
    }

    public void setSupplierCatalogReference(String supplierCatalogReference) {
        this.supplierCatalogReference = supplierCatalogReference;
    }

    public String getSupplierAddress1() {
        return supplierAddress1;
    }

    public void setSupplierAddress1(String supplierAddress1) {
        this.supplierAddress1 = supplierAddress1;
    }

    public String getSupplierAddress2() {
        return supplierAddress2;
    }

    public void setSupplierAddress2(String supplierAddress2) {
        this.supplierAddress2 = supplierAddress2;
    }

    public String getSupplierCity() {
        return supplierCity;
    }

    public void setSupplierCity(String supplierCity) {
        this.supplierCity = supplierCity;
    }

    public String getSupplierState() {
        return supplierState;
    }

    public void setSupplierState(String supplierState) {
        this.supplierState = supplierState;
    }

    public String getSupplierZip() {
        return supplierZip;
    }

    public void setSupplierZip(String supplierZip) {
        this.supplierZip = supplierZip;
    }

    public String getSupplierCountry() {
        return supplierCountry;
    }

    public void setSupplierCountry(String supplierCountry) {
        this.supplierCountry = supplierCountry;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Date getContractExpDate() {
        return contractExpDate;
    }

    public void setContractExpDate(Date contractExpDate) {
        this.contractExpDate = contractExpDate;
    }

    public Date getSupplierCatalogDate() {
        return supplierCatalogDate;
    }

    public void setSupplierCatalogDate(Date supplierCatalogDate) {
        this.supplierCatalogDate = supplierCatalogDate;
    }
    
}
