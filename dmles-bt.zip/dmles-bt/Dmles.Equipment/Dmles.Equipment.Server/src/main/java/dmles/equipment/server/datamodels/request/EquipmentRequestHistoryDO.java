package dmles.equipment.server.datamodels.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
import java.util.Date;

/* Note: This may be replaced by logstash at some point in the future. */
public class EquipmentRequestHistoryDO implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private String action;
    private String performedBy;
    
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSX")
    private Date performedDate;

    public EquipmentRequestHistoryDO() {
    }

    public EquipmentRequestHistoryDO(String action, String performedBy, Date performedDate) {
        this.action = action;
        this.performedBy = performedBy;
        this.performedDate = performedDate;
    }
    
    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getPerformedBy() {
        return performedBy;
    }

    public void setPerformedBy(String performedBy) {
        this.performedBy = performedBy;
    }

    public Date getPerformedDate() {
        return performedDate;
    }

    public void setPerformedDate(Date performedDate) {
        this.performedDate = performedDate;
    }
    
    
}
