package dmles.equipment.server.datamodels.request.workflow.definition;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import mil.jmlfdc.common.constants.DateAndTime;
import mil.jmlfdc.common.datamodel.MorphiaEntity;
import mil.jmlfdc.common.utils.StringUtil;
import org.mongodb.morphia.annotations.Embedded;
import org.mongodb.morphia.annotations.Entity;

@Entity("EquipmentRequestWorkflowDefinition")
public class WorkflowDefinitionDO extends MorphiaEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    private String name;
    private String service;

    @Embedded
    private List<WorkflowLevelDefinitionDO> levelDefinitions = new ArrayList<>();

    private String version;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateAndTime.DATE_TIME_PATTERN)
    private Date dateCreated;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateAndTime.DATE_TIME_PATTERN)
    private Date dateUpdated;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateAndTime.DATE_TIME_PATTERN)
    private Date effectiveDate;
    private String updatedBy;
    private boolean active;

    public WorkflowDefinitionDO() {
    }

    public WorkflowDefinitionDO(String name, String service, String version, Date dateCreated, Date dateUpdated) {
        this.name = name;
        this.service = service;
        this.version = version;
        this.dateCreated = dateCreated;
        this.dateUpdated = dateUpdated;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public List<WorkflowLevelDefinitionDO> getLevelDefinitions() {
        return levelDefinitions;
    }
    
    public WorkflowLevelDefinitionDO getLevelDefinition(Integer level) {
        return levelDefinitions.get(level);
    }
    
    public void setLevelDefinitions(List<WorkflowLevelDefinitionDO> levelDefinitions) {
        this.levelDefinitions = levelDefinitions;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public Date getDateUpdated() {
        return dateUpdated;
    }

    public void setDateUpdated(Date dateUpdated) {
        this.dateUpdated = dateUpdated;
    }
    
    public Date getEffectiveDate() {
        return effectiveDate;
    }

    public void setEffectiveDate(Date effectiveDate) {
        this.effectiveDate = effectiveDate;
    }
    
    public String getRoleOwner(Integer wfLevelId) {
        String ownerRole = "No role owner";
        WorkflowLevelDefinitionDO wfLevelDefinition = getLevelDefinition(wfLevelId);
        // TODO: Only really need the role name, WFD needs to be updated
        if (null != wfLevelDefinition.getOwnerRoleId() && !StringUtil.isEmptyOrNull(wfLevelDefinition.getOwnerRoleId())) {
            ownerRole = wfLevelDefinition.getOwnerRoleId();
        }
        return ownerRole;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }
}