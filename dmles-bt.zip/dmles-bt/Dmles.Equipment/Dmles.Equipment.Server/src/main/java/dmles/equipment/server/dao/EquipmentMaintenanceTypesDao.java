package dmles.equipment.server.dao;

import javax.enterprise.context.Dependent;
import java.util.ArrayList;
import java.util.List;

import mil.jmlfdc.common.dao.BaseDao;
import dmles.equipment.server.datamodels.request.EquipmentMaintenanceTypesDO;
import org.mongodb.morphia.query.Query;

@Dependent
public class EquipmentMaintenanceTypesDao extends BaseDao<EquipmentMaintenanceTypesDO, String> {
    
    public EquipmentMaintenanceTypesDao(){
        super(EquipmentMaintenanceTypesDO.class);
    }

    public List<String> findMaintenanceCodes( String serviceAgency ) {
        
        List<String> maintCodes = new ArrayList<>();
        
        Query<EquipmentMaintenanceTypesDO> query = getQuery(EquipmentMaintenanceTypesDO.class);
        query.retrievedFields(true, "types");
    	query.field("serviceAgency.code").equal(serviceAgency);

        List<EquipmentMaintenanceTypesDO> codesList = query.asList();
        
        if ( codesList.size() == 1 )
        {    
            maintCodes = codesList.get(0).getMaintenanceCodes();
            
        } else {
            maintCodes.add("");
        }
        
        return maintCodes;
    }
    
}