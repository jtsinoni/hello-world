package dmles.equipment.server.dao;

import javax.enterprise.context.Dependent;
import mil.jmlfdc.common.dao.BaseDao;
import dmles.equipment.server.datamodels.request.EquipmentManufacturerDO;
import java.util.List;

@Dependent
public class EquipmentManufacturerDao extends BaseDao<EquipmentManufacturerDO, String> {
    
    public EquipmentManufacturerDao(){
        super(EquipmentManufacturerDO.class);
    }

    public List<EquipmentManufacturerDO> findCodeAndText() {
        List<EquipmentManufacturerDO> manufactureList = (List<EquipmentManufacturerDO>) this.getDatastore().createQuery(EquipmentManufacturerDO.class)
                .retrievedFields(true, "organizationNm")
                .field("deleteInd").equal("N")
                .asList();
        
        return manufactureList;
    }
    
}