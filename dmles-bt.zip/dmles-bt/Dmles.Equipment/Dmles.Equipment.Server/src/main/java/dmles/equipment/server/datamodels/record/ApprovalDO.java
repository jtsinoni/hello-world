package dmles.equipment.server.datamodels.record;

import org.mongodb.morphia.annotations.Embedded;

import java.io.Serializable;

@Embedded
public class ApprovalDO implements Serializable {
    private static final long serialVersionUID = 1L;
    private String rankGrade;
    private String firstName;
    private String lastName;
    private String transReasTypeTx;
    private Integer mtfSerial;
    private String equipBalanceRefTx;
    private String specialty;
    private String sos;
    private String cfoAsstClsTyTx;
    private String duidTypeDesc;
    private String duiiStatusDesc;

    public String getRankGrade() {
        return rankGrade;
    }

    public void setRankGrade(String rankGrade) {
        this.rankGrade = rankGrade;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getTransReasTypeTx() {
        return transReasTypeTx;
    }

    public void setTransReasTypeTx(String transReasTypeTx) {
        this.transReasTypeTx = transReasTypeTx;
    }

    public Integer getMtfSerial() {
        return mtfSerial;
    }

    public void setMtfSerial(Integer mtfSerial) {
        this.mtfSerial = mtfSerial;
    }

    public String getEquipBalanceRefTx() {
        return equipBalanceRefTx;
    }

    public void setEquipBalanceRefTx(String equipBalanceRefTx) {
        this.equipBalanceRefTx = equipBalanceRefTx;
    }

    public String getSpecialty() {
        return specialty;
    }

    public void setSpecialty(String specialty) {
        this.specialty = specialty;
    }

    public String getSos() {
        return sos;
    }

    public void setSos(String sos) {
        this.sos = sos;
    }

    public String getCfoAsstClsTyTx() {
        return cfoAsstClsTyTx;
    }

    public void setCfoAsstClsTyTx(String cfoAsstClsTyTx) {
        this.cfoAsstClsTyTx = cfoAsstClsTyTx;
    }

    public String getDuidTypeDesc() {
        return duidTypeDesc;
    }

    public void setDuidTypeDesc(String duidTypeDesc) {
        this.duidTypeDesc = duidTypeDesc;
    }

    public String getDuiiStatusDesc() {
        return duiiStatusDesc;
    }

    public void setDuiiStatusDesc(String duiiStatusDesc) {
        this.duiiStatusDesc = duiiStatusDesc;
    }
}