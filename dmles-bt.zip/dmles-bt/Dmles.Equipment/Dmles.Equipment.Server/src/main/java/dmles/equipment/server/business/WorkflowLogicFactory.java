package dmles.equipment.server.business;

import dmles.common.general.logging.Logger;
import dmles.equipment.server.dao.EquipmentRequestDao;
import dmles.equipment.server.dao.WorkflowDefinitionDao;
import dmles.equipment.server.dao.WorkflowProcessingDao;
import dmles.equipment.server.datamodels.request.EquipmentRequestDO;
import dmles.equipment.server.datamodels.request.workflow.definition.WorkflowDefinitionDO;
import dmles.equipment.server.datamodels.request.workflow.process.WorkflowProcessingDO;
import mil.jmlfdc.common.datamodel.CurrentUserBT;
import mil.jmlfdc.common.exception.ObjectNotFoundException;
import mil.jmlfdc.common.utils.StringUtil;


import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.validation.constraints.NotNull;

@Stateless
public class WorkflowLogicFactory {

    @Inject
    private Logger logger;
    @Inject
    private CurrentUserBT currentUserBT;    
    @Inject
    private EquipmentRequestDao equipReqDao;
    @Inject
    private WorkflowDefinitionDao wfDefinitionDao;
    @Inject
    private WorkflowProcessingDao wfProcessingDao;

    public WorkflowLogic rebuildLogic(@NotNull String requestId) throws ObjectNotFoundException {
        EquipmentRequestDO request = equipReqDao.findById(requestId);
        WorkflowLogic wfLogic = rebuildLogic(request);
        return wfLogic;
    }    
    
    public WorkflowLogic rebuildLogic(@NotNull EquipmentRequestDO request) throws ObjectNotFoundException {
        
        WorkflowProcessingDO wfProcessing = request.getWfProcessing();
        if(null == wfProcessing){
            logger.warn("Request has not been submitted for processing.");
            return null;
        }     
        
        WorkflowDefinitionDO wfDefinition = wfProcessing.getWfDefinition();
        if(null == wfDefinition){
            logger.error("Unable to obtain workflow definition"); 
            return null;
        }

        return new WorkflowLogic(request, wfDefinition, currentUserBT, wfProcessingDao);
    }    
    
    public WorkflowLogic buildLogic(@NotNull String requestId) throws ObjectNotFoundException {
        EquipmentRequestDO request = equipReqDao.findById(requestId);
        WorkflowLogic wfLogic = buildLogic(request);
        return wfLogic;
    }    
    
    public WorkflowLogic buildLogic(@NotNull EquipmentRequestDO request) throws ObjectNotFoundException {

        String serviceCode = currentUserBT.getServiceCode();
        if(null == currentUserBT || StringUtil.isEmptyOrNull(serviceCode)){
            logger.error("Unable to obtain to get user's service code"); 
            return null;
        }        
        
        WorkflowDefinitionDO wfDefinition = wfDefinitionDao.findByServiceName(serviceCode);
        if(null == wfDefinition){
            logger.error("Unable to obtain workflow definition"); 
            return null;
        }

        return new WorkflowLogic(request, wfDefinition, currentUserBT, wfProcessingDao);
    }
    
}
