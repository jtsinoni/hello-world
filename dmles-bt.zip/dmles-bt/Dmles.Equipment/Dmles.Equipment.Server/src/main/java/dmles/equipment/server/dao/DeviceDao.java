package dmles.equipment.server.dao;

import javax.enterprise.context.Dependent;
import mil.jmlfdc.common.dao.BaseDao;
import dmles.equipment.server.datamodels.request.DeviceDO;
import java.util.List;

@Dependent
public class DeviceDao extends BaseDao<DeviceDO, String> {

    public DeviceDao() {
        super(DeviceDO.class);
    }

    public List<DeviceDO> findCodeAndText() {

        List<DeviceDO> deviceList = (List<DeviceDO>) this.getDatastore().createQuery(DeviceDO.class).retrievedFields(true, "deviceCode", "nomenclature")
                .field("isRetired").equal(false)
                .asList();

        return deviceList;
    }

}
