package dmles.equipment.server.business;

import dmles.equipment.server.datamodels.request.workflow.definition.LevelDefinitionReviewDO;
import dmles.equipment.server.datamodels.request.workflow.definition.WorkflowLevelDefinitionDO;
import dmles.equipment.server.datamodels.request.workflow.process.ReviewDO;
import dmles.equipment.server.datamodels.request.workflow.process.ReviewUserDO;
import dmles.equipment.server.datamodels.request.workflow.process.WorkflowLevelProcessingDO;
import dmles.equipment.server.datamodels.request.workflow.process.WorkflowProcessingDO;
import dmles.user.client.UserService;
import dmles.user.core.IUserService;
import dmles.user.core.clientmodel.CurrentUserBasicPT;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import mil.jmlfdc.common.exception.ObjectNotFoundException;
import mil.jmlfdc.common.utils.ObjectMapper;

@Stateless
public class ReviewUserBuilder {
    
    @Inject
    @UserService
    private IUserService userService;

    @Inject
    private ObjectMapper objectMapper;

    public void buildReviewUsers(WorkflowProcessingDO wfpDO) throws ObjectNotFoundException {

        int currentLevelId = wfpDO.getCurrentLevel().getLevelId();
        WorkflowLevelProcessingDO currentLevel = wfpDO.getCurrentLevel();
        WorkflowLevelDefinitionDO levelDefinition = wfpDO.getWfDefinition().getLevelDefinitions().get(currentLevelId);

        Map<String, List<CurrentUserBasicPT>> userElementMap = new HashMap<>();
        List<LevelDefinitionReviewDO> reviewDefinitionElementsList = levelDefinition.getLevelDefinitionReviews();

        List<String> definitionRolesList = getRoles(reviewDefinitionElementsList);
        
        String userType = levelDefinition.getUserType();
        String[] rolesArray = definitionRolesList.toArray(new String[definitionRolesList.size()]);    
        
        userElementMap = userService.getUsersForRoles(userType, rolesArray);
        List<ReviewDO> reviews = currentLevel.getReviews();
        
        userElementMap.forEach((roleId, userList) -> {
            for (ReviewDO reviewDO : reviews) {
                if(reviewDO.getRoleId().equals(roleId)){
                    List<ReviewUserDO> ReviewUsersDO = objectMapper.getList(ReviewUserDO[].class, userList);
                    reviewDO.setReviewUsersDO(ReviewUsersDO);
                }
            }
            }
        );
        
    }
    
    private List<String> getRoles(List<LevelDefinitionReviewDO> list) {
        List<String> roleList = new ArrayList<>();
        for (LevelDefinitionReviewDO item: list) {
            roleList.add(item.getRoleId());
        }
        return roleList;
    }
}
