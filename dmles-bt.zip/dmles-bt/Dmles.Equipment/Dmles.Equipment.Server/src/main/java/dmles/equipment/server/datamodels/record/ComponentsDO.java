package dmles.equipment.server.datamodels.record;

import org.mongodb.morphia.annotations.Embedded;

import java.io.Serializable;

@Embedded

public class ComponentsDO implements Serializable {
    private static final long serialVersionUID = 1L;
    private Integer cMeID;
    private String cMeEcnID;
    private Integer cMEItemSerial;
    private String cItemID;
    private String cDeviceText;
    private Integer cManuOrgSerial;
    private String cOrgName;
    private String cMeManufModelID;
    private String cMeMfgSerialID;
    private Integer cManufMdlSerID;
    private String cManufMdlComnID;
    private Integer cTotalAcqCost;

    public Integer getcMeID() {
        return cMeID;
    }

    public void setcMeID(Integer cMeID) {
        this.cMeID = cMeID;
    }

    public String getcMeEcnID() {
        return cMeEcnID;
    }

    public void setcMeEcnID(String cMeEcnID) {
        this.cMeEcnID = cMeEcnID;
    }

    public Integer getcMEItemSerial() {
        return cMEItemSerial;
    }

    public void setcMEItemSerial(Integer cMEItemSerial) {
        this.cMEItemSerial = cMEItemSerial;
    }

    public String getcItemID() {
        return cItemID;
    }

    public void setcItemID(String cItemID) {
        this.cItemID = cItemID;
    }

    public String getcDeviceText() {
        return cDeviceText;
    }

    public void setcDeviceText(String cDeviceText) {
        this.cDeviceText = cDeviceText;
    }

    public Integer getcManuOrgSerial() {
        return cManuOrgSerial;
    }

    public void setcManuOrgSerial(Integer cManuOrgSerial) {
        this.cManuOrgSerial = cManuOrgSerial;
    }

    public String getcOrgName() {
        return cOrgName;
    }

    public void setcOrgName(String cOrgName) {
        this.cOrgName = cOrgName;
    }

    public String getcMeManufModelID() {
        return cMeManufModelID;
    }

    public void setcMeManufModelID(String cMeManufModelID) {
        this.cMeManufModelID = cMeManufModelID;
    }

    public String getcMeMfgSerialID() {
        return cMeMfgSerialID;
    }

    public void setcMeMfgSerialID(String cMeMfgSerialID) {
        this.cMeMfgSerialID = cMeMfgSerialID;
    }

    public Integer getcManufMdlSerID() {
        return cManufMdlSerID;
    }

    public void setcManufMdlSerID(Integer cManufMdlSerID) {
        this.cManufMdlSerID = cManufMdlSerID;
    }

    public String getcManufMdlComnID() {
        return cManufMdlComnID;
    }

    public void setcManufMdlComnID(String cManufMdlComnID) {
        this.cManufMdlComnID = cManufMdlComnID;
    }

    public Integer getcTotalAcqCost() {
        return cTotalAcqCost;
    }

    public void setcTotalAcqCost(Integer cTotalAcqCost) {
        this.cTotalAcqCost = cTotalAcqCost;
    }
}