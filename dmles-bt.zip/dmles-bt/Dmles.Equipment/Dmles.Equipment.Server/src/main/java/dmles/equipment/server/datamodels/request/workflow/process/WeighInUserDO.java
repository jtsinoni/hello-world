package dmles.equipment.server.datamodels.request.workflow.process;

import java.io.Serializable;

public class WeighInUserDO implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private String id;
    private String profileName;
    private String pkiDn;
    private String dodaac;
    private String email;
    private String firstName;
    private String lastName;
    private String userType;
    private String serviceCode;
    private String regionCode;    

    public WeighInUserDO() {
    }
    
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getProfileName() {
        return profileName;
    }

    public void setProfileName(String profileName) {
        this.profileName = profileName;
    }

    public String getPkiDn() {
        return pkiDn;
    }

    public void setPkiDn(String pkiDn) {
        this.pkiDn = pkiDn;
    }

    public String getDodaac() {
        return dodaac;
    }

    public void setDodaac(String dodaac) {
        this.dodaac = dodaac;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public String getServiceCode() {
        return serviceCode;
    }

    public void setServiceCode(String serviceCode) {
        this.serviceCode = serviceCode;
    }

    public String getRegionCode() {
        return regionCode;
    }

    public void setRegionCode(String regionCode) {
        this.regionCode = regionCode;
    }
    
    
}
