package dmles.equipment.server.datamodels;

import java.io.Serializable;

public class OrganizationDO implements Serializable {
    private static final long serialVersionUID = 1L; 
    private String id;
    private String organizationID;
    private String organizationOrgName;
    private String organizationSerial;    

    public OrganizationDO() {
    }

    public OrganizationDO(String organizationID, String organizationOrgName, String organizationSerial) {
        this.organizationID = organizationID;
        this.organizationOrgName = organizationOrgName;
        this.organizationSerial = organizationSerial;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
    
    public String getOrganizationID() {
        return organizationID;
    }

    public void setOrganizationID(String organizationID) {
        this.organizationID = organizationID;
    }

    public String getOrganizationOrgName() {
        return organizationOrgName;
    }

    public void setOrganizationOrgName(String organizationOrgName) {
        this.organizationOrgName = organizationOrgName;
    }

    public String getOrganizationSerial() {
        return organizationSerial;
    }

    public void setOrganizationSerial(String organizationSerial) {
        this.organizationSerial = organizationSerial;
    }
    
}
