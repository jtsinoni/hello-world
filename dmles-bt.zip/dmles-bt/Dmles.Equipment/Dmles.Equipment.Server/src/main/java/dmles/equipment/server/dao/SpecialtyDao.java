package dmles.equipment.server.dao;

import javax.enterprise.context.Dependent;
import mil.jmlfdc.common.dao.BaseDao;
import dmles.equipment.server.datamodels.request.SpecialtyDO;

@Dependent
public class SpecialtyDao extends BaseDao<SpecialtyDO, String> {
    
    public SpecialtyDao(){
        super(SpecialtyDO.class);
    }
    
}