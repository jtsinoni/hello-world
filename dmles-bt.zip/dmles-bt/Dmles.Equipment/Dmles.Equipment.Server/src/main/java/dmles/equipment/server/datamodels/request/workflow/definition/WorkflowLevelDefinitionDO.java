package dmles.equipment.server.datamodels.request.workflow.definition;

import org.mongodb.morphia.annotations.Embedded;

import java.util.ArrayList;
import java.util.List;

public class WorkflowLevelDefinitionDO {

    private Integer levelId;
    private String name;
    private String userType;
    private String ownerRoleId;
    @Embedded
    private RulesDO rules;
    @Embedded
    private List<LevelDefinitionReviewDO> levelDefinitionReviews = new ArrayList<>();
    @Embedded
    private LevelCriteriaDO levelCriteria;

    public WorkflowLevelDefinitionDO() {
    }

    public WorkflowLevelDefinitionDO(Integer levelId, 
            String name,
            String ownerRoleId) {
        this.name = name;
        this.levelId = levelId;
        this.ownerRoleId = ownerRoleId;
    }

    public Integer getLevelId() {
        return levelId;
    }

    public void setLevelId(Integer levelId) {
        this.levelId = levelId;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOwnerRoleId() {
        return ownerRoleId;
    }

    public void setOwnerRoleId(String ownerRoleId) {
        this.ownerRoleId = ownerRoleId;
    }

    public List<LevelDefinitionReviewDO> getLevelDefinitionReviews() {
        return levelDefinitionReviews;
    }

    public void setLevelDefinitionReviews(List<LevelDefinitionReviewDO> levelDefinitionReviews) {
        this.levelDefinitionReviews = levelDefinitionReviews;
    }

    public LevelCriteriaDO getLevelCriteria() {
        if (levelCriteria == null) {
            levelCriteria  = new LevelCriteriaDO();
        }
        return levelCriteria;
    }

    public void setLevelCriteria(LevelCriteriaDO nextLevelCriteria) {
        this.levelCriteria = nextLevelCriteria;
    }

    public RulesDO getRules() {
        if (rules == null) {
            rules = new RulesDO();
        }
        return rules;
    }

    public void setRules(RulesDO rules) {
        this.rules = rules;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        WorkflowLevelDefinitionDO that = (WorkflowLevelDefinitionDO) o;

        if (levelId != null
                && !levelId.equals(that.levelId))
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = levelId != null ? levelId.hashCode() : 0;
        result = 31 * result + (name != null ? name.hashCode() : 0);
        result = 31 * result + (userType != null ? userType.hashCode() : 0);
        result = 31 * result + (ownerRoleId != null ? ownerRoleId.hashCode() : 0);
        return result;
    }
}
