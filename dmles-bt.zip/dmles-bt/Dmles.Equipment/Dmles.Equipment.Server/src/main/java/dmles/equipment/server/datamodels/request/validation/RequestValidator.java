package dmles.equipment.server.datamodels.request.validation;

import dmles.equipment.core.datamodels.catalog.SuggestedSourceItem;
import dmles.equipment.server.datamodels.request.EquipmentRequestDO;
import dmles.equipment.server.datamodels.request.EquipmentRequestTypeDO;
import dmles.equipment.server.datamodels.request.ExtraItemDO;
import dmles.equipment.server.datamodels.request.ReplacementItemDO;
import dmles.equipment.server.datamodels.request.RequestInformationDO;
import dmles.equipment.server.datamodels.request.RequestedEquipmentDO;
import dmles.equipment.server.datamodels.request.TrainingItemDO;
import mil.jmlfdc.common.exception.ValidationException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class RequestValidator {
    private static final List<String> TYPE_CODES_VALIDATION = new ArrayList<>(Arrays.asList("N", "U", "A"));


    public void validate(EquipmentRequestDO request) throws ValidationException {
        List<String> errors = new ArrayList<>();
        RequestInformationDO rInfo = request.getRequestInformation();
        validateRequestInformation(rInfo, errors);

        if (errors.size() > 0) {
            String message = String.join("; ", errors);
            throw new ValidationException(message);
        }

    }

    private void validateRequestInformation(RequestInformationDO rInfo,
                                            List<String> errors) {

        if (rInfo == null) {
            errors.add("RequestInformation is required");
            return;
        }

        if (rInfo.getCriticalCode() == null) {
            errors.add("Request Information - Criticality Code required");
        }

        if (rInfo.getCustomer() == null) {
            errors.add("Request Information - Customer required");
        }

        if (rInfo.getMissionImpact() == null) {
            errors.add("Request Information - Mission Impact required");
        }

        if (rInfo.getOrganization() == null) {
            errors.add("Request Information - Organization required");
        }

        if (rInfo.getRequestNumber() == null) {
            errors.add("Request Information - Request Number required");
        }

        if (rInfo.getRequestReason() == null) {
            errors.add("Request Information - Request Reason required");
        }

        if (rInfo.getRequestTitle() == null) {
            errors.add("Request Information - Request Title required");
        }

        if (rInfo.getRequestType() == null) {
            errors.add("Request Information - Request Type required");
        }

        RequestedEquipmentDO equip = rInfo.getEquipment();
        validateEquipment(equip, errors);

        List<ExtraItemDO> extraItems = rInfo.getExtraItems();
        validateExtraItems(extraItems, errors);

        List<SuggestedSourceItem> suggestedSources = rInfo.getSuggestedSources();
        validateSuggestedSources(suggestedSources, errors);

        Integer quantity = rInfo.getQuantityRequested();
        if (quantity == null || quantity <= 0) {
            errors.add("Request Information - Quantity requested required");
        }

        validateRequestTypeCode(rInfo, errors);
        validateDelivery(rInfo, errors);

        List<TrainingItemDO> trainingItems = rInfo.getTraining();
        validateTraining(trainingItems, errors);
    }

    private void validateTraining(List<TrainingItemDO> trainingItems, List<String> errors) {

        for (TrainingItemDO item: trainingItems) {
            if (item.getTrainees() == null) {
                errors.add("Request Information - Training item trainees required");
            }
            Integer people = item.getPeople();
            if (people == null || people == 0) {
                errors.add("Request Information - Training item people required");
            }
            if (item.getPeople() == null) {
                errors.add("Request Information - Training item people required");
            }
        }
    }

    private void validateDelivery(RequestInformationDO rInfo, List<String> errors) {

        if (rInfo.getRequestedDeliveryDate() != null && rInfo.getRequestedDeliveryDateReason() == null) {
            errors.add("Request Information - delivery reason required");
        }

    }

    private void validateRequestTypeCode(RequestInformationDO rInfo, List<String> errors) {
        EquipmentRequestTypeDO type = rInfo.getRequestType();
        if (type != null && type.getCode() != null) {
            String code = type.getCode();
            List<ReplacementItemDO> replacedItems = rInfo.getReplacedItems();

            if (TYPE_CODES_VALIDATION.contains(code) && (replacedItems == null || replacedItems.isEmpty())){
                errors.add("Request Information - Type code is invalid");
            }
        }

    }

    private void validateSuggestedSources(List<SuggestedSourceItem> suggestedSources, List<String> errors) {
        boolean isValid = false;

        if (suggestedSources != null && !suggestedSources.isEmpty()) {
            for(SuggestedSourceItem ssi : suggestedSources) {
                if (ssi.getCreditCard() == null) {
                    errors.add("Request Information - Suggested Source credit card required");
                }
                if (ssi.getSourceName() == null) {
                    errors.add("Request Information - Suggested Source name required");
                }
                if (ssi.getSourceDivision() == null) {
                    errors.add("Request Information - Suggested Source division required");
                }
                if (ssi.getPocName() == null) {
                    errors.add("Request Information - Suggested Source POC name required");
                }
                if (ssi.getPocEmail() == null) {
                    errors.add("Request Information - Suggested Source POC email required");
                }
                if (ssi.getPocPhone1() == null) {
                    errors.add("Request Information - Suggested Source POC phone required");
                }
                if (ssi.getPrimarySource() != null && Boolean.TRUE.compareTo(ssi.getPrimarySource()) == 0 ) {
                    if (isValid) {
                        isValid = false;
                        // only one selected source
                        break;
                    } else {
                        isValid = true;
                    }
                }
            }
        }

        if (!isValid) {
            errors.add("Request Information - One Suggested Source must be primary ");
        }
    }

    private void validateExtraItems(List<ExtraItemDO> extraItems, List<String> errors) {

        for (ExtraItemDO item : extraItems) {
            if (item.getType() == null) {
                errors.add("Request Information - Extra item types are required");
                break;
            }
        }
    }

    private void validateEquipment(RequestedEquipmentDO equip, List<String> errors) {
        if (equip.getManufacturer() == null) {
            errors.add("Request Information - Equipment manufacturer required");
        }
        
        Float unitCost = equip.getUnitCost();
        if (unitCost == null) {
            errors.add("Request Information - Equipment Unit Cost required");
        }
        
        if(equip.getCatalogId() == null){
            if(equip.getDescription() == null){
                errors.add("Request Information - Equipment Description is required");
            }
        }
        
    }

}
