package dmles.equipment.server.datamodels.request;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.mongodb.morphia.annotations.Embedded;

public class SafetyInformationDO implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @Embedded
    private List<EnvironmentalConcernDO> environmentalConcerns = new ArrayList<>();    
    
    @Embedded
    private List<SafetyConcernDO> safetyConcerns = new ArrayList<>();

    public SafetyInformationDO() {
    }

    public List<EnvironmentalConcernDO> getEnvironmentalConcerns() {
        return environmentalConcerns;
    }

    public void setEnvironmentalConcerns(List<EnvironmentalConcernDO> environmentalConcerns) {
        this.environmentalConcerns = environmentalConcerns;
    }

    public List<SafetyConcernDO> getSafetyConcerns() {
        return safetyConcerns;
    }

    public void setSafetyConcerns(List<SafetyConcernDO> safetyConcerns) {
        this.safetyConcerns = safetyConcerns;
    }
    
}
