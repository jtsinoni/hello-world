package dmles.equipment.server.datamodels.request.workflow.definition;


public class LevelDefinitionWeighInDO {
    
    private String elementName;
    private String roleId;
    private String weighInDisplayName;

    public String getElementName() {
        return elementName;
    }

    public void setElementName(String elementName) {
        this.elementName = elementName;
    }

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    public String getWeighInDisplayName() {
        return weighInDisplayName;
    }
    
    public void setWeighInDisplayName(String weighInDisplayName) {
        this.weighInDisplayName = weighInDisplayName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        LevelDefinitionWeighInDO that = (LevelDefinitionWeighInDO) o;

        if (elementName != null ? !elementName.equals(that.elementName) : that.elementName != null)
            return false;
        if (roleId != null ? !roleId.equals(that.roleId) : that.roleId != null) return false;
        if (weighInDisplayName != null ? weighInDisplayName.equals(that.weighInDisplayName) : that.weighInDisplayName == null)
            return false;
        return true;
    }

    @Override
    public int hashCode() {
        int result = elementName != null ? elementName.hashCode() : 0;
        result = 31 * result + (roleId != null ? roleId.hashCode() : 0);
        result = 31 * result + (weighInDisplayName != null ? weighInDisplayName.hashCode() : 0);
        return result;
    }
}
