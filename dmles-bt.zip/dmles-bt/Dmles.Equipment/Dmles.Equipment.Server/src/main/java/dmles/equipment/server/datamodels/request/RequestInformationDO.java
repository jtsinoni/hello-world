package dmles.equipment.server.datamodels.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import dmles.equipment.core.datamodels.catalog.CatalogItem;
import dmles.equipment.server.datamodels.CustomerDO;
import dmles.equipment.server.datamodels.OrganizationDO;
import dmles.equipment.server.datamodels.PersonDO;
import org.mongodb.morphia.annotations.Embedded;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import mil.jmlfdc.common.constants.DateAndTime;

public class RequestInformationDO {

    private String criticalCode;
    private String description;
    private List<ExtraItemDO> extraItems = new ArrayList<>();
    private String missionImpact;
    private String missionImpactDoc;
    private String requestedDeliveryDateReason;
    private String requestedItemId;
    private String requestNumber;
    private String requestTitle;
    private Integer quantityRequested;
    private Float totalCompAccSupplies;
    private Float totalIncludedTrainingCost;
    private Float totalTDYCost;
    
    private List<AttachmentItemDO> attachments = new ArrayList<>(); // TODO: Will be embeded once used    
    
    @Embedded
    private CatalogItem catalogItem = new CatalogItem(); 
    @Embedded
    private CustomerDO customer;      
    @Embedded
    private RequestedEquipmentDO equipment = new RequestedEquipmentDO();    
    @Embedded
    private List<EquipmentRequirementDO> equipmentRequirements = new ArrayList<>();     
    @Embedded
    private List<NoteItemDO> notes = new ArrayList<>();    
    @Embedded
    private OrganizationDO organization;    
    @Embedded
    private List<ReplacementItemDO> replacedItems = new ArrayList<>();   
    @Embedded
    private PersonDO requestor = new PersonDO();    
    @Embedded
    private EquipmentRequestReasonDO requestReason;
    @Embedded
    private EquipmentRequestTypeDO requestType;
    @Embedded
    private SubmitterDO submitter = new SubmitterDO();     
    @Embedded
    private List<SuggestedSourceDO> suggestedSources = new ArrayList<>();     
    @Embedded
    private List<TrainingItemDO> training = new ArrayList<>();    
    
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateAndTime.DATE_TIME_PATTERN)
    private Date requestedDeliveryDate;    
   

    public List<AttachmentItemDO> getAttachments() {
        return attachments;
    }

    public void setAttachments(List<AttachmentItemDO> attachments) {
        this.attachments = attachments;
    }

    public CatalogItem getCatalogItem() {
        return catalogItem;
    }

    public void setCatalogItem(CatalogItem catalogItem) {
        this.catalogItem = catalogItem;
    }

    public String getCriticalCode() {
        return criticalCode;
    }

    public void setCriticalCode(String criticalCode) {
        this.criticalCode = criticalCode;
    }

    public SubmitterDO getSubmitter() {
        return submitter;
    }

    public void setSubmitter(SubmitterDO custodian) {
        this.submitter = custodian;
    }

    public CustomerDO getCustomer() {
        return customer;
    }

    public void setCustomer(CustomerDO customer) {
        this.customer = customer;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<ExtraItemDO> getExtraItems() {
        return extraItems;
    }

    public void setExtraItems(List<ExtraItemDO> extraItems) {
        this.extraItems = extraItems;
    }

    public String getMissionImpact() {
        return missionImpact;
    }

    public void setMissionImpact(String missionImpact) {
        this.missionImpact = missionImpact;
    }

    public String getMissionImpactDoc() {
        return missionImpactDoc;
    }

    public void setMissionImpactDoc(String missionImpactDoc) {
        this.missionImpactDoc = missionImpactDoc;
    }

    public List<NoteItemDO> getNotes() {
        return notes;
    }

    public void setNotes(List<NoteItemDO> notes) {
        this.notes = notes;
    }

    public OrganizationDO getOrganization() {
        return organization;
    }

    public void setOrganization(OrganizationDO organization) {
        this.organization = organization;
    }

    public List<ReplacementItemDO> getReplacedItems() {
        return replacedItems;
    }

    public void setReplacedItems(List<ReplacementItemDO> replacedItems) {
        this.replacedItems = replacedItems;
    }

    public Date getRequestedDeliveryDate() {
        return requestedDeliveryDate;
    }

    public void setRequestedDeliveryDate(Date requestedDeliveryDate) {
        this.requestedDeliveryDate = requestedDeliveryDate;
    }

    public String getRequestedDeliveryDateReason() {
        return requestedDeliveryDateReason;
    }

    public void setRequestedDeliveryDateReason(String requestedDeliveryDateReason) {
        this.requestedDeliveryDateReason = requestedDeliveryDateReason;
    }

    public PersonDO getRequestor() {
        return requestor;
    }

    public void setRequestor(PersonDO requestor) {
        this.requestor = requestor;
    }

    public String getRequestedItemId() {
        return requestedItemId;
    }

    public void setRequestedItemId(String requestedItemId) {
        this.requestedItemId = requestedItemId;
    }

    public String getRequestNumber() {
        return requestNumber;
    }

    public void setRequestNumber(String requestNumber) {
        this.requestNumber = requestNumber;
    }

    public String getRequestTitle() {
        return requestTitle;
    }

    public void setRequestTitle(String requestTitle) {
        this.requestTitle = requestTitle;
    }

    public EquipmentRequestReasonDO getRequestReason() {
        return requestReason;
    }

    public void setRequestReason(EquipmentRequestReasonDO requestReason) {
        this.requestReason = requestReason;
    }

    public EquipmentRequestTypeDO getRequestType() {
        return requestType;
    }

    public void setRequestType(EquipmentRequestTypeDO requestType) {
        this.requestType = requestType;
    }

    public List<SuggestedSourceDO> getSuggestedSources() {
        return suggestedSources;
    }

    public void setSuggestedSources(List<SuggestedSourceDO> suggestedSources) {
        this.suggestedSources = suggestedSources;
    }

    public Float getTotalCompAccSupplies() {
        return totalCompAccSupplies;
    }

    public void setTotalCompAccSupplies(Float totalCompAccSupplies) {
        this.totalCompAccSupplies = totalCompAccSupplies;
    }

    public Float getTotalIncludedTrainingCost() {
        return totalIncludedTrainingCost;
    }

    public void setTotalIncludedTrainingCost(Float totalIncludedTrainingCost) {
        this.totalIncludedTrainingCost = totalIncludedTrainingCost;
    }

    public Float getTotalTDYCost() {
        return totalTDYCost;
    }

    public void setTotalTDYCost(Float totalTDYCost) {
        this.totalTDYCost = totalTDYCost;
    }

    public List<TrainingItemDO> getTraining() {
        return training;
    }

    public void setTraining(List<TrainingItemDO> training) {
        this.training = training;
    }

    public RequestedEquipmentDO getEquipment() {
        return equipment;
    }

    public void setEquipment(RequestedEquipmentDO equipment) {
        this.equipment = equipment;
    }

    public List<EquipmentRequirementDO> getEquipmentRequirements() {
        return equipmentRequirements;
    }

    public void setEquipmentRequirements(List<EquipmentRequirementDO> equipmentRequirements) {
        this.equipmentRequirements = equipmentRequirements;
    }

    public Integer getQuantityRequested() {
        return quantityRequested;
    }

    public void setQuantityRequested(Integer quantityRequested) {
        this.quantityRequested = quantityRequested;
    }

}
