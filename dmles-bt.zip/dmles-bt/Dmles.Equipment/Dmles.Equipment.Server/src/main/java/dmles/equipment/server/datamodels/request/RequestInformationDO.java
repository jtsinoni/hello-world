package dmles.equipment.server.datamodels.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import dmles.equipment.core.datamodels.Customer;
import dmles.equipment.core.datamodels.Organization;
import dmles.equipment.core.datamodels.Person;
import dmles.equipment.core.datamodels.catalog.CatalogItem;
import dmles.equipment.core.datamodels.catalog.SuggestedSourceItem;
import org.mongodb.morphia.annotations.Embedded;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class RequestInformationDO {

    private List<AttachmentItemDO> attachments = new ArrayList<>(); // TODO: Item variables needed
    @Embedded
    private CatalogItem catalogItem = new CatalogItem();
    private String criticalCode;
    @Embedded
    private SubmitterDO submitter = new SubmitterDO();
    @Embedded
    private Customer customer;
    private String description;
    @Embedded
    private RequestedEquipmentDO equipment = new RequestedEquipmentDO();
    private List<ExtraItemDO> extraItems = new ArrayList<>();
    private String missionImpact;
    private String missionImpactDoc;
    @Embedded
    private List<NoteItemDO> notes = new ArrayList<>(); // TODO: Item variables needed
    @Embedded
    private Organization organization;
    @Embedded
    private List<ReplacementItemDO> replacedItems = new ArrayList<>();
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSX")
    private Date requestedDeliveryDate;
    private String requestedDeliveryDateReason;
    @Embedded
    private Person requester = new Person();
    private String requestedItemId;
    private String requestNumber;
    private String requestTitle;
    @Embedded
    private EquipmentRequestReasonDO requestReason;
    @Embedded
    private EquipmentRequestTypeDO requestType;
    @Embedded
    private List<SuggestedSourceItem> suggestedSources = new ArrayList<>();
    private Integer quantityRequested;

    private Float totalPrice;
    private Float totalCompAccSupplies;
    private Float totalTrainingCost;
    @Embedded
    private List<TrainingItemDO> training = new ArrayList<>();
    @Embedded
    private List<EquipmentRequirementDO> equipmentRequirements = new ArrayList<>();    

    public List<AttachmentItemDO> getAttachments() {
        return attachments;
    }

    public void setAttachments(List<AttachmentItemDO> attachments) {
        this.attachments = attachments;
    }

    public CatalogItem getCatalogItem() {
        return catalogItem;
    }

    public void setCatalogItem(CatalogItem catalogItem) {
        this.catalogItem = catalogItem;
    }

    public String getCriticalCode() {
        return criticalCode;
    }

    public void setCriticalCode(String criticalCode) {
        this.criticalCode = criticalCode;
    }

    public SubmitterDO getSubmitter() {
        return submitter;
    }

    public void setSubmitter(SubmitterDO custodian) {
        this.submitter = custodian;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<ExtraItemDO> getExtraItems() {
        return extraItems;
    }

    public void setExtraItems(List<ExtraItemDO> extraItems) {
        this.extraItems = extraItems;
    }

    public String getMissionImpact() {
        return missionImpact;
    }

    public void setMissionImpact(String missionImpact) {
        this.missionImpact = missionImpact;
    }

    public String getMissionImpactDoc() {
        return missionImpactDoc;
    }

    public void setMissionImpactDoc(String missionImpactDoc) {
        this.missionImpactDoc = missionImpactDoc;
    }

    public List<NoteItemDO> getNotes() {
        return notes;
    }

    public void setNotes(List<NoteItemDO> notes) {
        this.notes = notes;
    }

    public Organization getOrganization() {
        return organization;
    }

    public void setOrganization(Organization organization) {
        this.organization = organization;
    }

    public List<ReplacementItemDO> getReplacedItems() {
        return replacedItems;
    }

    public void setReplacedItems(List<ReplacementItemDO> replacedItems) {
        this.replacedItems = replacedItems;
    }

    public Date getRequestedDeliveryDate() {
        return requestedDeliveryDate;
    }

    public void setRequestedDeliveryDate(Date requestedDeliveryDate) {
        this.requestedDeliveryDate = requestedDeliveryDate;
    }

    public String getRequestedDeliveryDateReason() {
        return requestedDeliveryDateReason;
    }

    public void setRequestedDeliveryDateReason(String requestedDeliveryDateReason) {
        this.requestedDeliveryDateReason = requestedDeliveryDateReason;
    }

    public Person getRequester() {
        return requester;
    }

    public void setRequester(Person requester) {
        this.requester = requester;
    }

    public String getRequestedItemId() {
        return requestedItemId;
    }

    public void setRequestedItemId(String requestedItemId) {
        this.requestedItemId = requestedItemId;
    }

    public String getRequestNumber() {
        return requestNumber;
    }

    public void setRequestNumber(String requestNumber) {
        this.requestNumber = requestNumber;
    }

    public String getRequestTitle() {
        return requestTitle;
    }

    public void setRequestTitle(String requestTitle) {
        this.requestTitle = requestTitle;
    }

    public EquipmentRequestReasonDO getRequestReason() {
        return requestReason;
    }

    public void setRequestReason(EquipmentRequestReasonDO requestReason) {
        this.requestReason = requestReason;
    }

    public EquipmentRequestTypeDO getRequestType() {
        return requestType;
    }

    public void setRequestType(EquipmentRequestTypeDO requestType) {
        this.requestType = requestType;
    }

    public List<SuggestedSourceItem> getSuggestedSources() {
        return suggestedSources;
    }

    public void setSuggestedSources(List<SuggestedSourceItem> suggestedSources) {
        this.suggestedSources = suggestedSources;
    }

    public Float getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(Float totalPrice) {
        this.totalPrice = totalPrice;
    }

    public Float getTotalCompAccSupplies() {
        return totalCompAccSupplies;
    }

    public void setTotalCompAccSupplies(Float totalCompAccSupplies) {
        this.totalCompAccSupplies = totalCompAccSupplies;
    }

    public Float getTotalTrainingCost() {
        return totalTrainingCost;
    }

    public void setTotalTrainingCost(Float totalTrainingCost) {
        this.totalTrainingCost = totalTrainingCost;
    }

    public List<TrainingItemDO> getTraining() {
        return training;
    }

    public void setTraining(List<TrainingItemDO> training) {
        this.training = training;
    }

    public RequestedEquipmentDO getEquipment() {
        return equipment;
    }

    public void setEquipment(RequestedEquipmentDO equipment) {
        this.equipment = equipment;
    }

    public List<EquipmentRequirementDO> getEquipmentRequirements() {
        return equipmentRequirements;
    }

    public void setEquipmentRequirements(List<EquipmentRequirementDO> equipmentRequirements) {
        this.equipmentRequirements = equipmentRequirements;
    }

    public Integer getQuantityRequested() {
        return quantityRequested;
    }

    public void setQuantityRequested(Integer quantityRequested) {
        this.quantityRequested = quantityRequested;
    }

}
