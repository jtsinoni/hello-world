package dmles.equipment.server.datamodels.request;

import java.io.Serializable;

public class EquipmentRequirementDO implements Serializable  {
    private static final long serialVersionUID = 1L;
    private String category; 
    private String requirement;
    private String specification;

    public EquipmentRequirementDO() {
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getRequirement() {
        return requirement;
    }

    public void setRequirement(String requirement) {
        this.requirement = requirement;
    }

    public String getSpecification() {
        return specification;
    }

    public void setSpecification(String specification) {
        this.specification = specification;
    }
    
}
