package dmles.equipment.server.datamodels.request;

import java.io.Serializable;

public class AttachmentItemDO implements Serializable {
    private static final long serialVersionUID = 1L; 

    // TODO: Add note class instance variables
    
    public AttachmentItemDO() {
    }
    
}
