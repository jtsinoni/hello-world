package dmles.equipment.server.datamodels.request;

import java.io.Serializable;
import mil.jmlfdc.common.datamodel.MorphiaEntity;
import org.mongodb.morphia.annotations.Entity;

@Entity("LiteratureType")
public class LiteratureTypeDO extends MorphiaEntity implements Serializable {
    private static final long serialVersionUID = 1L;
    private String literatureTypeCd;
    private String literatureTypeTx;

    public String getLiteratureTypeCd() {
        return literatureTypeCd;
    }

    public void setLiteratureTypeCd(String literatureTypeCd) {
        this.literatureTypeCd = literatureTypeCd;
    }

    public String getLiteratureTypeTx() {
        return literatureTypeTx;
    }

    public void setLiteratureTypeTx(String literatureTypeTx) {
        this.literatureTypeTx = literatureTypeTx;
    }
    
    
}
