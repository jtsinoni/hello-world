package dmles.equipment.server.utils;

import dmles.equipment.server.datamodels.request.EquipmentRequestDO;

public class RequestExtension {

    private EquipmentRequestDO erDo;

    public RequestExtension(EquipmentRequestDO erDo) {
        this.erDo = erDo;
    }

    public Double getTotalCostAsDouble() {
        Float totalRequisitionCost = erDo.getTotalRequisitionCost();
        Double totalRequisitionCostDouble = null;

        if (totalRequisitionCost != null) {
            totalRequisitionCostDouble = new Double(totalRequisitionCost);
        }
        return totalRequisitionCostDouble;
    }

    public boolean meetsCostCriteria(Double cost, Double costCriteria){
        boolean meets = false;
        if (cost != null && costCriteria != null) {
            if (cost >= costCriteria) {
                meets = true;
            }
        }
        return meets;
    }


}
