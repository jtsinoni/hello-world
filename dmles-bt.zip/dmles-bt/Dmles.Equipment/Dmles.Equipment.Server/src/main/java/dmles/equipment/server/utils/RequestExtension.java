package dmles.equipment.server.utils;

import dmles.equipment.server.datamodels.request.EquipmentRequestDO;

public class RequestExtension {

    private EquipmentRequestDO erDo;

    public RequestExtension(EquipmentRequestDO erDo) {
        this.erDo = erDo;
    }

    public Double getTotalCostAsDouble() {
        Float totalPrice = erDo.getTotalPrice();
        Double totalPriceDouble = null;

        if (totalPrice != null) {
            totalPriceDouble = new Double(totalPrice);
        }
        return totalPriceDouble;
    }

    public boolean meetsCostCriteria(Double cost, Double costCriteria){
        boolean meets = false;
        if (cost != null && costCriteria != null) {
            if (cost >= costCriteria) {
                meets = true;
            }
        }
        return meets;
    }


}
