package dmles.equipment.server.business;

import dmles.equipment.core.datamodels.mtf.MtfSite;

public class MtfSites {
    public static MtfSite Bamc = new MtfSite("BAMC Http", "https://jw8cui02");
}
