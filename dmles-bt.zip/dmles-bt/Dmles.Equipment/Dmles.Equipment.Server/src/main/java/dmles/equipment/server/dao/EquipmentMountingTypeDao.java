/*
    // ==========================================================================
    //       NOTICE:  THIS SOFTWARE WAS DEVELOPED UNDER CONTRACT
    //        TO THE U.S. GOVERNMENT, WHICH RESERVES ALL SOURCE
    //             RIGHTS AND FULL TECHNICAL DATA RIGHTS.
    // ==========================================================================
    //
 */

package dmles.equipment.server.dao;

import javax.enterprise.context.Dependent;
import mil.jmlfdc.common.dao.BaseDao;
import dmles.equipment.server.datamodels.request.EquipmentMountingTypeDO;

@Dependent
public class EquipmentMountingTypeDao extends BaseDao<EquipmentMountingTypeDO, String> {
    
    public EquipmentMountingTypeDao(){
        super(EquipmentMountingTypeDO.class);
    }
    
}