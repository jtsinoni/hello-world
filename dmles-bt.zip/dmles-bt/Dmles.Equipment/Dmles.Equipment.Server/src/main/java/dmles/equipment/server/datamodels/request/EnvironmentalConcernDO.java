package dmles.equipment.server.datamodels.request;

import java.io.Serializable;

public class EnvironmentalConcernDO implements Serializable {
    private static final long serialVersionUID = 1L;   
    
    private String name;
    private Boolean generates;
    private Boolean uses;
    private Boolean na;
    private String comments;

    public EnvironmentalConcernDO() {
    }

    public EnvironmentalConcernDO(String name, Boolean generates, Boolean uses, Boolean na, String comments) {
        this.name = name;
        this.generates = generates;
        this.uses = uses;
        this.na = na;
        this.comments = comments;
    }
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Boolean getGenerates() {
        return generates;
    }

    public void setGenerates(Boolean generates) {
        this.generates = generates;
    }

    public Boolean getUses() {
        return uses;
    }

    public void setUses(Boolean uses) {
        this.uses = uses;
    }

    public Boolean getNa() {
        return na;
    }

    public void setNa(Boolean na) {
        this.na = na;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }
    
}
