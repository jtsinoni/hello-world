package dmles.equipment.server.datamodels.request;

import java.io.Serializable;

public class LiteratureDO implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private String type;
    private Float cost;
    private Integer quantity;
    private Float totalCost;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Float getCost() {
        return cost;
    }

    public void setCost(Float cost) {
        this.cost = cost;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Float getTotalCost() {
        return totalCost;
    }

    public void setTotalCost(Float totalCost) {
        this.totalCost = totalCost;
    }
    
}
