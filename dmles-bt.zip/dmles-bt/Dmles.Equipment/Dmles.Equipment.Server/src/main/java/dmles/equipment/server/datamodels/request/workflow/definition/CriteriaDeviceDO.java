package dmles.equipment.server.datamodels.request.workflow.definition;

public class CriteriaDeviceDO {

    private String deviceCode;
    private String deviceName;

    public String getDeviceCode() {
        return deviceCode;
    }

    public void setDeviceCode(String deviceCode) {
        this.deviceCode = deviceCode;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        CriteriaDeviceDO that = (CriteriaDeviceDO) o;

        if (!(deviceCode == null && that.deviceCode == null) ||
                deviceCode != null && !deviceCode.equals(that.deviceCode))
            return false;
        if (!(deviceName == null && that.deviceName == null) ||
                (deviceName != null && deviceName.equals(that.deviceName)))
            return false;
        return true;
    }

    @Override
    public int hashCode() {
        int result = deviceCode != null ? deviceCode.hashCode() : 0;
        result = 31 * result + (deviceName != null ? deviceName.hashCode() : 0);
        return result;
    }

}
