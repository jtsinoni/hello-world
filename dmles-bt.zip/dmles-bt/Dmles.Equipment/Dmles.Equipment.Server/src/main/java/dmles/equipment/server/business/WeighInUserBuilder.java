package dmles.equipment.server.business;

import dmles.equipment.server.datamodels.request.workflow.definition.LevelDefinitionWeighInDO;
import dmles.equipment.server.datamodels.request.workflow.definition.WorkflowLevelDefinitionDO;
import dmles.equipment.server.datamodels.request.workflow.process.WeighInDO;
import dmles.equipment.server.datamodels.request.workflow.process.WeighInUserDO;
import dmles.equipment.server.datamodels.request.workflow.process.WorkflowLevelProcessingDO;
import dmles.equipment.server.datamodels.request.workflow.process.WorkflowProcessingDO;
import dmles.user.client.UserService;
import dmles.user.core.IUserService;
import dmles.user.core.clientmodel.CurrentUserBasicPT;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import mil.jmlfdc.common.exception.ObjectNotFoundException;
import mil.jmlfdc.common.utils.ObjectMapper;

@Stateless
public class WeighInUserBuilder {
    
    @Inject
    @UserService
    private IUserService userService;

    @Inject
    private ObjectMapper objectMapper;

    public void buildWeighInUsers(WorkflowProcessingDO wfpDO) throws ObjectNotFoundException {

        int currentLevelId = wfpDO.getCurrentLevel().getLevelId();
        WorkflowLevelProcessingDO currentLevel = wfpDO.getCurrentLevel();
        WorkflowLevelDefinitionDO levelDefinition = wfpDO.getWfDefinition().getLevelDefinitions().get(currentLevelId);

        Map<String, List<CurrentUserBasicPT>> userElementMap = new HashMap<>();
        List<LevelDefinitionWeighInDO> weighInLefinitionElementsList = levelDefinition.getLevelDefinitionWeighIns();

        List<String> definitionRolesList = getRoles(weighInLefinitionElementsList);
        
        String userType = levelDefinition.getUserType();
        String[] rolesArray = definitionRolesList.toArray(new String[definitionRolesList.size()]);    
        
        userElementMap = userService.getUsersForRoles(userType, rolesArray);
        List<WeighInDO> weighIns = currentLevel.getWeighIns();
        
        userElementMap.forEach((roleId, userList) -> {
            for (WeighInDO weighInDO : weighIns) {
                if(weighInDO.getRoleId().equals(roleId)){
                    List<WeighInUserDO> weighInUsersDO = objectMapper.getList(WeighInUserDO[].class, userList);
                    weighInDO.setWeighInUsersDO(weighInUsersDO);
                }
            }
            }
        );
        
    }
    
    private List<String> getRoles(List<LevelDefinitionWeighInDO> list) {
        List<String> roleList = new ArrayList<>();
        for (LevelDefinitionWeighInDO item: list) {
            roleList.add(item.getRoleId());
        }
        return roleList;
    }
}
