package dmles.equipment.server.datamodels.request;

import java.io.Serializable;
import mil.jmlfdc.common.datamodel.MorphiaEntity;
import org.mongodb.morphia.annotations.Entity;

@Entity("EquipManufacturer")
public class EquipmentManufacturerDO extends MorphiaEntity implements Serializable {
    private static final long serialVersionUID = 1L;
    private Boolean deleteInd;
    private String organizationNm;

    public Boolean getDeleteInd() {
        return deleteInd;
    }

    public void setDeleteInd(Boolean deleteInd) {
        this.deleteInd = deleteInd;
    }

    public String getOrganizationNm() {
        return organizationNm;
    }

    public void setOrganizationNm(String organizationNm) {
        this.organizationNm = organizationNm;
    }
}
