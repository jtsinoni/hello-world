package dmles.equipment.server.datamodels.request;

import java.io.Serializable;
import mil.jmlfdc.common.datamodel.MorphiaEntity;
import org.mongodb.morphia.annotations.Entity;

@Entity("TraineeLocationType")
public class TraineeLocationTypeDO extends MorphiaEntity implements Serializable {
    private static final long serialVersionUID = 1L;
    private String trainingLocationTypeCd;
    private String trainingLocationTypeTx;

    public String getTrainingLocationTypeCd() {
        return trainingLocationTypeCd;
    }

    public void setTrainingLocationTypeCd(String trainingLocationTypeCd) {
        this.trainingLocationTypeCd = trainingLocationTypeCd;
    }

    public String getTrainingLocationTypeTx() {
        return trainingLocationTypeTx;
    }

    public void setTrainingLocationTypeTx(String trainingLocationTypeTx) {
        this.trainingLocationTypeTx = trainingLocationTypeTx;
    }
    
    
}
