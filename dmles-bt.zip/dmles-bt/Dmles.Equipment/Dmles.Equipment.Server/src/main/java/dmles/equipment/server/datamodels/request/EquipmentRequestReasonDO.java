package dmles.equipment.server.datamodels.request;

import mil.jmlfdc.common.datamodel.MorphiaEntity;
import org.mongodb.morphia.annotations.Entity;

@Entity("EquipRequestReason")
public class EquipmentRequestReasonDO extends MorphiaEntity {

    private String code;
    private String mask;
    private String name;

    public String getCode() {
        return code;
    }

    public String getMask() {
        return mask;
    }

    public String getName() {
        return name;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public void setMask(String mask) {
        this.mask = mask;
    }

    public void setName(String name) {
        this.name = name;
    }

}
