package dmles.equipment.server.business;

import dmles.equipment.server.dao.EquipmentRequestDao;
import dmles.equipment.server.datamodels.request.EquipmentRequestDO;
import mil.jmlfdc.common.datamodel.CurrentUserBT;
import mil.jmlfdc.common.datamodel.UserType;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import javax.inject.Inject;

@Stateless
public class EquipmentRequestFetcher {

    @Inject
    private CurrentUserBT user;

    @Inject
    private EquipmentRequestDao requestDao;

    public List<EquipmentRequestDO> getRequestsPerUserType() {

        List<EquipmentRequestDO> listDo;
        UserType type = UserType.valueOf(user.getUserType().toString());
        switch (type) {
            case GLOBAL:
                listDo = requestDao.findAll();
                break;
            case SERVICE:
                listDo = requestDao.findByService(user.getServiceCode());
                break;
            case SERVICEREGION:
                listDo = requestDao.findByServiceAndRegion(user.getServiceCode(), user.getRegionCode());
                break;
            case SITE:
                listDo = requestDao.findBySite(user.getDodaac());
                break;
            default:
                listDo = new ArrayList<>();
        }

        return listDo;

    }

}
