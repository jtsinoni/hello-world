package dmles.equipment.server.datamodels.request.workflow.definition;


public class LevelDefinitionWeighIn {
    
    private String elementName;
    private String roleId;
    private String weighInDisplayName;

    public String getElementName() {
        return elementName;
    }

    public void setElementName(String elementName) {
        this.elementName = elementName;
    }

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    public String getWeighInDisplayName() {
        return weighInDisplayName;
    }
    
    public void setWeighInDisplayName(String weighInDisplayName) {
        this.weighInDisplayName = weighInDisplayName;
    }
    
}
