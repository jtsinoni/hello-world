package dmles.equipment.server.datamodels.record;

import org.mongodb.morphia.annotations.Embedded;

import java.io.Serializable;

@Embedded
public class MaintenanceTypeDO implements Serializable {
    private static final long serialVersionUID = 1L;
    private Integer ME_ID;
    private Integer miTypeCode;
    private String mdDueDt;
    private String mdLastSvcDt;
    private String miTypeDescText;
    private Integer mpId;
    private Integer miInuseMonthQty;
    private Integer miMobltyMnthQty;
    private Integer miStoredMnthQty;
    private Integer meId;
    private String operationalStatus;

    public Integer getME_ID() {
        return ME_ID;
    }

    public void setME_ID(Integer ME_ID) {
        this.ME_ID = ME_ID;
    }

    public Integer getMiTypeCode() {
        return miTypeCode;
    }

    public void setMiTypeCode(Integer miTypeCode) {
        this.miTypeCode = miTypeCode;
    }

    public String getMdDueDt() {
        return mdDueDt;
    }

    public void setMdDueDt(String mdDueDt) {
        this.mdDueDt = mdDueDt;
    }

    public String getMdLastSvcDt() {
        return mdLastSvcDt;
    }

    public void setMdLastSvcDt(String mdLastSvcDt) {
        this.mdLastSvcDt = mdLastSvcDt;
    }

    public String getMiTypeDescText() {
        return miTypeDescText;
    }

    public void setMiTypeDescText(String miTypeDescText) {
        this.miTypeDescText = miTypeDescText;
    }

    public Integer getMpId() {
        return mpId;
    }

    public void setMpId(Integer mpId) {
        this.mpId = mpId;
    }

    public Integer getMiInuseMonthQty() {
        return miInuseMonthQty;
    }

    public void setMiInuseMonthQty(Integer miInuseMonthQty) {
        this.miInuseMonthQty = miInuseMonthQty;
    }

    public Integer getMiMobltyMnthQty() {
        return miMobltyMnthQty;
    }

    public void setMiMobltyMnthQty(Integer miMobltyMnthQty) {
        this.miMobltyMnthQty = miMobltyMnthQty;
    }

    public Integer getMiStoredMnthQty() {
        return miStoredMnthQty;
    }

    public void setMiStoredMnthQty(Integer miStoredMnthQty) {
        this.miStoredMnthQty = miStoredMnthQty;
    }

    public Integer getMeId() {
        return meId;
    }

    public void setMeId(Integer meId) {
        this.meId = meId;
    }

    public String getOperationalStatus() {
        return operationalStatus;
    }

    public void setOperationalStatus(String operationalStatus) {
        this.operationalStatus = operationalStatus;
    }
}