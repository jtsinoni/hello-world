/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dmles.equipment.server.business;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;

/**
 *
 * @author thomas.schaffer
 */
public class DmlesHostnameVerifier implements HostnameVerifier{

    @Override
    public boolean verify(String string, SSLSession ssls) {
        System.out.println("In DmlesHostnameVerify...");
        System.out.println(string);
        return true;
    }
    
}
