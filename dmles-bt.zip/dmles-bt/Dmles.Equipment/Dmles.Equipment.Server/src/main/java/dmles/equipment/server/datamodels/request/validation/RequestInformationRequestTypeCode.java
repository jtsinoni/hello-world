package dmles.equipment.server.datamodels.request.validation;


import static java.lang.annotation.ElementType.ANNOTATION_TYPE;
import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import javax.validation.Constraint;
import javax.validation.Payload;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

@Target( {ANNOTATION_TYPE, TYPE} )
@Retention(RUNTIME)
@Constraint(validatedBy = RequestInformationRequestTypeCodeValidator.class)
@Documented
public @interface RequestInformationRequestTypeCode {

    String message() default "Request Type N, U, A require replaced items";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

}
