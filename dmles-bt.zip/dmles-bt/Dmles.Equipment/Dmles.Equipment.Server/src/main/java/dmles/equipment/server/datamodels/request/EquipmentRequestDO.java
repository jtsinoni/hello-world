package dmles.equipment.server.datamodels.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import dmles.equipment.core.datamodels.catalog.CatalogItem;
import dmles.equipment.server.datamodels.request.workflow.process.WorkflowProcessingDO;
import mil.jmlfdc.common.datamodel.MorphiaEntity;
import mil.jmlfdc.common.utils.StringUtil;
import org.mongodb.morphia.annotations.Embedded;
import org.mongodb.morphia.annotations.Entity;
import org.mongodb.morphia.annotations.Reference;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import mil.jmlfdc.common.constants.DateAndTime;

@Entity("EquipmentRequest")
public class EquipmentRequestDO extends MorphiaEntity {
    
    private Boolean itemIdProvided;
    
    private String updatedBy;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateAndTime.DATE_TIME_PATTERN)
    private Date updatedDate;
    private Float totalOtherCost;
    private Float totalRequisitionCost;
    private List<AttachmentItemDO> attachments = new ArrayList<>(); // TODO: Item variables needed
    @Embedded
    private CatalogItem catalogItem = new CatalogItem();
    @Embedded
    private RequestInformationDO requestInformation;
    @Embedded
    private FacilityInformationDO facilityInformation = new FacilityInformationDO();
    @Embedded
    private SafetyInformationDO safetyInformation = new SafetyInformationDO();
    @Embedded
    private MaintenanceInformationDO maintenanceInformation;
    @Embedded
    private TechnologyInformationDO technologyInformation = new TechnologyInformationDO();
    @Reference
    private WorkflowProcessingDO wfProcessing;
    @Embedded
    private List<NoteItemDO> notes = new ArrayList<>(); // TODO: Item variables needed

    public EquipmentRequestDO() {
    }

    public Boolean getItemIdProvided() {
        return itemIdProvided;
    }

    public void setItemIdProvided(Boolean itemIdProvided) {
        this.itemIdProvided = itemIdProvided;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public boolean isProcessing() {
        boolean val = false;
        if(null != wfProcessing && !StringUtil.isEmptyOrNull(wfProcessing.getId())){
            val = true;
        }
        return val;
    }

    public List<AttachmentItemDO> getAttachments() {
        return attachments;
    }

    public void setAttachments(List<AttachmentItemDO> attachments) {
        this.attachments = attachments;
    }


    public CatalogItem getCatalogItem() {
        return catalogItem;
    }

    public void setCatalogItem(CatalogItem catalogItem) {
        this.catalogItem = catalogItem;
    }

    public RequestInformationDO getRequestInformation() {
        return requestInformation;
    }

    public void setRequestInformation(RequestInformationDO requestInformation) {
        this.requestInformation = requestInformation;
    }

    public FacilityInformationDO getFacilityInformation() {
        return facilityInformation;
    }

    public void setFacilityInformation(FacilityInformationDO facilityInformation) {
        this.facilityInformation = facilityInformation;
    }

    public SafetyInformationDO getSafetyInformation() {
        return safetyInformation;
    }

    public void setSafetyInformation(SafetyInformationDO safetyInformation) {
        this.safetyInformation = safetyInformation;
    }

    public MaintenanceInformationDO getMaintenanceInformation() {
        return maintenanceInformation;
    }

    public void setMaintenanceInformation(MaintenanceInformationDO maintenanceInformation) {
        this.maintenanceInformation = maintenanceInformation;
    }

    public TechnologyInformationDO getTechnologyInformation() {
        return technologyInformation;
    }

    public void setTechnologyInformation(TechnologyInformationDO technologyInformation) {
        this.technologyInformation = technologyInformation;
    }

    public WorkflowProcessingDO getWfProcessing() {
        return wfProcessing;
    }

    public void setWfProcessing(WorkflowProcessingDO wfProcessing) {
        this.wfProcessing = wfProcessing;
    }

    public Float getTotalOtherCost() {return totalOtherCost;}

    public void setTotalOtherCost(Float totalOtherCost) {this.totalOtherCost = totalOtherCost;}

    public Float getTotalRequisitionCost() {
        return totalRequisitionCost;
    }

    public void setTotalRequisitionCost(Float totalRequisitionCost) {
        this.totalRequisitionCost = totalRequisitionCost;
    }

    public List<NoteItemDO> getNotes() {
        return notes;
    }

    public void setNotes(List<NoteItemDO> notes) {
        this.notes = notes;
    }

}
