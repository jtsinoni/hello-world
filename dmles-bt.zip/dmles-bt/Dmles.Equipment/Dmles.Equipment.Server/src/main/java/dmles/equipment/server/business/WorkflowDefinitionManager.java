package dmles.equipment.server.business;

import dmles.equipment.core.datamodels.request.workflow.definition.LevelCriteria;
import dmles.equipment.core.datamodels.request.workflow.definition.WorkflowDefinition;
import dmles.equipment.server.dao.EquipmentRequestDao;
import dmles.equipment.server.dao.WorkflowDefinitionDao;
import dmles.equipment.server.datamodels.request.workflow.definition.CriteriaCatalogItemDO;
import dmles.equipment.server.datamodels.request.workflow.definition.CriteriaDeviceDO;
import dmles.equipment.server.datamodels.request.workflow.definition.LevelCriteriaDO;
import dmles.equipment.server.datamodels.request.workflow.definition.WorkflowDefinitionDO;
import dmles.equipment.server.datamodels.request.workflow.definition.WorkflowLevelDefinitionDO;
import dmles.oauth.core.datamodel.CurrentUserBT;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.validation.constraints.NotNull;
import mil.jmlfdc.common.business.BusinessManager;
import mil.jmlfdc.common.exception.ObjectNotFoundException;
import mil.jmlfdc.common.utils.ListUtil;
import mil.jmlfdc.common.utils.ObjectMapper;
import mil.jmlfdc.common.utils.StringUtil;
import org.slf4j.Logger;

@Stateless
public class WorkflowDefinitionManager extends BusinessManager {

    @Inject
    private Logger logger;

    @Inject
    private CurrentUserBT currentUserBt;

    @Inject
    private ObjectMapper objectMapper;

    @Inject
    private StringUtil stringUtil;

    @Inject
    private WorkflowDefinitionDao wfDefinitionDao;

    @Inject
    private ListUtil listUtil;


    // TODO: Could be broken out to update the major and epic sections of the
    // version number (###.###.###)
    // TODO: May want to move this to common.
    private String updateMinorVersion(String currentVersion) {
        String[] versionSectionsArray = currentVersion.split("\\.");
        List<String> versionSectionsList = Arrays.asList(versionSectionsArray);
        String minorSectionS = versionSectionsList.get(2);
        Integer minorSectionI = stringUtil.convertstringToInteger(minorSectionS);
        minorSectionI = minorSectionI + 1;
        versionSectionsList.set(2, minorSectionI.toString());
        String result = String.join(".", versionSectionsList);
        return result;
    }

    private void updateWorkflow(WorkflowDefinitionDO wfDefDo) {
        wfDefDo.setDateUpdated(new Date());
        wfDefDo.setVersion(updateMinorVersion(wfDefDo.getVersion()));
        wfDefDo.setUpdatedBy(currentUserBt.getPkiDn());
        wfDefinitionDao.upsert(wfDefDo);
    }

    // Workflow Definition
    public WorkflowDefinition createWorkflowDefinition(@NotNull WorkflowDefinition wfd) throws ObjectNotFoundException {
        WorkflowDefinitionDO wfdDo = objectMapper.getObject(WorkflowDefinitionDO.class, wfd);
        wfDefinitionDao.upsert(wfdDo);
        WorkflowDefinitionDO returnWfd = new WorkflowDefinitionDO();
        if (!StringUtil.isEmptyOrNull(wfdDo.getId())) {
            returnWfd = wfDefinitionDao.findById(wfdDo.getId());
        }
        return objectMapper.getObject(WorkflowDefinition.class, returnWfd);
    }

    public WorkflowDefinition getWorkflowDefinition(@NotNull String serviceName) throws ObjectNotFoundException {
        WorkflowDefinitionDO wfDefDo = wfDefinitionDao.findByServiceName(serviceName);
        return objectMapper.getObject(WorkflowDefinition.class, wfDefDo);
    }

    // Level Criteria
    public WorkflowDefinition addCatalogCriteria(@NotNull String serviceName,
            @NotNull String levelID,
            @NotNull String catalogID,
            @NotNull String catalogName) {
        WorkflowDefinitionDO wfDefDo = wfDefinitionDao.findByServiceName(serviceName);

        WorkflowLevelDefinitionDO levelDef = wfDefDo.getLevelDefinition(stringUtil.convertstringToInteger(levelID));
        List<CriteriaCatalogItemDO> catCriteriaList = levelDef.getLevelCriteria().getCatalogItems();
        CriteriaCatalogItemDO newCatCriteria = new CriteriaCatalogItemDO();
        newCatCriteria.setCatalogID(catalogID);
        newCatCriteria.setCatalogName(catalogName);
        catCriteriaList.add(newCatCriteria);
        levelDef.getLevelCriteria().setCatalogItems(catCriteriaList);

        updateWorkflow(wfDefDo);
        WorkflowDefinitionDO wfDefDoOut = wfDefinitionDao.findByServiceName(serviceName);
        return objectMapper.getObject(WorkflowDefinition.class, wfDefDoOut);
    }

    public WorkflowDefinition addDeviceCriteria(@NotNull String serviceName,
            @NotNull String levelID,
            @NotNull String deviceCode,
            @NotNull String deviceName) {
        WorkflowDefinitionDO wfDefDo = wfDefinitionDao.findByServiceName(serviceName);

        WorkflowLevelDefinitionDO levelDef = wfDefDo.getLevelDefinition(stringUtil.convertstringToInteger(levelID));
        List<CriteriaDeviceDO> deviceCriteriaList = levelDef.getLevelCriteria().getDevices();
        CriteriaDeviceDO newDeviceCriteria = new CriteriaDeviceDO();
        newDeviceCriteria.setDeviceCode(deviceCode);
        newDeviceCriteria.setDeviceName(deviceName);
        deviceCriteriaList.add(newDeviceCriteria);
        levelDef.getLevelCriteria().setDevices(deviceCriteriaList);

        updateWorkflow(wfDefDo);
        WorkflowDefinitionDO wfDefDoOut = wfDefinitionDao.findByServiceName(serviceName);
        return objectMapper.getObject(WorkflowDefinition.class, wfDefDoOut);
    }

    public LevelCriteria getCriteria(@NotNull String serviceName,
                                     @NotNull String levelID) {
        WorkflowDefinitionDO wfDefDo = wfDefinitionDao.findByServiceName(serviceName);

        WorkflowLevelDefinitionDO levelDef = wfDefDo.getLevelDefinition(stringUtil.convertstringToInteger(levelID));
        LevelCriteriaDO criteriaDO = levelDef.getLevelCriteria();
        return objectMapper.getObject(LevelCriteria.class, criteriaDO);
    }

    public WorkflowDefinition removeCatalogCriteria(@NotNull String serviceName,
            @NotNull String levelID,
            @NotNull String catalogID) {
        WorkflowDefinitionDO wfDefDo = wfDefinitionDao.findByServiceName(serviceName);

        WorkflowLevelDefinitionDO levelDef = wfDefDo.getLevelDefinition(stringUtil.convertstringToInteger(levelID));
        List<CriteriaCatalogItemDO> catCriteriaList = levelDef.getLevelCriteria().getCatalogItems();
        List<CriteriaCatalogItemDO> returnCatCriteriaList = new ArrayList<>(catCriteriaList);

        for (int i = 0; i < catCriteriaList.size(); i++) {
            CriteriaCatalogItemDO catalog = catCriteriaList.get(i);
            String reqCatalogIDLower = catalogID.toLowerCase();
            String currCatalogIDLower = catalog.getCatalogID().toLowerCase();
            if (currCatalogIDLower.equals(reqCatalogIDLower)) {
                int objIndex = returnCatCriteriaList.indexOf(catalog);
                returnCatCriteriaList.remove(objIndex);
            }
        }

        levelDef.getLevelCriteria().setCatalogItems(returnCatCriteriaList);
        updateWorkflow(wfDefDo);
        WorkflowDefinitionDO wfDefDoOut = wfDefinitionDao.findByServiceName(serviceName);
        return objectMapper.getObject(WorkflowDefinition.class, wfDefDoOut);
    }

    public WorkflowDefinition removeDeviceCriteria(@NotNull String serviceName,
            @NotNull String levelID,
            @NotNull String deviceCode) {
        WorkflowDefinitionDO wfDefDo = wfDefinitionDao.findByServiceName(serviceName);

        WorkflowLevelDefinitionDO levelDef = wfDefDo.getLevelDefinition(stringUtil.convertstringToInteger(levelID));
        List<CriteriaDeviceDO> deviceCriteriaList = levelDef.getLevelCriteria().getDevices();
        List<CriteriaDeviceDO> returnDeviceCriteriaList = new ArrayList<>(deviceCriteriaList);

        for (int i = 0; i < deviceCriteriaList.size(); i++) {
            CriteriaDeviceDO device = deviceCriteriaList.get(i);
            String reqDeviceLower = deviceCode.toLowerCase();
            String currDeviceLower = device.getDeviceCode().toLowerCase();
            if (currDeviceLower.equals(reqDeviceLower)) {
                int objIndex = returnDeviceCriteriaList.indexOf(device);
                returnDeviceCriteriaList.remove(objIndex);
            }
        }

        levelDef.getLevelCriteria().setDevices(returnDeviceCriteriaList);
        updateWorkflow(wfDefDo);
        WorkflowDefinitionDO wfDefDoOut = wfDefinitionDao.findByServiceName(serviceName);
        return objectMapper.getObject(WorkflowDefinition.class, wfDefDoOut);
    }

    public WorkflowDefinition updateCostCriteria(@NotNull String serviceName,
            @NotNull String levelID,
            String totalCost) {
        WorkflowDefinitionDO wfDefDo = wfDefinitionDao.findByServiceName(serviceName);

        WorkflowLevelDefinitionDO levelDef = wfDefDo.getLevelDefinition(stringUtil.convertstringToInteger(levelID));
        if (StringUtil.isEmptyOrNull(totalCost)) {
            logger.warn("Service: {}, Level: {}, removing total cost", serviceName, levelID);
            levelDef.getLevelCriteria().setTotalCostThreshold(null);
        } else {
            levelDef.getLevelCriteria().setTotalCostThreshold(new Float(totalCost));
        }

        updateWorkflow(wfDefDo);
        WorkflowDefinitionDO wfDefDoOut = wfDefinitionDao.findByServiceName(serviceName);
        return objectMapper.getObject(WorkflowDefinition.class, wfDefDoOut);
    }

    @Override
    public String getRequestorId() {
        return currentUserBt.getProfileId();
    }

    @Override
    public String getRequestorName() {
        return currentUserBt.getFullName();
    }

    public WorkflowDefinition saveWorkflowDefinition(WorkflowDefinition workflowDefinition) {
        WorkflowDefinitionDO fromApi = objectMapper.getObject(WorkflowDefinitionDO.class, workflowDefinition);
        WorkflowDefinitionDO fromDb = wfDefinitionDao.findById(fromApi.getId());

        fromDb.setDateUpdated(new Date());
        fromDb.setName(fromApi.getName());
        fromDb.setService(fromApi.getService());
        fromDb.setActive(fromApi.isActive());
        fromDb.setUpdatedBy(currentUserBt.getProfileId());

        wfDefinitionDao.update(fromDb);

        return objectMapper.getObject(WorkflowDefinition.class, fromDb);
    }

    public WorkflowDefinition updateWorkflowLevel(WorkflowDefinition workflowDefinition) {
        WorkflowDefinitionDO fromApi = objectMapper.getObject(WorkflowDefinitionDO.class, workflowDefinition);
        WorkflowDefinitionDO fromDb = wfDefinitionDao.findById(fromApi.getId());

        List<WorkflowLevelDefinitionDO> apiLevels = fromApi.getLevelDefinitions();
        List<WorkflowLevelDefinitionDO> dbLevels = fromDb.getLevelDefinitions();

        List<WorkflowLevelDefinitionDO> toAdd = listUtil.subtractList(apiLevels, dbLevels);
        dbLevels.addAll(toAdd);

        List<WorkflowLevelDefinitionDO> toDelete = listUtil.subtractList(dbLevels, apiLevels);
        dbLevels.removeAll(toDelete);

        List<WorkflowLevelDefinitionDO> updated = listUtil.getUpdatedItems(dbLevels, apiLevels);
        listUtil.updateItems(dbLevels, updated);

        wfDefinitionDao.update(fromDb);
        return objectMapper.getObject(WorkflowDefinition.class, fromDb);
    }

    public WorkflowDefinition updateWorkflowDefLevelCriteria(WorkflowDefinition workflowDefinition) {
        WorkflowDefinitionDO fromApi = objectMapper.getObject(WorkflowDefinitionDO.class, workflowDefinition);
        WorkflowDefinitionDO fromDb = wfDefinitionDao.findById(fromApi.getId());

        fromDb = updateLevelCriteria(fromApi, fromDb);

        wfDefinitionDao.update(fromDb);
        return objectMapper.getObject(WorkflowDefinition.class, fromDb);
    }

    private WorkflowDefinitionDO updateLevelCriteria(WorkflowDefinitionDO fromApi, WorkflowDefinitionDO fromDb) {

        List<WorkflowLevelDefinitionDO> apiLevels = fromApi.getLevelDefinitions();
        List<WorkflowLevelDefinitionDO> dbLevels = fromDb.getLevelDefinitions();

        for (int i = 0; i < dbLevels.size(); i++) {
            WorkflowLevelDefinitionDO apiLevel = apiLevels.get(i);
            WorkflowLevelDefinitionDO dbLevel = dbLevels.get(i);
            int apiHash = apiLevel.getLevelCriteria().hashCode();
            int dbHash = dbLevel.getLevelCriteria().hashCode();
            if (apiHash != dbHash) {
                dbLevel.setLevelCriteria(apiLevel.getLevelCriteria());
            }
        }
        return fromDb;
    }

    public WorkflowDefinition updateWorkflowDefWeighInElements(WorkflowDefinition workflowDefinition) {
        WorkflowDefinitionDO fromApi = objectMapper.getObject(WorkflowDefinitionDO.class, workflowDefinition);
        WorkflowDefinitionDO fromDb = wfDefinitionDao.findById(fromApi.getId());

        fromDb = updateWeighInElements(fromApi, fromDb);

        wfDefinitionDao.update(fromDb);
        return objectMapper.getObject(WorkflowDefinition.class, fromDb);
    }

    private WorkflowDefinitionDO updateWeighInElements(WorkflowDefinitionDO fromApi, WorkflowDefinitionDO fromDb) {
        List<WorkflowLevelDefinitionDO> apiLevels = fromApi.getLevelDefinitions();
        List<WorkflowLevelDefinitionDO> dbLevels = fromDb.getLevelDefinitions();

        for (int i = 0; i < dbLevels.size(); i++) {
            WorkflowLevelDefinitionDO apiLevel = apiLevels.get(i);
            WorkflowLevelDefinitionDO dbLevel = dbLevels.get(i);
            int apiHash = apiLevel.getLevelDefinitionWeighIns().hashCode();
            int dbHash = dbLevel.getLevelDefinitionWeighIns().hashCode();
            if (apiHash != dbHash) {
                dbLevel.setLevelDefinitionWeighIns(apiLevel.getLevelDefinitionWeighIns());
                break;
            }
        }
        return fromDb;
    }

    public WorkflowDefinition updateWorkflowDefRules(WorkflowDefinition workflowDefinition) {
        WorkflowDefinitionDO fromApi = objectMapper.getObject(WorkflowDefinitionDO.class, workflowDefinition);
        WorkflowDefinitionDO fromDb = wfDefinitionDao.findById(fromApi.getId());

        fromDb = updateRules(fromApi, fromDb);

        wfDefinitionDao.update(fromDb);
        return objectMapper.getObject(WorkflowDefinition.class, fromDb);
    }

    private WorkflowDefinitionDO updateRules(WorkflowDefinitionDO fromApi, WorkflowDefinitionDO fromDb) {
        List<WorkflowLevelDefinitionDO> apiLevels = fromApi.getLevelDefinitions();
        List<WorkflowLevelDefinitionDO> dbLevels = fromDb.getLevelDefinitions();

        for (int i = 0; i < dbLevels.size(); i++) {
            WorkflowLevelDefinitionDO apiLevel = apiLevels.get(i);
            WorkflowLevelDefinitionDO dbLevel = dbLevels.get(i);
            int apiHash = apiLevel.getRules().hashCode();
            int dbHash = dbLevel.getRules().hashCode();
            if (apiHash != dbHash) {
                dbLevel.setRules(apiLevel.getRules());
            }
        }
        return fromDb;
    }

}
