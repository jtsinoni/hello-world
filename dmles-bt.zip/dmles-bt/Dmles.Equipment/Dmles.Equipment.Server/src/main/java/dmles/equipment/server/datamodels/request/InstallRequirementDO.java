package dmles.equipment.server.datamodels.request;

import java.io.Serializable;

public class InstallRequirementDO implements Serializable {
    
    private static final long serialVersionUID = 1L; 
    private String description;
    private Float cost; 

    public InstallRequirementDO() {
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Float getCost() {
        return cost;
    }

    public void setCost(Float cost) {
        this.cost = cost;
    }
    
}
