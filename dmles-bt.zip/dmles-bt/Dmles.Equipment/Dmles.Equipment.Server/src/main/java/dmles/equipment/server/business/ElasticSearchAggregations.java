package dmles.equipment.server.business;

import org.elasticsearch.common.xcontent.XContentHelper;
import org.elasticsearch.search.aggregations.AggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.enterprise.context.Dependent;
import javax.inject.Inject;


////////////////////////////////////////////////////////////////////////////////
// TODO: NEEDS TO BE REFACTORED!!!!!!!!!!!!
// THIS CLASS NEEDS TO BE REFACTORED INTO A COMMON AREA SINCE IT IS/CAN BE USED
// BY MULTIPLE MODULES.
//------------------------------------------------------------------------------
// This class was copied to the Dmles.ABi.Server module and repackaged so we 
// will be ready for the March 3 Demo.
// This means that there are 2 copies of this code in the Business Tier!!!
////////////////////////////////////////////////////////////////////////////////

@Dependent
public class ElasticSearchAggregations {
    @Inject
    private Logger logger;

    /**
     * Processes a generic aggregations request clause from the PT with the
     * format: {"aggregations": [{"name":"orgIds","field":"orgId","size":"300"},
     * {"name":"custOrgIds","field":"custOrgId","size":"5000"},...]} and
     * ultimately returns an Elasticsearch-specific terms aggregation clause
     *
     * Parses the generic clause into a HashMap which is then passed to
     * createAggregations
     *
     * @param aggs - the generic aggregations request clause from PT
     *
     * @return a string Elasticsearch-specific terms aggregation clause
     */
    public String processAggregations(String aggs) {
        Map<String, AggregationProperties> aggregationsMap = new HashMap<>();
        JSONParser parser = new JSONParser();
        Object obj;
        try {
            obj = parser.parse(aggs);
            JSONObject jsonObject = (JSONObject) obj;
            JSONArray aggregationsArray = (JSONArray) jsonObject.get("aggregations");
            if (aggregationsArray != null) {
            Iterator<JSONObject> iterator = aggregationsArray.iterator();
                while (iterator.hasNext()) {
                    AggregationProperties currentProperties = new AggregationProperties();
                    JSONObject entry = (JSONObject) iterator.next();
                    currentProperties.setName(entry.get("name").toString());
                    currentProperties.setField(entry.get("field").toString());
                    currentProperties.setSize(entry.get("size").toString());
                    aggregationsMap.put(currentProperties.getName(), currentProperties);
                    // logger.info("Aggregation processed::{}", currentProperties.describe());
                }
            }
        } catch (ParseException ex) {
            logger.error(null, ex);
        }

        return createAggregations(aggregationsMap);
    }

    /**
     * Builds an Elasticsearch-specific terms aggregation clause given a HashMap
     *
     * @param aggregationsMap a map of desired contents of aggregation
     *
     * @return a string Elasticsearch-specific terms aggregation clause
     */
    private String createAggregations(Map<String, AggregationProperties> aggregationsMap) {
        StringBuilder sb = new StringBuilder();

        // add opening bracket
        sb.append("{ ");

        // add comma delimited term aggregations
        for (Map.Entry<String, AggregationProperties> entry : aggregationsMap.entrySet()) {
            AggregationBuilder termsAgg
                    = AggregationBuilders
                    .terms(entry.getValue().getName())
                    .field(entry.getValue().getField())
                    .size(Integer.parseInt(entry.getValue().getSize()))
                    .order(Terms.Order.term(true));
            // logger.info("termsAgg: " + XContentHelper.toString(termsAgg));
            String tAgg = XContentHelper.toString(termsAgg);

            // get rid of first and last characters - '{' and '}'
            tAgg = tAgg.substring(1, tAgg.length() - 1);

            sb.append(tAgg);
            sb.append(",");
        }

        // remove the final comma
        sb.deleteCharAt(sb.length() - 1);

        // add closing bracket
        sb.append(" }");

        logger.info("aggs used in ES template = " + sb.toString());
        return sb.toString();
    }

}
