package dmles.equipment.server.business;

import dmles.equipment.server.dao.WorkflowProcessingDao;
import dmles.equipment.server.datamodels.request.EquipmentRequestDO;
import dmles.equipment.server.datamodels.request.workflow.process.WorkflowHistoryDO;
import dmles.equipment.server.datamodels.request.workflow.process.WorkflowProcessingDO;
import dmles.oauth.core.datamodel.CurrentUserBT;

import java.util.Date;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

@ApplicationScoped
public class WorkflowHistoryManager {

    @Inject
    private CurrentUserBT user;
    @Inject
    private WorkflowProcessingDao wfProcessingDao;

    // used for CDI
    public WorkflowHistoryManager() {}

    public WorkflowHistoryManager(CurrentUserBT user, WorkflowProcessingDao wfProcessingDao) {
        this.user = user;
        this.wfProcessingDao = wfProcessingDao;
    }

    public void addHistory(EquipmentRequestDO request, String levelName, String appSection, String action){
        WorkflowHistoryDO historyItem = createHistory(appSection, action, levelName);
        WorkflowProcessingDO wfPdo = request.getWfProcessing();
        wfPdo.getHistory().add(historyItem);
        wfProcessingDao.update(wfPdo);
    }

    public void addHistory(WorkflowProcessingDO wfPdo, String levelName, String appSection, String action){
        WorkflowHistoryDO historyItem = createHistory(appSection, action, levelName);
        wfPdo.getHistory().add(historyItem);
        wfProcessingDao.update(wfPdo);
    }

    private WorkflowHistoryDO createHistory(String appSection, String action, String levelName){
        WorkflowHistoryDO historyItem = new WorkflowHistoryDO();
        historyItem.setId(new Date().getTime());
        historyItem.setAction(action);
        historyItem.setSection(appSection);
        historyItem.setLevel(levelName);
        historyItem.setUser(user.getFullName());
        historyItem.setWhen(new Date());
        return historyItem;
    }


}
