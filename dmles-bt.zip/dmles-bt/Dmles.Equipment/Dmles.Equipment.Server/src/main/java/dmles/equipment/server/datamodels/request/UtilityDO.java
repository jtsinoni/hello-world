package dmles.equipment.server.datamodels.request;

import java.io.Serializable;

public class UtilityDO implements Serializable {

    private static final long serialVersionUID = 1L;

    private String name;
    private Boolean required;
    private Boolean available;
    private Boolean na;
    private String comments;
    private String specifications;

    public UtilityDO() {
    }

    public UtilityDO(String name, Boolean required, Boolean available, Boolean na, String comments, String specifications) {
        this.name = name;
        this.required = required;
        this.available = available;
        this.na = na;
        this.comments = comments;
        this.specifications = specifications;
    }
         
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Boolean getRequired() {
        return required;
    }

    public void setRequired(Boolean required) {
        this.required = required;
    }

    public Boolean getAvailable() {
        return available;
    }

    public void setAvailable(Boolean available) {
        this.available = available;
    }

    public Boolean getNa() {
        return na;
    }

    public void setNa(Boolean na) {
        this.na = na;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }    

    public String getSpecifications() {
        return specifications;
    }

    public void setSpecifications(String specifications) {
        this.specifications = specifications;
    }
    
}
