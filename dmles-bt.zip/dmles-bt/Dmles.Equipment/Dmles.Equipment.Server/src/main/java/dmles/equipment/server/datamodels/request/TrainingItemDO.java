package dmles.equipment.server.datamodels.request;

public class TrainingItemDO {

    private String trainees;
    private Integer people;
    private Boolean includedCost;
    private String location;
    private Float registrationCost;
    private Float travelCost;
    private Float perDiem;
    private Integer days;
    private Float total;
    private String comments;     

    public TrainingItemDO() {
    }

    public String getTrainees() {
        return trainees;
    }

    public void setTrainees(String trainees) {
        this.trainees = trainees;
    }

    public Integer getPeople() {
        return people;
    }

    public void setPeople(Integer people) {
        this.people = people;
    }

    public Boolean getIncludedCost() {return includedCost;}

    public void setIncludedCost(Boolean includedCost) {this.includedCost = includedCost;}

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public Float getRegistrationCost() {
        return registrationCost;
    }

    public void setRegistrationCost(Float registrationCost) {
        this.registrationCost = registrationCost;
    }

    public Float getTravelCost() {
        return travelCost;
    }

    public void setTravelCost(Float travelCost) {
        this.travelCost = travelCost;
    }

    public Float getPerDiem() {
        return perDiem;
    }

    public void setPerDiem(Float perDiem) {
        this.perDiem = perDiem;
    }

    public Integer getDays() {
        return days;
    }

    public void setDays(Integer days) {
        this.days = days;
    }

    public Float getTotal() {
        return total;
    }

    public void setTotal(Float total) {
        this.total = total;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }
    
}
