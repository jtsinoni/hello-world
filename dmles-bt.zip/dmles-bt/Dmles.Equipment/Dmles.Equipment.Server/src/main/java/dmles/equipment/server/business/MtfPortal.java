package dmles.equipment.server.business;

import dmles.equipment.server.datamodels.request.EquipmentRequestDO;
import dmles.equipment.server.datamodels.request.EquipmentRequestReasonDO;
import dmles.equipment.core.datamodels.mtf.MtfSite;
import org.jboss.resteasy.client.jaxrs.ResteasyClientBuilder;
import org.jboss.resteasy.client.jaxrs.ResteasyClientBuilder.HostnameVerificationPolicy;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation.Builder;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;

public class MtfPortal {

    private final MtfSite mtfSite;
    private final Client client;

    public MtfPortal(MtfSite mtfSite) {
        this.mtfSite = mtfSite;
        this.client = constructClient();
    }

    public List<EquipmentRequestReasonDO> getEquipmentRequestReasons() {
        Builder target = buildTarget("EquipmentRequest/GetEquipmentRequestReasons");
        List<EquipmentRequestReasonDO> result = target.get(new GenericType<List<EquipmentRequestReasonDO>>() {
        });
        return result;
    }

    public void recordApprovedEquipmentRequest(EquipmentRequestDO equipmentRequest) {
        Builder target = buildTarget("EquipmentRequest/RecordApprovedEquipmentRequest");
        System.out.println("Posting to MTF Sites is currently disabled for testing");
        target.post(Entity.entity(equipmentRequest, MediaType.APPLICATION_JSON), EquipmentRequestDO.class);
    }

    private Client constructClient() {
        ResteasyClientBuilder builder = new ResteasyClientBuilder();
        builder.hostnameVerification(HostnameVerificationPolicy.ANY);

        KeyStore trustStore = loadStore("C:/DMLESPrograms/jboss-eap-7.0.0.Beta/jboss-eap-7.0/certs/localhost-truststore.jks", "password");
        System.out.println("Successfully loaded trust store");

        builder.trustStore(trustStore);

        KeyStore keyStore = loadStore("C:/DMLESPrograms/jboss-eap-7.0.0.Beta/jboss-eap-7.0/certs/localhost.jks", "password");
        System.out.println("Successfully loaded key store");
        builder.keyStore(keyStore, "password");

        builder.disableTrustManager();
        Client client = builder.build();
        System.out.println("Built client successfully");
        return client;
    }

    private Builder buildTarget(String actionPath) {
        String targetString = String.format("%s/Api/%s", mtfSite.getUrl(), actionPath);
        System.out.println(String.format("Built target: %s", targetString));
        return client.target(targetString).request(MediaType.APPLICATION_JSON);
    }

    private KeyStore loadStore(String keyStorePath, String password) {
        try {
            KeyStore ks = KeyStore.getInstance("JKS");
            InputStream readStream = new FileInputStream(keyStorePath);
            ks.load(readStream, password.toCharArray());
            readStream.close();
            return ks;
        } catch (KeyStoreException | NoSuchAlgorithmException | CertificateException ex) {
            Logger.getLogger(MtfPortal.class.getName()).log(Level.SEVERE, null, ex);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(MtfPortal.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(MtfPortal.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

}
