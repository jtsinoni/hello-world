package dmles.equipment.server.business;

import dmles.equipment.core.datamodels.request.workflow.process.LevelCriteriaNeeded;
import dmles.equipment.core.datamodels.request.workflow.process.WeighInResult;
import dmles.equipment.core.datamodels.request.workflow.process.WeighInStatus;
import dmles.equipment.core.datamodels.request.workflow.process.WorkflowLevelStatus;
import dmles.equipment.core.datamodels.request.workflow.process.WorkflowProcessing;
import dmles.equipment.server.dao.WorkflowProcessingDao;
import dmles.equipment.server.datamodels.request.EquipmentRequestDO;
import dmles.equipment.server.datamodels.request.workflow.definition.RulesDO;
import dmles.equipment.server.datamodels.request.workflow.definition.WorkflowDefinitionDO;
import dmles.equipment.server.datamodels.request.workflow.definition.WorkflowLevelDefinitionDO;
import dmles.equipment.server.datamodels.request.workflow.process.WeighInDO;
import dmles.equipment.server.datamodels.request.workflow.process.WorkflowCommentDO;
import dmles.equipment.server.datamodels.request.workflow.process.WorkflowHistoryDO;
import dmles.equipment.server.datamodels.request.workflow.process.WorkflowLevelProcessingDO;
import dmles.equipment.server.datamodels.request.workflow.process.WorkflowProcessingDO;
import dmles.oauth.core.datamodel.CurrentUserBT;
import dmles.user.core.clientmodel.UserType;
import mil.jmlfdc.common.exception.InvalidDataException;
import mil.jmlfdc.common.utils.StringUtil;
import dmles.equipment.core.datamodels.Comment;
import dmles.equipment.server.datamodels.request.workflow.definition.LevelDefinitionWeighInDO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import javax.inject.Inject;

// TODO: Further checks are needed to make sure an item is not moved up or down
// the workflow unless it's allowed.  For instance, all weigh-ins have been entered.
class WorkflowLogic {
  
    private static final Logger logger = LoggerFactory.getLogger(WorkflowLogic.class);
    public static final String INITIAL_REQUEST = "Initial Request";

    private CurrentUserBT user;     
    private EquipmentRequestDO request;
    private WorkflowDefinitionDO wfDefinition;
    private LevelCriteriaNeededFactory levelCriteriaNeededFactory = LevelCriteriaNeededFactory.getInstance();
    private WorkflowHistoryManager history;
    private WorkflowProcessingDao wfProcessingDao;

    WorkflowLogic(EquipmentRequestDO request, WorkflowDefinitionDO wfDefinition, CurrentUserBT user, WorkflowProcessingDao wfProcessingDao) {
        this.request = request;
        this.wfDefinition = wfDefinition;
        this.user = user;
        this.history = new WorkflowHistoryManager(user, wfProcessingDao);
    }

    private Comment createComment(String comment) {
        Comment commentObj = new Comment();
        commentObj.setComment(comment);
        commentObj.setCreated(new Date());
        commentObj.setId(new Date().getTime());
        commentObj.setNameFirst(user.getFirstName());
        commentObj.setNameLast(user.getLastName());
        return commentObj;
    }
    
    List<LevelCriteriaNeeded> getLevelsCriteriaNeeded() {
        int currentLevel = request.getWfProcessing().getCurrentLevelId();
        return getLevelsCriteriaNeeded(currentLevel);
    }

    private List<LevelCriteriaNeeded> getLevelsCriteriaNeeded(int startLevel) {
        int levelId = startLevel;

        List<LevelCriteriaNeeded> list = new ArrayList<>();
        Map<Integer, WorkflowLevelProcessingDO> levels =
                request.getWfProcessing().getLevels();

        for (WorkflowLevelProcessingDO wfp : levels.values()) {
            Integer wfpLevelId = wfp.getLevelId();
            if (wfpLevelId > levelId || (wfpLevelId == levelId && !wfp.getLevelId().equals(levels.size() -1))) {
                LevelCriteriaNeeded lcn = getLevelCriteriaNeeded(wfpLevelId);
                list.add(lcn);
            }
        }
        return list;
    }

    private boolean followingLevelsNeeded() {
        WorkflowProcessingDO wfPdo = request.getWfProcessing();
        int levelID = wfPdo.getCurrentLevelId() + 1;
        boolean retVal = false;
        if (!wfPdo.isEndOfWorkflow()) {
            List<LevelCriteriaNeeded> levelCriteriaNeeded = getLevelsCriteriaNeeded(levelID);
            for (LevelCriteriaNeeded needed : levelCriteriaNeeded) {
                if (needed.isCriteriaSet()) {
                    retVal = true;
                    break;
                }
            }
        }
        return retVal;
    }

    private boolean isLevelNeeded(int levelId) {

        LevelCriteriaNeeded levelCriteriaNeeded = getLevelCriteriaNeeded(levelId);
        return (levelCriteriaNeeded.isCriteriaSet());
    }

    private LevelCriteriaNeeded getLevelCriteriaNeeded(int levelId) {

        WorkflowLevelDefinitionDO levelDef = wfDefinition.getLevelDefinition(levelId);

        return levelCriteriaNeededFactory.getLevelCriteraNeeded(request, levelDef);

    }


    String getCurrentLevelName() {
        return getCurrentLevelName(request);
    }    
    
    private String getCurrentLevelName(EquipmentRequestDO request) {
        WorkflowProcessingDO wfProcessing = request.getWfProcessing();
        if (null == wfProcessing || StringUtil.isEmptyOrNull(wfProcessing.getId())) {
            return "Initial Request";
        }

        return wfProcessing.getCurrentLevel().getLevelName();
    }    
    
    public String getInitialRequestLevelName() {
        return INITIAL_REQUEST;
    }
    
    final Boolean goToPreviousLevel(EquipmentRequestDO request) {
        Boolean wentToPrevious = false;
        WorkflowProcessingDO wfpdo = request.getWfProcessing();
        WorkflowLevelProcessingDO currentLevelProcessing = wfpdo.getCurrentLevel();
        WorkflowLevelProcessingDO prevLevelProcessing = wfpdo.getPreviousLevel();

        if (null == prevLevelProcessing) {
            logger.warn("Go to Previous Level: Request already at level 0");
        } else {
            currentLevelProcessing.updateStatus(WorkflowLevelStatus.REWORK.toString(), "Tester");
            Integer prevLevelId = prevLevelProcessing.getLevelId();
            wfpdo.setCurrentOwnerRole(wfDefinition.getRoleOwner(prevLevelId));
            wfpdo.setCurrentLevelId(prevLevelId);
            prevLevelProcessing.updateStatus(WorkflowLevelStatus.ACTIVE.toString(), WorkflowHistoryDO.SYSTEM);
            wentToPrevious = true;
        }
        return wentToPrevious;
    }

    protected final Boolean goToNextLevel() {
        List<String> messages = findNextLevel();
        return (messages.size() == 0);
    }

    protected final List<String> findNextLevel() {
        List<String> messages = new ArrayList<>();
        WorkflowProcessingDO wfpdo = request.getWfProcessing();
        Integer startLevel = wfpdo.getCurrentLevelId();
        String startStatus = wfpdo.getCurrentLevel().getStatus();
        boolean forceUp = WorkflowLevelStatus.FORCEDUP.toString().equals(startStatus);
        boolean stopHere = false;

        // loop until we get to a level where we stop
        do {

            if (requestComplete(wfpdo.isCurrentLevel(startLevel), wfpdo.isEndOfWorkflow(), forceUp, !followingLevelsNeeded())) {
                stopHere = true;
                wfpdo.setIsCompleted(true);
                completeWorkflow(wfpdo);
                // TODO: Send to DMLSS?
            } else {
                // move to the next level
                WorkflowLevelProcessingDO nextLevelProcessing = wfpdo.getNextLevel();
                Integer levelId = nextLevelProcessing.getLevelId();
                wfpdo.setCurrentOwnerRole(wfDefinition.getRoleOwner(levelId));
                wfpdo.setCurrentLevelId(levelId);
                boolean levelNeeded = isLevelNeeded(levelId);

                // if this level is needed then stop here
                if (forceUp || levelNeeded) {
                    nextLevelProcessing.updateStatus(WorkflowLevelStatus.ACTIVE.toString(), WorkflowHistoryDO.SYSTEM);
                    stopHere = true;
                } else {
                    // if the level is not needed but other levels are then skip the current level
                    if (followingLevelsNeeded()) {
                        nextLevelProcessing.updateStatus(WorkflowLevelStatus.SKIPPED.toString(), WorkflowHistoryDO.SYSTEM);
                    } else {
                        // if the level is not needed and following levels are not needed then complete the workflow

                        wfpdo.setCurrentLevelId(startLevel);
                        stopHere = true;
                        completeWorkflow(wfpdo);
                    }
                }
            }
        } while (!stopHere);
        return messages;
    }

    boolean requestComplete(Boolean onStartLevel, boolean endOfWorkflow, boolean forceUp, boolean nextLevelsNotNeeded) {
        boolean retVal = false;

        if (onStartLevel && endOfWorkflow) {
            retVal = true;
        } else if (!forceUp && nextLevelsNotNeeded){
            retVal = true;
        }

        return retVal;
    }

    private void completeWorkflow(WorkflowProcessingDO wfPdo) {
        wfPdo.setCurrentStatus(WorkflowLevelStatus.COMPLETED.toString());
        wfPdo.getCurrentLevel().setStatus(WorkflowLevelStatus.COMPLETED.toString());
        history.addHistory(request, getCurrentLevelName(), "Manage", "Processing completed");
    }

    protected final void updateWeighInResult(WorkflowProcessingDO wfPdo,
                                             String weighInRoleId, String result) {
        WorkflowLevelProcessingDO currentLevelProcessing = wfPdo.getCurrentLevel();
        Integer currLevelId = currentLevelProcessing.getLevelId();

        WorkflowDefinitionDO wfDef = wfPdo.getWfDefinition();
        WorkflowLevelDefinitionDO wfLevelDef = wfDef.getLevelDefinition(currLevelId);
        RulesDO rules = wfLevelDef.getRules();
        //This checks if autoApprove is allowed on the level
        Boolean canAutoApprove = rules.getAllowAutoApproveAfterWeighIn();
        //This checks if the levelOwner has chosen to autoApprove the request
        Boolean isAutoApprove = currentLevelProcessing.getAutoApproveAfterWeighins();

        for (WeighInDO weighIn : currentLevelProcessing.getWeighIns()) {
            if (weighInRoleId.equals(weighIn.getRoleId())) {
                weighIn.setWeighInResult(result);
                weighIn.setWeighInStatus(WeighInStatus.SUBMITTED.toString());
                break;
            }
        }

        if (Boolean.TRUE.equals(canAutoApprove) && Boolean.TRUE.equals(isAutoApprove)) {
            autoApprove(currentLevelProcessing);
        }
    }

    void autoApprove(WorkflowLevelProcessingDO currentLevel) {
        if (allWeighInsApproved(currentLevel.getWeighIns())) {
            approve();
        }
    }

    boolean allWeighInsApproved(List<WeighInDO> weighIns) {
        boolean retVal = true;

        for (WeighInDO weighIn : weighIns) {
            String result = weighIn.getWeighInResult();
            // if skipped then OK
            // if submitted then it must be approved, recommend approved, or neutral
            String status = weighIn.getWeighInStatus();
            if (! (WeighInStatus.SUBMITTED.toString().equals(status)
                    && (WeighInResult.APPROVE.toString().equals(result)
                        || WeighInResult.RECOMMEND_APPROVE.toString().equals(result)
                        || WeighInResult.NEUTRAL.toString().equals(result))
                    || WeighInStatus.SKIPPED.toString().equals(status))){
                retVal = false;
                break;
            }
        }
        return retVal;
    }

    protected final void updateWeighInStatus(WorkflowLevelProcessingDO currentLevel,
            String weighInRoleId, String status) {
        if (StringUtil.isEmptyOrNull(weighInRoleId)) {  // Update all
            for (WeighInDO weighIn : currentLevel.getWeighIns()) {
                weighIn.setWeighInStatus(status);
            }
        } else {
            for (WeighInDO weighIn : currentLevel.getWeighIns()) { // Update specific weigh-in
                if (weighInRoleId.equals(weighIn.getRoleId())) {
                    weighIn.setWeighInStatus(status);

                    if (WeighInStatus.REWORK.toString().equals(status)) {
                        weighIn.setWeighInResult(null);
                    }

                    break;
                }
            }
        }
    }

    protected final List<WeighInDO> updateWeighInStatus(WorkflowLevelProcessingDO currLevelIn, WorkflowLevelProcessingDO currLevelDb) {

        List<WeighInDO> dosIn = currLevelIn.getWeighIns();
        List<WeighInDO> dosDb = currLevelDb.getWeighIns();
        List<WeighInDO> changed = new ArrayList<>();

        for (int i = 0; i < dosDb.size(); i ++) {
            WeighInDO doIn = dosIn.get(i);
            WeighInDO doDb = dosDb.get(i);

            if (!doDb.equalsStatus(doIn)) {
                doDb.setRoleId(doIn.getRoleId());
                doDb.setWeighInStatus(doIn.getWeighInStatus());
                doDb.setWeighInDisplayName(doIn.getWeighInDisplayName());
                doDb.setSelectedUserId(doIn.getSelectedUserId());
                changed.add(doDb);
            }
        }
        return changed;
    }
    
    private WorkflowCommentDO buildComment(String comment){
        WorkflowCommentDO commentDO = new WorkflowCommentDO();
        commentDO.setId(new Date().getTime());
        commentDO.setComment(comment);
        commentDO.setCreated(new Date());
        commentDO.setFirstName(user.getFirstName());
        commentDO.setLastName(user.getLastName());
        commentDO.setLevelName(getCurrentLevelName(request));    
        return commentDO;
    }

    public void addProcessComment(String comment) {
        WorkflowCommentDO newComment = buildComment(comment);
        WorkflowProcessingDO wfProcessing = request.getWfProcessing();
        if (null == wfProcessing.getComments()) {
            List<WorkflowCommentDO> comments = new ArrayList<>();
            comments.add(newComment);
            wfProcessing.setComments(comments);
        } else {
            wfProcessing.getComments().add(newComment);
        }
        history.addHistory(request, getCurrentLevelName(), "Manage", "General comment added");
    }

    public void removeProcessComment(String commentId) {
        WorkflowProcessingDO wfProcessing = request.getWfProcessing();

        if (null != wfProcessing.getComments() && wfProcessing.getComments().size() > 0){
            for (WorkflowCommentDO commentDO : wfProcessing.getComments()) {
                if (commentDO.getId().toString().equals(commentId)) {
                    wfProcessing.getComments().remove(commentDO);
                    break;
                }
            }
            String action = "General comment removed";
            history.addHistory(request, getCurrentLevelName(), "Manage", action);
        }else{
            logger.warn("Comment list is empty, unable to remove comment: " + commentId);
        }
        
    }

    public void addWeighInComment(String weighInRoleId, String comment) {
        WorkflowProcessingDO wfpdo = request.getWfProcessing();
        
        String weighInDisplayName = "";
        WorkflowLevelProcessingDO currentLevelProcessing = wfpdo.getCurrentLevel();
        for (WeighInDO weighIn : currentLevelProcessing.getWeighIns()) {
            if (weighIn.getRoleId().equals(weighInRoleId)) {
                weighInDisplayName = weighIn.getWeighInDisplayName();
                weighIn.getComments().add(createComment(comment));
                break;
            }
        }
        
        String section = weighInDisplayName + " Weigh-in";
        String action = "Weigh-in comment added";
        history.addHistory(request, getCurrentLevelName(), section, action);
    }

    public void removeWeighInComment(String weighInRoleId, String commentId) {
        WorkflowProcessingDO wfpdo = request.getWfProcessing();
        WorkflowLevelProcessingDO currentLevelProcessing = wfpdo.getCurrentLevel();
        
        if(null != currentLevelProcessing.getWeighIns() && currentLevelProcessing.getWeighIns().size() > 0){
            for (WeighInDO weighIn : currentLevelProcessing.getWeighIns()) {
                if (weighIn.getRoleId().equals(weighInRoleId)) {
                    
                    if(null != weighIn.getComments() && weighIn.getComments().size() > 0){            
                        for (Comment comment : weighIn.getComments()) {
                            if (comment.getId().toString().equals(commentId)) {
                                weighIn.getComments().remove(comment);
                                break;
                            }
                        }
                    }else{
                        logger.warn("Weigh-in comment list is empty, unable to remove comment: " + commentId);
                    }
                }
            }

            String action = "Weigh-in comment removed";
            history.addHistory(request, getCurrentLevelName(), "Manage", action);
        }else{
            logger.warn("Weigh-in list is empty, unable to remove comment: " + commentId);
        }
    }

    public void addWeighInResult(String weighInRole, String result, String weighInDisplayName) {
        WorkflowProcessingDO wfPdo = request.getWfProcessing();
        updateWeighInResult(wfPdo, weighInRole, result);

        String section = weighInDisplayName + " Weigh-in";
        String action = weighInDisplayName + " weigh-in submitted: " + result;
        history.addHistory(request, getCurrentLevelName(), section, action);
    }

    public void addWeighInStatus(WorkflowProcessingDO wfProcessingIn, WorkflowProcessingDO wfProcessingDb) {
        WorkflowLevelProcessingDO currLevelIn = wfProcessingIn.getCurrentLevel();
        WorkflowLevelProcessingDO currLeveDB = wfProcessingDb.getCurrentLevel();

        List<WeighInDO> changed = updateWeighInStatus(currLevelIn, currLeveDB);

        for (WeighInDO wdo : changed) {
            String newStatus = wdo.getWeighInDisplayName() + " weigh-in status changed to " + wdo.getWeighInStatus();
            history.addHistory(wfProcessingDb, getCurrentLevelName(), "Manage", newStatus);
        }
    }

    public Boolean approve() {
        WorkflowLevelProcessingDO wflPdo = request.getWfProcessing().getCurrentLevel();
        wflPdo.updateStatus(WorkflowLevelStatus.APPROVED.toString(), "Tester");

        boolean success = false;
        // TODO: Check weigh-ins, etc
        if (allWeighInsApproved(wflPdo.getWeighIns())) {

            String action = "Request approved";
            history.addHistory(request, getCurrentLevelName(), "Manage", action);

            success = goToNextLevel();

        }

        return success;
    }

    public void beginWeighIns(String weighInRole, String weighInDisplayName) {
        WorkflowProcessingDO wfpdo = request.getWfProcessing();
        WorkflowLevelProcessingDO currentLevelProcessing = wfpdo.getCurrentLevel();
        updateWeighInStatus(currentLevelProcessing, weighInRole, WeighInStatus.PENDING.toString());
        
        String action = "Submitted for weigh-ins";
        if(!StringUtil.isEmptyOrNull(weighInDisplayName)){
            action = "Submitted for " + weighInDisplayName + " weigh-in";
        }

        history.addHistory(request, getCurrentLevelName(), "Manage", action);
    }

    public void cancel() {
        WorkflowProcessingDO wfpdo = request.getWfProcessing();
        WorkflowLevelProcessingDO wflpdo = wfpdo.getCurrentLevel();
        wflpdo.updateStatus(WorkflowLevelStatus.CANCELLED.toString(), user.getFullName());
        wfpdo.setIsCompleted(true);
        wfpdo.setCurrentStatus(WorkflowLevelStatus.CANCELLED.toString());
        
        String action = "Request cancelled";
        history.addHistory(request, getCurrentLevelName(), "Manage", action);
    }

    public void retract() throws InvalidDataException {
        WorkflowProcessingDO wfPdo = request.getWfProcessing();

        // figure out user's level
        Integer userLevel = getUserWfLevel(wfPdo.getWfDefinition(), user.getUserType());
        // back up to that level
        Integer currentLevel = wfPdo.getCurrentLevelId();

        //work back through the workflow until we get to the user's level
        for (int i = currentLevel; i >= userLevel; i--) {
            WorkflowLevelProcessingDO level = wfPdo.getLevel(i);
            if (i == userLevel) {
                level.updateStatus(WorkflowLevelStatus.ACTIVE.toString(), user.getFullName());
                wfPdo.setCurrentLevelId(userLevel);
            } else {
                level.updateStatus(WorkflowLevelStatus.RETRACTED.toString(), user.getFullName());
            }
        }

    }

    Integer getUserWfLevel(WorkflowDefinitionDO wfDev, UserType userType) throws InvalidDataException {

        if (userType == null) {
            throw new InvalidDataException("User type on profile cannot be null");
        }
        List<WorkflowLevelDefinitionDO> levelDefs = wfDev.getLevelDefinitions();
        Integer retVal = null;

        for (WorkflowLevelDefinitionDO def: levelDefs) {
            if (userType.name().equals(def.getUserType())) {
                retVal = def.getLevelId();
                break;
            }
        }
        return retVal;
    }

    public Boolean forceUp() {
        WorkflowLevelProcessingDO wflpdo = request.getWfProcessing().getCurrentLevel();
        wflpdo.updateStatus(WorkflowLevelStatus.FORCEDUP.toString(), user.getFullName());
        
        String action = "Request forced up";
        history.addHistory(request, getCurrentLevelName(), "Manage", action);
        
        return goToNextLevel();        
    }

    public void hold() {
        WorkflowProcessingDO wfpdo = request.getWfProcessing();
        WorkflowLevelProcessingDO wflpdo = wfpdo.getCurrentLevel();
        wflpdo.updateStatus(WorkflowLevelStatus.HOLD.toString(), user.getFullName());
        wfpdo.setCurrentStatus(WorkflowLevelStatus.HOLD.toString());
        
        String action = "Request put on hold";
        history.addHistory(request, getCurrentLevelName(), "Manage", action);
    }

    public void reactivate() {
        WorkflowProcessingDO wfpdo = request.getWfProcessing();
        WorkflowLevelProcessingDO wflpdo = wfpdo.getCurrentLevel();
        wflpdo.updateStatus(WorkflowLevelStatus.ACTIVE.toString(), user.getFullName());
        wfpdo.setIsCompleted(false);
        wfpdo.setCurrentStatus(WorkflowLevelStatus.ACTIVE.toString());    
        
        String action = "Request reactivated";
        history.addHistory(request, getCurrentLevelName(), "Manage", action);
    }

    public void reject() {
        WorkflowProcessingDO wfpdo = request.getWfProcessing();
        WorkflowLevelProcessingDO wflpdo = wfpdo.getCurrentLevel();
        wflpdo.updateStatus(WorkflowLevelStatus.REJECTED.toString(), "Tester");
        wfpdo.setIsCompleted(true);
        wfpdo.setCurrentStatus(WorkflowLevelStatus.REJECTED.toString());       
        
        String action = "Request rejected";
        history.addHistory(request, getCurrentLevelName(), "Manage", action);
    }

    public void rework() {
        WorkflowLevelProcessingDO wflpdo = request.getWfProcessing().getCurrentLevel();
        wflpdo.updateStatus(WorkflowLevelStatus.REWORK.toString(), "Tester");
        
        String action = "Submitted for rework";
        history.addHistory(request, getCurrentLevelName(), "Manage", action);
        
        goToPreviousLevel(request);
    }

    public void saveWfProcessing() {
        saveWfProcessing(null);
    }
    
    public void saveWfProcessing(String sectionUpdated) {
        WorkflowProcessingDO workflowProcessing = request.getWfProcessing();
        
        if(!StringUtil.isEmptyOrNull(sectionUpdated)){
            history.addHistory(request, getCurrentLevelName(), sectionUpdated, "Data updated");
        }
        
        workflowProcessing.setUpdatedBy(user.getFullName());
        workflowProcessing.setUpdatedDate(new Date());
    }

    public WorkflowProcessingDO submit() {

        // TODO: Get from User object
        Integer currentLevelId = 0;
        String currentStatus = WorkflowLevelStatus.ACTIVE.toString();
        String currentOwner = null;

        // Build the levels according to the definition
        Map<Integer, WorkflowLevelProcessingDO> levels = new HashMap<>();
        for (WorkflowLevelDefinitionDO levelDef : wfDefinition.getLevelDefinitions()) {

            // Build the next level
            WorkflowLevelProcessingDO wfLevelProcessing = new WorkflowLevelProcessingDO();
            Integer levelId = levelDef.getLevelId();
            wfLevelProcessing.setLevelId(levelId);
            wfLevelProcessing.setLevelName(levelDef.getName());

            if (Objects.equals(currentLevelId, levelId)) {
                wfLevelProcessing.setStatus(currentStatus);
                currentOwner = levelDef.getOwnerRoleId();
            }

            // Build Weigh-Ins for the next level
            List<WeighInDO> weighIns = new ArrayList<>();
            for (LevelDefinitionWeighInDO ldwi : levelDef.getLevelDefinitionWeighIns()) {
                WeighInDO weighIn = new WeighInDO();
                weighIn.setElementName(ldwi.getElementName());
                weighIn.setRoleId(ldwi.getRoleId());
                weighIn.setWeighInDisplayName(ldwi.getWeighInDisplayName());
                weighIn.setWeighInStatus(WeighInStatus.NEW.toString());
                weighIns.add(weighIn);
            }
            wfLevelProcessing.setWeighIns(weighIns);

            levels.put(levelId, wfLevelProcessing);
        }

        // Build WFP
        WorkflowProcessingDO wfProcessing = new WorkflowProcessingDO();
        wfProcessing.setCurrentLevelId(currentLevelId);
        wfProcessing.setCurrentStatus(currentStatus);
        wfProcessing.setCurrentOwnerRole(currentOwner);
        wfProcessing.setLevels(levels);
        wfProcessing.setIsCompleted(false);
        wfProcessing.setRequestId(request.getId());
        wfProcessing.setWfDefinition(wfDefinition);

        return wfProcessing;
    }

    public EquipmentRequestDO getRequest() {
        return request;
    }

    public void setRequest(EquipmentRequestDO request) {
        this.request = request;
    }

    public CurrentUserBT getUser() {
        return user;
    }

    public void setUser(CurrentUserBT user) {
        this.user = user;
    }

    public WorkflowDefinitionDO getWfDefinition() {
        return wfDefinition;
    }

    public void setWfDefinition(WorkflowDefinitionDO wfDefinition) {
        this.wfDefinition = wfDefinition;
    }

}
