package dmles.equipment.server.business;

import dmles.common.general.logging.LogManager;
import dmles.common.general.logging.Logger;
import dmles.equipment.core.datamodels.request.workflow.process.LevelCriteriaNeeded;
import dmles.equipment.core.datamodels.request.workflow.process.ReviewStatus;
import dmles.equipment.core.datamodels.request.workflow.process.WorkflowLevelStatus;
import dmles.equipment.server.dao.WorkflowProcessingDao;
import dmles.equipment.server.datamodels.request.EquipmentRequestDO;
import dmles.equipment.server.datamodels.request.workflow.definition.LevelDefinitionReviewDO;
import dmles.equipment.server.datamodels.request.workflow.definition.RulesDO;
import dmles.equipment.server.datamodels.request.workflow.definition.WorkflowDefinitionDO;
import dmles.equipment.server.datamodels.request.workflow.definition.WorkflowLevelDefinitionDO;
import dmles.equipment.server.datamodels.request.workflow.process.*;
import mil.jmlfdc.common.datamodel.CurrentUserBT;
import mil.jmlfdc.common.datamodel.UserType;
import mil.jmlfdc.common.exception.InvalidDataException;
import mil.jmlfdc.common.utils.StringUtil;
import dmles.equipment.server.datamodels.CommentDO;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

// TODO: Further checks are needed to make sure an item is not moved up or down
// the workflow unless it's allowed.  For instance, all reviews have been entered.
class WorkflowLogic {

    private Logger logger = LogManager.getLogger();

    public static final String INITIAL_REQUEST = "Initial Request";

    private CurrentUserBT user;     
    private EquipmentRequestDO request;
    private WorkflowDefinitionDO wfDefinition;
    private LevelCriteriaNeededFactory levelCriteriaNeededFactory = LevelCriteriaNeededFactory.getInstance();
    private WorkflowHistoryManager history;
    private WorkflowProcessingDao wfProcessingDao;

    WorkflowLogic(EquipmentRequestDO request, WorkflowDefinitionDO wfDefinition, CurrentUserBT user, WorkflowProcessingDao wfProcessingDao) {
        this.request = request;
        this.wfDefinition = wfDefinition;
        this.user = user;
        this.history = new WorkflowHistoryManager(user, wfProcessingDao);
        this.logger = logger;
    }

    private CommentDO createComment(String comment) {
        CommentDO commentObj = new CommentDO();
        commentObj.setComment(comment);
        commentObj.setCreated(new Date());
        commentObj.setId(new Date().getTime());
        commentObj.setFirstName(user.getFirstName());
        commentObj.setLastName(user.getLastName());
        return commentObj;
    }
    
    List<LevelCriteriaNeeded> getLevelsCriteriaNeeded() {
        int currentLevel = request.getWfProcessing().getCurrentLevelId();
        return getLevelsCriteriaNeeded(currentLevel);
    }

    private List<LevelCriteriaNeeded> getLevelsCriteriaNeeded(int startLevel) {
        int levelId = startLevel;

        List<LevelCriteriaNeeded> list = new ArrayList<>();
        Map<Integer, WorkflowLevelProcessingDO> levels =
                request.getWfProcessing().getLevels();

        for (WorkflowLevelProcessingDO wfp : levels.values()) {
            Integer wfpLevelId = wfp.getLevelId();
            if (wfpLevelId > levelId || (wfpLevelId == levelId && !wfp.getLevelId().equals(levels.size() -1))) {
                LevelCriteriaNeeded lcn = getLevelCriteriaNeeded(wfpLevelId);
                list.add(lcn);
            }
        }
        return list;
    }

    private boolean followingLevelsNeeded() {
        WorkflowProcessingDO wfPdo = request.getWfProcessing();
        int levelID = wfPdo.getCurrentLevelId() + 1;
        boolean retVal = false;
        if (!wfPdo.isEndOfWorkflow()) {
            List<LevelCriteriaNeeded> levelCriteriaNeeded = getLevelsCriteriaNeeded(levelID);
            for (LevelCriteriaNeeded needed : levelCriteriaNeeded) {
                if (needed.isCriteriaSet()) {
                    retVal = true;
                    break;
                }
            }
        }
        return retVal;
    }

    private boolean isLevelNeeded(int levelId) {

        LevelCriteriaNeeded levelCriteriaNeeded = getLevelCriteriaNeeded(levelId);
        return (levelCriteriaNeeded.isCriteriaSet());
    }

    private LevelCriteriaNeeded getLevelCriteriaNeeded(int levelId) {

        WorkflowLevelDefinitionDO levelDef = wfDefinition.getLevelDefinition(levelId);

        return levelCriteriaNeededFactory.getLevelCriteraNeeded(request, levelDef);

    }


    String getCurrentLevelName() {
        return getCurrentLevelName(request);
    }    
    
    private String getCurrentLevelName(EquipmentRequestDO request) {
        WorkflowProcessingDO wfProcessing = request.getWfProcessing();
        if (null == wfProcessing || StringUtil.isEmptyOrNull(wfProcessing.getId())) {
            return "Initial Request";
        }

        return wfProcessing.getCurrentLevel().getLevelName();
    }    
    
    public String getInitialRequestLevelName() {
        return INITIAL_REQUEST;
    }
    
    final Boolean goToPreviousLevel(EquipmentRequestDO request) {
        Boolean wentToPrevious = false;
        WorkflowProcessingDO wfpdo = request.getWfProcessing();
        WorkflowLevelProcessingDO currentLevelProcessing = wfpdo.getCurrentLevel();
        WorkflowLevelProcessingDO prevLevelProcessing = wfpdo.getPreviousLevel();

        if (null == prevLevelProcessing) {
            logger.warn("Go to Previous Level: Request already at level 0");
        } else {
            currentLevelProcessing.updateStatus(WorkflowLevelStatus.REWORK.toString(), user.getFullName());
            Integer prevLevelId = prevLevelProcessing.getLevelId();
            wfpdo.setCurrentOwnerRole(wfDefinition.getRoleOwner(prevLevelId));
            wfpdo.setCurrentLevelId(prevLevelId);
            prevLevelProcessing.updateStatus(WorkflowLevelStatus.ACTIVE.toString(), WorkflowHistoryDO.SYSTEM);
            wentToPrevious = true;
        }
        return wentToPrevious;
    }

    protected final Boolean goToNextLevel() {
        List<String> messages = findNextLevel();
        return (messages.size() == 0);
    }

    protected final List<String> findNextLevel() {
        List<String> messages = new ArrayList<>();
        WorkflowProcessingDO wfpdo = request.getWfProcessing();
        Integer startLevel = wfpdo.getCurrentLevelId();
        String startStatus = wfpdo.getCurrentLevel().getStatus();
        boolean forceUp = WorkflowLevelStatus.FORCEDUP.toString().equals(startStatus);
        boolean stopHere = false;

        // loop until we get to a level where we stop
        do {

            if (requestComplete(wfpdo.isCurrentLevel(startLevel), wfpdo.isEndOfWorkflow(), forceUp, !followingLevelsNeeded())) {
                stopHere = true;
                wfpdo.setIsCompleted(true);
                completeWorkflow(wfpdo);
                // TODO: Send to DMLSS?
            } else {
                // move to the next level
                WorkflowLevelProcessingDO nextLevelProcessing = wfpdo.getNextLevel();
                Integer levelId = nextLevelProcessing.getLevelId();
                wfpdo.setCurrentOwnerRole(wfDefinition.getRoleOwner(levelId));
                wfpdo.setCurrentLevelId(levelId);
                boolean levelNeeded = isLevelNeeded(levelId);

                // if this level is needed then stop here
                if (forceUp || levelNeeded) {
                    nextLevelProcessing.updateStatus(WorkflowLevelStatus.ACTIVE.toString(), WorkflowHistoryDO.SYSTEM);
                    stopHere = true;
                } else {
                    // if the level is not needed but other levels are then skip the current level
                    if (followingLevelsNeeded()) {
                        nextLevelProcessing.updateStatus(WorkflowLevelStatus.SKIPPED.toString(), WorkflowHistoryDO.SYSTEM);
                    } else {
                        // if the level is not needed and following levels are not needed then complete the workflow

                        wfpdo.setCurrentLevelId(startLevel);
                        stopHere = true;
                        completeWorkflow(wfpdo);
                    }
                }
            }
        } while (!stopHere);
        return messages;
    }

    boolean requestComplete(Boolean onStartLevel, boolean endOfWorkflow, boolean forceUp, boolean nextLevelsNotNeeded) {
        boolean retVal = false;

        if (onStartLevel && endOfWorkflow) {
            retVal = true;
        } else if (!forceUp && nextLevelsNotNeeded){
            retVal = true;
        }

        return retVal;
    }

    private void completeWorkflow(WorkflowProcessingDO wfPdo) {
        wfPdo.setCurrentStatus(WorkflowLevelStatus.COMPLETED.toString());
        wfPdo.getCurrentLevel().setStatus(WorkflowLevelStatus.COMPLETED.toString());
        history.addHistory(request, getCurrentLevelName(), "Manage", "Processing completed");
    }

    protected final void updateReviewResult(WorkflowProcessingDO wfPdo,
                                            String reviewDisplayName, Integer resultCode, String resultText) {
        WorkflowLevelProcessingDO currentLevelProcessing = wfPdo.getCurrentLevel();
        Integer currLevelId = currentLevelProcessing.getLevelId();

        WorkflowDefinitionDO wfDef = wfPdo.getWfDefinition();
        WorkflowLevelDefinitionDO wfLevelDef = wfDef.getLevelDefinition(currLevelId);
        RulesDO rules = wfLevelDef.getRules();
        //This checks if autoApprove is allowed on the level
        Boolean canAutoApprove = rules.getAllowAutoApproveAfterReview();
        //This checks if the levelOwner has chosen to autoApprove the request
        Boolean isAutoApprove = currentLevelProcessing.getAutoApproveAfterReviews();

        for (ReviewDO review : currentLevelProcessing.getReviews()) {
            if (reviewDisplayName.equals(review.getReviewDisplayName())) {
                ReviewResultDO result = review.getReviewResult();
                result.setCode(resultCode);
                result.setText(resultText);
                review.setReviewStatus(ReviewStatus.SUBMITTED.toString());
                break;
            }
        }

        if (Boolean.TRUE.equals(canAutoApprove) && Boolean.TRUE.equals(isAutoApprove)) {
            autoApprove(currentLevelProcessing);
        }
    }

    void autoApprove(WorkflowLevelProcessingDO currentLevel) {
        if (allReviewsApproved(currentLevel.getReviews())) {
            approve();
        }
    }

    boolean allReviewsApproved(List<ReviewDO> reviews) {
        boolean retVal = true;

        for (ReviewDO review : reviews) {
            ReviewResultDO result = review.getReviewResult();
            // if skipped then OK
            // if submitted then it must be approved, recommend approved, or neutral
            String status = review.getReviewStatus();
            if (! (ReviewStatus.SUBMITTED.toString().equals(status)
                    && (result.getCode() == 1
                        || result.getCode() == 0)
                    || ReviewStatus.SKIPPED.toString().equals(status))){
                retVal = false;
                break;
            }
        }
        return retVal;
    }

    protected final void updateReviewStatus(WorkflowLevelProcessingDO currentLevel,
            String reviewDisplayName, String status) {
        if (StringUtil.isEmptyOrNull(reviewDisplayName)) {  // Update all
            for (ReviewDO review : currentLevel.getReviews()) {
                review.setReviewStatus(status);
            }
        } else {
            for (ReviewDO review : currentLevel.getReviews()) { // Update specific review
                if (reviewDisplayName.equals(review.getReviewDisplayName())) {
                    review.setReviewStatus(status);

                    if (ReviewStatus.REWORK.toString().equals(status)) {
                        review.setReviewResult(null);
                    }

                    if (ReviewStatus.SKIPPED.toString().equals(status)) {
                        review.setSelectedUserId(null);
                    }

                    break;
                }
            }
        }
    }

    //TODO left this in because wasn't sure what was using this and why it was here

    /*protected final final void updateReviewStatus(WorkflowLevelProcessingDO currLevelIn, WorkflowLevelProcessingDO currLevelDb) {

        List<ReviewDO> dosIn = currLevelIn.getReviews();
        List<ReviewDO> dosDb = currLevelDb.getReviews();
        List<ReviewDO> changed = new ArrayList<>();

        for (int i = 0; i < dosDb.size(); i ++) {
            ReviewDO doIn = dosIn.get(i);
            ReviewDO doDb = dosDb.get(i);

            if (!doDb.equalsStatus(doIn)) {
                doDb.setRoleId(doIn.getRoleId());
                doDb.setReviewStatus(doIn.getReviewStatus());
                doDb.setReviewDisplayName(doIn.getReviewDisplayName());
                doDb.setSelectedUserId(doIn.getSelectedUserId());
                changed.add(doDb);
            }
        }
        return changed;
    }*/
    
    private WorkflowCommentDO buildComment(String comment){
        WorkflowCommentDO commentDO = new WorkflowCommentDO();
        commentDO.setId(new Date().getTime());
        commentDO.setComment(comment);
        commentDO.setCreated(new Date());
        commentDO.setFirstName(user.getFirstName());
        commentDO.setLastName(user.getLastName());
        commentDO.setLevelName(getCurrentLevelName(request));    
        return commentDO;
    }

    public void addProcessComment(String comment) {
        WorkflowCommentDO newComment = buildComment(comment);
        WorkflowProcessingDO wfProcessing = request.getWfProcessing();
        if (null == wfProcessing.getComments()) {
            List<WorkflowCommentDO> comments = new ArrayList<>();
            comments.add(newComment);
            wfProcessing.setComments(comments);
        } else {
            wfProcessing.getComments().add(newComment);
        }
        history.addHistory(request, getCurrentLevelName(), "Manage", "General comment added");
    }

    public void removeProcessComment(String commentId) {
        WorkflowProcessingDO wfProcessing = request.getWfProcessing();

        if (null != wfProcessing.getComments() && wfProcessing.getComments().size() > 0){
            for (WorkflowCommentDO commentDO : wfProcessing.getComments()) {
                if (commentDO.getId().toString().equals(commentId)) {
                    wfProcessing.getComments().remove(commentDO);
                    break;
                }
            }
            String action = "General comment removed";
            history.addHistory(request, getCurrentLevelName(), "Manage", action);
        }else{
            logger.warn("Comment list is empty, unable to remove comment: " + commentId);
        }
        
    }

    public void addReviewComment(String reviewDisplayName, String comment) {
        WorkflowProcessingDO wfpdo = request.getWfProcessing();

        WorkflowLevelProcessingDO currentLevelProcessing = wfpdo.getCurrentLevel();
        for (ReviewDO review : currentLevelProcessing.getReviews()) {
            if (review.getReviewDisplayName().equals(reviewDisplayName)) {
                review.getComments().add(createComment(comment));
                break;
            }
        }
        
        String section = reviewDisplayName + " Review";
        String action = "Review comment added";
        history.addHistory(request, getCurrentLevelName(), section, action);
    }

    public void removeReviewComment(String reviewDisplayName, String commentId) {
        WorkflowProcessingDO wfpdo = request.getWfProcessing();
        WorkflowLevelProcessingDO currentLevelProcessing = wfpdo.getCurrentLevel();
        
        if(null != currentLevelProcessing.getReviews() && currentLevelProcessing.getReviews().size() > 0){
            for (ReviewDO review : currentLevelProcessing.getReviews()) {
                if (review.getReviewDisplayName().equals(reviewDisplayName)) {
                    
                    if(null != review.getComments() && review.getComments().size() > 0){
                        for (CommentDO comment : review.getComments()) {
                            if (comment.getId().toString().equals(commentId)) {
                                review.getComments().remove(comment);
                                break;
                            }
                        }
                    }else{
                        logger.warn("Review comment list is empty, unable to remove comment: " + commentId);
                    }
                }
            }

            String action = "Review comment removed";
            history.addHistory(request, getCurrentLevelName(), "Manage", action);
        }else{
            logger.warn("Review list is empty, unable to remove comment: " + commentId);
        }
    }

    public void addReviewResult(Integer resultCode, String resultText, String reviewDisplayName) {
        WorkflowProcessingDO wfPdo = request.getWfProcessing();
        updateReviewResult(wfPdo, reviewDisplayName, resultCode, resultText);

        String section = reviewDisplayName + " Review";
        String action = reviewDisplayName + " review submitted: " + resultText;
        history.addHistory(request, getCurrentLevelName(), section, action);
    }

    public void addReviewStatus(String status, String reviewDisplayName) {
        WorkflowProcessingDO wfPdo = request.getWfProcessing();
        WorkflowLevelProcessingDO currentLevelProcessing = wfPdo.getCurrentLevel();
        updateReviewStatus(currentLevelProcessing, reviewDisplayName, status);

        String section = reviewDisplayName + " Review";
        String action = reviewDisplayName + " review status submitted: " + status;
        history.addHistory(request, getCurrentLevelName(), section, action);
    }

    public Boolean approve() {
        WorkflowLevelProcessingDO wflPdo = request.getWfProcessing().getCurrentLevel();
        Integer currLevelId = wflPdo.getLevelId();
        WorkflowDefinitionDO wfDef = request.getWfProcessing().getWfDefinition();
        WorkflowLevelDefinitionDO wfLevelDef = wfDef.getLevelDefinition(currLevelId);
        RulesDO rules = wfLevelDef.getRules();

        boolean success = false;
        Boolean canOverrideNegativeReviews = rules.getAllowOwnerOverrideNegativeReviews();
        if ((Boolean.FALSE.equals(canOverrideNegativeReviews) && allReviewsApproved(wflPdo.getReviews())) ||
                Boolean.TRUE.equals(canOverrideNegativeReviews)) {

            String action = "Request approved";
            history.addHistory(request, getCurrentLevelName(), "Manage", action);

            wflPdo.updateStatus(WorkflowLevelStatus.APPROVED.toString(), user.getFullName());

            success = goToNextLevel();

        }

        return success;
    }

    public void beginReviews(String reviewRole, String reviewDisplayName) {
        WorkflowProcessingDO wfpdo = request.getWfProcessing();
        WorkflowLevelProcessingDO currentLevelProcessing = wfpdo.getCurrentLevel();
        updateReviewStatus(currentLevelProcessing, reviewDisplayName, ReviewStatus.PENDING.toString());
        
        String action = "Submitted for reviews";
        if(!StringUtil.isEmptyOrNull(reviewDisplayName)){
            action = "Submitted for " + reviewDisplayName + " review";
        }

        history.addHistory(request, getCurrentLevelName(), "Manage", action);
    }

    public void cancel() {
        WorkflowProcessingDO wfpdo = request.getWfProcessing();
        WorkflowLevelProcessingDO wflpdo = wfpdo.getCurrentLevel();
        wflpdo.updateStatus(WorkflowLevelStatus.CANCELLED.toString(), user.getFullName());
        wfpdo.setIsCompleted(true);
        wfpdo.setCurrentStatus(WorkflowLevelStatus.CANCELLED.toString());
        
        String action = "Request cancelled";
        history.addHistory(request, getCurrentLevelName(), "Manage", action);
    }

    public void retract() throws InvalidDataException {
        WorkflowProcessingDO wfPdo = request.getWfProcessing();

        // figure out user's level
        Integer userLevel = getUserWfLevel(wfPdo.getWfDefinition(), user.getUserType());
        // back up to that level
        Integer currentLevel = wfPdo.getCurrentLevelId();

        //work back through the workflow until we get to the user's level
        for (int i = currentLevel; i >= userLevel; i--) {
            WorkflowLevelProcessingDO level = wfPdo.getLevel(i);
            if (i == userLevel) {
                level.updateStatus(WorkflowLevelStatus.ACTIVE.toString(), user.getFullName());
                wfPdo.setCurrentLevelId(userLevel);
            } else {
                level.updateStatus(WorkflowLevelStatus.RETRACTED.toString(), user.getFullName());
            }
        }

    }

    Integer getUserWfLevel(WorkflowDefinitionDO wfDev, UserType userType) throws InvalidDataException {

        if (userType == null) {
            throw new InvalidDataException("User type on profile cannot be null");
        }
        List<WorkflowLevelDefinitionDO> levelDefs = wfDev.getLevelDefinitions();
        Integer retVal = null;

        for (WorkflowLevelDefinitionDO def: levelDefs) {
            if (userType.name().equals(def.getUserType())) {
                retVal = def.getLevelId();
                break;
            }
        }
        return retVal;
    }

    public Boolean forceUp() {
        WorkflowLevelProcessingDO wflpdo = request.getWfProcessing().getCurrentLevel();
        wflpdo.updateStatus(WorkflowLevelStatus.FORCEDUP.toString(), user.getFullName());
        
        String action = "Request forced up";
        history.addHistory(request, getCurrentLevelName(), "Manage", action);
        
        return goToNextLevel();        
    }

    public void hold() {
        WorkflowProcessingDO wfpdo = request.getWfProcessing();
        WorkflowLevelProcessingDO wflpdo = wfpdo.getCurrentLevel();
        wflpdo.updateStatus(WorkflowLevelStatus.HOLD.toString(), user.getFullName());
        wfpdo.setCurrentStatus(WorkflowLevelStatus.HOLD.toString());
        
        String action = "Request put on hold";
        history.addHistory(request, getCurrentLevelName(), "Manage", action);
    }

    public void reactivate() {
        WorkflowProcessingDO wfpdo = request.getWfProcessing();
        WorkflowLevelProcessingDO wflpdo = wfpdo.getCurrentLevel();
        wflpdo.updateStatus(WorkflowLevelStatus.ACTIVE.toString(), user.getFullName());
        wfpdo.setIsCompleted(false);
        wfpdo.setCurrentStatus(WorkflowLevelStatus.ACTIVE.toString());    
        
        String action = "Request reactivated";
        history.addHistory(request, getCurrentLevelName(), "Manage", action);
    }

    public void reject() {
        WorkflowProcessingDO wfpdo = request.getWfProcessing();
        WorkflowLevelProcessingDO wflpdo = wfpdo.getCurrentLevel();
        wflpdo.updateStatus(WorkflowLevelStatus.REJECTED.toString(), user.getFullName());
        wfpdo.setIsCompleted(true);
        wfpdo.setCurrentStatus(WorkflowLevelStatus.REJECTED.toString());       
        
        String action = "Request rejected";
        history.addHistory(request, getCurrentLevelName(), "Manage", action);
    }

    public void rework() {
        WorkflowLevelProcessingDO wflpdo = request.getWfProcessing().getCurrentLevel();
        wflpdo.updateStatus(WorkflowLevelStatus.REWORK.toString(), user.getFullName());
        
        String action = "Submitted for rework";
        history.addHistory(request, getCurrentLevelName(), "Manage", action);
        
        goToPreviousLevel(request);
    }

    public void saveWfProcessing() {
        saveWfProcessing(null);
    }
    
    public void saveWfProcessing(String sectionUpdated) {
        WorkflowProcessingDO workflowProcessing = request.getWfProcessing();
        
        if(!StringUtil.isEmptyOrNull(sectionUpdated)){
            history.addHistory(request, getCurrentLevelName(), sectionUpdated, "Data updated");
        }
        
        workflowProcessing.setUpdatedBy(user.getFullName());
        workflowProcessing.setUpdatedDate(new Date());
    }

    public WorkflowProcessingDO submit() {

        // TODO: Get from User object
        Integer currentLevelId = 0;
        String currentStatus = WorkflowLevelStatus.ACTIVE.toString();
        String currentOwner = null;

        // Build the levels according to the definition
        Map<Integer, WorkflowLevelProcessingDO> levels = new HashMap<>();
        for (WorkflowLevelDefinitionDO levelDef : wfDefinition.getLevelDefinitions()) {

            // Build the next level
            WorkflowLevelProcessingDO wfLevelProcessing = new WorkflowLevelProcessingDO();
            Integer levelId = levelDef.getLevelId();
            wfLevelProcessing.setLevelId(levelId);
            wfLevelProcessing.setLevelName(levelDef.getName());

            if (Objects.equals(currentLevelId, levelId)) {
                wfLevelProcessing.setStatus(currentStatus);
                currentOwner = levelDef.getOwnerRoleId();
            }

            // Build Reviews for the next level
            List<ReviewDO> reviews = new ArrayList<>();
            for (LevelDefinitionReviewDO ldwi : levelDef.getLevelDefinitionReviews()) {
                ReviewDO review = new ReviewDO();
                review.setElementName(ldwi.getElementName());
                review.setRoleId(ldwi.getRoleId());
                review.setReviewDisplayName(ldwi.getReviewDisplayName());
                review.setReviewStatus(ReviewStatus.NEW.toString());
                reviews.add(review);
            }
            wfLevelProcessing.setReviews(reviews);

            levels.put(levelId, wfLevelProcessing);
        }

        // Build WFP
        WorkflowProcessingDO wfProcessing = new WorkflowProcessingDO();
        wfProcessing.setCurrentLevelId(currentLevelId);
        wfProcessing.setCurrentStatus(currentStatus);
        wfProcessing.setCurrentOwnerRole(currentOwner);
        wfProcessing.setLevels(levels);
        wfProcessing.setIsCompleted(false);
        wfProcessing.setRequestId(request.getId());
        wfProcessing.setWfDefinition(wfDefinition);

        return wfProcessing;
    }

    public EquipmentRequestDO getRequest() {
        return request;
    }

    public void setRequest(EquipmentRequestDO request) {
        this.request = request;
    }

    public CurrentUserBT getUser() {
        return user;
    }

    public void setUser(CurrentUserBT user) {
        this.user = user;
    }

    public WorkflowDefinitionDO getWfDefinition() {
        return wfDefinition;
    }

    public void setWfDefinition(WorkflowDefinitionDO wfDefinition) {
        this.wfDefinition = wfDefinition;
    }

}
