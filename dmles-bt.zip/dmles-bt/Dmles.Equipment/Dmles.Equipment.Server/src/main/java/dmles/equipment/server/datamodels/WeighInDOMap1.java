package dmles.equipment.server.datamodels;

import java.util.HashMap;
import java.util.Map;


public class WeighInDOMap1 {
    
    private static final Map<String,String> MAP;
    
    static{
        MAP = new HashMap<>();
        MAP.put("Site Equipment Technologist", "equip-request-technology");
        MAP.put("Site Equipment Maintenance", "equip-request-maintenance");
        MAP.put("Site Equipment Facilities", "equip-request-facilities");
        MAP.put("Site Equipment Safety", "equip-request-safety");
        
    }
    public static Map<String,String> getMap(){
        return MAP;
    }
}
