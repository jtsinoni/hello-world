package dmles.equipment.server.dao;

import javax.enterprise.context.Dependent;
import mil.jmlfdc.common.dao.BaseDao;
import dmles.equipment.server.datamodels.request.EquipmentRequestTypeDO;

@Dependent
public class EquipmentRequestTypeDao extends BaseDao<EquipmentRequestTypeDO, String> {

    public EquipmentRequestTypeDao() {
        super(EquipmentRequestTypeDO.class);
    }

}
