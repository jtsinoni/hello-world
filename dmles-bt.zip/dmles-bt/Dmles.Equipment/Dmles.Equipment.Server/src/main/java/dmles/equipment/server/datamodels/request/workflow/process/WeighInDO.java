package dmles.equipment.server.datamodels.request.workflow.process;

import dmles.equipment.server.datamodels.CommentDO;
import org.mongodb.morphia.annotations.Embedded;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class WeighInDO {
    private static final Integer CURRENT_VERSION = 1;
    
    private String weighInDisplayName;
    private String elementName;
    private String weighInStatus;
    private String weighInResult;
    private String selectedUserId;
    private String roleId;
    
    @Embedded
    private List<WeighInUserDO> weighInUsers = new ArrayList<>();    

    @Embedded
    private List<CommentDO> comments = new ArrayList<>();

    public String getSelectedUserId() {
        return selectedUserId;
    }

    public void setSelectedUserId(String selectedUserId) {
        this.selectedUserId = selectedUserId;
    }
    
    public String getWeighInDisplayName() {
        return weighInDisplayName;
    }

    public void setWeighInDisplayName(String weighInDisplayName) {
        this.weighInDisplayName = weighInDisplayName;
    }

    public String getElementName() {
        return elementName;
    }

    public void setElementName(String elementName) {
        this.elementName = elementName;
    }

    public List<WeighInUserDO> getWeighInUsers() {
        return weighInUsers;
    }

    public void setWeighInUsers(List<WeighInUserDO> weighInUsers) {
        this.weighInUsers = weighInUsers;
    }

    public List<CommentDO> getComments() {
        return comments;
    }

    public void setComments(List<CommentDO> comments) {
        this.comments = comments;
    }

    public String getWeighInStatus() {
        return weighInStatus;
    }

    public void setWeighInStatus(String weighInStatus) {
        this.weighInStatus = weighInStatus;
    }

    public String getWeighInResult() {
        return weighInResult;
    }

    public void setWeighInResult(String weighInResult) {
        this.weighInResult = weighInResult;
    }

    public List<WeighInUserDO> getWeighInUsersDO() {
        return weighInUsers;
    }

    public void setWeighInUsersDO(List<WeighInUserDO> weighInUsers) {
        this.weighInUsers = weighInUsers;
    }
    
    public String getRoleId() {
        return roleId;
    }
    
    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    public boolean equalsStatus(Object o) {
        if (this == o) return true;
        if (!(o instanceof WeighInDO)) return false;
        WeighInDO weighInDO = (WeighInDO) o;
        return Objects.equals(weighInDisplayName, weighInDO.weighInDisplayName) &&
                Objects.equals(weighInStatus, weighInDO.weighInStatus) &&
                Objects.equals(selectedUserId, weighInDO.selectedUserId) &&
                Objects.equals(roleId, weighInDO.roleId);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof WeighInDO)) return false;
        WeighInDO weighInDO = (WeighInDO) o;
        return Objects.equals(weighInDisplayName, weighInDO.weighInDisplayName) &&
                Objects.equals(elementName, weighInDO.elementName) &&
                Objects.equals(weighInStatus, weighInDO.weighInStatus) &&
                Objects.equals(weighInResult, weighInDO.weighInResult) &&
                Objects.equals(selectedUserId, weighInDO.selectedUserId) &&
                Objects.equals(roleId, weighInDO.roleId) &&
                Objects.equals(weighInUsers, weighInDO.weighInUsers) &&
                Objects.equals(comments, weighInDO.comments);
    }

    @Override
    public int hashCode() {
        return Objects.hash(weighInDisplayName, elementName, weighInStatus, weighInResult, selectedUserId, roleId, weighInUsers, comments);
    }
}
