package dmles.equipment.server.datamodels.request.workflow.definition;

public class CriteriaCatalogItemDO {

    private String catalogID;
    private String catalogName;
    private Float totalCost;

    public String getCatalogID() {
        return catalogID;
    }

    public void setCatalogID(String catalogID) {
        this.catalogID = catalogID;
    }

    public String getCatalogName() {
        return catalogName;
    }

    public void setCatalogName(String catalogName) {
        this.catalogName = catalogName;
    }

    public Float getTotalCost() {
        return totalCost;
    }

    public void setTotalCost(Float totalCost) {
        this.totalCost = totalCost;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        CriteriaCatalogItemDO that = (CriteriaCatalogItemDO) o;

        if (!(catalogID == null && that.catalogID == null) ||
                (catalogID != null && !catalogID.equals(that.catalogID)))
            return false;
        if (!(catalogName == null && that.catalogName == null) ||
                (catalogName != null && catalogName.equals(that.catalogName)))
            return false;
        if (!(totalCost == null && that.totalCost == null) ||
                (totalCost != null && totalCost.equals(that.totalCost)))
            return false;
        return true;
    }

    @Override
    public int hashCode() {
        int result = catalogID != null ? catalogID.hashCode() : 0;
        result = 31 * result + (catalogName != null ? catalogName.hashCode() : 0);
        return result;
    }

}
