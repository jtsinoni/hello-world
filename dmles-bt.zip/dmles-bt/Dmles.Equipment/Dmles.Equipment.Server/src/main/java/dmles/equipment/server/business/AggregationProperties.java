package dmles.equipment.server.business;

////////////////////////////////////////////////////////////////////////////////
// TODO: NEEDS TO BE REFACTORED!!!!!!!!!!!!
// THIS CLASS NEEDS TO BE REFACTORED INTO A COMMON AREA SINCE IT IS/CAN BE USED
// BY MULTIPLE MODULES.
//------------------------------------------------------------------------------
// This class was copied to the Dmles.ABi.Server module and repackaged so we 
// will be ready for the March 3 Demo.
// This means that there are 2 copies of this code in the Business Tier!!!
////////////////////////////////////////////////////////////////////////////////

public class AggregationProperties {

    private String name;
    private String field;
    private String size;

    public AggregationProperties() {

    }

    public String describe() {
        StringBuilder sb = new StringBuilder();
        sb.append("AggregationProperties::-->");
        sb.append("\nname::").append(getName());
        sb.append("\nfield::").append(getField());
        sb.append("\nsize::").append(getSize());
        return sb.toString();
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the field
     */
    public String getField() {
        return field;
    }

    /**
     * @param field the field to set
     */
    public void setField(String field) {
        this.field = field;
    }

    /**
     * @return the size
     */
    public String getSize() {
        return size;
    }

    /**
     * @param size the size to set
     */
    public void setSize(String size) {
        this.size = size;
    }    
}