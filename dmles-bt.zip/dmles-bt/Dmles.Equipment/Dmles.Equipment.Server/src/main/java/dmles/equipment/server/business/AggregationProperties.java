/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dmles.equipment.server.business;

/**
 */
public class AggregationProperties {

    private String name;
    private String field;
    private String size;

    public AggregationProperties() {

    }

    public String describe() {
        StringBuilder sb = new StringBuilder();
        sb.append("AggregationProperties::-->");
        sb.append("\nname::").append(getName());
        sb.append("\nfield::").append(getField());
        sb.append("\nsize::").append(getSize());
        return sb.toString();
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the field
     */
    public String getField() {
        return field;
    }

    /**
     * @param field the field to set
     */
    public void setField(String field) {
        this.field = field;
    }

    /**
     * @return the size
     */
    public String getSize() {
        return size;
    }

    /**
     * @param size the size to set
     */
    public void setSize(String size) {
        this.size = size;
    }    
}