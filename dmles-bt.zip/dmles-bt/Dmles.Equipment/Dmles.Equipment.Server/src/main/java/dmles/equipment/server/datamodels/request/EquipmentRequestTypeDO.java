package dmles.equipment.server.datamodels.request;

import java.io.Serializable;
import mil.jmlfdc.common.datamodel.MorphiaEntity;
import org.mongodb.morphia.annotations.Entity;

import javax.validation.constraints.AssertTrue;
import javax.validation.constraints.NotNull;

@Entity("EquipRequestType")
public class EquipmentRequestTypeDO extends MorphiaEntity implements Serializable {

    private static final long serialVersionUID = 1L;
    @NotNull(message = "Request Type Code is required")
    private String code;
    @NotNull(message = "Request Type Name is required")
    private String name;

    public EquipmentRequestTypeDO() {
    }

    public EquipmentRequestTypeDO(String code, String name) {
        this.code = code;
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public void setName(String name) {
        this.name = name;
    }

}
