package dmles.equipment.server.business;

import dmles.common.business.nifi.NifiManager;
import dmles.equipment.core.datamodels.record.EquipmentRecord;
import dmles.equipment.server.dao.EquipmentRecordDao;
import dmles.equipment.server.datamodels.record.EquipmentRecordDO;
import mil.jmlfdc.common.constants.DateAndTime;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.ejb.Stateless;
import javax.inject.Inject;
import mil.jmlfdc.common.business.BusinessManager;
import mil.jmlfdc.common.utils.ObjectMapper;
import org.json.simple.JSONObject;

@Stateless
public class EquipmentRecordManager extends BusinessManager {

    @Inject
    private EquipmentRecordDao equipmentRecordDao;

    @Inject
    private ObjectMapper objectMapper;

    @Inject
    NifiManager nifiManager;

    
    public long getEquipmentRecordsCount() {
        long erCount = equipmentRecordDao.countAll();
        return erCount;
    }


    public EquipmentRecord findRecord(String dodaac, int meId) {
        List<EquipmentRecordDO> recordsFound = equipmentRecordDao.findRecord(dodaac, meId);
        EquipmentRecordDO returnRecord = new EquipmentRecordDO();
        if (recordsFound.size() > 0) {
            returnRecord = recordsFound.get(0);
        }

        EquipmentRecord erec = objectMapper.getObject(EquipmentRecord.class, returnRecord);
        return erec;
    }

    public List<EquipmentRecord> findRecords(String dodaac, int meId) {
        List<EquipmentRecordDO> dbRecords = equipmentRecordDao.findRecord(dodaac, meId);
        List<EquipmentRecord> returnRecords = objectMapper.getList(EquipmentRecord[].class, dbRecords);

        return returnRecords;
    }



    public Long getSiteEquipmentRecordByMeId(String siteDoDAAC,String meID) {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("DODAAC", siteDoDAAC);
        jsonObject.put("MEID", meID);
        String jsonString = jsonObject.toString();

        nifiManager.getEquipmentRecordFromDmlss(jsonString);

        return null;
    }


    public Long getSiteEquipmentRecordByItemId(String siteDoDAAC,String itemId) {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("DODAAC", siteDoDAAC);
        jsonObject.put("ItemID", itemId);
        String jsonString = jsonObject.toString();

        nifiManager.getEquipmentRecordFromDmlss(jsonString);

        return null;
    }


    public Long getSiteEquipmentRecordAfterDate(String siteDoDAAC,Date modifiedDate) {
        SimpleDateFormat modifiedDt = new SimpleDateFormat(DateAndTime.DATE_PATTERN);
        String dateString = modifiedDt.format(modifiedDate);

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("DODAAC", siteDoDAAC);
        jsonObject.put("ModifiedDate", dateString);
        String jsonString = jsonObject.toString();

        nifiManager.getEquipmentRecordFromDmlss(jsonString);
        return null;
    }


    public Long getSiteEquipmentRecordAll(String siteDoDAAC) {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("DODAAC", siteDoDAAC);
        String jsonString = jsonObject.toString();
        nifiManager.getEquipmentRecordFromDmlss(jsonString);
        return null;
    }



}
