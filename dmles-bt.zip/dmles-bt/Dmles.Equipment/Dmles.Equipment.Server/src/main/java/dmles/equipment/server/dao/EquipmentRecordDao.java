/*
 // ==========================================================================
 //       NOTICE:  THIS SOFTWARE WAS DEVELOPED UNDER CONTRACT
 //        TO THE U.S. GOVERNMENT, WHICH RESERVES ALL SOURCE
 //             RIGHTS AND FULL TECHNICAL DATA RIGHTS.
 // ==========================================================================
 //
 */
package dmles.equipment.server.dao;

import dmles.equipment.server.datamodels.record.EquipmentRecordDO;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.enterprise.context.Dependent;
import mil.jmlfdc.common.dao.BaseDao;
import mil.jmlfdc.common.dao.DataStore;

/**
 *
 * @author matthew.roberts
 */
@Dependent
public class EquipmentRecordDao extends BaseDao<EquipmentRecordDO, String> {

    public EquipmentRecordDao() {
        super(EquipmentRecordDO.class);
    }
    
    protected void setDatastore(DataStore datastore) {
        super.setDatastore(datastore);
    }
    
    public <T> List<EquipmentRecordDO> findRecord(T dodaac, T meId) {
    	
    	Map<String, T> fieldFilter = new HashMap<>();
    	fieldFilter.put("siteDoDDAC", dodaac);
    	fieldFilter.put("meId", meId);
    	
        return  this.query(fieldFilter);
    }

}