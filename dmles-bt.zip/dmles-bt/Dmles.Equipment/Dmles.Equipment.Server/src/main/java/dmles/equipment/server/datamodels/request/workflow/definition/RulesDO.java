package dmles.equipment.server.datamodels.request.workflow.definition;

public class RulesDO {
    private boolean allowWeighInBypassOnApprove;
    private boolean allowWeighInSelection;
    private boolean allowForceUp;
    private boolean allowAutoApproveAfterWeighIn;
    private boolean allowModify;
    private boolean allowReject;
    private boolean allowHold;
    private boolean allowRework;
    private boolean allowRequestCancel;
    private boolean allowCancel;
    private boolean allowOwnerOverrideNegativeWeighIns;
    private boolean allowRetract;
    private boolean allowNoteConcern;

    public Boolean getAllowWeighInBypassOnApprove() {
        return allowWeighInBypassOnApprove;
    }

    public void setAllowWeighInBypassOnApprove(Boolean allowWeighInBypassOnApprove) {
        this.allowWeighInBypassOnApprove = allowWeighInBypassOnApprove;
    }

    public Boolean getAllowWeighInSelection() {
        return allowWeighInSelection;
    }

    public void setAllowWeighInSelection(Boolean allowWeighInSelection) {
        this.allowWeighInSelection = allowWeighInSelection;
    }

    public Boolean getAllowForceUp() {
        return allowForceUp;
    }

    public void setAllowForceUp(Boolean allowForceUp) {
        this.allowForceUp = allowForceUp;
    }

    public Boolean getAllowAutoApproveAfterWeighIn() {
        return allowAutoApproveAfterWeighIn;
    }

    public void setAllowAutoApproveAfterWeighIn(Boolean allowAutoApproveAfterWeighIn) {
        this.allowAutoApproveAfterWeighIn = allowAutoApproveAfterWeighIn;
    }

    public Boolean getAllowModify() {
        return allowModify;
    }

    public void setAllowModify(Boolean allowModify) {
        this.allowModify = allowModify;
    }

    public Boolean getAllowReject() {
        return allowReject;
    }

    public void setAllowReject(Boolean allowReject) {
        this.allowReject = allowReject;
    }

    public Boolean getAllowHold() {
        return allowHold;
    }

    public void setAllowHold(Boolean allowHold) {
        this.allowHold = allowHold;
    }

    public Boolean getAllowRework() {
        return allowRework;
    }

    public void setAllowRework(Boolean allowRework) {
        this.allowRework = allowRework;
    }

    public Boolean getAllowRequestCancel() {
        return allowRequestCancel;
    }

    public void setAllowRequestCancel(Boolean allowRequestCancel) {
        this.allowRequestCancel = allowRequestCancel;
    }

    public Boolean getAllowCancel() {
        return allowCancel;
    }

    public void setAllowCancel(Boolean allowCancel) {
        this.allowCancel = allowCancel;
    }

    public Boolean getAllowOwnerOverrideNegativeWeighIns() {
        return allowOwnerOverrideNegativeWeighIns;
    }

    public void setAllowOwnerOverrideNegativeWeighIns(Boolean allowOwnerOverrideNegativeWeighIns) {
        this.allowOwnerOverrideNegativeWeighIns = allowOwnerOverrideNegativeWeighIns;
    }

    public Boolean getAllowRetract() {
        return allowRetract;
    }

    public void setAllowRetract(Boolean allowRetract) {
        this.allowRetract = allowRetract;
    }

    public Boolean getAllowNoteConcern() {
        return allowNoteConcern;
    }

    public void setAllowNoteConcern(Boolean allowNoteConcern) {
        this.allowNoteConcern = allowNoteConcern;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        RulesDO rulesDO = (RulesDO) o;

        if (allowWeighInBypassOnApprove != rulesDO.allowWeighInBypassOnApprove) return false;
        if (allowWeighInSelection != rulesDO.allowWeighInSelection) return false;
        if (allowForceUp != rulesDO.allowForceUp) return false;
        if (allowAutoApproveAfterWeighIn != rulesDO.allowAutoApproveAfterWeighIn) return false;
        if (allowModify != rulesDO.allowModify) return false;
        if (allowReject != rulesDO.allowReject) return false;
        if (allowHold != rulesDO.allowHold) return false;
        if (allowRework != rulesDO.allowRework) return false;
        if (allowRequestCancel != rulesDO.allowRequestCancel) return false;
        if (allowCancel != rulesDO.allowCancel) return false;
        if (allowOwnerOverrideNegativeWeighIns != rulesDO.allowOwnerOverrideNegativeWeighIns) return false;
        if (allowRetract != rulesDO.allowRetract) return false;
        return allowNoteConcern == rulesDO.allowNoteConcern;

    }

    @Override
    public int hashCode() {
        int result = (allowWeighInBypassOnApprove ? 1 : 0);
        result = 31 * result + (allowWeighInSelection ? 1 : 0);
        result = 31 * result + (allowForceUp ? 1 : 0);
        result = 31 * result + (allowAutoApproveAfterWeighIn ? 1 : 0);
        result = 31 * result + (allowModify ? 1 : 0);
        result = 31 * result + (allowReject ? 1 : 0);
        result = 31 * result + (allowHold ? 1 : 0);
        result = 31 * result + (allowRework ? 1 : 0);
        result = 31 * result + (allowRequestCancel ? 1 : 0);
        result = 31 * result + (allowCancel ? 1 : 0);
        result = 31 * result + (allowOwnerOverrideNegativeWeighIns ? 1 : 0);
        result = 31 * result + (allowRetract ? 1 : 0);
        result = 31 * result + (allowNoteConcern ? 1 : 0);
        return result;
    }
}
