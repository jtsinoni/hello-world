package dmles.equipment.server.datamodels.record;

import org.mongodb.morphia.annotations.Embedded;

import java.io.Serializable;

@Embedded
public class MaintCostDO implements Serializable {
    private static final long serialVersionUID = 1L;
    private String mcFiscalYearTm;
    private Integer mcDownTime;
    private Integer mcUnschdWoQty;
    private Float mcOPartCostAmt;
    private Float mcOUTimeQty;
    private Float mcOULabCstAmt;
    private Float mcOSTimeQty;
    private Float mcOSLabCstAmt;
    private Float mcCPartCostAmt;
    private Integer mcCUTimeQty;
    private Float mcCULabCstAmt;
    private Integer mcCSTimeQty;
    private Float mcCSLabCstAmt;

    public String getMcFiscalYearTm() {
        return mcFiscalYearTm;
    }

    public void setMcFiscalYearTm(String mcFiscalYearTm) {
        this.mcFiscalYearTm = mcFiscalYearTm;
    }

    public Integer getMcDownTime() {
        return mcDownTime;
    }

    public void setMcDownTime(Integer mcDownTime) {
        this.mcDownTime = mcDownTime;
    }

    public Integer getMcUnschdWoQty() {
        return mcUnschdWoQty;
    }

    public void setMcUnschdWoQty(Integer mcUnschdWoQty) {
        this.mcUnschdWoQty = mcUnschdWoQty;
    }

    public Float getMcOPartCostAmt() {
        return mcOPartCostAmt;
    }

    public void setMcOPartCostAmt(Float mcOPartCostAmt) {
        this.mcOPartCostAmt = mcOPartCostAmt;
    }

    public Float getMcOUTimeQty() {
        return mcOUTimeQty;
    }

    public void setMcOUTimeQty(Float mcOUTimeQty) {
        this.mcOUTimeQty = mcOUTimeQty;
    }

    public Float getMcOULabCstAmt() {
        return mcOULabCstAmt;
    }

    public void setMcOULabCstAmt(Float mcOULabCstAmt) {
        this.mcOULabCstAmt = mcOULabCstAmt;
    }

    public Float getMcOSTimeQty() {
        return mcOSTimeQty;
    }

    public void setMcOSTimeQty(Float mcOSTimeQty) {
        this.mcOSTimeQty = mcOSTimeQty;
    }

    public Float getMcOSLabCstAmt() {
        return mcOSLabCstAmt;
    }

    public void setMcOSLabCstAmt(Float mcOSLabCstAmt) {
        this.mcOSLabCstAmt = mcOSLabCstAmt;
    }

    public Float getMcCPartCostAmt() {
        return mcCPartCostAmt;
    }

    public void setMcCPartCostAmt(Float mcCPartCostAmt) {
        this.mcCPartCostAmt = mcCPartCostAmt;
    }

    public Integer getMcCUTimeQty() {
        return mcCUTimeQty;
    }

    public void setMcCUTimeQty(Integer mcCUTimeQty) {
        this.mcCUTimeQty = mcCUTimeQty;
    }

    public Float getMcCULabCstAmt() {
        return mcCULabCstAmt;
    }

    public void setMcCULabCstAmt(Float mcCULabCstAmt) {
        this.mcCULabCstAmt = mcCULabCstAmt;
    }

    public Integer getMcCSTimeQty() {
        return mcCSTimeQty;
    }

    public void setMcCSTimeQty(Integer mcCSTimeQty) {
        this.mcCSTimeQty = mcCSTimeQty;
    }

    public Float getMcCSLabCstAmt() {
        return mcCSLabCstAmt;
    }

    public void setMcCSLabCstAmt(Float mcCSLabCstAmt) {
        this.mcCSLabCstAmt = mcCSLabCstAmt;
    }
}