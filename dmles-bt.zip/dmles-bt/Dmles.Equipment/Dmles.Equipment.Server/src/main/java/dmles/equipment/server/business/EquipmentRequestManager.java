package dmles.equipment.server.business;

import dmles.equipment.core.datamodels.request.CriticalCode;
import dmles.equipment.core.datamodels.request.CriticalCodes;
import dmles.equipment.core.datamodels.request.Device;
import dmles.equipment.core.datamodels.request.EquipmentCriticality;
import dmles.equipment.core.datamodels.request.EquipmentManufacturer;
import dmles.equipment.core.datamodels.request.EquipmentMountingType;
import dmles.equipment.core.datamodels.request.EquipmentRequest;
import dmles.equipment.core.datamodels.request.EquipmentRequestReason;
import dmles.equipment.core.datamodels.request.EquipmentRequestType;
import dmles.equipment.core.datamodels.request.EquipmentTraineeType;
import dmles.equipment.core.datamodels.request.LiteratureType;
import dmles.equipment.core.datamodels.request.Specialty;
import dmles.equipment.core.datamodels.request.TraineeLocationType;
import dmles.equipment.server.dao.CriticalCodeDao;
import dmles.equipment.server.dao.DeviceDao;
import dmles.equipment.server.dao.EquipmentCriticalityDao;
import dmles.equipment.server.dao.EquipmentMaintenanceTypesDao;
import dmles.equipment.server.dao.EquipmentManufacturerDao;
import dmles.equipment.server.dao.EquipmentMountingTypeDao;
import dmles.equipment.server.dao.EquipmentRequestDao;
import dmles.equipment.server.dao.EquipmentRequestReasonDao;
import dmles.equipment.server.dao.EquipmentRequestTypeDao;
import dmles.equipment.server.dao.EquipmentTraineeTypeDao;
import dmles.equipment.server.dao.LiteratureTypeDao;
import dmles.equipment.server.dao.SpecialtyDao;
import dmles.equipment.server.dao.TraineeLocationTypeDao;
import dmles.equipment.server.datamodels.request.CriticalCodeDO;
import dmles.equipment.server.datamodels.request.CriticalCodesDO;
import dmles.equipment.server.datamodels.request.DeviceDO;
import dmles.equipment.server.datamodels.request.EquipmentCriticalityDO;
import dmles.equipment.server.datamodels.request.EquipmentManufacturerDO;
import dmles.equipment.server.datamodels.request.EquipmentMountingTypeDO;
import dmles.equipment.server.datamodels.request.EquipmentRequestDO;
import dmles.equipment.server.datamodels.request.EquipmentRequestReasonDO;
import dmles.equipment.server.datamodels.request.EquipmentRequestTypeDO;
import dmles.equipment.server.datamodels.request.EquipmentTraineeTypeDO;
import dmles.equipment.server.datamodels.request.LiteratureTypeDO;
import dmles.equipment.server.datamodels.request.RequestInformationDO;
import dmles.equipment.server.datamodels.request.SpecialtyDO;
import dmles.equipment.server.datamodels.request.TraineeLocationTypeDO;
import dmles.oauth.core.datamodel.CurrentUserBT;
import mil.jmlfdc.common.business.BusinessManager;
import mil.jmlfdc.common.exception.ObjectNotFoundException;
import mil.jmlfdc.common.utils.ObjectMapper;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.validation.constraints.NotNull;

@Stateless
public class EquipmentRequestManager extends BusinessManager {

    @Inject
    private CriticalCodeDao criticalCodeDao;
    @Inject 
    private EquipmentMaintenanceTypesDao equipmentMaintenanceTypeDao;
    @Inject
    private DeviceDao deviceDao;
    @Inject
    private EquipmentCriticalityDao equipmentCriticalityDao;
    @Inject
    private EquipmentManufacturerDao equipmentManufacturerDao;
    @Inject
    private EquipmentMountingTypeDao equipmentMountingTypeDao;
    @Inject
    private EquipmentRequestDao equipmentRequestDao;
    @Inject
    private EquipmentRequestReasonDao equipmentRequestReasonDao;
    @Inject
    private EquipmentRequestTypeDao equipmentRequestTypeDao;
    @Inject
    private LiteratureTypeDao literatureTypeDao;
    @Inject
    private EquipmentTraineeTypeDao equipmentTraineeTypeDao;
    @Inject
    private SpecialtyDao specialtyDao;
    @Inject
    private TraineeLocationTypeDao traineeLocationTypeDao;
    @Inject
    private EquipmentRequestFetcher requestFetcher;
    @Inject
    private ObjectMapper objectMapper;
    @Inject
    private WorkflowHistoryManager history;
    @Inject
    private CurrentUserBT currentUserBt;

    public List<EquipmentRequestType> getEquipmentRequestTypes() {
        List<EquipmentRequestTypeDO> ertDos = equipmentRequestTypeDao.findAll();
        List<EquipmentRequestType>  erts = objectMapper.getList(EquipmentRequestType[].class, ertDos);
        return erts;        
    }

    public List<EquipmentRequestReason> getEquipmentRequestReasons() {

        List<EquipmentRequestReasonDO> errDos = equipmentRequestReasonDao.findAll();
        List<EquipmentRequestReason>  errs = objectMapper.getList(EquipmentRequestReason[].class, errDos);
        return errs;
    }

    public List<EquipmentRequest> getAllEquipmentRequests() {
        List<EquipmentRequestDO> erDos = equipmentRequestDao.findAll();
        List<EquipmentRequest>  ers = objectMapper.getList(EquipmentRequest[].class, erDos);
        return ers;
    }
    
    public List<CriticalCode> getCriticalCodes(String serviceAgencyCode) {
        List<CriticalCodeDO> recordsFound;
        if (serviceAgencyCode == null || serviceAgencyCode.isEmpty()){
            recordsFound = criticalCodeDao.findAll();    
        } else {
            recordsFound = criticalCodeDao.findByServiceAgencyCode(serviceAgencyCode);
        }
        List<CriticalCode> cCodes = objectMapper.getList(CriticalCode[].class, recordsFound);
        return cCodes;
    }

    public List<CriticalCodes> getCriticalCodesByServiceAgencyCode(String serviceAgencyCode) {
        List<CriticalCodesDO> recordsFound = new ArrayList<>();
        recordsFound = criticalCodeDao.findCodesByServiceAgencyCode(serviceAgencyCode);
        List<CriticalCodes> cCodes = objectMapper.getList(CriticalCodes[].class, recordsFound);
        return cCodes;
    }

    public List<String> getEquipmentMaintenanceTypes(String serviceAgency) {
        List<String> recordsFound = equipmentMaintenanceTypeDao.findMaintenanceCodes(serviceAgency);
        return recordsFound;
    }
    
    public List<Device> getDevices() {
        List<DeviceDO> deviceDos = deviceDao.findCodeAndText();
        List<Device> devices = objectMapper.getList(Device[].class, deviceDos);
        return devices;
    }

    public List<EquipmentCriticality> getEquipmentCriticalities() {
        List<EquipmentCriticalityDO> ecDo = equipmentCriticalityDao.findAll();
        List<EquipmentCriticality> equipCrits = objectMapper.getList(EquipmentCriticality[].class, ecDo);
        return equipCrits;
    }

    public List<EquipmentManufacturer> getEquipmentManufacturers() {
        List<EquipmentManufacturerDO> emDos = equipmentManufacturerDao.findCodeAndText();
        List<EquipmentManufacturer> eman = objectMapper.getList(EquipmentManufacturer[].class, emDos);
        return eman;
    }

    public List<EquipmentMountingType> getEquipmentMountingTypes() {
        List<EquipmentMountingTypeDO> eMountTypeDos = equipmentMountingTypeDao.findAll();
        List<EquipmentMountingType> eMountTypes = objectMapper.getList(EquipmentMountingType[].class, eMountTypeDos);
        return eMountTypes;
    }

    public EquipmentRequest getEquipmentRequest(String id) {
        EquipmentRequestDO ereqDo = equipmentRequestDao.findById(id);
        EquipmentRequest ereq = objectMapper.getObject(EquipmentRequest.class, ereqDo);
        return ereq;
    }
    
    public List<EquipmentRequest> getEquipmentRequests() {
        List<EquipmentRequestDO> requestDOListIn = requestFetcher.getRequestsPerUserType(); 
        List<EquipmentRequest> requestDOListOut = objectMapper.getList(EquipmentRequest[].class, requestDOListIn);
        return requestDOListOut;
    }    

    public List<EquipmentTraineeType> getEquipmentTraineeTypes() {
        List<EquipmentTraineeTypeDO> ettDos = equipmentTraineeTypeDao.findAll();
        List<EquipmentTraineeType> etts = objectMapper.getList(EquipmentTraineeType[].class, ettDos);
        return etts;
    }

    public List<LiteratureType> getLiteratureTypes() {
        List<LiteratureTypeDO> litTypeDos = literatureTypeDao.findAll();
        List<LiteratureType> litTypes = objectMapper.getList(LiteratureType[].class, litTypeDos);
        return litTypes;
    }

    public List<Specialty> getSpecialties() {
        List<SpecialtyDO> specDos = specialtyDao.findAll();
        List<Specialty> spec = objectMapper.getList(Specialty[].class, specDos);
        return spec;
    }

    public List<TraineeLocationType> getTraineeLocationTypes() {
        List<TraineeLocationTypeDO> tltypeDos = traineeLocationTypeDao.findAll();
        List<TraineeLocationType> tltypes = objectMapper.getList(TraineeLocationType[].class, tltypeDos);
        return tltypes;
    }

    public List<EquipmentRequestReason> testRemoteMtf() {
        MtfPortal mtfPortal = new MtfPortal(MtfSites.Bamc);
        List<EquipmentRequestReasonDO> ereqReqsDos = mtfPortal.getEquipmentRequestReasons();
        List<EquipmentRequestReason> ereqReqs = objectMapper.getList(EquipmentRequestReason[].class,ereqReqsDos);
        return ereqReqs;
    }

    public EquipmentRequest saveRequest(@NotNull EquipmentRequest request) throws ObjectNotFoundException {
        EquipmentRequestDO equipReqDO = objectMapper.getObject(EquipmentRequestDO.class, request);

        equipmentRequestDao.upsert(equipReqDO);

        return objectMapper.getObject(EquipmentRequest.class, equipReqDO);
    }

    public EquipmentRequest saveRequestInfo(@NotNull EquipmentRequest request) throws ObjectNotFoundException {
        EquipmentRequestDO reqIn = objectMapper.getObject(EquipmentRequestDO.class, request);
        EquipmentRequestDO requestDO = equipmentRequestDao.findById(request.id);

        RequestInformationDO riIn = reqIn.getRequestInformation();
        RequestInformationDO riDo = requestDO.getRequestInformation();

        riDo.setRequestTitle(riIn.getRequestTitle());
        riDo.setRequestNumber(riIn.getRequestNumber());
        riDo.setRequestType(riIn.getRequestType());
        riDo.setRequestReason(riIn.getRequestReason());
        riDo.setCriticalCode(riIn.getCriticalCode());
        riDo.setReplacedItems(riIn.getReplacedItems());
        riDo.setMissionImpact(riIn.getMissionImpact());
        riDo.setDescription(riIn.getDescription());
        riDo.setRequestedDeliveryDate(riIn.getRequestedDeliveryDate());
        riDo.setRequestedDeliveryDateReason(riIn.getRequestedDeliveryDateReason());

        saveCommonlyChangedData(reqIn, requestDO, "Save Request Info");

        equipmentRequestDao.update(requestDO);

        return objectMapper.getObject(EquipmentRequest.class, requestDO);
    }

    public EquipmentRequest saveRequestCustomerInfo(@NotNull EquipmentRequest request) throws ObjectNotFoundException {
        EquipmentRequestDO reqIn = objectMapper.getObject(EquipmentRequestDO.class, request);
        EquipmentRequestDO requestDO = equipmentRequestDao.findById(request.id);

        RequestInformationDO riIn = reqIn.getRequestInformation();
        RequestInformationDO riDo = requestDO.getRequestInformation();

        riDo.setOrganization(riIn.getOrganization());
        riDo.setCustomer(riIn.getCustomer());
        riDo.setRequester(riIn.getRequester());

        saveCommonlyChangedData(reqIn, requestDO, "Save Customer Info");

        equipmentRequestDao.update(requestDO);

        return objectMapper.getObject(EquipmentRequest.class, requestDO);
    }

    public EquipmentRequest saveRequestEquipmentInfo(@NotNull EquipmentRequest request) throws ObjectNotFoundException {
        EquipmentRequestDO reqIn = objectMapper.getObject(EquipmentRequestDO.class, request);
        EquipmentRequestDO requestDO = equipmentRequestDao.findById(request.id);

        RequestInformationDO riIn = reqIn.getRequestInformation();
        RequestInformationDO riDo = requestDO.getRequestInformation();

        riDo.setEquipment(riIn.getEquipment());
        riDo.setCatalogItem(riIn.getCatalogItem());
        riDo.setQuantityRequested(riIn.getQuantityRequested());
        riDo.setEquipmentRequirements(riIn.getEquipmentRequirements());

        saveCommonlyChangedData(reqIn, requestDO, "Save Equipment Info");

        equipmentRequestDao.update(requestDO);

        return objectMapper.getObject(EquipmentRequest.class, requestDO);
    }

    public EquipmentRequest saveRequestExtraItems(@NotNull EquipmentRequest request) throws ObjectNotFoundException {
        EquipmentRequestDO reqIn = objectMapper.getObject(EquipmentRequestDO.class, request);
        EquipmentRequestDO requestDO = equipmentRequestDao.findById(request.id);

        RequestInformationDO riIn = reqIn.getRequestInformation();
        RequestInformationDO riDo = requestDO.getRequestInformation();

        riDo.setExtraItems(riIn.getExtraItems());

        saveCommonlyChangedData(reqIn, requestDO, "Save Extra Items");

        equipmentRequestDao.update(requestDO);

        return objectMapper.getObject(EquipmentRequest.class, requestDO);
    }

    public EquipmentRequest saveRequestSourceOfSupply(@NotNull EquipmentRequest request) throws ObjectNotFoundException {
        EquipmentRequestDO reqIn = objectMapper.getObject(EquipmentRequestDO.class, request);
        EquipmentRequestDO requestDO = equipmentRequestDao.findById(request.id);

        RequestInformationDO riIn = reqIn.getRequestInformation();
        RequestInformationDO riDo = requestDO.getRequestInformation();

        riDo.setSuggestedSources(riIn.getSuggestedSources());

        saveCommonlyChangedData(reqIn, requestDO, "Save Source of Supply");

        equipmentRequestDao.update(requestDO);

        return objectMapper.getObject(EquipmentRequest.class, requestDO);
    }

    public EquipmentRequest saveRequestTraining(@NotNull EquipmentRequest request) throws ObjectNotFoundException {
        EquipmentRequestDO reqIn = objectMapper.getObject(EquipmentRequestDO.class, request);
        EquipmentRequestDO requestDO = equipmentRequestDao.findById(request.id);

        RequestInformationDO riIn = reqIn.getRequestInformation();
        RequestInformationDO riDo = requestDO.getRequestInformation();

        riDo.setTraining(riIn.getTraining());

        saveCommonlyChangedData(reqIn, requestDO, "Save Training Info");

        equipmentRequestDao.update(requestDO);

        return objectMapper.getObject(EquipmentRequest.class, requestDO);
    }

    public EquipmentRequest saveFacilities(@NotNull EquipmentRequest request) throws ObjectNotFoundException {
        EquipmentRequestDO reqIn = objectMapper.getObject(EquipmentRequestDO.class, request);
        EquipmentRequestDO requestDO = equipmentRequestDao.findById(request.id);

        requestDO.setFacilityInformation(reqIn.getFacilityInformation());
        saveCommonlyChangedData(reqIn, requestDO, "Save Facilities Info");

        equipmentRequestDao.update(requestDO);

        return objectMapper.getObject(EquipmentRequest.class, requestDO);
    }

    public EquipmentRequest saveMaintenance(@NotNull EquipmentRequest request) throws ObjectNotFoundException {
        EquipmentRequestDO reqIn = objectMapper.getObject(EquipmentRequestDO.class, request);
        EquipmentRequestDO requestDO = equipmentRequestDao.findById(request.id);

        requestDO.setMaintenanceInformation(reqIn.getMaintenanceInformation());
        requestDO.getRequestInformation().setTraining(reqIn.getRequestInformation().getTraining());
        saveCommonlyChangedData(reqIn, requestDO, "Save Maintenance Info");

        equipmentRequestDao.update(requestDO);

        return objectMapper.getObject(EquipmentRequest.class, requestDO);
    }

    public EquipmentRequest saveSafety(@NotNull EquipmentRequest request) throws ObjectNotFoundException {
        EquipmentRequestDO reqIn = objectMapper.getObject(EquipmentRequestDO.class, request);
        EquipmentRequestDO requestDO = equipmentRequestDao.findById(request.id);

        requestDO.setSafetyInformation(reqIn.getSafetyInformation());
        saveCommonlyChangedData(reqIn, requestDO, "Save Safety Info");

        equipmentRequestDao.update(requestDO);

        return objectMapper.getObject(EquipmentRequest.class, requestDO);
    }

    public EquipmentRequest saveTechnology(@NotNull EquipmentRequest request) throws ObjectNotFoundException {
        EquipmentRequestDO reqIn = objectMapper.getObject(EquipmentRequestDO.class, request);
        EquipmentRequestDO requestDO = equipmentRequestDao.findById(request.id);

        requestDO.setTechnologyInformation(reqIn.getTechnologyInformation());
        saveCommonlyChangedData(reqIn, requestDO, "Save Technology Info");

        equipmentRequestDao.update(requestDO);

        return objectMapper.getObject(EquipmentRequest.class, requestDO);
    }

    private void saveCommonlyChangedData(EquipmentRequestDO reqIn, EquipmentRequestDO requestDo, String section) {

        requestDo.setAttachments(reqIn.getAttachments());
        requestDo.setNotes(reqIn.getNotes());
        requestDo.setTotalPrice(reqIn.getTotalPrice());
        requestDo.setUpdatedBy(currentUserBt.getFullName());
        requestDo.setUpdatedDate(new Date());
        String levelName = requestDo.getWfProcessing().getCurrentLevel().getLevelName();
        history.addHistory(requestDo, levelName, "DataChange", section);

    }

    @Override
    public String getRequestorId() {
        return currentUserBt.getProfileId();
    }

    @Override
    public String getRequestorName() {
        return currentUserBt.getFullName();
    }
    

}
