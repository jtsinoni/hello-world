package dmles.equipment.server.business;

import dmles.equipment.core.datamodels.request.RequestCriticality;
import dmles.equipment.core.datamodels.request.CriticalCodes;
import dmles.equipment.core.datamodels.request.Device;
import dmles.equipment.core.datamodels.request.EquipmentCriticality;
import dmles.equipment.core.datamodels.request.EquipmentManufacturer;
import dmles.equipment.core.datamodels.request.EquipmentMountingType;
import dmles.equipment.core.datamodels.request.EquipmentRequest;
import dmles.equipment.core.datamodels.request.EquipmentRequestDashBoard;
import dmles.equipment.core.datamodels.request.EquipmentRequestReason;
import dmles.equipment.core.datamodels.request.EquipmentRequestType;
import dmles.equipment.core.datamodels.request.EquipmentTraineeType;
import dmles.equipment.core.datamodels.request.LiteratureType;
import dmles.equipment.core.datamodels.request.Specialty;
import dmles.equipment.core.datamodels.request.TraineeLocationType;
import dmles.equipment.core.datamodels.request.workflow.definition.WorkflowLevelDefinition;
import dmles.equipment.server.dao.CriticalCodeDao;
import dmles.equipment.server.dao.DeviceDao;
import dmles.equipment.server.dao.EquipmentCriticalityDao;
import dmles.equipment.server.dao.EquipmentMaintenanceTypesDao;
import dmles.equipment.server.dao.EquipmentManufacturerDao;
import dmles.equipment.server.dao.EquipmentMountingTypeDao;
import dmles.equipment.server.dao.EquipmentRequestDao;
import dmles.equipment.server.dao.EquipmentRequestReasonDao;
import dmles.equipment.server.dao.EquipmentRequestTypeDao;
import dmles.equipment.server.dao.EquipmentTraineeTypeDao;
import dmles.equipment.server.dao.LiteratureTypeDao;
import dmles.equipment.server.dao.SpecialtyDao;
import dmles.equipment.server.dao.TraineeLocationTypeDao;
import dmles.equipment.server.datamodels.request.RequestCriticalityDO;
import dmles.equipment.server.datamodels.request.CriticalCodesDO;
import dmles.equipment.server.datamodels.request.DeviceDO;
import dmles.equipment.server.datamodels.request.EquipmentCriticalityDO;
import dmles.equipment.server.datamodels.request.EquipmentManufacturerDO;
import dmles.equipment.server.datamodels.request.EquipmentMountingTypeDO;
import dmles.equipment.server.datamodels.request.EquipmentRequestDO;
import dmles.equipment.server.datamodels.request.EquipmentRequestReasonDO;
import dmles.equipment.server.datamodels.request.EquipmentRequestTypeDO;
import dmles.equipment.server.datamodels.request.EquipmentTraineeTypeDO;
import dmles.equipment.server.datamodels.request.LiteratureTypeDO;
import dmles.equipment.server.datamodels.request.MaintenanceInformationDO;
import dmles.equipment.server.datamodels.request.RequestInformationDO;
import dmles.equipment.server.datamodels.request.SpecialtyDO;
import dmles.equipment.server.datamodels.request.TraineeLocationTypeDO;
import mil.jmlfdc.common.datamodel.CurrentUserBT;
import dmles.user.core.clientmodel.Role;
import dmles.user.client.UserService;
import dmles.user.core.IUserService;
import dmles.user.core.clientmodel.UserProfile;
import mil.jmlfdc.common.datamodel.UserType;
import mil.jmlfdc.common.business.BusinessManager;
import mil.jmlfdc.common.exception.ObjectNotFoundException;
import mil.jmlfdc.common.utils.ObjectMapper;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.validation.constraints.NotNull;
import org.slf4j.Logger;

@Stateless
public class EquipmentRequestManager extends BusinessManager {

    @Inject Logger log;

    @Inject
    private CriticalCodeDao criticalCodeDao;
    @Inject
    private EquipmentMaintenanceTypesDao equipmentMaintenanceTypeDao;
    @Inject
    private DeviceDao deviceDao;
    @Inject
    private EquipmentCriticalityDao equipmentCriticalityDao;
    @Inject
    private EquipmentManufacturerDao equipmentManufacturerDao;
    @Inject
    private EquipmentMountingTypeDao equipmentMountingTypeDao;
    @Inject
    private EquipmentRequestDao equipmentRequestDao;
    @Inject
    private EquipmentRequestReasonDao equipmentRequestReasonDao;
    @Inject
    private EquipmentRequestTypeDao equipmentRequestTypeDao;
    @Inject
    private LiteratureTypeDao literatureTypeDao;
    @Inject
    private EquipmentTraineeTypeDao equipmentTraineeTypeDao;
    @Inject
    private SpecialtyDao specialtyDao;
    @Inject
    private TraineeLocationTypeDao traineeLocationTypeDao;
    @Inject
    private EquipmentRequestFetcher requestFetcher;
    @Inject
    @UserService
    private IUserService userService;
    @Inject
    private ObjectMapper objectMapper;
    @Inject
    private WorkflowHistoryManager history;
    @Inject
    private WorkflowProcessingManager wfProcManager;

    public EquipmentRequestDashBoard buildEquipmentDashboardStats() throws ObjectNotFoundException {
        EquipmentRequestDashBoard dashBoard = new EquipmentRequestDashBoard();
        List<EquipmentRequest> requests = getEquipmentRequests();
        dashBoard.activeRequests = getNumberOfActiveEquipmentRequests(requests);
        dashBoard.newRequests = getNumberOfNewEquipmentRequests(requests);
        dashBoard.pendingActions = getNumberOfPendingEquipmentRequests(requests);
        return dashBoard;
    }
    public List<EquipmentRequestType> getEquipmentRequestTypes() {
        List<EquipmentRequestTypeDO> ertDos = equipmentRequestTypeDao.findAll();
        List<EquipmentRequestType>  erts = objectMapper.getList(EquipmentRequestType[].class, ertDos);
        return erts;
    }

    public List<EquipmentRequestReason> getEquipmentRequestReasons() {

        List<EquipmentRequestReasonDO> errDos = equipmentRequestReasonDao.findAll();
        List<EquipmentRequestReason>  errs = objectMapper.getList(EquipmentRequestReason[].class, errDos);
        return errs;
    }

    public Integer getNumberOfActiveEquipmentRequests(final List<EquipmentRequest> requests) {
        Integer activeRequests = 0;
        for (EquipmentRequest request : requests) {
            if (request.requestInformation.submitter.userId != null &&
                    request.requestInformation.submitter.userId.equals(currentUserBt.getProfileId()) &&
                    request.updatedBy != null &&
                    request.updatedDate != null &&
                    request.wfProcessing != null &&
                    request.wfProcessing.currentStatus.equalsIgnoreCase("Active")) {
                activeRequests++;
            }
        }
        return activeRequests;
    }

    public Integer getNumberOfNewEquipmentRequests(final List<EquipmentRequest> requests) {
        Integer newRequests = 0;
        for (EquipmentRequest request : requests) {
            if (request.wfProcessing != null &&
                    request.wfProcessing.history != null &&
                    request.wfProcessing.history.size() == 1) {
                newRequests++;
            }
        }
        return newRequests;
    }

    public Integer getNumberOfPendingEquipmentRequests(final List<EquipmentRequest> requests) throws ObjectNotFoundException {
        Integer pendingRequests = 0;
        UserType userType = currentUserBt.getUserType();
        for (EquipmentRequest request : requests) {
            if (request.wfProcessing != null &&
                    request.wfProcessing.currentStatus.equalsIgnoreCase("Active")) {
                for (WorkflowLevelDefinition wflDefinition : request.wfProcessing.wfDefinition.levelDefinitions) {
                    if (wflDefinition.userType.equals(userType.name())) {
                        UserProfile profile = userService.getUserProfileById(currentUserBt.getProfileId());
                        for (Role role : profile.roles) {
                            if (role.id.equals(wflDefinition.ownerRoleId)) {
                                pendingRequests++;
                                break;
                            }
                        }
                    }
                }
            }
        }
        return pendingRequests;
    }

    public List<EquipmentRequest> getAllEquipmentRequests() {
        List<EquipmentRequestDO> erDos = equipmentRequestDao.findAll();
        List<EquipmentRequest>  ers = objectMapper.getList(EquipmentRequest[].class, erDos);
        return ers;
    }

    public List<RequestCriticality> getCriticalCodes(String serviceAgencyCode) {
        List<RequestCriticalityDO> recordsFound;
        if (serviceAgencyCode == null || serviceAgencyCode.isEmpty()){
            recordsFound = criticalCodeDao.findAll();
        } else {
            recordsFound = criticalCodeDao.findByServiceAgencyCode(serviceAgencyCode);
        }
        List<RequestCriticality> cCodes = objectMapper.getList(RequestCriticality[].class, recordsFound);
        return cCodes;
    }

    public List<CriticalCodes> getCriticalCodesByServiceAgencyCode(String serviceAgencyCode) {
        List<CriticalCodesDO> recordsFound = new ArrayList<>();
        recordsFound = criticalCodeDao.findCodesByServiceAgencyCode(serviceAgencyCode);
        List<CriticalCodes> cCodes = objectMapper.getList(CriticalCodes[].class, recordsFound);
        return cCodes;
    }

    public List<String> getEquipmentMaintenanceTypes(String serviceAgency) {
        List<String> recordsFound = equipmentMaintenanceTypeDao.findMaintenanceCodes(serviceAgency);
        return recordsFound;
    }

    public List<Device> getDevices() {
        List<DeviceDO> deviceDos = deviceDao.findCodeAndText();
        List<Device> devices = objectMapper.getList(Device[].class, deviceDos);
        return devices;
    }

    public List<EquipmentCriticality> getEquipmentCriticalities() {
        List<EquipmentCriticalityDO> ecDo = equipmentCriticalityDao.findAll();
        List<EquipmentCriticality> equipCrits = objectMapper.getList(EquipmentCriticality[].class, ecDo);
        return equipCrits;
    }

    public List<EquipmentManufacturer> getEquipmentManufacturers() {
        List<EquipmentManufacturerDO> emDos = equipmentManufacturerDao.findCodeAndText();
        List<EquipmentManufacturer> eman = objectMapper.getList(EquipmentManufacturer[].class, emDos);
        return eman;
    }

    public List<EquipmentMountingType> getEquipmentMountingTypes() {
        List<EquipmentMountingTypeDO> eMountTypeDos = equipmentMountingTypeDao.findAll();
        List<EquipmentMountingType> eMountTypes = objectMapper.getList(EquipmentMountingType[].class, eMountTypeDos);
        return eMountTypes;
    }

    public EquipmentRequest getEquipmentRequest(String id) {
        EquipmentRequestDO ereqDo = equipmentRequestDao.findById(id);
        EquipmentRequest ereq = objectMapper.getObject(EquipmentRequest.class, ereqDo);
        return ereq;
    }

    public List<EquipmentRequest> getEquipmentRequests() {
        List<EquipmentRequestDO> requestDOListIn = requestFetcher.getRequestsPerUserType();
        List<EquipmentRequest> requestDOListOut = objectMapper.getList(EquipmentRequest[].class, requestDOListIn);
        return requestDOListOut;
    }

    public List<EquipmentTraineeType> getEquipmentTraineeTypes() {
        List<EquipmentTraineeTypeDO> ettDos = equipmentTraineeTypeDao.findAll();
        List<EquipmentTraineeType> etts = objectMapper.getList(EquipmentTraineeType[].class, ettDos);
        return etts;
    }

    public List<LiteratureType> getLiteratureTypes() {
        List<LiteratureTypeDO> litTypeDos = literatureTypeDao.findAll();
        List<LiteratureType> litTypes = objectMapper.getList(LiteratureType[].class, litTypeDos);
        return litTypes;
    }

    public List<Specialty> getSpecialties() {
        List<SpecialtyDO> specDos = specialtyDao.findAll();
        List<Specialty> spec = objectMapper.getList(Specialty[].class, specDos);
        return spec;
    }

    public List<TraineeLocationType> getTraineeLocationTypes() {
        List<TraineeLocationTypeDO> tltypeDos = traineeLocationTypeDao.findAll();
        List<TraineeLocationType> tltypes = objectMapper.getList(TraineeLocationType[].class, tltypeDos);
        return tltypes;
    }

    public void generateRequestSequenceNumber(@NotNull EquipmentRequest request) {
        if (request.requestInformation.requestNumber == null || request.requestInformation.requestNumber.equals("")) {
            request.requestInformation.requestNumber = getRandomRequestNumber();
        }
    }
    public List<EquipmentRequestReason> testRemoteMtf() {
        MtfPortal mtfPortal = new MtfPortal(MtfSites.Bamc);
        List<EquipmentRequestReasonDO> ereqReqsDos = mtfPortal.getEquipmentRequestReasons();
        List<EquipmentRequestReason> ereqReqs = objectMapper.getList(EquipmentRequestReason[].class,ereqReqsDos);
        return ereqReqs;
    }

    public EquipmentRequest saveRequest(@NotNull EquipmentRequest request) throws ObjectNotFoundException {
        generateRequestSequenceNumber(request);
        EquipmentRequestDO equipReqDO = objectMapper.getObject(EquipmentRequestDO.class, request);

        equipReqDO.setUpdatedBy(currentUserBt.getFullName());
        equipReqDO.setUpdatedDate(new Date());

        //This updates the request
        equipmentRequestDao.upsert(equipReqDO);

        return objectMapper.getObject(EquipmentRequest.class, equipReqDO);
    }

    public EquipmentRequest saveRequestInfo(@NotNull EquipmentRequest request) throws ObjectNotFoundException {
        EquipmentRequestDO reqIn = objectMapper.getObject(EquipmentRequestDO.class, request);
        EquipmentRequestDO requestDO = equipmentRequestDao.findById(request.id);

        RequestInformationDO riIn = reqIn.getRequestInformation();
        RequestInformationDO riDo = requestDO.getRequestInformation();

        riDo.setRequestTitle(riIn.getRequestTitle());
        riDo.setRequestNumber(riIn.getRequestNumber());
        riDo.setRequestType(riIn.getRequestType());
        riDo.setRequestReason(riIn.getRequestReason());
        riDo.setCriticalCode(riIn.getCriticalCode());
        riDo.setMissionImpact(riIn.getMissionImpact());
        riDo.setDescription(riIn.getDescription());
        riDo.setRequestedDeliveryDate(riIn.getRequestedDeliveryDate());
        riDo.setRequestedDeliveryDateReason(riIn.getRequestedDeliveryDateReason());

        saveCommonlyChangedData(reqIn, requestDO, "Save Request Info");

        equipmentRequestDao.update(requestDO);

        return objectMapper.getObject(EquipmentRequest.class, requestDO);
    }

    public EquipmentRequest saveRequestCustomerInfo(@NotNull EquipmentRequest request) throws ObjectNotFoundException {
        EquipmentRequestDO reqIn = objectMapper.getObject(EquipmentRequestDO.class, request);
        EquipmentRequestDO requestDO = equipmentRequestDao.findById(request.id);

        RequestInformationDO riIn = reqIn.getRequestInformation();
        RequestInformationDO riDo = requestDO.getRequestInformation();

        riDo.setOrganization(riIn.getOrganization());
        riDo.setCustomer(riIn.getCustomer());
        riDo.setRequestor(riIn.getRequestor());

        saveCommonlyChangedData(reqIn, requestDO, "Save Customer Info");

        equipmentRequestDao.update(requestDO);

        return objectMapper.getObject(EquipmentRequest.class, requestDO);
    }

    public EquipmentRequest saveRequestEquipmentInfo(@NotNull EquipmentRequest request) throws ObjectNotFoundException {
        EquipmentRequestDO reqIn = objectMapper.getObject(EquipmentRequestDO.class, request);
        EquipmentRequestDO requestDO = equipmentRequestDao.findById(request.id);

        RequestInformationDO riIn = reqIn.getRequestInformation();
        RequestInformationDO riDo = requestDO.getRequestInformation();
        MaintenanceInformationDO miIn = reqIn.getMaintenanceInformation();
        MaintenanceInformationDO miDo = requestDO.getMaintenanceInformation();

        riDo.setEquipment(riIn.getEquipment());
        riDo.setCatalogItem(riIn.getCatalogItem());
        riDo.setQuantityRequested(riIn.getQuantityRequested());
        riDo.setEquipmentRequirements(riIn.getEquipmentRequirements());
        riDo.setReplacedItems(riIn.getReplacedItems());
        //This field is determined by the item selected so if the item is saved this field need to be saved also
        miDo.setAcceptanceInspection(miIn.getAcceptanceInspection());

        saveCommonlyChangedData(reqIn, requestDO, "Save Equipment Info");

        equipmentRequestDao.update(requestDO);

        return objectMapper.getObject(EquipmentRequest.class, requestDO);
    }

    public EquipmentRequest saveRequestExtraItems(@NotNull EquipmentRequest request) throws ObjectNotFoundException {
        EquipmentRequestDO reqIn = objectMapper.getObject(EquipmentRequestDO.class, request);
        EquipmentRequestDO requestDO = equipmentRequestDao.findById(request.id);

        RequestInformationDO riIn = reqIn.getRequestInformation();
        RequestInformationDO riDo = requestDO.getRequestInformation();

        riDo.setExtraItems(riIn.getExtraItems());

        saveCommonlyChangedData(reqIn, requestDO, "Save Extra Items");

        equipmentRequestDao.update(requestDO);

        return objectMapper.getObject(EquipmentRequest.class, requestDO);
    }

    public EquipmentRequest saveRequestSourceOfSupply(@NotNull EquipmentRequest request) throws ObjectNotFoundException {
        EquipmentRequestDO reqIn = objectMapper.getObject(EquipmentRequestDO.class, request);
        EquipmentRequestDO requestDO = equipmentRequestDao.findById(request.id);

        RequestInformationDO riIn = reqIn.getRequestInformation();
        RequestInformationDO riDo = requestDO.getRequestInformation();

        riDo.setSuggestedSources(riIn.getSuggestedSources());

        saveCommonlyChangedData(reqIn, requestDO, "Save Source of Supply");

        equipmentRequestDao.update(requestDO);

        return objectMapper.getObject(EquipmentRequest.class, requestDO);
    }

    public EquipmentRequest saveRequestTraining(@NotNull EquipmentRequest request) throws ObjectNotFoundException {
        EquipmentRequestDO reqIn = objectMapper.getObject(EquipmentRequestDO.class, request);
        EquipmentRequestDO requestDO = equipmentRequestDao.findById(request.id);

        RequestInformationDO riIn = reqIn.getRequestInformation();
        RequestInformationDO riDo = requestDO.getRequestInformation();

        riDo.setTraining(riIn.getTraining());

        saveCommonlyChangedData(reqIn, requestDO, "Save Training Info");

        equipmentRequestDao.update(requestDO);

        return objectMapper.getObject(EquipmentRequest.class, requestDO);
    }

    public EquipmentRequest saveFacilities(@NotNull EquipmentRequest request) throws ObjectNotFoundException {
        EquipmentRequestDO reqIn = objectMapper.getObject(EquipmentRequestDO.class, request);
        EquipmentRequestDO requestDO = equipmentRequestDao.findById(request.id);

        requestDO.setFacilityInformation(reqIn.getFacilityInformation());
        saveCommonlyChangedData(reqIn, requestDO, "Save Facilities Info");

        equipmentRequestDao.update(requestDO);

        return objectMapper.getObject(EquipmentRequest.class, requestDO);
    }

    public EquipmentRequest saveMaintenance(@NotNull EquipmentRequest request) throws ObjectNotFoundException {
        EquipmentRequestDO reqIn = objectMapper.getObject(EquipmentRequestDO.class, request);
        EquipmentRequestDO requestDO = equipmentRequestDao.findById(request.id);

        RequestInformationDO riIn = reqIn.getRequestInformation();
        RequestInformationDO riDo = requestDO.getRequestInformation();

        requestDO.setMaintenanceInformation(reqIn.getMaintenanceInformation());
        riDo.setExtraItems(riIn.getExtraItems());
        riDo.setTraining(riIn.getTraining());
        saveCommonlyChangedData(reqIn, requestDO, "Save Maintenance Info");

        equipmentRequestDao.update(requestDO);

        return objectMapper.getObject(EquipmentRequest.class, requestDO);
    }

    public EquipmentRequest saveSafety(@NotNull EquipmentRequest request) throws ObjectNotFoundException {
        EquipmentRequestDO reqIn = objectMapper.getObject(EquipmentRequestDO.class, request);
        EquipmentRequestDO requestDO = equipmentRequestDao.findById(request.id);

        requestDO.setSafetyInformation(reqIn.getSafetyInformation());
        saveCommonlyChangedData(reqIn, requestDO, "Save Safety Info");

        equipmentRequestDao.update(requestDO);

        return objectMapper.getObject(EquipmentRequest.class, requestDO);
    }

    public EquipmentRequest saveTechnology(@NotNull EquipmentRequest request) throws ObjectNotFoundException {
        EquipmentRequestDO reqIn = objectMapper.getObject(EquipmentRequestDO.class, request);
        EquipmentRequestDO requestDO = equipmentRequestDao.findById(request.id);

        requestDO.setTechnologyInformation(reqIn.getTechnologyInformation());
        saveCommonlyChangedData(reqIn, requestDO, "Save Technology Info");

        equipmentRequestDao.update(requestDO);

        return objectMapper.getObject(EquipmentRequest.class, requestDO);
    }

    private void saveCommonlyChangedData(EquipmentRequestDO reqIn, EquipmentRequestDO requestDo, String section) {

        requestDo.setAttachments(reqIn.getAttachments());
        requestDo.setCatalogItem(reqIn.getCatalogItem());
        requestDo.setNotes(reqIn.getNotes());
        requestDo.setTotalOtherCost(reqIn.getTotalOtherCost());
        requestDo.setTotalRequisitionCost(reqIn.getTotalRequisitionCost());
        requestDo.setUpdatedBy(currentUserBt.getFullName());
        requestDo.setUpdatedDate(new Date());
        String levelName = requestDo.getWfProcessing().getCurrentLevel().getLevelName();
        history.addHistory(requestDo, levelName, "DataChange", section);

    }

    private String getRandomRequestNumber() {
        // get the current milliseconds since java Epoch, converted to base 36 (results in 8 characters)
        Long epochMilli = Instant.now().toEpochMilli();
        String epochNow = Long.toString(epochMilli, 36);

        // generate a random number in the range below, convert to base 36 (results in 6 characters)
        Random r = new Random();
        String rand = Long.toString(r.nextInt(2100000000-1), 36);

        // append the two, into a 14 character result, ensure that the length of the result is no longer than 14 chars
        String comb = rand + epochNow;
        if (comb.length() > 14) {
            comb = comb.substring(0,14);
        }
        return comb;
    }

}
