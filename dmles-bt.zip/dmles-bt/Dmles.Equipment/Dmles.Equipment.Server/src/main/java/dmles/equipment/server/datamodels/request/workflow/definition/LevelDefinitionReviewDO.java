package dmles.equipment.server.datamodels.request.workflow.definition;


public class LevelDefinitionReviewDO {
    
    private String elementName;
    private String roleId;
    private String reviewDisplayName;

    public String getElementName() {
        return elementName;
    }

    public void setElementName(String elementName) {
        this.elementName = elementName;
    }

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    public String getReviewDisplayName() {
        return reviewDisplayName;
    }
    
    public void setReviewDisplayName(String reviewDisplayName) {
        this.reviewDisplayName = reviewDisplayName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        LevelDefinitionReviewDO that = (LevelDefinitionReviewDO) o;

        if (elementName != null ? !elementName.equals(that.elementName) : that.elementName != null)
            return false;
        if (roleId != null ? !roleId.equals(that.roleId) : that.roleId != null) return false;
        if (reviewDisplayName != null ? reviewDisplayName.equals(that.reviewDisplayName) : that.reviewDisplayName == null)
            return false;
        return true;
    }

    @Override
    public int hashCode() {
        int result = elementName != null ? elementName.hashCode() : 0;
        result = 31 * result + (roleId != null ? roleId.hashCode() : 0);
        result = 31 * result + (reviewDisplayName != null ? reviewDisplayName.hashCode() : 0);
        return result;
    }
}
