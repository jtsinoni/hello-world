package dmles.equipment.server.datamodels.request;

import org.mongodb.morphia.annotations.Embedded;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class TechnologyInformationDO implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @Embedded
    private List<TechnologyRequirementsDO> technologyRequirements = new ArrayList<>();
    @Embedded
    private List<SoftwareDO> software = new ArrayList<>();    

    public TechnologyInformationDO() {
    }

    public List<TechnologyRequirementsDO> getTechnologyRequirements() {
        return technologyRequirements;
    }

    public void setTechnologyRequirements(List<TechnologyRequirementsDO> technologyRequirements) {
        this.technologyRequirements = technologyRequirements;
    }

    public List<SoftwareDO> getSoftware() {
        return software;
    }

    public void setSoftware(List<SoftwareDO> software) {
        this.software = software;
    }
    
}
