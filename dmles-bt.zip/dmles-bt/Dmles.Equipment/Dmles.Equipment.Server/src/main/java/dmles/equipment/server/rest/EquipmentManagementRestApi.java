package dmles.equipment.server.rest;

import dmles.equipment.core.IEquipmentService;
import dmles.equipment.core.datamodels.record.EquipmentRecord;
import dmles.equipment.core.datamodels.request.RequestCriticality;
import dmles.equipment.core.datamodels.request.CriticalCodes;
import dmles.equipment.core.datamodels.request.Device;
import dmles.equipment.core.datamodels.request.EquipmentCriticality;
import dmles.equipment.core.datamodels.request.EquipmentManufacturer;
import dmles.equipment.core.datamodels.request.EquipmentMountingType;
import dmles.equipment.core.datamodels.request.EquipmentRequest;
import dmles.equipment.core.datamodels.request.EquipmentRequestReason;
import dmles.equipment.core.datamodels.request.EquipmentRequestType;
import dmles.equipment.core.datamodels.request.EquipmentTraineeType;
import dmles.equipment.core.datamodels.request.LiteratureType;
import dmles.equipment.core.datamodels.request.Specialty;
import dmles.equipment.core.datamodels.request.TraineeLocationType;
import dmles.equipment.core.datamodels.request.workflow.definition.LevelCriteria;
import dmles.equipment.core.datamodels.request.workflow.definition.WorkflowDefinition;
import dmles.equipment.core.datamodels.request.workflow.process.LevelCriteriaNeeded;
import dmles.equipment.core.datamodels.request.workflow.process.WorkflowProcessing;
import dmles.equipment.server.business.ElasticSearchManager;
import dmles.equipment.server.business.EquipmentRecordManager;
import dmles.equipment.server.business.EquipmentRequestManager;
import dmles.equipment.server.business.WorkflowDefinitionManager;
import dmles.equipment.server.business.WorkflowProcessingManager;
import io.swagger.annotations.Api;

import mil.jmlfdc.common.exception.InvalidDataException;
import mil.jmlfdc.common.exception.ObjectNotFoundException;
import mil.jmlfdc.common.exception.ValidationException;
import mil.jmlfdc.common.rest.RestApiBase;

import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

@Api
@ApplicationScoped
public class EquipmentManagementRestApi extends RestApiBase implements IEquipmentService {

    @Inject
    private ElasticSearchManager esManager;
    @Inject
    private EquipmentRecordManager equipRecordManager;
    @Inject
    private EquipmentRequestManager equipRequestManager;
    @Inject
    private WorkflowProcessingManager wfProcManager;
    @Inject
    private WorkflowDefinitionManager wfDefManager;

    @Override
    public List<EquipmentRequest> getAllEquipmentRequests() {
        return  equipRequestManager.getAllEquipmentRequests();
    }

    @Override
    public Response getCatalogSearchResults(@QueryParam("searchValue") String searchValue, @QueryParam("dodaac") String dodaac) {
        String responseString = esManager.getCatalogSearchResults(searchValue, dodaac);
        return Response.status(Response.Status.OK).entity(responseString).build();
    }

    @Override
    public List<RequestCriticality> getCriticalCodes(@QueryParam("serviceAgency") String serviceAgencyCode) {
        return equipRequestManager.getCriticalCodes(serviceAgencyCode);
    }
    
    @Override
    public List<CriticalCodes> getCriticalCodesByServiceAgencyCodes(@QueryParam("serviceAgency") String serviceAgencyCode) {
        return equipRequestManager.getCriticalCodesByServiceAgencyCode(serviceAgencyCode);
    }
    
    @Override
    public List<String> getEquipmentMaintenanceTypes(@DefaultValue("AD") @QueryParam("serviceAgency") String serviceAgency) {
        return equipRequestManager.getEquipmentMaintenanceTypes(serviceAgency);
        /* As of 12/6/2016 this call is no longer valid. 
           what we thought was Maintenance Types is actually Installation Type(Extended, In-House, Turnkey). 
           The Maintenance Types will come from each Organization and we don't have that information right now. 
           Maintenance type info may be part of the Organization data in the future
        */
    }

    @Override
    public List<Device> getDevices() {
        return equipRequestManager.getDevices();
    }

    @Override
    public List<EquipmentCriticality> getEquipmentCriticalities() {
        return equipRequestManager.getEquipmentCriticalities();
    }

    @Override
    public List<EquipmentManufacturer> getEquipmentManufacturers() {
        return equipRequestManager.getEquipmentManufacturers();
        //return new ArrayList<>();
    }

    @Override
    public List<EquipmentMountingType> getEquipmentMountingTypes() {
        return equipRequestManager.getEquipmentMountingTypes();
    }

    @Override
    public EquipmentRecord getEquipmentRecord(@QueryParam("dodaac") String dodaac, @QueryParam("meId") int meId) {
        return equipRecordManager.findRecord(dodaac, meId);
    }

    @Override
    public Response getEquipmentRecordSearchResults(@QueryParam("searchValue") String searchValue,
            @QueryParam("aggregations") String aggregations) {
        String responseString = esManager.getEquipmentRecordSearchResults(searchValue, aggregations);
        return Response.status(Response.Status.OK).entity(responseString).build();
    }

    @Override
    public List<EquipmentRecord> getEquipmentRecords(@QueryParam("dodaac") String dodaac,
            @QueryParam("meId") int meId) {
        return equipRecordManager.findRecords(dodaac, meId);
    }

    @Override
    public long getEquipmentRecordsCount() {
        return equipRecordManager.getEquipmentRecordsCount();
    }
    
    @Override
    public EquipmentRequest getEquipmentRequest(@QueryParam("id") String id) {
        return equipRequestManager.getEquipmentRequest(id);
    }
    
    @Override
    public List<EquipmentRequest> getEquipmentRequests() {
        return equipRequestManager.getEquipmentRequests();
    }    

    @Override
    public List<EquipmentRequestReason> getEquipmentRequestReasons() {
        return equipRequestManager.getEquipmentRequestReasons();
    }

    @Override
    public List<EquipmentRequestType> getEquipmentRequestTypes() {
        return equipRequestManager.getEquipmentRequestTypes();
    }

    @Override
    public List<EquipmentTraineeType> getEquipmentTraineeTypes() {
        return equipRequestManager.getEquipmentTraineeTypes();
    }

    @Override
    public List<LiteratureType> getLiteratureTypes() {
        return equipRequestManager.getLiteratureTypes();
    }

    @Override
    public Response getJmarSearchResults(@QueryParam("searchValue") String searchValue) {
        String responseString = esManager.getJmarSearchResults(searchValue);
        return Response.status(Response.Status.OK).entity(responseString).build();
    }

    @Override
    public List<Specialty> getSpecialties() {
        return equipRequestManager.getSpecialties();
    }

    @Override
    public List<TraineeLocationType> getTraineeLocationTypes() {
        return equipRequestManager.getTraineeLocationTypes();
    }    
    
    @Override
    public EquipmentRequest addProcessComment(@QueryParam("requestId") String requestId, @QueryParam("comment") String comment) throws ObjectNotFoundException {
        return wfProcManager.addProcessComment(requestId, comment);
    }

    @Override
    public EquipmentRequest removeProcessComment(@QueryParam("requestId") String requestId, @QueryParam("commentId") String commentId) throws ObjectNotFoundException {
        return wfProcManager.removeProcessComment(requestId, commentId);
    }    
    
    @Override
    public EquipmentRequest addWeighInComment(@QueryParam("requestId") String requestId, 
            @QueryParam("weighInRole") String weighInRole, 
            @QueryParam("comment") String comment) throws ObjectNotFoundException {
        return wfProcManager.addWeighInComment(requestId, weighInRole, comment);
    }   
    
    @Override
    public EquipmentRequest removeWeighInComment(@QueryParam("requestId") String requestId, 
            @QueryParam("weighInRole") String weighInRole, 
            @QueryParam("commentId") String commentId) throws ObjectNotFoundException {
        return wfProcManager.removeWeighInComment(requestId, weighInRole, commentId);
    }       

    @Override
    public EquipmentRequest approveRequest(@QueryParam("requestId") String requestId) throws ObjectNotFoundException {
        return wfProcManager.approveRequest(requestId);
    }

    @Override
    public EquipmentRequest cancelRequest(@QueryParam("requestId") String requestId) throws ObjectNotFoundException {
        return wfProcManager.cancelRequest(requestId);
    }

    @Override
    public EquipmentRequest retractRequest(@QueryParam("requestId") String requestId) throws ObjectNotFoundException, InvalidDataException {
        return wfProcManager.retractRequest(requestId);
    }

    @Override
    public EquipmentRequest forceUpRequest(@QueryParam("requestId") String requestId) throws ObjectNotFoundException {
        return wfProcManager.forceUpRequest(requestId);
    }

    @Override
    public EquipmentRequest holdRequest(@QueryParam("requestId") String requestId) throws ObjectNotFoundException {
        return wfProcManager.holdRequest(requestId);
    }

    @Override
    public EquipmentRequest reactivateRequest(@QueryParam("requestId") String requestId) throws ObjectNotFoundException {
        return wfProcManager.reactivateRequest(requestId);
    }   

    @Override
    public EquipmentRequest rejectRequest(@QueryParam("requestId") String requestId) throws ObjectNotFoundException {
        return wfProcManager.rejectRequest(requestId);
    }

    @Override
    public EquipmentRequest reworkRequest(@QueryParam("requestId") String requestId) throws ObjectNotFoundException {
        return wfProcManager.reworkRequest(requestId);
    }

    @Override
    public EquipmentRequest saveRequest(EquipmentRequest request) throws ObjectNotFoundException {
        return equipRequestManager.saveRequest(request);
    }

    @Override
    public EquipmentRequest saveRequestInfo(EquipmentRequest request) throws ObjectNotFoundException {
        return equipRequestManager.saveRequestInfo(request);
    }

    @Override
    public EquipmentRequest saveRequestCustomerInfo(EquipmentRequest request) throws ObjectNotFoundException {
        return equipRequestManager.saveRequestCustomerInfo(request);
    }

    @Override
    public EquipmentRequest saveRequestEquipmentInfo(EquipmentRequest request) throws ObjectNotFoundException {
        return equipRequestManager.saveRequestEquipmentInfo(request);
    }

    @Override
    public EquipmentRequest saveRequestExtraItems(EquipmentRequest request) throws ObjectNotFoundException {
        return equipRequestManager.saveRequestExtraItems(request);
    }

    @Override
    public EquipmentRequest saveRequestSourceOfSupply(EquipmentRequest request) throws ObjectNotFoundException {
        return equipRequestManager.saveRequestSourceOfSupply(request);
    }

    @Override
    public EquipmentRequest saveRequestTraining(EquipmentRequest request) throws ObjectNotFoundException {
        return equipRequestManager.saveRequestTraining(request);
    }

    @Override
    public EquipmentRequest saveRequestFacilities(EquipmentRequest request) throws ObjectNotFoundException {
        return equipRequestManager.saveFacilities(request);
    }      
    
    @Override
    public EquipmentRequest saveRequestMaintenance(EquipmentRequest request) throws ObjectNotFoundException {
        return equipRequestManager.saveMaintenance(request);
    }    
    
    @Override
    public EquipmentRequest saveRequestTechnology(EquipmentRequest request) throws ObjectNotFoundException {
        return equipRequestManager.saveTechnology(request);
    }          
    
    @Override
    public EquipmentRequest saveRequestSafety(EquipmentRequest request) throws ObjectNotFoundException {
        return equipRequestManager.saveSafety(request);
    }              

    @Override
    public EquipmentRequest buildWeighins(@QueryParam("requestId") String requestId) throws ObjectNotFoundException {
        return wfProcManager.buildWeighIns(requestId);
    }     
    
    @Override
    public EquipmentRequest submitForWeighins(@QueryParam("requestId") String requestId, 
            @QueryParam("weighInRole") String weighInRole,
            @QueryParam("weighInDisplayName") String weighInDisplayName) throws ObjectNotFoundException {
        return wfProcManager.submitForWeighIns(requestId, weighInRole, weighInDisplayName);
    }    

    @Override
    public EquipmentRequest submitForProcessing(EquipmentRequest request) throws ObjectNotFoundException, ValidationException {
        return wfProcManager.submitForProcessing(request);
    }   
    
    @Override
    public EquipmentRequest submitWeighinResult(@QueryParam("requestId") String requestId, 
            @QueryParam("weighInRole") String weighInRole, 
            @QueryParam("result") String result, 
            @QueryParam("weighInDisplayName") String weighInDisplayName,
            EquipmentRequest request) throws ObjectNotFoundException {
            if(null != request){
                saveRequest(request);
            }
        return wfProcManager.submitWeighInResult(requestId, weighInRole, 
                result, weighInDisplayName);
    }
    
    @Override
    public EquipmentRequest submitWeighinStatus(EquipmentRequest request) throws ObjectNotFoundException {
            if(null != request){
                saveRequest(request);
            }
        return wfProcManager.submitWeighInStatus(request);
    } 

    @Override
    public List<String> getWeighInResults() {
        return wfProcManager.getWeighInResults();
    }

    @Override
    public List<String> getWeighInStatuses() {
        return wfProcManager.getWeighInStatuses();
    } 

    @Override
    public WorkflowProcessing getWorkflowProcessing(@QueryParam("id") String id) throws ObjectNotFoundException {
        return wfProcManager.getWorkflowProcessing(id);
    }

    @Override
    public WorkflowProcessing getWorkflowProcessingByRequestId(@QueryParam("requestId") String requestId) throws ObjectNotFoundException {
        return wfProcManager.getWorkflowProcessingByRequestId(requestId);
    }   
    
    @Override
    public WorkflowDefinition createWorkflowDefinition(WorkflowDefinition wfd) throws ObjectNotFoundException {
        return wfDefManager.createWorkflowDefinition(wfd);
    }        
    
    @Override
    public WorkflowDefinition getWorkflowDefinition(@QueryParam("service") String service) throws ObjectNotFoundException {
        return wfDefManager.getWorkflowDefinition(service);
    }    
    
    @Override
    public WorkflowDefinition addWorkflowDefCatalogCriteria(@QueryParam("serviceName") String serviceName,
            @QueryParam("levelID") String levelID,
            @QueryParam("catalogID") String catalogID,
            @QueryParam("catalogName") String catalogName) throws ObjectNotFoundException {
        return wfDefManager.addCatalogCriteria(serviceName, levelID, catalogID, catalogName);
    }      
    
    @Override
    public WorkflowDefinition removeWorkflowDefCatalogCriteria(@QueryParam("serviceName") String serviceName,
            @QueryParam("levelID") String levelID,
            @QueryParam("catalogID") String catalogID) throws ObjectNotFoundException {
        return wfDefManager.removeCatalogCriteria(serviceName, levelID, catalogID);
    }    
    
    @Override
    public WorkflowDefinition addWorkflowDefDeviceCriteria(@QueryParam("serviceName") String serviceName,
            @QueryParam("levelID") String levelID,
            @QueryParam("deviceCode") String deviceCode,
            @QueryParam("deviceName") String deviceName) throws ObjectNotFoundException {
        return wfDefManager.addDeviceCriteria(serviceName, levelID, deviceCode, deviceName);
    }      
    
    @Override
    public WorkflowDefinition removeWorkflowDefDeviceCriteria(@QueryParam("serviceName") String serviceName,
            @QueryParam("levelID") String levelID,
            @QueryParam("deviceCode") String deviceCode) throws ObjectNotFoundException {
        return wfDefManager.removeDeviceCriteria(serviceName, levelID, deviceCode);
    }    
    
    @Override
    public WorkflowDefinition updateWorkflowDefCostCriteria(@QueryParam("serviceName") String serviceName,
            @QueryParam("levelID") String levelID,
            @QueryParam("totalCost") String totalCost) throws ObjectNotFoundException {
        return wfDefManager.updateCostCriteria(serviceName, levelID, totalCost);
    }       
    
    @Override
    public LevelCriteria getWorkflowDefCriteria(@QueryParam("serviceName") String serviceName,
                                                @QueryParam("levelID") String levelID) throws ObjectNotFoundException {
        return wfDefManager.getCriteria(serviceName, levelID);
    }    

    @Override
    public List<EquipmentRequestReason> testRemoteMtf() {
        return equipRequestManager.testRemoteMtf();
    }

    @Override
    public List<LevelCriteriaNeeded> getLevelsCriteriaNeeded(@QueryParam("requestId")String requestId) throws ObjectNotFoundException {
        return wfProcManager.getLevelsCriteriaNeeded(requestId);
    }

    @Override
    public List<LevelCriteriaNeeded> getLevelsCriteriaNeeded(EquipmentRequest request) throws ObjectNotFoundException {
        return wfProcManager.getLevelsCriteriaNeeded(request);
    }

    @Override
    public WorkflowDefinition saveWorkflowDefinition(WorkflowDefinition workflowDefinition) {
        return wfDefManager.saveWorkflowDefinition(workflowDefinition);
    }

    @Override
    public WorkflowDefinition updateWorkflowLevel(WorkflowDefinition workflowDefinition) {
        return wfDefManager.updateWorkflowLevel(workflowDefinition);
    }

    @Override
    public WorkflowDefinition updateWorkflowDefLevelCriteria(WorkflowDefinition workflowDefinition) {
        return wfDefManager.updateWorkflowDefLevelCriteria(workflowDefinition);
    }

    @Override
    public WorkflowDefinition updateWorkflowDefWeighInElements(WorkflowDefinition workflowDefinition) {
        return wfDefManager.updateWorkflowDefWeighInElements(workflowDefinition);
    }

    @Override
    public WorkflowDefinition updateWorkflowDefRules(WorkflowDefinition workflowDefinition) {
        return wfDefManager.updateWorkflowDefRules(workflowDefinition);
    }
}
