package dmles.equipment.server.dao;

import javax.enterprise.context.Dependent;
import mil.jmlfdc.common.dao.BaseDao;
import dmles.equipment.server.datamodels.request.workflow.process.ReviewResultDO;
import java.util.ArrayList;
import java.util.List;

@Dependent
public class ReviewResultDao extends BaseDao<ReviewResultDO, String>{

    public ReviewResultDao() {
        super(ReviewResultDO.class);
    }

}
