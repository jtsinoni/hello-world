package dmles.equipment.server.utils;

import org.apache.deltaspike.core.api.config.ConfigProperty;
import org.apache.deltaspike.core.api.jmx.JmxManaged;
import org.apache.deltaspike.core.api.jmx.MBean;
import org.slf4j.Logger;

import javax.annotation.PostConstruct;
import javax.ejb.Startup;
import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
@Startup
@MBean(name="dmles.equipment.server.utils.EquipmentManagementConfiguration", description="MBean for File Exchange Configuration parameters",
        objectName="EquipmentManagementConfigurationMXBean:type=dmles.equipment.server.utils.EquipmentManagementConfiguration")
public class EquipmentManagementConfiguration implements EquipmentManagementConfigurationMXBean {
    
    @Inject
    private Logger logger;

    @Inject
    @ConfigProperty(name = "test")
    private String test;

    @JmxManaged(description = "Gets the test message.")
    @Override
    public String getTest() {
        return test;
    }

    @JmxManaged(description = "Sets the test message.")
    @Override
    public void setTest(String test) {
        this.test = test;
    }

    @PostConstruct
    public void init() {
        logger.info("................HIT...............");
    }

}
