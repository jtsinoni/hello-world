package dmles.equipment.server.datamodels.request;

import javax.validation.constraints.AssertTrue;

public class RequestedEquipmentDO {
    private String catalogId;
    private String description;
    private Boolean isFoundInCatalog;
    private String manufacturer;
    private String model;
    private String deviceName;
    private String deviceCode;
    private String otherSystemRequired;
    private Float unitCost;

    public RequestedEquipmentDO() {
    }

    public RequestedEquipmentDO(String catalogId, String description, Boolean isFoundInCatalog, String manufacturer, String model, String deviceName, String otherSystemRequired, Float unitCost) {
        this.catalogId = catalogId;
        this.description = description;
        this.isFoundInCatalog = isFoundInCatalog;
        this.manufacturer = manufacturer;
        this.model = model;
        this.deviceName = deviceName;
        this.otherSystemRequired = otherSystemRequired;
        this.unitCost = unitCost;
    }

    public String getCatalogId() {
        return catalogId;
    }

    public void setCatalogId(String catalogId) {
        this.catalogId = catalogId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Boolean getIsFoundInCatalog() {
        return isFoundInCatalog;
    }

    public void setIsFoundInCatalog(Boolean isFoundInCatalog) {
        this.isFoundInCatalog = isFoundInCatalog;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    public String getDeviceCode() {
        return deviceCode;
    }

    public void setDeviceCode(String deviceCode) {
        this.deviceCode = deviceCode;
    }

    public String getOtherSystemRequired() {
        return otherSystemRequired;
    }

    public void setOtherSystemRequired(String otherSystemRequired) {
        this.otherSystemRequired = otherSystemRequired;
    }

    public Float getUnitCost() {
        return unitCost;
    }

    public void setUnitCost(Float unitCost) {
        this.unitCost = unitCost;
    }

}
