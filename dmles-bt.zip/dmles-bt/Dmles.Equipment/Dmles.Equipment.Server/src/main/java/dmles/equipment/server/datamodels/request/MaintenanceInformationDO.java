package dmles.equipment.server.datamodels.request;

import org.mongodb.morphia.annotations.Embedded;

import java.util.ArrayList;
import java.util.List;

public class MaintenanceInformationDO {

    private String acceptanceInspection;
    private Float estimatedAnnualServiceCost;
    private String installationRequired;
    @Embedded
    private List<InstallRequirementDO> installationRequirements = new ArrayList<>();
    @Embedded
    private List<LiteratureDO> literature = new ArrayList<>();
    private String maintenanceActivity;
    private Boolean maintenanceByOrg;
    private Boolean maintenanceByService;
    private Boolean maintenanceByOGA;
    private String maintenanceExplanation;
    private String tmdeRequired;
    private Float totalInstallationCosts;
    private Float totalLiteratureCosts;

    public String getAcceptanceInspection() {
        return acceptanceInspection;
    }

    public void setAcceptanceInspection(String acceptanceInspection) {
        this.acceptanceInspection = acceptanceInspection;
    }

    public Float getEstimatedAnnualServiceCost() {
        return estimatedAnnualServiceCost;
    }

    public void setEstimatedAnnualServiceCost(Float estimatedAnnualServiceCost) {
        this.estimatedAnnualServiceCost = estimatedAnnualServiceCost;
    }

    public String getInstallationRequired() {
        return installationRequired;
    }

    public void setInstallationRequired(String installationRequired) {
        this.installationRequired = installationRequired;
    }

    public List<InstallRequirementDO> getInstallationRequirements() {
        return installationRequirements;
    }

    public void setInstallationRequirements(List<InstallRequirementDO> installationRequirements) {
        this.installationRequirements = installationRequirements;
    }

    public List<LiteratureDO> getLiterature() {
        return literature;
    }

    public void setLiterature(List<LiteratureDO> literature) {
        this.literature = literature;
    }

    public String getMaintenanceActivity() {
        return maintenanceActivity;
    }

    public void setMaintenanceActivity(String maintenanceActivity) {
        this.maintenanceActivity = maintenanceActivity;
    }

    public Boolean getMaintenanceByOrg() {
        return maintenanceByOrg;
    }

    public void setMaintenanceByOrg(Boolean maintenanceByOrg) {
        this.maintenanceByOrg = maintenanceByOrg;
    }

    public Boolean getMaintenanceByService() {
        return maintenanceByService;
    }

    public void setMaintenanceByService(Boolean maintenanceByService) {
        this.maintenanceByService = maintenanceByService;
    }

    public Boolean getMaintenanceByOGA() {
        return maintenanceByOGA;
    }

    public void setMaintenanceByOGA(Boolean maintenanceByOGA) {
        this.maintenanceByOGA = maintenanceByOGA;
    }

    public String getMaintenanceExplanation() {
        return maintenanceExplanation;
    }

    public void setMaintenanceExplanation(String maintenanceExplanation) {
        this.maintenanceExplanation = maintenanceExplanation;
    }

    public String getTmdeRequired() {
        return tmdeRequired;
    }

    public void setTmdeRequired(String tmdeRequired) {
        this.tmdeRequired = tmdeRequired;
    }

    public Float getTotalInstallationCosts() {
        return totalInstallationCosts;
    }

    public void setTotalInstallationCosts(Float totalInstallationCosts) {
        this.totalInstallationCosts = totalInstallationCosts;
    }

    public Float getTotalLiteratureCosts() {
        return totalLiteratureCosts;
    }

    public void setTotalLiteratureCosts(Float totalLiteratureCosts) {
        this.totalLiteratureCosts = totalLiteratureCosts;
    }

    
}
