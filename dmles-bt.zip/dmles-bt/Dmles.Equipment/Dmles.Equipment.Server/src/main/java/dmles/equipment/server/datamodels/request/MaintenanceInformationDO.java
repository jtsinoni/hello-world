package dmles.equipment.server.datamodels.request;

import org.mongodb.morphia.annotations.Embedded;

import java.util.ArrayList;
import java.util.List;

public class MaintenanceInformationDO {

    private Boolean acceptanceInspection;
    private Float estimatedAnnualServiceCost;
    private String installationRequired;
    private String maintenanceActivity;
    private String maintenanceExplanation;
    private String maintenanceProvidedBy;
    private String tmdeRequired;
    private Float totalInstallationCosts;
    private Float totalLiteratureCosts;
    
    @Embedded
    private List<InstallRequirementDO> installationRequirements = new ArrayList<>();
    
    @Embedded
    private List<LiteratureDO> literature = new ArrayList<>();    

    public Boolean getAcceptanceInspection() {
        return acceptanceInspection;
    }

    public void setAcceptanceInspection(Boolean acceptanceInspection) {
        this.acceptanceInspection = acceptanceInspection;
    }

    public Float getEstimatedAnnualServiceCost() {
        return estimatedAnnualServiceCost;
    }

    public void setEstimatedAnnualServiceCost(Float estimatedAnnualServiceCost) {
        this.estimatedAnnualServiceCost = estimatedAnnualServiceCost;
    }

    public String getInstallationRequired() {
        return installationRequired;
    }

    public void setInstallationRequired(String installationRequired) {
        this.installationRequired = installationRequired;
    }

    public List<InstallRequirementDO> getInstallationRequirements() {
        return installationRequirements;
    }

    public void setInstallationRequirements(List<InstallRequirementDO> installationRequirements) {
        this.installationRequirements = installationRequirements;
    }

    public List<LiteratureDO> getLiterature() {
        return literature;
    }

    public void setLiterature(List<LiteratureDO> literature) {
        this.literature = literature;
    }

    public String getMaintenanceActivity() {
        return maintenanceActivity;
    }

    public void setMaintenanceActivity(String maintenanceActivity) {
        this.maintenanceActivity = maintenanceActivity;
    }

    public String getMaintenanceExplanation() {
        return maintenanceExplanation;
    }

    public void setMaintenanceExplanation(String maintenanceExplanation) {
        this.maintenanceExplanation = maintenanceExplanation;
    }

    public String getMaintenanceProvidedBy() {
        return maintenanceProvidedBy;
    }

    public void setMaintenanceProvidedBy(String maintenanceProvidedBy) {
        this.maintenanceProvidedBy = maintenanceProvidedBy;
    }
    
    public String getTmdeRequired() {
        return tmdeRequired;
    }

    public void setTmdeRequired(String tmdeRequired) {
        this.tmdeRequired = tmdeRequired;
    }

    public Float getTotalInstallationCosts() {
        return totalInstallationCosts;
    }

    public void setTotalInstallationCosts(Float totalInstallationCosts) {
        this.totalInstallationCosts = totalInstallationCosts;
    }

    public Float getTotalLiteratureCosts() {
        return totalLiteratureCosts;
    }

    public void setTotalLiteratureCosts(Float totalLiteratureCosts) {
        this.totalLiteratureCosts = totalLiteratureCosts;
    }

    
}
