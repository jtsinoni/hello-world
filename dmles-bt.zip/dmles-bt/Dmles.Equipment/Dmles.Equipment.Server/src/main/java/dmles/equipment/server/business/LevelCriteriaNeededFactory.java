package dmles.equipment.server.business;

import dmles.equipment.core.datamodels.request.workflow.process.LevelCriteriaNeeded;
import dmles.equipment.server.datamodels.request.EquipmentRequestDO;
import dmles.equipment.server.datamodels.request.workflow.definition.WorkflowLevelDefinitionDO;

import java.util.ArrayList;
import java.util.List;

class LevelCriteriaNeededFactory {

    private static LevelCriteriaNeededFactory instance = new LevelCriteriaNeededFactory();
    private static List<ICriteriaEvaluator> evaluators;

    static {
        evaluators = new ArrayList<>(3);
        evaluators.add(new TotalCostCriteriaNeededEvaluator());
        evaluators.add(new DeviceCriteriaNeededEvaluator());
        evaluators.add(new CatalogCriteriaNeededEvaluator());

    }

    static LevelCriteriaNeededFactory getInstance() {
        return instance;
    }

    LevelCriteriaNeeded getLevelCriteraNeeded(EquipmentRequestDO request, WorkflowLevelDefinitionDO levelDef) {

        LevelCriteriaNeeded lcn = new LevelCriteriaNeeded();
        lcn.levelName = levelDef.getName();

        for (ICriteriaEvaluator evaluator: evaluators) {
            lcn = evaluator.evaluateCriteria(lcn, request, levelDef);
        }

        return lcn;
    }
}
