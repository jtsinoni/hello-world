package dmles.equipment.server.dao;

import javax.enterprise.context.Dependent;
import mil.jmlfdc.common.dao.BaseDao;
import dmles.equipment.server.datamodels.request.EquipmentRequestReasonDO;

@Dependent
public class EquipmentRequestReasonDao extends BaseDao<EquipmentRequestReasonDO, String> {

    public EquipmentRequestReasonDao() {
        super(EquipmentRequestReasonDO.class);
    }

}
