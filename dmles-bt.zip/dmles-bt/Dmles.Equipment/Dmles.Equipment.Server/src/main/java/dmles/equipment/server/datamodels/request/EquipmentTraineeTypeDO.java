package dmles.equipment.server.datamodels.request;

import java.io.Serializable;
import mil.jmlfdc.common.datamodel.MorphiaEntity;
import org.mongodb.morphia.annotations.Entity;

@Entity("EquipTraineeType")
public class EquipmentTraineeTypeDO extends MorphiaEntity implements Serializable {
    private static final long serialVersionUID = 1L;
    private String equipTraineeTypeCd;
    private String equipTraineeTypeTx;

    public String getEquipTraineeTypeCd() {
        return equipTraineeTypeCd;
    }

    public void setEquipTraineeTypeCd(String equipTraineeTypeCd) {
        this.equipTraineeTypeCd = equipTraineeTypeCd;
    }

    public String getEquipTraineeTypeTx() {
        return equipTraineeTypeTx;
    }

    public void setEquipTraineeTypeTx(String equipTraineeTypeTx) {
        this.equipTraineeTypeTx = equipTraineeTypeTx;
    }
}
