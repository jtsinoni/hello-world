package dmles.equipment.server.datamodels.request;

import dmles.equipment.core.datamodels.Customer;
import dmles.equipment.core.datamodels.Organization;
import dmles.equipment.core.datamodels.catalog.CatalogItem;
import dmles.equipment.core.datamodels.catalog.SuggestedSourceItem;
import dmles.equipment.server.datamodels.request.validation.RequestValidator;
import mil.jmlfdc.common.exception.ValidationException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

public class RequestValidatorTest {

    private RequestValidator validator = new RequestValidator();
    private EquipmentRequestDO req;
    private RequestInformationDO reqInfo;

    @Before
    public void setup() {

        setupData();
    }

    public void setupData() {

        req = new EquipmentRequestDO();
        reqInfo = new RequestInformationDO();
        req.setRequestInformation(reqInfo);
        reqInfo.setQuantityRequested(0);
        reqInfo.setRequestTitle("title");
        reqInfo.setRequestNumber("rn");
        EquipmentRequestTypeDO type = new EquipmentRequestTypeDO();
        reqInfo.setRequestType(type);
        type.setCode("code");
        type.setName("name");
        EquipmentRequestReasonDO reas = new EquipmentRequestReasonDO();
        reqInfo.setRequestReason(reas);
        reqInfo.setCriticalCode("cc");
        reqInfo.setMissionImpact("mi");
        Organization org = new Organization();
        reqInfo.setOrganization(org);
        reqInfo.setCustomer(new Customer());
        RequestedEquipmentDO equip = new RequestedEquipmentDO();
        equip.setUnitCost(0f);
        equip.setManufacturer("man");
        equip.setCatalogId("cat");
        reqInfo.setEquipment(equip);
        SuggestedSourceItem ssi = new SuggestedSourceItem();
        List<SuggestedSourceItem> lssi = new ArrayList<>();
        ssi.setSourceName("mame");
        ssi.setCreditCard(true);
        ssi.setPocEmail("am");
        ssi.setPocName("pn");
        ssi.setPocPhone1("asdf");
        ssi.setSourceDivision("div");
        ssi.setPrimarySource(true);
        lssi.add(ssi);
        reqInfo.setSuggestedSources(lssi);
        EquipmentRequestReasonDO reason = new EquipmentRequestReasonDO();
        reqInfo.setRequestReason(reason);
        CatalogItem catalogItem = new CatalogItem();
        reqInfo.setCatalogItem(catalogItem);
        reqInfo.setQuantityRequested(1);
    }

/*
    private <T> void  printErrors(String method, Set<ConstraintViolation<T>> set, int expectedCount) {
        if (expectedCount != set.size()) {
            System.out.println("method = " + method + " : error count - " + set.size());
            for (ConstraintViolation<T> cv : set) {
                System.out.println(cv.getMessage());
            }
        }
        Assert.assertTrue(set.size() == expectedCount);
    }
*/

    @Test
    public void testOk() throws ValidationException {
        this.validator.validate(req);
    }

    @Test
    public void requestTitleTest() throws ValidationException {
        reqInfo.setRequestTitle(null);
        try {
            this.validator.validate(req);
        } catch (ValidationException e) {
            String msg = e.getMessage();
            Assert.assertEquals("Request Information - Request Title required", msg);
        }
    }

    @Test
    public void requestNumberTest() throws ValidationException {
        reqInfo.setRequestNumber(null);
        try {
            this.validator.validate(req);
        } catch (ValidationException e) {
            String msg = e.getMessage();
            Assert.assertEquals("Request Information - Request Number required", msg);
        }
    }

    @Test
    public void requestTypeTest() throws ValidationException {
        reqInfo.setRequestType(null);
        try {
            this.validator.validate(req);
        } catch (ValidationException e) {
            String msg = e.getMessage();
            Assert.assertEquals("Request Information - Request Type required", msg);
        }
    }

    @Test
    public void requestReasonTest() {
        reqInfo.setRequestReason(null);
        try {
            this.validator.validate(req);
        } catch (ValidationException e) {
            String msg = e.getMessage();
            Assert.assertEquals("Request Information - Request Reason required", msg);
        }
    }

    @Test
    public void requestCCTest() throws ValidationException {
        reqInfo.setCriticalCode(null);
        try {
            this.validator.validate(req);
        } catch (ValidationException e) {
            String msg = e.getMessage();
            Assert.assertEquals("Request Information - Criticality Code required", msg);
        }
    }

    @Test
    public void requestMissionImpactTest() throws ValidationException {
        reqInfo.setMissionImpact(null);
        try {
            this.validator.validate(req);
        } catch (ValidationException e) {
            String msg = e.getMessage();
            Assert.assertEquals("Request Information - Mission Impact required", msg);
        }
    }

    @Test
    public void requestOrgTest() throws ValidationException {
        reqInfo.setOrganization(null);
        try {
            this.validator.validate(req);
        } catch (ValidationException e) {
            String msg = e.getMessage();
            Assert.assertEquals("Request Information - Organization required", msg);
        }
    }

    @Test
    public void requestCustTest() throws ValidationException {
        reqInfo.setCustomer(null);
        try {
            this.validator.validate(req);
        } catch (ValidationException e) {
            String msg = e.getMessage();
            Assert.assertEquals("Request Information - Customer required", msg);
        }
    }

    @Test
    public void quantityRequestedTest() throws ValidationException {
        reqInfo.setQuantityRequested(null);
        try {
            this.validator.validate(req);
        } catch (ValidationException e) {
            String msg = e.getMessage();
            Assert.assertEquals("Request Information - Quantity requested required", msg);
        }
    }

    @Test
    public void requestTypeTestErr() throws ValidationException {
        EquipmentRequestTypeDO reqType = new EquipmentRequestTypeDO();
        reqType.setCode("N");
        reqType.setName("name");
        reqInfo.setRequestType(reqType);
        try {
            this.validator.validate(req);
        } catch (ValidationException e) {
            String msg = e.getMessage();
            Assert.assertEquals("Request Information - Type code is invalid", msg);
        }
    }

    @Test
    public void requestTypeTestNoErr() throws ValidationException {
        EquipmentRequestTypeDO reqType = new EquipmentRequestTypeDO();
        reqType.setCode("Z");
        reqType.setName("name");
        reqInfo.setRequestType(reqType);
        try {
            this.validator.validate(req);
        } catch (ValidationException e) {
            String msg = e.getMessage();
            Assert.assertEquals("Request Information - Mission Impact required", msg);
        }
    }

}
