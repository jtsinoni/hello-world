package dmles.equipment.server.business;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dmles.equipment.server.datamodels.request.workflow.definition.LevelDefinitionReviewDO;
import dmles.equipment.server.datamodels.request.workflow.definition.WorkflowLevelDefinitionDO;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class WorkflowLogicUpdateSubmitTest extends WorkflowLogicBaseTest {

    @Test
    public void testUpdateAll() {
        
        List<WorkflowLevelDefinitionDO> definitions = new ArrayList<>();
        WorkflowLevelDefinitionDO level1 = mock(WorkflowLevelDefinitionDO.class);
        WorkflowLevelDefinitionDO level2 = mock(WorkflowLevelDefinitionDO.class);
        definitions.add(level1);
        definitions.add(level2);
        
        when(wfDefinition.getLevelDefinitions()).thenReturn(definitions);
        when(level1.getLevelId()).thenReturn(0);
        List<LevelDefinitionReviewDO> ldwis = new ArrayList<>();
        LevelDefinitionReviewDO ldwi = mock(LevelDefinitionReviewDO.class);
        ldwis.add(ldwi);
        String roleid = "roleid";
        String elementName = "elementName";
        when(ldwi.getRoleId()).thenReturn(roleid);
        when(ldwi.getElementName()).thenReturn(elementName);
        
        when(level1.getLevelDefinitionReviews()).thenReturn(ldwis);
        
        wfLogic.submit();

        verify(wfDefinition).getLevelDefinitions();
        verify(level1).getLevelId();
        verify(level1).getName();
        verify(ldwi).getRoleId();
        verify(ldwi).getElementName();
        verify(level1).getLevelDefinitionReviews();
    }

}
