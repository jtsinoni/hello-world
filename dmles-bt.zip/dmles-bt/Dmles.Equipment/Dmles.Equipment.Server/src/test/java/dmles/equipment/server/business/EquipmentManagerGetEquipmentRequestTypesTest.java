package dmles.equipment.server.business;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dmles.equipment.core.datamodels.request.EquipmentRequestType;
import dmles.equipment.server.datamodels.request.EquipmentRequestTypeDO;
import java.util.ArrayList;
import org.junit.Test;

import java.util.List;

public class EquipmentManagerGetEquipmentRequestTypesTest extends EquipmentManagerBaseTest {
    
    @Test
    public void test1() {
        
        List<EquipmentRequestTypeDO> values = new ArrayList<>();
        
        when(equipmentRequestTypeDao.findAll()).thenReturn(values);
        
        emm.getEquipmentRequestTypes();
        
        verify(equipmentRequestTypeDao).findAll();
        verify(objectMapper).getList(EquipmentRequestType[].class, values);
        
    }

}