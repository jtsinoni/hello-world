package dmles.equipment.server.business;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dmles.equipment.core.datamodels.request.EquipmentRequestReason;
import dmles.equipment.server.datamodels.request.EquipmentRequestReasonDO;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

public class EquipmentManagerGetEquipmentReasonsTest extends EquipmentManagerBaseTest {
    
    @Test
    public void test1() {
        
        List<EquipmentRequestReasonDO> list = new ArrayList<>();
        
        when(equipmentRequestReasonDao.findAll()).thenReturn(list);
        
        emm.getEquipmentRequestReasons();
        
        verify(equipmentRequestReasonDao).findAll();
        verify(objectMapper).getList(EquipmentRequestReason[].class, list);

    }

}