package dmles.equipment.server.business;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dmles.equipment.core.datamodels.request.workflow.process.ReviewStatus;
import dmles.equipment.server.datamodels.request.workflow.process.ReviewDO;
import dmles.equipment.server.datamodels.request.workflow.process.WorkflowLevelProcessingDO;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class WorkflowLogicUpdateReviewStatusTest extends WorkflowLogicBaseTest {

    private final String reviewRoleId = "reviewRoleId";
    private final String status = "status";
    private List<ReviewDO> reviews;
    private ReviewDO wi1;
    private ReviewDO wi2;

    @Override
    @Before
    public void setup() {
        super.setup();
        reviews = new ArrayList<>();
        wi1 = mock(ReviewDO.class);
        wi2 = mock(ReviewDO.class);
        reviews.add(wi2);
        reviews.add(wi1);
        when(wfLevelProcessing.getReviews()).thenReturn(reviews);
    }

    @Test
    public void testUpdateAll() {
        
        wfLogic.updateReviewStatus(wfLevelProcessing, null, status);

        verify(wfLevelProcessing).getReviews();
        verify(wi1).setReviewStatus(status);
        verify(wi2).setReviewStatus(status);

    }

    @Test
    public void testUpdateSome() {

        when(wi1.getRoleId()).thenReturn(reviewRoleId);

        wfLogic.updateReviewStatus(wfLevelProcessing, reviewRoleId, status);

        verify(wfLevelProcessing).getReviews();
        verify(wi1).getRoleId();
        verify(wi1).setReviewStatus(status);
    }

    @Test
    public void testUpdateRework() {

        when(wi1.getRoleId()).thenReturn(reviewRoleId);

        wfLogic.updateReviewStatus(wfLevelProcessing, reviewRoleId, ReviewStatus.REWORK.toString());

        verify(wfLevelProcessing).getReviews();
        verify(wi1).getRoleId();
        verify(wi1).setReviewStatus(ReviewStatus.REWORK.toString());
        verify(wi1).setReviewResult(null);

    }

    @Test
    public void test() {

        WorkflowLevelProcessingDO currLevelIn = mock(WorkflowLevelProcessingDO.class);
        WorkflowLevelProcessingDO currLevelDb = mock(WorkflowLevelProcessingDO.class);
        List<ReviewDO> wIns = new ArrayList<>();
        ReviewDO wIn1 = mock(ReviewDO.class);
        ReviewDO wIn2 = mock(ReviewDO.class);
        wIns.add(wIn1);
        wIns.add(wIn2);
        List<ReviewDO> wDbs = new ArrayList<>();
        ReviewDO wDb2 = mock(ReviewDO.class);
        wDbs.add(wIn1);
        wDbs.add(wDb2);
        String roleId = "roleId";
        when(wDb2.getRoleId()).thenReturn(roleId);
        when(currLevelIn.getReviews()).thenReturn(wIns);
        when(currLevelDb.getReviews()).thenReturn(wDbs);

        wfLogic.updateReviewStatus(currLevelIn, currLevelDb);

        verify(currLevelIn).getReviews();
        verify(currLevelDb).getReviews();
        verify(wDb2).setSelectedUserId(null);
        verify(wDb2).setRoleId(null);
        verify(wDb2).setReviewDisplayName(null);
        verify(wDb2).setReviewStatus(null);

        verify(wIn2).getSelectedUserId();
        verify(wIn2).getRoleId();
        verify(wIn2).getReviewDisplayName();
        verify(wIn2).getReviewStatus();
    }

}
