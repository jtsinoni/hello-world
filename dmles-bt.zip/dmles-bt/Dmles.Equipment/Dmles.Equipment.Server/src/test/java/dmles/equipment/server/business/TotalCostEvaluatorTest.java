package dmles.equipment.server.business;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dmles.equipment.core.datamodels.request.workflow.process.LevelCriteriaNeeded;
import dmles.equipment.server.datamodels.request.EquipmentRequestDO;
import dmles.equipment.server.datamodels.request.workflow.definition.LevelCriteriaDO;
import dmles.equipment.server.datamodels.request.workflow.definition.WorkflowLevelDefinitionDO;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

public class TotalCostEvaluatorTest {

    @Mock
    private EquipmentRequestDO erDo;
    @Mock
    private WorkflowLevelDefinitionDO wldo;
    @Mock
    private LevelCriteriaDO lcdo;

    private TotalCostCriteriaNeededEvaluator eval;
    private LevelCriteriaNeeded lcn;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        eval = new TotalCostCriteriaNeededEvaluator();
        lcn = new LevelCriteriaNeeded();
    }

    @Test
    public void testEval() {
        Float f = 1f;
        when(erDo.getTotalPrice()).thenReturn(f);
        when(wldo.getLevelCriteria()).thenReturn(lcdo);
        when(lcdo.getTotalCostThreshold()).thenReturn(f);

        eval.evaluateCriteria(lcn, erDo, wldo);


        assertTrue(lcn.costCriteriaMet);

        verify(erDo).getTotalPrice();
        verify(wldo).getLevelCriteria();
        verify(lcdo).getTotalCostThreshold();
    }

    @Test
    public void testEvalNull() {
        Float f = 1f;
        when(erDo.getTotalPrice()).thenReturn(f);
        when(wldo.getLevelCriteria()).thenReturn(lcdo);
        when(lcdo.getTotalCostThreshold()).thenReturn(null);

        eval.evaluateCriteria(lcn, erDo, wldo);


        assertFalse(lcn.costCriteriaMet);

        verify(erDo).getTotalPrice();
        verify(wldo).getLevelCriteria();
        verify(lcdo).getTotalCostThreshold();
    }
}
