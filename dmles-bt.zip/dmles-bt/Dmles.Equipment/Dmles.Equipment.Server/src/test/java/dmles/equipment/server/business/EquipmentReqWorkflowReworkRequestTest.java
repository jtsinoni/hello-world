package dmles.equipment.server.business;

import mil.jmlfdc.common.exception.ObjectNotFoundException;
import org.junit.Test;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class EquipmentReqWorkflowReworkRequestTest extends EquipmentReqWorkflowBaseTest {

    @Test
    public void test1() throws ObjectNotFoundException {
        addWorkflowWhens();
        when(wfProcessing.getCurrentLevel()).thenReturn(currentLevelProcessing);
        when(wfProcessing.getNextLevel()).thenReturn(currentLevelProcessing);

        erwm.reworkRequest(requestId);

        verify(requestDO, times(4)).getWfProcessing();
        verify(wfProcessing, times(2)).getCurrentLevel();
        verify(wfProcessing, times(0)).getNextLevel();
        verify(wfProcessing, times(1)).getPreviousLevel();
        verify(wfProcessing, times(0)).isEndOfWorkflow();
        addWorkflowVerifies();
    }
}
