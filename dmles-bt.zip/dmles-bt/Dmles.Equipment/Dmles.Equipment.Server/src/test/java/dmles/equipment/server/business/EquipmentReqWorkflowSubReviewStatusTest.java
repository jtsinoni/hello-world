package dmles.equipment.server.business;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dmles.equipment.server.datamodels.request.EquipmentRequestDO;
import dmles.equipment.server.datamodels.request.workflow.process.WorkflowProcessingDO;
import mil.jmlfdc.common.exception.ObjectNotFoundException;
import org.junit.Test;

public class EquipmentReqWorkflowSubReviewStatusTest extends EquipmentReqWorkflowBaseTest {
    
    @Test
    public void test1() throws ObjectNotFoundException {
        when(objectMapper.getObject(EquipmentRequestDO.class, request)).thenReturn(requestDO);
        String id = "id";
        when(requestDO.getId()).thenReturn(id);
        EquipmentRequestDO dbRequest = mock(EquipmentRequestDO.class);
        when(persistHelper.getRequest(id)).thenReturn(dbRequest);

        when(requestDO.getWfProcessing()).thenReturn(wfProcessing);
        WorkflowProcessingDO dbWfProcessing = mock(WorkflowProcessingDO.class);
        when(dbRequest.getWfProcessing()).thenReturn(dbWfProcessing);
        WorkflowLogic wLogic = mock(WorkflowLogic.class);

        when(wfFactory.rebuildLogic(requestDO)).thenReturn(wLogic);

        erwm.submitReviewStatus(request);

        verify(objectMapper).getObject(EquipmentRequestDO.class, request);
        verify(requestDO).getId();
        verify(persistHelper).getRequest(id);
        verify(requestDO).getWfProcessing();
        verify(dbRequest).getWfProcessing();
        verify(wfFactory).rebuildLogic(requestDO);
        verify(wLogic).addReviewStatus(wfProcessing, dbWfProcessing);

    }
}
