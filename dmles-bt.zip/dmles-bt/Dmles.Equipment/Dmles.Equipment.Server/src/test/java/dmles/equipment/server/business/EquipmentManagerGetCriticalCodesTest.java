package dmles.equipment.server.business;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dmles.equipment.core.datamodels.request.CriticalCode;
import dmles.equipment.server.datamodels.request.CriticalCodeDO;
import org.junit.Test;

import java.util.ArrayList;

import java.util.List;

public class EquipmentManagerGetCriticalCodesTest extends EquipmentManagerBaseTest {
    
    @Test
    public void test1() {
        List<CriticalCodeDO> doList = new ArrayList<>();
                
        when(criticalCodeDao.findAll()).thenReturn(doList);
        
        emm.getCriticalCodes("DA");
        emm.getCriticalCodes("");
        emm.getCriticalCodesByServiceAgencyCode("DF");
    }

}