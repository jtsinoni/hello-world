package dmles.equipment.server.business;

import static org.mockito.Mockito.when;

import dmles.equipment.server.datamodels.request.RequestCriticalityDO;
import org.junit.Test;

import java.util.ArrayList;

import java.util.List;

public class EquipmentManagerGetCriticalCodesTest extends EquipmentManagerBaseTest {
    
    @Test
    public void test1() {
        List<RequestCriticalityDO> doList = new ArrayList<>();
                
        when(criticalCodeDao.findAll()).thenReturn(doList);
        
        emm.getCriticalCodes("DA");
        emm.getCriticalCodes("");
        emm.getCriticalCodesByServiceAgencyCode("DF");
    }

}