package dmles.equipment.server.business;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dmles.equipment.core.datamodels.request.workflow.process.ReviewStatus;
import dmles.equipment.server.datamodels.request.workflow.process.ReviewDO;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class WorkflowLogicUpdateReviewResultTest extends WorkflowLogicBaseTest {

    @Test
    public void test() {
        
        List<ReviewDO> reviews = new ArrayList<>();
        ReviewDO wi1 = mock(ReviewDO.class);
        ReviewDO wi2 = mock(ReviewDO.class);
        reviews.add(wi2);
        reviews.add(wi1);

        when(wfProcessing.getCurrentLevel()).thenReturn(wfLevelProcessing);
        Integer levelId = 0;
        when(wfProcessing.getWfDefinition()).thenReturn(wfDefinition);
        when(wfDefinition.getLevelDefinition(levelId)).thenReturn(wfLevelDefinition);
        when(wfLevelDefinition.getRules()).thenReturn(rulesDo);
        when(rulesDo.getAllowAutoApproveAfterReview()).thenReturn(false);

        when(wfLevelProcessing.getLevelId()).thenReturn(levelId);
        when(wfLevelProcessing.getReviews()).thenReturn(reviews);
        String reviewDisplayName = "Review Name";
        when(wi1.getReviewDisplayName()).thenReturn(reviewDisplayName);
        String result = "result";
        
        wfLogic.updateReviewResult(wfProcessing, reviewDisplayName, result);

        verify(wfProcessing).getCurrentLevel();
        verify(wfProcessing).getWfDefinition();
        verify(wfDefinition).getLevelDefinition(levelId);
        verify(wfLevelDefinition).getRules();
        verify(rulesDo).getAllowAutoApproveAfterReview();

        verify(wfLevelProcessing).getReviews();
        verify(wi1).getReviewDisplayName();
        verify(wi1).setReviewResult(result);
        verify(wi1).setReviewStatus(ReviewStatus.SUBMITTED.toString());
        
    }

}
