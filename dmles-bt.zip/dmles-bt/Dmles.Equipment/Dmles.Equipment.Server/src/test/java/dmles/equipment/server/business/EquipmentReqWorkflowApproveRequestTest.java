package dmles.equipment.server.business;

import mil.jmlfdc.common.exception.ObjectNotFoundException;
import org.junit.Test;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class EquipmentReqWorkflowApproveRequestTest extends EquipmentReqWorkflowBaseTest {
    
    @Test
    public void testIsNotComplete() throws ObjectNotFoundException {
        /*addWorkflowWhens();
        when(wfProcessing.getCurrentLevel()).thenReturn(currentLevelProcessing);
        when(wfProcessing.getNextLevel()).thenReturn(currentLevelProcessing);
        when(wfProcessing.isEndOfWorkflow()).thenReturn(false);
        
        erwm.approveRequest(requestId);
        
        verify(requestDO, times(4)).getWfProcessing();
        verify(wfProcessing).getCurrentLevel();
        verify(wfProcessing).getNextLevel();
        verify(wfProcessing).isEndOfWorkflow();
        addWorkflowVerifies();*/
    }
    
    @Test
    public void testIsComplete() throws ObjectNotFoundException {
        /*addWorkflowWhens();
        when(wfProcessing.getCurrentLevel()).thenReturn(currentLevelProcessing);
        when(wfProcessing.getNextLevel()).thenReturn(currentLevelProcessing);
        when(wfProcessing.isEndOfWorkflow()).thenReturn(true);
        
        erwm.approveRequest(requestId);
        
        verify(requestDO, times(4)).getWfProcessing();
        verify(wfProcessing).getCurrentLevel();
        verify(wfProcessing, times(0)).getNextLevel();
        verify(wfProcessing).isEndOfWorkflow();        
        addWorkflowVerifies();*/
    }    
}
