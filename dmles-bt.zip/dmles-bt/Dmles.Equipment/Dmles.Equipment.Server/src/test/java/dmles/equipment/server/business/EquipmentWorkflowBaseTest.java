package dmles.equipment.server.business;

import dmles.equipment.server.dao.EquipmentRequestDao;
import dmles.equipment.server.dao.WorkflowDefinitionDao;
import dmles.equipment.server.dao.WorkflowProcessingDao;
import mil.jmlfdc.common.utils.ObjectMapper;
import org.junit.Before;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;

public class EquipmentWorkflowBaseTest {
    
    @Mock protected Logger logger;
    @Mock protected ObjectMapper objectMapper;
    @Mock protected EquipmentRequestDao equipReqDao;
    @Mock protected WorkflowProcessingDao wfProcessingDao;
    @Mock protected WorkflowDefinitionDao wfDefinitionDao;
    @Mock protected WorkflowLogicFactory wfFactory;
    @Mock protected EquipmentRequestManager equipmentManager;

    @InjectMocks protected WorkflowProcessingManager erwm;
    
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

}