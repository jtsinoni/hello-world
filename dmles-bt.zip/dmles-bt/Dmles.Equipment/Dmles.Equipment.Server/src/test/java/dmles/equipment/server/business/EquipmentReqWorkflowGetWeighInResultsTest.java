package dmles.equipment.server.business;

import java.util.List;
import org.junit.Assert;
import org.junit.Test;

public class EquipmentReqWorkflowGetWeighInResultsTest extends EquipmentReqWorkflowBaseTest {

    @Test
    public void testEmpty() {
        List<String> statuses = erwm.getWeighInResults();
        Assert.assertNotNull(statuses);
        Assert.assertFalse(statuses.isEmpty());        
    }

}
