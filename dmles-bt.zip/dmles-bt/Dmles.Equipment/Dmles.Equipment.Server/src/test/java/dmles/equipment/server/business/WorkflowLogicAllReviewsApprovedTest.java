package dmles.equipment.server.business;

import dmles.equipment.core.datamodels.request.workflow.process.ReviewResult;
import dmles.equipment.core.datamodels.request.workflow.process.ReviewStatus;
import dmles.equipment.server.datamodels.request.workflow.process.ReviewDO;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;

public class WorkflowLogicAllReviewsApprovedTest {

    private WorkflowLogic logic;
    @Mock private ReviewDO wTrue;
    @Mock private ReviewDO wFalse;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        logic = new WorkflowLogic(null, null, null, null);
        Mockito.when(wTrue.getReviewStatus()).thenReturn(ReviewStatus.SUBMITTED.toString());
        Mockito.when(wTrue.getReviewResult()).thenReturn(ReviewResult.NEUTRAL.toString());
        Mockito.when(wFalse.getReviewStatus()).thenReturn(ReviewStatus.PENDING.toString());

    }

    @Test
    public void test1() {
        List<ReviewDO> list = buildList(0,0, true);

        logic.allReviewsApproved(list);
        verify(0,1);
    }

    // TODO: Fix before going to Test
//    @Test
//    public void test2() {
//        List<ReviewDO> list = buildList(1,0, true);
//
//        logic.allReviewsApproved(list);
//        verify(1,1);
//
//    }

    // TODO: Fix before going to Test
//    @Test
//    public void test21() {
//        List<ReviewDO> list = buildList(1,1, true);
//
//        logic.allReviewsApproved(list);
//        verify(1,1);
//
//    }

    // TODO: Fix before going to Test
//    @Test
//    public void test3() {
//        List<ReviewDO> list = buildList(2,0, true);
//
//        logic.allReviewsApproved(list);
//        verify(2,1);
//
//    }

    // TODO: Fix before going to Test
//    @Test
//    public void test31() {
//        List<ReviewDO> list = buildList(2,1, true);
//
//        logic.allReviewsApproved(list);
//        verify(2,1);
//
//    }

    // TODO: Fix before going to Test
//    @Test
//    public void test4() {
//        List<ReviewDO> list = buildList(3,0, true);
//
//        logic.allReviewsApproved(list);
//        verify(3,1);
//
//    }

    // TODO: Fix before going to Test
//    @Test
//    public void test44() {
//        List<ReviewDO> list = buildList(3,4, true);
//
//        logic.allReviewsApproved(list);
//        verify(3,1);
//
//    }

    // TODO: Fix before going to Test
//    @Test
//    public void test40() {
//        List<ReviewDO> list = buildList(3,4, false);
//
//        logic.allReviewsApproved(list);
//        verify(7,0);
//
//    }

    private void verify(int trueCount, int falseCount) {
        Mockito.verify(wTrue, Mockito.times(trueCount)).getReviewStatus();
        Mockito.verify(wTrue, Mockito.times(trueCount)).getReviewResult();
        Mockito.verify(wFalse, Mockito.times(falseCount)).getReviewStatus();

    }
    private List<ReviewDO> buildList(int numBefore, int numAfter, boolean includeFalse) {
        List<ReviewDO> list = new ArrayList<>();


        list.addAll(buildTrueList(numBefore));
        if (includeFalse) {
            list.add(wFalse);
        }
        list.addAll(buildTrueList(numAfter));
        return list;
    }

    private List<ReviewDO> buildTrueList(int count) {
        List<ReviewDO> list = new ArrayList<>();
        for (int i = 1; i <= count; i++) {
            list.add(wTrue);
        }
        return list;
    }
}
