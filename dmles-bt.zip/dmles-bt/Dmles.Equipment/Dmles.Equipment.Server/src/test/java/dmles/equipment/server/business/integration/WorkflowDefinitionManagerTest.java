package dmles.equipment.server.business.integration;

import dmles.equipment.core.datamodels.request.workflow.definition.WorkflowDefinition;
import dmles.equipment.server.business.WorkflowDefinitionManager;
import dmles.equipment.server.dao.WorkflowDefinitionDao;
import dmles.equipment.server.datamodels.request.workflow.definition.WorkflowDefinitionDO;
import dmles.equipment.server.datamodels.request.workflow.definition.WorkflowLevelDefinitionDO;
import mil.jmlfdc.common.datamodel.CurrentUserBT;
import mil.jmlfdc.common.utils.ListUtil;
import mil.jmlfdc.common.utils.ObjectMapper;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.*;

public class WorkflowDefinitionManagerTest {

    private WorkflowDefinition def = new WorkflowDefinition();
    @Mock
    private WorkflowDefinitionDO fromApi;
    @Mock
    private WorkflowDefinitionDO fromDb;
    @Mock
    private ObjectMapper mapper;
    @Mock
    private WorkflowDefinitionDao wfDefinitionDao;
    @Mock
    private CurrentUserBT user;
    @Mock
    private ListUtil listUtil;

    @InjectMocks
    private WorkflowDefinitionManager mgr;

    private static String ID = "2";

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        when(mapper.getObject(WorkflowDefinitionDO.class, def)).
                thenReturn(fromApi);
        when(fromApi.getId()).thenReturn(ID);
        when(wfDefinitionDao.findById(ID)).thenReturn(fromDb);
    }

    public void stdVerifies() {
        verify(mapper).getObject(WorkflowDefinitionDO.class, def);
        verify(fromApi).getId();
        verify(wfDefinitionDao).findById(ID);
        verify(wfDefinitionDao).update(fromDb);
        verify(mapper).getObject(WorkflowDefinition.class, fromDb);
    }

    @Test
    public void saveWorkflowDefinition() {
        String name = "name";
        when(fromApi.getName()).thenReturn(name);
        String service = "service";
        when(fromApi.getService()).thenReturn(service);
        String profileId = "profileid";
        when(user.getProfileId()).thenReturn(profileId);

        mgr.saveWorkflowDefinition(def);

        stdVerifies();
        verify(fromDb).setDateUpdated(any(Date.class));
        verify(fromDb).setName(name);
        verify(fromDb).setService(service);
        verify(fromDb).setUpdatedBy(profileId);
        verify(fromDb).setDateUpdated(any(Date.class));
    }

    @Test
    public void updateWorkflowLevelTest() {
        List<WorkflowLevelDefinitionDO> apiLevels = new ArrayList<>();
        when(fromApi.getLevelDefinitions()).thenReturn(apiLevels);
        List<WorkflowLevelDefinitionDO> dbLevels = new ArrayList<>();
        when(fromDb.getLevelDefinitions()).thenReturn(dbLevels);
        List<WorkflowLevelDefinitionDO> subApiLevels = new ArrayList<>();
        when(listUtil.subtractList(apiLevels, dbLevels)).thenReturn(subApiLevels);
        List<WorkflowLevelDefinitionDO> subDBLevels = new ArrayList<>();
        when(listUtil.subtractList(dbLevels, apiLevels)).thenReturn(subDBLevels);
        List<WorkflowLevelDefinitionDO> updated = new ArrayList<>();
        when(listUtil.getUpdatedItems(apiLevels, dbLevels)).thenReturn(updated);

        mgr.updateWorkflowLevel(def);

        verify(fromApi).getLevelDefinitions();
        verify(fromDb).getLevelDefinitions();
        verify(listUtil, times(2)).subtractList(apiLevels, dbLevels);
        verify(listUtil).getUpdatedItems(apiLevels, dbLevels);
        verify(listUtil).updateItems(apiLevels, updated);
    }
}
