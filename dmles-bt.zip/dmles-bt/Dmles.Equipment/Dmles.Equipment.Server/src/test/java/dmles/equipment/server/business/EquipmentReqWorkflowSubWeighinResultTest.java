package dmles.equipment.server.business;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dmles.equipment.core.datamodels.request.EquipmentRequest;
import dmles.equipment.core.datamodels.request.workflow.process.WeighInResult;
import mil.jmlfdc.common.exception.ObjectNotFoundException;
import org.junit.Test;

public class EquipmentReqWorkflowSubWeighinResultTest extends EquipmentReqWorkflowBaseTest {
    
    @Test
    public void test1() throws ObjectNotFoundException {
        String weighInResult = WeighInResult.APPROVE.toString();
        
        //addWorkflowWhens();
        WorkflowLogic wlogic = mock(WorkflowLogic.class);

        when(wfFactory.rebuildLogic(anyString())).thenReturn(wlogic);
        when(wlogic.getRequest()).thenReturn(requestDO);
        when(persistHelper.saveRequest(requestDO, wlogic)). thenReturn(requestDO);

        erwm.submitWeighInResult(requestId, weighInRole, weighInResult, weighInDisplayName);

        verify(wfFactory).rebuildLogic(anyString());
        verify(wlogic).addWeighInResult(weighInRole, weighInResult, weighInDisplayName);
        verify(wfFactory).rebuildLogic(requestId);
        verify(persistHelper).saveRequest(requestDO, wlogic);
        verify(objectMapper).getObject(EquipmentRequest.class, requestDO);
    }
}
