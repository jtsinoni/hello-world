package dmles.equipment.server.business;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dmles.equipment.core.datamodels.request.EquipmentManufacturer;
import dmles.equipment.server.datamodels.request.EquipmentManufacturerDO;
import org.junit.Test;

import java.util.ArrayList;

import java.util.List;
import static org.mockito.Mockito.verify;

public class EquipmentManagerGetEquipmentManufacturersTest extends EquipmentManagerBaseTest {
    
    @Test
    public void test1() {
        List<EquipmentManufacturerDO> doList = new ArrayList<>();
        
        when(equipmentManufacturerDao.findCodeAndText()).thenReturn(doList);
        
        emm.getEquipmentManufacturers();
        
        verify(equipmentManufacturerDao).findCodeAndText();
        verify(objectMapper).getList(EquipmentManufacturer[].class, doList);
    }

}