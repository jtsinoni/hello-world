package dmles.equipment.server.business;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dmles.equipment.core.datamodels.request.workflow.process.WeighInStatus;
import dmles.equipment.server.datamodels.request.workflow.process.WeighInDO;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class WorkflowLogicUpdateWeighInResultTest extends WorkflowLogicBaseTest {

    @Test
    public void test() {
        
        List<WeighInDO> weighIns = new ArrayList<>();
        WeighInDO wi1 = mock(WeighInDO.class);
        WeighInDO wi2 = mock(WeighInDO.class);
        weighIns.add(wi2);
        weighIns.add(wi1);

        when(wfProcessing.getCurrentLevel()).thenReturn(wfLevelProcessing);
        Integer levelId = 0;
        when(wfProcessing.getWfDefinition()).thenReturn(wfDefinition);
        when(wfDefinition.getLevelDefinition(levelId)).thenReturn(wfLevelDefinition);
        when(wfLevelDefinition.getRules()).thenReturn(rulesDo);
        when(rulesDo.getAllowAutoApproveAfterWeighIn()).thenReturn(false);

        when(wfLevelProcessing.getLevelId()).thenReturn(levelId);
        when(wfLevelProcessing.getWeighIns()).thenReturn(weighIns);
        String weighInRoleId = "weighInRoleId";
        when(wi1.getRoleId()).thenReturn(weighInRoleId);
        String result = "result";
        
        wfLogic.updateWeighInResult(wfProcessing, weighInRoleId, result);

        verify(wfProcessing).getCurrentLevel();
        verify(wfProcessing).getWfDefinition();
        verify(wfDefinition).getLevelDefinition(levelId);
        verify(wfLevelDefinition).getRules();
        verify(rulesDo).getAllowAutoApproveAfterWeighIn();

        verify(wfLevelProcessing).getWeighIns();
        verify(wi1).getRoleId();
        verify(wi1).setWeighInResult(result);
        verify(wi1).setWeighInStatus(WeighInStatus.SUBMITTED.toString());
        
    }

}
