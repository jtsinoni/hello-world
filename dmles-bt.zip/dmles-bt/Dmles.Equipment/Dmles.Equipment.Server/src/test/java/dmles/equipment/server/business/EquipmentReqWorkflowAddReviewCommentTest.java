package dmles.equipment.server.business;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import mil.jmlfdc.common.exception.ObjectNotFoundException;
import org.junit.Test;

public class EquipmentReqWorkflowAddReviewCommentTest extends EquipmentReqWorkflowBaseTest {
    
    @Test
    public void test1() throws ObjectNotFoundException {
        addWorkflowWhens();
        when(wfProcessing.getCurrentLevel()).thenReturn(currentLevelProcessing);
        
        erwm.addReviewComment(requestId, reviewRole, comment);
        
        verify(requestDO, times(3)).getWfProcessing();
        addWorkflowVerifies();
    }
}
