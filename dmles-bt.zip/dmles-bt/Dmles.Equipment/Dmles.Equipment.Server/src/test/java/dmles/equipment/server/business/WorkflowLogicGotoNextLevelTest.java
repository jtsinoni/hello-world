package dmles.equipment.server.business;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dmles.equipment.core.datamodels.request.workflow.process.WorkflowLevelStatus;
import dmles.equipment.server.datamodels.request.workflow.process.WorkflowHistoryDO;
import org.junit.Test;


public class WorkflowLogicGotoNextLevelTest extends WorkflowLogicBaseTest {

    @Test
    public void testNextLevelIsComplete() {
        /*when(request.getWfProcessing()).thenReturn(wfProcessing);
        when(wfProcessing.isEndOfWorkflow()).thenReturn(true);
        
        wfLogic.goToNextLevel();

        verify(request).getWfProcessing();
        verify(wfProcessing).isEndOfWorkflow();
        verify(wfProcessing).setIsCompleted(true);
        verify(wfProcessing).setCurrentStatus(WorkflowLevelStatus.APPROVED.toString());
        */
    }

    @Test
    public void testNextLevelNotComplete() {
        /*when(request.getWfProcessing()).thenReturn(wfProcessing);
        when(wfProcessing.isEndOfWorkflow()).thenReturn(false);
        when(wfProcessing.getNextLevel()).thenReturn(wfLevelProcessing);
        Integer levelId = 2;
        when(wfLevelProcessing.getLevelId()).thenReturn(levelId);
        String roleOwner = "roleOwner";
        when(wfDefinition.getRoleOwner(levelId)).thenReturn(roleOwner);
        
        wfLogic.goToNextLevel();

        verify(request).getWfProcessing();
        verify(wfProcessing).isEndOfWorkflow();
        verify(wfProcessing).getNextLevel();
        verify(wfLevelProcessing).getLevelId();
        verify(wfDefinition).getRoleOwner(levelId);
        verify(wfProcessing).setCurrentOwnerRole(roleOwner);
        verify(wfProcessing).setCurrentLevelId(levelId);
        verify(wfLevelProcessing).updateStatus(WorkflowLevelStatus.ACTIVE.toString(), WorkflowHistoryDO.SYSTEM);
        */
    }

}
