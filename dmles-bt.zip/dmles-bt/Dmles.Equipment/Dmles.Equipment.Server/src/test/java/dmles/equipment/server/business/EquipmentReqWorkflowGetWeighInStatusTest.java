package dmles.equipment.server.business;

import java.util.List;
import org.junit.Assert;
import org.junit.Test;

public class EquipmentReqWorkflowGetWeighInStatusTest extends EquipmentReqWorkflowBaseTest {

    @Test
    public void testEmpty() {
        List<String> statuses = erwm.getWeighInStatuses();
        Assert.assertNotNull(statuses);
        Assert.assertFalse(statuses.isEmpty());
    }

}
