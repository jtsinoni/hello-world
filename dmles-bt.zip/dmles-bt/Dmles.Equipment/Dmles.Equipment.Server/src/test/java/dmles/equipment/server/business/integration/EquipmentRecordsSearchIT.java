package dmles.equipment.server.business.integration;

import dmles.equipment.server.EquipmentIntegrationBase;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import com.fasterxml.jackson.databind.ObjectMapper;
import dmles.equipment.server.business.ElasticSearchManager;
import dmles.equipment.server.datamodels.ElasticResult;
import org.junit.Test;

import java.io.IOException;
import javax.inject.Inject;

public class EquipmentRecordsSearchIT extends EquipmentIntegrationBase {
    
    @Inject
    private ElasticSearchManager searchManager;
    
    @Test
    public void testSearch() throws IOException {
        
        String results = searchManager.getEquipmentRecordSearchResults("test", "");
        
        assertNotNull(results);
        ObjectMapper mapper = new ObjectMapper();
        
        ElasticResult result = mapper.readValue(results, ElasticResult.class);
        assertTrue(result.hits.total > 0);
        
        System.out.println("Search hits - " + result.hits.total );
    }

}
