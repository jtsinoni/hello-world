package dmles.equipment.server.business.integration;

import dmles.equipment.server.EquipmentIntegrationBase;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import com.fasterxml.jackson.databind.ObjectMapper;
import dmles.equipment.server.business.ElasticSearchManager;
import dmles.equipment.server.datamodels.ElasticResult;
import org.junit.Test;

import java.io.IOException;
import javax.inject.Inject;

public class EquipmentCatalogSearchIT extends EquipmentIntegrationBase {
    
    @Inject
    private ElasticSearchManager searchManager;
    
    @Test
    public void testSearch() throws IOException {
        
        String results = searchManager.getCatalogSearchResults("test", null);
        
        assertNotNull(results);

        ObjectMapper mapper = new ObjectMapper();
        
        ElasticResult result = mapper.readValue(results, ElasticResult.class);
        assertTrue(result.hits.total > 0);
        
        System.out.println("Search Hits - " + result.hits.total);
    }

    @Test
    public void testSearchMiss() throws IOException {
        
        String results = searchManager.getCatalogSearchResults("asdfadsqwerqew", null);
        
        assertNotNull(results);

        ObjectMapper mapper = new ObjectMapper();

        ElasticResult result = mapper.readValue(results, ElasticResult.class);

        assertEquals(0, result.hits.total);

        System.out.println("Search Hits - " + result.hits.total);
    }
    
}
