package dmles.equipment.server.business;

import dmles.equipment.server.dao.WorkflowProcessingDao;
import dmles.equipment.server.datamodels.request.EquipmentRequestDO;
import dmles.equipment.server.datamodels.request.workflow.definition.RulesDO;
import dmles.equipment.server.datamodels.request.workflow.definition.WorkflowDefinitionDO;
import dmles.equipment.server.datamodels.request.workflow.definition.WorkflowLevelDefinitionDO;
import dmles.equipment.server.datamodels.request.workflow.process.WorkflowCommentDO;
import dmles.equipment.server.datamodels.request.workflow.process.WorkflowLevelProcessingDO;
import dmles.equipment.server.datamodels.request.workflow.process.WorkflowProcessingDO;
import mil.jmlfdc.common.datamodel.CurrentUserBT;
import org.junit.Before;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

class WorkflowLogicBaseTest {

    @Mock CurrentUserBT user;
    @Mock EquipmentRequestDO request;
    @Mock WorkflowDefinitionDO wfDefinition;
    @Mock WorkflowCommentDO commentDO;    
    @Mock WorkflowProcessingDO wfProcessing;
    @Mock WorkflowLevelProcessingDO wfLevelProcessing;
    @Mock WorkflowProcessingDao wfProcessingDao;
    @Mock WorkflowLevelDefinitionDO wfLevelDefinition;
    @Mock RulesDO rulesDo;
    WorkflowLogic wfLogic;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        wfLogic = new WorkflowLogic(request, wfDefinition, user, wfProcessingDao);
    }
}
