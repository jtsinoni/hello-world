package dmles.equipment.server.business;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;


public class ElasticSearchAggregationsTest {
    
    private final static String AGGS = 
      "{\"aggregations\": [{\"name\":\"orgIds\",\"field\":\"orgId\",\"size\":\"300\"}," +
         "{\"name\":\"custOrgIds\",\"field\":\"custOrgId\",\"size\":\"5000\"}]}";
    
    @Mock Logger logger;
    @InjectMocks private ElasticSearchAggregations esAggs;
    
    @Before
    public void setup() {
        esAggs = new ElasticSearchAggregations();
        MockitoAnnotations.initMocks(this);
    }
    
    @Test
    public void test1() {
        
        String result = esAggs.processAggregations(AGGS);
        Assert.assertNotNull(result);
        Assert.assertEquals(1, countOccurences(result, "\"orgIds\" : {"));
        Assert.assertEquals(1, countOccurences(result, "\"field\" : \"orgId\","));
        Assert.assertEquals(1, countOccurences(result, "\"size\" : 300,"));
        Assert.assertEquals(1, countOccurences(result, "\"custOrgIds\" : {"));
        Assert.assertEquals(1, countOccurences(result, "\"field\" : \"custOrgId\""));
        Assert.assertEquals(1, countOccurences(result, "\"size\" : 5000,"));
        Assert.assertEquals(2, countOccurences(result, "\"terms\" : {"));
        Assert.assertEquals(2, countOccurences(result, "\"order\" : {"));
        Assert.assertEquals(2, countOccurences(result, "\"_term\" : \"asc\""));
        
    }
    
    private int countOccurences(String result, String search) {
        
        int count = 0;
        
        int pos = 0;
        
        do {
            pos = result.indexOf(search, pos + 1);
            if (pos >= 0) {
                count ++;
            }
        } while (pos >= 0);
        
        return count;
    }
}
