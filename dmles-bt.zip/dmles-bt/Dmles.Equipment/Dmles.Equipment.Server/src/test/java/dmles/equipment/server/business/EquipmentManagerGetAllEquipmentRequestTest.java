package dmles.equipment.server.business;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dmles.equipment.core.datamodels.request.EquipmentRequest;
import dmles.equipment.server.datamodels.request.EquipmentRequestDO;
import org.junit.Test;

import java.util.ArrayList;

import java.util.List;

public class EquipmentManagerGetAllEquipmentRequestTest extends EquipmentManagerBaseTest {
    
    @Test
    public void test1() {
        List<EquipmentRequestDO> doList = new ArrayList<>();
        
        when(equipmentRequestDao.findAll()).thenReturn(doList);
        
        emm.getAllEquipmentRequests();
        
        verify(equipmentRequestDao).findAll();
        verify(objectMapper).getList(EquipmentRequest[].class, doList);
    }

}