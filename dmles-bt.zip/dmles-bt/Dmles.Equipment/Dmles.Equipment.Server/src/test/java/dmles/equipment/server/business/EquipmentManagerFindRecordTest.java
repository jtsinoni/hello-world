package dmles.equipment.server.business;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dmles.equipment.core.datamodels.record.EquipmentRecord;
import dmles.equipment.server.datamodels.record.EquipmentRecordDO;
import org.junit.Test;

import java.util.ArrayList;

import java.util.List;

public class EquipmentManagerFindRecordTest extends EquipmentRecordManagerBaseTest {
    
    @Test
    public void test0() {
        String dodaac = "id";
        int meId = 1;
        List<EquipmentRecordDO> doList = new ArrayList<>();
        
        when(equipmentRecordDao.findRecord(dodaac, meId)).thenReturn(doList);
        
        erm.findRecord(dodaac, meId);
        
        verify(equipmentRecordDao).findRecord(dodaac, meId);
    }

    @Test
    public void test1() {
        String dodaac = "id";
        int meId = 1;
        List<EquipmentRecordDO> doList = new ArrayList<>();
        EquipmentRecordDO edo = mock(EquipmentRecordDO.class);
        doList.add(edo);
        
        when(equipmentRecordDao.findRecord(dodaac, meId)).thenReturn(doList);
        
        erm.findRecord(dodaac, meId);
        
        verify(equipmentRecordDao).findRecord(dodaac, meId);
        verify(objectMapper).getObject(EquipmentRecord.class, edo);
    }

}