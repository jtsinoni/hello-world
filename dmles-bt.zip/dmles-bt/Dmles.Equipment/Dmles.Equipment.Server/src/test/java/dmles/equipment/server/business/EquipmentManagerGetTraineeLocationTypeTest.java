package dmles.equipment.server.business;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dmles.equipment.core.datamodels.request.TraineeLocationType;
import dmles.equipment.server.datamodels.request.TraineeLocationTypeDO;
import org.junit.Test;

import java.util.ArrayList;

import java.util.List;

public class EquipmentManagerGetTraineeLocationTypeTest extends EquipmentManagerBaseTest {
    
    @Test
    public void test1() {
        List<TraineeLocationTypeDO> doList = new ArrayList<>();
        
        when(traineeLocationTypeDao.findAll()).thenReturn(doList);
        
        emm.getTraineeLocationTypes();
        
        verify(traineeLocationTypeDao).findAll();
        verify(objectMapper).getList(TraineeLocationType[].class, doList);
    }

}