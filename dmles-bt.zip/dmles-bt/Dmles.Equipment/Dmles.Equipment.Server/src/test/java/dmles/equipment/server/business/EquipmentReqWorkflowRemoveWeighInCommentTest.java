package dmles.equipment.server.business;


import dmles.equipment.server.datamodels.request.workflow.process.WeighInDO;
import java.util.ArrayList;
import java.util.List;
import mil.jmlfdc.common.exception.ObjectNotFoundException;
import dmles.equipment.server.datamodels.CommentDO;
import org.junit.Assert;
import org.junit.Test;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;



public class EquipmentReqWorkflowRemoveWeighInCommentTest extends EquipmentReqWorkflowBaseTest {
    
    @Test
    public void testRemoveComment() throws ObjectNotFoundException {
        String commentIdStr = "1234";
        Long commentIdL = 1234L;       
        
        List<CommentDO> comments =  new ArrayList<>();
        CommentDO commentDataObj = new CommentDO();
        commentDataObj.setComment(comment);
        commentDataObj.setId(commentIdL);
        comments.add(commentDataObj);
        
        List<WeighInDO> weighIns = new ArrayList<>();
        WeighInDO weighInObj = new WeighInDO();
        weighInObj.setComments(comments);
        weighInObj.setRoleId(weighInRole);
        weighIns.add(weighInObj);

        addWorkflowWhens();
        when(wfProcessing.getCurrentLevel()).thenReturn(currentLevelProcessing);
        when(currentLevelProcessing.getWeighIns()).thenReturn(weighIns);
        when(weighIn.getRoleId()).thenReturn(weighInRole);
        when(weighIn.getComments()).thenReturn(comments);
        when(commentObj.getId()).thenReturn(commentIdL);
        
        erwm.removeWeighInComment(requestId, weighInRole, commentIdStr);
        
        Assert.assertEquals(0, comments.size());
        
        verify(requestDO, times(3)).getWfProcessing();
        verify(wfProcessing).getCurrentLevel();
        verify(currentLevelProcessing, times(3)).getWeighIns();
        
        verify(wfProcessing, times(0)).getNextLevel();
        verify(wfProcessing, times(0)).getPreviousLevel();
        verify(wfProcessing, times(0)).isEndOfWorkflow();

        addWorkflowVerifies();          
    }
        
}
