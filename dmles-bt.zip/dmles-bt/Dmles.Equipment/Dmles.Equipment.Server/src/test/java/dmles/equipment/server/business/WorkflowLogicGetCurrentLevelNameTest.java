package dmles.equipment.server.business;

import org.junit.Test;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class WorkflowLogicGetCurrentLevelNameTest extends WorkflowLogicBaseTest {

    private final String id = "id";
    private final String levelName = "levelName";

    @Test
    public void testSaveNull() {
        when(request.getWfProcessing()).thenReturn(null);

        wfLogic.getCurrentLevelName();

        verify(request).getWfProcessing();
    }

    @Test
    public void testSaveNull2() {
        when(request.getWfProcessing()).thenReturn(wfProcessing);
        when(wfProcessing.getId()).thenReturn(null);

        wfLogic.getCurrentLevelName();

        verify(request).getWfProcessing();
        verify(wfProcessing).getId();
    }

    @Test
    public void testSaveEmpty() {
        when(request.getWfProcessing()).thenReturn(wfProcessing);
        when(wfProcessing.getId()).thenReturn("");

        wfLogic.getCurrentLevelName();

        verify(request).getWfProcessing();
        verify(wfProcessing).getId();
    }

    @Test
    public void testSaveOK() {
        when(request.getWfProcessing()).thenReturn(wfProcessing);
        when(wfProcessing.getId()).thenReturn(id);
        when(wfProcessing.getCurrentLevel()).thenReturn(wfLevelProcessing);
        when(wfLevelProcessing.getLevelName()).thenReturn(levelName);

        wfLogic.getCurrentLevelName();

        verify(request).getWfProcessing();
        verify(wfProcessing).getId();
        verify(wfProcessing).getCurrentLevel();
        verify(wfLevelProcessing).getLevelName();
    }

}
