package dmles.equipment.server.business;

import dmles.equipment.core.datamodels.request.workflow.definition.WorkflowDefinition;
import dmles.equipment.server.datamodels.request.workflow.definition.WorkflowDefinitionDO;
import mil.jmlfdc.common.exception.ObjectNotFoundException;
import org.junit.Test;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class EquipmentReqWorkflowCreateWorkflowDefinitionTest extends EquipmentReqWorkflowBaseTest {

    @Test
    public void testEmpty() throws ObjectNotFoundException {
        
        WorkflowDefinition workflowDefinition = mock(WorkflowDefinition.class);
        WorkflowDefinitionDO workflowDefinitionDO = mock(WorkflowDefinitionDO.class);
        
        when(objectMapper.getObject(WorkflowDefinitionDO.class, workflowDefinition))
                .thenReturn(workflowDefinitionDO);
        
        wfdm.createWorkflowDefinition(workflowDefinition);
        
        verify(objectMapper).getObject(WorkflowDefinitionDO.class, workflowDefinition);
        verify(wfDefinitionDao).upsert(workflowDefinitionDO);
        verify(objectMapper).getObject(eq(WorkflowDefinition.class), any(WorkflowDefinitionDO.class));
    }

    @Test
    public void testValid() throws ObjectNotFoundException {
        
        String id = "id";
        
        WorkflowDefinition workflowDefinition = mock(WorkflowDefinition.class);
        WorkflowDefinitionDO workflowDefinitionDO = mock(WorkflowDefinitionDO.class);
        
        when(objectMapper.getObject(WorkflowDefinitionDO.class, workflowDefinition))
                .thenReturn(workflowDefinitionDO);
        when(workflowDefinitionDO.getId()).thenReturn(id);
        when(wfDefinitionDao.findById(id)).thenReturn(workflowDefinitionDO);
        
        wfdm.createWorkflowDefinition(workflowDefinition);
        
        verify(objectMapper).getObject(WorkflowDefinitionDO.class, workflowDefinition);
        verify(workflowDefinitionDO, times(2)).getId();
        verify(wfDefinitionDao).findById(id);
        verify(wfDefinitionDao).upsert(workflowDefinitionDO);
        verify(objectMapper).getObject(eq(WorkflowDefinition.class), any(WorkflowDefinitionDO.class));
    }
}
