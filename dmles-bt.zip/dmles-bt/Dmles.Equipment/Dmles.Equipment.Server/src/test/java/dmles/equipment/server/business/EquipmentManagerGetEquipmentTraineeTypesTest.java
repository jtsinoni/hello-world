package dmles.equipment.server.business;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dmles.equipment.core.datamodels.request.EquipmentTraineeType;
import dmles.equipment.server.datamodels.request.EquipmentTraineeTypeDO;
import org.junit.Test;

import java.util.ArrayList;

import java.util.List;

public class EquipmentManagerGetEquipmentTraineeTypesTest extends EquipmentManagerBaseTest {
    
    @Test
    public void test1() {
        List<EquipmentTraineeTypeDO> doList = new ArrayList<>();
        
        when(equipmentTraineeTypeDao.findAll()).thenReturn(doList);
        
        emm.getEquipmentTraineeTypes();
        
        verify(equipmentTraineeTypeDao).findAll();
        verify(objectMapper).getList(EquipmentTraineeType[].class, doList);
    }

}