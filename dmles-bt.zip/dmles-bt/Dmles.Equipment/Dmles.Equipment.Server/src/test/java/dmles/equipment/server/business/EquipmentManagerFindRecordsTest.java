package dmles.equipment.server.business;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dmles.equipment.core.datamodels.record.EquipmentRecord;
import dmles.equipment.server.datamodels.record.EquipmentRecordDO;
import org.junit.Test;

import java.util.ArrayList;

import java.util.List;

public class EquipmentManagerFindRecordsTest extends EquipmentRecordManagerBaseTest {
    
    @Test
    public void test1() {
        String dodaac = "dodaac";
        int meId = 1;
        
        List<EquipmentRecordDO> doList = new ArrayList<>();
        
        when(equipmentRecordDao.findRecord(dodaac, meId)).thenReturn(doList);
        
        erm.findRecords(dodaac, meId);
        
        verify(equipmentRecordDao).findRecord(dodaac, meId);
        verify(objectMapper).getList(EquipmentRecord[].class, doList);
    }

}