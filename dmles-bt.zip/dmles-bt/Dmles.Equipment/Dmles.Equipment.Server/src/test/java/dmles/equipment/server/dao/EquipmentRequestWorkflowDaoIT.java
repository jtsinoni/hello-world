package dmles.equipment.server.dao;

import dmles.equipment.server.EquipmentIntegrationBase;
import org.apache.deltaspike.core.api.config.ConfigProperty;
import org.jboss.arquillian.junit.Arquillian;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.MalformedURLException;
import javax.inject.Inject;

@RunWith(Arquillian.class)
public class EquipmentRequestWorkflowDaoIT extends EquipmentIntegrationBase {

    private final static Logger logger = LoggerFactory.getLogger(EquipmentRequestWorkflowDaoIT.class);

    private String id;

    @Inject
    private WorkflowDefinitionDao wfDefDao;
    @Inject
    @ConfigProperty(name = "database")
    private String database;

    @Before
    public void setUp() throws MalformedURLException {
        logger.info("setUp()::Setting up for EquipmentRequestWorkflowDao Tests");
        logger.info("Using database " + database);
    }

    @Test
    public void equipmentRequestWorkflowDaoNotNull() {
        logger.info("equipmentRequestWorkflowDaoNotNull():: wfDao is {}", wfDefDao);
        Assert.assertNotNull(wfDefDao);
    }

    @After
    public void cleanUp() {
        if (id != null) {
            //fupd.deleteById(id);
            //logger.info("cleanUp:: removing id {} from database.", id);
        }
    }
}
