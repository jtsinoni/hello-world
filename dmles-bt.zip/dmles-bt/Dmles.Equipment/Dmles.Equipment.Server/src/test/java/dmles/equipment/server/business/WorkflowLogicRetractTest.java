package dmles.equipment.server.business;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dmles.equipment.core.datamodels.request.workflow.process.WorkflowLevelStatus;
import dmles.equipment.server.datamodels.request.workflow.definition.WorkflowLevelDefinitionDO;
import dmles.equipment.server.datamodels.request.workflow.process.WorkflowLevelProcessingDO;
import mil.jmlfdc.common.datamodel.UserType;
import mil.jmlfdc.common.exception.InvalidDataException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;

import java.util.ArrayList;
import java.util.List;

public class WorkflowLogicRetractTest extends WorkflowLogicBaseTest {

    private  List<WorkflowLevelDefinitionDO> levelDefs;
    private WorkflowLevelDefinitionDO wfd0;
    private WorkflowLevelDefinitionDO wfd1;
    private WorkflowLevelDefinitionDO wfd2;
    private WorkflowLevelDefinitionDO wfd3;
    @Mock
    WorkflowLevelProcessingDO wfLevelProcessing3;
    @Mock
    WorkflowLevelProcessingDO wfLevelProcessing2;
    @Mock
    WorkflowLevelProcessingDO wfLevelProcessing1;
    @Mock
    WorkflowLevelProcessingDO wfLevelProcessing0;

    @Override
    @Before
    public void setup() {
        super.setup();
        levelDefs = new ArrayList<>();
        wfd0 = mock(WorkflowLevelDefinitionDO.class);
        wfd1 = mock(WorkflowLevelDefinitionDO.class);
        wfd2 = mock(WorkflowLevelDefinitionDO.class);
        wfd3 = mock(WorkflowLevelDefinitionDO.class);
        levelDefs.add(wfd0);
        levelDefs.add(wfd1);
        levelDefs.add(wfd2);
        levelDefs.add(wfd3);
        when(wfd0.getUserType()).thenReturn(UserType.SITE.name());
        when(wfd1.getUserType()).thenReturn(UserType.SERVICEREGION.name());
        when(wfd2.getUserType()).thenReturn(UserType.SERVICE.name());
        when(wfd3.getUserType()).thenReturn(UserType.GLOBAL.name());

    }

    @Test
    public void testGetUserWfLevelOk() throws InvalidDataException {

        when(wfDefinition.getLevelDefinitions()).thenReturn(levelDefs);
        when(wfd0.getLevelId()).thenReturn(0);
        when(wfd0.getUserType()).thenReturn(UserType.SERVICE.name());
        wfLogic.getUserWfLevel(wfDefinition, UserType.SERVICE);

        verify(wfDefinition).getLevelDefinitions();
        verify(wfd0).getLevelId();
        verify(wfd0).getUserType();

    }

    @Test(expected = InvalidDataException.class)
    public void testGetUserWfLevelNull() throws InvalidDataException {

        wfLogic.getUserWfLevel(wfDefinition, null);

    }

    @Test
    public void testRetractOK() throws InvalidDataException {
        when(request.getWfProcessing()).thenReturn(wfProcessing);
        when(user.getUserType()).thenReturn(UserType.SITE);
        when(wfProcessing.getWfDefinition()).thenReturn(wfDefinition);
        when(wfProcessing.getCurrentLevelId()).thenReturn(2);
        when(wfDefinition.getLevelDefinitions()).thenReturn(levelDefs);
        when(wfd0.getUserType()).thenReturn(UserType.SITE.name());
        when(wfd1.getUserType()).thenReturn(UserType.SERVICEREGION.name());
        when(wfd2.getUserType()).thenReturn(UserType.SERVICE.name());
        when(wfProcessing.getLevel(2)).thenReturn(wfLevelProcessing2);
        when(wfProcessing.getLevel(1)).thenReturn(wfLevelProcessing1);
        when(wfProcessing.getLevel(0)).thenReturn(wfLevelProcessing0);

        when(wfDefinition.getLevelDefinitions()).thenReturn(levelDefs);

        wfLogic.retract();
        verify(request).getWfProcessing();
        verify(user).getUserType();
        verify(wfProcessing).getWfDefinition();
        verify(wfProcessing).getCurrentLevelId();
        verify(wfDefinition).getLevelDefinitions();
        verify(wfd0).getUserType();
        verify(wfProcessing).getLevel(2);
        verify(wfProcessing).getLevel(1);
        verify(wfProcessing).getLevel(0);

        verify(wfProcessing).setCurrentLevelId(0);
        verify(wfLevelProcessing2).updateStatus(WorkflowLevelStatus.RETRACTED.toString(), null);
        verify(wfLevelProcessing1).updateStatus(WorkflowLevelStatus.RETRACTED.toString(), null);
        verify(wfLevelProcessing0).updateStatus(WorkflowLevelStatus.ACTIVE.toString(), null);

    }

    @Test
    public void testRetractTooHigh() throws InvalidDataException {
        when(request.getWfProcessing()).thenReturn(wfProcessing);
        when(user.getUserType()).thenReturn(UserType.GLOBAL);
        when(wfProcessing.getWfDefinition()).thenReturn(wfDefinition);
        when(wfProcessing.getCurrentLevelId()).thenReturn(0);
        when(wfDefinition.getLevelDefinitions()).thenReturn(levelDefs);
        when(wfd3.getLevelId()).thenReturn(3);
        when(wfd0.getUserType()).thenReturn(UserType.SITE.name());
        when(wfd1.getUserType()).thenReturn(UserType.SERVICEREGION.name());
        when(wfd2.getUserType()).thenReturn(UserType.SERVICE.name());
        when(wfd3.getUserType()).thenReturn(UserType.GLOBAL.name());

        when(wfDefinition.getLevelDefinitions()).thenReturn(levelDefs);

        wfLogic.retract();
        verify(request).getWfProcessing();
        verify(user).getUserType();
        verify(wfProcessing).getWfDefinition();
        verify(wfProcessing).getCurrentLevelId();
        verify(wfDefinition).getLevelDefinitions();
        verify(wfd3).getLevelId();
        verify(wfd2, times(0)).getLevelId();
        verify(wfd2).getUserType();
        verify(wfd1).getUserType();
        verify(wfd0).getUserType();

        verify(wfLevelProcessing3, times(0)).updateStatus(WorkflowLevelStatus.RETRACTED.toString(), null);
        verify(wfLevelProcessing2, times(0)).updateStatus(WorkflowLevelStatus.RETRACTED.toString(), null);
        verify(wfLevelProcessing1, times(0)).updateStatus(WorkflowLevelStatus.RETRACTED.toString(), null);
        verify(wfLevelProcessing0, times(0)).updateStatus(WorkflowLevelStatus.RETRACTED.toString(), null);

    }

    @Test
    public void testRetractSame() throws InvalidDataException {

        when(request.getWfProcessing()).thenReturn(wfProcessing);
        when(user.getUserType()).thenReturn(UserType.SERVICEREGION);
        when(wfProcessing.getWfDefinition()).thenReturn(wfDefinition);
        when(wfProcessing.getCurrentLevelId()).thenReturn(1);
        when(wfDefinition.getLevelDefinitions()).thenReturn(levelDefs);
        when(wfd1.getLevelId()).thenReturn(1);
        when(wfd0.getUserType()).thenReturn(UserType.SITE.name());
        when(wfd1.getUserType()).thenReturn(UserType.SERVICEREGION.name());
        when(wfd2.getUserType()).thenReturn(UserType.SERVICE.name());
        when(wfd3.getUserType()).thenReturn(UserType.GLOBAL.name());
        when(wfProcessing.getLevel(1)).thenReturn(wfLevelProcessing1);

        when(wfDefinition.getLevelDefinitions()).thenReturn(levelDefs);

        wfLogic.retract();
        verify(request).getWfProcessing();
        verify(user).getUserType();
        verify(wfProcessing).getWfDefinition();
        verify(wfProcessing).getCurrentLevelId();
        verify(wfDefinition).getLevelDefinitions();
        verify(wfd1).getLevelId();
        verify(wfd1).getUserType();
        verify(wfd0).getUserType();

        verify(wfProcessing).setCurrentLevelId(1);
        verify(wfLevelProcessing3, times(0)).updateStatus(WorkflowLevelStatus.RETRACTED.toString(), null);
        verify(wfLevelProcessing2, times(0)).updateStatus(WorkflowLevelStatus.RETRACTED.toString(), null);
        verify(wfLevelProcessing1, times(1)).updateStatus(WorkflowLevelStatus.ACTIVE.toString(), null);
        verify(wfLevelProcessing0, times(0)).updateStatus(WorkflowLevelStatus.RETRACTED.toString(), null);

    }
}
