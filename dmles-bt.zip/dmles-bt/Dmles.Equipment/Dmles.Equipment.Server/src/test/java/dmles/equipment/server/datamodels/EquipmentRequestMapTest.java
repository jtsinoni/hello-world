package dmles.equipment.server.datamodels;

import static org.junit.Assert.*;

import dmles.equipment.core.datamodels.record.EquipmentRecord;
import dmles.equipment.server.datamodels.record.ApprovalDO;
import dmles.equipment.server.datamodels.record.ComponentsDO;
import dmles.equipment.server.datamodels.record.EquipmentRecordDO;
import dmles.equipment.server.datamodels.record.LocationInventoryDO;
import dmles.equipment.server.datamodels.record.MaintCostDO;
import dmles.equipment.server.datamodels.record.MaintenanceDO;
import dmles.equipment.server.datamodels.record.MaintenanceTypeDO;
import dmles.equipment.server.datamodels.record.NotesDO;
import java.util.ArrayList;
import java.util.List;
import org.junit.Before;
import org.junit.Test;

import mil.jmlfdc.common.utils.ObjectMapper;

public class EquipmentRequestMapTest {
    
    private final ObjectMapper mapper = new ObjectMapper();

    @Test
    public void testMap() {
        EquipmentRecordDO erdo = buildEquipmentRecord();
        
        EquipmentRecord er = mapper.getObject(EquipmentRecord.class, erdo);
        
        assertNotNull(er);
    }

    private EquipmentRecordDO buildEquipmentRecord() {
        EquipmentRecordDO erdo = new EquipmentRecordDO(
                getApprovals(), 
                getComponents(),
                getLocationInventory(), 
                getMaintCost(), 
                getMaint(),
                getMaintType(),
                getNotes());
        
        erdo.setAcqCapitalEquip("ac");
        erdo.setAcqCommodClsTx("acct");
        erdo.setAcqFunctionId("afi");
        erdo.setAcqFundCd("afc");
        erdo.setAcqSpecialtyCode("asc");
        erdo.setAssemblageCount(Integer.MIN_VALUE);
        erdo.setAssemblyMtfSer(Integer.BYTES);
        erdo.setAssemblyOrgID("as");
        erdo.setAssemblyOrgNM("on");
        erdo.setAssetTypeCd("ty");
        erdo.setAssmDescrDetail("ad");
        erdo.setAssmInstDescr("ai");
        erdo.setAssmInstNum(Integer.MIN_VALUE);
        erdo.setAssmNumDetail("and");
        erdo.setCfoAsstClsTyCd("cac");
        
        
        return erdo;
    }
    
    private List<NotesDO> getNotes() {
        List<NotesDO> notes = new ArrayList<>();
        NotesDO note = new NotesDO();
        
        note.setMeId(Integer.SIZE);
        note.setMeNoteAuthrNm("mna");
        note.setMeNotesDate("dt");
        note.setMeNotesText("nt");
        note.setMeNotesTypeCD("ty");
        
        notes.add(note);
        return notes;
    }
    private List<MaintenanceTypeDO> getMaintType() {
        List<MaintenanceTypeDO> maintenanceType = new ArrayList<>();
        MaintenanceTypeDO mtd = new MaintenanceTypeDO();
        
        mtd.setME_ID(Integer.SIZE);
        mtd.setMdDueDt("dd");
        mtd.setMdLastSvcDt("mdl");
        mtd.setMiInuseMonthQty(Integer.MIN_VALUE);
        mtd.setMiMobltyMnthQty(Integer.BYTES);
        mtd.setMiStoredMnthQty(Integer.MIN_VALUE);
        mtd.setMiTypeCode(Integer.MIN_VALUE);
        mtd.setMiTypeDescText("det");
        mtd.setMpId(Integer.SIZE);
        mtd.setOperationalStatus("opstat");
        
        maintenanceType.add(mtd);
        return maintenanceType;
    }
    
    private List<MaintenanceDO> getMaint() {
        List<MaintenanceDO> maintenance = new ArrayList<>();
        MaintenanceDO mdo = new MaintenanceDO();
        
        mdo.setContractorNm("cn");
        mdo.setDeviceCd("dc");
        mdo.setEiTmdeInd("eti");
        mdo.setErtReadinessCdAndText("ertr");
        mdo.setMaSerial(Integer.MAX_VALUE);
        mdo.setMaintActivityOrgNm("oname");
        mdo.setMaintAssmntTyTx("mattt");
        mdo.setMeEcnId("ecn");
        mdo.setMeId(Integer.SIZE);
        mdo.setMel(Float.MAX_VALUE);
        mdo.setMpId(Integer.SIZE);
        mdo.setMrlc(Float.MIN_VALUE);
        mdo.setOperationalStatus("os");
        mdo.setOperationalStatusTx("ost");
        mdo.setOtherGovtMaintSrc("ogmc");
        mdo.setRltDescTx("dt");
        mdo.setSchedTeamOrgNm("ston");
        mdo.setUnschedTeamOrgNm("uston");
        mdo.setWorkOrderCount(Integer.MIN_VALUE);
        
        maintenance.add(mdo);
        return maintenance;
    }
    private List<MaintCostDO> getMaintCost() {
        List<MaintCostDO> maintCost = new ArrayList<>();
        MaintCostDO mc = new MaintCostDO();
        
        mc.setMcCPartCostAmt(1f);
        mc.setMcCSLabCstAmt(1f);
        mc.setMcCSTimeQty(1);
        mc.setMcCULabCstAmt(1f);
        mc.setMcCUTimeQty(Integer.SIZE);
        mc.setMcDownTime(Integer.MIN_VALUE);
        mc.setMcFiscalYearTm("fsyt");
        mc.setMcOPartCostAmt(Float.MIN_NORMAL);
        mc.setMcOSLabCstAmt(Float.MAX_VALUE);
        mc.setMcOSTimeQty(Float.MAX_VALUE);
        mc.setMcOULabCstAmt(Float.MAX_VALUE);
        mc.setMcOUTimeQty(Float.MAX_VALUE);
        mc.setMcUnschdWoQty(Integer.MIN_VALUE);
        
        maintCost.add(mc);
        return maintCost;
    }
    private List<LocationInventoryDO> getLocationInventory() {
        List<LocationInventoryDO> locationInventory = new ArrayList<>();
        LocationInventoryDO lido = new LocationInventoryDO();
        
        lido.setBuilding("building");
        lido.setEqpmtInvMthdTx("einvmthdtx");
        lido.setEqptInvReasonTx("eqinvtreadontx");
        lido.setInacctSerial("inacctserail");
        lido.setLocID("locid");
        lido.setOnlnEquipDayQty("onineqdayqt");
        lido.setOnlnEquipLoanDt("oninequiploandt");
        lido.setPltPermntLocTx("permloc");
        lido.setRoom("room");
        lido.setRoomFloorNum("floornum");
        lido.setSubLocID("sublocid");
        
        locationInventory.add(lido);
        return locationInventory;
    }
    private List<ComponentsDO> getComponents() {
        List<ComponentsDO> components = new ArrayList<>();
        ComponentsDO cdo = new ComponentsDO();
        cdo.setcDeviceText("devtxt");
        cdo.setcItemID("citemid");
        cdo.setcMEItemSerial(1);
        cdo.setcManuOrgSerial(2);
        cdo.setcManufMdlComnID("manufmdlcommid");
        cdo.setcManufMdlSerID(3);
        cdo.setcMeEcnID("meecnid");
        cdo.setcMeID(4);
        cdo.setcMeManufModelID("cmemanufmodelid");
        cdo.setcOrgName("orgname");
        cdo.setcTotalAcqCost(5);
        components.add(cdo);
        return components;
    }
    private List<ApprovalDO> getApprovals() {
        List<ApprovalDO> approvals = new ArrayList<>();
        ApprovalDO apdo = new ApprovalDO();
        apdo.setCfoAsstClsTyTx("cfoasstclstytx");
        apdo.setDuidTypeDesc("duidtypedesc");
        apdo.setDuiiStatusDesc("duiistatusdesc");
        apdo.setEquipBalanceRefTx("ebalreft");
        apdo.setFirstName("firstname");
        apdo.setLastName("lastname");
        apdo.setMtfSerial(1);
        apdo.setRankGrade("rgrade");
        apdo.setSos("sos");
        apdo.setSpecialty("specialty");
        apdo.setTransReasTypeTx("transreastypetx");
        approvals.add(apdo);
        return approvals;
    }
    
}
