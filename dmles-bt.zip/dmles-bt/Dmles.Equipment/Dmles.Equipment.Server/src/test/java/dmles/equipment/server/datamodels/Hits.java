package dmles.equipment.server.datamodels;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Hits {
    
    public int total;
    public double max_score;
    //public Object[] hits;
    
}
