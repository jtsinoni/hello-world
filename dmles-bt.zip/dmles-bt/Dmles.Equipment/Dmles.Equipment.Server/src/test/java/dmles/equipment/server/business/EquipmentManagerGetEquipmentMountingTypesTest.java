package dmles.equipment.server.business;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dmles.equipment.core.datamodels.request.EquipmentMountingType;
import dmles.equipment.server.datamodels.request.EquipmentMountingTypeDO;
import org.junit.Test;

import java.util.ArrayList;

import java.util.List;

public class EquipmentManagerGetEquipmentMountingTypesTest extends EquipmentManagerBaseTest {
    
    @Test
    public void test1() {
        List<EquipmentMountingTypeDO> doList = new ArrayList<>();
        
        when(equipmentMountingTypeDao.findAll()).thenReturn(doList);
        
        emm.getEquipmentMountingTypes();
        
        verify(equipmentMountingTypeDao).findAll();
        verify(objectMapper).getList(EquipmentMountingType[].class, doList);
    }

}