package dmles.equipment.server.business;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dmles.equipment.core.datamodels.request.workflow.process.WorkflowLevelStatus;
import dmles.equipment.server.datamodels.request.workflow.process.WorkflowHistoryDO;
import dmles.equipment.server.datamodels.request.workflow.process.WorkflowLevelProcessingDO;
import org.junit.Test;

public class WorkflowLogicGotoPreviousLevelTest extends WorkflowLogicBaseTest {

    @Test
    public void testNullPrevLevel() {
        when(request.getWfProcessing()).thenReturn(wfProcessing);
        when(wfProcessing.getCurrentLevel()).thenReturn(wfLevelProcessing);
        when(wfProcessing.getPreviousLevel()).thenReturn(null);
        
        wfLogic.goToPreviousLevel(request);

        verify(request).getWfProcessing();
        verify(wfProcessing).getCurrentLevel();
        verify(wfProcessing).getPreviousLevel();

    }

    @Test
    public void testValidPrevLevel() {
        
        WorkflowLevelProcessingDO prevLevel = mock(WorkflowLevelProcessingDO.class);
        
        when(request.getWfProcessing()).thenReturn(wfProcessing);
        when(wfProcessing.getCurrentLevel()).thenReturn(wfLevelProcessing);
        when(wfProcessing.getPreviousLevel()).thenReturn(prevLevel);
        Integer levelId = 2;
        when(prevLevel.getLevelId()).thenReturn(levelId);
        String roleOwner = "roleOwner";
        when(wfDefinition.getRoleOwner(levelId)).thenReturn(roleOwner);

        wfLogic.goToPreviousLevel(request);

        verify(request).getWfProcessing();
        verify(wfProcessing).getCurrentLevel();
        verify(wfProcessing).getPreviousLevel();
        verify(wfLevelProcessing).updateStatus(WorkflowLevelStatus.REWORK.toString(), "Tester");
        verify(prevLevel).getLevelId();
        verify(wfDefinition).getRoleOwner(levelId);
        verify(wfProcessing).setCurrentOwnerRole(roleOwner);
        verify(wfProcessing).setCurrentLevelId(levelId);
        verify(prevLevel).updateStatus(WorkflowLevelStatus.ACTIVE.toString(), WorkflowHistoryDO.SYSTEM);
    }

}
