package dmles.equipment.server.datamodels;


public class ElasticResult {
    
    public int took;
    public boolean timed_out;
    public Hits hits;
    public Shards _shards;
}
