package dmles.equipment.server.business;

import dmles.equipment.core.datamodels.request.workflow.process.LevelCriteriaNeeded;
import dmles.equipment.server.datamodels.request.EquipmentRequestDO;
import dmles.equipment.server.datamodels.request.RequestInformationDO;
import dmles.equipment.server.datamodels.request.RequestedEquipmentDO;
import dmles.equipment.server.datamodels.request.workflow.definition.CriteriaDeviceDO;
import dmles.equipment.server.datamodels.request.workflow.definition.LevelCriteriaDO;
import dmles.equipment.server.datamodels.request.workflow.definition.WorkflowLevelDefinitionDO;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.*;

public class DeviceEvaluatorTest {

    @Mock
    private EquipmentRequestDO erDo;
    @Mock
    private WorkflowLevelDefinitionDO wldo;
    @Mock
    private LevelCriteriaDO lcdo;
    @Mock
    private RequestInformationDO requestInfo;
    @Mock
    private RequestedEquipmentDO reqEquip;

    private DeviceCriteriaNeededEvaluator eval;
    private LevelCriteriaNeeded lcn;
    private List<CriteriaDeviceDO> devices;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        eval = new DeviceCriteriaNeededEvaluator();
        lcn = new LevelCriteriaNeeded();
        devices = new ArrayList<>();
    }

    @Test
    public void testEvalAmount() {
        Float f = 1f;
        Float f2 = 2f;
        when(erDo.getTotalRequisitionCost()).thenReturn(f);
        when(wldo.getLevelCriteria()).thenReturn(lcdo);
        when(lcdo.getDeviceCostThreshold()).thenReturn(f2);

        LevelCriteriaNeeded val = eval.evaluateCriteria(lcn, erDo, wldo);


        assertFalse(val.deviceCriteriaMet);

        verify(erDo).getTotalRequisitionCost();
        verify(wldo).getLevelCriteria();
        verify(lcdo).getDeviceCostThreshold();
    }

    @Test
    public void testEvalNullDevices() {
        Float f = 1f;
        when(erDo.getTotalRequisitionCost()).thenReturn(f);
        when(wldo.getLevelCriteria()).thenReturn(lcdo);
        when(lcdo.getDeviceCostThreshold()).thenReturn(f);
        when(lcdo.getDevices()).thenReturn(null);

        LevelCriteriaNeeded val = eval.evaluateCriteria(lcn, erDo, wldo);


        assertFalse(val.deviceCriteriaMet);

        verify(erDo).getTotalRequisitionCost();
        verify(wldo).getLevelCriteria();
        verify(lcdo).getDeviceCostThreshold();
        verify(lcdo).getDevices();
    }

    @Test
    public void testEvalNullRequestInfo() {
        Float f = 1f;
        when(erDo.getTotalRequisitionCost()).thenReturn(f);
        when(wldo.getLevelCriteria()).thenReturn(lcdo);
        when(lcdo.getDeviceCostThreshold()).thenReturn(f);
        when(lcdo.getDevices()).thenReturn(devices);

        LevelCriteriaNeeded val = eval.evaluateCriteria(lcn, erDo, wldo);


        assertFalse(val.deviceCriteriaMet);

        verify(erDo).getTotalRequisitionCost();
        verify(wldo).getLevelCriteria();
        verify(lcdo).getDeviceCostThreshold();
        verify(lcdo).getDevices();
    }

    @Test
    public void testEvalNullEquipment() {
        Float f = 1f;
        when(erDo.getTotalRequisitionCost()).thenReturn(f);
        when(wldo.getLevelCriteria()).thenReturn(lcdo);
        when(lcdo.getDeviceCostThreshold()).thenReturn(f);
        when(lcdo.getDevices()).thenReturn(devices);
        when(erDo.getRequestInformation()).thenReturn(requestInfo);

        LevelCriteriaNeeded val = eval.evaluateCriteria(lcn, erDo, wldo);


        assertFalse(val.deviceCriteriaMet);

        verify(erDo).getTotalRequisitionCost();
        verify(wldo).getLevelCriteria();
        verify(lcdo).getDeviceCostThreshold();
        verify(lcdo).getDevices();
        verify(erDo).getRequestInformation();
    }

    @Test
    public void testEvalNullDeviceCode() {
        Float f = 1f;
        when(erDo.getTotalRequisitionCost()).thenReturn(f);
        when(wldo.getLevelCriteria()).thenReturn(lcdo);
        when(lcdo.getDeviceCostThreshold()).thenReturn(f);
        when(lcdo.getDevices()).thenReturn(devices);
        when(erDo.getRequestInformation()).thenReturn(requestInfo);
        when(requestInfo.getEquipment()).thenReturn(reqEquip);
        when(reqEquip.getDeviceCode()).thenReturn(null);

        LevelCriteriaNeeded val = eval.evaluateCriteria(lcn, erDo, wldo);


        assertFalse(val.deviceCriteriaMet);

        verify(erDo).getTotalRequisitionCost();
        verify(wldo).getLevelCriteria();
        verify(lcdo).getDeviceCostThreshold();
        verify(lcdo).getDevices();
        verify(erDo).getRequestInformation();
        verify(requestInfo, times(2)).getEquipment();
        verify(reqEquip).getDeviceCode();
    }

    @Test
    public void testEvalLoopNone() {
        String deviceCode = "deviceCode";
        Float f = 1f;
        when(erDo.getTotalRequisitionCost()).thenReturn(f);
        when(wldo.getLevelCriteria()).thenReturn(lcdo);
        when(lcdo.getDeviceCostThreshold()).thenReturn(f);
        when(lcdo.getDevices()).thenReturn(devices);
        when(erDo.getRequestInformation()).thenReturn(requestInfo);
        when(requestInfo.getEquipment()).thenReturn(reqEquip);
        when(reqEquip.getDeviceCode()).thenReturn(deviceCode);

        LevelCriteriaNeeded val = eval.evaluateCriteria(lcn, erDo, wldo);


        assertFalse(val.deviceCriteriaMet);

        verify(erDo).getTotalRequisitionCost();
        verify(wldo).getLevelCriteria();
        verify(lcdo).getDeviceCostThreshold();
        verify(lcdo).getDevices();
        verify(erDo).getRequestInformation();
        verify(requestInfo, times(2)).getEquipment();
        verify(reqEquip).getDeviceCode();
    }

    @Test
    public void testEvalLoopNomatch() {
        String devCode = "devcode";
        CriteriaDeviceDO crit = mock(CriteriaDeviceDO.class);
        crit.setDeviceCode(devCode);
        devices.add(crit);
        Float f = 1f;
        when(erDo.getTotalRequisitionCost()).thenReturn(f);
        when(wldo.getLevelCriteria()).thenReturn(lcdo);
        when(lcdo.getDeviceCostThreshold()).thenReturn(f);
        when(lcdo.getDevices()).thenReturn(devices);
        when(erDo.getRequestInformation()).thenReturn(requestInfo);
        when(requestInfo.getEquipment()).thenReturn(reqEquip);
        when(reqEquip.getDeviceCode()).thenReturn(devCode);
        when(crit.getDeviceCode()).thenReturn("nomatch");

        LevelCriteriaNeeded val = eval.evaluateCriteria(lcn, erDo, wldo);


        assertFalse(val.deviceCriteriaMet);

        verify(erDo).getTotalRequisitionCost();
        verify(wldo).getLevelCriteria();
        verify(lcdo).getDeviceCostThreshold();
        verify(lcdo).getDevices();
        verify(erDo).getRequestInformation();
        verify(requestInfo, times(2)).getEquipment();
        verify(reqEquip).getDeviceCode();
        verify(crit).getDeviceCode();
    }

    @Test
    public void testEvalLoopMatch() {
        String devCode = "devcode";
        CriteriaDeviceDO crit = mock(CriteriaDeviceDO.class);
        crit.setDeviceCode(devCode);
        devices.add(crit);
        Float f = 1f;
        when(erDo.getTotalRequisitionCost()).thenReturn(f);
        when(wldo.getLevelCriteria()).thenReturn(lcdo);
        when(lcdo.getDeviceCostThreshold()).thenReturn(f);
        when(lcdo.getDevices()).thenReturn(devices);
        when(erDo.getRequestInformation()).thenReturn(requestInfo);
        when(requestInfo.getEquipment()).thenReturn(reqEquip);
        when(reqEquip.getDeviceCode()).thenReturn(devCode);
        when(crit.getDeviceCode()).thenReturn(devCode);

        LevelCriteriaNeeded val = eval.evaluateCriteria(lcn, erDo, wldo);


        assertTrue(val.deviceCriteriaMet);

        verify(erDo).getTotalRequisitionCost();
        verify(wldo).getLevelCriteria();
        verify(lcdo).getDeviceCostThreshold();
        verify(lcdo).getDevices();
        verify(erDo).getRequestInformation();
        verify(requestInfo, times(2)).getEquipment();
        verify(reqEquip).getDeviceCode();
        verify(crit).getDeviceCode();
    }

}
