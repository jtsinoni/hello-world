package dmles.equipment.server.business;

import static org.mockito.Matchers.anyMap;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Test;

public class ElasticSearchManagerGetCatalogSearchResultsTest 
    extends ElasticSearchManagerBaseTest {

    @Test
    public void testNull() {
        String searchValue = null;
        String dodaac = null;
        String result = "result";
        
        when(esDao.getSearchResults(
                anyMap(), eq(ElasticSearchManager.CATALOG_SEARCH_TEMP)))
                .thenReturn(result);

        esm.getCatalogSearchResults(searchValue, dodaac);
        
        verify(esDao).getSearchResults(anyMap(), eq(ElasticSearchManager.CATALOG_SEARCH_TEMP));
    }

    @Test
    public void testEmptyDodaac() {
        String searchValue = "";
        String dodaac = "";
        String result = "result";
        
        when(esDao.getSearchResults(
                anyMap(), eq(ElasticSearchManager.CATALOG_SEARCH_TEMP)))
                .thenReturn(result);

        esm.getCatalogSearchResults(searchValue, dodaac);
        
        verify(esDao).getSearchResults(anyMap(), eq(ElasticSearchManager.CATALOG_SEARCH_TEMP));
    }

    @Test
    public void testOkDodaac() {
        String searchValue = "sv";
        String dodaac = "dodaac";
        String result = "result";
        
        when(esDao.getSearchResults(
                anyMap(), eq(ElasticSearchManager.CATALOG_SEARCH_TEMP)))
                .thenReturn(result);

        esm.getCatalogSearchResults(searchValue, dodaac);
        
        verify(esDao).getSearchResults(anyMap(), eq(ElasticSearchManager.CATALOG_SEARCH_TEMP));
    }

}
