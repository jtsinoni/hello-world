package dmles.equipment.server.business;

import static org.mockito.Matchers.anyMap;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import static dmles.equipment.server.business.ElasticSearchManager.JMAR_SEARCH_TEMP;

import org.junit.Test;

public class ElasticSearchManagerGetJmarSearchResultsTest 
    extends ElasticSearchManagerBaseTest {

    @Test
    public void testNull() {
        String searchValue = null;
        String result = "result";
        
        when(esDao.getSearchResults(
                anyMap(), eq(ElasticSearchManager.JMAR_SEARCH_TEMP)))
                .thenReturn(result);

        esm.getJmarSearchResults(searchValue);
        
        verify(esDao).getSearchResults(anyMap(), eq(ElasticSearchManager.JMAR_SEARCH_TEMP));
    }

    @Test
    public void testEmptyDodaac() {
        String searchValue = "";
        String result = "result";
        
        when(esDao.getSearchResults(
                anyMap(), eq(ElasticSearchManager.JMAR_SEARCH_TEMP)))
                .thenReturn(result);

        esm.getJmarSearchResults(searchValue);
        
        verify(esDao).getSearchResults(anyMap(), eq(ElasticSearchManager.JMAR_SEARCH_TEMP));
    }

    @Test
    public void testOkDodaac() {
        String searchValue = "sv";
        String result = "result";
        
        when(esDao.getSearchResults(
                anyMap(), eq(ElasticSearchManager.JMAR_SEARCH_TEMP)))
                .thenReturn(result);

        esm.getJmarSearchResults(searchValue);
        
        verify(esDao).getSearchResults(anyMap(), eq(ElasticSearchManager.JMAR_SEARCH_TEMP));
    }

}
