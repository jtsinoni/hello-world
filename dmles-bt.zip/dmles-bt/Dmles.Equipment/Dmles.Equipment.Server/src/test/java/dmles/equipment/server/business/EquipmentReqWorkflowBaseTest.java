package dmles.equipment.server.business;

import dmles.equipment.core.datamodels.request.EquipmentRequest;
import dmles.equipment.server.dao.EquipmentRequestDao;
import dmles.equipment.server.dao.WorkflowDefinitionDao;
import dmles.equipment.server.dao.WorkflowProcessingDao;
import dmles.equipment.server.datamodels.CommentDO;
import dmles.equipment.server.datamodels.request.EquipmentRequestDO;
import dmles.equipment.server.datamodels.request.validation.RequestValidator;
import dmles.equipment.server.datamodels.request.workflow.definition.WorkflowDefinitionDO;
import dmles.equipment.server.datamodels.request.workflow.process.WeighInDO;
import dmles.equipment.server.datamodels.request.workflow.process.WorkflowCommentDO;
import dmles.equipment.server.datamodels.request.workflow.process.WorkflowLevelProcessingDO;
import dmles.equipment.server.datamodels.request.workflow.process.WorkflowProcessingDO;
import dmles.oauth.core.datamodel.CurrentUserBT;
import mil.jmlfdc.common.exception.ObjectNotFoundException;
import mil.jmlfdc.common.utils.ObjectMapper;

import org.junit.Before;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;

public class EquipmentReqWorkflowBaseTest {

    @Mock Logger logger;
    @Mock CommentDO commentObj;
    @Mock CurrentUserBT user;
    @Mock ObjectMapper objectMapper;
    @Mock EquipmentRequest request;
    @Mock EquipmentRequestDao equipReqDao;
    @Mock WorkflowProcessingDao wfProcessingDao;
    @Mock WorkflowDefinitionDao wfDefinitionDao;
    @Mock WorkflowLogicFactory wfFactory;
    @Mock WorkflowCommentDO commentDO;
    @Mock EquipmentRequestManager equipmentManager;
    @Mock EquipmentRequestDO requestDO;
    @Mock WorkflowDefinitionDO wfDefinition;
    @Mock WorkflowLevelProcessingDO currentLevelProcessing;
    @Mock WorkflowProcessingDO wfProcessing;
    @Mock EquipmentRequestPersistenceHelper persistHelper;
    @Mock WeighInDO weighIn;
    @Mock RequestValidator requestValidator;
    @Mock WorkflowHistoryManager history;

    @InjectMocks
    WorkflowProcessingManager erwm;

    @InjectMocks
    WorkflowDefinitionManager wfdm;    
    
    String comment = "comment";
    String serviceCode = "DA";
    String pkiDn = "all";
    String firstName = "TestFirstName";
    String lastName = "TestLastName";
    String userId = "userId";
    String requestId = "requestId";
    String levelName = "levelName";
    String weighInRole = "weighInRole";
    String weighInDisplayName = "weighInDisplayName";
    WorkflowLogic wfLogic;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        wfLogic = new WorkflowLogic(requestDO, wfDefinition, user, wfProcessingDao);
    }

    protected void addRequestWhens() {
        when(requestDO.getId()).thenReturn(requestId);
        when(requestDO.getWfProcessing()).thenReturn(wfProcessing);
        when(objectMapper.getObject(EquipmentRequestDO.class, request)).thenReturn(requestDO);
    }

    protected void addObjectMapperToClientWhens() {
        when(objectMapper.getObject(EquipmentRequestDO.class, request)).thenReturn(requestDO);
    }

    protected void addWorkflowWhens() throws ObjectNotFoundException {
        when(wfFactory.rebuildLogic(requestId)).thenReturn(wfLogic);
        when(requestDO.getWfProcessing()).thenReturn(wfProcessing);
        when(persistHelper.saveRequest(requestDO, wfLogic)).thenReturn(requestDO);
        when(objectMapper.getObject(EquipmentRequest.class, requestDO)).thenReturn(request);   
    }
    
    protected void addWorkflowVerifies() throws ObjectNotFoundException {
        verify(wfFactory).rebuildLogic(requestId);
        verify(persistHelper).saveRequest(requestDO, wfLogic);
        verify(objectMapper).getObject(EquipmentRequest.class, requestDO);
    }    

    protected void addStandardWhens() throws ObjectNotFoundException {
        addDefaultWhens();
        addWfactString();
    }

    protected void addStandardWhens(EquipmentRequestDO requestDo) throws ObjectNotFoundException {
        addDefaultWhens();
        addWfactObjectWhens(requestDo);
    }

    protected void addDefaultWhens() {
        //when(wfLogic.getRequest()).thenReturn(requestDO);
        when(requestDO.getWfProcessing()).thenReturn(wfProcessing);

        //when(wfLogic.getCurrentLevelName()).thenReturn(levelName);
    }

    protected void addPersistenceWhens() throws ObjectNotFoundException {
        when(persistHelper.saveRequest(requestDO, wfLogic)).thenReturn(requestDO);
    }

    protected void addRequestProcessWhens() {
        when(requestDO.getWfProcessing()).thenReturn(wfProcessing);
    }

    protected void addWfactString() throws ObjectNotFoundException {
        when(wfFactory.buildLogic(requestId)).thenReturn(wfLogic);
    }

    protected void addWfactRebuildString() throws ObjectNotFoundException {
        when(wfFactory.rebuildLogic(requestId)).thenReturn(wfLogic);
    }

    protected void addWfactObjectWhens(EquipmentRequestDO requestDo) throws ObjectNotFoundException {
        when(wfFactory.buildLogic(requestDo)).thenReturn(wfLogic);
    }
 
    protected void addRequestVerifies() throws ObjectNotFoundException {
        verify(requestDO).getId();
        verify(objectMapper).getObject(EquipmentRequestDO.class, request);
    }

    protected void addStandardVerifies(String action, String section) throws ObjectNotFoundException {
        addStandardVerifies(action, section, 4);
    }

    protected void addStandardVerifies(String action, String section, int getRequestTimesCalled) throws ObjectNotFoundException {
        verify(wfFactory).buildLogic(requestId);
        verify(wfLogic, times(getRequestTimesCalled)).getRequest();
        verify(requestDO).getWfProcessing();
        verify(wfProcessingDao).update(wfProcessing);
        verify(persistHelper).saveRequest(requestDO, wfLogic);
        verify(equipmentManager).getEquipmentRequest(requestId);
    }

    protected void addSubmitVerifies() throws ObjectNotFoundException {
        verify(requestDO).getId();
    }

}
