package dmles.equipment.server.business;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Test;

import java.util.Date;

public class WorkflowLogicSaveTest extends WorkflowLogicBaseTest {

    @Test
    public void testSave() {
        when(request.getWfProcessing()).thenReturn(wfProcessing);

        wfLogic.saveWfProcessing();

        verify(request).getWfProcessing();
        verify(user).getFullName();
        verify(wfProcessing).setUpdatedBy(null);
        verify(wfProcessing).setUpdatedDate(any(Date.class));
    }

}
