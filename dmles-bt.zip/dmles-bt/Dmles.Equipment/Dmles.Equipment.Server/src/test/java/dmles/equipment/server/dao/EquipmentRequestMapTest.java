package dmles.equipment.server.dao;

import static org.junit.Assert.*;

import dmles.equipment.core.datamodels.request.EquipmentRequest;
import dmles.equipment.core.datamodels.request.workflow.process.WorkflowProcessing;
import dmles.equipment.server.datamodels.request.EquipmentRequestDO;
import mil.jmlfdc.common.utils.ObjectMapper;
import org.bson.types.ObjectId;
import org.junit.Test;

public class EquipmentRequestMapTest {
    
    private final ObjectMapper mapper = new ObjectMapper();
    private final String id1 = new ObjectId().toString();
    private final String id2 = new ObjectId().toString();
    
    @Test
    public void testSave() {
        
        EquipmentRequest er = new EquipmentRequest();
        er.id = id1;
        
        WorkflowProcessing wfp = new WorkflowProcessing();
        wfp.currentLevelId = 1;
        wfp.id = id2;
        er.wfProcessing = wfp;
        
        EquipmentRequestDO erdo = mapper.getObject(EquipmentRequestDO.class, er);
        
        assertNotNull(erdo);
        assertEquals(id1, erdo.getId());
        assertNotNull(erdo.getWfProcessing());
        assertEquals(id2, erdo.getWfProcessing().getId());
    }
    
}
