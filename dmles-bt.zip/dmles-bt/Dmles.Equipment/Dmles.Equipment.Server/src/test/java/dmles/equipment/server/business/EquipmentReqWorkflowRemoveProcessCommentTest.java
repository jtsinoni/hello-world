package dmles.equipment.server.business;

import dmles.equipment.server.datamodels.request.workflow.process.WorkflowCommentDO;
import java.util.ArrayList;
import java.util.List;
import mil.jmlfdc.common.exception.ObjectNotFoundException;
import org.junit.Test;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class EquipmentReqWorkflowRemoveProcessCommentTest extends EquipmentReqWorkflowBaseTest {
    
    @Test
    public void test1() throws ObjectNotFoundException {
        List<WorkflowCommentDO> comments = mock(ArrayList.class);
        String commentIdStr = "1234";

        addWorkflowWhens();
        when(wfProcessing.getCurrentLevel()).thenReturn(currentLevelProcessing);
        when(requestDO.getWfProcessing().getComments()).thenReturn(comments);
        
        erwm.removeProcessComment(requestId, commentIdStr);
        
        verify(requestDO, times(2)).getWfProcessing();
        verify(wfProcessing, times(2)).getComments();
        verify(wfProcessing, times(0)).getNextLevel();
        verify(wfProcessing, times(0)).getPreviousLevel();
        verify(wfProcessing, times(0)).isEndOfWorkflow();
        addWorkflowVerifies();        
    }
}
