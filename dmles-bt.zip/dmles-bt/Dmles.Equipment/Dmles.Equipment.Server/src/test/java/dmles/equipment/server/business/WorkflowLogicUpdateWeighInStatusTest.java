package dmles.equipment.server.business;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dmles.equipment.core.datamodels.request.workflow.process.WeighInStatus;
import dmles.equipment.server.datamodels.request.workflow.process.WeighInDO;
import dmles.equipment.server.datamodels.request.workflow.process.WorkflowLevelProcessingDO;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class WorkflowLogicUpdateWeighInStatusTest extends WorkflowLogicBaseTest {

    private final String weighInRoleId = "weighInRoleId";
    private final String status = "status";
    private List<WeighInDO> weighIns;
    private WeighInDO wi1;
    private WeighInDO wi2;

    @Override
    @Before
    public void setup() {
        super.setup();
        weighIns = new ArrayList<>();
        wi1 = mock(WeighInDO.class);
        wi2 = mock(WeighInDO.class);
        weighIns.add(wi2);
        weighIns.add(wi1);
        when(wfLevelProcessing.getWeighIns()).thenReturn(weighIns);
    }

    @Test
    public void testUpdateAll() {
        
        wfLogic.updateWeighInStatus(wfLevelProcessing, null, status);

        verify(wfLevelProcessing).getWeighIns();
        verify(wi1).setWeighInStatus(status);
        verify(wi2).setWeighInStatus(status);

    }

    @Test
    public void testUpdateSome() {

        when(wi1.getRoleId()).thenReturn(weighInRoleId);

        wfLogic.updateWeighInStatus(wfLevelProcessing, weighInRoleId, status);

        verify(wfLevelProcessing).getWeighIns();
        verify(wi1).getRoleId();
        verify(wi1).setWeighInStatus(status);
    }

    @Test
    public void testUpdateRework() {

        when(wi1.getRoleId()).thenReturn(weighInRoleId);

        wfLogic.updateWeighInStatus(wfLevelProcessing, weighInRoleId, WeighInStatus.REWORK.toString());

        verify(wfLevelProcessing).getWeighIns();
        verify(wi1).getRoleId();
        verify(wi1).setWeighInStatus(WeighInStatus.REWORK.toString());
        verify(wi1).setWeighInResult(null);

    }

    @Test
    public void test() {

        WorkflowLevelProcessingDO currLevelIn = mock(WorkflowLevelProcessingDO.class);
        WorkflowLevelProcessingDO currLevelDb = mock(WorkflowLevelProcessingDO.class);
        List<WeighInDO> wIns = new ArrayList<>();
        WeighInDO wIn1 = mock(WeighInDO.class);
        WeighInDO wIn2 = mock(WeighInDO.class);
        wIns.add(wIn1);
        wIns.add(wIn2);
        List<WeighInDO> wDbs = new ArrayList<>();
        WeighInDO wDb2 = mock(WeighInDO.class);
        wDbs.add(wIn1);
        wDbs.add(wDb2);
        String roleId = "roleId";
        when(wDb2.getRoleId()).thenReturn(roleId);
        when(currLevelIn.getWeighIns()).thenReturn(wIns);
        when(currLevelDb.getWeighIns()).thenReturn(wDbs);

        wfLogic.updateWeighInStatus(currLevelIn, currLevelDb);

        verify(currLevelIn).getWeighIns();
        verify(currLevelDb).getWeighIns();
        verify(wDb2).setSelectedUserId(null);
        verify(wDb2).setRoleId(null);
        verify(wDb2).setWeighInDisplayName(null);
        verify(wDb2).setWeighInStatus(null);

        verify(wIn2).getSelectedUserId();
        verify(wIn2).getRoleId();
        verify(wIn2).getWeighInDisplayName();
        verify(wIn2).getWeighInStatus();
    }

}
