package dmles.equipment.server.business;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import mil.jmlfdc.common.exception.ObjectNotFoundException;
import org.junit.Test;

public class EquipmentReqWorkflowSubForReviewsTest extends EquipmentReqWorkflowBaseTest {
    
    @Test
    public void test1() throws ObjectNotFoundException {
        addWorkflowWhens();
        when(wfProcessing.getCurrentLevel()).thenReturn(currentLevelProcessing);
        when(wfProcessing.getNextLevel()).thenReturn(currentLevelProcessing);

        erwm.submitForReviews(requestId, reviewRole, reviewDisplayName);

        verify(requestDO, times(3)).getWfProcessing();
        verify(wfProcessing).getCurrentLevel();
        verify(wfProcessing, times(0)).getNextLevel();
        verify(wfProcessing, times(0)).getPreviousLevel();
        verify(wfProcessing, times(0)).isEndOfWorkflow();
        addWorkflowVerifies();        
    }
}
