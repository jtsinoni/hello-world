package dmles.equipment.server.utils;

import static org.junit.Assert.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dmles.equipment.server.datamodels.request.EquipmentRequestDO;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

public class RquestExtensionTest {

    @Mock
    private EquipmentRequestDO requestDo;
    private RequestExtension rex;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        rex = new RequestExtension(requestDo);
    }

    @Test
    public void getCost() {
        Float total = 1f;

        when(requestDo.getTotalPrice()).thenReturn(total);

        Double val = rex.getTotalCostAsDouble();

        assertNotNull(val);
        assertEquals(total, new Float(val));
        verify(requestDo).getTotalPrice();

    }

    @Test
    public void getCostNull() {

        when(requestDo.getTotalPrice()).thenReturn(null);

        Double val = rex.getTotalCostAsDouble();

        assertNull(val);
        verify(requestDo).getTotalPrice();

    }

    @Test
    public void costCriteria() {

        assertTrue(rex.meetsCostCriteria(2d, 1d));
        assertFalse(rex.meetsCostCriteria(1d, 2d));
        assertTrue(rex.meetsCostCriteria(1d, 1d));
    }
}
