
package dmles.equipment.server.business;

import dmles.equipment.server.dao.EquipmentRecordDao;
import mil.jmlfdc.common.datamodel.CurrentUserBT;
import mil.jmlfdc.common.utils.ObjectMapper;
import org.junit.Before;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;

public class EquipmentRecordManagerBaseTest {
    
    @Mock protected CurrentUserBT user;
    @Mock protected Logger logger;
    @Mock protected EquipmentRecordDao equipmentRecordDao;
    @Mock protected ObjectMapper objectMapper;
    
    @InjectMocks protected EquipmentRecordManager erm;
    
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

}