package dmles.equipment.server.business;

import dmles.equipment.core.datamodels.request.workflow.process.WorkflowProcessing;
import mil.jmlfdc.common.exception.ObjectNotFoundException;
import org.junit.Test;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class EquipmentReqWorkflowGetWorkflowProcessingTest extends EquipmentReqWorkflowBaseTest {

    @Test
    public void test1() throws ObjectNotFoundException {
        String processId = "processId";
        when(wfProcessingDao.findById(processId))
                .thenReturn(wfProcessing);
        
        erwm.getWorkflowProcessing(processId);
        
        verify(wfProcessingDao).findById(processId);
        verify(objectMapper).getObject(WorkflowProcessing.class, wfProcessing);
    }
}
