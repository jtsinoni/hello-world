package dmles.equipment.server;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.deltaspike.core.api.config.ConfigProperty;
import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.spec.WebArchive;
import org.jboss.shrinkwrap.resolver.api.maven.Maven;
import org.junit.Before;
import org.junit.runner.RunWith;

import java.io.File;
import javax.inject.Inject;

@RunWith(Arquillian.class)
public class EquipmentIntegrationBase {
    @Inject
    @ConfigProperty(name = "database")
    private String database;
    @Inject
    @ConfigProperty(name = "esHostName")
    private String esHostName;

    @Deployment
    public static WebArchive createDeployment() {

        File[] pomLibraryFiles = Maven.resolver()
                .loadPomFromFile("pom.xml")
                .importRuntimeDependencies().resolve()
                .withTransitivity().asFile();

        WebArchive warChive = ShrinkWrap.create(WebArchive.class)
                .addAsLibraries(pomLibraryFiles)
                .addPackages(true,
                        "dmles.equipment.server"
                );

        File[] resourceFiles = new File("src/test/resources").listFiles();
        if (!ArrayUtils.isEmpty(resourceFiles)) {
            for (File file : resourceFiles) {
                warChive.addAsResource(file);
            }
        }

        File[] manifestResourceFiles = new File("src/main/webapp/META-INF").listFiles();
        if (!ArrayUtils.isEmpty(manifestResourceFiles)) {
            for (File file : manifestResourceFiles) {
                warChive.addAsManifestResource(file);
            }
        }

        File[] webInfFiles = new File("src/main/webapp/WEB-INF").listFiles();
        if (!ArrayUtils.isEmpty(webInfFiles)) {
            for (File file : webInfFiles) {
                warChive.addAsWebInfResource(file);
            }
        }

        File[] webResourceFiles = new File("src/main/webapp").listFiles();
        if (!ArrayUtils.isEmpty(webResourceFiles)) {
            for (File file : webResourceFiles) {
                if (!file.isDirectory()) {
                    warChive.addAsWebResource(file);
                }
            }
        }

        return warChive;
    }
    
    @Before
    public void setup() {
        System.out.println("Using database " + database);
        System.out.println("Using elastic database " + esHostName);
    }
}
