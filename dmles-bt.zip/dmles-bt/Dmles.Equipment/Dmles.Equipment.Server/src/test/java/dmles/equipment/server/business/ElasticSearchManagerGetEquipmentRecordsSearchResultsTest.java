package dmles.equipment.server.business;

import static org.mockito.Matchers.anyMap;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import static dmles.equipment.server.business.ElasticSearchManager.EQUIP_REC_SEARCH_TEMP;

import mil.jmlfdc.common.datamodel.CurrentUserBT;
import mil.jmlfdc.common.datamodel.UserType;
import org.junit.Test;
import org.mockito.Mock;

public class ElasticSearchManagerGetEquipmentRecordsSearchResultsTest 
    extends ElasticSearchManagerBaseTest {
    @Mock CurrentUserBT currentUserBt;

    @Test
    public void testNull() {
        String searchValue = null;
        String dodaac = null;
        String result = "result";

        when(currentUserBt.getUserType()).thenReturn(UserType.GLOBAL);

        when(esDao.getSearchResults(
                anyMap(), eq(ElasticSearchManager.EQUIP_REC_SEARCH_TEMP)))
                .thenReturn(result);

        esm.getEquipmentRecordSearchResults(searchValue, dodaac);
        
        verify(esDao).getSearchResults(anyMap(), eq(ElasticSearchManager.EQUIP_REC_SEARCH_TEMP));
    }

    @Test
    public void testEmptyDodaac() {
        String searchValue = "";
        String dodaac = "";
        String result = "result";

        when(currentUserBt.getUserType()).thenReturn(UserType.GLOBAL);

        when(esDao.getSearchResults(
                anyMap(), eq(ElasticSearchManager.EQUIP_REC_SEARCH_TEMP)))
                .thenReturn(result);

        esm.getEquipmentRecordSearchResults(searchValue, dodaac);
        
        verify(esDao).getSearchResults(anyMap(), eq(ElasticSearchManager.EQUIP_REC_SEARCH_TEMP));
    }

    @Test
    public void testOkDodaac() {
        String searchValue = "sv";
        String dodaac = "dodaac";
        String result = "result";

        when(currentUserBt.getUserType()).thenReturn(UserType.GLOBAL);

        when(esDao.getSearchResults(
                anyMap(), eq(ElasticSearchManager.EQUIP_REC_SEARCH_TEMP)))
                .thenReturn(result);

        esm.getEquipmentRecordSearchResults(searchValue, dodaac);
        
        verify(esDao).getSearchResults(anyMap(), eq(ElasticSearchManager.EQUIP_REC_SEARCH_TEMP));
    }

}
