package dmles.equipment.server.business;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dmles.equipment.core.datamodels.request.Device;
import dmles.equipment.server.datamodels.request.DeviceDO;
import org.junit.Test;

import java.util.ArrayList;

import java.util.List;

public class EquipmentManagerGetDevicesTest extends EquipmentManagerBaseTest {
    
    @Test
    public void test1() {
        List<DeviceDO> doList = new ArrayList<>();
        
        when(deviceDao.findCodeAndText()).thenReturn(doList);
        
        emm.getDevices();
        
        verify(deviceDao).findCodeAndText();
        verify(objectMapper).getList(Device[].class, doList);
    }

}