package dmles.equipment.server.business;

import mil.jmlfdc.common.exception.ObjectNotFoundException;
import org.junit.Test;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class EquipmentReqWorkflowForceUpRequestTest extends EquipmentReqWorkflowBaseTest {
    
    @Test
    public void testIsNotComplete() throws ObjectNotFoundException {
        /*addWorkflowWhens();
        when(wfProcessing.getCurrentLevel()).thenReturn(currentLevelProcessing);
        when(wfProcessing.getNextLevel()).thenReturn(currentLevelProcessing);
        when(wfProcessing.isEndOfWorkflow()).thenReturn(false);
        
        erwm.forceUpRequest(requestId);
        
        verify(requestDO, times(4)).getWfProcessing();
        verify(wfProcessing).getCurrentLevel();
        verify(wfProcessing).getNextLevel();
        verify(wfProcessing, times(0)).getPreviousLevel(); 
        verify(wfProcessing).isEndOfWorkflow();
        addWorkflowVerifies(); */
    }
    
    @Test
    public void testIsComplete() throws ObjectNotFoundException {
        /*addWorkflowWhens();
        when(wfProcessing.getCurrentLevel()).thenReturn(currentLevelProcessing);
        when(wfProcessing.getNextLevel()).thenReturn(currentLevelProcessing);
        when(wfProcessing.isEndOfWorkflow()).thenReturn(true);
        
        erwm.forceUpRequest(requestId);
        
        verify(requestDO, times(4)).getWfProcessing();
        verify(wfProcessing).getCurrentLevel();
        verify(wfProcessing, times(0)).getNextLevel();
        verify(wfProcessing, times(0)).getPreviousLevel();        
        verify(wfProcessing).isEndOfWorkflow();
        addWorkflowVerifies(); */
    }    
}
