package dmles.equipment.server.business;

import dmles.equipment.core.datamodels.request.workflow.definition.WorkflowDefinition;
import dmles.equipment.server.datamodels.request.workflow.definition.WorkflowDefinitionDO;
import mil.jmlfdc.common.exception.ObjectNotFoundException;
import org.junit.Test;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class EquipmentReqWorkflowGetWorkflowDefinitionTest extends EquipmentReqWorkflowBaseTest {

    @Test
    public void test1() throws ObjectNotFoundException {
        String serviceName = "serviceName";
        WorkflowDefinitionDO workflowDefinitionDO = mock(WorkflowDefinitionDO.class);
        
        when(wfDefinitionDao.findByServiceName(serviceName))
                .thenReturn(workflowDefinitionDO);
        
        wfdm.getWorkflowDefinition(serviceName);
        
        verify(wfDefinitionDao).findByServiceName(serviceName);
        verify(objectMapper).getObject(WorkflowDefinition.class, workflowDefinitionDO);
    }
}
