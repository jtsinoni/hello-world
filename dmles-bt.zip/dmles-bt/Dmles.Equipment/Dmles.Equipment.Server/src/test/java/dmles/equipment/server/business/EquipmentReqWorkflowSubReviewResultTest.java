package dmles.equipment.server.business;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dmles.equipment.core.datamodels.request.EquipmentRequest;
import dmles.equipment.core.datamodels.request.workflow.process.ReviewResult;
import mil.jmlfdc.common.exception.ObjectNotFoundException;
import org.junit.Test;

public class EquipmentReqWorkflowSubReviewResultTest extends EquipmentReqWorkflowBaseTest {
    
    @Test
    public void test1() throws ObjectNotFoundException {
        String reviewResult = ReviewResult.RECOMMEND_APPROVE.toString();
        
        //addWorkflowWhens();
        WorkflowLogic wlogic = mock(WorkflowLogic.class);

        when(wfFactory.rebuildLogic(anyString())).thenReturn(wlogic);
        when(wlogic.getRequest()).thenReturn(requestDO);
        when(persistHelper.saveRequest(requestDO, wlogic)). thenReturn(requestDO);

        erwm.submitReviewResult(requestId,reviewResult, reviewDisplayName);

        verify(wfFactory).rebuildLogic(anyString());
        verify(wlogic).addReviewResult(reviewResult, reviewDisplayName);
        verify(wfFactory).rebuildLogic(requestId);
        verify(persistHelper).saveRequest(requestDO, wlogic);
        verify(objectMapper).getObject(EquipmentRequest.class, requestDO);
    }
}
