package dmles.equipment.server.datamodels.request;

import dmles.equipment.core.datamodels.catalog.CatalogItem;
import dmles.equipment.core.datamodels.request.workflow.process.WeighInResult;
import dmles.equipment.core.datamodels.request.workflow.process.WeighInStatus;
import dmles.equipment.core.datamodels.request.workflow.process.WorkflowLevelStatus;
import dmles.equipment.server.datamodels.request.workflow.process.WeighInDO;
import dmles.equipment.server.datamodels.request.workflow.process.WeighInUserDO;
import dmles.equipment.server.datamodels.request.workflow.process.WorkflowCommentDO;
import dmles.equipment.server.datamodels.request.workflow.process.WorkflowHistoryDO;
import dmles.equipment.server.datamodels.request.workflow.process.WorkflowLevelProcessingDO;
import dmles.equipment.server.datamodels.request.workflow.process.WorkflowProcessingDO;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;
import mil.jmlfdc.common.utils.MiscUtils;
import dmles.equipment.core.datamodels.Comment;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class TestDataModelsEquipmentRequestWorkflowProcess {
    
    private final Logger logger = LoggerFactory.getLogger(TestDataModelsEquipmentRequestWorkflowProcess.class);
    
    @Test
    public void getterSetterTest() {
        
        List<String> noTest = Arrays.asList("");

        /* datamodels.equipment.request.workflow.process tests */
        MiscUtils.getterSetterTest(WeighInDO.class, new ArrayList<>() );
        MiscUtils.getterSetterTest(WeighInResult.class, new ArrayList<>());
        MiscUtils.getterSetterTest(WeighInStatus.class, new ArrayList<>() );
        MiscUtils.getterSetterTest(WorkflowLevelProcessingDO.class, new ArrayList<>());
        MiscUtils.getterSetterTest(WorkflowLevelStatus.class, new ArrayList<>() );
        MiscUtils.getterSetterTest(WorkflowProcessingDO.class, new ArrayList<>());
        MiscUtils.getterSetterTest(WorkflowHistoryDO.class, new ArrayList<>());       
    }
    
    @Test
    public void dmWorkflowProcessTest() {
        
        boolean testBool = true;
        Date testDate = new Date();
        Integer testInt = 1;
        Long testLong = 1l;
        String testStr = "";
        
        CatalogItem catalogData = new CatalogItem();
        SortedMap<Integer, WorkflowLevelProcessingDO> testLevels = new TreeMap<>();
        Map<Integer, WorkflowLevelProcessingDO> testLevels2 = new TreeMap<>();
        
        List<Comment> testComments = new ArrayList();
        List<WorkflowCommentDO> testWorkflowComments = new ArrayList();
        List<WeighInDO> testWeighIns = new ArrayList();
        List<WeighInResult> testWeighResLst = new ArrayList();
        
        WorkflowLevelStatus testWrkFlwLvlStat;
        WeighInResult testWeighInRes;
        WeighInStatus testWeighInStat;
        WeighInUserDO testWeighInUser = new WeighInUserDO();
        
        WeighInDO testWeighIn = new WeighInDO();
        WorkflowLevelProcessingDO testWrkFlLvlProc = new WorkflowLevelProcessingDO();        
        WorkflowProcessingDO testWorkFlProc = new WorkflowProcessingDO();
        WorkflowHistoryDO testWorkFlProcHist = new WorkflowHistoryDO();
         
        testWeighIn.setComments(testComments);
        testWeighIn.setWeighInDisplayName(testStr);
        testWeighIn.setWeighInResult(testStr);
        testWeighIn.setWeighInStatus(testStr);
        testComments = testWeighIn.getComments();
        testStr = testWeighIn.getWeighInDisplayName();
        testStr = testWeighIn.getWeighInResult();
        testStr = testWeighIn.getWeighInStatus();

        testWeighInRes = WeighInResult.valueOf("APPROVE");
        testBool = testWeighInRes.equalsName(testStr);
        testStr = null;
        testBool = testWeighInRes.equalsName(testStr);
        testStr = testWeighInRes.toString();

        testWeighInStat = WeighInStatus.valueOf("NEW");
        testBool = testWeighInStat.equalsName(testStr);
        testStr = null;
        testBool = testWeighInStat.equalsName(testStr);
        testStr = testWeighInStat.toString();
        
        testWrkFlLvlProc.setWeighIns(testWeighIns);
        testWrkFlLvlProc.setStatus(testStr);
        testWrkFlLvlProc.setUpdatedBy(testStr);
        testWrkFlLvlProc.setUpdatedDate(testDate);
        testWrkFlLvlProc.setLevelId(testInt);
        testWrkFlLvlProc.setLevelName(testStr);
        testWeighIns = testWrkFlLvlProc.getWeighIns();
        testStr = testWrkFlLvlProc.getStatus();
        testStr = testWrkFlLvlProc.getUpdatedBy();
        testDate = testWrkFlLvlProc.getUpdatedDate();
        testInt = testWrkFlLvlProc.getLevelId();
        testStr = testWrkFlLvlProc.getLevelName();
        
        testWrkFlwLvlStat = WorkflowLevelStatus.valueOf("NEW");
        testBool = testWrkFlwLvlStat.equalsName(testStr);
        testStr = null;
        testBool = testWrkFlwLvlStat.equalsName(testStr);
                
        testWorkFlProc.setRequestId(testStr);
        testWorkFlProc.setLevels(testLevels);
        testWorkFlProc.setUpdatedBy(testStr);
        testWorkFlProc.setUpdatedDate(testDate);
        testWorkFlProc.setCurrentOwnerRole(testStr);
        testWorkFlProc.setIsCompleted(testBool);
        testWorkFlProc.setCurrentLevelId(testInt);
        testWorkFlProc.setCurrentStatus(testStr);
        testWorkFlProc.setComments(testWorkflowComments);
        testStr = testWorkFlProc.getRequestId();
        testStr = testWorkFlProc.getUpdatedBy();
        testDate = testWorkFlProc.getUpdatedDate();
        testStr = testWorkFlProc.getCurrentOwnerRole();
        testBool = testWorkFlProc.getIsCompleted();
        testInt = testWorkFlProc.getCurrentLevelId();
        testStr = testWorkFlProc.getCurrentStatus();
        testWorkflowComments = testWorkFlProc.getComments();
        testLevels2 = testWorkFlProc.getLevels();
        
        testWorkFlProcHist.setId(testLong);
        testWorkFlProcHist.setLevel(testStr);
        testWorkFlProcHist.setUser(testStr);
        testWorkFlProcHist.setWhen(testDate);
        testLong = testWorkFlProcHist.getId();
        testStr = testWorkFlProcHist.getLevel();
        testStr = testWorkFlProcHist.getUser();
        testDate = testWorkFlProcHist.getWhen();

    }
    
}
