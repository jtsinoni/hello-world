package dmles.equipment.server.business;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import mil.jmlfdc.common.exception.ObjectNotFoundException;
import org.junit.Test;

public class EquipmentReqWorkflowAddWeighInCommentTest extends EquipmentReqWorkflowBaseTest {
    
    @Test
    public void test1() throws ObjectNotFoundException {
        addWorkflowWhens();
        when(wfProcessing.getCurrentLevel()).thenReturn(currentLevelProcessing);
        
        erwm.addWeighInComment(requestId, weighInRole, comment);
        
        verify(requestDO, times(3)).getWfProcessing();
        addWorkflowVerifies();
    }
}
