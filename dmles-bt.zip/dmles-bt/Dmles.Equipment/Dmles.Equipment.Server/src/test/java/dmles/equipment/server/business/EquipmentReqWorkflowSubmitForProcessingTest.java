package dmles.equipment.server.business;

import dmles.equipment.core.datamodels.request.EquipmentRequest;
import dmles.equipment.server.datamodels.request.EquipmentRequestDO;
import mil.jmlfdc.common.exception.ObjectNotFoundException;
import mil.jmlfdc.common.exception.ValidationException;
import org.junit.Test;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class EquipmentReqWorkflowSubmitForProcessingTest extends EquipmentReqWorkflowBaseTest {

    @Test
    public void test1() throws ObjectNotFoundException, ValidationException {
        when(wfFactory.buildLogic(requestDO)).thenReturn(wfLogic);
        when(requestDO.getWfProcessing()).thenReturn(wfProcessing);
        when(persistHelper.saveRequest(requestDO, wfLogic)).thenReturn(requestDO);
        when(wfProcessingDao.findById(wfProcessing.getId())).thenReturn(wfProcessing);
        
        when(objectMapper.getObject(EquipmentRequestDO.class, request)).thenReturn(requestDO); 
        when(objectMapper.getObject(EquipmentRequest.class, requestDO)).thenReturn(request); 
        when(wfProcessing.getCurrentLevel()).thenReturn(currentLevelProcessing);
        when(wfProcessing.getNextLevel()).thenReturn(currentLevelProcessing);

        erwm.submitForProcessing(request);

        verify(requestDO).getWfProcessing();
        verify(wfProcessing, times(0)).getCurrentLevel();
        verify(wfProcessing, times(2)).getId();
        //verify(wfProcessingDao).insert(wfProcessing);
        verify(wfProcessingDao).findById(wfProcessing.getId());
        
        verify(wfProcessing, times(0)).getNextLevel();
        verify(wfProcessing, times(0)).getPreviousLevel();
        verify(wfProcessing, times(0)).isEndOfWorkflow();

        verify(wfFactory).buildLogic(requestDO);
        verify(persistHelper, times(1)).saveRequest(requestDO, wfLogic);
        verify(objectMapper).getObject(EquipmentRequestDO.class, request);
        verify(objectMapper).getObject(EquipmentRequest.class, requestDO);
        verify(requestValidator).validate(requestDO);
    }
}
