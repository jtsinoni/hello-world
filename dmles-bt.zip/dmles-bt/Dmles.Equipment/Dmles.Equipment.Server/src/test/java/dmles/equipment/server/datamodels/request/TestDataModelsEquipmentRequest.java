package dmles.equipment.server.datamodels.request;

import dmles.equipment.core.datamodels.catalog.SuggestedSourceItem;
import dmles.equipment.core.datamodels.catalog.CatalogItem;
import dmles.equipment.core.datamodels.request.ServiceAgency;
import dmles.equipment.core.datamodels.request.workflow.process.WorkflowLevelStatus;
import dmles.equipment.server.datamodels.request.workflow.process.WorkflowHistoryDO;
import dmles.equipment.server.datamodels.request.workflow.process.WorkflowProcessingDO;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import mil.jmlfdc.common.utils.MiscUtils;
import dmles.equipment.core.datamodels.Customer;
import dmles.equipment.core.datamodels.Organization;
import dmles.equipment.core.datamodels.Person;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TestDataModelsEquipmentRequest {
    
    private final Logger logger = LoggerFactory.getLogger(TestDataModelsEquipmentRequest.class);
    
    @Test
    public void getterSetterTest() {

        /* datamodels.equipment.request tests */
        MiscUtils.getterSetterTest(AttachmentItemDO.class, new ArrayList<>() );
        MiscUtils.getterSetterTest(CriticalCodeDO.class, new ArrayList<>());
        MiscUtils.getterSetterTest(ServiceAgency.class, new ArrayList<>());        
        MiscUtils.getterSetterTest(DeviceDO.class, new ArrayList<>());
        MiscUtils.getterSetterTest(EnvironmentalConcernDO.class, new ArrayList<>());
        MiscUtils.getterSetterTest(EquipmentCriticalityDO.class, new ArrayList<>());
        MiscUtils.getterSetterTest(EquipmentManufacturerDO.class, new ArrayList<>());
        MiscUtils.getterSetterTest(EquipmentMountingTypeDO.class, new ArrayList<>()); 
        MiscUtils.getterSetterTest(EquipmentRequestDO.class, new ArrayList<>() );
        MiscUtils.getterSetterTest(EquipmentRequestHistoryDO.class, new ArrayList<>());
        MiscUtils.getterSetterTest(EquipmentRequestReasonDO.class, new ArrayList<>());
        MiscUtils.getterSetterTest(EquipmentRequestStatusDO.class, new ArrayList<>());
        MiscUtils.getterSetterTest(EquipmentRequestTypeDO.class, new ArrayList<>());
        MiscUtils.getterSetterTest(EquipmentTraineeTypeDO.class, new ArrayList<>());
        //MiscUtils.getterSetterTest(ExtraItem.class, new ArrayList<String>()); << NOT PUBLIC
        MiscUtils.getterSetterTest(FacilityInformationDO.class, new ArrayList<>());
        //MiscUtils.getterSetterTest(InstallRequirement.class, new ArrayList<String>()); << NOT PUBLIC
        MiscUtils.getterSetterTest(LiteratureDO.class, new ArrayList<>() );
        MiscUtils.getterSetterTest(LiteratureTypeDO.class, new ArrayList<>() );
        MiscUtils.getterSetterTest(NoteItemDO.class, new ArrayList<>());
        //MiscUtils.getterSetterTest(ReplacementItem.class, new ArrayList<String>()); << NOT PUBLIC
        MiscUtils.getterSetterTest(RequestedEquipmentDO.class, new ArrayList<>());
        MiscUtils.getterSetterTest(SafetyConcernDO.class, new ArrayList<>());
        MiscUtils.getterSetterTest(SafetyInformationDO.class, new ArrayList<>());
        MiscUtils.getterSetterTest(SpecialtyDO.class, new ArrayList<>());
        MiscUtils.getterSetterTest(TechnologyInformationDO.class, new ArrayList<>());
        MiscUtils.getterSetterTest(TechnologyRequirementsDO.class, new ArrayList<>());
        MiscUtils.getterSetterTest(TraineeLocationTypeDO.class, new ArrayList<>());        
        //MiscUtils.getterSetterTest(TrainingItem.class, new ArrayList<String>()); << NOT PUBLIC
        MiscUtils.getterSetterTest(UtilityDO.class, new ArrayList<>()); 

    }
    
    @Test
    public void dmEquipmentRequestTest(){
        
        boolean testBool = true;
        Date testDate = new Date();
        float testFloat = 1.34f;
        Integer testInt = 1;
        String testStr = "t";

        CriticalCodeDO testCriticalCode = new CriticalCodeDO();
        CriticalCodesDO test1CritCodes = new CriticalCodesDO();
        ServiceAgencyDO testServAgency = new ServiceAgencyDO();
        DeviceDO testDevice = new DeviceDO();
        EnvironmentalConcernDO testEnvConc = new EnvironmentalConcernDO(testStr,testBool,testBool,testBool,testStr);        
        EquipmentCriticalityDO testEqCrit = new EquipmentCriticalityDO();
        EquipmentManufacturerDO testEqManuf = new EquipmentManufacturerDO();
        EquipmentMountingTypeDO testEqMtype = new EquipmentMountingTypeDO();
        EquipmentRequestDO testEqReq = new EquipmentRequestDO();
        testEqReq.setMaintenanceInformation(new MaintenanceInformationDO());
        testEqReq.setRequestInformation(new RequestInformationDO());
        testEqReq.setFacilityInformation(new FacilityInformationDO());
        testEqReq.setRequestInformation(new RequestInformationDO());
        
        EquipmentRequestHistoryDO testEqReqHist = new EquipmentRequestHistoryDO(testStr,testStr,testDate);
        //EquipmentRequestReasonDO testEqReqReas = new EquipmentRequestReasonDO(testStr,testStr,testStr);
        EquipmentRequestStatusDO testEqReqStat = new EquipmentRequestStatusDO(WorkflowLevelStatus.ACTIVE);
        EquipmentRequestStatusDO testEqReqStat2 = new EquipmentRequestStatusDO(WorkflowLevelStatus.ACTIVE,testStr);
        EquipmentRequestTypeDO testEqReqTyp = new EquipmentRequestTypeDO(testStr, testStr);
        LiteratureDO testLit = new LiteratureDO();
        LiteratureTypeDO testLitType = new LiteratureTypeDO();
        SafetyConcernDO testSafCon = new SafetyConcernDO(testStr, testBool, testBool, testStr);
        SafetyInformationDO testSafInfo = new SafetyInformationDO();
        SpecialtyDO  testSpec = new SpecialtyDO();
        TraineeLocationTypeDO testTrainType = new TraineeLocationTypeDO();
        RequestedEquipmentDO testReqEq = new RequestedEquipmentDO(testStr,testStr,testBool,testStr,testStr,testStr,testStr,testFloat);
        TechnologyInformationDO testTechInfo = new TechnologyInformationDO();
        TechnologyRequirementsDO testTechReqs = new TechnologyRequirementsDO( testStr, testBool, testBool, 
            testBool, testStr, testStr);
        UtilityDO testUtil = new UtilityDO(testStr, testBool, testBool, testBool, testStr, testStr );
        
        List<WorkflowHistoryDO> testHistory = new ArrayList<>();      
        
        List<AttachmentItemDO> testAttachItem = new ArrayList<>();
        List<CriticalCodesDO> testCritCodes = new ArrayList<>();
        List<EnvironmentalConcernDO> testEnvCons = new ArrayList<>();
        List<LiteratureDO> testLitList = new ArrayList<>();
        List<NoteItemDO> testNoteItems = new ArrayList<>();
        List<SafetyConcernDO> testSafConcs = new ArrayList();
        List<SuggestedSourceItem> suggestedSources = new ArrayList<>();
        List<TechnologyRequirementsDO> testTechReqLst = new ArrayList<>();
        List<TrainingItemDO> testTrainItem = new ArrayList<>();
        List<UtilityDO> testUtl = new ArrayList<>();
        
        CatalogItem testCatItem = new CatalogItem();
        Customer testCust = new Customer();
        Organization testOrg = new Organization();
        Person testPerson = new Person();
        //CustodianDO testCustodian = new CustodianDO();
        WorkflowProcessingDO testWrkFlProc = new WorkflowProcessingDO();
        
        
        testStr = testCriticalCode.getId();
        
        testServAgency.code = "testcode";
        testServAgency.name = "testName";

        testServAgency.setCode(testStr);
        testStr = testServAgency.getCode();

        testServAgency.setName(testStr);
        testStr = testServAgency.getName();
        
        testCriticalCode.setServiceAgency(testServAgency);
        testCriticalCode.setCriticalCodes(testCritCodes);
        testServAgency = testCriticalCode.getServiceAgency();
        testCritCodes = testCriticalCode.getCriticalCodes();
        
        test1CritCodes.setCode("testCode");
        testStr = test1CritCodes.getCode();
        test1CritCodes.setDescription("{testDesc");
        testStr = test1CritCodes.getDescription();
        
        testDevice.setNomenclature(testStr);
        testDevice.setDeviceCode(testStr);
        /*testDevice.setCentrallyManagedInd(testBool);
        testDevice.setDeleteInd(testBool);
        testDevice.setDeviceAccountableCd(testBool);
        testDevice.setMaintRequiredCd(testBool);
        testDevice.setFederalSupplyCd(testInt);
        testDevice.setLifeExpectancyQty(testInt);
        testDevice.setRelativeRiskLevelCd(testInt);
        testDevice.setDeviceClassCd(testStr);
        testDevice.setDeviceDefinitionTx(testStr);
        testDevice.setIsRetired(testStr);
        testDevice.setSpecialtyCd(testStr);*/
        
        testStr = testDevice.getDeviceCode();
        testStr = testDevice.getNomenclature();
        
        /*testBool = testDevice.getDeleteInd();
        testBool = testDevice.getDeviceAccountableCd();
        testBool = testDevice.getMaintRequiredCd();
        testInt = testDevice.getFederalSupplyCd();
        testInt = testDevice.getLifeExpectancyQty();
        testInt = testDevice.getRelativeRiskLevelCd();
        testStr = testDevice.getDeviceClassCd();
        testStr = testDevice.getDeviceDefinitionTx();
        testStr = testDevice.getIsRetired();
        testStr = testDevice.getSpecialtyCd();*/
        
        testEnvConc.setName(testStr);
        testEnvConc.setNa(testBool);
        testEnvConc.setUses(testBool);
        testEnvConc.setGenerates(testBool);
        testStr = testEnvConc.getName();
        testBool = testEnvConc.getNa();
        testBool = testEnvConc.getUses();
        testBool = testEnvConc.getGenerates();

        testEqCrit.setEquipCriticalityTx(testStr);
        testEqCrit.setEquipCriticalityCd(1);
        testEqCrit.setServiceAgencyCd(testStr);
        testStr = testEqCrit.getEquipCriticalityTx();
        testStr = testEqCrit.getServiceAgencyCd();
        
        //testEqManuf.setCentrallyManagedInd(testBool);
        testEqManuf.setDeleteInd(testBool);
        //testEqManuf.setExternalOrgSerial(testInt);
        testEqManuf.setOrganizationNm(testStr);
        testBool = testEqManuf.getDeleteInd();
        //testInt = testEqManuf.getExternalOrgSerial();
        testStr = testEqManuf.getOrganizationNm();
                
        testEqMtype.setEquipMountingTypeTx(testStr);
        testEqMtype.setEquipMountingTypeCd(1);
        testStr = testEqMtype.getEquipMountingTypeTx();

        testEqReqTyp.setName(testStr);
        testStr = testEqReqTyp.getName();

        testEqReq.getMaintenanceInformation().setLiterature(testLitList);
        testEqReq.getMaintenanceInformation().setTotalLiteratureCosts(testFloat);
        testEqReq.setTotalPrice(testFloat);
        testEqReq.getRequestInformation().setTotalTrainingCost(testFloat);
        testEqReq.getRequestInformation().setCriticalCode(testStr);
        testEqReq.setItemIdProvided(testBool);
        testEqReq.getRequestInformation().setMissionImpact(testStr);
        testEqReq.getRequestInformation().setMissionImpactDoc(testStr);
        testEqReq.getRequestInformation().setQuantityRequested(testInt);
        testEqReq.getRequestInformation().setRequestedDeliveryDate(testDate);
        testEqReq.getRequestInformation().setRequestedDeliveryDateReason(testStr);
        testEqReq.getRequestInformation().setDescription(testStr);
        testEqReq.getRequestInformation().setRequestedItemId(testStr);
        testEqReq.getRequestInformation().setRequestNumber(testStr);
        testEqReq.getRequestInformation().setRequestTitle(testStr);
        testEqReq.getRequestInformation().setTotalCompAccSupplies(testFloat);
        testEqReq.getFacilityInformation().setFacilityModificationCost(testFloat);
        testEqReq.getMaintenanceInformation().setTotalInstallationCosts(testFloat);
        testEqReq.getMaintenanceInformation().setMaintenanceActivity(testStr);
        testEqReq.getMaintenanceInformation().setMaintenanceByOrg(testBool);
        testEqReq.getMaintenanceInformation().setMaintenanceByService(testBool);
        testEqReq.getMaintenanceInformation().setMaintenanceByOGA(testBool);
        testEqReq.getMaintenanceInformation().setEstimatedAnnualServiceCost(testFloat);
        testEqReq.getMaintenanceInformation().setMaintenanceExplanation(testStr);
        testEqReq.getMaintenanceInformation().setTmdeRequired(testStr);
        testEqReq.getMaintenanceInformation().setInstallationRequired(testStr);
        testEqReq.getRequestInformation().setRequester(testPerson);
        testEqReq.getRequestInformation().setCustomer(testCust);
        testEqReq.getRequestInformation().setOrganization(testOrg);
        testEqReq.setUpdatedBy(testStr);
        testEqReq.getRequestInformation().setEquipment(testReqEq);
        testEqReq.getRequestInformation().setRequestType(testEqReqTyp);
        testEqReq.setCatalogItem(testCatItem);
        testEqReq.getRequestInformation().setSuggestedSources(suggestedSources);
        testEqReq.setUpdatedDate(testDate);
        testEqReq.setNotes(testNoteItems);
        testEqReq.setAttachments(testAttachItem);
        testEqReq.setWfProcessing(testWrkFlProc);
        testEqReq.getRequestInformation().setTraining(testTrainItem);
        testEqReq.setSafetyInformation(testSafInfo);
        testEqReq.setTechnologyInformation(testTechInfo);
        //testEqReq.setHistory(testHistory);
        
        testTechInfo = testEqReq.getTechnologyInformation();
        testSafInfo = testEqReq.getSafetyInformation();
        testLitList = testEqReq.getMaintenanceInformation().getLiterature();
        testFloat = testEqReq.getMaintenanceInformation().getTotalLiteratureCosts();
        testFloat = testEqReq.getTotalPrice();
        testFloat = testEqReq.getRequestInformation().getTotalTrainingCost();
        testStr = testEqReq.getRequestInformation().getCriticalCode();
        testBool = testEqReq.getItemIdProvided();
        testStr = testEqReq.getRequestInformation().getMissionImpact();
        testStr = testEqReq.getRequestInformation().getMissionImpactDoc();
        testInt = testEqReq.getRequestInformation().getQuantityRequested();
        testDate = testEqReq.getRequestInformation().getRequestedDeliveryDate();
        testStr = testEqReq.getRequestInformation().getRequestedDeliveryDateReason();
        testStr = testEqReq.getRequestInformation().getDescription();
        testStr = testEqReq.getRequestInformation().getRequestedItemId();
        testStr = testEqReq.getRequestInformation().getRequestNumber();
        testStr = testEqReq.getRequestInformation().getRequestTitle();
        testFloat = testEqReq.getRequestInformation().getTotalCompAccSupplies();
        testFloat = testEqReq.getFacilityInformation().getFacilityModificationCost();
        testFloat = testEqReq.getMaintenanceInformation().getTotalInstallationCosts();
        testStr = testEqReq.getMaintenanceInformation().getMaintenanceActivity();
        testBool = testEqReq.getMaintenanceInformation().getMaintenanceByOrg();
        testBool = testEqReq.getMaintenanceInformation().getMaintenanceByService();
        testBool = testEqReq.getMaintenanceInformation().getMaintenanceByOGA();
        testFloat = testEqReq.getMaintenanceInformation().getEstimatedAnnualServiceCost();
        testStr = testEqReq.getMaintenanceInformation().getMaintenanceExplanation();
        testStr = testEqReq.getMaintenanceInformation().getTmdeRequired();
        testStr = testEqReq.getMaintenanceInformation().getInstallationRequired();
        //testCustodian = testEqReq.getCustodian();
        testPerson = testEqReq.getRequestInformation().getRequester();
        testCust = testEqReq.getRequestInformation().getCustomer();
        testOrg = testEqReq.getRequestInformation().getOrganization();
        testStr = testEqReq.getUpdatedBy();
        testReqEq = testEqReq.getRequestInformation().getEquipment();
        testEqReq.getFacilityInformation();
        testEqReqTyp = testEqReq.getRequestInformation().getRequestType();
        testCatItem = testEqReq.getCatalogItem();

        suggestedSources = testEqReq.getRequestInformation().getSuggestedSources();
        testDate = testEqReq.getUpdatedDate();
        testNoteItems = testEqReq.getNotes();
        testAttachItem = testEqReq.getAttachments();
        testWrkFlProc = testEqReq.getWfProcessing();
        testTrainItem = testEqReq.getRequestInformation().getTraining();
        
        //testHistory = testEqReq.getHistory();
        
        testEqReqStat.setState(WorkflowLevelStatus.ACTIVE);

        testLit.setType(testStr);
        testLit.setCost(testFloat);
        testLit.setQuantity(testInt);
        testLit.setTotalCost(testFloat);
        testStr = testLit.getType();
        testFloat = testLit.getCost();
        testInt = testLit.getQuantity();
        testFloat = testLit.getTotalCost();

        testLitType.setLiteratureTypeCd(testStr);
        testLitType.setLiteratureTypeTx(testStr);
        testStr = testLitType.getLiteratureTypeCd();
        testStr = testLitType.getLiteratureTypeTx();
        
        testReqEq.setIsFoundInCatalog(testBool);
        testReqEq.setManufacturer(testStr);
        testReqEq.setModel(testStr);
        testReqEq.setDeviceName(testStr);
        testReqEq.setDeviceCode(testStr);
        testReqEq.setOtherSystemRequired(testStr);
        testReqEq.setUnitCost(testFloat);
        testStr = testReqEq.getManufacturer();
        testStr = testReqEq.getModel();
        testStr = testReqEq.getDeviceName();
        testStr = testReqEq.getDeviceCode();
        testStr = testReqEq.getOtherSystemRequired();
        testFloat = testReqEq.getUnitCost();

        testSpec.setCode(testStr);
        testSpec.setDescription(testStr);
        testStr = testSpec.getCode();
        testStr = testSpec.getDescription();

        testSafCon.setRequired(testBool);
        
        testSafInfo.setEnvironmentalConcerns(testEnvCons);
        testSafInfo.setSafetyConcerns(testSafConcs);
        testSafConcs = testSafInfo.getSafetyConcerns();
                
        testTechInfo.setTechnologyRequirements(testTechReqLst);
        
        testTechReqs.setName(testStr);
        testTechReqs.setRequired(testBool);
        testTechReqs.setAvailable(testBool);
        testTechReqs.setNa(testBool);
        testTechReqs.setComments(testStr);
        testTechReqs.setSpecifications(testStr);
        testStr = testTechReqs.getName();
        testBool = testTechReqs.getRequired();
        testBool = testTechReqs.getNa();
        testStr = testTechReqs.getComments();
        testStr = testTechReqs.getSpecifications();

        testTrainType.setTrainingLocationTypeCd(testStr);
        testTrainType.setTrainingLocationTypeTx(testStr);
        testStr = testTrainType.getTrainingLocationTypeCd();
        testStr = testTrainType.getTrainingLocationTypeTx();
        
        testUtil.setName(testStr);
        testUtil.setRequired(testBool);
        testUtil.setAvailable(testBool);
        testUtil.setNa(testBool);
        testUtil.setComments(testStr);
        testUtil.setSpecifications(testStr);
        testStr = testUtil.getName();
        testBool = testUtil.getRequired();
        testBool = testUtil.getNa();
        testStr = testUtil.getComments();
        testStr = testUtil.getSpecifications();
        
    }
       
}
