package dmles.equipment.server.business;

import dmles.search.dao.ElasticSearchDao;
import org.junit.Before;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;

import org.mockito.Mock;

public class ElasticSearchManagerBaseTest {

    @Mock protected Logger logger;
    @Mock protected ElasticSearchDao esDao;
    @Mock protected ElasticSearchAggregations esAggregations;

    @InjectMocks
    protected ElasticSearchManager esm;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

}
