package dmles.equipment.server.datamodels;


public class Shards {
    
    public int total;
    public int successful;
    public int failed;
}
