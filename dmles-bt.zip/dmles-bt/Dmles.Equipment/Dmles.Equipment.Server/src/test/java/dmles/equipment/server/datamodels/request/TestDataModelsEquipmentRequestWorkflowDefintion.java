package dmles.equipment.server.datamodels.request;

import dmles.equipment.server.datamodels.request.workflow.definition.LevelDefinitionWeighInDO;
import dmles.equipment.server.datamodels.request.workflow.definition.WorkflowDefinitionDO;
import dmles.equipment.server.datamodels.request.workflow.definition.WorkflowLevelDefinitionDO;
import mil.jmlfdc.common.utils.MiscUtils;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

public class TestDataModelsEquipmentRequestWorkflowDefintion {
    
    private final Logger logger = LoggerFactory.getLogger(TestDataModelsEquipmentRequestWorkflowDefintion.class);
    
    @Test
    public void getterSetterTest() {
        
        List<String> noTest = Arrays.asList("");
        
        /* datamodels.equipment.request.workflow.definition tests */
        MiscUtils.getterSetterTest(WorkflowDefinitionDO.class, new ArrayList<String>() );
        MiscUtils.getterSetterTest(WorkflowLevelDefinitionDO.class, new ArrayList<String>());
        
    }
    
    @Test
    public void dmWorkFlowDefinitionTest(){
        
        boolean testBool = true;
        String testRetStr = "";
        Date testDate = new Date();
        
        List<WorkflowLevelDefinitionDO> testWorkflowLevelDefs = new ArrayList();
        
        WorkflowDefinitionDO testWorkflowDef = new WorkflowDefinitionDO(); 
        WorkflowDefinitionDO testWorkflowDef2 = new WorkflowDefinitionDO("name", "service", "version", testDate, testDate ); 
        
        testRetStr = testWorkflowDef2.getName();
        testRetStr = testWorkflowDef2.getService();
        testRetStr = testWorkflowDef2.getVersion();
        
        testWorkflowDef.setName("testNm");
        testWorkflowDef.setService("testSvc");
        testWorkflowDef.setVersion("testVer");
        
        testWorkflowDef.setLevelDefinitions(testWorkflowLevelDefs);
        
        testWorkflowLevelDefs = testWorkflowDef.getLevelDefinitions(); 
        
        String testRole = "TestRole";
        
        WorkflowLevelDefinitionDO testWorkflowLevel = new WorkflowLevelDefinitionDO( 1, "Name", testRole
        );
        
        testWorkflowLevel.setLevelId(6);
        Integer lvlId = testWorkflowLevel.getLevelId();
                        
        testWorkflowLevel.setName("lvlName");
        testRetStr = testWorkflowLevel.getName();
        
        testWorkflowLevel.getRules().setAllowAutoApproveAfterWeighIn(testBool);
        testWorkflowLevel.getRules().setAllowCancel(testBool);
        testWorkflowLevel.getRules().setAllowForceUp(testBool);
        testWorkflowLevel.getRules().setAllowHold(testBool);
        testWorkflowLevel.getRules().setAllowModify(testBool);
        testWorkflowLevel.getRules().setAllowNoteConcern(testBool);
        testWorkflowLevel.getRules().setAllowOwnerOverrideNegativeWeighIns(testBool);
        testWorkflowLevel.getRules().setAllowReject(testBool);
        testWorkflowLevel.getRules().setAllowRequestCancel(testBool);
        testWorkflowLevel.getRules().setAllowRetract(testBool);
        testWorkflowLevel.getRules().setAllowRework(testBool);
        testWorkflowLevel.getRules().setAllowWeighInBypassOnApprove(testBool);
        testWorkflowLevel.getRules().setAllowWeighInSelection(testBool);
        
        testBool = testWorkflowLevel.getRules().getAllowAutoApproveAfterWeighIn();
        testBool = testWorkflowLevel.getRules().getAllowCancel();
        testBool = testWorkflowLevel.getRules().getAllowForceUp();
        testBool = testWorkflowLevel.getRules().getAllowHold();
        testBool = testWorkflowLevel.getRules().getAllowModify();
        testBool = testWorkflowLevel.getRules().getAllowNoteConcern();
        testBool = testWorkflowLevel.getRules().getAllowOwnerOverrideNegativeWeighIns();
        testBool = testWorkflowLevel.getRules().getAllowReject();
        testBool = testWorkflowLevel.getRules().getAllowRequestCancel();
        testBool = testWorkflowLevel.getRules().getAllowRetract();
        testBool = testWorkflowLevel.getRules().getAllowRework();
        testBool = testWorkflowLevel.getRules().getAllowWeighInBypassOnApprove();
        testBool = testWorkflowLevel.getRules().getAllowWeighInSelection();

        testRole = testWorkflowLevel.getOwnerRoleId();
        testWorkflowLevel.setOwnerRoleId(testRole);
        
        List<LevelDefinitionWeighInDO> testRoles = new ArrayList<>();
        testRoles = testWorkflowLevel.getLevelDefinitionWeighIns();
        testWorkflowLevel.setLevelDefinitionWeighIns(testRoles);  
        
    }
}
