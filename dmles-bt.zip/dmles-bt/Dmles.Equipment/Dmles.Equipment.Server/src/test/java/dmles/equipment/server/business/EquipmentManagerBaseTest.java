
package dmles.equipment.server.business;

import dmles.equipment.server.dao.CriticalCodeDao;
import dmles.equipment.server.dao.DeviceDao;
import dmles.equipment.server.dao.EquipmentCriticalityDao;
import dmles.equipment.server.dao.EquipmentManufacturerDao;
import dmles.equipment.server.dao.EquipmentMountingTypeDao;
import dmles.equipment.server.dao.EquipmentRecordDao;
import dmles.equipment.server.dao.EquipmentRequestDao;
import dmles.equipment.server.dao.EquipmentRequestReasonDao;
import dmles.equipment.server.dao.EquipmentRequestTypeDao;
import dmles.equipment.server.dao.EquipmentTraineeTypeDao;
import dmles.equipment.server.dao.LiteratureTypeDao;
import dmles.equipment.server.dao.SpecialtyDao;
import dmles.equipment.server.dao.TraineeLocationTypeDao;
import dmles.oauth.core.datamodel.CurrentUserBT;
import mil.jmlfdc.common.utils.ObjectMapper;
import org.junit.Before;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;

public class EquipmentManagerBaseTest {
    
    @Mock protected CurrentUserBT user;
    @Mock protected Logger logger;
    @Mock protected CriticalCodeDao criticalCodeDao;
    @Mock protected DeviceDao deviceDao;
    @Mock protected EquipmentCriticalityDao equipmentCriticalityDao;
    @Mock protected EquipmentManufacturerDao equipmentManufacturerDao;
    @Mock protected EquipmentMountingTypeDao equipmentMountingTypeDao;
    @Mock protected EquipmentRequestDao equipmentRequestDao;
    @Mock protected EquipmentRecordDao equipmentRecordDao;
    @Mock protected LiteratureTypeDao literatureTypeDao;
    @Mock protected EquipmentTraineeTypeDao equipmentTraineeTypeDao;
    @Mock protected SpecialtyDao specialtyDao;
    @Mock protected TraineeLocationTypeDao traineeLocationTypeDao;
    @Mock protected ObjectMapper objectMapper;
    @Mock protected EquipmentRequestTypeDao equipmentRequestTypeDao;
    @Mock protected EquipmentRequestReasonDao equipmentRequestReasonDao;
    
    @InjectMocks protected EquipmentRequestManager emm;
    
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

}