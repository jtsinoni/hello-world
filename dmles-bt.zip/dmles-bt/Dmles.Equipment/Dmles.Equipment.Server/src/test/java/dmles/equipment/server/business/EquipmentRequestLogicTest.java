package dmles.equipment.server.business;

import dmles.equipment.server.datamodels.request.EquipmentRequestDO;
import dmles.equipment.server.datamodels.request.workflow.definition.WorkflowDefinitionDO;
import dmles.equipment.server.datamodels.request.workflow.definition.WorkflowLevelDefinitionDO;
import dmles.user.core.clientmodel.UserProfile;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class EquipmentRequestLogicTest {

    private static final Logger logger = Logger.getLogger(EquipmentRequestLogicTest.class.getName());
    private static final String ROLE_EQUIP_MNGR = "EquipmentManager";
    private static final String ROLE_REGIONAL_EQUIP_MNGR = "RegionalEquipmentManager";
    private static final String ROLE_DHA_EQUIP_MNGR = "DHAEquipmentManager";  
    private static final String ROLE_FACILITY_MNGR = "FacilitiesManager";  
    private static final String ROLE_TECH_MNGR = "TechnologyManager";  
    private static final String ROLE_MEDICAL_MNGR = "MedicalManager";              
    private final EquipmentRequestDO request1 = new EquipmentRequestDO();
    private final WorkflowDefinitionDO workflow = new WorkflowDefinitionDO();
    private final UserProfile user1 = new UserProfile();
    
    @Before
    public void setUp() throws MalformedURLException {
        logger.log(Level.INFO, "setUp:: Setting up EquipmentRequestLogic tests");
        buildWorkflow();
    }

    @Test
    public void performTest() {
        logger.log(Level.INFO, "testFileUploadDaoNotNull::Entering testFileUploadDaoNotNull test...");
        // TODO
    }

    @After
    public void cleanUp() {
        logger.log(Level.INFO, "cleanUp:: Cleaning up EquipmentRequestLogic tests");
    }

    private void buildWorkflow() {
        // TODO
    }

    private List<WorkflowLevelDefinitionDO> buildLevels() {
        List<WorkflowLevelDefinitionDO> levels = new ArrayList<>();
        
        // TODO
        
        return levels;
    }

}
