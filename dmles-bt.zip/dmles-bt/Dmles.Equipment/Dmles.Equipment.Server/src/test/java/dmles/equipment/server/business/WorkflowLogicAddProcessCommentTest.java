package dmles.equipment.server.business;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dmles.equipment.server.datamodels.request.workflow.process.WorkflowCommentDO;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;


public class WorkflowLogicAddProcessCommentTest extends WorkflowLogicBaseTest {
    
    private final String firstName = "TestFirstName";
    private final String lastName = "TestLastName";      
    
    @Test
    public void testSave() {
        String comment = "comment";
        List<WorkflowCommentDO> comments = mock(ArrayList.class);
        when(request.getWfProcessing()).thenReturn(wfProcessing);
        when(wfProcessing.getComments()).thenReturn(comments);
        
        when(user.getFirstName()).thenReturn(firstName);
        when(user.getLastName()).thenReturn(lastName);
        
        wfLogic.addProcessComment(comment);

        verify(request, times(4)).getWfProcessing();
        verify(user).getFirstName();
        verify(user).getLastName();
        verify(wfProcessing, times(2)).getComments();
        verify(comments).add(any(WorkflowCommentDO.class));
    }
    
}
