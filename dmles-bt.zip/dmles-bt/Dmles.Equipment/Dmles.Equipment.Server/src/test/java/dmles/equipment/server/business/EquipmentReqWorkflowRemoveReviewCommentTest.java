package dmles.equipment.server.business;


import java.util.ArrayList;
import java.util.List;

import dmles.equipment.server.datamodels.request.workflow.process.ReviewDO;
import mil.jmlfdc.common.exception.ObjectNotFoundException;
import dmles.equipment.server.datamodels.CommentDO;
import org.junit.Assert;
import org.junit.Test;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;



public class EquipmentReqWorkflowRemoveReviewCommentTest extends EquipmentReqWorkflowBaseTest {
    
    @Test
    public void testRemoveComment() throws ObjectNotFoundException {
        String commentIdStr = "1234";
        Long commentIdL = 1234L;       
        
        List<CommentDO> comments =  new ArrayList<>();
        CommentDO commentDataObj = new CommentDO();
        commentDataObj.setComment(comment);
        commentDataObj.setId(commentIdL);
        comments.add(commentDataObj);
        
        List<ReviewDO> reviews = new ArrayList<>();
        ReviewDO reviewObj = new ReviewDO();
        reviewObj.setComments(comments);
        reviewObj.setRoleId(reviewRole);
        reviews.add(reviewObj);

        addWorkflowWhens();
        when(wfProcessing.getCurrentLevel()).thenReturn(currentLevelProcessing);
        when(currentLevelProcessing.getReviews()).thenReturn(reviews);
        when(review.getRoleId()).thenReturn(reviewRole);
        when(review.getComments()).thenReturn(comments);
        when(commentObj.getId()).thenReturn(commentIdL);
        
        erwm.removeReviewComment(requestId, reviewRole, commentIdStr);
        
        Assert.assertEquals(0, comments.size());
        
        verify(requestDO, times(3)).getWfProcessing();
        verify(wfProcessing).getCurrentLevel();
        verify(currentLevelProcessing, times(3)).getReviews();
        
        verify(wfProcessing, times(0)).getNextLevel();
        verify(wfProcessing, times(0)).getPreviousLevel();
        verify(wfProcessing, times(0)).isEndOfWorkflow();

        addWorkflowVerifies();          
    }
        
}
