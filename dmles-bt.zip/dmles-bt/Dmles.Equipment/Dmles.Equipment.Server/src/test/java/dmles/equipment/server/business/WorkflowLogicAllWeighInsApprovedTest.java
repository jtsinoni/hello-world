package dmles.equipment.server.business;

import dmles.equipment.core.datamodels.request.workflow.process.WeighInResult;
import dmles.equipment.core.datamodels.request.workflow.process.WeighInStatus;
import dmles.equipment.server.datamodels.request.workflow.process.WeighInDO;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;

public class WorkflowLogicAllWeighInsApprovedTest {

    private WorkflowLogic logic;
    @Mock private WeighInDO wTrue;
    @Mock private WeighInDO wFalse;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        logic = new WorkflowLogic(null, null, null, null);
        Mockito.when(wTrue.getWeighInStatus()).thenReturn(WeighInStatus.SUBMITTED.toString());
        Mockito.when(wFalse.getWeighInStatus()).thenReturn(WeighInStatus.PENDING.toString());

    }

    @Test
    public void test1() {
        List<WeighInDO> list = buildList(0,0, true);

        logic.allWeighInsApproved(list);
        verify(0,1);
    }

    // TODO: Fix before going to Test
//    @Test
//    public void test2() {
//        List<WeighInDO> list = buildList(1,0, true);
//
//        logic.allWeighInsApproved(list);
//        verify(1,1);
//
//    }

    // TODO: Fix before going to Test
//    @Test
//    public void test21() {
//        List<WeighInDO> list = buildList(1,1, true);
//
//        logic.allWeighInsApproved(list);
//        verify(1,1);
//
//    }

    // TODO: Fix before going to Test
//    @Test
//    public void test3() {
//        List<WeighInDO> list = buildList(2,0, true);
//
//        logic.allWeighInsApproved(list);
//        verify(2,1);
//
//    }

    // TODO: Fix before going to Test
//    @Test
//    public void test31() {
//        List<WeighInDO> list = buildList(2,1, true);
//
//        logic.allWeighInsApproved(list);
//        verify(2,1);
//
//    }

    // TODO: Fix before going to Test
//    @Test
//    public void test4() {
//        List<WeighInDO> list = buildList(3,0, true);
//
//        logic.allWeighInsApproved(list);
//        verify(3,1);
//
//    }

    // TODO: Fix before going to Test
//    @Test
//    public void test44() {
//        List<WeighInDO> list = buildList(3,4, true);
//
//        logic.allWeighInsApproved(list);
//        verify(3,1);
//
//    }

    // TODO: Fix before going to Test
//    @Test
//    public void test40() {
//        List<WeighInDO> list = buildList(3,4, false);
//
//        logic.allWeighInsApproved(list);
//        verify(7,0);
//
//    }

    private void verify(int trueCount, int falseCount) {
        Mockito.verify(wTrue, Mockito.times(trueCount)).getWeighInStatus();
        Mockito.verify(wTrue, Mockito.times(trueCount)).getWeighInResult();
        Mockito.verify(wFalse, Mockito.times(falseCount)).getWeighInStatus();

    }
    private List<WeighInDO> buildList(int numBefore, int numAfter, boolean includeFalse) {
        List<WeighInDO> list = new ArrayList<>();


        list.addAll(buildTrueList(numBefore));
        if (includeFalse) {
            list.add(wFalse);
        }
        list.addAll(buildTrueList(numAfter));
        return list;
    }

    private List<WeighInDO> buildTrueList(int count) {
        List<WeighInDO> list = new ArrayList<>();
        for (int i = 1; i <= count; i++) {
            list.add(wTrue);
        }
        return list;
    }
}
