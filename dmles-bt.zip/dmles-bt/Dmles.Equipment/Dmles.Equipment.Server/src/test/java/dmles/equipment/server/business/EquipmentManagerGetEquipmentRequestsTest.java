package dmles.equipment.server.business;

import dmles.equipment.core.datamodels.request.EquipmentRequest;
import dmles.equipment.server.datamodels.request.EquipmentRequestDO;
import java.util.ArrayList;
import java.util.List;
import org.junit.Test;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;


public class EquipmentManagerGetEquipmentRequestsTest extends EquipmentManagerBaseTest {
    
    @Test
    public void test1() {
        List<EquipmentRequestDO> doList = new ArrayList<>();
        
        //when(requestFetcher.getRequestsPerUserType()).thenReturn(doList);
        
        //emm.getEquipmentRequests();
        
        //verify(requestFetcher).getRequestsPerUserType();
        //verify(objectMapper).getList(EquipmentRequest[].class, doList);
    }    
    
}