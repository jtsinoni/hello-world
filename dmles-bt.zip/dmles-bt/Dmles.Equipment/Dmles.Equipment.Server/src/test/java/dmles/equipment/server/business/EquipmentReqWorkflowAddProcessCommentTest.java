package dmles.equipment.server.business;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dmles.equipment.server.datamodels.request.workflow.process.WorkflowCommentDO;
import mil.jmlfdc.common.exception.ObjectNotFoundException;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

public class EquipmentReqWorkflowAddProcessCommentTest extends EquipmentReqWorkflowBaseTest {

    @Test
    public void testWithComments() throws ObjectNotFoundException {
        String comment = "comment";
        List<WorkflowCommentDO> comments = mock(ArrayList.class);
        addDefaultWhens();
        addWorkflowWhens();
        when(wfProcessing.getComments()).thenReturn(comments);

        erwm.addProcessComment(requestId, comment);

        verify(requestDO, times(4)).getWfProcessing();
        addWorkflowVerifies();
    }
    
    @Test
    public void testWithOutComments() throws ObjectNotFoundException {
        String comment = "comment";

        addWorkflowWhens();
        when(wfProcessing.getComments()).thenReturn(null);

        erwm.addProcessComment(requestId, comment);

        verify(requestDO, times(4)).getWfProcessing();
        addWorkflowVerifies();
    }    
}
