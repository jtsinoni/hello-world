package dmles.equipment.server.business;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dmles.equipment.core.datamodels.request.EquipmentRequest;
import dmles.equipment.server.datamodels.request.EquipmentRequestDO;
import org.junit.Test;

public class EquipmentManagerGetEquipmentRequestTest extends EquipmentManagerBaseTest {
    
    @Test
    public void test1() {
        String id = "id";
        EquipmentRequestDO request = mock(EquipmentRequestDO.class);
        
        when(equipmentRequestDao.findById(id)).thenReturn(request);
        
        emm.getEquipmentRequest(id);
        
        verify(equipmentRequestDao).findById(id);
        verify(objectMapper).getObject(EquipmentRequest.class, request);
    }

}