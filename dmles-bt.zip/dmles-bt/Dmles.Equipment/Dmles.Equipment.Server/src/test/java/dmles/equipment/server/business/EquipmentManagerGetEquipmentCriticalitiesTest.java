package dmles.equipment.server.business;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dmles.equipment.core.datamodels.request.EquipmentCriticality;
import dmles.equipment.server.datamodels.request.EquipmentCriticalityDO;
import org.junit.Test;

import java.util.ArrayList;

import java.util.List;

public class EquipmentManagerGetEquipmentCriticalitiesTest extends EquipmentManagerBaseTest {
    
    @Test
    public void test1() {
        List<EquipmentCriticalityDO> doList = new ArrayList<>();
        
        when(equipmentCriticalityDao.findAll()).thenReturn(doList);
        
        emm.getEquipmentCriticalities();
        
        verify(equipmentCriticalityDao).findAll();
        verify(objectMapper).getList(EquipmentCriticality[].class, doList);
    }

}