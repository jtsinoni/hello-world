package dmles.equipment.server.business;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dmles.equipment.core.datamodels.request.LiteratureType;
import dmles.equipment.server.datamodels.request.LiteratureTypeDO;
import org.junit.Test;

import java.util.ArrayList;

import java.util.List;

public class EquipmentManagerGetLiteratureTypesTest extends EquipmentManagerBaseTest {
    
    @Test
    public void test1() {
        List<LiteratureTypeDO> doList = new ArrayList<>();
        
        when(literatureTypeDao.findAll()).thenReturn(doList);
        
        emm.getLiteratureTypes();
        
        verify(literatureTypeDao).findAll();
        verify(objectMapper).getList(LiteratureType[].class, doList);
    }

}