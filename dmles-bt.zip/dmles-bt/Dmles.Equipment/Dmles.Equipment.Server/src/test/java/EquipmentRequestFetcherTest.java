
import dmles.equipment.server.business.EquipmentRequestFetcher;
import dmles.equipment.server.dao.EquipmentRequestDao;
import dmles.equipment.server.datamodels.request.EquipmentRequestDO;
import dmles.oauth.core.datamodel.CurrentUserBT;
import dmles.user.core.clientmodel.UserType;
import java.util.ArrayList;
import java.util.List;
import mil.jmlfdc.common.utils.ObjectMapper;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import org.mockito.MockitoAnnotations;

public class EquipmentRequestFetcherTest {
    
    @Mock CurrentUserBT user;
    @Mock EquipmentRequestDao requestDao;
    @InjectMocks EquipmentRequestFetcher requestFetcher;
    
    public String serviceCode = "DA";
    public String regionCode = "RHC-A";
    public  String dodaac = "W33DME";
    
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }    
    
    @Test
    public void testGlobal(){
        List<EquipmentRequestDO> listDo = mock(ArrayList.class);
        when(user.getUserType()).thenReturn(UserType.GLOBAL);
        when(requestDao.findAll()).thenReturn(listDo);
        
        requestFetcher.getRequestsPerUserType();
        
        verify(user).getUserType();
        verify(requestDao).findAll();
        verify(requestDao, times(0)).findByService(serviceCode);
        verify(requestDao, times(0)).findByServiceAndRegion(serviceCode, regionCode);
        verify(requestDao, times(0)).findBySite(dodaac);        
    }
    
    @Test
    public void testService(){
        List<EquipmentRequestDO> listDo = mock(ArrayList.class);
        when(user.getUserType()).thenReturn(UserType.SERVICE);
        when(user.getServiceCode()).thenReturn(serviceCode);
        when(requestDao.findByService(serviceCode)).thenReturn(listDo);
        
        requestFetcher.getRequestsPerUserType();
        
        verify(user).getUserType();
        verify(requestDao, times(0)).findAll();
        verify(requestDao).findByService(serviceCode);
        verify(requestDao, times(0)).findByServiceAndRegion(serviceCode, regionCode);
        verify(requestDao, times(0)).findBySite(dodaac);
    }    
    
    @Test
    public void testRegion(){
        List<EquipmentRequestDO> listDo = mock(ArrayList.class);
        when(user.getUserType()).thenReturn(UserType.SERVICEREGION);
        when(user.getServiceCode()).thenReturn(serviceCode);
        when(user.getRegionCode()).thenReturn(regionCode);
        when(requestDao.findByServiceAndRegion(serviceCode, regionCode)).thenReturn(listDo);
        
        requestFetcher.getRequestsPerUserType();
        
        verify(user).getUserType();
        verify(requestDao, times(0)).findAll();
        verify(requestDao, times(0)).findByService(serviceCode);        
        verify(requestDao).findByServiceAndRegion(serviceCode, regionCode);
        verify(requestDao, times(0)).findBySite(dodaac);
    }   
    
    @Test
    public void testSite(){
        List<EquipmentRequestDO> listDo = mock(ArrayList.class);
        when(user.getUserType()).thenReturn(UserType.SITE);
        when(user.getDodaac()).thenReturn(dodaac);
        when(requestDao.findBySite(dodaac)).thenReturn(listDo);
        
        requestFetcher.getRequestsPerUserType();
        
        verify(user).getUserType();
        verify(requestDao, times(0)).findAll();
        verify(requestDao, times(0)).findByService(serviceCode);
        verify(requestDao, times(0)).findByServiceAndRegion(serviceCode, regionCode);        
        verify(requestDao).findBySite(dodaac);
    }  
        
}
