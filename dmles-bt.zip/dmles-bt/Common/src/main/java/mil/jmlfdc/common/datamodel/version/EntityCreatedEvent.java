package mil.jmlfdc.common.datamodel.version;


public class EntityCreatedEvent {
    private final Object object;
    
    public EntityCreatedEvent(Object object) {
        this.object = object;
    }
    
    public Object object() {
        return object;
    }
}