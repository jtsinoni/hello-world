package mil.jmlfdc.common.dao;

import mil.jmlfdc.common.datamodel.version.VersionedData;

import java.util.List;

interface IGenericVersionedDao<T extends VersionedData, PK> {

    public List<T> findAll();

    public T findById(PK pk);

    public List<T> query(String queryString);

    public T upsert(T type);

    public void insert(T type);

    public void delete(T type);

    public void deleteById(PK id);

    public T update(T type);

    public T merge(T type);
}
