package mil.jmlfdc.common.business.history;

import com.fasterxml.jackson.core.JsonProcessingException;
import mil.jmlfdc.common.exception.InvalidStateException;
import mil.jmlfdc.common.exception.UserExceptionMessages;
import org.slf4j.Logger;

import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.util.Date;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.interceptor.InvocationContext;

@RequestScoped
public class InvocationContextLogger {

    public static final String GET_LOG_MESSAGE = "getLogMessage";

    @Inject
    private Logger logger;
    @Inject
    private ApplicationHistoryBuilder historyBuilder;
    @Inject
    private ApplicationHistoryLogger historyLogger;
    @Inject
    private MessageFactory logMessageFactory;

    public void logStart(InvocationContext ctx,
            String requestorId, String requestorName) throws JsonProcessingException, InvalidStateException {

        Class<?> targetClass = ctx.getTarget().getClass();
        Method targetMethod = ctx.getMethod();

        historyBuilder.setStartDate(new Date())
                .setApplication(targetClass.getSimpleName())
                .setActionName(targetMethod.getName())
                .setActionType(ActionType.START)
                .setRequestorId(requestorId)
                .setRequestorName(requestorName);

        buildParameters(ctx, targetMethod);

        ApplicationHistory hist = historyBuilder.build();
        //logger.info("Beginning {}.{}", hist.application, hist.actionName);

        historyLogger.logHistory(hist);
    }

    public void logComplete(InvocationContext ctx, String message, ErrorType errorType) {
        // Adding try catch with throw of runtime exception.
        // We always want application logging and we want the request to fail
        // if there is a problem. 
        try {
            if (message == null) {
                Class<?> targetClass = ctx.getTarget().getClass();
                Method targetMethod = ctx.getMethod();
                String endpointName = targetClass.getSimpleName() + "." + targetMethod.getName();
                message = logMessageFactory.getMessage(GET_LOG_MESSAGE, endpointName, ctx);
            }
            ApplicationHistory endhist = historyBuilder
                    .setActionType(ActionType.COMPLETE)
                    .setEndDate(new Date())
                    .setMessage(message)
                    .setErrorType(errorType)
                    .build();

            historyLogger.logHistory(endhist);
            //logger.info("ending {}.{}", endhist.application, endhist.actionName);
        } catch (Exception exception) {
            logger.error("Failed attempting to log completion of business request ", exception);
            throw new RuntimeException(UserExceptionMessages.GENERIC.toString(), exception);
        }
    }

    private void buildParameters(InvocationContext ctx, Method method) {

        Object[] params = ctx.getParameters();
        Class<?>[] types = ctx.getMethod().getParameterTypes();
        Parameter[] methodParams = method.getParameters();

        for (int i = 0; i < params.length; i++) {
            Object param = params[i];
            Class type = types[i];
            String paramName = methodParams[i].getName();
            String inputParameterName = String.format("%s %s", type.getSimpleName(), paramName);
            historyBuilder.addInputParameter(inputParameterName, param);
        }

    }
}
