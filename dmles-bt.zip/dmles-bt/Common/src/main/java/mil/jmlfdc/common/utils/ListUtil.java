package mil.jmlfdc.common.utils;

import javax.enterprise.context.ApplicationScoped;
import java.util.ArrayList;
import java.util.List;

@ApplicationScoped
public class ListUtil {

    public static <T> T getObjectFromList(int index, List<T> dataList){
        T returnObj = null;
        if(!isEmpty(dataList)){
            returnObj = dataList.get(index);
        }
        return returnObj;
    }

    public <T> List<T> getUpdatedItems(
            List<T> list1, 
            List<T> list2) {
        
        List<T> toUpdate = new ArrayList<>();
        
        if (list1 != null && list2 != null) {
            for (T list2Item : list2) {
                int index = list1.indexOf(list2Item);
                if (index >= 0) {
                    T list1Item = list1.get(index);
                    if (list1Item.hashCode() != list2Item.hashCode()) {
                        toUpdate.add(list2Item);
                    }
                }
            }
        }
        return toUpdate;
    }

    public <T> List<T> updateItems(List<T> originalList, 
            List<T> itemsToUpdate) {
        
        if (itemsToUpdate != null && !itemsToUpdate.isEmpty()) {
            if (originalList != null && itemsToUpdate != null) {
                for (T perm : itemsToUpdate) {
                    int index = originalList.indexOf(perm);
                    originalList.set(index, perm);
                }
            }
        }
        return originalList;
    }
    
    public <T> List<T> subtractList(
            List<T> removeFrom,
            List<T> items) {
        
        List<T> removeRoles;
        if (removeFrom != null && items != null) {
            removeRoles = new ArrayList<>(removeFrom);
            List<T> itemRoles = new ArrayList<>(items);

            removeRoles.removeAll(itemRoles);
        } else {
            removeRoles = new ArrayList<>();
        }
        return removeRoles;

    }

    public <T> List<T> merge(List<T> original,
            List<T> changedList) {
        
        List<T> itemsToUpdate = getUpdatedItems(original,
                    changedList);
        
        original = updateItems(original, itemsToUpdate);
        
        List<T> itemsToAdd = subtractList(
                changedList,
                original);
        
        original.addAll(itemsToAdd);
                
        List<T> itemsToRemove = subtractList(
                original,
                changedList);
        
        original.removeAll(itemsToRemove);
        
        return original;
    }

    public static boolean isEmpty(List<?> list) {
        boolean val = (list == null || list.isEmpty());
        
        return val;
    }
}
