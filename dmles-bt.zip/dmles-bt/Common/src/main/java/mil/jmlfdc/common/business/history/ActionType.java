
package mil.jmlfdc.common.business.history;

public enum ActionType {
    START, COMPLETE, ERROR;
}
