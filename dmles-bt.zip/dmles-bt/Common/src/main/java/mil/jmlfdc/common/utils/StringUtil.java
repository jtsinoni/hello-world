package mil.jmlfdc.common.utils;

import java.util.EmptyStackException;
import javax.ejb.Stateless;
import javax.inject.Inject;
import org.slf4j.Logger;

@Stateless
public class StringUtil {
    
    @Inject
    private Logger logger;     
    
    public Double convertStringToDouble(String doubleS){
        Double retDouble = null;
        try{
            retDouble = new Double(doubleS);
        }catch(Exception ex){
            logger.error("Error converting string to double: " + ex.getMessage());
            // TODO: Throw user friendly error
            throw new EmptyStackException();            
        }          
        
        return retDouble;
    }    
    
    public Float convertStringToFloat(String floatS){
        Float retFloat = null;
        try{
            retFloat = new Float(floatS);
        }catch(Exception ex){
            logger.error("Error converting string to float: " + ex.getMessage());
            // TODO: Throw user friendly error
            throw new EmptyStackException();            
        }          
        
        return retFloat;
    }
    
    public Integer convertstringToInteger(String intS){
        Integer retInt = null;
        try{
            retInt = Integer.parseInt(intS);
        }catch(Exception ex){
            logger.error("Error converting string to integer: " + ex.getMessage());
            // TODO: Throw user friendly error
            throw new EmptyStackException();            
        }        
        
        return retInt;
    }    
    
    public static boolean isEmptyOrNull(String val){
        boolean isEmpty = false;
        
        if(val == null || val.isEmpty()){
            isEmpty = true;
        }
        
        return isEmpty;
    }
    
    public static String getFullName(String first, String last){
        return first + " " + last;
    }
    
}