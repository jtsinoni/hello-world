package mil.jmlfdc.common.datamodel;

import com.fasterxml.jackson.annotation.JsonFormat;
import mil.jmlfdc.common.constants.DateAndTime;

import java.util.Date;

public class FileData {

    public String fileId;
    public String uploadedFileName;
    public Date uploadDateTime;
    public  String uploadedBy;
    public long fileSize;

}
