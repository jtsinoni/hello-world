package mil.jmlfdc.common.datamodel.version;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.context.spi.CreationalContext;
import javax.enterprise.inject.spi.Bean;
import javax.enterprise.inject.spi.BeanManager;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import mil.jmlfdc.common.exception.ConfigurationException;

@ApplicationScoped
public class BeanFactory {

    public BeanManager getBeanManager() throws ConfigurationException {

        BeanManager beanm;
        try {
            InitialContext initialContext = new InitialContext();
            beanm = (BeanManager) initialContext.lookup("java:comp/BeanManager");
        } catch (NamingException exception) {
            throw new ConfigurationException("BeanManager not found ", exception );
        }
        return beanm;
    }

    public <T> T getBean(Class<?> beanClass) throws ConfigurationException {
        BeanManager bm = getBeanManager();
        Bean<T> bean = (Bean<T>) bm.getBeans(beanClass).iterator().next();

        CreationalContext<T> ctx = bm.createCreationalContext(bean);
        T beanInstance = (T) bm.getReference(bean, beanClass, ctx);
        return beanInstance;
    }

}
