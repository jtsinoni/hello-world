package mil.jmlfdc.common.datamodel.version;

import mil.jmlfdc.common.exception.ConfigurationException;
import mil.jmlfdc.common.utils.FileUtil;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class ConverterFactory {

    private final BeanFactory beanFactory = new BeanFactory();
    private Map<String, List<DmlesDataConverter>> map = new ConcurrentHashMap<>();
    

    public List<DmlesDataConverter> getConverters(String className) throws Exception {
        List<DmlesDataConverter> retval;
        if (map.containsKey(className)) {
            retval = map.get(className);
        } else {
            retval = loadConverters(className);
            map.put(className, retval);
        }
        return retval;
    }

    private synchronized List<DmlesDataConverter> loadConverters(String className) throws IOException,
            ClassNotFoundException, NoSuchMethodException, InstantiationException,
            IllegalAccessException, IllegalArgumentException, InvocationTargetException, 
            ConfigurationException {

        List<DmlesDataConverter> result = map.get(className);
        if (result == null) {
            result = new ArrayList<>();
            String configName = String.format("converters/%s.txt", className);

            List<String> converterClassNames = FileUtil.getClasspathFileLines(configName);

            for (String converterClassName : converterClassNames) {
                Class<?> clazz = Class.forName(converterClassName);
                DmlesDataConverter converter = beanFactory.getBean(clazz);
                result.add(converter);
            }
        }
        return result;
    }

}
