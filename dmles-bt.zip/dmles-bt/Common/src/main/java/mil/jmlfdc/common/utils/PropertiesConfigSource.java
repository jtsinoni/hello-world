package mil.jmlfdc.common.utils;

import org.apache.deltaspike.core.spi.config.ConfigSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class PropertiesConfigSource implements ConfigSource {
    
    private static final Logger logger = LoggerFactory.getLogger(PropertiesConfigSource.class);
    private CommonPropertyUtils commonPropertyUtils;
	
	// This config resource gets loaded first, if it needs to be loaded last specify a high ordinal number i.e. 2000
	// By loading first, other config resources can override the properties
    private final static int ordinal = 0;
    
    private Map<String, String> properties;
    
    public PropertiesConfigSource() { 
        commonPropertyUtils = new CommonPropertyUtils();
        commonPropertyUtils.init();
        init();
    }
    
    @PostConstruct
    public void init() {
    	properties = commonPropertyUtils.getPropertiesAsMap();
    }
    
    @Override
    public int getOrdinal() {
        return ordinal;
    }

    @Override
    public String getPropertyValue(String key) {
    	return properties.get(key);
    }

    @Override
    public String getConfigName() {
        return "morphia.properties";
    }

    @Override
    public boolean isScannable() {
        return true;
    }

    @Override
    public Map<String, String> getProperties() {
    	logger.debug("Getting properties: {}", properties);
        return properties;
    }
}
