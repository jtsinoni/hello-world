package mil.jmlfdc.common.utils;

import org.apache.deltaspike.core.spi.config.ConfigSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class CommonPropertyUtils implements ConfigSource {

    private static final Logger logger = LoggerFactory.getLogger(CommonPropertyUtils.class);

    private Properties properties = new Properties();
    private CommonPropertyUtils instance = null;

    public CommonPropertyUtils() {
    }

    @PostConstruct
    public void init() {
        initPropertyFile("morphia.properties");
    }

    /**
     * Gets a value from a property file
     *
     * @param key
     * @return
     */
    public String getProperty(String key) {
        return properties.getProperty(key);
    }

    public void setPropertyFile(String propertyFile) {
        initPropertyFile(propertyFile);
    }

    private void initPropertyFile(String propertyFile) {
        InputStream resourceAsStream = CommonPropertyUtils.class.getClassLoader().getResourceAsStream(propertyFile);
        try {
            Properties props = new Properties();
            props.load(resourceAsStream);
            for (Map.Entry<Object,Object> entry : props.entrySet()) {
                properties.putIfAbsent(entry.getKey(), entry.getValue());
            }
            //properties.load(resourceAsStream);
        } catch (IOException e) {
            logger.error(e.getMessage());
        }
    }

    /**
     * @return properties as a Map
     */
    public Map<String, String> getPropertiesAsMap() {

        Map<String, String> map = new HashMap<>();
        for (String key : properties.stringPropertyNames()) {
            map.put(key, properties.getProperty(key));
            logger.info("key: {} value: {}", key, properties.getProperty(key));
        }
        return map;
    }

    @Override
    public int getOrdinal() {
        return 100;
    }

    @Override
    public Map<String, String> getProperties() {
        return getPropertiesAsMap();
    }

    @Override
    public String getPropertyValue(String string) {
        return getProperty(string);
    }

    @Override
    public String getConfigName() {
        return "CommonPropertyUtils";
    }

    @Override
    public boolean isScannable() {
        return true;
    }
}
