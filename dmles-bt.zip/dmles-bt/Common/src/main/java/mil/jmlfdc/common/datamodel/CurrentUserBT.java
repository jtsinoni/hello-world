package mil.jmlfdc.common.datamodel;

import javax.enterprise.context.RequestScoped;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@RequestScoped
public class CurrentUserBT {

//    private Date requestStart = new Date();
    private String profileId = null;
    private String pkiDn = null;
    private String firstName = null;
    private String lastName = null;
    private String serviceCode = null;
    private List<String> effectiveEndpoints;
    private UserType userType;
    //private String userType;
    private String appProfileType;
    private String dodaac;
    private String regionCode;
    private String token;
    private String realPropertyId;
    private Date lockedDate;
    private Date unlockedDate;
    private String reason;
    private Date updatedDate;
    private String updatedBy;
    private Boolean _isDeleted = Boolean.FALSE;
    private Date deletedDate;
    private String userProfileStatus;
    private Date profileExpirationDate;
    private Date profileSuspensionDate;

    public String getRealPropertyId() {
        return realPropertyId;
    }

    public void setRealPropertyId(String realPropertyId) {
        this.realPropertyId = realPropertyId;
    }

//    public Date getRequestStart() {
//        return requestStart;
//    }
//
//    public void setRequestStart(Date requestStart) {
//        this.requestStart = requestStart;
//    }

    public String getProfileId() {
        return profileId;
    }

    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }

    public String getPkiDn() {
        return pkiDn;
    }

    public void setPkiDn(String pkiDn) {
        this.pkiDn = pkiDn;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    
    public List<String> getEffectiveEndpoints() {
        if (effectiveEndpoints == null) {
            effectiveEndpoints = new ArrayList<>();
        }
        return effectiveEndpoints;
    }

    public void setEffectiveEndpoints(List<String> effectiveEndpoints) {
        this.effectiveEndpoints = effectiveEndpoints;
    }

    public String getServiceCode() {
        return serviceCode;
    }

    public void setServiceCode(String serviceCode) {
        this.serviceCode = serviceCode;
    }

    public UserType getUserType() {
        return userType;
    }

    public void setUserType(UserType userType) {
        this.userType = userType;
    }

    /*public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }*/

    public String getDodaac() {
        return dodaac;
    }

    public void setDodaac(String dodaac) {
        this.dodaac = dodaac;
    }

    public String getRegionCode() {
        return regionCode;
    }

    public void setRegionCode(String regionCode) {
        this.regionCode = regionCode;
    }

    public String getFullName() {
        return String.format("%s, %s", this.lastName, this.firstName);
    }

    public String getAppProfileType() { return appProfileType; }

    public void setAppProfileType(String appProfileType) {
        this.appProfileType = appProfileType;
    }
    
    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public Date getLockedDate() { return lockedDate; }

    public void setLockedDate(Date lockedDate) { this.lockedDate = lockedDate; }

    public Date getUnlockedDate() { return unlockedDate; }

    public void setUnlockedDate(Date unlockedDate) { this.unlockedDate = unlockedDate; }

    public String getReason() { return reason; }

    public void setReason(String reason) { this.reason = reason; }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Boolean get_isDeleted() { return _isDeleted; }

    public void set_isDeleted(Boolean _isDeleted) { this._isDeleted = _isDeleted; }

    public Date getDeletedDate() { return deletedDate; }

    public void setDeletedDate(Date deletedDate) { this.deletedDate = deletedDate; }

    public String getUserProfileStatus() { return userProfileStatus; }

    public void setUserProfileStatus(String userProfileStatus) { this.userProfileStatus = userProfileStatus; }

    public Date getProfileExpirationDate() { return profileExpirationDate; }

    public void setProfileExpirationDate(Date profileExpirationDate) { this.profileExpirationDate = profileExpirationDate; }

    public Date getProfileSuspensionDate() { return profileSuspensionDate; }

    public void setProfileSuspensionDate(Date profileSuspensionDate) { this.profileSuspensionDate = profileSuspensionDate; }
}
