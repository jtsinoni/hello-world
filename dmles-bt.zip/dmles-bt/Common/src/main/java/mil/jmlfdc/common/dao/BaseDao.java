package mil.jmlfdc.common.dao;

import mil.jmlfdc.common.datamodel.MorphiaEntity;
import org.bson.types.ObjectId;
import org.mongodb.morphia.Datastore;
import org.mongodb.morphia.query.Query;
import org.mongodb.morphia.query.UpdateOperations;
import org.mongodb.morphia.query.UpdateResults;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.ws.rs.NotFoundException;

public abstract class BaseDao<T extends MorphiaEntity, PK> implements IGenericDao<T, PK> {
    
    @Inject
    private Logger logger;

    @Inject
    private DataStore datastore;
    
    protected final Class<T> classType;
    protected final String className;
    
    public BaseDao(Class<T> persistentClass) {
        classType = persistentClass;
        className = classType.getSimpleName();
    }
    
    @PostConstruct
    public void postConstruct() {
        logConnectionProperties();
    }
    
    private Logger getLogger() {
        if (logger == null) {
            logger = LoggerFactory.getLogger(BaseDao.class);
        }
        return logger;
    }
    public BaseDao(Class<T> persistentClass, DataStore datastore) {
        classType = persistentClass;
        className = classType.getSimpleName();
        this.datastore = datastore;
    }

    @Override
    public T upsert(T t) {
        T retval = null;
        if (t.getId() == null) {
            getLogger().info("Calling insert");
           // retval = t;
            insert(t);
        } else {
            getLogger().info("Calling update");
            t = update(t);
        }
        //moved retval outside so that update will also return retval properly
        retval = t;
        return retval;
    }

    @Override
    public void insert( T t) {
        getDatastore().save(t);
    }

    @Override
    public void delete(T t) {
    	getDatastore().delete(t);
    }

    @Override
    public void deleteById(PK id) {
        T item = findById(id);
        if (item != null) {
            delete(item);
        }
    }

    @Override
    public T update(T t) {
        getDatastore().save(t);
        return t;
    }

    @Override
    public Integer update(Query<T> query, UpdateOperations<T> ops) {
        UpdateResults results = getDatastore().update(query, ops);
        return results.getUpdatedCount();
    }

    @Override
    public T merge(T t) {
        getDatastore().merge(t);
        return t;
    }

    @Override
    public List<T> findAll() {
        Query<T> query = getDatastore().createQuery(classType);
        List<T> results = query.asList();
        return results;
    }

    public long countAll() {
        Query<T> query = getDatastore().createQuery(classType);
        long results = query.count();
        return results;
    }
   

    @Override
    public T findById(PK id) {
        String sid = id.toString();
        
        if (!ObjectId.isValid(sid)) {
            throw new NotFoundException();
        }
        ObjectId oid = new ObjectId(sid);
        
        return getDatastore().find(classType).field("_id").equal(oid).get();

        //return getDatastore().get(classType, id);
    }

    @Override
    public List<T> query(String queryString) {
        Query<T> query = getDatastore().createQuery(classType);
        List<MorphiaFieldFilter> fieldFilters = MorphiaFieldFilter.Parse(queryString);

        fieldFilters.forEach(filter -> {
            query.field(filter.fieldName).equal(filter.fieldValue);
        });

        List<T> results = query.asList();
        return results;
    }

    public List<T> query(Map<String, ?> fieldFilter) {
        Query<T> query = getDatastore().createQuery(classType);
        fieldFilter.forEach((key, value) -> {
            query.field(key).equal(value);
        });

        return query.asList();
    }

    public UpdateOperations<T> getDatabaseOperation() {
        return getDatastore().createUpdateOperations(classType);
    }

    private static class MorphiaFieldFilter {

        private static List<MorphiaFieldFilter> Parse(String queryString) {
            List<MorphiaFieldFilter> filterList = new ArrayList<>();

            List<String> filters = new ArrayList<String>(Arrays.asList(queryString.split("&")));

            filters.forEach(filter -> {
                String[] parts = filter.split("=");

                MorphiaFieldFilter newFilter = new MorphiaFieldFilter();
                newFilter.fieldName = parts[0];
                newFilter.fieldValue = parts[1];

                filterList.add(newFilter);
            });

            return filterList;
        }

        public String fieldName;
        public Object fieldValue;

        public MorphiaFieldFilter() {
        }
    }

    protected Datastore getDatastore() {
    	return datastore.getMorphiaDataStore();
    }
    
    protected void setDatastore(DataStore datastore) {
        this.datastore = datastore;
    }

    protected Query<T> getQuery() {
        return getDatastore().createQuery(classType);
    }

    protected Query<T> getQuery(Class<T> persistentClass) {
        return getDatastore().createQuery(persistentClass);
    }

    public void logConnectionProperties() {
        getLogger().debug(datastore.getConnectionProperties());
    }
}
