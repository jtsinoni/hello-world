package mil.jmlfdc.common.datamodel;

import org.bson.types.ObjectId;
import org.mongodb.morphia.annotations.Id;

import mil.jmlfdc.common.utils.StringUtil;

public class MorphiaEntity {

    @Id
    private ObjectId id;

    public String getId() {
        return (id == null) ? null : id.toString();
    }

    public void setId(String id) {
        if (StringUtil.isBlankOrNull(id)) {
            this.id = new ObjectId();
        } else {
            this.id = new ObjectId(id);
        }
    }

    public void setObjectId(ObjectId id) {
        this.id = id;
    }
}
