package mil.jmlfdc.common.business.history;

import mil.jmlfdc.common.cache.EndpointCache;
import org.slf4j.Logger;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.interceptor.InvocationContext;

@ApplicationScoped
public class MessageFactory {
    
    @Inject
    private EndpointCache endpointCache;
    @Inject
    private Logger logger;
    @Inject
    private MessageParser messageParser;

    public String getMessage(String endpointMethodName, String endpointName, InvocationContext ctx) {
        String message = null;
        try {
            String logMessage = endpointCache.getCachedValue(endpointName, endpointMethodName);
            
            Object[] parameters = ctx.getParameters();
            message = messageParser.build(logMessage, parameters);

        } catch (Exception ignoreException) {
            // log the string format message but ignore
            logger.warn("Formatting of message for " + endpointName
                    + " failed. Mesage = " + ignoreException.getMessage());
        }
        return message;
    }
    
}
