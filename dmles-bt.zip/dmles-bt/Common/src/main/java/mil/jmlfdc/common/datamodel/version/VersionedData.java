package mil.jmlfdc.common.datamodel.version;

import com.mongodb.DBObject;
import mil.jmlfdc.common.datamodel.MorphiaEntity;
import mil.jmlfdc.common.exception.ConfigurationException;
import org.mongodb.morphia.annotations.PostLoad;
import org.mongodb.morphia.annotations.PreLoad;
import org.mongodb.morphia.annotations.Transient;

import java.util.List;

public abstract class VersionedData extends MorphiaEntity {

    public abstract Integer getCurrentVersion();

    private static final BeanFactory BEAN_FACTORY = new BeanFactory();
    private static final ConverterFactory CONVERTER_FACTORY = new ConverterFactory();
    @Transient
    private boolean needToSave = false;
    private DataVersion dataVersion;
    
    @PostLoad
    public void postLoad() throws ConfigurationException {
        if (needToSave) {
            needToSave = false;
            EventPublisher publisher = BEAN_FACTORY.getBean(EventPublisher.class);
            publisher.publishEvent(this);
        }
    }
    
    @PreLoad
    public void preLoad(DBObject dbObj) throws Exception {
        Integer currentVersion = getCurrentVersion();
        Object versionParentObj = dbObj.get(DmlesDataConverter.VERSION);
        Object instanceVersionObj = null;
        if (versionParentObj != null) {
            instanceVersionObj = ((DBObject) versionParentObj).get(DmlesDataConverter.VERSION_NUMBER);
        }
        Integer instanceVersion;
        if (instanceVersionObj == null) {
            instanceVersion = 0;
        } else {
            instanceVersion = new Integer(instanceVersionObj.toString());
        }
        if (currentVersion.compareTo(instanceVersion) != 0) {
            needToSave = true;
            convertDataObject(instanceVersion, currentVersion, dbObj);
        }
    }
    
    public void convertDataObject(Integer version, Integer currentVersion, DBObject dbObj) 
            throws Exception {
        
        String className = this.getClass().getSimpleName();
        
        List<DmlesDataConverter> convertersRef = CONVERTER_FACTORY.getConverters(className);

        for (DmlesDataConverter converter : convertersRef) {
            version = converter.convert(version, currentVersion, dbObj);
        }

    }
}
