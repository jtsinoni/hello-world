package mil.jmlfdc.common.business.history;

import dmles.common.general.logging.BusinessTierLog;
import dmles.common.general.logging.Logger;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.Date;
import javax.enterprise.context.Dependent;
import javax.inject.Inject;

@Dependent
public class ApplicationHistoryLogger {

    @Inject
    @BusinessTierLog
    private Logger logger;

    public ApplicationHistoryLogger() {
    }

    public ApplicationHistoryLogger(Logger logger) {
        this.logger = logger;
    }

    public void logHistory(ApplicationHistory appHist) throws JsonProcessingException {

        appHist.threadId = Thread.currentThread().getId();
        appHist.logTime = new Date();
        logger.warn(getOutputString(appHist));

    }

        protected final String getOutputString(ApplicationHistory appHist) throws JsonProcessingException {
        ObjectMapper jmapper = new ObjectMapper();
        String output = jmapper.writeValueAsString(appHist);
        return output;
    }

//    private Logger getLogger() {
//        if (logger == null) {
//            logger = LoggerFactory.getLogger(ApplicationHistoryLogger.class);
//        }
//        return logger;
//    }
}
