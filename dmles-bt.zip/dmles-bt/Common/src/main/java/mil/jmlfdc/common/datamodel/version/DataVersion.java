package mil.jmlfdc.common.datamodel.version;

import java.util.Date;


public class DataVersion {

    private String versionNumber;
    private Date updateDate;

    public String getVersionNumber() {
        return versionNumber;
    }

    public void setVersionNumber(String versionNumber) {
        this.versionNumber = versionNumber;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }
    
}
