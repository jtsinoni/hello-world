package mil.jmlfdc.common.dao;

import mil.jmlfdc.common.datamodel.version.EntityCreatedEvent;
import mil.jmlfdc.common.datamodel.version.VersionedData;
import org.slf4j.Logger;

import javax.enterprise.event.Observes;
import javax.inject.Inject;

public abstract class VersionedBaseDao<T extends VersionedData, PK>
        extends BaseDao<T, PK>
        implements IGenericVersionedDao<T, PK> {

    @Inject
    private Logger logger;

    public VersionedBaseDao(Class<T> persistentClass) {
        super(persistentClass);
    }

    public VersionedBaseDao(Class<T> persistentClass, DataStore datastore) {
        super(persistentClass, datastore);
    }

    public void saveVersionedData(
            @Observes EntityCreatedEvent event) {

        T item = (T) event.object();
        this.update(item);
    }
}
