package mil.jmlfdc.common.datamodel.version;

import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;

import java.util.Date;
import java.util.Map;

public abstract class DmlesDataConverter {

    public static final String VERSION = "dataVersion";
    public static final String VERSION_NUMBER = "versionNumber";
    public static final String UPDATE_DATE = "updateDate";

    public Integer convert(Integer version, Integer currentVersion, DBObject object) {
        Integer convertVersion = getConvertVersion();
        Integer retVersion = version;
        if (currentVersion <= convertVersion && version == convertVersion - 1) {

            DBObject versionObj = new BasicDBObject();
            versionObj.put(VERSION_NUMBER, currentVersion);
            versionObj.put(UPDATE_DATE, new Date());
            object.put(VERSION, versionObj);

            convertObject(object);
            retVersion = convertVersion;
        }
        return retVersion;
    }

    public abstract Integer getConvertVersion();

    public abstract void convertObject(DBObject object);

}
