package mil.jmlfdc.common.utils;

import java.sql.Timestamp;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.Calendar;
import java.util.Date;

public class DateUtil {

    public static Timestamp getCurrentUTCTimestamp() {
        ZonedDateTime utc = ZonedDateTime.now(ZoneOffset.UTC);
        Date date = Date.from(utc.toInstant());
        return new Timestamp(date.getTime());
    }
    
    public static Date getCurrentUTCDate() {
        ZonedDateTime utc = ZonedDateTime.now(ZoneOffset.UTC);
        return Date.from(utc.toInstant());
    }

    /*
    dateVar: Date to be manipulated
    calendarType: Calendar.YEAR, Calendar.MONTH, Calendar.DATE, Calendar.HOUR, Calendar.MINUTE, Calendar.SECOND
    i: amount to add or subtract from the date
     */
    public static Date manipulateDate(Date dateVar, int calendarType, int i){
        Calendar c = Calendar.getInstance();
        c.setTime(dateVar);
        c.add(calendarType, i);
        return c.getTime();
    }
}
