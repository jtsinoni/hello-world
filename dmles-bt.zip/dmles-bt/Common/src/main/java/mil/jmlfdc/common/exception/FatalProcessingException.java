package mil.jmlfdc.common.exception;

public class FatalProcessingException extends RuntimeException {

    public FatalProcessingException(String message) {
        super(message);
    }

    public FatalProcessingException(String message, Throwable cause) {
        super(message, cause);
    }

}
