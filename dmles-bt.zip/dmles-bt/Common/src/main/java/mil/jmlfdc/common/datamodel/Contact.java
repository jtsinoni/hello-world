package mil.jmlfdc.common.datamodel;

public class Contact {
    public String firstName;
    public String lastName;
    public String title;
    public String mobilePhone;
    public String workPhone;
    public String email;
    public String website;

}
