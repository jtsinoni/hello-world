package mil.jmlfdc.common.datamodel;

public enum UserType {
    
    GLOBAL, SERVICE, SERVICEREGION, SITE;
    
}
