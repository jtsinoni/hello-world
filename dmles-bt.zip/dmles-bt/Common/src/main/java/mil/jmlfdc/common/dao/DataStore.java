package mil.jmlfdc.common.dao;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;

import org.apache.deltaspike.core.api.config.ConfigProperty;
import org.mongodb.morphia.Datastore;
import org.mongodb.morphia.Morphia;
import org.slf4j.Logger;

import java.net.UnknownHostException;
import javax.annotation.PostConstruct;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import org.slf4j.LoggerFactory;


@ApplicationScoped
public class DataStore {

    private static final String LOG_FORMAT = "DB Hosts: %s, DB Replica-Set: %s, Database: %s";
    private Datastore datastore;
    
    @Inject
    private Logger logger;
    
    @Inject
    @ConfigProperty(name = "mapPackage")
    private String mapPackage;
    
    @Inject
    @ConfigProperty(name = "database")
    private String database;
    
    @Inject
    @ConfigProperty(name = "mongoDbHosts")
    private String mongoDbHosts;  
    
    @Inject
    @ConfigProperty(name = "mongoDbRepSet")
    private String mongoDbRepSet;     

    public DataStore() {
    }
    
    @PostConstruct
    public void log() {
        getLogger().info(String.format(LOG_FORMAT, mongoDbHosts, mongoDbRepSet, database));
    }
    
    public DataStore(String mapPackage, String database, String host, String port, String mongoDbHosts, String mongoDbRepSet) {
        this.mapPackage = mapPackage;
        this.database = database;
        this.mongoDbHosts = mongoDbHosts;
        this.mongoDbRepSet = mongoDbRepSet;
    }

    public Datastore getMorphiaDataStore() {
        if (datastore == null) {
            try {
                final Morphia morphia = new Morphia();
                morphia.mapPackage(mapPackage);

                String dbUri = buildDbUri();
                
                MongoClient client = new MongoClient(new MongoClientURI(dbUri));
                datastore = morphia.createDatastore(client, database);
                datastore.ensureIndexes();

                getLogger().debug("Hosts: {}, Replica-Set: {}, Database: {}", mongoDbHosts, mongoDbRepSet, database);
            } catch (UnknownHostException ex) {
                getLogger().error("{}", ex);
            }
        }
        return datastore;
    }
    
    private Logger getLogger() {
        if (logger == null) {
            logger = LoggerFactory.getLogger(DataStore.class);
        }
        return logger;
    }
    
    public String getConnectionProperties() {
        return String.format("package: %s, database: %s, hosts: %s, replica-set: %s", mapPackage, database, mongoDbHosts, mongoDbRepSet);
    }

    private String buildDbUri() {
        StringBuilder sb = new StringBuilder();
        sb.append("mongodb://");
        sb.append(mongoDbHosts);
        sb.append("/");
        
        if(null != mongoDbRepSet && !mongoDbRepSet.isEmpty()){
            sb.append("?replicaSet=");   
            sb.append(mongoDbRepSet);
        }
        
        getLogger().info("DataStore MongoDB URI: {}", sb.toString());
        return sb.toString();
    }
}
