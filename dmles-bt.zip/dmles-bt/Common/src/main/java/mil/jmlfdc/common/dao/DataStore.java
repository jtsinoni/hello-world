package mil.jmlfdc.common.dao;

import com.mongodb.MongoClient;

import org.apache.deltaspike.core.api.config.ConfigProperty;
import org.mongodb.morphia.Datastore;
import org.mongodb.morphia.Morphia;
import org.slf4j.Logger;

import java.net.UnknownHostException;
import javax.annotation.PostConstruct;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import org.slf4j.LoggerFactory;


@ApplicationScoped
public class DataStore {

    private static final String LOG_FORMAT = "DB connection %s:%s - collection - %s ";
    
    @Inject
    private Logger logger;
    @Inject
    @ConfigProperty(name = "mapPackage")
    private String mapPackage;
    @Inject
    @ConfigProperty(name = "database")
    private String database;
    @Inject
    @ConfigProperty(name = "host")
    private String host;
    @Inject
    @ConfigProperty(name = "port")
    private String port;
    
    private Datastore datastore;

    public DataStore() {
    }
    
    @PostConstruct
    public void log() {
        getLogger().info(String.format(LOG_FORMAT, host, port, database));
    }
    
    public DataStore(String mapPackage, String database, String host,
            String port) {
        this.mapPackage = mapPackage;
        this.database = database;
        this.host = host;
        this.port = port;
    }

    public Datastore getMorphiaDataStore() {
        if (datastore == null) {
            try {
                final Morphia morphia = new Morphia();
                morphia.mapPackage(mapPackage);

                datastore = morphia.createDatastore(new MongoClient(host, Integer.parseInt(port)), database);
//                datastore.ensureIndexes();

                getLogger().debug("Host: {}, Database: {}, Port: {}", host, database, port);
            } catch (UnknownHostException ex) {
                getLogger().error("{}", ex);
            }
        }
        return datastore;
    }
    
    private Logger getLogger() {
        if (logger == null) {
            logger = LoggerFactory.getLogger(DataStore.class);
        }
        return logger;
    }
    public String getConnectionProperties() {
        return String.format("mapPackage: %s, database: %s, host: %s, port: %s",
                mapPackage, database, host, port);
    }
}
