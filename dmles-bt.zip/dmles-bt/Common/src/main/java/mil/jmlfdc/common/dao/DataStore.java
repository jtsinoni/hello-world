package mil.jmlfdc.common.dao;

import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;
import org.apache.deltaspike.core.api.config.ConfigProperty;
import org.mongodb.morphia.Datastore;
import org.mongodb.morphia.Morphia;
import org.slf4j.Logger;

import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.annotation.PostConstruct;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import mil.jmlfdc.common.utils.StringUtil;
import org.slf4j.LoggerFactory;

@ApplicationScoped
public class DataStore {

    private static final String LOG_FORMAT = "DB Hosts: %s, DB Replica-Set: %s, Database: %s";
    private Datastore datastore;

    @Inject
    private Logger logger;

    @Inject
    @ConfigProperty(name = "mapPackage")
    private String mapPackage;

    @Inject
    @ConfigProperty(name = "database")
    private String database;

    @Inject
    @ConfigProperty(name = "mongoDbHosts")
    private String mongoDbHosts;

    @Inject
    @ConfigProperty(name = "mongoDbRepSet")
    private String mongoDbRepSet;
    
    @Inject
    @ConfigProperty(name = "mongoUserId")    
    private String mongoUserId;
    
    @Inject
    @ConfigProperty(name = "mongoUserPw")    
    private String mongoUserPw;    

    private String adminDb = "admin";

    public DataStore() {
    }

    @PostConstruct
    public void log() {
        getLogger().info(String.format(LOG_FORMAT, mongoDbHosts, mongoDbRepSet, database));
    }

    public DataStore(String mapPackage, 
            String database, 
            String host, 
            String port, 
            String mongoDbHosts, 
            String mongoDbRepSet,
            String mongoUserId,
            String mongoUserPw) {
        this.mapPackage = mapPackage;
        this.database = database;
        this.mongoDbHosts = mongoDbHosts;
        this.mongoDbRepSet = mongoDbRepSet;
        this.mongoUserId = mongoUserId;
        this.mongoUserPw = mongoUserPw;
    }

    public Datastore getMorphiaDataStore() {
        if (datastore == null) {
            try {

                List<ServerAddress> hosts = getDmlesHosts();

                MongoClient client;
                if (!StringUtil.isEmptyOrNull(mongoUserId) && !StringUtil.isEmptyOrNull(mongoUserPw)) {
                    List<MongoCredential> credentialList = getDmlesCredentials();
                    client = new MongoClient(hosts, credentialList);
                } else {
                    client = new MongoClient(hosts);
                }

                final Morphia morphia = new Morphia();
                morphia.mapPackage(mapPackage);
                datastore = morphia.createDatastore(client, database);
                datastore.ensureIndexes();

                getLogger().debug("Hosts: {}, Replica-Set: {}, Database: {}", mongoDbHosts, mongoDbRepSet, database);
            } catch (UnknownHostException ex) {
                getLogger().error("{}", ex);
            }

        }
        return datastore;
    }

    private Logger getLogger() {
        if (logger == null) {
            logger = LoggerFactory.getLogger(DataStore.class);
        }
        return logger;
    }

    public String getConnectionProperties() {
        return String.format("package: %s, database: %s, hosts: %s, replica-set: %s", mapPackage, database, mongoDbHosts, mongoDbRepSet);
    }

    private List<MongoCredential> getDmlesCredentials() {
        List<MongoCredential> credentialList = new ArrayList<>();

        MongoCredential credential = MongoCredential.createScramSha1Credential(mongoUserId,
                adminDb,
                mongoUserPw.toCharArray());
        credentialList.add(credential);

        return credentialList;
    }

    private List<ServerAddress> getDmlesHosts() throws UnknownHostException {
        List<ServerAddress> hosts = new ArrayList<>();

        List<String> itemss = Arrays.asList(mongoDbHosts.split("\\s*,\\s*"));
        for (String item : itemss) {
            String[] host = item.split(":", 2);
            String hostName = host[0];
            Integer portNumber = Integer.parseInt(host[1]);
            hosts.add(new ServerAddress(hostName, portNumber));
        }

        return hosts;
    }

}
