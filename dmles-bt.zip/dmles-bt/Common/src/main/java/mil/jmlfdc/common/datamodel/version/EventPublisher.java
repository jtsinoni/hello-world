package mil.jmlfdc.common.datamodel.version;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.event.Event;
import javax.inject.Inject;

@ApplicationScoped
public class EventPublisher {

    @Inject
    private Event<EntityCreatedEvent> entityCreatedEvent;

    public void publishEvent(VersionedData objectToPublish) {
        entityCreatedEvent
                .fire(new EntityCreatedEvent(objectToPublish));
    }

}