package mil.jmlfdc.common.rest;

import java.lang.reflect.Method;
import mil.jmlfdc.common.business.history.MessageFactory;
import mil.jmlfdc.common.exception.ApplicationException;
import mil.jmlfdc.common.exception.UserExceptionMessages;
import mil.jmlfdc.common.exception.UserNotFoundException;
import org.apache.commons.lang3.StringUtils;
import org.apache.deltaspike.core.api.config.ConfigProperty;
import org.jboss.resteasy.util.HttpResponseCodes;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Context;

public abstract class RestApiBase {
    
    public static final Integer APP_EXCEPTION = 470;
    public static final String GET_USER_MESSAGE = "getUserMessage";
    
    @Inject
    private Logger logger;
    @Context
    private HttpServletResponse response;
    @Inject
    @ConfigProperty(name = "btdebug")
    private String btdebug;
    @Inject
    private MessageFactory messageFactory;
    
    @AroundInvoke
    public Object aroundRestMethods(InvocationContext ctx) throws Exception {
        Object result = null;
        
        try {
            result = ctx.proceed();
            if (result == null) {
                Class<?> targetClass = ctx.getTarget().getClass();
                Method targetMethod = ctx.getMethod();
                String endpointName = targetClass.getSimpleName() + "." + targetMethod.getName();
                String msg = messageFactory.getMessage(GET_USER_MESSAGE, endpointName, ctx);
                response.getWriter().write(msg);
                //result = msg;
            }
        } catch (UserNotFoundException userEx) {
            response.sendError(HttpResponseCodes.SC_UNAUTHORIZED,
                    userEx.getMessage());
        } catch (ApplicationException appEx) {
            appEx.printStackTrace();
            response.sendError(APP_EXCEPTION, appEx.getMessage());
            logger.error("Method processing failed", appEx);
        } catch (Exception ex) {
            ex.printStackTrace();
            if (! StringUtils.isEmpty(btdebug)) {
                throw ex;
            }
            logger.error("Method processing failed", ex);
            String msg = UserExceptionMessages.GENERIC.toString();
            response.sendError(HttpResponseCodes.SC_INTERNAL_SERVER_ERROR, msg);
        }
        
        return result;
    }
    
    public void setResponse(HttpServletResponse response) {
        this.response = response;
    }
    
    protected void setBtDebug(String btdebug) {
        this.btdebug = btdebug;
    }
}
