package mil.jmlfdc.common.business.history;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class MessageParser {

    private static final String PATTERN = "\\{([\\w\\.]*)\\}*";

    public String build(String logMessage, Object[] parameters) 
            throws NoSuchMethodException, IllegalAccessException, 
            IllegalArgumentException, InvocationTargetException, NoSuchFieldException {
        
        StringBuilder sb = new StringBuilder(logMessage);

        Matcher matcher = Pattern.compile(PATTERN).matcher(logMessage);
        while (matcher.find()) {
            String item = matcher.group();
            // drop leading "{" and trailing "}"
            String trimmedItem = item.substring(1, item.length() - 1);
            String[] itemComponents = trimmedItem.split("\\.");
            String posStr = itemComponents[0];
            Integer position = new Integer(posStr);
            Object object = parameters[position];
            String replacementValue = recurseStringForValue(itemComponents, object);
            Integer replacementPosition = sb.indexOf(item);
            sb.replace(replacementPosition, replacementPosition + item.length(),
                    replacementValue);
        }

        return sb.toString();
    }

    protected String recurseStringForValue(String[] itemComponents, Object object)
            throws NoSuchMethodException, IllegalAccessException,
            IllegalArgumentException, InvocationTargetException, NoSuchFieldException {

        Object lastObject = object;

        for (int i = 1; i < itemComponents.length; i++) {
            String methodOrPropertyName = itemComponents[i];
            if (methodOrPropertyName.startsWith("get")) {
                Method method = lastObject.getClass().getMethod(methodOrPropertyName);
                lastObject = method.invoke(lastObject);
            } else {
                Field field = lastObject.getClass().getDeclaredField(methodOrPropertyName);
                lastObject = field.get(lastObject);
            }
        }
        String retVal;
        if (lastObject == null) {
            retVal = "";
        } else {
            retVal = lastObject.toString();
        }
        return retVal;
    }
}
