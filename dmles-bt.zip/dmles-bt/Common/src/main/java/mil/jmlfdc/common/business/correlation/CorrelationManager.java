package mil.jmlfdc.common.business.correlation;

import mil.jmlfdc.common.utils.Stack;

import java.util.UUID;
import javax.enterprise.context.RequestScoped;

@RequestScoped
public class CorrelationManager {

    private Stack<String> stack = new Stack<>();

    public String start() {
        UUID uuid = UUID.randomUUID();
        String uuidString = uuid.toString();
        stack.push(uuidString);
        return uuidString;
    }

    private String getCorrelationId(int level) {
       return stack.peek(level);
    }

    public String getCurrentCorrelationId() {
        return getCorrelationId(0);
    }

    public String getParentCorrelationId() {
        return getCorrelationId(1);
    }

    public String end() {
        return stack.pop();
    }
}
