package mil.jmlfdc.common.utils;

import org.modelmapper.Converter;
import org.modelmapper.ModelMapper;
import org.modelmapper.PropertyMap;

import java.util.Arrays;
import java.util.List;

import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class ObjectMapper {

    public <T,U> List<T> getList(Class<T[]> clazz, List<U> uList) {
        ModelMapper mapper = getMapper();
        T[] tArray = mapper.map(uList, clazz);
        return Arrays.asList(tArray);
    }

    public <T, U> T getObject(Class<T> clazz, U uObject) {
        
        T returnObject = null;
        
        if (uObject != null) {
            ModelMapper mapper = getMapper();
        
            returnObject = mapper.map(uObject, clazz);
        }
        
        return returnObject;
    }
    
    public <T, U> T getObject(Class<T> clazz, U uObject, PropertyMap<?,?> pmap) {
        
        T returnObject = null;

        if (uObject != null) {
            ModelMapper mapper = getMapper();
            if (pmap != null) {
                mapper.addMappings(pmap);
            }

            returnObject = mapper.map(uObject, clazz);
        }
        return returnObject;
    }
    
    public <T, U> T getObject(Class<T> clazz, U uObject, Converter<?,?> converter) {
        
        T returnObject = null;

        if (uObject != null) {
            ModelMapper mapper = getMapper();
            if (converter != null) {
                mapper.addConverter(converter);
            }

            returnObject = mapper.map(uObject, clazz);
        }
        return returnObject;
    }
    
    public <T, U> T getObject(Class<T> clazz, U uObject, Converter<?,?> converter, PropertyMap<?,?> pmap) {
        
        T returnObject = null;

        if (uObject != null) {
            ModelMapper mapper = getMapper();
            if (converter != null) {
                mapper.addConverter(converter);
            }
            if (pmap != null) {
                mapper.addMappings(pmap);
            }

            returnObject = mapper.map(uObject, clazz);
        }
        return returnObject;
    }
    
    public ModelMapper getMapper() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setFieldMatchingEnabled(true);
        return mapper;
    }

}
