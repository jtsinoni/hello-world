package mil.jmlfdc.common.exception;

public class ObjectNotFoundException extends ApplicationException {

    public ObjectNotFoundException(String message) {
        super(message);
    }

    public ObjectNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }

}
