
package mil.jmlfdc.common.business.history;

public enum ErrorType {
    APPLICATION, SYSTEM;
}
