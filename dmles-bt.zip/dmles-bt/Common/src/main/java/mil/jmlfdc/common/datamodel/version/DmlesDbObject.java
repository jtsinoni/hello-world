package mil.jmlfdc.common.datamodel.version;

import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;

import java.util.Map;

public class DmlesDbObject {

    private DBObject dbo;
    private DBObject fromPathParent;
    private String fromPathLastRef;
    private DBObject toPathParent;
    private String toPathLastRef;

    public DmlesDbObject(DBObject dbObject) {
        dbo = dbObject;
    }

    public DBObject move(String fromRef, String toRef) {
        setFromRef(fromRef);
        setToRef(toRef);
        return move();
    }

    public void moveConvertSingle(String fromRef, String toRef, Map<Object, Object> map) {
        move(fromRef, toRef);
        convert(map);
    }

    public void moveConvertList(String fromRef, String toRef, Map<Object, Object> map) {
        move(fromRef, toRef);
        convertList(map);
    }

    private void setFromRef(String objectRef) {
        fromPathParent = findElementParent(objectRef, false);
        fromPathLastRef = getLastRef(objectRef);

    }

    private void setToRef(String objectRef) {
        toPathParent = findElementParent(objectRef, true);
        toPathLastRef = getLastRef(objectRef);

    }

    private String getLastRef(String objectRef) {
        String[] refs = objectRef.split("/");
        return refs[refs.length - 1];
    }

    private DBObject findElementParent(String objectRef, boolean createIfNull) {
        return findElement(objectRef, createIfNull, 1);
    }

    private DBObject findElement(String objectRef, boolean createIfNull, int parentage) {

        String[] refs = objectRef.split("/");

        DBObject retVal = dbo;
        for (int i = 0; i < refs.length; i++) {
            String ref = refs[i];
            if (i == refs.length - parentage) {
                break;
            } else {
                Object obj = retVal.get(ref);
                DBObject val;
                if (obj == null) {
                    if (createIfNull) {
                        val = new BasicDBObject();
                        retVal.put(ref, val);
                    } else {
                        break;
                    }
                } else {
                    val = (DBObject) retVal.get(ref);
                }
                retVal = val;
            }
        }
        return retVal;
    }


    private void convert(Map<Object, Object> map) {
        Object oldVal = toPathParent.get(toPathLastRef);

        if (oldVal == null) {
            return;
        }

        String oldValString = oldVal.toString();

        if (map.containsKey(oldValString)) {
            Object newVal = map.get(oldValString);
            toPathParent.put(toPathLastRef, newVal);
        }

    }

    private DBObject move() {

        Object fromValue = fromPathParent.get(fromPathLastRef);

        DBObject to = null;

        if (fromValue != null) {

            to = new BasicDBObject(toPathLastRef, fromValue);

            toPathParent.putAll(to);
            fromPathParent.removeField(fromPathLastRef);
        }
        return to;
    }

    private void convertList(Map<Object, Object> map) {

        Object listObj = toPathParent.get(toPathLastRef);

        if (listObj != null) {
            BasicDBList dbList = (BasicDBList) listObj;
            Object[] listArray = dbList.toArray();

            for (Object item : listArray) {
                if (map.containsKey(item)) {
                    int position = dbList.indexOf(item);
                    Object newElementValue = map.get(item);
                    dbList.remove(position);
                    dbList.add(position, newElementValue);
                }
            }
        }

    }
}
