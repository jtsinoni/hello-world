package mil.jmlfdc.common.utils;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Stream;


public class FileUtil {
    
    public static String fullPath(String fileName) {
        URL url = Thread.currentThread().getContextClassLoader().getResource(fileName);
        if (url == null) {
            url = ClassLoader.getSystemResource(fileName);
            if (url == null) {
                url = ClassLoader.getSystemClassLoader().getResource(fileName);
            }
        }
        String val = null;
        if (url != null) {
            val = url.getFile();
        }
        return val;
    }
    
    public static List<String> getClasspathFileLines(String fileName) 
            throws FileNotFoundException, IOException {
        InputStream inStream = Thread.currentThread().getContextClassLoader().getResourceAsStream(fileName);
        if (inStream == null) {
            inStream = Thread.currentThread().getContextClassLoader().getResourceAsStream("/" + fileName);
            throw new FileNotFoundException(fileName);
        }
        return getFileLines(inStream);
    }
    
    public static List<String> getFileLines(InputStream stream) 
            throws FileNotFoundException, IOException {
        List<String> lines = null;
        if (stream != null) {
            lines = new ArrayList<>();
            BufferedReader bufRead = new BufferedReader(new InputStreamReader(stream));
            String line;
             while((line = bufRead.readLine()) != null){
                lines.add(line);
            }
        }
        return lines;
    }
    
}
