package mil.jmlfdc.common.business.history;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.util.Date;
import java.util.Map;


public class ApplicationHistory {
    
    @JsonFormat(shape = JsonFormat.Shape.STRING, 
            pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSX",
            timezone = "America/New_York")
    public Date startDate;
    @JsonFormat(shape = JsonFormat.Shape.STRING, 
            pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSX",
            timezone = "America/New_York")
    public Date endDate;
    public long duration;
    public long threadId;
    public String application;
    public String actionName;
    public ActionType actionType;
    public Map<String, Object> inputParameters;
    public String requestorId;
    public String requestorName;
    public String correlationId;
    public ErrorType errorType;
    public Object result;
    public String message;
    @JsonFormat(shape = JsonFormat.Shape.STRING, 
            pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSX",
            timezone = "America/New_York")
    public Date logTime;
    
}
