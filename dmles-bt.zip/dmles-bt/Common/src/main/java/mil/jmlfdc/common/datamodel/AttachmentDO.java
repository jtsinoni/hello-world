package mil.jmlfdc.common.datamodel;

import java.io.Serializable;
import java.util.Date;


public class AttachmentDO implements Serializable {
    //private static final long serialVersionUID = 1L;

    public String description;
    public FileDataDO fileRef;
    public String section;

  //  public AttachmentItemDO() {}


    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public FileDataDO getFileRef() {
        return fileRef;
    }

    public void setFileRef(FileDataDO fileRef) {
        this.fileRef = fileRef;
    }

    public String getSection() {
        return section;
    }

    public void setSection(String section) {
        this.section = section;
    }
}
