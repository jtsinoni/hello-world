package mil.jmlfdc.common.exception;

public class InvalidStateException extends ApplicationException {

    public InvalidStateException(String message) {
        super(message);
    }

    public InvalidStateException(String message, Throwable cause) {
        super(message, cause);
    }

}
