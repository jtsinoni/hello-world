package mil.jmlfdc.common.business.history;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import mil.jmlfdc.common.exception.InvalidStateException;

import java.util.Date;
import java.util.HashMap;
import javax.enterprise.context.RequestScoped;

@RequestScoped
public class ApplicationHistoryBuilder {
    
    private final ApplicationHistory appHistory;
    
    public ApplicationHistoryBuilder() {
        appHistory = new ApplicationHistory();
        appHistory.startDate = new Date();
        appHistory.inputParameters = new HashMap<String, Object>();
    }
    
    public ApplicationHistoryBuilder setStartDate(Date date) {
        appHistory.startDate = date;
        return this;
    }
    
    public ApplicationHistoryBuilder setApplication(String application) {
        appHistory.application = application;
        return this;
    }
    
    public ApplicationHistoryBuilder addInputParameter(String name, Object inputParam) {
        appHistory.inputParameters.put(name, inputParam);
        return this;
    }
    
    public ApplicationHistoryBuilder setRequestorId(String id) {
        appHistory.requestorId = id;
        return this;
    }

    public ApplicationHistoryBuilder setRequestorName(String requestorName) {
        appHistory.requestorName = requestorName;
        return this;
    }
    
    public ApplicationHistoryBuilder setCorrelationId(String id) {
        appHistory.correlationId = id;
        return this;
    }
    
    public ApplicationHistoryBuilder setErrorType(ErrorType errorType) {
        appHistory.errorType = errorType;
        return this;
    }
    
    public ApplicationHistoryBuilder setActionType(ActionType actionType) {
        appHistory.actionType = actionType;
        return this;
    }
    
    public ApplicationHistoryBuilder setActionName(String actionName) {
        appHistory.actionName = actionName;
        return this;
    }
    
    public ApplicationHistoryBuilder setMessage(String message) {
        appHistory.message = message;
        return this;
    }
    
    public ApplicationHistoryBuilder setEndDate(Date endDate) {
        appHistory.endDate = endDate;
        return this;
    }
    
    public ApplicationHistoryBuilder setResult(String result) {
        appHistory.result = result;
        return this;
    }
    
    public ApplicationHistoryBuilder setResult(Object result) throws JsonProcessingException {
        ObjectMapper jmapper = new ObjectMapper();
        appHistory.result = jmapper.writeValueAsString(result);
        return this;
    }
    
    public ApplicationHistory build() throws InvalidStateException {
        if (appHistory.application == null || appHistory.startDate == null
                || appHistory.requestorId == null || appHistory.requestorName == null
                || appHistory.actionType == null || appHistory.actionName == null
                || appHistory.startDate == null ) {
            throw new InvalidStateException(
              "application, date, requestorId, requestorName, actionType, actionName, "
                      + "and startDate properties must be set");
        }
        if (appHistory.endDate != null) {
            appHistory.duration = appHistory.endDate.getTime() - appHistory.startDate.getTime();
        }
        return appHistory;
    }

}
