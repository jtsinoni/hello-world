package mil.jmlfdc.common.cache;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class EndpointCache {
    private Class<?> cachedClass = null; 
    private final Map<String, Object> objectMap = new HashMap<>();
    
    public <T> void setCachedObject(String key, T value) {
        objectMap.put(key, value);
    }
    
    public <T> T getCachedObject(String key) {
        T result = null;
        
        if (objectMap.containsKey(key)) {
            Object object = objectMap.get(key);
            result = (T) object;
        }
        return result;
    }

    public <T> List<T> getAllCachedObjects() {
        List<T> items = new ArrayList<>();
        Collection<?> values = objectMap.values();
        for (Object value : values) {
            if (value != null) {
                items.add((T) value);
            }
        }
        return items;
    }
    // limited this to no-argument methods for now
    public String getCachedValue(String key, String method) 
            throws NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        Object obj = objectMap.get(key);
        Method objMethod = obj.getClass().getMethod(method);
        Object valueObj = objMethod.invoke(obj);
        return valueObj.toString();
    }
    
    public Class getCachedClass(){
        return cachedClass;
    }
    public void setClass(Class cachedClass) {
        this.cachedClass = cachedClass;
    }
}
