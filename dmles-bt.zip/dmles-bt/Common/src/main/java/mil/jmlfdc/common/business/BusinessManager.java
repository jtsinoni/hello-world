package mil.jmlfdc.common.business;

import javax.enterprise.context.Dependent;
import mil.jmlfdc.common.business.history.ErrorType;
import mil.jmlfdc.common.business.history.InvocationContextLogger;
import mil.jmlfdc.common.exception.ApplicationException;
import mil.jmlfdc.common.exception.UserExceptionMessages;
import mil.jmlfdc.common.exception.UserNotFoundException;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

@Dependent
public abstract class BusinessManager {
        
    @Inject
    private Logger logger;
    @Inject
    private InvocationContextLogger contextLogger;

    @AroundInvoke
    public Object logBusinessMethods(InvocationContext ctx) throws Exception {
        Object result = null;
        
        contextLogger.logStart(ctx, getRequestorId(), getRequestorName());
        
        try {
            result = ctx.proceed();
            contextLogger.logComplete(ctx, null, null);

        } catch (UserNotFoundException userEx) {
            contextLogger.logComplete(ctx, userEx.getMessage(), ErrorType.APPLICATION);
            throw userEx;
        } catch (ApplicationException appEx) {
            //TODO: temporary - remove - problem with logging
            appEx.printStackTrace();
            contextLogger.logComplete(ctx, appEx.getMessage(), ErrorType.APPLICATION);
            logger.error("Method processing failed", appEx);
            throw appEx;
        } catch (Exception ex) {
            contextLogger.logComplete(ctx, ex.getMessage(), ErrorType.SYSTEM);
            //TODO: remove - temporary - having some logging problems
            ex.printStackTrace();
            logger.error("Method processing failed", ex);
            throw new Exception(UserExceptionMessages.GENERIC.toString());
        }
        
        return result;
    }
    
    public abstract String getRequestorId();
    
    public abstract String getRequestorName();
}
