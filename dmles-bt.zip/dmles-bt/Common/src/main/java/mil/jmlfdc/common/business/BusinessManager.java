package mil.jmlfdc.common.business;

import mil.jmlfdc.common.business.correlation.CorrelationManager;
import mil.jmlfdc.common.business.history.ErrorType;
import mil.jmlfdc.common.business.history.InvocationContextLogger;
import mil.jmlfdc.common.business.history.MessageFactory;
import mil.jmlfdc.common.datamodel.CurrentUserBT;
import mil.jmlfdc.common.exception.ApplicationException;
import mil.jmlfdc.common.exception.UserExceptionMessages;
import mil.jmlfdc.common.exception.UserNotFoundException;
import org.slf4j.Logger;

import java.lang.reflect.Method;
import javax.inject.Inject;
import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

public abstract class BusinessManager {

    public static final String GET_LOG_MESSAGE = "getLogMessage";

    @Inject
    private Logger logger;
    @Inject
    private InvocationContextLogger contextLogger;
    @Inject
    private CorrelationManager correlationManager;
    @Inject
    private MessageFactory logMessageFactory;

    @Inject
    protected CurrentUserBT currentUserBt;

    private String getRequestorId() {
        String requestorId = currentUserBt.getProfileId();
        if (requestorId == null) {
            requestorId = "1";
        }
        return requestorId;
    }

    private String getRequestorName() {
        String requestorName = currentUserBt.getFullName();
        if (requestorName == null) {
            requestorName = "RegistrationUser";
        }
        return requestorName;
    }

    @AroundInvoke
    public Object logBusinessMethods(InvocationContext ctx) throws Exception {
        Object result = null;

        correlationManager.start();
        contextLogger.logStart(ctx, getRequestorId(), getRequestorName());
        String message = null;
        ErrorType errorType = null;

        try {
            result = ctx.proceed();
            message = buildSuccessMessage(ctx);

        } catch (UserNotFoundException userEx) {
            message = userEx.getMessage();
            errorType = ErrorType.APPLICATION;
            throw userEx;
        } catch (ApplicationException appEx) {
            message = appEx.getMessage();
            errorType = ErrorType.APPLICATION;
            throw appEx;
        } catch (Exception ex) {
            message = ex.getMessage();
            errorType = ErrorType.APPLICATION;
            throw new Exception(UserExceptionMessages.GENERIC.toString(), ex);
        } finally {
            contextLogger.logComplete(ctx, message, errorType);
            correlationManager.end();
        }

        return result;
    }

//    public abstract String getRequestorId();
//
//    public abstract String getRequestorName();


    private String buildSuccessMessage(InvocationContext ctx) {
        Class<?> targetClass = ctx.getTarget().getClass();
        Method targetMethod = ctx.getMethod();
        String endpointName = targetClass.getSimpleName() + "." + targetMethod.getName();
        String message = logMessageFactory.getMessage(GET_LOG_MESSAGE, endpointName, ctx);
        return message;
    }
}
