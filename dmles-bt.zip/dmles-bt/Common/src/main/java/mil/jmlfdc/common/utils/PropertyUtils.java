package mil.jmlfdc.common.utils;

import org.slf4j.Logger;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

@ApplicationScoped
public class PropertyUtils {

    @Inject
    private Logger logger;

    private Properties properties;
    private PropertyUtils instance = null;

    public PropertyUtils() {
            
    }
    
    @PostConstruct
    public void init() {
        properties = new Properties();
        initPropertyFile("config.properties");
    }
    /**
     * Gets a value from a property file
     *
     * @param key
     * @return
     */
    public String getProperty(String key) {
        return properties.getProperty(key);
    }

    public void setPropertyFile(String propertyFile) {
        initPropertyFile(propertyFile);
    }

    private void initPropertyFile(String propertyFile) {
        InputStream resourceAsStream = PropertyUtils.class.getClassLoader().getResourceAsStream(propertyFile);
        try {
            properties.load(resourceAsStream);
        } catch (IOException e) {
            logger.error(e.getMessage());
        }
    } 
}
