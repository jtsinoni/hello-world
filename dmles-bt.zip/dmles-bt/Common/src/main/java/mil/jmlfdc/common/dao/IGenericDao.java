package mil.jmlfdc.common.dao;

import java.util.List;
import mil.jmlfdc.common.datamodel.MorphiaEntity;

import javax.validation.Valid;

interface IGenericDao<T extends MorphiaEntity, PK> {

    List<T> findAll();

    T findById(PK pk);

    List<T> query(String queryString);

    T upsert(T t);

    void insert(T t);

    void delete(T t);

    void deleteById(PK id);

    T update( T t);

    T merge( T t);
}
