package mil.jmlfdc.common.business;

import dmles.common.general.configuration.ConfigurationManager;
import org.jboss.resteasy.client.jaxrs.ResteasyClient;
import org.jboss.resteasy.client.jaxrs.ResteasyClientBuilder;
import org.jboss.resteasy.client.jaxrs.ResteasyWebTarget;

import javax.annotation.PostConstruct;
import javax.enterprise.context.Dependent;
import javax.inject.Inject;

@Dependent
public abstract class RestClientFactory<T extends Object> {

    @Inject
    private ConfigurationManager configurationManager;

    protected String businessApiUrl;
    
    protected final Class<T> classType;
    private final String serviceName;

    public RestClientFactory(Class<T> classType, String serviceName) {
        this.classType = classType;
        this.serviceName = serviceName;
    }

    @PostConstruct
    public void postConstruct() {
        businessApiUrl = configurationManager.getDmlesAppHost();
    }

    public T createClient() {
        ResteasyWebTarget target = buildTarget();
 
        T client = target.proxy(classType);
        return client;
    }
    
    // TODO: pass in prop and switch between non-secured and secured
    protected ResteasyWebTarget buildTarget() {
        ResteasyClient resteasyClient 
            = new ResteasyClientBuilder().build();
        return resteasyClient.target(getUrl());
    }
    
    private String getUrl() {
        String url = businessApiUrl.trim();
        if (url != null && !url.endsWith("/")) {
            url += "/";
        }
        return url + serviceName; 
    }
}
