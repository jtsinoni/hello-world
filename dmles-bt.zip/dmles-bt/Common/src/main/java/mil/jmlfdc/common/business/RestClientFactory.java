package mil.jmlfdc.common.business;

import org.apache.deltaspike.core.api.config.ConfigProperty;
import org.jboss.resteasy.client.jaxrs.ResteasyClient;
import org.jboss.resteasy.client.jaxrs.ResteasyClientBuilder;
import org.jboss.resteasy.client.jaxrs.ResteasyWebTarget;

import javax.inject.Inject;
 
public abstract class RestClientFactory<T extends Object> {
    
    @Inject
    @ConfigProperty(name = "businessApiUrl")
    protected String businessApiUrl;
    
    protected final Class<T> classType;
    private final String serviceName;
    
    public RestClientFactory(Class<T> classType, String serviceName) {
        this.classType = classType;
        this.serviceName = serviceName;
    }
    
    public T createClient() {
        ResteasyWebTarget target = buildTarget();
 
        T client = target.proxy(classType);
        return client;
    }
    
    // TODO: pass in prop and switch between non-secured and secured
    protected ResteasyWebTarget buildTarget() {
        ResteasyClient resteasyClient 
            = new ResteasyClientBuilder().build();
        return resteasyClient.target(getUrl());
    }
    
    private String getUrl() {
        String url = businessApiUrl.trim();
        if (url != null && !url.endsWith("/")) {
            url += "/";
        }
        return url + serviceName; 
    }
}
