package mil.jmlfdc.common.datamodel;


public class Attachment {
    public String description;
    public FileData fileRef;
    public String section;
}

