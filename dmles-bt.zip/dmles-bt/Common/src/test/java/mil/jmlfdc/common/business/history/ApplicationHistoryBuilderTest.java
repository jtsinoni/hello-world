package mil.jmlfdc.common.business.history;

import static org.junit.Assert.assertNotNull;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import mil.jmlfdc.common.exception.InvalidStateException;
import org.junit.Before;
import org.junit.Test;

import java.util.Date;

public class ApplicationHistoryBuilderTest {
    
    private ApplicationHistoryBuilder hist;
    
    @Before
    public void setUp() {
        hist = new ApplicationHistoryBuilder();
    }

    @Test
    public void testOK() throws InvalidStateException, JsonProcessingException {
        
        ApplicationHistory ahist = hist.addInputParameter("input1","input1")
                .addInputParameter("input2","input2")
                .setActionType(ActionType.START)
                .setApplication("UserManager")
                .setMessage("message")
                .setRequestorId("objectId")
                .setRequestorName("requestorName")
                .setActionName("actionName")
                .setEndDate(new Date())
                .build();
        
        // if an exception is not thrown then we pass
        assertNotNull(ahist);
        ObjectMapper jmapper = new ObjectMapper();
        
        System.out.println(jmapper.writeValueAsString(ahist));
        
    }

    @Test(expected = InvalidStateException.class)
    public void testFailApplication() throws InvalidStateException, JsonProcessingException {
        
        hist
                .setActionType(ActionType.START)
                .setMessage("message")
                .setRequestorId("objectId")
                .setRequestorName("requestorName")
                .setActionName("actionName")
                .setEndDate(new Date())
                .build();
        
    }

    @Test(expected = InvalidStateException.class)
    public void testFailActionType() throws InvalidStateException, JsonProcessingException {
        
        hist
                .setApplication("UserManager")
                .setMessage("message")
                .setRequestorId("objectId")
                .setRequestorName("requestorName")
                .setActionName("actionName")
                .setEndDate(new Date())
                .build();
        
    }

    @Test(expected = InvalidStateException.class)
    public void testFailMessage() throws InvalidStateException, JsonProcessingException {
        
        hist
                .setActionType(ActionType.START)
                .setActionType(ActionType.START)
                .setRequestorId("objectId")
                .setRequestorName("requestorName")
                .setActionName("actionName")
                .setEndDate(new Date())
                .build();
        
    }

    @Test(expected = InvalidStateException.class)
    public void testFailRequestorId() throws InvalidStateException, JsonProcessingException {
        
        hist
                .setActionType(ActionType.START)
                .setActionType(ActionType.START)
                .setRequestorName("requestorName")
                .setMessage("message")
                .setActionName("actionName")
                .setEndDate(new Date())
                .build();
        
    }

    @Test(expected = InvalidStateException.class)
    public void testFailRequestorName() throws InvalidStateException, JsonProcessingException {
        
        hist
                .setActionType(ActionType.START)
                .setActionType(ActionType.START)
                .setRequestorId("requestorId")
                .setMessage("message")
                .setActionName("actionName")
                .setEndDate(new Date())
                .build();
        
    }

    @Test(expected = InvalidStateException.class)
    public void testFailActionName() throws InvalidStateException, JsonProcessingException {
        
        hist
                .setActionType(ActionType.START)
                .setActionType(ActionType.START)
                .setMessage("message")
                .setRequestorId("objectId")
                .setRequestorName("requestorName")
                .setEndDate(new Date())
                .build();
        
    }
}