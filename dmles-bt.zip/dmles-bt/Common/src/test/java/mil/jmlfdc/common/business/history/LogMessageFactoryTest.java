package mil.jmlfdc.common.business.history;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import mil.jmlfdc.common.cache.EndpointCache;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;

import javax.interceptor.InvocationContext;

public class LogMessageFactoryTest {
    
    @Mock
    private EndpointCache endpointCache;
    @Mock
    private Logger logger;
    @Mock
    private InvocationContext ctx;
    @Mock
    private MessageParser messageParser;
    
    @InjectMocks
    private MessageFactory fact;
    
    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }
    
    @Test
    public void testGetLogMessage() throws Exception {
        
        String endpointName = "endpointName";
        String logMessage = "Message {0.getVal} the rest of the message";
        String expected = "Message val the rest of the message";
                
        when(endpointCache.getCachedValue(endpointName, "getLogMessage"))
                .thenReturn(logMessage);
        
        Object[] objArr = new Object[1];
        LogMessageTestObject obj = new LogMessageTestObject();
        objArr[0] = obj;
        
        when(ctx.getParameters()).thenReturn(objArr);
        when(messageParser.build(logMessage, objArr)).thenReturn(expected);
        
        fact.getMessage(InvocationContextLogger.GET_LOG_MESSAGE, 
                endpointName, ctx);
        
        verify(endpointCache).getCachedValue(endpointName, "getLogMessage");
        verify(ctx).getParameters();
    }
    
    @Test
    public void testGetLogMessage2() throws Exception {
        
        String endpointName = "endpointName";
        String logMessage = "Message {0.getObj.getVal} the rest of the message";
        String expected = "Message val2 the rest of the message";
        
        when(endpointCache.getCachedValue(endpointName, "getLogMessage"))
                .thenReturn(logMessage);
        
        Object[] objArr = new Object[1];
        LogMessageTestObject obj = new LogMessageTestObject();
        objArr[0] = obj;
        
        when(ctx.getParameters()).thenReturn(objArr);
        when(messageParser.build(logMessage, objArr)).thenReturn(expected);
        
        fact.getMessage(InvocationContextLogger.GET_LOG_MESSAGE, 
                endpointName, ctx);
        
        verify(endpointCache).getCachedValue(endpointName, "getLogMessage");
        verify(ctx).getParameters();
    }
    
    @Test
    public void testGetLogMessageNull() throws Exception {
        
        String endpointName = null;
        
        when(endpointCache.getCachedValue(endpointName, "getLogMessage"))
                .thenReturn(null);
        
        Object[] objArr = new Object[1];
        LogMessageTestObject obj = new LogMessageTestObject();
        objArr[0] = obj;
        
        when(ctx.getParameters()).thenReturn(objArr);
        
        String retval = fact.getMessage(InvocationContextLogger.GET_LOG_MESSAGE, 
                endpointName, ctx);
        
        verify(endpointCache).getCachedValue(endpointName, "getLogMessage");
        verify(ctx).getParameters();
        assertNull(retval);
    }

    @Test
    public void testGetLogMessage22() throws Exception {
        
        String endpointName = "endpointName";
        String logMessage = "Message {0.getObj.getVal} the rest of the message {0.getVal}";
        String expected = "Message val2 the rest of the message val";
        
        when(endpointCache.getCachedValue(endpointName, "getLogMessage"))
                .thenReturn(logMessage);
        
        Object[] objArr = new Object[1];
        LogMessageTestObject obj = new LogMessageTestObject();
        objArr[0] = obj;
        
        when(ctx.getParameters()).thenReturn(objArr);
        when(messageParser.build(logMessage, objArr)).thenReturn(expected);
        
        fact.getMessage(InvocationContextLogger.GET_LOG_MESSAGE, 
                endpointName, ctx);
        
        verify(endpointCache).getCachedValue(endpointName, "getLogMessage");
        verify(ctx).getParameters();
    }
}
