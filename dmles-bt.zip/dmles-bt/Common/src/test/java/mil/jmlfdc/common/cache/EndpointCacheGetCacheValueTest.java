package mil.jmlfdc.common.cache;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.runner.Request.method;

import org.junit.Before;
import org.junit.Test;


public class EndpointCacheGetCacheValueTest {
    
    private static final String KEY = "key";
    
    private EndpointCache cache;
    
    @Before
    public void setup() {
        cache = new EndpointCache();
        
    }
    
    @Test
    public void testOk() throws Exception {
        ClassToTestCache tclass = new ClassToTestCache();
        cache.setCachedObject(KEY, tclass);
        String retval = cache.getCachedValue(KEY, "getValue");
        
        assertNotNull(retval);
        assertEquals(ClassToTestCache.VALUE, retval);
    }
    
    @Test(expected = NoSuchMethodException.class)
    public void testWrongName() throws Exception {
        ClassToTestCache tclass = new ClassToTestCache();
        cache.setCachedObject(KEY, tclass);
        String retval = cache.getCachedValue(KEY, "getVal");
        
        assertNotNull(retval);
        assertEquals(ClassToTestCache.VALUE, retval);
    }
    
    @Test(expected = NoSuchMethodException.class)
    public void testJasParameters() throws Exception {
        ClassToTestCache tclass = new ClassToTestCache();
        cache.setCachedObject(KEY, tclass);
        String retval = cache.getCachedValue(KEY, "getValueWithParameter");
        
        assertNotNull(retval);
        assertEquals(ClassToTestCache.VALUE, retval);
    }
}
