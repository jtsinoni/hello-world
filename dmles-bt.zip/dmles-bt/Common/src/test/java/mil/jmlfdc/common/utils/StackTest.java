package mil.jmlfdc.common.utils;

import static junit.framework.TestCase.assertNotNull;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import mil.jmlfdc.common.utils.Stack;
import org.junit.Before;
import org.junit.Test;

public class StackTest {

    private Stack<String> stack;

    @Before
    public void setup() {
        stack = new Stack<>();
    }

    @Test
    public void testStack0(){

        String valPeek = stack.peek();
        String valPop = stack.pop();

        assertNull(valPeek);
        assertNull(valPop);

    }

    @Test
    public void testStack1(){
        String val = "val";
        stack.push(val);
        String valPeek = stack.peek();
        String valPop = stack.pop();

        assertNotNull(valPeek);
        assertEquals(val, valPeek);
        assertNotNull(valPop);
        assertEquals(val, valPop);

    }

    @Test
    public void testStack2(){
        String val = "val";
        String val2 = "val2";
        stack.push(val);
        stack.push(val2);

        String valPeek = stack.peek();
        String valPop = stack.pop();

        assertNotNull(valPeek);
        assertEquals(val2, valPeek);
        assertNotNull(valPop);
        assertEquals(val2, valPop);

        valPeek = stack.peek();
        valPop = stack.pop();

        assertNotNull(valPeek);
        assertEquals(val, valPeek);
        assertNotNull(valPop);
        assertEquals(val, valPop);

    }
}
