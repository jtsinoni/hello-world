package mil.jmlfdc.common.rest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import mil.jmlfdc.common.exception.ObjectNotFoundException;
import org.apache.deltaspike.core.api.config.ConfigProperty;
import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.resteasy.util.HttpResponseCodes;
import org.jboss.shrinkwrap.api.Archive;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Context;

@RunWith(Arquillian.class)
public class RestApiBaseIT extends BaseArquillianTest {

    @Inject
    private Logger logger;
    @Inject
    private RestApiBaseImplTest baseImpl;
    @Context
    private HttpServletResponse response;
    @Inject
    @ConfigProperty(name = "btdebug")
    private String btdebug;

    @Deployment(testable = true)
    public static Archive<?> createDeployment() {
        String[] packages = new String[1];
        packages[0] = "mil.jmlfdc.common";
        return createDeployment(packages);
    }

    @Before
    public void setUp() {
        baseImpl.setBtDebug(null);
    }
    
    // make sure there are no exceptions
    @Test
    public void testOk() {
        logger.warn("Testing testOK");
        baseImpl.testOk();
    }

//    @Test(expected = ApplicationException.class)
    @Test
    public void testApplicationException() throws ObjectNotFoundException {
        logger.warn("Testing testApplicationException");
        baseImpl.testApplicationException();

        assertNotNull(response);
        Integer status = response.getStatus();
        assertEquals(RestApiBase.APP_EXCEPTION, status);
        
    }

    @Test
    public void testUserNotFoundException() throws ObjectNotFoundException {
        logger.warn("Testing testUserNotFoundException");
        baseImpl.testApplicationException();
        
        assertNotNull(response);
        int status = response.getStatus();
        assertEquals(HttpResponseCodes.SC_UNAUTHORIZED, status);
        
    }

//    @Test(expected = Exception.class)
    @Test
    public void testException() throws Exception {
        logger.warn("Testing testException");
        baseImpl.setBtDebug("debug");
        
        baseImpl.testException();

    }

//    @Test(expected = Exception.class)
    @Test
    public void testExceptionCaught() throws Exception {
        logger.warn("Testing testExceptionCaught");
        
        baseImpl.testException();

        assertNotNull(response);
        int status = response.getStatus();
        assertEquals(HttpResponseCodes.SC_INTERNAL_SERVER_ERROR, status);
        
    }

}