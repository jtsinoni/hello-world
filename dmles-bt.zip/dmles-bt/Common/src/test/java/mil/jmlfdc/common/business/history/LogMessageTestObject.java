package mil.jmlfdc.common.business.history;


public class LogMessageTestObject {
    
    public static final String VAL = "val";
    private LogMessageTestObject2 obj = new LogMessageTestObject2();
    
    public String getVal() {
        return VAL;
    }
    
    public LogMessageTestObject2 getObj() {
        return obj;
    }
}
