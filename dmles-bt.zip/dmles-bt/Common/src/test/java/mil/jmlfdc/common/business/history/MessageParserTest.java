package mil.jmlfdc.common.business.history;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.lang.reflect.InvocationTargetException;

public class MessageParserTest {

    private MessageParser messageParser;
    private TestDO tdo = new TestDO();
    private TestDO tdo2 = new TestDO();
    private TestDO tdo3 = new TestDO();

    @Before
    public void setup() {

        messageParser = new MessageParser();
        tdo.setName("tdoName");
        tdo.setTestDo(tdo2);
        tdo2.setName("tdo2Name");
        tdo3.setName("tdo3Name");

    }

    @Test
    public void testOK() throws InvocationTargetException, NoSuchMethodException, NoSuchFieldException, IllegalAccessException {

        String logMessage = "this {0.getName} is a {0.getTestDo.getName} !!";
        Object[] parameters = new Object[2];
        parameters[0] = tdo;
        parameters[1] = tdo3;

        String msg = messageParser.build(logMessage, parameters);

        Assert.assertNotNull(msg);
        Assert.assertEquals("this tdoName is a tdo2Name !!", msg);

    }

    @Test
    public void testOK2() throws InvocationTargetException, NoSuchMethodException, NoSuchFieldException, IllegalAccessException {

        String logMessage = "this {0.getName} is a {1.getName} !!";
        Object[] parameters = new Object[2];
        parameters[0] = tdo;
        parameters[1] = tdo3;

        String msg = messageParser.build(logMessage, parameters);

        Assert.assertNotNull(msg);
        Assert.assertEquals("this tdoName is a tdo3Name !!", msg);

    }

    @Test(expected = NoSuchMethodException.class)
    public void testInvalid1() throws InvocationTargetException, NoSuchMethodException, NoSuchFieldException, IllegalAccessException {

        String logMessage = "this {0.getName} is a {1.getTestTdo.getName} !!";
        Object[] parameters = new Object[2];
        parameters[0] = tdo;
        parameters[1] = tdo3;

        messageParser.build(logMessage, parameters);

    }

    @Test
    public void testInvalid2() throws InvocationTargetException, NoSuchMethodException, NoSuchFieldException, IllegalAccessException {

        String logMessage = "this {0.getName} is a {0.getTestDo.getName} !!";
        Object[] parameters = new Object[2];
        parameters[0] = tdo;
        parameters[1] = tdo3;
        tdo2.setName(null);

        String msg = messageParser.build(logMessage, parameters);

        Assert.assertNotNull(msg);
        Assert.assertEquals("this tdoName is a  !!", msg);
    }
}
