package mil.jmlfdc.common.rest;

import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.Archive;
import org.jboss.shrinkwrap.api.spec.JavaArchive;

public class BaseArquillianTest {

    @Deployment(testable = true)
    public static Archive<?> createDeployment(String[] packages) {

        Archive archive = ShrinkWrap.create(JavaArchive.class)
                .addClass(RestApiBaseImplTest.class);
        return archive;
    }

}
