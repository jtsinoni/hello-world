package mil.jmlfdc.common.datamodel.version;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import org.junit.Before;
import org.junit.Test;


public class DmlesDbObjectFindElementTest {
    private DmlesDbObject dbObject;
    
//    @Before
//    private void setup() {
//        dbObject = new DmlesDbObject();
//    }
    
    @Test
    public void test1() {
        // TODO: Test is failing during deployments, fix needed 
        /*
        DBObject dbobc = new BasicDBObject("c", "cval");
        DBObject dbobb = new BasicDBObject("b", dbobc);
        DBObject dboba = new BasicDBObject("a", dbobb);
        
        DBObject dbobroot = new BasicDBObject();
        dbobroot.putAll(dboba);
        
        DmlesDbObject ddo = new DmlesDbObject(dbobroot);
        
        ddo.move("a/b", "a/d/b");
        
        System.out.println(dboba.toString());
        Object objd = ((DBObject)dboba.get("a")).get("d");
        assertNotNull(objd);
        Object objc = ((DBObject) objd).get("b");
        assertNotNull(objc);
        assertEquals(dbobc, objc);
        */
    }

}
