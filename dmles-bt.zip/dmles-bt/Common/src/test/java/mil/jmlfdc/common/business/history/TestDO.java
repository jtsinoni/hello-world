package mil.jmlfdc.common.business.history;

public class TestDO {

    private String name;
    private TestDO testDo;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public TestDO getTestDo() {
        return testDo;
    }

    public void setTestDo(TestDO testDo) {
        this.testDo = testDo;
    }
}
