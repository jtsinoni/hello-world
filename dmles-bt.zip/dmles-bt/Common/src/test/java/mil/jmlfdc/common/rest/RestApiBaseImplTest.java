package mil.jmlfdc.common.rest;

import mil.jmlfdc.common.exception.ObjectNotFoundException;
import mil.jmlfdc.common.exception.UserNotFoundException;

import javax.ejb.Stateless;


@Stateless
public class RestApiBaseImplTest extends RestApiBase {
    
    public void testOk() {
    }
    
    public void testUserException() throws UserNotFoundException {
        throw new UserNotFoundException("test");
    }
    
    public void testApplicationException() throws ObjectNotFoundException {
        throw new ObjectNotFoundException("test");
    }
    
    public void testException() throws Exception {
        throw new Exception("test");
    }
}
