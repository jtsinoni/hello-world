package mil.jmlfdc.common.cache;


public class ClassToTestCache {
    
    public static final String VALUE = "value";
    
    public String getValue() {
        return VALUE;
    }
    
    public String getValueWithParameter(String param) {
        return null;
    }
}
