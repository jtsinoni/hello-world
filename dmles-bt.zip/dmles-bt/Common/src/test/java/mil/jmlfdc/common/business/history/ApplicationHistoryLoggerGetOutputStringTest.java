package mil.jmlfdc.common.business.history;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

import com.fasterxml.jackson.core.JsonProcessingException;

public class ApplicationHistoryLoggerGetOutputStringTest {
    
    private ApplicationHistoryLogger logger;
    
    @Before
    public void setUp() {
        logger = new ApplicationHistoryLogger();
    }
    
    @Test
    public void testResult() throws JsonProcessingException {
        
        ApplicationHistory hist = new ApplicationHistory();
        hist.actionName = "name";
        ApplicationHistory hist2 = new ApplicationHistory();
        hist2.actionName = "name";
        hist.result = hist2;
        
        String value = logger.getOutputString(hist);
        
        assertNotNull(value);
    }
}