package mil.jmlfdc.common.business.history;


public class TestInputParamter {
    
    public String val1;
    public int val2;
    
}
