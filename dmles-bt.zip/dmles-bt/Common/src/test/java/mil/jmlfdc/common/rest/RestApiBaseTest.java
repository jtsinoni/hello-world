package mil.jmlfdc.common.rest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import mil.jmlfdc.common.exception.ObjectNotFoundException;
import mil.jmlfdc.common.exception.UserExceptionMessages;
import mil.jmlfdc.common.exception.UserNotFoundException;
import org.jboss.resteasy.util.HttpResponseCodes;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;

import javax.interceptor.InvocationContext;
import javax.servlet.http.HttpServletResponse;

public class RestApiBaseTest {
    
    @Mock 
    private Logger logger;
    @Mock 
    private HttpServletResponse response;
    @Mock 
    private InvocationContext ctx;
    @InjectMocks
    private RestApiBaseImplTest base;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }
    
    @Test
    public void testUserNotFoundException() throws Exception {
        String message = "message";
        when(ctx.proceed()).thenThrow(new UserNotFoundException(message));
        base.aroundRestMethods(ctx);
        
        verify(ctx).proceed();
        verify(response).sendError(HttpResponseCodes.SC_UNAUTHORIZED,
                    message);
    }

    @Test
    public void testOK() throws Exception {
        Object result = new Object();
        
        when(ctx.proceed()).thenReturn(result);
        Object retval = base.aroundRestMethods(ctx);
        
        assertNotNull(retval);
        assertEquals(result, retval);
    }

    // TODO: Failing during deployments, needs fixed
    /*
    @Test
    public void testApplicationException() throws Exception {

        String message = "message";
        when(ctx.proceed()).thenThrow(new ObjectNotFoundException(message));
        base.aroundRestMethods(ctx);
        
        verify(ctx).proceed();
        verify(response).sendError(470, message);
    }
    */

    // TODO: Failing during deployments, needs fixed
    /*
    @Test
    public void testException() throws Exception {
        String message = "message";
        when(ctx.proceed()).thenThrow(new Exception(message));
        base.aroundRestMethods(ctx);
        
        verify(ctx).proceed();
        verify(response).sendError(
                HttpResponseCodes.SC_INTERNAL_SERVER_ERROR, 
                UserExceptionMessages.GENERIC.toString());  
    }
    */

    // TODO: Failing during deployments, needs fixed
    /*
    @Test(expected = Exception.class)
    public void testDebugException() throws Exception {
        
        String message = "message";
        when(ctx.proceed()).thenThrow(new Exception(message));
        base.setBtDebug("a");
        
        base.aroundRestMethods(ctx); 
    }
    */
}