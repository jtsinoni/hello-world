package mil.jmlfdc.common.datamodel.version;


import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class DmlesDbObjectConvertListTest {

    private DmlesDbObject dbObject;

    @Test
    public void testMoveConvertString() {

        BasicDBList list = new BasicDBList();
        list.add("dmles/common/business/nifi");
        list.add("b");
        list.add("c");

        DBObject listRef = new BasicDBObject();
        listRef.put("list", list);

        DBObject root = new BasicDBObject();
        root.putAll(listRef);

        System.out.println(root.toString());

        dbObject = new DmlesDbObject(root);

        dbObject.moveConvertList("list", "listref/lista", getMap());

        System.out.println(root.toString());

        Object movedList = ((DBObject)root.get("listref")).get("lista");
        assertNotNull(movedList);

        BasicDBList listObj = (BasicDBList) movedList;
        assertNotNull(listObj);
        assertEquals("z", listObj.get(0));
        assertEquals("y", listObj.get(1));
        assertEquals("x", listObj.get(2));

    }

    private Map<Object,Object> getMap() {
        Map<Object,Object> map = new HashMap<>();
        map.put("dmles/common/business/nifi","z");
        map.put("b","y");
        map.put("c","x");
        return map;
    }
    @Test
    public void testMoveConvertInteger() {

        BasicDBList list = new BasicDBList();
        list.add(1);
        list.add(2);
        list.add(3);

        DBObject listRef = new BasicDBObject();
        listRef.put("list", list);

        DBObject root = new BasicDBObject();
        root.putAll(listRef);

        System.out.println(root.toString());

        dbObject = new DmlesDbObject(root);

        dbObject.moveConvertList("list", "listref/lista", getIntegerMap());

        System.out.println(root.toString());

        Object movedList = ((DBObject)root.get("listref")).get("lista");
        assertNotNull(movedList);

        BasicDBList listObj = (BasicDBList) movedList;
        assertNotNull(listObj);
        assertEquals(11, listObj.get(0));
        assertEquals(12, listObj.get(1));
        assertEquals(13, listObj.get(2));

    }

    private Map<Object,Object> getIntegerMap() {
        Map<Object,Object> map = new HashMap<>();
        map.put(1,11);
        map.put(2,12);
        map.put(3,13);
        return map;
    }
}
