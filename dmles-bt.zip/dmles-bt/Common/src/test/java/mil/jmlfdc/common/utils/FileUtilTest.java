package mil.jmlfdc.common.utils;

import org.junit.Test;

import static org.junit.Assert.*;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

public class FileUtilTest {
    
    @Test(expected = FileNotFoundException.class)
    public void testNotFound() throws IOException {
        
        FileUtil.getClasspathFileLines("notfound");
        
    }

    @Test
    public void testFound() throws IOException {
        
        List<String> lines = FileUtil.getClasspathFileLines("test/testFile.txt");
        
        assertNotNull(lines);
        assertEquals(lines.size(), 2);
        String line0 = lines.get(0);
        String line1 = lines.get(1);
        assertNotNull(line0);
        assertNotNull(line1);
        assertEquals("test1", line0);
        assertEquals("test2", line1);
        
    }
}