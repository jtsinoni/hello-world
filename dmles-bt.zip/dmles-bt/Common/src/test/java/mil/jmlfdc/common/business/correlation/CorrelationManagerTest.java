package mil.jmlfdc.common.business.correlation;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

public class CorrelationManagerTest {

    private CorrelationManager mgr;

    @Before
    public void setup() {
        mgr = new CorrelationManager();
    }

    @Test
    public void testSingle() {
        generalTest(1);
    }

    @Test
    public void testMulti() {
        generalTest(10);
    }

    public void generalTest(int iterations) {

        List<String> starts = new ArrayList<>();
        List<String> ends = new ArrayList<>();

        for (int i = 0; i < iterations; i++) {
            starts.add(mgr.start());
        }

        for (int i = 0; i < iterations; i++) {
            ends.add(0,mgr.end());
        }

        for (int i = 0; i < iterations; i++) {
            Assert.assertEquals(starts.get(i), ends.get(i));
        }

    }

}
