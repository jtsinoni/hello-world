package mil.jmlfdc.common.business.history;


public class LogMessageTestObject2 {
    
    public static final String VAL = "val2";
    
    public String getVal() {
        return VAL;
    }
    
}
