package dmles.oauth.core.rest;

import mil.jmlfdc.common.business.RestClientFactory;
import org.jboss.resteasy.client.jaxrs.ResteasyWebTarget;

import javax.inject.Inject;
 
public abstract class SecuredRestClientFactory<T extends Object>
    extends RestClientFactory<T> {
 
    @Inject
    private TokenHeaderRequestFilter filter;
    
    public SecuredRestClientFactory(Class<T> classType, String serviceName) {
        super(classType, serviceName);
    }
    
    @Override
    public T createClient() {
        
        ResteasyWebTarget target = buildTarget();
        
        target.register(filter);
        
        T client = target.proxy(classType);

        return client;
    }
}
