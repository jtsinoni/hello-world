package dmles.oauth.core.token;

import mil.jmlfdc.common.exception.InvalidDataException;
import org.apache.deltaspike.core.api.config.ConfigProperty;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

@ApplicationScoped
public class TokenKey {

    public static final String CLIENT_ID = "clientId";
    private static final String DMLES = "dmles";
    private static final String TEWLS = "tewls";

    @Inject
    @ConfigProperty(name = DMLES)
    private String dmlesEncryptionKey;
//    @Inject
//    @ConfigProperty(name = TEWLS)
//    private String tewlsEncryptionKey;

    private final Map<String, String> keyMap = new HashMap<>();

    @PostConstruct
    public void postConstruct() {
        if (dmlesEncryptionKey == null) {
            throw new RuntimeException("configuration for DMLES encryption key not found");
        }
        keyMap.put(DMLES, dmlesEncryptionKey);
        //keyMap.put(TEWLS, tewlsEncryptionKey);
    }

    public String getKey(String clientId) throws InvalidDataException {
        String key = null;
        if (keyMap.containsKey(clientId)) {
            key = keyMap.get(clientId);
        } else {
            throw new InvalidDataException(
                    String.format("clientId %s was not found", clientId));
        }
        return key;
    }

    protected void setDmlesEncryptionKey(String key) {
        dmlesEncryptionKey = key;
    }
}
