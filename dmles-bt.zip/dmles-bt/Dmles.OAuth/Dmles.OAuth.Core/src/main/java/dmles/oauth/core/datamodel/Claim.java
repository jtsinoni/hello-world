package dmles.oauth.core.datamodel;

public enum Claim {
    ID ("Id"), 
    PKIDN ("PkiDn"), 
    ROLE ("Role"), 
    FIRST_NAME ("FirstName"), 
    LAST_NAME ("LastName"), 
    ENDPOINT ("Endpoint"),
    USER_TYPE ("UserType"),
    SERVICE_CODE ("ServiceCode"), 
    REGION_CODE ("RegionCode"),
    DODAAC ("Dodaac");
    
    private final String claim;
    
    Claim(String claim) {
        this.claim = claim;
    }
    
}
