package dmles.oauth.core.datamodel;

import org.picketlink.idm.credential.AbstractToken;
import org.picketlink.json.jose.JWS;
import org.picketlink.json.jose.JWSBuilder;

/**
 *
 * @author robert.hayes
 */
public class DmlesToken extends AbstractToken {
    private final JWS jws;
    
    public DmlesToken(String encodedToken) {
        super(encodedToken);
        this.jws = new JWSBuilder().build(encodedToken);
    }

    @Override
    public String getSubject() {
        return this.jws.getSubject();
    } 
    
    public String getId() {
        return jws.getId();
    }
    
}
