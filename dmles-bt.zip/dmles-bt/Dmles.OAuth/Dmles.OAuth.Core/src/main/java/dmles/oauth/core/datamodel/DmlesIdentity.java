package dmles.oauth.core.datamodel;

import org.picketlink.idm.model.AbstractIdentityType;
import org.picketlink.idm.model.Account;

import java.util.List;
/**
 *
 * @author robert.hayes
 */

public class DmlesIdentity extends AbstractIdentityType implements Account, Identity {
    private String userId = null;
    private String firstName = null;
    private String lastName = null;
    private List<String> roles = null;
    
    @Override
    public String getUserId() {
        return userId;
    }
    
    public void setUserId(final String userId) {
        this.userId = userId;
    }

    /** GetFirstName.
     * @return the firstName
     */
    @Override
    public String getFirstName() {
        return firstName;
    }

    /** SetFirstName.
     * @param firstName the firstName to set
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /** getLastName.
     * @return the lastName
     */
    @Override
    public String getLastName() {
        return lastName;
    }

    /** setLastName.
     * @param lastName the lastName to set
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /** getRoles.
     * @return the roles
     */
    @Override
    public List<String> getRoles() {
        return roles;
    }

    /** setRoles.
     * @param roles the roles to set
     */
    public void setRoles(List<String> roles) {
        this.roles = roles;
    }

    
}
