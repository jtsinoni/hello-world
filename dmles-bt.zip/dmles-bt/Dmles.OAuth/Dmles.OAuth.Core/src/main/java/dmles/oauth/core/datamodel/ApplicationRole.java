package dmles.oauth.core.datamodel;

/**
 * <p>Roles supported by this application.</p>
 *
 */
public interface ApplicationRole {

    String ADMINISTRATOR = "admin";
    String USER = "user";


}
