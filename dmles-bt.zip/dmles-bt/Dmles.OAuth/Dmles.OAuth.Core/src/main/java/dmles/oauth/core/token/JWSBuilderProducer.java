package dmles.oauth.core.token;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;
import org.picketlink.json.jose.JWSBuilder;

@ApplicationScoped
public class JWSBuilderProducer {
    
    @Produces
    @JwsBuilder
    public JWSBuilder createBuilder() {
        return new JWSBuilder();
    }
}
