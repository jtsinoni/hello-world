package dmles.oauth.core.datamodel;

import dmles.user.core.clientmodel.UserType;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.enterprise.context.RequestScoped;

@RequestScoped
public class CurrentUserBT {

    private Date requestStart = new Date();
    private String profileId = null;
    private String pkiDn = null;
    private String firstName = null;
    private String lastName = null;
    private String serviceCode = null;
    private List<String> effectiveEndpoints;
    private UserType userType;
    private String dodaac;
    private String regionCode;
    private String token;

    public Date getRequestStart() {
        return requestStart;
    }

    public void setRequestStart(Date requestStart) {
        this.requestStart = requestStart;
    }

    public String getProfileId() {
        return profileId;
    }

    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }

    public String getPkiDn() {
        return pkiDn;
    }

    public void setPkiDn(String pkiDn) {
        this.pkiDn = pkiDn;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    
    public List<String> getEffectiveEndpoints() {
        if (effectiveEndpoints == null) {
            effectiveEndpoints = new ArrayList<>();
        }
        return effectiveEndpoints;
    }

    public void setEffectiveEndpoints(List<String> effectiveEndpoints) {
        this.effectiveEndpoints = effectiveEndpoints;
    }

    public String getServiceCode() {
        return serviceCode;
    }

    public void setServiceCode(String serviceCode) {
        this.serviceCode = serviceCode;
    }

    public UserType getUserType() {
        return userType;
    }

    public void setUserType(UserType userType) {
        this.userType = userType;
    }

    public String getDodaac() {
        return dodaac;
    }

    public void setDodaac(String dodaac) {
        this.dodaac = dodaac;
    }

    public String getRegionCode() {
        return regionCode;
    }

    public void setRegionCode(String regionCode) {
        this.regionCode = regionCode;
    }

    public String getFullName() {
        return String.format("%s, %s", this.lastName, this.firstName);
    }
    
    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

}
