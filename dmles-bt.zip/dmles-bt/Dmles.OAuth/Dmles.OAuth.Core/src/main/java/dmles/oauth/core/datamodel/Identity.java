package dmles.oauth.core.datamodel;

import org.picketlink.idm.model.IdentityType;

import java.util.List;

/**
 *
 * @author robert.hayes
 */
public interface Identity extends IdentityType {

    static String IDENTITY = "identity";
    
    String getUserId();
    
    List<String> getRoles();
    
    String getLastName();
    
    String getFirstName();
}
