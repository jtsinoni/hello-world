package dmles.oauth.core.rest;

import dmles.oauth.core.datamodel.CurrentUserBT;
import dmles.oauth.core.datamodel.TokenDateUtil;
import dmles.oauth.core.http.RequestUtil;
import dmles.oauth.core.token.TokenBuilder;
import dmles.oauth.core.token.TokenKey;
import dmles.user.core.clientmodel.CurrentUserPT;
import dmles.user.core.clientmodel.Endpoint;
import mil.jmlfdc.common.exception.InvalidDataException;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.client.ClientRequestContext;
import javax.ws.rs.client.ClientRequestFilter;
import javax.ws.rs.core.MultivaluedMap;
import org.slf4j.Logger;

@RequestScoped
public class TokenHeaderRequestFilter implements ClientRequestFilter {

    public static final String AUTHORIZATION = "Authorization";
    public static final String TOKEN_SERVICE = "TokenService";
    @Inject
    private Logger logger;
    @Inject
    private RequestUtil requestUtil;
    @Inject
    private TokenBuilder tokenBuilder;
    @Inject 
    private CurrentUserBT currentUserBt;
    
    @Override
    public void filter(ClientRequestContext requestContext) throws IOException {
        
        try {
            MultivaluedMap<String,Object> headers = requestContext.getHeaders();
            String clientid = requestUtil.getClientId();
            
            String tokenValue = getTokenValue(clientid);
            headers.add(AUTHORIZATION, tokenValue);
            headers.add(TokenKey.CLIENT_ID, clientid);
        } catch (InvalidDataException ex) {
            logger.error(ex.getMessage());
        }
        
    }
    
    private String getTokenValue(String clientId) throws InvalidDataException {
        
        String tokenValue = getTokenFromHeader();
        
        if (tokenValue == null) {
            CurrentUserPT user = buildApplicationUser();
            List<Endpoint> endpoints = new ArrayList<>();
            int expiration = TokenDateUtil.getCurrentTimeAsInt() 
                    + (10 * 365 * 24 * 60 * 60); // 10 years

            String tokenString = tokenBuilder.buildToken(user, TOKEN_SERVICE, endpoints, 
                    expiration, clientId);
            tokenValue = TokenBuilder.TOKEN + tokenString;
        }
        
        return tokenValue;
        
    }
    private CurrentUserPT buildApplicationUser() {
        CurrentUserPT user = new CurrentUserPT();
        
        user.firstName = TokenBuilder.TOKEN;
        user.lastName = TokenBuilder.TOKEN;
        user.id = TokenBuilder.TOKEN;
        user.pkiDn = TokenBuilder.TOKEN;
        user.serviceCode = TokenBuilder.TOKEN;
        
        return user;
    }

    private String getTokenFromHeader() {
        String value = null;
        
        if (currentUserBt != null) {
            String headerValue = currentUserBt.getToken();
            if (headerValue != null) {
                value = TokenBuilder.TOKEN + headerValue;
            }
        }
        
        return value;
    }
}
