package dmles.oauth.core.http;

import dmles.oauth.core.token.TokenKey;
import org.picketlink.http.internal.HttpServletRequestProducer;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

@ApplicationScoped
public class RequestUtil {

    @Inject
    private HttpServletRequestProducer servletRequestProducer;

    public String getClientId() {
        HttpServletRequest req = servletRequestProducer.produce();
        String clientId = req.getHeader(TokenKey.CLIENT_ID);
        return clientId;
    }
}
