package dmles.oauth.core.token;

import dmles.oauth.core.datamodel.Claim;
import dmles.oauth.core.datamodel.TokenDateUtil;
import dmles.user.core.clientmodel.CurrentUserPT;
import dmles.user.core.clientmodel.Endpoint;
import mil.jmlfdc.common.exception.InvalidDataException;
import org.picketlink.json.jose.JWSBuilder;

import java.util.List;
import java.util.UUID;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

@ApplicationScoped
public class TokenBuilder {
    
    public static final String TOKEN = "Token ";
    @Inject
    private TokenKey tokenKey;
    @Inject
    @JwsBuilder
    private JWSBuilder builder;

    public String buildToken(final CurrentUserPT user, final String userId, 
            List<Endpoint> effectiveEndpoints, String clientId) throws InvalidDataException {
        
        return buildToken(user, userId, effectiveEndpoints, 
                getDefaultExpiration(),
                clientId);
                
    }
    
    public int getDefaultExpiration() {

        final int currentTime = TokenDateUtil.getCurrentTimeAsInt();
        return currentTime + (4 * 60 * 60); // 4 hours
    }
    
    public String buildToken(final CurrentUserPT user, final String userId, 
            final List<Endpoint> effectiveEndpoints, final int expiration,
            final String clientId) throws InvalidDataException {
        
        String key = tokenKey.getKey(clientId);
        return buildToken(user, userId, effectiveEndpoints, expiration,
                clientId, key);
    }
    
    public String buildToken(final CurrentUserPT user, final String userId, 
            final List<Endpoint> effectiveEndpoints, final int expiration,
            final String clientId, String key) {
        final int currentTime = TokenDateUtil.getCurrentTimeAsInt();
        
        builder
                .id(UUID.randomUUID().toString())
                .issuer("dmles")
                .hmac512(key.getBytes())
                .issuedAt(currentTime)
                .subject(userId)
                .expiration(expiration)
                .notBefore(currentTime);
        
        addClaim(Claim.ID.toString(), user.id);
        addClaim(Claim.PKIDN.toString(), user.pkiDn);
        addClaim(Claim.FIRST_NAME.toString(), user.firstName);
        addClaim(Claim.LAST_NAME.toString(), user.lastName);
        addClaim(Claim.SERVICE_CODE.toString(), user.serviceCode);
        addClaim(Claim.USER_TYPE.toString(), user.userType);
        addClaim(Claim.REGION_CODE.toString(), user.regionCode);
        addClaim(Claim.DODAAC.toString(), user.dodaac);

        addEndpoints(effectiveEndpoints);


        return builder.build().encode();

    }
    protected void addEndpoints(final List<Endpoint> effectiveEndpoints) {
        
        for (Endpoint endp : effectiveEndpoints) {
            builder.claim(Claim.ENDPOINT.toString(), endp.businessMethod);
        }

    }
    
    protected void addClaim(String claim, String value) {
        if (claim != null && value != null) {
            builder.claim(claim, value);
        }
    }
}
