package dmles.oauth.core.utils;

import org.apache.deltaspike.core.api.config.PropertyFileConfig;

import javax.ejb.Singleton;
import javax.ejb.Startup;

@Singleton
@Startup
public class EncryptionKeyPropertyFileConfig implements PropertyFileConfig {

    @Override
    public String getPropertyFileName() {
        return "encryptionKeys.properties"; 
    }

}