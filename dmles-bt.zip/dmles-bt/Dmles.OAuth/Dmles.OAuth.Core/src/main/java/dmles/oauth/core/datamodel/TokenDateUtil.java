package dmles.oauth.core.datamodel;

import java.util.Date;

/**
 *
 * @author robert.hayes
 */
public class TokenDateUtil {
    
    public static int getCurrentTimeAsInt() {
        return (int) (new Date().getTime() / 1000);
    }
    
    public static Date getDateFromIntTime(final int expDate) {
        return new Date(((long)expDate) * 1000L);
    }
    
    public static Date getCurrentDate() {
        return new Date();
    }
}
