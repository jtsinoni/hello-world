package dmles.oauth.core.rest;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dmles.oauth.core.http.RequestUtil;
import dmles.oauth.core.token.TokenBuilder;
import dmles.oauth.core.token.TokenKey;
import dmles.user.core.clientmodel.CurrentUserPT;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.io.IOException;
import java.util.List;
import javax.ws.rs.client.ClientRequestContext;
import javax.ws.rs.core.MultivaluedMap;
import mil.jmlfdc.common.exception.InvalidDataException;

public class TokenHeaderRequestFilterTest {

    @Mock
    private RequestUtil requestUtil;
    @Mock
    private TokenBuilder tokenBuilder;
    @Mock
    private ClientRequestContext requestContext;
    @Mock
    private MultivaluedMap<String,Object> headers;
    
    @InjectMocks
    private TokenHeaderRequestFilter filter;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void test() throws IOException, InvalidDataException {
        String clientId = "clientId";
        String token = "token";
        when(requestContext.getHeaders()).thenReturn(headers);
        when(requestUtil.getClientId()).thenReturn(clientId);

        when(tokenBuilder.buildToken(any(CurrentUserPT.class), 
                eq(TokenHeaderRequestFilter.TOKEN_SERVICE), 
                any(List.class), anyInt(), eq(clientId)))
                .thenReturn(token);
        
        filter.filter(requestContext);
        
        verify(requestContext).getHeaders();
        verify(requestUtil).getClientId();
        verify(tokenBuilder).buildToken(any(CurrentUserPT.class), 
                eq(TokenHeaderRequestFilter.TOKEN_SERVICE), 
                any(List.class), anyInt(), eq(clientId));
        verify(headers).add(eq(TokenHeaderRequestFilter.AUTHORIZATION), anyString());
        verify(headers).add(TokenKey.CLIENT_ID, clientId);
    }
}
