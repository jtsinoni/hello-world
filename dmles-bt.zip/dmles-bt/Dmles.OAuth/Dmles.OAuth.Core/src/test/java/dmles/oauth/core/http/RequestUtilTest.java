package dmles.oauth.core.http;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dmles.oauth.core.token.TokenKey;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.picketlink.http.internal.HttpServletRequestProducer;

import javax.servlet.http.HttpServletRequest;

public class RequestUtilTest {

    @Mock private HttpServletRequestProducer servletRequestProducer;
    @Mock private HttpServletRequest req;
    @InjectMocks private RequestUtil requestUtil;
    
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }
    
    @Test
    public void test() {
        String key = "key";
        
        when(servletRequestProducer.produce()).thenReturn(req);
        when(req.getHeader(TokenKey.CLIENT_ID)).thenReturn(key);
        
        requestUtil.getClientId();
        
        verify(servletRequestProducer).produce();
        verify(req).getHeader(TokenKey.CLIENT_ID);
    }

}