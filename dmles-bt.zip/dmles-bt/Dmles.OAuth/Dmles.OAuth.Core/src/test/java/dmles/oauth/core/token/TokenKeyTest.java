package dmles.oauth.core.token;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

import mil.jmlfdc.common.exception.InvalidDataException;

public class TokenKeyTest {

    private TokenKey tokenKey;
    
    @Before
    public void setUp() {
        tokenKey = new TokenKey();
    }
    
    @Test(expected = RuntimeException.class)
    public void testPostConstructNull() {
        
        tokenKey.postConstruct();
        
    }
    
    @Test
    public void testPostConstruct() {
        tokenKey.setDmlesEncryptionKey("key");
        tokenKey.postConstruct();
    }
    
    @Test
    public void testGetKeyFound() throws InvalidDataException {
        String key = "key";
        
        tokenKey.setDmlesEncryptionKey(key);
        tokenKey.postConstruct();
        String val = tokenKey.getKey("dmles");
        assertNotNull(val);
        assertEquals(key, val);
    }
    
    @Test(expected = InvalidDataException.class)
    public void testGetKeyNotFound() throws InvalidDataException {
        String key = "key";
        
        tokenKey.setDmlesEncryptionKey(key);
        tokenKey.postConstruct();
        String val = tokenKey.getKey("notFound");
    }
}