package dmles.oauth.core.token;

import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import dmles.oauth.core.datamodel.Claim;
import dmles.user.core.clientmodel.CurrentUserPT;
import dmles.user.core.clientmodel.Endpoint;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.picketlink.json.jose.JWSBuilder;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import mil.jmlfdc.common.exception.InvalidDataException;
import org.picketlink.json.jose.JWS;

public class TokenBuilderTest {

    @Mock
    private TokenKey tokenKey;
    @Mock
    private JWSBuilder builder;
    @InjectMocks
    private TokenBuilder tokenBuilder;
    
    private CurrentUserPT user = new CurrentUserPT();
    private String userId = "userId";
    private List<Endpoint> effectiveEndpoints = new ArrayList<>();
    private Endpoint endpoint = new Endpoint();
    private int expiration = 1;
    private String clientId = "clientId";
    private String key = "key";
    private JWS jws = mock(JWS.class);
    private String jwsString = "jws";
    
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        effectiveEndpoints.add(endpoint);
        user.id = "id";
        user.pkiDn = "pkiDn";
        user.firstName = "firstName";
        user.lastName = "lastName";
        endpoint.businessMethod = "url";
    }

    @Test
    public void testWithoutExpiration() throws IOException, InvalidDataException {
        setUpWhen();
        when(builder.expiration(anyInt())).thenReturn(builder);

        tokenBuilder.buildToken(user, userId, 
            effectiveEndpoints, clientId);
        
        verify(builder).expiration(anyInt());
        runVerify();
    }

    @Test
    public void testWithExpiration() throws IOException, InvalidDataException {
        setUpWhen();
        when(builder.expiration(expiration)).thenReturn(builder);

        tokenBuilder.buildToken(user, userId, 
            effectiveEndpoints, expiration,
            clientId);
        
        verify(builder).expiration(expiration);
        runVerify();
    }

    private void setUpWhen() throws InvalidDataException {
        when(tokenKey.getKey(clientId)).thenReturn(key);
        when(builder.id(anyString())).thenReturn(builder);
        when(builder.issuer("dmles")).thenReturn(builder);
        when(builder.hmac512(key.getBytes())).thenReturn(builder);
        when(builder.issuedAt(anyInt())).thenReturn(builder);
        when(builder.subject(userId)).thenReturn(builder);
        when(builder.notBefore(anyInt())).thenReturn(builder);
        when(builder.claim(Claim.ID.toString(), user.id)).thenReturn(builder);
        when(builder.claim(Claim.PKIDN.toString(), user.pkiDn)).thenReturn(builder);
        when(builder.claim(Claim.FIRST_NAME.toString(), user.firstName)).thenReturn(builder);
        when(builder.claim(Claim.LAST_NAME.toString(), user.lastName)).thenReturn(builder);
        when(builder.build()).thenReturn(jws);
        when(jws.encode()).thenReturn(jwsString);
    }
    private void runVerify() throws InvalidDataException {
        verify(tokenKey).getKey(clientId);
        verify(builder).id(anyString());
        verify(builder).issuer("dmles");
        verify(builder).hmac512(key.getBytes());
        verify(builder).issuedAt(anyInt());
        verify(builder).subject(userId);
        verify(builder).notBefore(anyInt());
        verify(builder).claim(Claim.ID.toString(), user.id);
        verify(builder).claim(Claim.PKIDN.toString(), user.pkiDn);
        verify(builder).claim(Claim.FIRST_NAME.toString(), user.firstName);
        verify(builder).claim(Claim.LAST_NAME.toString(), user.lastName);
        verify(builder).claim(Claim.ENDPOINT.toString(), endpoint.businessMethod);
        verify(builder).build();
        verify(jws).encode();
        
    }
}
