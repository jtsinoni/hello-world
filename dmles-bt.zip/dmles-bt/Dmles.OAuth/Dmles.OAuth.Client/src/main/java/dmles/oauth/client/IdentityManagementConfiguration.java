package dmles.oauth.client;

import org.picketlink.event.IdentityConfigurationEvent;
import org.picketlink.idm.config.IdentityConfigurationBuilder;

import javax.ejb.Stateless;
import javax.enterprise.event.Observes;
import javax.inject.Inject;

@Stateless
public class IdentityManagementConfiguration {
    
    @Inject
    private TokenConsumer tokenConsumer;
    
    public void configureIdentityManagement(@Observes IdentityConfigurationEvent event) {
        
        IdentityConfigurationBuilder builder = event.getConfig();
        builder
            .named("sp.config")
                .stores()
                    .token()
                        .tokenConsumer(tokenConsumer)
                        .supportAllFeatures();
    }
    
}