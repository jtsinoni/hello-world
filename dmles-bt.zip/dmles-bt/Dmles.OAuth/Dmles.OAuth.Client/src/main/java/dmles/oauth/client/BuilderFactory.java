package dmles.oauth.client;

import dmles.oauth.core.token.TokenKey;
import mil.jmlfdc.common.exception.InvalidDataException;
import org.picketlink.json.jose.JWSBuilder;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

@ApplicationScoped
public class BuilderFactory implements IBuilderFactory {
    
    @Inject
    private TokenKey tokenKey;
    
    @Override
    public JWSBuilder getBuilderInstance(String clientId) throws InvalidDataException {
        JWSBuilder builder = new JWSBuilder();
        String key = tokenKey.getKey(clientId);
        builder.hmac512(key.getBytes());
        return builder;
    }
}
