package dmles.oauth.client;

import org.apache.deltaspike.core.api.config.ConfigProperty;
import org.picketlink.config.SecurityConfigurationBuilder;
import org.picketlink.event.SecurityConfigurationEvent;

import org.picketlink.http.HttpMethod;
import org.slf4j.Logger;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.event.Observes;
import javax.inject.Inject;

@ApplicationScoped
public class HttpSecurityConfiguration {
    private static final String DEFAULT_PATH = "/*";
    private static final HttpMethod UNPROTECTED_METHODS = HttpMethod.OPTIONS;
    private static final HttpMethod[] PROTECTED_METHODS = 
            new HttpMethod[]{HttpMethod.GET, HttpMethod.POST,
                HttpMethod.DELETE, HttpMethod.HEAD, HttpMethod.PUT, HttpMethod.TRACE};
    
    @Inject
    private Logger logger;
    
    @Inject
    @ConfigProperty(name = "securedPaths")
    private String securedPaths; 
    
    @Inject
    @ConfigProperty(name = "unSecuredPaths")
    private String unSecuredPaths; 
    
    public void onInit(@Observes SecurityConfigurationEvent event) {
        SecurityConfigurationBuilder builder = event.getBuilder();
        
        builder
            .identity()
                .stateless();
        for (String path: getSecuredPaths(securedPaths)) {
            builder.http()
                .forPath(path)
                    .withMethod(UNPROTECTED_METHODS)
                    .unprotected()
                    .cors()
                        .allowAll()
                .forPath(path)
                    .withMethod(PROTECTED_METHODS)
                    .authenticateWith()
                        .token()
                    .cors()
                        .allowAll()
                    ;
        }
        builder.http()
            .forPath(DEFAULT_PATH)
                    .withMethod(UNPROTECTED_METHODS)
                    .unprotected()
                .cors()
                    .allowAll();
        
        if (unSecuredPaths != null) {
            for (String path: getSecuredPaths(unSecuredPaths)) {
                builder.http()
                    .forPath(path)
                        .unprotected()
                        .cors()
                            .allowAll()
                        ;
            }
        }
    }
    
    protected String[] getSecuredPaths(final String securedPaths) {
        
        String retval;
        
        if (securedPaths == null) {
            logger.warn("HTTP secured paths is null. Using default of /*");
            retval = DEFAULT_PATH;
        } else {
            logger.info("HTTP secured paths " + securedPaths);
            retval = securedPaths;
        }
        return retval.split(",");
    }
}
