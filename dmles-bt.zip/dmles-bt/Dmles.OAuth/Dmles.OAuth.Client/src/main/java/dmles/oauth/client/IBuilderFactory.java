package dmles.oauth.client;

import mil.jmlfdc.common.exception.InvalidDataException;
import org.picketlink.json.jose.JWSBuilder;

interface IBuilderFactory {
    public JWSBuilder getBuilderInstance(String clientId) throws InvalidDataException;
}
