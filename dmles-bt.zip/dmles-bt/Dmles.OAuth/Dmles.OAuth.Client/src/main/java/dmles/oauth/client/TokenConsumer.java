package dmles.oauth.client;

import dmles.oauth.core.datamodel.Claim;
import dmles.oauth.core.datamodel.CurrentUserBT;
import dmles.oauth.core.datamodel.DmlesIdentity;
import dmles.oauth.core.datamodel.DmlesToken;
import dmles.oauth.core.datamodel.TokenDateUtil;
import dmles.oauth.core.http.RequestUtil;
import dmles.user.core.clientmodel.UserType;
import mil.jmlfdc.common.exception.InvalidStateException;
import mil.jmlfdc.common.exception.ObjectNotFoundException;
import org.picketlink.idm.credential.Token;
import org.picketlink.idm.model.IdentityType;
import org.picketlink.idm.model.annotation.StereotypeProperty;
import org.picketlink.json.jose.JWS;
import org.picketlink.json.jose.JWSBuilder;
import org.slf4j.Logger;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import mil.jmlfdc.common.exception.InvalidDataException;

@ApplicationScoped
public class TokenConsumer implements Token.Consumer<DmlesToken> {

    @Inject
    private Logger logger;
    @Inject
    private IBuilderFactory builderFactory;
    @Inject
    private CurrentUserBT currentUser;
    @Inject
    private RequestUtil requestUtil;

    @Override
    public <I extends IdentityType> I extractIdentity(
        DmlesToken token, Class<I> type, StereotypeProperty.Property prprt, Object object) {

        DmlesIdentity identity = new DmlesIdentity();
        identity.setUserId(token.getId());

        return (I) identity;
    }

    @Override
    public boolean validate(DmlesToken token) {
        boolean isValid = false;
        logger.debug("token received - " + token);

        if (token != null && token.getSubject() != null) {
            final String tokenString = token.getToken();

            logger.debug(String.format("token subject - %s - %s", token.getSubject(), token));
            
            JWS jws = null;

            try {
                String clientId = requestUtil.getClientId();
                JWSBuilder builder = builderFactory.getBuilderInstance(clientId);

                jws = builder.build(tokenString);

                isValid = validateJws(jws);
            } catch (InvalidDataException ide) {
                logger.warn(ide.getMessage());
                isValid = false;
            }
            
            if (isValid) {
                try {
                    buildIdentity(jws, token.getToken());
                } catch (ObjectNotFoundException | InvalidStateException ex) {
                    logger.error("Could not retrieve user's effective permissions", ex);
                    isValid = false;
                }
            } else {
                logger.error("Unable to validate JWT: token expired - returning false");
            }
        }
        return isValid;
    }

    public void buildIdentity(final JWS jws, final String token) throws ObjectNotFoundException, InvalidStateException {
        
        String pkidn = jws.getSubject();
        String id = jws.getClaim(Claim.ID.toString());
        currentUser.setProfileId(id);
        currentUser.setPkiDn(pkidn);
        currentUser.setFirstName(jws.getClaim(Claim.FIRST_NAME.toString()));
        currentUser.setLastName(jws.getClaim(Claim.LAST_NAME.toString()));
        currentUser.setServiceCode(jws.getClaim(Claim.SERVICE_CODE.toString()));
        currentUser.setToken(token);
        List<String> endpoints = jws.getClaimValues(Claim.ENDPOINT.toString());
        currentUser.setEffectiveEndpoints(endpoints);
        String userTypeStr = jws.getClaim(Claim.USER_TYPE.toString());
        if (userTypeStr != null && userTypeStr != "") {
            currentUser.setUserType(UserType.valueOf(userTypeStr));
        }
        currentUser.setRegionCode(jws.getClaim(Claim.REGION_CODE.toString()));
        currentUser.setDodaac(jws.getClaim(Claim.DODAAC.toString()));
        
    }
    
    public boolean validateJws(final JWS jws) {
        boolean retval = false;

        final Date currentDate = TokenDateUtil.getCurrentDate();
        final Date expDate = TokenDateUtil.getDateFromIntTime(jws.getExpiration());
        final Date issueDate = TokenDateUtil.getDateFromIntTime(jws.getIssuedAt());

        final SimpleDateFormat sdf = new SimpleDateFormat("YYYY-MM-dd:HH:mm");
        final String currDate = sdf.format(currentDate);
        final String expirationDate = sdf.format(expDate);
        logger.debug(String.format("Current date %s - JWT expiration date %s ", currDate, expirationDate));

        if (currentDate.before(expDate)
            && (currentDate.after(issueDate) )) {
            retval = true;
        }

        return retval;

    }

    @Override
    public Class<DmlesToken> getTokenType() {
        return DmlesToken.class;
    }
    
}
