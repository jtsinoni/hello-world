package dmles.oauth.server.business;

import dmles.oauth.core.datamodel.DmlesToken;
import dmles.oauth.core.http.RequestUtil;
import dmles.oauth.core.token.TokenBuilder;
import dmles.oauth.core.token.TokenKey;
import dmles.oauth.server.exception.SystemException;
import dmles.user.client.UserService;
import dmles.user.core.IUserService;
import dmles.user.core.clientmodel.CurrentUserPT;
import dmles.user.core.clientmodel.Endpoint;
import mil.jmlfdc.common.exception.InvalidDataException;
import mil.jmlfdc.common.exception.InvalidStateException;
import mil.jmlfdc.common.exception.ObjectNotFoundException;
import org.picketlink.idm.credential.Token;
import org.picketlink.idm.model.Account;
import org.slf4j.Logger;

import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import javax.inject.Inject;

@Stateless
public class TokenProvider implements Token.Provider<DmlesToken> {
    
    @Inject
    private Logger logger;
    @Inject 
    @UserService
    private IUserService userService;
    @Inject
    private TokenBuilder tokenBuilder;
    @Inject
    private RequestUtil requestUtil;
    @Inject
    private TokenKey tokenKey;
    
    @Override
    public DmlesToken issue(Account acnt) {
        DmlesToken token = null;

        if (acnt != null && acnt.getId() != null) {
            String userId = acnt.getId();
            logger.debug("Account id = " + userId);
            CurrentUserPT user;
            List<Endpoint> effectiveEndpoints;
            String clientId = requestUtil.getClientId();
            
            String key;
            try {
                key = tokenKey.getKey(clientId);
            } catch (InvalidDataException ex) {
                try {
                    key = tokenKey.getKey("dmles");
                } catch (InvalidDataException ex1) {
                    throw new SystemException("dmles encryption key not found");
                }
            }
            try {
                user = userService.getUsersCurrentProfile(userId);
                
                effectiveEndpoints = 
                        userService.getEffectiveEndpoints(user.id);
            
            } catch (ObjectNotFoundException | InvalidStateException ex) {
                // there is not an active user 
                user = new CurrentUserPT();
                user.pkiDn = userId;
                user.id = "";
                user.firstName = "";
                user.lastName = "";
                user.serviceCode = "";
                user.userType = "";
                user.serviceCode = "";
                user.regionCode = "";
                effectiveEndpoints = new ArrayList<>();
                Endpoint endpoint = new Endpoint();
                endpoint.businessMethod = "/V1/unsecured/register";
                effectiveEndpoints.add(endpoint);
                
            }
            
            String tokString = tokenBuilder.buildToken(user, userId,
                            effectiveEndpoints,
                            tokenBuilder.getDefaultExpiration(),
                            clientId, key);
            token = new DmlesToken(tokString);
        }

        return token;
    }
    
    /**
     * The renew method re-issues the token.
     *
     * @param acnt picketlink idm account
     * @param token Dmles tokens
     * @return returns a DmlesToken
     */
    @Override
    public DmlesToken renew(Account acnt, DmlesToken token) {

        DmlesToken retval = issue(acnt);

        return retval;
    }

    /**
     * Returns the type of token.
     *
     * @return Type equals DmlesToken
     */
    @Override
    public Class<DmlesToken> getTokenType() {
        return DmlesToken.class;
    }

    @Override
    public void invalidate(Account acnt) {

        throw new UnsupportedOperationException("Not supported yet.");
    }

}
