package dmles.oauth.server.business;

import dmles.oauth.core.datamodel.DmlesIdentity;
import org.picketlink.annotations.PicketLink;
import org.picketlink.authentication.BaseAuthenticator;
import org.picketlink.credential.DefaultLoginCredentials;
import org.picketlink.idm.credential.Credentials;
import org.picketlink.idm.model.Account;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;

@PicketLink
public class Authenticator extends BaseAuthenticator {

    @Inject
    DefaultLoginCredentials credentials;

    private static final Logger LOGGER = LoggerFactory.getLogger(Authenticator.class);

    @Override
    public void authenticate() {

        LOGGER.debug("Custom Authenticator called");
        
        if (credentials != null && credentials.getUserId() != null) {
            LOGGER.debug("Credentials status sent to VALID");
            String userId = credentials.getUserId();
            Object cred = credentials.getCredential();
            credentials.setStatus(Credentials.Status.VALID);
        } else {
            LOGGER.debug("Credentials status sent to INVALID");
            credentials.setStatus(Credentials.Status.INVALID);
        }
    }

    @Override
    public AuthenticationStatus getStatus() {
        LOGGER.debug("getStatus called");
        if (credentials != null && credentials.getStatus().equals(Credentials.Status.VALID)) {
            LOGGER.debug("Authentication status VALID");
            return Authenticator.AuthenticationStatus.SUCCESS;
        } else {
            LOGGER.debug("Authentication status INVALID");
            return Authenticator.AuthenticationStatus.FAILURE;
        }
    }

    @Override
    public Account getAccount() {
        DmlesIdentity user = new DmlesIdentity();

        if (credentials != null && credentials.getStatus().equals(Credentials.Status.VALID)) {
            user.setId(credentials.getUserId());
        }

        return user;
    }
}
