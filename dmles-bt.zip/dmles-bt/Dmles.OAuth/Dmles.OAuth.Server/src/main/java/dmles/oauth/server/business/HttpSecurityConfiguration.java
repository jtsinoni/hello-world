package dmles.oauth.server.business;

import org.picketlink.config.SecurityConfigurationBuilder;
import org.picketlink.event.SecurityConfigurationEvent;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.event.Observes;

@ApplicationScoped
public class HttpSecurityConfiguration {

    public void onInit(@Observes SecurityConfigurationEvent event) {
        SecurityConfigurationBuilder builder = event.getBuilder();
        
        builder
            .identity()
                .stateless()
            .http()
                .forPath("/token")
                    .authenticateWith()
                        .token()
                    .cors()
                        .allowAll();
    }

}
