/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dmles.abi.core.datamodel;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.util.Date;
import mil.jmlfdc.common.constants.DateAndTime;

public class PingData {
    public String message;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateAndTime.DATE_TIME_PATTERN)
    public Date createdDate;
}
