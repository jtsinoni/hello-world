package dmles.abi.core.datamodel.staging.join;

import dmles.abi.core.datamodel.staging.ABiCatalogStagingRecord;
import java.util.List;

public class JoinRecordCommand {
    public String mode;
    public List<String> childRecords;
    public ABiCatalogStagingRecord masterRecord;
}
