package dmles.abi.core.datamodel.taxonomy;

import com.fasterxml.jackson.annotation.JsonProperty;

public class UnspscCommodity {
    @JsonProperty("segment")
    public String segmentId;
    
    @JsonProperty("family")
    public String familyId;
    
    @JsonProperty("class")
    public String classId;
    
    @JsonProperty("commodity")
    public String commodityId;
    public String commodityTitle;
    public String definition;
}
//{
//    "_id" : "10151912",
//    "@version" : "1",
//    "@timestamp" : "2016-12-16T05:58:30.766Z",

//    "segment" : "10000000",
//    "segmentTitle" : "Live Plant and Animal Material and Accessories and Supplies",

//    "family" : "10150000",
//    "familyTitle" : "Seeds and bulbs and seedlings and cuttings",

//    "class" : "10151900",
//    "classTitle" : "Flower seeds and bulbs and seedlings and cuttings",

//    "key" : "177679",

//    "commodity" : "10151912",
//    "commodityTitle" : "Ivy leaf geranium seeds or seedlings",

//    "definition" : "Seeds from the geraniaceae family plant"
//}
