package dmles.abi.core.datamodel.staging;

import java.util.ArrayList;
import java.util.List;

public class JoinStagingRecordsState {
    public List<ABiCatalogStagingRecord> joinCandidates;
    public int preferredRecordIndex;
    public ABiCatalogStagingRecord masterRecord;
    
    public JoinStagingRecordsState() {
        joinCandidates = new ArrayList<>();
    }
}
