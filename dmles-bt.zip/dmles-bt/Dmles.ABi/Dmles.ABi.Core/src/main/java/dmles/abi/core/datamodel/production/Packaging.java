package dmles.abi.core.datamodel.production;

import java.math.BigDecimal;
import java.util.Date;

public class Packaging {
    public Integer ipPackSerial;
    public BigDecimal burdenedPriceAmt;
    public Date createDt;
    public String createUserId;
    public Integer ecatItemId;
    public Integer ipPackLevel;
    public String ipPackCd;
    public Integer ipPackQty;
    public String ipGtin;
    public Date lastUpdateDt;
    public String lastUpdateUserId;
    public String lowUomInd;
    public Integer maximumOrderQty;
    public String medAirBridgeInd;
    public Integer minimumOrderQty;
    public Integer multipleOrderQty;
    public String nsn;
    public String packCubeUomCd;
    public Integer packCubeVol;
    public Integer packLengthDm;
    public String packLengthUomCd;
    public Integer packGrossWeight;
    public String packGrossWeightUomCd;
    public Integer packHeightDm;
    public String packHeightUomCd;
    public BigDecimal packPriceAmt;
    public Integer packWidthDm;
    public String packWidthUomCd;
    public Date priceEffDt;
    public Date priceExpDt;
    public Integer productSourcePriceSeqId;
    public BigDecimal taxAmt;
    public String sosCd;
    public Integer sosSerial;
}
