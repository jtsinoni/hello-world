package dmles.abi.core.datamodel.staging;

public class CommodityClass {
    public String id;
    public String commodityClassName;
    public String commodityType;
    public String militaryServiceCode;
}
