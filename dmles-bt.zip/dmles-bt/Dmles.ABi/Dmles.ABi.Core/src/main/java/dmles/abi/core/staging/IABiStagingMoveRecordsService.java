package dmles.abi.core.staging;

import dmles.abi.core.datamodel.PingData;
import dmles.abi.core.datamodel.staging.ABiCatalogStagingRecord;
import dmles.abi.core.datamodel.staging.MoveRecordsResponse;
import dmles.abi.core.datamodel.staging.join.StagingRecordByMmc;
import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

@Path("/V1/staging/moveRecords")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public interface IABiStagingMoveRecordsService {
    @GET
    @Path("/getPing")
    PingData getPing();
    
    @GET
    @Path("/getInUseRecordListCount")
    Long getInUseRecordListCount();
    
    @GET
    @Path("/getInUseRecordList")
    List<ABiCatalogStagingRecord> getInUseRecordList(@QueryParam("startIndex") int startIndex, 
                            @QueryParam("numEntriesToReturn") int numEntriesToReturn);

    @GET
    @Path("/getGHXStagingRecordListCount")
    Long getGHXStagingRecordListCount();
    
    @GET
    @Path("/getGHXStagingRecordList")
    List<ABiCatalogStagingRecord> getGHXStagingRecordList(@QueryParam("startIndex") int startIndex, 
                            @QueryParam("numEntriesToReturn") int numEntriesToReturn);
    
    @GET
    @Path("/getStagingRecordsMatchingSiteCatalogCount")
    Long getStagingRecordsMatchingSiteCatalogCount();
   
    @GET
    @Path("/getStagingRecordsMatchingSiteCatalogList")
    List<ABiCatalogStagingRecord> getStagingRecordsMatchingSiteCatalogList(@QueryParam("startIndex") int startIndex, 
                            @QueryParam("numEntriesToReturn") int numEntriesToReturn);
    
    @GET
    @Path("/getStagingRecordsMatchingSiteCatalogProductSeqIdCount")
    Long getStagingRecordsMatchingSiteCatalogProductSeqIdCount();
   
    @GET
    @Path("/getStagingRecordsMatchingSiteCatalogProductSeqIdList")
    List<ABiCatalogStagingRecord> getStagingRecordsMatchingSiteCatalogProductSeqIdList(@QueryParam("startIndex") int startIndex, 
                            @QueryParam("numEntriesToReturn") int numEntriesToReturn);

    
    @GET
    @Path("/getStagingRecordsMatchingSiteCatalogNdcCount")
    Long getStagingRecordsMatchingSiteCatalogNdcCount();
   
    @GET
    @Path("/getStagingRecordsMatchingSiteCatalogNdcList")
    List<ABiCatalogStagingRecord> getStagingRecordsMatchingSiteCatalogNdcList(@QueryParam("startIndex") int startIndex, 
                            @QueryParam("numEntriesToReturn") int numEntriesToReturn);

    @GET
    @Path("/markGHXStagingRecordsForProduction")
    Long markGHXStagingRecordsForProduction();
    
    @GET
    @Path("/markStagingRecordsMatchingSiteCatalogForProduction")
    Long markStagingRecordsMatchingSiteCatalogForProduction();
    
    @GET
    @Path("/markStagingRecordsMatchingSiteCatalogProdSeqIdForProduction")
    Long markStagingRecordsMatchingSiteCatalogProdSeqIdForProduction();
    
    @GET
    @Path("/markStagingRecordsMatchingSiteCatalogNdcForProduction")
    Long markStagingRecordsMatchingSiteCatalogNdcForProduction();
    
    @GET
    @Path("/resetInUseRecordList")
    Long resetInUseRecordList();
    
    @POST
    @Path("/moveStagingRecordsToProduction")
    MoveRecordsResponse moveStagingRecordsToProduction(List<String> idList);
    
    @GET
    @Path("/moveApprovedStagingRecordsToProduction")
    MoveRecordsResponse moveApprovedStagingRecordsToProduction();
}
