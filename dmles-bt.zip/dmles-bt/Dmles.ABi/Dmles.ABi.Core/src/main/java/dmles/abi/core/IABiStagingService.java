/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dmles.abi.core;

import dmles.abi.core.datamodel.PingData;
import dmles.abi.core.datamodel.staging.ABiCatalogStagingRecord;
import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/V1/staging")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public interface IABiStagingService {

    @GET
    @Path("/getPing")
    PingData getPing();
 
    @GET
    @Path("/searchRecords")
    List<ABiCatalogStagingRecord> searchRecords(@QueryParam("filterData") String filterData);

    @GET
    @Path("/findRecordsJson")
    Response findRecordsJson(@QueryParam("startIndex") int startIndex, 
                            @QueryParam("numEntriesToReturn") int numEntriesToReturn);
    
    @POST
    @Path("/updateRecord")
    ABiCatalogStagingRecord updateRecord(ABiCatalogStagingRecord updatedRecord);

    @GET
    @Path("/createRecord")
    ABiCatalogStagingRecord createRecord();
    
    @GET
    @Path("/getProductStatusList")
    List<String> getProductStatusList();
    
    @GET
    @Path("/getDisposableReusableList")
    List<String> getDisposableReusableList();
    
    @GET
    @Path("/getSterileNonSterileList")
    List<String> getSterileNonSterileList();
    
    @GET
    @Path("/getHazardCodeList")
    List<String> getHazardCodeList();
    
    @GET
    @Path("/getLatexCodeList")
    List<String> getLatexCodeList();
    
    @GET
    @Path("/getGenderList")
    List<String> getGenderList();
}
