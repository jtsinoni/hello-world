package dmles.abi.core.datamodel.production;

public class SearchInput {    
    public String queryString;
    public String aggregations;    
}