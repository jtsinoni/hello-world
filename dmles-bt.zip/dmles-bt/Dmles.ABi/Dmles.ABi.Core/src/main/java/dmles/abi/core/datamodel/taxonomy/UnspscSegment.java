package dmles.abi.core.datamodel.taxonomy;

import com.fasterxml.jackson.annotation.JsonProperty;

public class UnspscSegment {
    @JsonProperty("segment")
    public String segmentId;
    public String segmentTitle;
}

