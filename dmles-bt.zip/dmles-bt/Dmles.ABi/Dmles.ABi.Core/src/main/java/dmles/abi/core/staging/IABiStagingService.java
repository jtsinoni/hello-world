package dmles.abi.core.staging;

import dmles.abi.core.datamodel.PingData;
import dmles.abi.core.datamodel.staging.ABiCatalogStagingRecord;
import dmles.abi.core.datamodel.staging.ABiCatalogStatistics;
import dmles.abi.core.datamodel.staging.ApprovalResult;
import dmles.abi.core.datamodel.staging.ApprovalStatus;
import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/V1/staging")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public interface IABiStagingService {

    @GET
    @Path("/getPing")
    PingData getPing();
 
    @GET
    @Path("/searchRecords")
    List<ABiCatalogStagingRecord> searchRecords(@QueryParam("mode") String mode, 
            @QueryParam("filterData") String filterData);

    @GET
    @Path("/findRecordsJson")
    Response findRecordsJson(@QueryParam("startIndex") int startIndex, 
                            @QueryParam("numEntriesToReturn") int numEntriesToReturn);
    
    @POST
    @Path("/updateRecord")
    ABiCatalogStagingRecord updateRecord(ABiCatalogStagingRecord updatedRecord);

    @GET
    @Path("/createRecord")
    ABiCatalogStagingRecord createRecord();
    
    @GET
    @Path("/getStatistics")
    ABiCatalogStatistics getStatistics();
    
    @POST
    @Path("/canRecordBeApproved")
    ApprovalStatus canRecordBeApproved(ABiCatalogStagingRecord recordToApprove);
    
    @POST
    @Path("/approveRecord")
    ApprovalResult approveRecord(ABiCatalogStagingRecord recordToApprove);
}
