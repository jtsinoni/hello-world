package dmles.abi.core.datamodel.taxonomy;

import java.util.ArrayList;
import java.util.List;

public class UnspscFamilyHierarchy extends UnspscFamily {
    public List<UnspscClassHierarchy> classes;
    public UnspscFamilyHierarchy() {
        super();
        classes = new ArrayList<>();
    }
}
