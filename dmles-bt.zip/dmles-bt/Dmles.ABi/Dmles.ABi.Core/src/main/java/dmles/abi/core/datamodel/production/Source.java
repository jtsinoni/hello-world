package dmles.abi.core.datamodel.production;

public class Source {
    public Integer sosSerial;
    public String sosCd;
    public String sosTypeCd;
    public String supplierNm;
    public String typeItemId;
    public String vendItemNum;
    public Integer ipPackSerial;
    public String dropShipFeeInd;
    public String dropShipOnlyInd;
}
