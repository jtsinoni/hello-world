package dmles.abi.core.datamodel.staging;

public class ProductIdentifier {
    public String identifier;
    public String identifierType;
}
