package dmles.abi.core.datamodel.staging;

public class ProductIdentifier {
    public String identifier;
    public String identifierType;

    public ProductIdentifier() { }
    
    public ProductIdentifier(ProductIdentifier source) {
        this.identifier = source.identifier;
        this.identifierType = source.identifierType;
    }
}
