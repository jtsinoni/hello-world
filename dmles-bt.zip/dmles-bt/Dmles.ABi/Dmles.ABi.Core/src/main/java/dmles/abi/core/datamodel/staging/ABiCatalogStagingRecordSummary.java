package dmles.abi.core.datamodel.staging;

public class ABiCatalogStagingRecordSummary {
    public String id;
    public String enterpriseProductIdentifier;
    public String manufacturer;
    public String manufacturerCatalogNumber;
    public String ndc;
    public String shortItemDescription;
    public String productStatus;
    public String catalogSource;

    public ABiCatalogStagingRecordSummary(ABiCatalogStagingRecord record) {
        this.id = record.id;
        this.enterpriseProductIdentifier = record.enterpriseProductIdentifier;
        this.manufacturer = record.manufacturer;
        this.manufacturerCatalogNumber = record.manufacturerCatalogNumber;
        this.ndc = record.ndc;
        this.shortItemDescription = record.shortItemDescription;
        this.productStatus = record.productStatus;
        this.catalogSource = record.catalogSource;
    }
}
