package dmles.abi.core.datamodel.staging;

import java.util.ArrayList;
import java.util.List;

public class MoveRecordsResponse {
    public List<String> idsThatWereMoved;
    public List<String> idsThatWereNotMoved;
    
    public MoveRecordsResponse() {
        idsThatWereMoved = new ArrayList<>();
        idsThatWereNotMoved = new ArrayList<>();
    }
}
