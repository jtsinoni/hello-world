package dmles.abi.core.datamodel.taxonomy;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Date;
import mil.jmlfdc.common.constants.DateAndTime;
import org.mongodb.morphia.annotations.Property;

public class UnspscRecord {
    public String version;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateAndTime.DATE_TIME_PATTERN)
    public Date timestamp;
    
    @JsonProperty("segment")
    @Property("segment")
    public String segmentId;
    public String segmentTitle;
    
    @JsonProperty("family")
    @Property("family")
    public String familyId;
    public String familyTitle;
    
    @JsonProperty("class")
    @Property("class")
    public String classId;
    public String classTitle;
    
    public String key;

    @JsonProperty("commodity")
    @Property("commodity")
    public String commodityId;
    public String commodityTitle;
    public String definition;
}
