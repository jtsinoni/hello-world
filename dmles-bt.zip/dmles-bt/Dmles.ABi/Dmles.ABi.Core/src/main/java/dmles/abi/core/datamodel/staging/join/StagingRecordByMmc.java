package dmles.abi.core.datamodel.staging.join;

import dmles.abi.core.datamodel.staging.ABiCatalogStagingRecordSummary;
import java.util.ArrayList;
import java.util.List;

public class StagingRecordByMmc {
    public String mmcId;
    public int count;
    public List<ABiCatalogStagingRecordSummary> stagingRecords;
    
    public StagingRecordByMmc() {
        this.stagingRecords = new ArrayList<>();
    }
}
