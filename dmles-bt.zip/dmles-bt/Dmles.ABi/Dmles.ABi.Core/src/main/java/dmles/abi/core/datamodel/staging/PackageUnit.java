package dmles.abi.core.datamodel.staging;

public class PackageUnit {
    public String id;
    public String ansiPackUnit;
    public String dodPackUnit;
    public String packText;
    public boolean inUse;
}
