package dmles.abi.core.datamodel.production;

public class ItemRestriction {
    public String restrictCd;
    public String restrictDescription;
    public String restrictType;
}
