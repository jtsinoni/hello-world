package dmles.abi.core.datamodel.taxonomy;

import java.util.ArrayList;
import java.util.List;

public class UnspscSegmentHierarchy extends UnspscSegment {
    public List<UnspscFamilyHierarchy> families;
    public UnspscSegmentHierarchy() {
        super();
        families = new ArrayList<>();
    }
}
