package dmles.abi.core.datamodel.staging;

public class ABiCatalogStatistics {
    public Long stagingRecordCount;
    public Long productionCandidateCount;
    public Long mergedRecordsCount;
    public Long awaitingApprovalCount;
    public Long approvedCount;
    public Long publishedCount;
}
