package dmles.abi.core.datamodel.staging;

import java.util.ArrayList;
import java.util.List;

public class ApprovalStatus {
    public boolean isApproved;
    public List<String> messageList;
    
    public ApprovalStatus() {
        messageList = new ArrayList<String>();
    }
}
