package dmles.abi.core.datamodel.taxonomy;

import java.util.ArrayList;
import java.util.List;

public class UnspscClassHierarchy extends UnspscClass {
    public List<UnspscCommodity> commodities;
    public UnspscClassHierarchy() {
        super();
        commodities = new ArrayList<>();
    }
}
