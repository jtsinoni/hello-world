package dmles.abi.core.datamodel.staging;

import com.fasterxml.jackson.annotation.JsonFormat;
import mil.jmlfdc.common.constants.DateAndTime;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ABiCatalogStagingRecord {
    public String id;
    public String enterpriseProductIdentifier;
    public String clinicalDescription;
    public String shortItemDescription;
    public String longItemDescription;
    public String fullDescription;
    public String manufacturer;
    public String manufacturerCatalogNumber;
    public String ndc;
    public Integer ghxProductIdentifier;
    public Integer mmcProductIdentifier;
    public String commodityType;
    public String productStatus;
    public String recordStatus;
// Removed the following attributes on 23Mar2017
//    public String unitOfUsePackageUnit;
//    public String unitOfUseUnit;
//    public Integer unitOfUseQuantity;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateAndTime.DATE_TIME_PATTERN)
    public Date publishedDate;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateAndTime.DATE_TIME_PATTERN)
    public Date updatedDate;
    public String approvedBy;
    public String approvalNote;
    public Integer unspscCode;
    public String unspscSegment;
    public String unspscFamily;
    public String unspscClass;
    public String unspscCommodity;
    public String hcpcsCode;
    public String hcpcsDescription;
    public String hcpcsStatus;
    public String productNoun;
    public String productType;
    public String age;
    public String gender;
    public String sizeShape;
    public String color;
    public String flavor;
    public String fragrance;
    public String sterileNonsterile;
    public String hazardCode;
    public String latexCode;
    public String disposableReusable;
    public String productUrl;
    // Changed to String on 15Mar2017
    public String mmcPreferredProductIdentifier;
    public String diameter;
    public String volume;
    public String weight;
    public String lengthWidthHeight;
    public String lengthWidthHeight2;
    public String brandGeneric;
    public String deaCode;
    public String dosageForm;
    public String drugCategory;
    public String drugStorageType;
    public String drugStrength;
    public String drugUnit;
    public Integer genericId;
    public String genericName;
    public String offMarket;
    public String spDrugCode;
    public Integer upc;
    public String ecriDeviceCode;
    public String ecriStandardizedProduct;
    public String ecriStandardizedCatalogNumber;
    public String ecriStandardizedManufacturer;
    public String ghxManufacturer;
    public String scriptproManufacturer;

    public String catalogSource;

    
    public List<String> productComposition = new ArrayList<>();
    public List<String> productProperties = new ArrayList<>();
    public List<String> locations = new ArrayList<>();
    public List<String> miscellaneous = new ArrayList<>();
    public List<String> productImages = new ArrayList<>();
    public List<String> trademarkBrandnames = new ArrayList<>();
    public List<String> otherManufacturerNames = new ArrayList<>();
    public List<ProductIdentifier> secondaryProductIdentifiers = new ArrayList<>();
    public List<PackagingDetail> packaging = new ArrayList<>();
    
    // Added the following attributes on 11Mar2017
    public String enterpriseProductIdentifierType;
    public String productSubstituteGroup;
    public String productGroup;
    public String ecriGuid;
    public List<ProductDocument> productDocumentation = new ArrayList<>();

    // Added the following attributes on 15Mar2017
    public String mergedTo;
    public String packagingDescription;

    // Added the following attributes on 23Mar2017
    public String netContentText;
    public Integer netContentQuantity;
    
    public ABiCatalogStagingRecord() { } 
    
    public ABiCatalogStagingRecord(ABiCatalogStagingRecord source) {
        this.id = source.id;
        this.enterpriseProductIdentifier = source.enterpriseProductIdentifier;
        this.clinicalDescription = source.clinicalDescription;
        this.shortItemDescription = source.shortItemDescription;
        this.longItemDescription = source.longItemDescription;
        this.fullDescription = source.fullDescription;
        this.manufacturer = source.manufacturer;
        this.manufacturerCatalogNumber = source.manufacturerCatalogNumber;
        this.ndc = source.ndc;
        this.ghxProductIdentifier = source.ghxProductIdentifier;
        this.mmcProductIdentifier = source.mmcProductIdentifier;
        this.commodityType = source.commodityType;
        this.productStatus = source.productStatus;
        this.recordStatus = source.recordStatus;
//        this.unitOfUsePackageUnit = source.unitOfUsePackageUnit;
//        this.unitOfUseUnit = source.unitOfUseUnit;
//        this.unitOfUseQuantity = source.unitOfUseQuantity;
        this.publishedDate = source.publishedDate;
        this.updatedDate = source.updatedDate;
        this.approvedBy = source.approvedBy;
        this.approvalNote = source.approvalNote;
        this.unspscCode = source.unspscCode;
        this.unspscSegment = source.unspscSegment;
        this.unspscFamily = source.unspscFamily;
        this.unspscClass = source.unspscClass;
        this.unspscCommodity = source.unspscCommodity;
        this.hcpcsCode = source.hcpcsCode;
        this.hcpcsDescription = source.hcpcsDescription;
        this.hcpcsStatus = source.hcpcsStatus;
        this.productNoun = source.productNoun;
        this.productType = source.productType;
        this.age = source.age;
        this.gender = source.gender;
        this.sizeShape = source.sizeShape;
        this.color = source.color;
        this.flavor = source.flavor;
        this.fragrance = source.fragrance;
        this.sterileNonsterile = source.sterileNonsterile;
        this.hazardCode = source.hazardCode;
        this.latexCode = source.latexCode;
        this.disposableReusable = source.disposableReusable;
        this.productUrl = source.productUrl;
        this.mmcPreferredProductIdentifier = source.mmcPreferredProductIdentifier;
        this.diameter = source.diameter;
        this.volume = source.volume;
        this.weight = source.weight;
        this.lengthWidthHeight = source.lengthWidthHeight;
        this.lengthWidthHeight2 = source.lengthWidthHeight2;
        this.brandGeneric = source.brandGeneric;
        this.deaCode = source.deaCode;
        this.dosageForm = source.dosageForm;
        this.drugCategory = source.drugCategory;
        this.drugStorageType = source.drugStorageType;
        this.drugStrength = source.drugStrength;
        this.drugUnit = source.drugUnit;
        this.genericId = source.genericId;
        this.genericName = source.genericName;
        this.offMarket = source.offMarket;
        this.spDrugCode = source.spDrugCode;
        this.upc = source.upc;
        this.ecriDeviceCode = source.ecriDeviceCode;
        this.ecriStandardizedProduct = source.ecriStandardizedProduct;
        this.ecriStandardizedCatalogNumber = source.ecriStandardizedCatalogNumber;
        this.ecriStandardizedManufacturer = source.ecriStandardizedManufacturer;
        this.ghxManufacturer = source.ghxManufacturer;
        this.scriptproManufacturer = source.scriptproManufacturer;

        this.catalogSource = source.catalogSource;

        if (source.productComposition != null) {
            this.productComposition.addAll(source.productComposition);
        }
        if (source.productProperties != null) {
            this.productProperties.addAll(source.productProperties);
        }
        if (source.locations != null) {
            this.locations.addAll(source.locations);
        }
        if (source.miscellaneous != null) {
            this.miscellaneous.addAll(source.miscellaneous);
        }
        if (source.productImages != null) {
            this.productImages.addAll(source.productImages);
        }
        if (source.trademarkBrandnames != null) {
            this.trademarkBrandnames.addAll(source.trademarkBrandnames);
        }
        if (source.otherManufacturerNames != null) {
            this.otherManufacturerNames.addAll(source.otherManufacturerNames);
        }

        if (source.secondaryProductIdentifiers != null) {
            for (ProductIdentifier prodId : source.secondaryProductIdentifiers) {
                this.secondaryProductIdentifiers.add(new ProductIdentifier(prodId));
            }
        }

        if (source.packaging != null) {
            for (PackagingDetail pck : source.packaging) {
                this.packaging.add(new PackagingDetail(pck));
            }
        }

        this.enterpriseProductIdentifierType = source.enterpriseProductIdentifierType;
        this.productSubstituteGroup = source.productSubstituteGroup;
        this.productGroup = source.productGroup;
        this.ecriGuid = source.ecriGuid;
        
        if (source.productDocumentation != null) {
            for (ProductDocument pdoc : source.productDocumentation) {
                this.productDocumentation.add(new ProductDocument(pdoc));
            }
        }
        
        this.netContentText = source.netContentText;
        this.netContentQuantity = source.netContentQuantity;
    }
}
