package dmles.abi.core.datamodel.staging;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import mil.jmlfdc.common.constants.DateAndTime;

public class ABiCatalogStagingRecord {
    public String id;
    public String clinicalDescription;
    public String shortItemDescription;
    public String longItemDescription;
    public String fullDescription;
    public String manufacturer;
    public String manufacturerCatalogNumber;
    public String ndc;
    public String ghxProductIdentifier;
    public String mmcProductIdentifier;
    public String commodityType;
    public String productStatus;
    public String recordStatus;
    public String unitOfUsePackageUnit;
    public String unitOfUseUnit;
    public String unitOfUseQuantity;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateAndTime.DATE_TIME_PATTERN)
    public Date publishedDate;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateAndTime.DATE_TIME_PATTERN)
    public Date updatedDate;
    public String approvedBy;
    public String approvalNote;
    public String unspscCode;
    public String unspscSegment;
    public String unspscFamily;
    public String unspscClass;
    public String unspscCommodity;
    public String hcpcsCode;
    public String hcpcsDescription;
    public String hcpcsStatus;
    public String productNoun;
    public String productType;
    public String age;
    public String gender;
    public String sizeShape;
    public String color;
    public String flavor;
    public String fragrance;
    public String sterileNonsterile;
    public String hazardCode;
    public String latexCode;
    public String disposableReusable;
    public String productUrl;
    public String preferredProductIdentifier;
    public String diameter;
    public String volume;
    public String weight;
    public String lengthWidthHeight;
    public String lengthWidthHeight2;
    public String brandGeneric;
    public String deaCode;
    public String dosageForm;
    public String drugCategory;
    public String drugStorageType;
    public String drugStrength;
    public String drugUnit;
    public String genericId;
    public String genericName;
    public String offMarket;
    public String spDrugCode;
    public String ecriDeviceCode;
    public String ecriStandardizedProduct;
    public String ecriStandardizedCatalogNumber;
    public String ecriStandardizedManufacturer;
    public String ghxManufacturer;
    public String scriptproManufacturer;

    public String catalogSource;

    
    public List<String> productComposition = new ArrayList<>();
    public List<String> productProperties = new ArrayList<>();
    public List<String> locations = new ArrayList<>();
    public List<String> miscellaneous = new ArrayList<>();
    public List<String> productImages = new ArrayList<>();
    public List<String> trademarkBrandnames = new ArrayList<>();
    public List<String> otherManufacturerNames = new ArrayList<>();
    public List<ProductIdentifier> secondaryProductIdentifiers = new ArrayList<>();
    public List<PackagingDetail> packaging = new ArrayList<>();
}
