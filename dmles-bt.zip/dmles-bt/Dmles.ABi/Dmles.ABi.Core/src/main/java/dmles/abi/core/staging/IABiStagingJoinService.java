package dmles.abi.core.staging;

import dmles.abi.core.datamodel.PingData;
import dmles.abi.core.datamodel.staging.ABiCatalogStagingRecord;
import dmles.abi.core.datamodel.staging.join.InitiateJoinSettings;
import dmles.abi.core.datamodel.staging.join.JoinRecordCommand;
import dmles.abi.core.datamodel.staging.join.JoinStagingRecordsState;
import dmles.abi.core.datamodel.staging.join.StagingRecordByMmc;
import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

@Path("/V1/staging/join")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public interface IABiStagingJoinService {

    @GET
    @Path("/getPing")
    PingData getPing();
    
    @GET
    @Path("/getMergePossibilitiesByMmc")
    List<StagingRecordByMmc> getMergePossibilitiesByMmc();
    
    @POST
    @Path("/initiateJoinRecordProcess")
    JoinStagingRecordsState initiateJoinRecordProcess(InitiateJoinSettings settings);
    
    @POST
    @Path("/processJoinRecordCommand")
    ABiCatalogStagingRecord processJoinRecordCommand(JoinRecordCommand joinRecordCommand);
    
    @GET
    @Path("/undoMerge")
    List<ABiCatalogStagingRecord> undoMerge(@QueryParam("masterRecordId") String masterRecordId);
    
    @GET
    @Path("/getMergedRecordList")
    List<ABiCatalogStagingRecord> getMergedRecordList(@QueryParam("filterData") String filterData);
            
}
