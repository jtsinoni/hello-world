package dmles.abi.core.datamodel.staging;

import java.util.ArrayList;
import java.util.List;

public class PackagingDetail {

    public String enterprisePackageIdentifier;
    public String gtin;
    public String niin;
    public String nsn;
    public List<ProductIdentifier> otherPackageIdentifiers = new ArrayList<>();
    public String packageUnit;
    public String packageQuantity;
    public String gudidIdentifierType;
    public List<BarcodeItem> barcodeData = new ArrayList<>();
}
