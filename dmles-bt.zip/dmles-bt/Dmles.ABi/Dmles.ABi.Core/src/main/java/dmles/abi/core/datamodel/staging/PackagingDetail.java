package dmles.abi.core.datamodel.staging;

import java.util.ArrayList;
import java.util.List;

public class PackagingDetail {

    public String enterprisePackageIdentifier;
    public String gtin;
// Removed on 23Mar2017
//    public String niin;
//    public String nsn;
    public List<ProductIdentifier> otherPackageIdentifiers = new ArrayList<>();
    public String packageUnit;
    public Integer packageQuantity;
    public String gudidIdentifierType;
    public List<String> barcodeData = new ArrayList<>();
    
// Removed on 23Mar2017
//    public String unitDescription;

    // Added on 23Mar2017
    public String packageUnitText;
    public String packageUnitDescription;
    public Integer doseOrUseCount;
    public Integer innerPackMultiple;
    public List<String> nsn = new ArrayList<>();
    
    public PackagingDetail() { }
    
    public PackagingDetail(PackagingDetail source) {
        this.enterprisePackageIdentifier = source.enterprisePackageIdentifier;
        this.gtin = source.gtin;
//        this.niin = source.niin;
//        this.nsn = source.nsn;
//        this.unitDescription = source.unitDescription;
        this.packageUnit = source.packageUnit;
        this.packageQuantity = source.packageQuantity;
        this.gudidIdentifierType = source.gudidIdentifierType;
        
        if (source.otherPackageIdentifiers != null) {
            for (ProductIdentifier pi : source.otherPackageIdentifiers) {
                this.otherPackageIdentifiers.add(new ProductIdentifier(pi));
            }
        }
        
        if (source.barcodeData != null) {
            for (String bd : source.barcodeData) {
                this.barcodeData.add(bd);
            }
        }
        
        this.packageUnitText = source.packageUnitText;
        this.packageUnitDescription = source.packageUnitDescription;
        this.doseOrUseCount = source.doseOrUseCount;
        this.innerPackMultiple = source.innerPackMultiple;
        
        if (source.nsn != null) {
            for (String nsn : source.nsn) {
                this.nsn.add(nsn);
            }
        }
    }
}
