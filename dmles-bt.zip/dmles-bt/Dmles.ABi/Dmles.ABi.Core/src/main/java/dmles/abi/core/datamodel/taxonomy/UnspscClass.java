package dmles.abi.core.datamodel.taxonomy;

import com.fasterxml.jackson.annotation.JsonProperty;

public class UnspscClass {
    @JsonProperty("segment")
    public String segmentId;
    
    @JsonProperty("family")
    public String familyId;
    
    @JsonProperty("class")
    public String classId;
    public String classTitle;
}
