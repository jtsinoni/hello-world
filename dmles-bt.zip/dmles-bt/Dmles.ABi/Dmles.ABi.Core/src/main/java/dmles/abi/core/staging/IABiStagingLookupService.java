package dmles.abi.core.staging;

import dmles.abi.core.datamodel.PingData;
import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

@Path("/V1/staging/lookup")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public interface IABiStagingLookupService {

    @GET
    @Path("/getPing")
    PingData getPing();
    
    @GET
    @Path("/getProductStatusList")
    List<String> getProductStatusList();
    
    @GET
    @Path("/getDisposableReusableList")
    List<String> getDisposableReusableList();
    
    @GET
    @Path("/getSterileNonSterileList")
    List<String> getSterileNonSterileList();
    
    @GET
    @Path("/getHazardCodeList")
    List<String> getHazardCodeList();
    
    @GET
    @Path("/getLatexCodeList")
    List<String> getLatexCodeList();
    
    @GET
    @Path("/getGenderList")
    List<String> getGenderList();
    
    @GET
    @Path("/getConfigurableItemList")
    List<String> getConfigurableItemList();
    
    @GET
    @Path("/getCustomizableItemList")
    List<String> getCustomizableItemList();
    
    @GET
    @Path("/getBrandGenericList")
    List<String> getBrandGenericList();
        
    @GET
    @Path("/getDeaCodeList")
    List<String> getDeaCodeList();
    
    @GET
    @Path("/getDosageFormList")
    List<String> getDosageFormList();
        
    @GET
    @Path("/getDrugCategoryCodeList")
    List<String> getDrugCategoryCodeList();
    
    @GET
    @Path("/getManufacturerTypeaheadList")
    List<String> getManufacturerTypeaheadList(@QueryParam("filterData") String filterData);
        
    @GET
    @Path("/getDocumentTypeList")
    List<String> getDocumentTypeList();
    
}
