package dmles.abi.core.datamodel.staging;

public class BarcodeItem {
    public String barcode;
    public String barcodeType;
}
