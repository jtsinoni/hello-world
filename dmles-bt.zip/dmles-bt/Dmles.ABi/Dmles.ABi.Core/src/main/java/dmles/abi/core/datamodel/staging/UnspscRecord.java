package dmles.abi.core.datamodel.staging;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Date;
import mil.jmlfdc.common.constants.DateAndTime;

public class UnspscRecord {
    public String version;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateAndTime.DATE_TIME_PATTERN)
    public Date timestamp;
    public String segment;
    public String segmentTitle;
    public String family;
    public String familyTitle;
    @JsonProperty("class")
    public String classId;
    public String classTitle;
    public String key;
    public String commodity;
    public String commodityTitle;
    public String definition;
}
