package dmles.abi.core;

import dmles.abi.core.datamodel.PingData;
import dmles.abi.core.datamodel.taxonomy.UnspscClass;
import dmles.abi.core.datamodel.taxonomy.UnspscCommodity;
import dmles.abi.core.datamodel.taxonomy.UnspscFamily;
import dmles.abi.core.datamodel.taxonomy.UnspscLevelDetails;
import dmles.abi.core.datamodel.taxonomy.UnspscSegment;
import dmles.abi.core.datamodel.taxonomy.UnspscSegmentHierarchy;
import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

@Path("/V1/taxonomy")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public interface IABiTaxonomyService {

    @GET
    @Path("/getPing")
    PingData getPing();
    
    @GET
    @Path("/getSegments")
    List<UnspscSegment> getSegments();
    
    @GET
    @Path("/getFamilies")
    List<UnspscFamily> getFamilies(@QueryParam("segmentId") String segmentId);
    
    @GET
    @Path("/getClasses")
    List<UnspscClass> getClasses(@QueryParam("familyId") String familyId);
    
    @GET
    @Path("/getCommodities")
    List<UnspscCommodity> getCommodities(@QueryParam("classId") String classId);
    
    @GET
    @Path("/getSegmentHierarchy")
    UnspscSegmentHierarchy getSegmentHierarchy(@QueryParam("segmentId") String segmentId);
    
    @GET
    @Path("/getTaxonomyLevelDetails")
    UnspscLevelDetails getTaxonomyLevelDetails(@QueryParam("level") String level,
                                               @QueryParam("levelId") String levelId);
    
    @GET
    @Path("/getTaxonomyLevelDetailsByUnspscCode")
    UnspscLevelDetails getTaxonomyLevelDetailsByUnspscCode(@QueryParam("unspscCode") Integer unspscCode);
}

// Segment
//   Family
//     Class
//       Commodity


//{
//    "_id" : "10151912",
//    "@version" : "1",
//    "@timestamp" : "2016-12-16T05:58:30.766Z",
//    "segment" : "10000000",
//    "segmentTitle" : "Live Plant and Animal Material and Accessories and Supplies",
//    "family" : "10150000",
//    "familyTitle" : "Seeds and bulbs and seedlings and cuttings",
//    "class" : "10151900",
//    "classTitle" : "Flower seeds and bulbs and seedlings and cuttings",
//    "key" : "177679",
//    "commodity" : "10151912",
//    "commodityTitle" : "Ivy leaf geranium seeds or seedlings",
//    "definition" : "Seeds from the geraniaceae family plant"
//}