package dmles.abi.core.datamodel.staging.join;

import java.util.List;

public class InitiateJoinSettings {
    public List<String> recordIdsToJoin;
    public String preferredRecordId;
}
