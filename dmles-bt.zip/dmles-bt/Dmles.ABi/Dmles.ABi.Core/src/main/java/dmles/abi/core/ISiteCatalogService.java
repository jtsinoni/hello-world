package dmles.abi.core;

import dmles.abi.core.datamodel.PingData;
import dmles.abi.core.datamodel.production.SiteCatalogRecord;
import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

@Path("/V1/sitecatalog")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public interface ISiteCatalogService {

    @GET
    @Path("/getPing")
    PingData getPing();

    @GET
    @Path("/getSiteCatalogByEnterpriseId")
    List<SiteCatalogRecord> getSiteCatalogByEnterpriseId(@QueryParam("enterpriseProductIdentifier") String enterpriseProductIdentifier);

    @GET
    @Path("/getSiteCatalogByProductId")
    List<SiteCatalogRecord> getSiteCatalogByProductId(@QueryParam("productSeqId") Integer productSeqId);

}
