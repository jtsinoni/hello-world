package dmles.abi.core.datamodel.staging;

public class ApprovalResult extends ApprovalStatus {
    public ABiCatalogStagingRecord approvedRecord;
}
