/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dmles.abi.core;

import dmles.abi.core.datamodel.PingData;
import dmles.abi.core.datamodel.production.SearchInput;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/V1/production")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public interface IABiProductionService {

    @POST
    @Path("/getABiCatalogRecordESResults")
    Response getABiCatalogRecordESResults(SearchInput searchInput);

    @GET
    @Path("/getCommodityTypes")
    Response getCommodityTypes();

    @GET
    @Path("/getProductNouns")
    Response getProductNouns();

    @GET
    @Path("/getUnspscSegments")
    Response getUnspscSegments();

    @GET
    @Path("/getPing")
    PingData getPing();
}
