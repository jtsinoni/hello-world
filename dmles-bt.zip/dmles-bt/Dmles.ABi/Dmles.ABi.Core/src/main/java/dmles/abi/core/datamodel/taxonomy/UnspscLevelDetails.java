package dmles.abi.core.datamodel.taxonomy;

public class UnspscLevelDetails {
    public String level;
    public String levelId;
    public String segmentTitle;
    public String familyTitle;
    public String classTitle;
    public String commodityTitle;
}
