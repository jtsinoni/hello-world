package dmles.abi.core.datamodel.taxonomy;

import com.fasterxml.jackson.annotation.JsonProperty;

public class UnspscFamily {
    @JsonProperty("segment")
    public String segmentId;

    @JsonProperty("family")
    public String familyId;
    public String familyTitle;
}
