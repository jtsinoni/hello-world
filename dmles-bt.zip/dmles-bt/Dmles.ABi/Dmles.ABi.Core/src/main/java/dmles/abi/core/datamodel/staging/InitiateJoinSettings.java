package dmles.abi.core.datamodel.staging;

import java.util.List;

public class InitiateJoinSettings {
    public List<String> recordIdsToJoin;
    public String preferredRecordId;
}
