package dmles.abi.client;

import dmles.abi.core.ISiteCatalogService;
import javax.enterprise.context.Dependent;
import mil.jmlfdc.common.business.RestClientFactory;

@Dependent
public class SiteCatalogClientFactory extends RestClientFactory<ISiteCatalogService> {
    public SiteCatalogClientFactory() {
        super(ISiteCatalogService.class, "Dmles.ABi.Server");
    }
}
