package dmles.abi.client;

import dmles.abi.core.IABiTaxonomyService;
import javax.enterprise.context.Dependent;
import mil.jmlfdc.common.business.RestClientFactory;

@Dependent
public class ABiTaxonomyClientFactory extends RestClientFactory<IABiTaxonomyService> {
    public ABiTaxonomyClientFactory(){
        super(IABiTaxonomyService.class, "Dmles.ABi.Server");
    }
}
