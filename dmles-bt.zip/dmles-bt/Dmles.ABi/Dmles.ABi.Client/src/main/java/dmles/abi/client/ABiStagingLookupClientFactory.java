package dmles.abi.client;

import dmles.abi.core.staging.IABiStagingLookupService;
import javax.enterprise.context.Dependent;
import mil.jmlfdc.common.business.RestClientFactory;

@Dependent
public class ABiStagingLookupClientFactory extends RestClientFactory<IABiStagingLookupService> {
    public ABiStagingLookupClientFactory(){
        super(IABiStagingLookupService.class, "Dmles.ABi.Server");
    }
   
}
