package dmles.abi.client;

import dmles.abi.core.staging.IABiStagingJoinService;
import javax.enterprise.context.Dependent;
import mil.jmlfdc.common.business.RestClientFactory;

@Dependent
public class ABiStagingJoinClientFactory extends RestClientFactory<IABiStagingJoinService> {
    public ABiStagingJoinClientFactory(){
        super(IABiStagingJoinService.class, "Dmles.ABi.Server");
    }
}
