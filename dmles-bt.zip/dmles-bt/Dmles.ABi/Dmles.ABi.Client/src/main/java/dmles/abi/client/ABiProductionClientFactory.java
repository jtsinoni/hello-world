/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dmles.abi.client;

import dmles.abi.core.IABiProductionService;
import javax.enterprise.context.Dependent;
import mil.jmlfdc.common.business.RestClientFactory;

@Dependent
public class ABiProductionClientFactory extends RestClientFactory<IABiProductionService> {
    public ABiProductionClientFactory(){
        super(IABiProductionService.class, "Dmles.ABi.Server");
    }
}
