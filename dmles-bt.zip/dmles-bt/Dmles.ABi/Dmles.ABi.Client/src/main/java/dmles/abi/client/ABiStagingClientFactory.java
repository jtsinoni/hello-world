package dmles.abi.client;

import dmles.abi.core.staging.IABiStagingService;
import javax.enterprise.context.Dependent;
import mil.jmlfdc.common.business.RestClientFactory;

@Dependent
public class ABiStagingClientFactory extends RestClientFactory<IABiStagingService> {
    public ABiStagingClientFactory(){
        super(IABiStagingService.class, "Dmles.ABi.Server");
    }
}
