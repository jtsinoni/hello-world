package dmles.abi.server.business;

import dmles.abi.core.datamodel.PingData;
import dmles.abi.core.datamodel.production.SiteCatalogRecord;
import dmles.abi.server.dao.SiteCatalogRecordDao;
import dmles.abi.server.dao.PingDataDao;
import dmles.abi.server.datamodel.PingDataDO;
import dmles.abi.server.datamodel.production.SiteCatalogRecordDO;

import java.util.List;
import javax.ejb.Stateless;
import javax.inject.Inject;

import mil.jmlfdc.common.business.BusinessManager;
import mil.jmlfdc.common.utils.ObjectMapper;
import org.slf4j.Logger;

@Stateless
public class SiteCatalogManager extends BusinessManager {

    @Inject
    private Logger log;

    @Inject
    private PingDataDao pingDataDao;

    @Inject
    private SiteCatalogRecordDao SiteCatalogRecordDao;

    @Inject
    private ObjectMapper objectMapper;

    public PingData getPing() {
        log.info("Pinged the BT SiteCatalogManager!");
        log.info("User: {}", currentUserBt.getPkiDn());
        PingDataDO pingDo = pingDataDao.getPingData("Hello from the SiteCatalogManager...");
        return objectMapper.getObject(PingData.class, pingDo);
    }

    public List<SiteCatalogRecord> getSiteCatalogByProductId(Integer productSeqId) {
        log.info("Start getSiteCatalogByProductId, productSeqId = " + productSeqId);
        List<SiteCatalogRecordDO> dbRecords = SiteCatalogRecordDao.getByProductSeqId(productSeqId);
        log.info("Retrieved: " + dbRecords.size() + " records, calling objectMapper.getList");
        List<SiteCatalogRecord> recordList = objectMapper.getList(SiteCatalogRecord[].class, dbRecords);
        log.info("End objectMapper.getList, return list");
        return recordList;
    }

    public List<SiteCatalogRecord> getSiteCatalogByEnterpriseId(String enterpriseProductIdentifier) {
        log.info("Start getSiteCatalogByEnterpriseId, enterpriseProductIdentifier = " + enterpriseProductIdentifier);
        List<SiteCatalogRecordDO> dbRecords = SiteCatalogRecordDao.getByEnterpriseId(enterpriseProductIdentifier);
        log.info("Retrieved: " + dbRecords.size() + " records, calling objectMapper.getList");
        List<SiteCatalogRecord> recordList = objectMapper.getList(SiteCatalogRecord[].class, dbRecords);
        log.info("End objectMapper.getList, return list");
        return recordList;
    }

}
