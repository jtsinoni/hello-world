package dmles.abi.server.taxonomy.datamodel;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import java.util.Date;
import mil.jmlfdc.common.constants.DateAndTime;
import mil.jmlfdc.common.datamodel.MorphiaEntity;
import org.mongodb.morphia.annotations.Entity;
import org.mongodb.morphia.annotations.Property;

@Entity(value = "unspsc", noClassnameStored = true)
public class UnspscRecordDO extends MorphiaEntity implements Serializable {
    private static long serialVersionUID = 1L;

    private String version;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateAndTime.DATE_TIME_PATTERN)
    private Date timestamp;
    private String segment;
    private String segmentTitle;
    private String family;
    private String familyTitle;
    @JsonProperty("class")
    @Property("class")
    private String classId;
    private String classTitle;
    private String key;
    private String commodity;
    private String commodityTitle;
    private String definition;

    public UnspscRecordDO() {
    }
    
    public String getVersion() {
        return version;
    }
    
    public void setVersion(String version) {
        this.version = version;
    }
    
    public Date getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }

    public String getSegment() {
        return segment;
    }

    public void setSegment(String segment) {
        this.segment = segment;
    }

    public String getSegmentTitle() {
        return segmentTitle;
    }

    public void setSegmentTitle(String segmentTitle) {
        this.segmentTitle = segmentTitle;
    }

    public String getFamily() {
        return family;
    }

    public void setFamily(String family) {
        this.family = family;
    }

    public String getFamilyTitle() {
        return familyTitle;
    }

    public void setFamilyTitle(String familyTitle) {
        this.familyTitle = familyTitle;
    }

    public String getClassId() {
        return classId;
    }

    public void setClassId(String classId) {
        this.classId = classId;
    }

    public String getClassTitle() {
        return classTitle;
    }

    public void setClassTitle(String classTitle) {
        this.classTitle = classTitle;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getCommodity() {
        return commodity;
    }

    public void setCommodity(String commodity) {
        this.commodity = commodity;
    }

    public String getCommodityTitle() {
        return commodityTitle;
    }

    public void setCommodityTitle(String commodityTitle) {
        this.commodityTitle = commodityTitle;
    }

    public String getDefinition() {
        return definition;
    }

    public void setDefinition(String definition) {
        this.definition = definition;
    }
    
}
