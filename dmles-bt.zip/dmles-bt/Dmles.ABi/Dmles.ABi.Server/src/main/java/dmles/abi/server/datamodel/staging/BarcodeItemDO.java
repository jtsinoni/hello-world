package dmles.abi.server.datamodel.staging;

import java.io.Serializable;
import org.mongodb.morphia.annotations.Embedded;

@Embedded
public class BarcodeItemDO implements Serializable {
    private static final long serialVersionUID = 1L;

    private String barcode;
    private String barcodeType;

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public String getBarcodeType() {
        return barcodeType;
    }

    public void setBarcodeType(String barcodeType) {
        this.barcodeType = barcodeType;
    }
    
}
