package dmles.abi.server.staging.dao;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import dmles.abi.server.staging.datamodel.ABiCatalogStagingRecordDO;
import dmles.abi.server.staging.datamodel.CommodityTypeDO;
import java.util.List;
import javax.enterprise.context.Dependent;
import javax.inject.Inject;
import mil.jmlfdc.common.dao.BaseDao;
import org.mongodb.morphia.query.Query;
import org.slf4j.Logger;

@Dependent
public class CommodityTypeDao extends BaseDao<CommodityTypeDO, String> {

    @Inject
    private Logger logger;

    public CommodityTypeDao() {
        super(CommodityTypeDO.class);
    }
    public List<String> getCommodityTypeList() {
        DBCollection m = this.getDatastore().getCollection(CommodityTypeDO.class);
        List<String> valueList = m.distinct("commodityType", new BasicDBObject());
        return valueList;
    }
    
}
