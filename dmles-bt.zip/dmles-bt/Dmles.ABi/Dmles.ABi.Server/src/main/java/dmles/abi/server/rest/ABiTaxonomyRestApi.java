package dmles.abi.server.rest;

import dmles.abi.core.IABiTaxonomyService;
import dmles.abi.core.datamodel.PingData;
import dmles.abi.core.datamodel.taxonomy.UnspscClass;
import dmles.abi.core.datamodel.taxonomy.UnspscCommodity;
import dmles.abi.core.datamodel.taxonomy.UnspscFamily;
import dmles.abi.core.datamodel.taxonomy.UnspscLevelDetails;
import dmles.abi.core.datamodel.taxonomy.UnspscSegment;
import dmles.abi.core.datamodel.taxonomy.UnspscSegmentHierarchy;
import dmles.abi.server.business.ABiProductionManager;
import dmles.abi.server.taxonomy.business.ABiTaxonomyManager;
import io.swagger.annotations.Api;
import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.QueryParam;
import mil.jmlfdc.common.rest.RestApiBase;

@Api(value="ABiTaxonomyRestApi", description="ABI Taxonomy REST API")
@ApplicationScoped
public class ABiTaxonomyRestApi extends RestApiBase implements IABiTaxonomyService {
    @Inject
    private ABiTaxonomyManager abiTaxonomyManager;

    @Override
    public PingData getPing() {
        return abiTaxonomyManager.getPing();
    }
    
    @Override
    public List<UnspscSegment> getSegments() {
        return abiTaxonomyManager.getSegments();
    }
    
    @Override
    public List<UnspscFamily> getFamilies(@QueryParam("segmentId") String segmentId) {
        return abiTaxonomyManager.getFamilies(segmentId);
    }
    
    @Override
    public List<UnspscClass> getClasses(@QueryParam("familyId") String familyId) {
        return abiTaxonomyManager.getClasses(familyId);
    }
    
    @Override
    public List<UnspscCommodity> getCommodities(@QueryParam("classId") String classId) {
        return abiTaxonomyManager.getCommodities(classId);
    }
    
    @Override
    public UnspscSegmentHierarchy getSegmentHierarchy(@QueryParam("segmentId") String segmentId) {
        return abiTaxonomyManager.getSegmentHierarchy(segmentId);
    }
    
    @Override
    public UnspscLevelDetails getTaxonomyLevelDetails(@QueryParam("level") String level,
                                                      @QueryParam("levelId") String levelId) {
        return abiTaxonomyManager.getTaxonomyLevelDetails(level, levelId);
    }

    @Override
    public UnspscLevelDetails getTaxonomyLevelDetailsByUnspscCode(@QueryParam("unspscCode") Integer unspscCode) {
        return abiTaxonomyManager.getTaxonomyLevelDetailsByUnspscCode(unspscCode);
    }

}
