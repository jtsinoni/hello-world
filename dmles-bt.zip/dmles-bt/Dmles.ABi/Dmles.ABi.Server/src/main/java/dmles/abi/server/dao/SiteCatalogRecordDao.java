package dmles.abi.server.dao;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoDatabase;
import dmles.abi.server.datamodel.production.SiteCatalogRecordDO;
import java.util.ArrayList;

import java.util.List;
import java.util.regex.Pattern;
import javax.enterprise.context.Dependent;
import javax.inject.Inject;

import mil.jmlfdc.common.dao.BaseDao;
import mil.jmlfdc.common.utils.StringUtil;
import org.bson.Document;
import org.mongodb.morphia.Datastore;
import org.mongodb.morphia.query.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Dependent
public class SiteCatalogRecordDao extends BaseDao<SiteCatalogRecordDO, String> {
    @Inject
    private Logger logger;

    public SiteCatalogRecordDao() {
        super(SiteCatalogRecordDO.class);
    }

    public List<SiteCatalogRecordDO> getByProductSeqId(Integer productSeqId) {
        Query<SiteCatalogRecordDO> query = getQuery(SiteCatalogRecordDO.class);
        query.field("productSeqId").equal(productSeqId);
        return query.asList();
    }

    public List<SiteCatalogRecordDO> getByEnterpriseId(String enterpriseProductIdentifier) {
        Query<SiteCatalogRecordDO> query = getQuery(SiteCatalogRecordDO.class);
        query.field("enterpriseProductIdentifier").equal(enterpriseProductIdentifier);
        return query.asList();
    }

    public List<SiteCatalogRecordDO> searchRecords(String filterData) {
        logger.debug("Entering searchRecords. FilterData is ***" + filterData + "***");

        Query<SiteCatalogRecordDO> query = getQuery(SiteCatalogRecordDO.class);
        if (StringUtil.isEmptyOrNull(filterData.trim())) {
            query.offset(0).limit(1000);
        } else {
            query.offset(0).limit(1000).or(
                    query.criteria("enterpriseProductIdentifier").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE))
            );
        }
        List<SiteCatalogRecordDO> products = query.asList();

        logger.debug("Got results from query. Products size is " + products.size());

        return products;
    }

    public List<Integer> getProductSeqIdList() {
        DBCollection m = this.getDatastore().getCollection(SiteCatalogRecordDO.class);
        BasicDBObject bdo = new BasicDBObject("productSeqId", new BasicDBObject("$ne", null));
        logger.info("######### getProductSeqIdList() Getting list of productSeqIds...");
        List<Integer> prodSeqIdList = m.distinct("productSeqId", bdo);
        logger.info("######### getProductSeqIdList() Done. Count is " + prodSeqIdList.size());
        return prodSeqIdList;
    }
    
    public List<String> getNdcList() {
        DBCollection m = this.getDatastore().getCollection(SiteCatalogRecordDO.class);
        BasicDBObject bdo = new BasicDBObject("ndc", new BasicDBObject("$ne", null));
        logger.info("######### getProductSeqIdList() Getting list of NDCs...");
        List<String> ndcList = m.distinct("ndc", bdo);
        logger.info("######### getProductSeqIdList() Done. Count is " + ndcList.size());
        return ndcList;
    }
}

