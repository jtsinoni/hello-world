package dmles.abi.server.rest;

import dmles.abi.core.staging.IABiStagingService;
import dmles.abi.core.datamodel.PingData;
import dmles.abi.core.datamodel.staging.ABiCatalogStagingRecord;
import dmles.abi.core.datamodel.staging.ABiCatalogStatistics;
import dmles.abi.core.datamodel.staging.ApprovalResult;
import dmles.abi.core.datamodel.staging.ApprovalStatus;
import dmles.abi.server.staging.business.ABiStagingManager;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;
import mil.jmlfdc.common.rest.RestApiBase;

@Api(value="ABiStagingRestApi", description="Manage ABI Staging REST API")
@ApplicationScoped
public class ABiStagingRestApi extends RestApiBase implements IABiStagingService {

    @Inject
    private ABiStagingManager abiStagingManager;

    @Override
    @ApiOperation(value = "Test the REST API is functional.")
    public PingData getPing() {
        return abiStagingManager.getPing();
    }

    @Override
    @ApiOperation(value = "Search for ABi Catalog Staging Records.")
    public List<ABiCatalogStagingRecord> searchRecords(
            @QueryParam("mode") String mode, @QueryParam("filterData") String filterData) {
        return abiStagingManager.searchRecords(mode, filterData);
    }

    @Override
    public Response findRecordsJson(@QueryParam("startIndex") int startIndex, 
                                    @QueryParam("numEntriesToReturn") int numEntriesToReturn) {
        String responseString = abiStagingManager.findRecordsJson(startIndex, numEntriesToReturn);
        return Response.status(Response.Status.OK).entity(responseString).build();
    }
    
    @Override
    @ApiOperation(value = "Update a modified ABi Catalog Staging Record")
    public ABiCatalogStagingRecord updateRecord(ABiCatalogStagingRecord updatedRecord) {
        return abiStagingManager.updateRecord(updatedRecord);
    }
    
    @Override
    @ApiOperation(value = "Create a new ABi Catalog Staging Record")
    public ABiCatalogStagingRecord createRecord() {
        return abiStagingManager.createRecord();
    }

    @Override
    @ApiOperation(value = "Gets Staging Catalog Statistics")
    public ABiCatalogStatistics getStatistics() {
        return abiStagingManager.getStatistics();
    }
    
    @Override
    @ApiOperation(value="Determines if record can be approved")
    public ApprovalStatus canRecordBeApproved(ABiCatalogStagingRecord recordToApprove) {
        return abiStagingManager.canRecordBeApproved(recordToApprove);
    }
    
    @Override
    @ApiOperation(value="Mark an ABi Catalog Record as approved")
    public ApprovalResult approveRecord(ABiCatalogStagingRecord recordToApprove) {
        return abiStagingManager.approveRecord(recordToApprove);
    }
}
