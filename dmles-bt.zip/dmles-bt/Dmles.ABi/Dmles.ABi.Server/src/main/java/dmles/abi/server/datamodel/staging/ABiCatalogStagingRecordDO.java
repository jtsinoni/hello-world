package dmles.abi.server.datamodel.staging;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import mil.jmlfdc.common.constants.DateAndTime;
import mil.jmlfdc.common.datamodel.MorphiaEntity;
import org.mongodb.morphia.annotations.Embedded;
import org.mongodb.morphia.annotations.Entity;
import org.mongodb.morphia.annotations.Property;

@Entity("abiCatalogStaging")
public class ABiCatalogStagingRecordDO extends MorphiaEntity implements Serializable {

    private static long serialVersionUID = 1L;

    private String clinicalDescription;
    private String shortItemDescription;
    private String longItemDescription;
    private String fullDescription;
    private String manufacturer;
    private String manufacturerCatalogNumber;
    private String ndc;
    private String ghxProductIdentifier;
    private String mmcProductIdentifier;
    private String commodityType;
    private String productStatus;
    private String recordStatus;
    private String unitOfUsePackageUnit;
    private String unitOfUseUnit;
    private String unitOfUseQuantity;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateAndTime.DATE_TIME_PATTERN)
    private Date publishedDate;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateAndTime.DATE_TIME_PATTERN)
    private Date updatedDate;
    private String approvedBy;
    private String approvalNote;
    private String unspscCode;
    private String unspscSegment;
    private String unspscFamily;
    private String unspscClass;
    private String unspscCommodity;
    private String hcpcsCode;
    private String hcpcsDescription;
    private String hcpcsStatus;
    private String productNoun;
    private String productType;
    private String age;
    private String gender;
    private String sizeShape;
    private String color;
    private String flavor;
    private String fragrance;
    private String sterileNonsterile;
    private String hazardCode;
    private String latexCode;
    private String disposableReusable;
    private String productUrl;
    private String preferredProductIdentifier;
    private String diameter;
    private String volume;
    private String weight;
    private String lengthWidthHeight;
    private String lengthWidthHeight2;
    private String brandGeneric;
    private String deaCode;
    private String dosageForm;
    private String drugCategory;
    private String drugStorageType;
    private String drugStrength;
    private String drugUnit;
    private String genericId;
    private String genericName;
    private String offMarket;
    private String spDrugCode;
    private String ecriDeviceCode;
    private String ecriStandardizedProduct;
    private String ecriStandardizedCatalogNumber;
    private String ecriStandardizedManufacturer;
    private String ghxManufacturer;
    private String scriptproManufacturer;

    private String catalogSource;

    private List<String> productComposition = new ArrayList<>();
    private List<String> productProperties = new ArrayList<>();
    private List<String> locations = new ArrayList<>();
    private List<String> miscellaneous = new ArrayList<>();
    private List<String> productImages = new ArrayList<>();
    private List<String> trademarkBrandnames = new ArrayList<>();
    private List<String> otherManufacturerNames = new ArrayList<>();
    @Embedded
    private List<ProductIdentifierDO> secondaryProductIdentifiers = new ArrayList<>();
    @Embedded
    private List<PackagingDetailDO> packaging = new ArrayList<>();

    public ABiCatalogStagingRecordDO() {
    }

    public ABiCatalogStagingRecordDO(
            List<String> productComposition,
            List<String> productProperties,
            List<String> locations,
            List<String> miscellaneous,
            List<String> productImages,
            List<String> trademarkBrandnames,
            List<String> otherManufacturerNames,
            List<ProductIdentifierDO> secondaryProductIdentifiers,
            List<PackagingDetailDO> packaging) {
        this.productComposition = productComposition;
        this.productProperties = productProperties;
        this.locations = locations;
        this.miscellaneous = miscellaneous;
        this.productImages = productImages;
        this.trademarkBrandnames = trademarkBrandnames;
        this.otherManufacturerNames = otherManufacturerNames;
        this.secondaryProductIdentifiers = secondaryProductIdentifiers;
        this.packaging = packaging;
    }

    public String getClinicalDescription() {
        return clinicalDescription;
    }

    public void setClinicalDescription(String clinicalDescription) {
        this.clinicalDescription = clinicalDescription;
    }

    public String getShortItemDescription() {
        return shortItemDescription;
    }

    public void setShortItemDescription(String shortItemDescription) {
        this.shortItemDescription = shortItemDescription;
    }

    public String getLongItemDescription() {
        return longItemDescription;
    }

    public void setLongItemDescription(String longItemDescription) {
        this.longItemDescription = longItemDescription;
    }

    public String getFullDescription() {
        return fullDescription;
    }

    public void setFullDescription(String fullDescription) {
        this.fullDescription = fullDescription;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public String getManufacturerCatalogNumber() {
        return manufacturerCatalogNumber;
    }

    public void setManufacturerCatalogNumber(String manufacturerCatalogNumber) {
        this.manufacturerCatalogNumber = manufacturerCatalogNumber;
    }

    public String getNdc() {
        return ndc;
    }

    public void setNdc(String ndc) {
        this.ndc = ndc;
    }

    public String getGhxProductIdentifier() {
        return ghxProductIdentifier;
    }

    public void setGhxProductIdentifier(String ghxProductIdentifier) {
        this.ghxProductIdentifier = ghxProductIdentifier;
    }

    public String getMmcProductIdentifier() {
        return mmcProductIdentifier;
    }

    public void setMmcProductIdentifier(String mmcProductIdentifier) {
        this.mmcProductIdentifier = mmcProductIdentifier;
    }

    public String getCommodityType() {
        return commodityType;
    }

    public void setCommodityType(String commodityType) {
        this.commodityType = commodityType;
    }

    public String getProductStatus() {
        return productStatus;
    }

    public void setProductStatus(String productStatus) {
        this.productStatus = productStatus;
    }

    public String getRecordStatus() {
        return recordStatus;
    }

    public void setRecordStatus(String recordStatus) {
        this.recordStatus = recordStatus;
    }

    public String getUnitOfUsePackageUnit() {
        return unitOfUsePackageUnit;
    }

    public void setUnitOfUsePackageUnit(String unitOfUsePackageUnit) {
        this.unitOfUsePackageUnit = unitOfUsePackageUnit;
    }

    public String getUnitOfUseUnit() {
        return unitOfUseUnit;
    }

    public void setUnitOfUseUnit(String unitOfUseUnit) {
        this.unitOfUseUnit = unitOfUseUnit;
    }

    public String getUnitOfUseQuantity() {
        return unitOfUseQuantity;
    }

    public void setUnitOfUseQuantity(String unitOfUseQuantity) {
        this.unitOfUseQuantity = unitOfUseQuantity;
    }

    public Date getPublishedDate() {
        return publishedDate;
    }

    public void setPublishedDate(Date publishedDate) {
        this.publishedDate = publishedDate;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getApprovedBy() {
        return approvedBy;
    }

    public void setApprovedBy(String approvedBy) {
        this.approvedBy = approvedBy;
    }

    public String getApprovalNote() {
        return approvalNote;
    }

    public void setApprovalNote(String approvalNote) {
        this.approvalNote = approvalNote;
    }

    public String getUnspscCode() {
        return unspscCode;
    }

    public void setUnspscCode(String unspscCode) {
        this.unspscCode = unspscCode;
    }

    public String getUnspscSegment() {
        return unspscSegment;
    }

    public void setUnspscSegment(String unspscSegment) {
        this.unspscSegment = unspscSegment;
    }

    public String getUnspscFamily() {
        return unspscFamily;
    }

    public void setUnspscFamily(String unspscFamily) {
        this.unspscFamily = unspscFamily;
    }

    public String getUnspscClass() {
        return unspscClass;
    }

    public void setUnspscClass(String unspscClass) {
        this.unspscClass = unspscClass;
    }

    public String getUnspscCommodity() {
        return unspscCommodity;
    }

    public void setUnspscCommodity(String unspscCommodity) {
        this.unspscCommodity = unspscCommodity;
    }

    public String getHcpcsCode() {
        return hcpcsCode;
    }

    public void setHcpcsCode(String hcpcsCode) {
        this.hcpcsCode = hcpcsCode;
    }

    public String getHcpcsDescription() {
        return hcpcsDescription;
    }

    public void setHcpcsDescription(String hcpcsDescription) {
        this.hcpcsDescription = hcpcsDescription;
    }

    public String getHcpcsStatus() {
        return hcpcsStatus;
    }

    public void setHcpcsStatus(String hcpcsStatus) {
        this.hcpcsStatus = hcpcsStatus;
    }

    public String getProductNoun() {
        return productNoun;
    }

    public void setProductNoun(String productNoun) {
        this.productNoun = productNoun;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getSizeShape() {
        return sizeShape;
    }

    public void setSizeShape(String sizeShape) {
        this.sizeShape = sizeShape;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getFlavor() {
        return flavor;
    }

    public void setFlavor(String flavor) {
        this.flavor = flavor;
    }

    public String getFragrance() {
        return fragrance;
    }

    public void setFragrance(String fragrance) {
        this.fragrance = fragrance;
    }

    public String getSterileNonsterile() {
        return sterileNonsterile;
    }

    public void setSterileNonsterile(String sterileNonsterile) {
        this.sterileNonsterile = sterileNonsterile;
    }

    public String getHazardCode() {
        return hazardCode;
    }

    public void setHazardCode(String hazardCode) {
        this.hazardCode = hazardCode;
    }

    public String getLatexCode() {
        return latexCode;
    }

    public void setLatexCode(String latexCode) {
        this.latexCode = latexCode;
    }

    public String getDisposableReusable() {
        return disposableReusable;
    }

    public void setDisposableReusable(String disposableReusable) {
        this.disposableReusable = disposableReusable;
    }

    public String getProductUrl() {
        return productUrl;
    }

    public void setProductUrl(String productUrl) {
        this.productUrl = productUrl;
    }

    public String getPreferredProductIdentifier() {
        return preferredProductIdentifier;
    }

    public void setPreferredProductIdentifier(String preferredProductIdentifier) {
        this.preferredProductIdentifier = preferredProductIdentifier;
    }

    public String getDiameter() {
        return diameter;
    }

    public void setDiameter(String diameter) {
        this.diameter = diameter;
    }

    public String getVolume() {
        return volume;
    }

    public void setVolume(String volume) {
        this.volume = volume;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public String getLengthWidthHeight() {
        return lengthWidthHeight;
    }

    public void setLengthWidthHeight(String lengthWidthHeight) {
        this.lengthWidthHeight = lengthWidthHeight;
    }

    public String getLengthWidthHeight2() {
        return lengthWidthHeight2;
    }

    public void setLengthWidthHeight2(String lengthWidthHeight2) {
        this.lengthWidthHeight2 = lengthWidthHeight2;
    }

    public String getBrandGeneric() {
        return brandGeneric;
    }

    public void setBrandGeneric(String brandGeneric) {
        this.brandGeneric = brandGeneric;
    }

    public String getDeaCode() {
        return deaCode;
    }

    public void setDeaCode(String deaCode) {
        this.deaCode = deaCode;
    }

    public String getDosageForm() {
        return dosageForm;
    }

    public void setDosageForm(String dosageForm) {
        this.dosageForm = dosageForm;
    }

    public String getDrugCategory() {
        return drugCategory;
    }

    public void setDrugCategory(String drugCategory) {
        this.drugCategory = drugCategory;
    }

    public String getDrugStorageType() {
        return drugStorageType;
    }

    public void setDrugStorageType(String drugStorageType) {
        this.drugStorageType = drugStorageType;
    }

    public String getDrugStrength() {
        return drugStrength;
    }

    public void setDrugStrength(String drugStrength) {
        this.drugStrength = drugStrength;
    }

    public String getDrugUnit() {
        return drugUnit;
    }

    public void setDrugUnit(String drugUnit) {
        this.drugUnit = drugUnit;
    }

    public String getGenericId() {
        return genericId;
    }

    public void setGenericId(String genericId) {
        this.genericId = genericId;
    }

    public String getGenericName() {
        return genericName;
    }

    public void setGenericName(String genericName) {
        this.genericName = genericName;
    }

    public String getOffMarket() {
        return offMarket;
    }

    public void setOffMarket(String offMarket) {
        this.offMarket = offMarket;
    }

    public String getSpDrugCode() {
        return spDrugCode;
    }

    public void setSpDrugCode(String spDrugCode) {
        this.spDrugCode = spDrugCode;
    }

    public String getEcriDeviceCode() {
        return ecriDeviceCode;
    }

    public void setEcriDeviceCode(String ecriDeviceCode) {
        this.ecriDeviceCode = ecriDeviceCode;
    }

    public String getEcriStandardizedProduct() {
        return ecriStandardizedProduct;
    }

    public void setEcriStandardizedProduct(String ecriStandardizedProduct) {
        this.ecriStandardizedProduct = ecriStandardizedProduct;
    }

    public String getEcriStandardizedCatalogNumber() {
        return ecriStandardizedCatalogNumber;
    }

    public void setEcriStandardizedCatalogNumber(String ecriStandardizedCatalogNumber) {
        this.ecriStandardizedCatalogNumber = ecriStandardizedCatalogNumber;
    }

    public String getEcriStandardizedManufacturer() {
        return ecriStandardizedManufacturer;
    }

    public void setEcriStandardizedManufacturer(String ecriStandardizedManufacturer) {
        this.ecriStandardizedManufacturer = ecriStandardizedManufacturer;
    }

    public String getGhxManufacturer() {
        return ghxManufacturer;
    }

    public void setGhxManufacturer(String ghxManufacturer) {
        this.ghxManufacturer = ghxManufacturer;
    }

    public String getScriptproManufacturer() {
        return scriptproManufacturer;
    }

    public void setScriptproManufacturer(String scriptproManufacturer) {
        this.scriptproManufacturer = scriptproManufacturer;
    }

    public String getCatalogSource() {
        return catalogSource;
    }

    public void setCatalogSource(String catalogSource) {
        this.catalogSource = catalogSource;
    }

    public List<String> getProductComposition() {
        return productComposition;
    }

    public void setProductComposition(List<String> ProductComposition) {
        this.productComposition = ProductComposition;
    }

    public List<String> getProductProperties() {
        return productProperties;
    }

    public void setProductProperties(List<String> ProductProperties) {
        this.productProperties = ProductProperties;
    }

    public List<String> getLocations() {
        return locations;
    }

    public void setLocations(List<String> Locations) {
        this.locations = Locations;
    }

    public List<String> getMiscellaneous() {
        return miscellaneous;
    }

    public void setMiscellaneous(List<String> Miscellaneous) {
        this.miscellaneous = Miscellaneous;
    }

    public List<String> getProductImages() {
        return productImages;
    }

    public void setProductImages(List<String> ProductImages) {
        this.productImages = ProductImages;
    }

    public List<String> getTrademarkBrandnames() {
        return trademarkBrandnames;
    }

    public void setTrademarkBrandnames(List<String> TrademarkBrandnames) {
        this.trademarkBrandnames = TrademarkBrandnames;
    }

    public List<String> getOtherManufacturerNames() {
        return otherManufacturerNames;
    }

    public void setOtherManufacturerNames(List<String> OtherManufacturerNames) {
        this.otherManufacturerNames = OtherManufacturerNames;
    }

    public List<ProductIdentifierDO> getSecondaryProductIdentifiers() {
        return secondaryProductIdentifiers;
    }

    public void setSecondaryProductIdentifiers(List<ProductIdentifierDO> secondaryProductIdentifiers) {
        this.secondaryProductIdentifiers = secondaryProductIdentifiers;
    }

    public List<PackagingDetailDO> getPackaging() {
        return packaging;
    }

    public void setPackaging(List<PackagingDetailDO> packaging) {
        this.packaging = packaging;
    }
}
