package dmles.abi.server.rest;

import dmles.abi.core.datamodel.PingData;
import dmles.abi.core.staging.IABiStagingDeltaService;
import dmles.abi.server.staging.business.ABiStagingDeltaManager;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import mil.jmlfdc.common.rest.RestApiBase;

@Api(value="ABiStagingDeltaRestApi", description="ABI Staging Delta REST API")
@ApplicationScoped
public class ABiStagingDeltaRestApi extends RestApiBase implements IABiStagingDeltaService {

    @Inject
    private ABiStagingDeltaManager abiStagingDeltaManager;

    @Override
    @ApiOperation(value = "Test the REST API is functional.")
    public PingData getPing() {
        return abiStagingDeltaManager.getPing();
    }
    
//    @Override
//    @ApiOperation(value = "Get a list of ABi Catalog Staging records that may be able to be merged since they share a common MMC Product Identifer.")
//    public List<StagingRecordByMmc> getMergePossibilitiesByMmc() {
//        return abiStagingJoinManager.getMergePossibilitiesByMmc();
//    }
    
}
