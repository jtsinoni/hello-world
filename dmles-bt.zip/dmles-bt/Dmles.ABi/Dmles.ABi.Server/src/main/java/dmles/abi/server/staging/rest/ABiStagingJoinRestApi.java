package dmles.abi.server.staging.rest;

import dmles.abi.core.datamodel.PingData;
import dmles.abi.core.datamodel.staging.ABiCatalogStagingRecord;
import dmles.abi.core.datamodel.staging.join.InitiateJoinSettings;
import dmles.abi.core.datamodel.staging.join.JoinRecordCommand;
import dmles.abi.core.datamodel.staging.join.JoinStagingRecordsState;
import dmles.abi.core.datamodel.staging.join.StagingRecordByMmc;
import dmles.abi.core.staging.IABiStagingJoinService;
import dmles.abi.server.staging.business.ABiStagingJoinManager;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.QueryParam;
import mil.jmlfdc.common.rest.RestApiBase;

@Api(value="ABiStagingJoinRestApi", description="Manage ABI Staging Join REST API")
@ApplicationScoped
public class ABiStagingJoinRestApi extends RestApiBase implements IABiStagingJoinService {

    @Inject
    private ABiStagingJoinManager abiStagingJoinManager;

    @Override
    @ApiOperation(value = "Test the REST API is functional.")
    public PingData getPing() {
        return abiStagingJoinManager.getPing();
    }
    
    @Override
    @ApiOperation(value = "Get a list of ABi Catalog Staging records that may be able to be merged since they share a common MMC Product Identifer.")
    public List<StagingRecordByMmc> getMergePossibilitiesByMmc() {
        return abiStagingJoinManager.getMergePossibilitiesByMmc();
    }
    @Override
    @ApiOperation(value = "initiate the join record process by providing a list of candidate record ids and the preferred record id.")
    public JoinStagingRecordsState initiateJoinRecordProcess(InitiateJoinSettings settings) {
        return abiStagingJoinManager.initiateJoinRecordProcess(settings);
    }

    @Override
    @ApiOperation(value = "processes a join record commmand to save or merge child records into a master record")
    public ABiCatalogStagingRecord processJoinRecordCommand(JoinRecordCommand joinRecordCommand) {
        return abiStagingJoinManager.processJoinRecordCommand(joinRecordCommand);
    }

    @Override
    @ApiOperation(value = "undoes a merge operation and returns a list of the children records that were previously joined.")
    public List<ABiCatalogStagingRecord> undoMerge(@QueryParam("masterRecordId") String masterRecordId) {
        return abiStagingJoinManager.undoMerge(masterRecordId);
    }

    @Override
    @ApiOperation(value = "returns a list of records that have been merged.")
    public List<ABiCatalogStagingRecord> getMergedRecordList(@QueryParam("filterData") String filterData) {
        return abiStagingJoinManager.getMergedRecordList(filterData);
    }
}
