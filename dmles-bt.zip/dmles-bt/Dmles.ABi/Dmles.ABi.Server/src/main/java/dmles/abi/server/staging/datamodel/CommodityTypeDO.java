package dmles.abi.server.staging.datamodel;

import java.io.Serializable;
import mil.jmlfdc.common.datamodel.MorphiaEntity;
import org.mongodb.morphia.annotations.Entity;

@Entity(value = "commodityType", noClassnameStored = true)
public class CommodityTypeDO extends MorphiaEntity implements Serializable {
    private static long serialVersionUID = 1L;

    private String unspscClass;
    private String commodityType;
    private String classTitle;

    public CommodityTypeDO() {
    }
    
    public String getUnspscClass() {
        return unspscClass;
    }

    public void setUnspscClass(String unspscClass) {
        this.unspscClass = unspscClass;
    }

    public String getCommodityType() {
        return commodityType;
    }

    public void setCommodityType(String commodityType) {
        this.commodityType = commodityType;
    }

    public String getClassTitle() {
        return classTitle;
    }

    public void setClassTitle(String classTitle) {
        this.classTitle = classTitle;
    }
    
}
