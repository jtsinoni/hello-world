package dmles.abi.server.rest;

import dmles.abi.core.IABiProductionService;
import dmles.abi.core.datamodel.PingData;
import dmles.abi.server.business.ABiProductionManager;
import io.swagger.annotations.Api;
import java.text.DateFormat;
import java.util.Date;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import mil.jmlfdc.common.rest.RestApiBase;

@Api
@ApplicationScoped
public class ABiProductionRestApi extends RestApiBase implements IABiProductionService {

    @Inject
    private ABiProductionManager abiProductionManager;
    
    @Override
    public PingData getPing() {
        return abiProductionManager.getPing();
    }
}
