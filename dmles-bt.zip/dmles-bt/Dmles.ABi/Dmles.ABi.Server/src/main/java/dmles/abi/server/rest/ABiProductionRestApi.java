package dmles.abi.server.rest;

import dmles.abi.core.IABiProductionService;
import dmles.abi.core.datamodel.PingData;
import dmles.abi.server.business.ABiProductionManager;
import io.swagger.annotations.Api;
import java.text.DateFormat;
import java.util.Date;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;
import mil.jmlfdc.common.rest.RestApiBase;

@Api(value="ABiProductionRestApi", description="Manage ABI Production REST API")
@ApplicationScoped
public class ABiProductionRestApi extends RestApiBase implements IABiProductionService {

    @Inject
    private ABiProductionManager abiProductionManager;
    
    @Override
    public PingData getPing() {
        return abiProductionManager.getPing();
    }
    
    @Override
    public Response getABiCatalogRecordSearchResults(@QueryParam("searchValue") String searchValue,
                                                  @QueryParam("aggregations") String aggregations) {
        String responseString = abiProductionManager.getABiCatalogRecordSearchResults(searchValue, aggregations);
        return Response.status(Response.Status.OK).entity(responseString).build();
    }
}
