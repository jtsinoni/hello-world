package dmles.abi.server.rest;

import dmles.abi.core.IABiProductionService;
import dmles.abi.core.datamodel.PingData;
import dmles.abi.core.datamodel.production.SearchInput;
import dmles.abi.server.business.ABiProductionManager;
import io.swagger.annotations.Api;
import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.core.Response;
import mil.jmlfdc.common.rest.RestApiBase;

@Api(value = "ABiProductionRestApi", description = "Manage ABI Production REST API")
@ApplicationScoped
public class ABiProductionRestApi extends RestApiBase implements IABiProductionService {

    @Inject
    private ABiProductionManager abiProductionManager;

    @Override
    public Response getABiCatalogRecordESResults(SearchInput searchInput) {        
        String responseString = abiProductionManager.getABiCatalogRecordESResults(searchInput.queryString, searchInput.aggregations);
        return Response.status(Response.Status.OK).entity(responseString).build();
    }

    @Override
    public Response getCommodityTypes() {
        List<String> response = abiProductionManager.getCommodityTypes();
        return Response.status(Response.Status.OK).entity(response).build();
    }

    @Override
    public Response getProductNouns() {
        List<String> response = abiProductionManager.getProductNouns();
        return Response.status(Response.Status.OK).entity(response).build();
    }

    @Override
    public Response getUnspscSegments() {
        List<String> response = abiProductionManager.getUnspscSegments();
        return Response.status(Response.Status.OK).entity(response).build();
    }

    // Leave this method here! - planning to have NAGIOS hit these ping methods to see if each BT micro service is up and available. 
    @Override
    public PingData getPing() {
        return abiProductionManager.getPing();
    }
}