package dmles.abi.server.dao;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoDatabase;
import dmles.abi.server.datamodel.staging.ABiCatalogStagingRecordDO;
import java.util.List;
import java.util.regex.Pattern;
import javax.enterprise.context.Dependent;
import javax.inject.Inject;
import mil.jmlfdc.common.dao.BaseDao;
import mil.jmlfdc.common.utils.StringUtil;
import org.mongodb.morphia.Datastore;
import org.mongodb.morphia.query.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Dependent
public class ABiCatalogStagingRecordDao extends BaseDao<ABiCatalogStagingRecordDO, String> {
    @Inject
    private Logger logger;

    public ABiCatalogStagingRecordDao() {
        super(ABiCatalogStagingRecordDO.class);
    }

    public MongoDatabase getMongoDatabase(String databaseName) {
        Datastore ds = this.getDatastore();
        MongoClient client = ds.getMongo();

        MongoDatabase mongoDb = client.getDatabase(databaseName);
        return mongoDb;
    }

    public List<ABiCatalogStagingRecordDO> searchRecords(String filterData) {
        logger.debug("Entering searchRecords. FilterData is ***" + filterData + "***");

        Query<ABiCatalogStagingRecordDO> query = getQuery(ABiCatalogStagingRecordDO.class);
        if (StringUtil.isEmptyOrNull(filterData.trim())) {
            query.offset(0).limit(1000);
        } else {
            query.offset(0).limit(1000).or(
                    query.criteria("ndc").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE)),
                    query.criteria("manufacturer").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE)),
                    query.criteria("catalogSource").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE)),
                    query.criteria("longItemDescription").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE)),
                    query.criteria("shortItemDescription").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE)),
                    query.criteria("manufacturerCatalogNumber").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE))
            );
        }
        List<ABiCatalogStagingRecordDO> products = query.asList();
        
        logger.debug("Got results from query. Products size is " + products.size());
        
        return products;
    }

    public List<String> getProductStatusList() {
        String[] valueArray = {"ACTIVE", "INACTIVE", "OBSOLETE", "REPLACED", "OFFMARKET"};
        return getValueList("productStatus", valueArray);
    }

    public List<String> getDisposableReusableList() {
        String[] valueArray = {"DISPOSABLE", "REUSABLE"};
        return getValueList("disposableReusable", valueArray);
    }

    public List<String> getSterileNonSterileList() {
        String[] valueArray = {"STERILE", "NONSTERILE"};
        return getValueList("sterileNonsterile", valueArray);
    }

    public List<String> getHazardCodeList() {
        String[] valueArray = {"HAZARDOUS", "NONHAZARDOUS"};
        return getValueList("hazardCode", valueArray);
    }

    public List<String> getLatexCodeList() {
        String[] valueArray = {"LATEX", "LATEX-FREE"};
        return getValueList("latexCode", valueArray);
    }

    public List<String> getGenderList() {
        String[] valueArray = {"MALE", "FEMALE", "UNISEX"};
        return getValueList("gender", valueArray);
    }

    private List<String> getValueList(String attributeName, String[] requiredValues) {
        DBCollection m = this.getDatastore().getCollection(ABiCatalogStagingRecordDO.class);
        List<String> valueList = m.distinct("name", new BasicDBObject());
        valueList = addIfNotInCollection(valueList, requiredValues);

        return valueList;
    }

    private List<String> addIfNotInCollection(List<String> stringList, String[] itemArray) {
        for (String item : itemArray) {
            if (!stringList.contains(item)) {
                stringList.add(item);
            }
        }
        return stringList;
    }
 }
