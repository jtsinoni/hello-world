package dmles.abi.server.staging.dao;

import dmles.abi.server.staging.dao.ABiCatalogStagingRecordDao;
import com.mongodb.MongoClient;
import com.mongodb.client.AggregateIterable;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import dmles.abi.core.datamodel.staging.ABiCatalogStagingRecord;
import dmles.abi.core.datamodel.staging.ABiCatalogStagingRecordSummary;
import dmles.abi.core.datamodel.staging.join.InitiateJoinSettings;
import dmles.abi.core.datamodel.staging.join.JoinRecordCommand;
import dmles.abi.core.datamodel.staging.join.JoinStagingRecordsState;
import dmles.abi.core.datamodel.staging.join.StagingRecordByMmc;
import dmles.abi.server.staging.datamodel.ABiCatalogStagingRecordDO;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.regex.Pattern;
import javax.enterprise.context.Dependent;
import javax.inject.Inject;
import mil.jmlfdc.common.dao.BaseDao;
import mil.jmlfdc.common.utils.DateUtil;
import mil.jmlfdc.common.utils.ObjectMapper;
import mil.jmlfdc.common.utils.StringUtil;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.mongodb.morphia.Datastore;
import org.mongodb.morphia.query.Criteria;
import org.mongodb.morphia.query.Query;
import org.mongodb.morphia.query.UpdateOperations;
import org.mongodb.morphia.query.ValidationException;
import org.slf4j.Logger;

@Dependent
public class ABiStagingJoinDao extends BaseDao<ABiCatalogStagingRecordDO, String> {

    @Inject
    private Logger logger;

    public ABiStagingJoinDao() {
        super(ABiCatalogStagingRecordDO.class);
    }

    public List<StagingRecordByMmc> getMergePossibilitiesByMmc(ObjectMapper objectMapper) {
        logger.debug("Inside of getMergePossibilitiesByMmc");
        AggregateIterable<Document> mmcAggregation = getAggregationByMmcDocument();
        MongoCursor<Document> rows = mmcAggregation.iterator();

        List<StagingRecordByMmc> stagingRecords = new ArrayList<>();
        while (rows.hasNext()) {
            Document row = rows.next();
            logger.debug("getMergePossibilitiesByMmc. Building staging record for row.");
            StagingRecordByMmc stagingRecord = buildStagingRecord(objectMapper, row);
            stagingRecords.add(stagingRecord);

        }
        stagingRecords.sort((o1, o2) -> o1.mmcId.compareTo(o2.mmcId));
        logger.debug("getMergePossibilitiesByMmc returning "
                + stagingRecords.size() + " records");
        return stagingRecords;
    }

    public JoinStagingRecordsState initiateJoinRecordProcess(ObjectMapper objectMapper, InitiateJoinSettings settings) {
        logger.debug("Inside of initiateJoinRecordProcess.");
        logger.debug("Records to join: " + String.join(", ", settings.recordIdsToJoin) + ")");
        logger.debug("Preferred id: " + settings.preferredRecordId);

        Integer mmcId = null;
        ABiCatalogStagingRecord preferredRecord = null;

        JoinStagingRecordsState state = new JoinStagingRecordsState();
        for (int i = 0; i < settings.recordIdsToJoin.size(); i++) {
            String currentId = settings.recordIdsToJoin.get(i);
            ABiCatalogStagingRecordDO rec = this.findById(currentId);
            ABiCatalogStagingRecord fullRecord = objectMapper.getObject(ABiCatalogStagingRecord.class, rec);
            if (mmcId == null) {
                mmcId = fullRecord.mmcProductIdentifier;
            }
            if (currentId.equals(settings.preferredRecordId)) {
                state.preferredRecordIndex = i;
                preferredRecord = fullRecord;
            }
            state.joinCandidates.add(fullRecord);
        }

        Map<String, Object> fieldFilter = new HashMap<>();
        fieldFilter.put("mmcProductIdentifier", mmcId);
        fieldFilter.put("recordStatus", "Merging");

        List<ABiCatalogStagingRecordDO> mergingRecordList = this.query(fieldFilter);
        if ((mergingRecordList == null) || (mergingRecordList.isEmpty())) {
            state.masterRecord = new ABiCatalogStagingRecord(preferredRecord);
            state.masterRecord.id = null;
            state.masterRecord.recordStatus = "Merging";
            state.masterRecord.catalogSource = "MERGING";
            ABiCatalogStagingRecordDO masterRecordDO = objectMapper.getObject(ABiCatalogStagingRecordDO.class, state.masterRecord);
            logger.debug("********* SAVED NEW MASTER RECORD TO MONGO **********");
            this.insert(masterRecordDO);
        } else {
            state.masterRecord = objectMapper.getObject(ABiCatalogStagingRecord.class, mergingRecordList.get(0));
            logger.debug("********* FETCHED MASTER RECORD FROM MONGO **********");
        }
        this.logger.debug("******* Master Record ID: " + state.masterRecord.id);
        return state;
    }

    public ABiCatalogStagingRecordDO processJoinRecordCommand(ObjectMapper objectMapper,
            JoinRecordCommand joinRecordCommand) {
        logger.debug("Inside of processJoinRecordCommand.");
        logger.debug("MODE: " + joinRecordCommand.mode);

        ABiCatalogStagingRecordDO finalMasterRecordDO = null;

        ABiCatalogStagingRecordDO updatedMasterRecordDO = objectMapper.getObject(ABiCatalogStagingRecordDO.class,
                joinRecordCommand.masterRecord);
        updatedMasterRecordDO.setUpdatedDate(DateUtil.getCurrentUTCDate());

        ABiCatalogStagingRecordDO existingMasterRecordDO = null;
        if (!StringUtil.isEmptyOrNull(joinRecordCommand.masterRecord.id)) {
            existingMasterRecordDO = this.findById(joinRecordCommand.masterRecord.id);
        } else {
            Map<String, Object> fieldFilter = new HashMap<>();
            fieldFilter.put("mmcProductIdentifier", joinRecordCommand.masterRecord.mmcProductIdentifier);
            fieldFilter.put("recordStatus", "Merging");
            List<ABiCatalogStagingRecordDO> mergingRecordList = this.query(fieldFilter);
            if (mergingRecordList.size() > 0) {
                existingMasterRecordDO = mergingRecordList.get(0);
            }
        }

        switch (joinRecordCommand.mode.toLowerCase()) {
            case "save":
                finalMasterRecordDO = saveMasterRecord(existingMasterRecordDO, updatedMasterRecordDO);
                break;
            case "merge":
                updatedMasterRecordDO.setRecordStatus("Merged");
                updatedMasterRecordDO.setCatalogSource("MERGED");
                finalMasterRecordDO = saveMasterRecord(existingMasterRecordDO, updatedMasterRecordDO);

                for (String childId : joinRecordCommand.childRecords) {
                    UpdateOperations<ABiCatalogStagingRecordDO> ops
                            = this.getDatastore().createUpdateOperations(ABiCatalogStagingRecordDO.class);
                    ops.set("mergedTo", finalMasterRecordDO.getId());
                    Query<ABiCatalogStagingRecordDO> query = this.getQuery(ABiCatalogStagingRecordDO.class);
                    ObjectId oid = new ObjectId(childId);
                    query.criteria("id").equal(oid);
                    Integer numRecordsUpdated = this.update(query, ops);
                    this.logger.debug("*** Update child record (" + childId + ") merged to field to "
                            + finalMasterRecordDO.getId() + ". Update Count: " + numRecordsUpdated);
                }
                break;
            default:
                throw new ValidationException("Command " + joinRecordCommand.mode + " is not supported.");
        }
        return finalMasterRecordDO;
    }

    public List<ABiCatalogStagingRecordDO> undoMerge(String masterRecordId) {
        // find records with mergedTo == masterRecordId
        Query<ABiCatalogStagingRecordDO> childrenRecordsQuery = this.getQuery();
        childrenRecordsQuery.criteria("mergedTo").equal(masterRecordId);
        childrenRecordsQuery.project("id", true);

        List<ABiCatalogStagingRecordDO> childrenRecords = childrenRecordsQuery.asList();

        // and update children records setting mergedTo to null
        UpdateOperations<ABiCatalogStagingRecordDO> ops
                = this.getDatastore().createUpdateOperations(ABiCatalogStagingRecordDO.class);
        ops.unset("mergedTo");
        Query<ABiCatalogStagingRecordDO> query = this.getQuery(ABiCatalogStagingRecordDO.class);
        query.criteria("mergedTo").equal(masterRecordId);
        Integer numRecordsUpdated = this.update(query, ops);
        this.logger.debug("*** undoMerge() -> Update children records with mergedTo = '" + masterRecordId
                + "' merged to field to null.   Update Count: " + numRecordsUpdated);

        // delete record with masterRecordId
        this.deleteById(masterRecordId);

        // build list of children records and return
        Query<ABiCatalogStagingRecordDO> findChildrenQuery = this.getQuery(ABiCatalogStagingRecordDO.class);
//        List<Criteria> idList = new ArrayList<Criteria>();
        List<ObjectId> idList = new ArrayList<>();
        for (ABiCatalogStagingRecordDO child : childrenRecords) {
            idList.add(new ObjectId(child.getId()));
//            idList.add(findChildrenQuery.criteria("id").equal(new ObjectId(child.getId())));
        }
        findChildrenQuery.criteria("id").hasAnyOf(idList);
//        findChildrenQuery.or((Criteria[]) idList);
        childrenRecords = findChildrenQuery.asList();
        return childrenRecords;
    }

    public List<ABiCatalogStagingRecordDO> getMergedRecordList(String filterData) {
        Query<ABiCatalogStagingRecordDO> query = getQuery(ABiCatalogStagingRecordDO.class);
        if (StringUtil.isEmptyOrNull(filterData)) {
            query.offset(0).limit(1000)
                    .criteria("recordStatus").notEqual("Merging")
                    .criteria("mergedTo").equal(null)
                    .criteria("recordStatus").equal("Merged");
        } else {
            filterData = filterData.trim();
            query.offset(0).limit(1000)
                    .criteria("recordStatus").notEqual("Merging")
                    .criteria("mergedTo").equal(null)
                    .criteria("recordStatus").equal("Merged")
                    .or(
                            query.criteria("ndc").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE)),
                            query.criteria("manufacturer").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE)),
                            query.criteria("longItemDescription").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE)),
                            query.criteria("shortItemDescription").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE)),
                            query.criteria("manufacturerCatalogNumber").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE)),
                            query.criteria("enterpriseProductIdentifier").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE))
                    );
        }
        List<ABiCatalogStagingRecordDO> mergedRecords = query.asList();
        return mergedRecords;
    }

    private AggregateIterable<Document> getAggregationByMmcDocument() {
        MongoDatabase mdb = getMongoDatabase();
        Document earlyFilter = getEarlyFilterDocument();
        Document groupDocument = getGroupDocument();
        Document sortDocument = getSortDocument();
        Document finalFilter = getFinalFilterDocument();
        Document limit = getLimitDocument();
        List<Document> pipeline = Arrays.asList(
                earlyFilter,
                groupDocument,
                sortDocument,
                finalFilter,
                limit);
        AggregateIterable<Document> aggregation = mdb.getCollection("abiCatalogStaging")
                .aggregate(pipeline)
                .allowDiskUse(Boolean.TRUE);
        return aggregation;
    }

    private MongoDatabase getMongoDatabase() {
        Datastore ds = this.getDatastore();
        MongoClient client = ds.getMongo();
        String dbName = ds.getDB().getName();
        MongoDatabase mongoDb = client.getDatabase(dbName);
        return mongoDb;
    }

    private Document getEarlyFilterDocument() {
        Document earlyFilter;
        String earlyFilterExpression
                = "{\n"
                + "   $match: \n"
                + "{      \n"
                + "       $and: \n"
                + "       [\n"
                + "           { mmcProductIdentifier: { $ne: null } },\n"
                + "           { mmcProductIdentifier: { $ne: NaN } },\n"
//                + "           { recordStatus: { $ne: 'Merging' } },\n"
                + "           { recordStatus: { $ne: 'Merged' } },\n"
                + "           { mergedTo: { $eq: null } },\n"
                + "       ] \n"
                + "   }\n"
                + "}\n";
        earlyFilter = Document.parse(earlyFilterExpression);
        return earlyFilter;
    }

    private Document getGroupDocument() {
        String groupExpr
                = "{\n"
                + "            $group : \n"
                + "            { \n"
                + "                _id: { mmcProductIdentifier: '$mmcProductIdentifier' },\n"
                + "                'count': { $sum: 1 },\n"
                + "                'record': \n"
                + "                { \n"
                + "                    $addToSet: \n"
                + "                    { \n"
                + "                        _id: '$_id', \n"
                + "                        id: '$id' \n"
                + "                    } \n"
                + "                }\n"
                + "            }"
                + "}";
        Document groupDocument = Document.parse(groupExpr);
        return groupDocument;
    }

    private Document getSortDocument() {
        String sortExpr = "{ $sort: { _id : 1 } }";
        Document sortDocument = Document.parse(sortExpr);
        return sortDocument;
    }

    private Document getFinalFilterDocument() {
        String filterExpr = "{ $match: { count: { $gt: 1 }} }";
        Document finalFilter = Document.parse(filterExpr);
        return finalFilter;
    }

    private Document getLimitDocument() {
        String limitExpr = "{ $limit: 250 }";
        Document limit = Document.parse(limitExpr);
        return limit;
    }

    private StagingRecordByMmc buildStagingRecord(ObjectMapper objectMapper, Document row) {

        StagingRecordByMmc stagingRecord = new StagingRecordByMmc();

        Document id = row.get("_id", Document.class);
        // not sure - this might have to be an integer
        Integer mmcId = id.get("mmcProductIdentifier", Integer.class);
        Integer count = row.get("count", Integer.class);
        logger.debug("Building Staging Record for mmcID " + mmcId + " which has " + count + " associated records");

        stagingRecord.count = count;
        stagingRecord.mmcId = mmcId.toString();

        List<Document> idList = row.get("record", ArrayList.class);
        Iterator<Document> listItems = idList.iterator();
        while (listItems.hasNext()) {
            Document listItem = listItems.next();
            ObjectId recordId = listItem.get("_id", ObjectId.class);

            ABiCatalogStagingRecordDO rec = this.findById(recordId.toString());
            logger.debug("Calling Object Mapper");

            ABiCatalogStagingRecord fullRecord = objectMapper.getObject(ABiCatalogStagingRecord.class, rec);
            ABiCatalogStagingRecordSummary summaryRecord = new ABiCatalogStagingRecordSummary(fullRecord);
            logger.debug("Adding to staging record list.");
            stagingRecord.stagingRecords.add(summaryRecord);
        }
        logger.debug("buildStagingRecord is complete.");

        return stagingRecord;
    }

    private ABiCatalogStagingRecordDO saveMasterRecord(ABiCatalogStagingRecordDO existingMasterRecordDO,
            ABiCatalogStagingRecordDO updatedMasterRecordDO) {
        String masterRecordId = null;
        if (existingMasterRecordDO == null) {
            this.insert(updatedMasterRecordDO);
            masterRecordId = updatedMasterRecordDO.getId();
        } else {
            Query<ABiCatalogStagingRecordDO> query = this.getQuery(ABiCatalogStagingRecordDO.class);
            ObjectId oid = new ObjectId(existingMasterRecordDO.getId());
            query.criteria("id").equal(oid);
            UpdateUtility uu = new UpdateUtility(this.getDatastore(), this.logger);
            List<String> fieldsToIgnore = Arrays.asList("logger", "id");
            UpdateOperations<ABiCatalogStagingRecordDO> ops = uu.buildUpdateOperations(existingMasterRecordDO, updatedMasterRecordDO, fieldsToIgnore);
//            UpdateOperations<ABiCatalogStagingRecordDO> ops = buildUpdateOperations(existingMasterRecordDO, updatedMasterRecordDO);
            if (ops != null) {
                Integer numRecordsUpdated = this.update(query, ops);
                this.logger.debug("*** Saved Master Record. Num Records Changed: " + numRecordsUpdated);
            }
            masterRecordId = existingMasterRecordDO.getId();
        }
        ABiCatalogStagingRecordDO finalMasterRecord = this.findById(masterRecordId);
        return finalMasterRecord;
    }
}
