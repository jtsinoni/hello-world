package dmles.abi.server.staging.dao;

import dmles.abi.server.staging.datamodel.ABiCatalogStagingRecordDO;
import dmles.abi.server.staging.datamodel.PackageUnitDO;
import java.util.List;
import javax.enterprise.context.Dependent;
import javax.inject.Inject;
import mil.jmlfdc.common.dao.BaseDao;
import org.mongodb.morphia.query.Query;
import org.slf4j.Logger;

@Dependent
public class PackageUnitDao extends BaseDao<PackageUnitDO, String> {

    @Inject
    private Logger logger;

    public PackageUnitDao() {
        super(PackageUnitDO.class);
    }
    public List<PackageUnitDO> getPackageUnitList() {
        Query<PackageUnitDO> query = getQuery();
        query.criteria("inUse").equal(true);
        List<PackageUnitDO> list = query.asList();
        return list;
    }
    
    public boolean doesPackageUnitExist(String packageUnit) {
        Query<PackageUnitDO> query = getQuery();
        query.criteria("inUse").equal(true);
        query.criteria("ansiPackUnit").equal(packageUnit);
        long count = query.count();
        return (count > 0);
    }
}
