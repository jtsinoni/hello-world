package dmles.abi.server.datamodel.production;

import org.mongodb.morphia.annotations.Embedded;

import java.io.Serializable;

@Embedded
public class ItemRestrictionDO implements Serializable {
    private static final long serialVersionUID = 1L;
    private String restrictCd;
    private String restrictDescription;
    private String restrictType;

    public ItemRestrictionDO() {
    }

    public String getRestrictCd() {
        return restrictCd;
    }

    public void setRestrictCd(String restrictCd) {
        this.restrictCd = restrictCd;
    }

    public String getRestrictDescription() {
        return restrictDescription;
    }

    public void setRestrictDescription(String restrictDescription) {
        this.restrictDescription = restrictDescription;
    }

    public String getRestrictType() {
        return restrictType;
    }

    public void setRestrictType(String restrictType) {
        this.restrictType = restrictType;
    }
}
