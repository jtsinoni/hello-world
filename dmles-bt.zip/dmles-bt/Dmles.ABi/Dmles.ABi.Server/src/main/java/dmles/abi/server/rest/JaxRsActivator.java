package dmles.abi.server.rest;

import dmles.common.general.configuration.ConfigurationManager;
import dmles.common.rest.CorsFilter;
import io.swagger.jaxrs.config.BeanConfig;

import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;
import java.util.HashSet;
import java.util.Set;

@ApplicationPath("/")
@ApplicationScoped
public class JaxRsActivator extends Application {
    @Inject
    private ConfigurationManager configurationManager;

    public JaxRsActivator() {
    }

    private String[] getSchemes() {
        String swaggerSchemes = configurationManager.getSwaggerSchemes();
        return swaggerSchemes.split(",");
    }

    @PostConstruct
    public void init() {

        String projectVersion = configurationManager.getProjectVersion();

        String swaggerHost = configurationManager.getSwaggerHost();
        String swaggerPort = configurationManager.getSwaggerPort();
        String basePath = "Dmles.ABi.Server";
        String resourcePackage = "dmles.abi.server.rest,dmles.abi.server.staging.rest,dmles.abi.server.taxonomy.rest";

        BeanConfig beanConfig = new BeanConfig();
        beanConfig.setVersion(projectVersion);
        beanConfig.setSchemes(getSchemes());

        String host = String.format("%s:%s", swaggerHost, swaggerPort);
        beanConfig.setHost(host);

        beanConfig.setBasePath(basePath);
        beanConfig.setResourcePackage(resourcePackage);
        beanConfig.setPrettyPrint(true);
        beanConfig.setScan(true);
    }

    @Override
    public Set<Class<?>> getClasses() {
        Set<Class<?>> resources = new HashSet<Class<?>>();

        resources.add(ABiStagingRestApi.class);
        resources.add(ABiProductionRestApi.class);
        resources.add(ABiTaxonomyRestApi.class);
        resources.add(SiteCatalogRestApi.class);
        resources.add(ABiStagingJoinRestApi.class);
        resources.add(ABiStagingLookupRestApi.class);
        resources.add(ABiStagingMoveRecordsRestApi.class);
        resources.add(ABiStagingDeltaRestApi.class);
        
        resources.add(io.swagger.jaxrs.listing.ApiListingResource.class);
        resources.add(io.swagger.jaxrs.listing.SwaggerSerializers.class);
        resources.add(CorsFilter.class);
        return resources;
    }
}
