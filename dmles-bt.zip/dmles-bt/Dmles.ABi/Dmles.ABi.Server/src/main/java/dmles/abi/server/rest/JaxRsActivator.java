package dmles.abi.server.rest;

import io.swagger.annotations.Api;
import io.swagger.jaxrs.config.BeanConfig;
import java.util.HashSet;
import java.util.Set;
import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;
import mil.jmlfdc.common.rest.CorsFilter;
import mil.jmlfdc.common.utils.AnnotationUtils;
import mil.jmlfdc.common.utils.PropertyUtils;

/**
 * A class extending {@link Application} and annotated with @ApplicationPath is
 * the Java EE 7 "no XML" approach to activating JAX-RS.
 *
 * <p>
 * Resources are served relative to the servlet path specified in the
 * {@link ApplicationPath} annotation.
 * </p>
 */
@ApplicationPath("/")
@ApplicationScoped
public class JaxRsActivator extends Application {

    @Inject
    private PropertyUtils propertyUtils;

    /**
     * @return http or http and https
     */
    private String[] getSchemes() {
        String swaggerSchemes = propertyUtils.getProperty("swagger.schemes");
        return swaggerSchemes.split(",");
    }

    public JaxRsActivator() {
    }

    @PostConstruct
    public void init() {
        BeanConfig beanConfig = new BeanConfig();
        beanConfig.setVersion(propertyUtils.getProperty("project.version"));
        beanConfig.setSchemes(getSchemes());

        String host = propertyUtils.getProperty("swagger.host") + ":" + propertyUtils.getProperty("swagger.port");
        beanConfig.setHost(host);

        beanConfig.setBasePath(propertyUtils.getProperty("swagger.base.path"));
        beanConfig.setResourcePackage(propertyUtils.getProperty("swagger.resource.package"));
        beanConfig.setPrettyPrint(true);
        beanConfig.setScan(true);
    }

    /**
     * swagger-core's providers
     */
    @Override
    public Set<Class<?>> getClasses() {
        Set<Class<?>> resources = new HashSet<Class<?>>();

        resources.add(ABiStagingRestApi.class);
        resources.add(ABiProductionRestApi.class);

        resources.add(io.swagger.jaxrs.listing.ApiListingResource.class);
        resources.add(io.swagger.jaxrs.listing.SwaggerSerializers.class);
        resources.add(CorsFilter.class);
        return resources;
    }
}
