package dmles.abi.server.taxonomy.business;

import dmles.abi.core.datamodel.PingData;
import dmles.abi.core.datamodel.taxonomy.UnspscClass;
import dmles.abi.core.datamodel.taxonomy.UnspscCommodity;
import dmles.abi.core.datamodel.taxonomy.UnspscFamily;
import dmles.abi.core.datamodel.taxonomy.UnspscLevelDetails;
import dmles.abi.core.datamodel.taxonomy.UnspscSegment;
import dmles.abi.core.datamodel.taxonomy.UnspscSegmentHierarchy;
import dmles.abi.server.taxonomy.dao.ABiTaxonomyDao;
import dmles.abi.server.dao.PingDataDao;
import dmles.abi.server.datamodel.PingDataDO;
import dmles.abi.server.taxonomy.datamodel.UnspscRecordDO;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.ws.rs.QueryParam;
import mil.jmlfdc.common.business.BusinessManager;
import mil.jmlfdc.common.utils.ObjectMapper;
import org.slf4j.Logger;

@Stateless
public class ABiTaxonomyManager extends BusinessManager {

    @Inject
    private Logger log;
    
    @Inject
    private PingDataDao pingDataDao;

    @Inject
    private ABiTaxonomyDao abiTaxonomyDao;
    
    @Inject
    private ObjectMapper objectMapper;      

    public PingData getPing() {
        log.info("Pinged the BT ABi TAXONOMY Manager!");
        log.info("User: {}", currentUserBt.getPkiDn());
        PingDataDO pingDo = pingDataDao.getPingData("Hello from the ABi TAXONOMY Manager...and have a NICE DAY!!!");
        return objectMapper.getObject(PingData.class, pingDo);
    }
    
    public List<UnspscSegment> getSegments() {
        List<UnspscSegment> returnRecords = this.abiTaxonomyDao.getSegments();
        return returnRecords;
    }
    
    public List<UnspscFamily> getFamilies(String segmentId) {
        List<UnspscFamily> returnRecords = this.abiTaxonomyDao.getFamilies(segmentId);
        return returnRecords;
    }
    
    public List<UnspscClass> getClasses(String familyId) {
        List<UnspscClass> returnRecords = this.abiTaxonomyDao.getClasses(familyId);
        return returnRecords;
    }
    
    public List<UnspscCommodity> getCommodities(String classId) {
        List<UnspscCommodity> returnRecords = this.abiTaxonomyDao.getCommodities(classId);
        return returnRecords;
    }
    
    public UnspscSegmentHierarchy getSegmentHierarchy(String segmentId) {
        UnspscSegmentHierarchy returnRecord = this.abiTaxonomyDao.getSegmentHierarchy(segmentId);
        return returnRecord;
    }

    public UnspscLevelDetails getTaxonomyLevelDetails(String level, String levelId) {
        UnspscLevelDetails returnRecord = this.abiTaxonomyDao.getTaxonomyLevelDetails(level, levelId);
        return returnRecord;
    }

    public UnspscLevelDetails getTaxonomyLevelDetailsByUnspscCode(Integer unspscCode) {
        UnspscLevelDetails returnRecord = this.abiTaxonomyDao.getTaxonomyLevelDetailsByUnspscCode(unspscCode);
        return returnRecord;
    }
}
