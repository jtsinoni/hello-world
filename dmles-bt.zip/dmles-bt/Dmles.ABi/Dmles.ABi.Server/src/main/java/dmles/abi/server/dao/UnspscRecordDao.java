package dmles.abi.server.dao;

import dmles.abi.server.datamodel.staging.UnspscRecordDO;
import javax.enterprise.context.Dependent;
import mil.jmlfdc.common.dao.BaseDao;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

@Dependent
public class UnspscRecordDao extends BaseDao<UnspscRecordDO, String> { 
    public UnspscRecordDao() {
        super(UnspscRecordDO.class);
    }

//    public List<UnspscRecordDO> searchRecords(String filterData) {
//        Query<UnspscRecordDO> query = getQuery(UnspscRecordDO.class);
//        query.or(
//                query.criteria("ndc").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE)),
//                query.criteria("manufacturer").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE)),
//                query.criteria("catalogSource").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE)),
//                query.criteria("longItemDescription").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE)),
//                query.criteria("shortItemDescription").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE)),
//                query.criteria("manufacturerCatalogNumber").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE))
//        );
//        List<UnspscRecordDO> products = query.asList();
//        return products;
//    }
    
}
