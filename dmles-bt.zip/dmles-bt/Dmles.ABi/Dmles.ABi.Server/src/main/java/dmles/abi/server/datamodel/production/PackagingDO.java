package dmles.abi.server.datamodel.production;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import org.mongodb.morphia.annotations.Embedded;

@Embedded
public class PackagingDO implements Serializable {
    private Integer ipPackSerial;
    private BigDecimal burdenedPriceAmt;
    private Date createDt;
    private String createUserId;
    private Integer ecatItemId;
    private Integer ipPackLevel;
    private String ipPackCd;
    private Integer ipPackQty;
    private String ipGtin;
    private Date lastUpdateDt;
    private String lastUpdateUserId;
    private String lowUomInd;
    private Integer maximumOrderQty;
    private String medAirBridgeInd;
    private Integer minimumOrderQty;
    private Integer multipleOrderQty;
    private String nsn;
    private String packCubeUomCd;
    private Integer packCubeVol;
    private Integer packLengthDm;
    private String packLengthUomCd;
    private Integer packGrossWeight;
    private String packGrossWeightUomCd;
    private Integer packHeightDm;
    private String packHeightUomCd;
    private BigDecimal packPriceAmt;
    private Integer packWidthDm;
    private String packWidthUomCd;
    private Date priceEffDt;
    private Date priceExpDt;
    private Integer productSourcePriceSeqId;
    private BigDecimal taxAmt;
    private String sosCd;
    private Integer sosSerial;

    public PackagingDO() {
    }

    public Integer getIpPackSerial() {
        return ipPackSerial;
    }

    public void setIpPackSerial(Integer ipPackSerial) {
        this.ipPackSerial = ipPackSerial;
    }

    public BigDecimal getBurdenedPriceAmt() {
        return burdenedPriceAmt;
    }

    public void setBurdenedPriceAmt(BigDecimal burdenedPriceAmt) {
        this.burdenedPriceAmt = burdenedPriceAmt;
    }

    public Date getCreateDt() {
        return createDt;
    }

    public void setCreateDt(Date createDt) {
        this.createDt = createDt;
    }

    public String getCreateUserId() {
        return createUserId;
    }

    public void setCreateUserId(String createUserId) {
        this.createUserId = createUserId;
    }

    public Integer getEcatItemId() {
        return ecatItemId;
    }

    public void setEcatItemId(Integer ecatItemId) {
        this.ecatItemId = ecatItemId;
    }

    public Integer getIpPackLevel() {
        return ipPackLevel;
    }

    public void setIpPackLevel(Integer ipPackLevel) {
        this.ipPackLevel = ipPackLevel;
    }

    public String getIpPackCd() {
        return ipPackCd;
    }

    public void setIpPackCd(String ipPackCd) {
        this.ipPackCd = ipPackCd;
    }

    public Integer getIpPackQty() {
        return ipPackQty;
    }

    public void setIpPackQty(Integer ipPackQty) {
        this.ipPackQty = ipPackQty;
    }

    public String getIpGtin() {
        return ipGtin;
    }

    public void setIpGtin(String ipGtin) {
        this.ipGtin = ipGtin;
    }

    public Date getLastUpdateDt() {
        return lastUpdateDt;
    }

    public void setLastUpdateDt(Date lastUpdateDt) {
        this.lastUpdateDt = lastUpdateDt;
    }

    public String getLastUpdateUserId() {
        return lastUpdateUserId;
    }

    public void setLastUpdateUserId(String lastUpdateUserId) {
        this.lastUpdateUserId = lastUpdateUserId;
    }

    public String getLowUomInd() {
        return lowUomInd;
    }

    public void setLowUomInd(String lowUomInd) {
        this.lowUomInd = lowUomInd;
    }

    public Integer getMaximumOrderQty() {
        return maximumOrderQty;
    }

    public void setMaximumOrderQty(Integer maximumOrderQty) {
        this.maximumOrderQty = maximumOrderQty;
    }

    public String getMedAirBridgeInd() {
        return medAirBridgeInd;
    }

    public void setMedAirBridgeInd(String medAirBridgeInd) {
        this.medAirBridgeInd = medAirBridgeInd;
    }

    public Integer getMinimumOrderQty() {
        return minimumOrderQty;
    }

    public void setMinimumOrderQty(Integer minimumOrderQty) {
        this.minimumOrderQty = minimumOrderQty;
    }

    public Integer getMultipleOrderQty() {
        return multipleOrderQty;
    }

    public void setMultipleOrderQty(Integer multipleOrderQty) {
        this.multipleOrderQty = multipleOrderQty;
    }

    public String getNsn() {
        return nsn;
    }

    public void setNsn(String nsn) {
        this.nsn = nsn;
    }

    public String getPackCubeUomCd() {
        return packCubeUomCd;
    }

    public void setPackCubeUomCd(String packCubeUomCd) {
        this.packCubeUomCd = packCubeUomCd;
    }

    public Integer getPackCubeVol() {
        return packCubeVol;
    }

    public void setPackCubeVol(Integer packCubeVol) {
        this.packCubeVol = packCubeVol;
    }

    public Integer getPackLengthDm() {
        return packLengthDm;
    }

    public void setPackLengthDm(Integer packLengthDm) {
        this.packLengthDm = packLengthDm;
    }

    public String getPackLengthUomCd() {
        return packLengthUomCd;
    }

    public void setPackLengthUomCd(String packLengthUomCd) {
        this.packLengthUomCd = packLengthUomCd;
    }

    public Integer getPackGrossWeight() {
        return packGrossWeight;
    }

    public void setPackGrossWeight(Integer packGrossWeight) {
        this.packGrossWeight = packGrossWeight;
    }

    public String getPackGrossWeightUomCd() {
        return packGrossWeightUomCd;
    }

    public void setPackGrossWeightUomCd(String packGrossWeightUomCd) {
        this.packGrossWeightUomCd = packGrossWeightUomCd;
    }

    public Integer getPackHeightDm() {
        return packHeightDm;
    }

    public void setPackHeightDm(Integer packHeightDm) {
        this.packHeightDm = packHeightDm;
    }

    public String getPackHeightUomCd() {
        return packHeightUomCd;
    }

    public void setPackHeightUomCd(String packHeightUomCd) {
        this.packHeightUomCd = packHeightUomCd;
    }

    public BigDecimal getPackPriceAmt() {
        return packPriceAmt;
    }

    public void setPackPriceAmt(BigDecimal packPriceAmt) {
        this.packPriceAmt = packPriceAmt;
    }

    public Integer getPackWidthDm() {
        return packWidthDm;
    }

    public void setPackWidthDm(Integer packWidthDm) {
        this.packWidthDm = packWidthDm;
    }

    public String getPackWidthUomCd() {
        return packWidthUomCd;
    }

    public void setPackWidthUomCd(String packWidthUomCd) {
        this.packWidthUomCd = packWidthUomCd;
    }

    public Date getPriceEffDt() {
        return priceEffDt;
    }

    public void setPriceEffDt(Date priceEffDt) {
        this.priceEffDt = priceEffDt;
    }

    public Date getPriceExpDt() {
        return priceExpDt;
    }

    public void setPriceExpDt(Date priceExpDt) {
        this.priceExpDt = priceExpDt;
    }

    public Integer getProductSourcePriceSeqId() {
        return productSourcePriceSeqId;
    }

    public void setProductSourcePriceSeqId(Integer productSourcePriceSeqId) {
        this.productSourcePriceSeqId = productSourcePriceSeqId;
    }

    public BigDecimal getTaxAmt() {
        return taxAmt;
    }

    public void setTaxAmt(BigDecimal taxAmt) {
        this.taxAmt = taxAmt;
    }

    public String getSosCd() {
        return sosCd;
    }

    public void setSosCd(String sosCd) {
        this.sosCd = sosCd;
    }

    public Integer getSosSerial() {
        return sosSerial;
    }

    public void setSosSerial(Integer sosSerial) {
        this.sosSerial = sosSerial;
    }
}