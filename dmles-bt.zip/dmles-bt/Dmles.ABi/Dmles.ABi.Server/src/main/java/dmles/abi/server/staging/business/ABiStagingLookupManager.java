package dmles.abi.server.staging.business;

import dmles.abi.core.datamodel.PingData;
import dmles.abi.server.staging.dao.ABiCatalogStagingRecordDao;
import dmles.abi.server.staging.dao.ABiStagingLookupDao;
import dmles.abi.server.dao.PingDataDao;
import dmles.abi.server.datamodel.PingDataDO;
import java.util.List;
import javax.ejb.Stateless;
import javax.inject.Inject;
import mil.jmlfdc.common.business.BusinessManager;
import mil.jmlfdc.common.utils.ObjectMapper;
import org.slf4j.Logger;

@Stateless
public class ABiStagingLookupManager extends BusinessManager {

    @Inject
    private Logger log;
    
    @Inject
    private PingDataDao pingDataDao;

    @Inject
    private ABiStagingLookupDao abiStagingLookupDao;
    
    @Inject
    private ObjectMapper objectMapper;      
    
    public PingData getPing(){
        log.info("Pinged the BT ABi STAGING LOOKUP Manager!");
        log.info("User: {}", currentUserBt.getPkiDn());
        PingDataDO pingDo = pingDataDao.getPingData("Hello from the ABi STAGING LOOKUP Manager...");
        return objectMapper.getObject(PingData.class, pingDo);
    }
    
    public List<String> getProductStatusList() {
        return abiStagingLookupDao.getProductStatusList();
    }
    
    public List<String> getDisposableReusableList() {
        return abiStagingLookupDao.getDisposableReusableList();
    }
    
    public List<String> getSterileNonSterileList() {
        return abiStagingLookupDao.getSterileNonSterileList();
    }
    
    public List<String> getHazardCodeList() {
        return abiStagingLookupDao.getHazardCodeList();
    }
    
    public List<String> getLatexCodeList() {
        return abiStagingLookupDao.getLatexCodeList();
    }

    public List<String> getGenderList() {
        return abiStagingLookupDao.getGenderList();
    }

    public List<String> getConfigurableItemList() {
        return abiStagingLookupDao.getConfigurableItemList();
    }
    
    public List<String> getCustomizableItemList() {
        return abiStagingLookupDao.getCustomizableItemList();
    }
    
    public List<String> getBrandGenericList() {
        return abiStagingLookupDao.getBrandGenericList();
    }
    
    public List<String> getDeaCodeList() {
        return abiStagingLookupDao.getDeaCodeList();
    }
    
    public List<String> getDosageFormList() {
        return abiStagingLookupDao.getDosageFormList();
    }
    
    public List<String> getDrugCategoryCodeList() {
        return abiStagingLookupDao.getDrugCategoryCodeList();
    }

    public List<String> getManufacturerTypeaheadList(String filterData) {
        return abiStagingLookupDao.getManufacturerTypeaheadList(filterData);
    }
    
    public List<String> getDocumentTypeList() {
        return abiStagingLookupDao.getDocumentTypeList();
    }
}
