package dmles.abi.server.staging.datamodel;

import java.io.Serializable;
import org.mongodb.morphia.annotations.Embedded;

@Embedded
public class ProductIdentifierDO implements Serializable {
    private static final long serialVersionUID = 1L;
    private String identifier;
    private String identifierType;

    public ProductIdentifierDO() {
        
    }
    
    public ProductIdentifierDO(ProductIdentifierDO source) {
        this.identifier = source.identifier;
        this.identifierType = source.identifierType;
    }

    public String getIdentifier() {
        return identifier;
    }

    public void setIdentifier(String identifier) {
        this.identifier = identifier;
    }

    public String getIdentifierType() {
        return identifierType;
    }

    public void setIdentifierType(String identifierType) {
        this.identifierType = identifierType;
    }
}
