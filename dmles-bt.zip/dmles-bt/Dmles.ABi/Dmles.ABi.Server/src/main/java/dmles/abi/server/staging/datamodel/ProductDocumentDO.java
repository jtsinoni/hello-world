package dmles.abi.server.staging.datamodel;

import org.mongodb.morphia.annotations.Embedded;

@Embedded
public class ProductDocumentDO {
    private String documentType;
    private String documentName;
    private String fileName;
    private String documentURL;
    
    public String getDocumentType() {
        return this.documentType;
    }
    
    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }
    
    public String getDocumentName() {
        return this.documentName;
    }
    
    public void setDocumentName(String documentName) {
        this.documentName = documentName;
    }
    
    public String getFileName() {
        return this.fileName;
    }
    
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
    
    public String getDocumentURL() {
        return this.documentURL;
    }
    
    public void setDocumentURL(String documentURL) {
        this.documentURL = documentURL;
    }
}
