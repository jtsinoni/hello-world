package dmles.abi.server.refactor.dao;

import java.io.StringReader;
import org.apache.deltaspike.core.api.config.ConfigProperty;

import java.util.Map;
import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.json.Json;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonReader;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.Invocation.Builder;
import javax.ws.rs.core.MediaType;
import org.jboss.resteasy.client.jaxrs.ResteasyClientBuilder;
import org.slf4j.Logger;

// TODO: Rewrite as a singleton, wasting to many resources
// previous testing showed an issue when using Dependent. 
//@Dependent
// removed request scoped because it was too resource intensive
////////////////////////////////////////////////////////////////////////////////
// TODO: NEEDS TO BE REFACTORED!!!!!!!!!!!!
// THIS CLASS NEEDS TO BE REFACTORED INTO A COMMON AREA SINCE IT IS/CAN BE USED
// BY MULTIPLE MODULES.
//------------------------------------------------------------------------------
// This class was copied from the Search module and repackaged so we 
// will be ready for the March 3 Demo.
// 
// NOTE: At present, there are two Elastic Search Instances.
// Equipment uses the ES 2.4 instance, whereas
// ABi (Catalog) uses the ES 5.2 instance.
// 
// Not sure if both instances will stay around, or whether Equipment will
// eventually move to ES 5.2.
//
// NOTE: ES 5.2 server settings are HARDCODED in this class.
// This decision was made so we don't have to mess with the deploy scripts
// and manage additional injectable properties for both of the ES instances.
// If both ES versions are required, hopefully this can be resolved when
// there is a move to a central/common configuration file.
////////////////////////////////////////////////////////////////////////////////
@RequestScoped
public class ElasticSearch5Dao {

//  NOTE: FOR ELASTIC SEARCH 5.2, WE WILL NOT INJECT THESE PROPERTIES.
//  THEY WILL BE TEMPORARILY HARDCODED INTO THE CONSTRUCTOR FOR NOW.
//    @Inject
//    @ConfigProperty(name = "esClientPort")
    private int clientPort;

//  NOTE: FOR ELASTIC SEARCH 5.2, WE WILL NOT INJECT THESE PROPERTIES.
//  THEY WILL BE TEMPORARILY HARDCODED INTO THE CONSTRUCTOR FOR NOW.
//    @Inject
//    @ConfigProperty(name = "esHostName")
    private String esHostName;

//  NOTE: FOR ELASTIC SEARCH 5.2, WE WILL NOT INJECT THESE PROPERTIES.
//  THEY WILL BE TEMPORARILY HARDCODED INTO THE CONSTRUCTOR FOR NOW.
//    @Inject
//    @ConfigProperty(name = "esMaxResults")
    private int maxResults;

    @Inject
    Logger log;
    
    @PostConstruct
    public void initialize() {
        //  NOTE: FOR ELASTIC SEARCH 5.2, WE WILL NOT INJECT THESE PROPERTIES.
        //  THEY WILL BE TEMPORARILY HARDCODED INTO THE CONSTRUCTOR FOR NOW.
        this.esHostName = "dmeddb3004";
        this.clientPort = 9200;
        this.maxResults = 250;
        log.info("Initializing ElasticSearch5Dao. host name is: " + this.esHostName + 
                " and client port is: " + this.clientPort);
    }
    
    public String getSearchResults(String elasticIndex, String elasticType, 
                                   String[] fields, Map<String, Object> templateParams,
                                   JsonObject aggregationsJsonObject) {
        String responseString = "";

        Client client = constructClient();
        Builder target = buildTarget(client, elasticIndex);

        String elasticSearchString = buildSearchJsonString(elasticIndex, elasticType, 
                        fields, templateParams, aggregationsJsonObject);
        log.info("elasticSearchString is " + elasticSearchString);

        responseString = target.post(Entity.entity(elasticSearchString, MediaType.APPLICATION_JSON), String.class);
        return responseString;
    }

    private Client constructClient() {
        log.info("Starting ElasticSearch5Dao.constructClient()...");
        ResteasyClientBuilder builder = new ResteasyClientBuilder();
        builder.hostnameVerification(ResteasyClientBuilder.HostnameVerificationPolicy.ANY);
        builder.disableTrustManager();
        
        // At some point, we will do certificate stuff in here with keystores

        Client client = builder.build();
        log.info("   Client built successfully.");
        return client;
    }

    private Invocation.Builder buildTarget(Client client, String elasticIndex) {
        // this is the URL we need to hit for elastic
        // e.ghttp://dmeddb3004:9200/enterprisecatalog/_search
        String targetString = String.format("http://%s:%d/%s/_search", 
                this.esHostName, this.clientPort, elasticIndex.toLowerCase());
        System.out.println(String.format("Built target: %s", targetString));
        return client.target(targetString).request(MediaType.APPLICATION_JSON);
    }

    private String buildSearchJsonString(String elasticIndex, String elasticType, 
                                         String[] fields,
                                         Map<String, Object> templateParams,
                                         JsonObject aggregationsJsonObject) {
        
        JsonArrayBuilder fieldsJsonArrayBuilder = Json.createArrayBuilder();
        for (String fieldName : fields) {
            fieldsJsonArrayBuilder = fieldsJsonArrayBuilder.add(fieldName);
        }
        
                
        String searchParamValue = getTemplateParamValue(templateParams, "searchKey", "_all");
        String analyzeWildcardParamValue = getTemplateParamValue(templateParams, "analyzeWildcard", "true");
        String searchValueParamValue = getTemplateParamValue(templateParams, "searchValue", "*");
        String defaultOperatorParamValue = getTemplateParamValue(templateParams, "defaultOperator", "AND");
        String allowLeadingWildcardParamValue = getTemplateParamValue(templateParams, "allowLeadingWildcard", "true");
        String typeParamValue = getTemplateParamValue(templateParams, "type", elasticType);
        String indexParamValue = getTemplateParamValue(templateParams, "index", elasticIndex);
        
        JsonObjectBuilder queryStringBuilder = Json.createObjectBuilder()
                .add("default_field",searchParamValue)
                .add("analyze_wildcard", analyzeWildcardParamValue)
                .add("query",searchValueParamValue)
                .add("default_operator",defaultOperatorParamValue)
                .add("allow_leading_wildcard", allowLeadingWildcardParamValue);
                
        JsonObjectBuilder queryJsonBuilder = Json.createObjectBuilder()
                .add("bool", Json.createObjectBuilder()
                    .add("must", Json.createArrayBuilder()
                        .add(Json.createObjectBuilder()
                                .add("term", Json.createObjectBuilder()
                                        .add("_type", typeParamValue)
                                )
                        )
                        .add(Json.createObjectBuilder()
                                .add("term", Json.createObjectBuilder()
                                        .add("_index", indexParamValue.toLowerCase())
                            )
                        )
                        .add(Json.createObjectBuilder()
                                .add("query_string", queryStringBuilder)
                        )
                    )
                );

        String aggregationsParamValue = getTemplateParamValue(templateParams, "aggregations", null);
        JsonObject elasticAggregationsJsonObject = null;
        
        if ((aggregationsParamValue != null) && (!aggregationsParamValue.isEmpty())) {
            StringReader stringReader = new StringReader(aggregationsParamValue);
            JsonReader reader = Json.createReader(stringReader);
            
            elasticAggregationsJsonObject = reader.readObject();
        }
        
        JsonObjectBuilder inlineJsonBuilder = Json.createObjectBuilder()
                .add("from", 0)
                .add("size", maxResults)
                // '_source' was 'fields' in ES 4.2
                .add("_source", fieldsJsonArrayBuilder)
                .add("query", queryJsonBuilder);
        
        if (elasticAggregationsJsonObject != null) {
            inlineJsonBuilder = inlineJsonBuilder.add("aggregations", elasticAggregationsJsonObject);
        }

        String queryString = inlineJsonBuilder.build().toString();
        return queryString;
    }
    
    private String getTemplateParamValue(Map<String, Object> templateParams, String key, String defaultValue) {
        String value = templateParams.keySet().contains(key) ?
                templateParams.get(key).toString() : defaultValue;
        return value;
    }
}
