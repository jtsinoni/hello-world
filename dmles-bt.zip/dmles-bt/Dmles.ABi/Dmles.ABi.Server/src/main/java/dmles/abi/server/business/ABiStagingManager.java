package dmles.abi.server.business;

import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import dmles.abi.core.datamodel.PingData;
import dmles.abi.core.datamodel.staging.ABiCatalogStagingRecord;
import dmles.abi.server.dao.ABiCatalogStagingRecordDao;
import dmles.abi.server.dao.PingDataDao;
import dmles.abi.server.datamodel.PingDataDO;
import dmles.abi.server.datamodel.staging.ABiCatalogStagingRecordDO;
import mil.jmlfdc.common.datamodel.CurrentUserBT;
import java.util.List;
import javax.ejb.Stateless;
import javax.inject.Inject;
import mil.jmlfdc.common.business.BusinessManager;
import mil.jmlfdc.common.utils.ObjectMapper;
import org.bson.Document;
import org.slf4j.Logger;

@Stateless
public class ABiStagingManager extends BusinessManager {

    @Inject
    private Logger log;
    
    @Inject
    private PingDataDao pingDataDao;

    @Inject
    private ABiCatalogStagingRecordDao abiCatalogStagingRecordDao;
    
    @Inject
    private ObjectMapper objectMapper;      
    
    public PingData getPing(){
        log.info("Pinged the BT ABi STAGING Manager!");
        log.info("User: {}", currentUserBt.getPkiDn());
        PingDataDO pingDo = pingDataDao.getPingData("Hello from the ABi STAGING Manager...");
        return objectMapper.getObject(PingData.class, pingDo);
    }
    

    public List<ABiCatalogStagingRecord> searchRecords(String filterData) {
        log.info("inside of searchRecords - query is *" + filterData + "*");

        log.info("******************************************************************************************");

        List<ABiCatalogStagingRecordDO> dbRecords = abiCatalogStagingRecordDao.searchRecords(filterData);
        log.info("Retrieved: " + dbRecords.size() + " records.");
        log.info("****** CALLING THE OBJECTMAPPER.GETLIST....");
        List<ABiCatalogStagingRecord> returnRecords = objectMapper.getList(ABiCatalogStagingRecord[].class, dbRecords);
        log.info("****** BACK FROM OBJECTMAPPER.GETLIST...");
        return returnRecords;
    }

//    Look at IEquipmentService > getCatalogSearchResults, then follow it to the DAO.  
//    It doesn't use the object mapper and is pretty close to going from ES to GUI all in either JSON or String format.
//    Save the run around, and look at ElasticSearchManager > getCatalogSearchResults.  
//    and the API response, def different.    
    public String findRecordsJson(int startIndex, int numEntriesToReturn) {
        log.info("inside of findRecordsJson");
        log.info("startIndex is " + startIndex);
        log.info("numEntriesToReturn is " + numEntriesToReturn);

        MongoDatabase db = abiCatalogStagingRecordDao.getMongoDatabase("enterpriseCatalog");
        MongoCollection coll = db.getCollection("abiCatalogStaging");

        FindIterable<Document> results = coll.find().skip(startIndex).limit(numEntriesToReturn);
        log.info("Just got back from finding results...");

        StringBuilder sb = new StringBuilder();
        sb.append("[ ");
        for (Document doc : results) {
            log.info("got a document: " + doc.toString());
            log.info("and it's JSON is like " + doc.toJson());
            String jsonStr = doc.toJson();
            jsonStr.replaceAll("\"_id\": \\{", "")
                    .replaceAll("\\},", "")
                    .replaceAll("    \"$oid\"", "\"id\"");
            sb.append(jsonStr);
            sb.append(",");
        }
        sb.deleteCharAt(sb.length() - 1);
        sb.append(" ]");
        String products = sb.toString();
        products = products.replaceAll("private Boolean ", "");
        return products;
    }

    public ABiCatalogStagingRecord updateRecord(ABiCatalogStagingRecord updatedRecord) {
        log.info("inside of updateRecord");
        ABiCatalogStagingRecordDO inputRecord = objectMapper.getObject(ABiCatalogStagingRecordDO.class, updatedRecord);
        abiCatalogStagingRecordDao.upsert(inputRecord);
        return objectMapper.getObject(ABiCatalogStagingRecord.class, inputRecord);
    }

    public ABiCatalogStagingRecord createRecord() {
        log.info("inside of createRecord");
        ABiCatalogStagingRecordDO newRecord = new ABiCatalogStagingRecordDO();
        newRecord.setCatalogSource("RESEARCH");
        return objectMapper.getObject(ABiCatalogStagingRecord.class, newRecord);
    }
    
    public List<String> getProductStatusList() {
        return abiCatalogStagingRecordDao.getProductStatusList();
    }
    
    public List<String> getDisposableReusableList() {
        return abiCatalogStagingRecordDao.getDisposableReusableList();
    }
    
    public List<String> getSterileNonSterileList() {
        return abiCatalogStagingRecordDao.getSterileNonSterileList();
    }
    
    public List<String> getHazardCodeList() {
        return abiCatalogStagingRecordDao.getHazardCodeList();
    }
    
    public List<String> getLatexCodeList() {
        return abiCatalogStagingRecordDao.getLatexCodeList();
    }

    public List<String> getGenderList() {
        return abiCatalogStagingRecordDao.getGenderList();
    }

}
