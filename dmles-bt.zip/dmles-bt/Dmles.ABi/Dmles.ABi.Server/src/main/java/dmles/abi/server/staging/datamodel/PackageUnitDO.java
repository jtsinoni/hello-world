package dmles.abi.server.staging.datamodel;

import java.io.Serializable;
import mil.jmlfdc.common.datamodel.MorphiaEntity;
import org.mongodb.morphia.annotations.Entity;

@Entity(value = "packageUnit", noClassnameStored = true)
public class PackageUnitDO extends MorphiaEntity implements Serializable {
    private static long serialVersionUID = 1L;

    private String ansiPackUnit;
    private String dodPackUnit;
    private String packText;
    private boolean inUse;

    public PackageUnitDO() {
        
    }
    
    public String getAnsiPackUnit() {
        return ansiPackUnit;
    }

    public void setAnsiPackUnit(String ansiPackUnit) {
        this.ansiPackUnit = ansiPackUnit;
    }

    public String getDodPackUnit() {
        return dodPackUnit;
    }

    public void setDodPackUnit(String dodPackUnit) {
        this.dodPackUnit = dodPackUnit;
    }

    public String getPackText() {
        return packText;
    }

    public void setPackText(String packText) {
        this.packText = packText;
    }

    public boolean isInUse() {
        return inUse;
    }

    public void setInUse(boolean inUse) {
        this.inUse = inUse;
    }
}
