package dmles.abi.server.taxonomy.dao;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import dmles.abi.core.datamodel.taxonomy.UnspscClass;
import dmles.abi.core.datamodel.taxonomy.UnspscClassHierarchy;
import dmles.abi.core.datamodel.taxonomy.UnspscCommodity;
import dmles.abi.core.datamodel.taxonomy.UnspscFamily;
import dmles.abi.core.datamodel.taxonomy.UnspscFamilyHierarchy;
import dmles.abi.core.datamodel.taxonomy.UnspscLevelDetails;
import dmles.abi.core.datamodel.taxonomy.UnspscRecord;
import dmles.abi.core.datamodel.taxonomy.UnspscSegment;
import dmles.abi.core.datamodel.taxonomy.UnspscSegmentHierarchy;
import dmles.abi.server.taxonomy.datamodel.UnspscRecordDO;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.enterprise.context.Dependent;
import javax.inject.Inject;
import mil.jmlfdc.common.dao.BaseDao;
import org.bson.Document;
import org.mongodb.morphia.Datastore;
import org.mongodb.morphia.query.CriteriaContainer;
import org.mongodb.morphia.query.Query;
import org.slf4j.Logger;

@Dependent
public class ABiTaxonomyDao extends BaseDao<UnspscRecordDO, String> {

    @Inject
    private Logger logger;

    public ABiTaxonomyDao() {
        super(UnspscRecordDO.class);
    }

    public List<UnspscSegment> getSegments() {
        MongoDatabase mdb = getMongoDatabase();
        MongoCursor<Document> rows = mdb.getCollection("unspsc")
                .aggregate(
                        Arrays.asList(
                                new Document("$group", new Document("_id",
                                        new Document("segment", "$segment")
                                                .append("segmentTitle", "$segmentTitle")
                                )
                                        .append("count", new Document("$sum", 1))
                                )
                        )
                )
                .iterator();
        List<UnspscSegment> segmentRecords = new ArrayList<UnspscSegment>();
        while (rows.hasNext()) {
            Document row = rows.next();
            Document id = row.get("_id", Document.class);
            String segment = id.get("segment", String.class);
            String segmentTitle = id.get("segmentTitle", String.class);
            UnspscSegment rec = new UnspscSegment();
            rec.segmentId = segment;
            rec.segmentTitle = segmentTitle;
            segmentRecords.add(rec);
        }
        segmentRecords.sort((o1, o2) -> o1.segmentId.compareTo(o2.segmentId));;
        return segmentRecords;
    }

    public List<UnspscFamily> getFamilies(String segmentId) {
        MongoDatabase mdb = getMongoDatabase();
        MongoCursor<Document> rows = mdb.getCollection("unspsc")
                .aggregate(
                        Arrays.asList(
                                new Document("$match", new Document("segment", segmentId)),
                                new Document("$group", new Document("_id",
                                        new Document("segment", "$segment")
                                                .append("family", "$family")
                                                .append("familyTitle", "$familyTitle")
                                )
                                        .append("count", new Document("$sum", 1))
                                )
                        )
                )
                .iterator();
        List<UnspscFamily> familyRecords = new ArrayList<>();
        while (rows.hasNext()) {
            Document row = rows.next();
            Document id = row.get("_id", Document.class);
            String segment = id.get("segment", String.class);
            String family = id.get("family", String.class);
            String familyTitle = id.get("familyTitle", String.class);
            UnspscFamily rec = new UnspscFamily();
            rec.segmentId = segment;
            rec.familyId = family;
            rec.familyTitle = familyTitle;
            familyRecords.add(rec);
        }
        familyRecords.sort((o1, o2) -> o1.familyId.compareTo(o2.familyId));;
        return familyRecords;
    }

    public List<UnspscClass> getClasses(String familyId) {
        MongoDatabase mdb = getMongoDatabase();
        MongoCursor<Document> rows = mdb.getCollection("unspsc")
                .aggregate(
                        Arrays.asList(
                                new Document("$match", new Document("family", familyId)),
                                new Document("$group", new Document("_id",
                                        new Document("segment", "$segment")
                                                .append("family", "$family")
                                                .append("class", "$class")
                                                .append("classTitle", "$classTitle")
                                )
                                        .append("count", new Document("$sum", 1))
                                )
                        )
                )
                .iterator();
        List<UnspscClass> classRecords = new ArrayList<>();
        while (rows.hasNext()) {
            Document row = rows.next();
            Document id = row.get("_id", Document.class);
            String segment = id.get("segment", String.class);
            String family = id.get("family", String.class);
            String classId = id.get("class", String.class);
            String classTitle = id.get("classTitle", String.class);
            UnspscClass rec = new UnspscClass();
            rec.segmentId = segment;
            rec.familyId = family;
            rec.classId = classId;
            rec.classTitle = classTitle;
            classRecords.add(rec);
        }
        classRecords.sort((o1, o2) -> o1.classId.compareTo(o2.classId));;
        return classRecords;
    }

    public List<UnspscCommodity> getCommodities(String classId) {
        MongoDatabase mdb = getMongoDatabase();
        MongoCursor<Document> rows = mdb.getCollection("unspsc")
                .aggregate(
                        Arrays.asList(
                                new Document("$match", new Document("class", classId)),
                                new Document("$group", new Document("_id",
                                        new Document("segment", "$segment")
                                                .append("family", "$family")
                                                .append("class", "$class")
                                                .append("commodity", "$commodity")
                                                .append("commodityTitle", "$commodityTitle")
                                                .append("definition", "$definition")
                                )
                                        .append("count", new Document("$sum", 1))
                                )
                        )
                )
                .iterator();
        List<UnspscCommodity> commodityRecords = new ArrayList<>();
        while (rows.hasNext()) {
            Document row = rows.next();
            Document id = row.get("_id", Document.class);
            String segment = id.get("segment", String.class);
            String family = id.get("family", String.class);
            String classIdVal = id.get("class", String.class);
            String commodity = id.get("commodity", String.class);
            String commodityTitle = id.get("commodityTitle", String.class);
            String definition = id.get("definition", String.class);
            UnspscCommodity rec = new UnspscCommodity();
            rec.segmentId = segment;
            rec.familyId = family;
            rec.classId = classIdVal;
            rec.commodityId = commodity;
            rec.commodityTitle = commodityTitle;
            rec.definition = definition;
            commodityRecords.add(rec);
        }
        commodityRecords.sort((o1, o2) -> o1.commodityId.compareTo(o2.commodityId));;
        return commodityRecords;
    }

    public UnspscSegmentHierarchy getSegmentHierarchy(String segmentId) {
        UnspscSegmentHierarchy segmentHierarchy = new UnspscSegmentHierarchy();
        UnspscRecord segment = getSegment(segmentId);
        segmentHierarchy.segmentId = segment.segmentId;
        segmentHierarchy.segmentTitle = segment.segmentTitle;

        for (UnspscFamily family : getFamilies(segmentHierarchy.segmentId)) {
            UnspscFamilyHierarchy familyHierarchy = new UnspscFamilyHierarchy();
            familyHierarchy.familyId = family.familyId;
            familyHierarchy.familyTitle = family.familyTitle;
            for (UnspscClass classRec : getClasses(familyHierarchy.familyId)) {
                UnspscClassHierarchy classHierarchy = new UnspscClassHierarchy();
                classHierarchy.classId = classRec.classId;
                classHierarchy.classTitle = classRec.classTitle;
                List<UnspscCommodity> commodities = getCommodities(classHierarchy.classId);
                classHierarchy.commodities.addAll(commodities);
                familyHierarchy.classes.add(classHierarchy);
            }
            segmentHierarchy.families.add(familyHierarchy);
        }
        return segmentHierarchy;
    }

    public UnspscLevelDetails getTaxonomyLevelDetails(String level, String levelId) {
        UnspscLevelDetails details = new UnspscLevelDetails();
        details.level = level;
        details.levelId = levelId;
        
        switch (level.toLowerCase()) {
            case "segment":
                UnspscRecord segment = getSegment(levelId);
                details.segmentTitle = getStringOrDefault(segment.segmentTitle, "");
                break;
            case "family":
                UnspscRecord family = getFamily(levelId);
                details.segmentTitle = getStringOrDefault(family.segmentTitle, "");
                details.familyTitle = getStringOrDefault(family.familyTitle, "");
                break;
            case "class":
                UnspscRecord classRec = getClass(levelId);
                details.segmentTitle = getStringOrDefault(classRec.segmentTitle, "");
                details.familyTitle = getStringOrDefault(classRec.familyTitle, "");
                details.classTitle = getStringOrDefault(classRec.classTitle, "");
                break;
            case "commodity":
                UnspscRecord commodity = getCommodity(levelId);
                details.segmentTitle = getStringOrDefault(commodity.segmentTitle, "");
                details.familyTitle = getStringOrDefault(commodity.familyTitle, "");
                details.classTitle = getStringOrDefault(commodity.classTitle, "");
                details.commodityTitle = getStringOrDefault(commodity.commodityTitle, "");
                break;
        }
        return details;
    }

    public UnspscLevelDetails getTaxonomyLevelDetailsByUnspscCode(Integer unspscCode) {
        String levelId = unspscCode.toString();
        String level = "";
        if (levelId.endsWith("000000")) {
            level = "segment";
        } else if (levelId.endsWith("0000")) {
            level = "family";
        } else if (levelId.endsWith("00")) {
            level = "class";
        } else {
            level = "commodity";
        }
        UnspscLevelDetails details = getTaxonomyLevelDetails(level, levelId);
        return details;
    }

    private MongoDatabase getMongoDatabase() {
        Datastore ds = this.getDatastore();
        MongoClient client = ds.getMongo();
        String dbName = ds.getDB().getName();
        MongoDatabase mongoDb = client.getDatabase(dbName);
        return mongoDb;
    }

    private UnspscRecord getSegment(String segmentId) {
        MongoDatabase mdb = getMongoDatabase();
        MongoCursor<Document> rows = mdb.getCollection("unspsc")
                .aggregate(
                        Arrays.asList(
                                new Document("$match", new Document("segment", segmentId)),
                                new Document("$group", new Document("_id",
                                        new Document("segment", "$segment")
                                                .append("segmentTitle", "$segmentTitle")
                                )
                                        .append("count", new Document("$sum", 1))
                                )
                        )
                )
                .iterator();
        Document row = rows.next();
        Document id = row.get("_id", Document.class);
        String segment = id.get("segment", String.class);
        String segmentTitle = id.get("segmentTitle", String.class);
        UnspscRecord segmentRecord = new UnspscRecord();
        segmentRecord.segmentId = segment;
        segmentRecord.segmentTitle = segmentTitle;
        return segmentRecord;
    }

    private UnspscRecord getFamily(String familyId) {
        MongoDatabase mdb = getMongoDatabase();
        MongoCursor<Document> rows = mdb.getCollection("unspsc")
                .aggregate(
                        Arrays.asList(
                                new Document("$match", new Document("family", familyId)),
                                new Document("$group", new Document("_id",
                                        new Document("segment", "$segment")
                                                .append("segmentTitle", "$segmentTitle")
                                                .append("family", "$family")
                                                .append("familyTitle", "$familyTitle")
                                )
                                        .append("count", new Document("$sum", 1))
                                )
                        )
                )
                .iterator();
        Document row = rows.next();
        Document id = row.get("_id", Document.class);
        String segment = id.get("segment", String.class);
        String segmentTitle = id.get("segmentTitle", String.class);
        String family = id.get("family", String.class);
        String familyTitle = id.get("familyTitle", String.class);
        UnspscRecord familyRecord = new UnspscRecord();
        familyRecord.segmentId = segment;
        familyRecord.segmentTitle = segmentTitle;
        familyRecord.familyId = family;
        familyRecord.familyTitle = familyTitle;
        return familyRecord;
    }

    private UnspscRecord getClass(String classId) {
        MongoDatabase mdb = getMongoDatabase();
        MongoCursor<Document> rows = mdb.getCollection("unspsc")
                .aggregate(
                        Arrays.asList(
                                new Document("$match", new Document("class", classId)),
                                new Document("$group", new Document("_id",
                                        new Document("segment", "$segment")
                                                .append("segmentTitle", "$segmentTitle")
                                                .append("family", "$family")
                                                .append("familyTitle", "$familyTitle")
                                                .append("class", "$class")
                                                .append("classTitle", "$classTitle")
                                )
                                        .append("count", new Document("$sum", 1))
                                )
                        )
                )
                .iterator();
        Document row = rows.next();
        Document id = row.get("_id", Document.class);
        String segment = id.get("segment", String.class);
        String segmentTitle = id.get("segmentTitle", String.class);
        String family = id.get("family", String.class);
        String familyTitle = id.get("familyTitle", String.class);
        String classIdVal = id.get("class", String.class);
        String classTitle = id.get("classTitle", String.class);
        UnspscRecord classRecord = new UnspscRecord();
        classRecord.segmentId = segment;
        classRecord.segmentTitle = segmentTitle;
        classRecord.familyId = family;
        classRecord.familyTitle = familyTitle;
        classRecord.classId = classIdVal;
        classRecord.classTitle = classTitle;
        return classRecord;
    }

    private UnspscRecord getCommodity(String commodityId) {
        MongoDatabase mdb = getMongoDatabase();
        MongoCursor<Document> rows = mdb.getCollection("unspsc")
                .aggregate(
                        Arrays.asList(
                                new Document("$match", new Document("commodity", commodityId)),
                                new Document("$group", new Document("_id",
                                        new Document("segment", "$segment")
                                                .append("segmentTitle", "$segmentTitle")
                                                .append("family", "$family")
                                                .append("familyTitle", "$familyTitle")
                                                .append("class", "$class")
                                                .append("classTitle", "$classTitle")
                                                .append("commodity", "$commodity")
                                                .append("commodityTitle", "$commodityTitle")
                                                .append("definition", "$definition")
                                )
                                        .append("count", new Document("$sum", 1))
                                )
                        )
                )
                .iterator();
        Document row = rows.next();
        Document id = row.get("_id", Document.class);
        String segment = id.get("segment", String.class);
        String segmentTitle = id.get("segmentTitle", String.class);
        String family = id.get("family", String.class);
        String familyTitle = id.get("familyTitle", String.class);
        String classIdVal = id.get("class", String.class);
        String classTitle = id.get("classTitle", String.class);
        String commodity = id.get("commodity", String.class);
        String commodityTitle = id.get("commodityTitle", String.class);
        String definition = id.get("definition", String.class);

        UnspscRecord commodityRecord = new UnspscRecord();
        commodityRecord.segmentId = segment;
        commodityRecord.segmentTitle = segmentTitle;
        commodityRecord.familyId = family;
        commodityRecord.familyTitle = familyTitle;
        commodityRecord.classId = classIdVal;
        commodityRecord.classTitle = classTitle;
        commodityRecord.commodityId = commodity;
        commodityRecord.commodityTitle = commodityTitle;
        commodityRecord.definition = definition;
        return commodityRecord;
    }

    private String getStringOrDefault(Object obj, String defaultValue) {
        String returnValue = defaultValue;
        if (obj != null) {
            returnValue = obj.toString();
        }
        return returnValue;
    }

    public boolean doesUnspscCodeExist(Integer unspscCode) {
        String unspscCodeStr = unspscCode.toString();
        Query<UnspscRecordDO> query = this.getQuery();
        CriteriaContainer orCriteria = query.or();
        orCriteria.add(query.criteria("segment").equal(unspscCodeStr));
        orCriteria.add(query.criteria("family").equal(unspscCodeStr));
        orCriteria.add(query.criteria("class").equal(unspscCodeStr));
        orCriteria.add(query.criteria("commodity").equal(unspscCodeStr));
        query.or(orCriteria);
        long count = query.count();
        return (count > 0);
    }
}
