package dmles.abi.server.staging.business;

import dmles.abi.core.datamodel.PingData;
import dmles.abi.core.datamodel.staging.ABiCatalogStagingRecord;
import dmles.abi.server.dao.PingDataDao;
import dmles.abi.server.dao.SiteCatalogRecordDao;
import dmles.abi.server.datamodel.PingDataDO;
import dmles.abi.server.staging.dao.ABiStagingJoinDao;
import dmles.abi.server.staging.dao.ABiStagingMoveRecordsDao;
import dmles.abi.server.staging.datamodel.ABiCatalogStagingRecordDO;
import java.util.List;
import javax.ejb.Stateless;
import javax.inject.Inject;
import mil.jmlfdc.common.business.BusinessManager;
import mil.jmlfdc.common.utils.ObjectMapper;
import org.slf4j.Logger;

@Stateless
public class ABiStagingMoveRecordsManager extends BusinessManager {

    @Inject
    private Logger log;
    
    @Inject
    private PingDataDao pingDataDao;

    @Inject
    private ABiStagingMoveRecordsDao abiStagingMoveRecordsDao;

    @Inject
    private SiteCatalogRecordDao siteCatalogRecordDao;
    
    @Inject
    private ObjectMapper objectMapper;      
    
    public PingData getPing(){
        log.info("Pinged the BT ABi STAGING MOVE RECORD Manager!");
        log.info("User: {}", currentUserBt.getPkiDn());
        PingDataDO pingDo = pingDataDao.getPingData("Hello from the ABi STAGING MOVE RECORD Manager...");
        return objectMapper.getObject(PingData.class, pingDo);
    }

    public Long getProductionCandidateRecordListCount() {
        Long count = abiStagingMoveRecordsDao.getProductionCandidateRecordListCount();
        return count;
    }

    public List<ABiCatalogStagingRecord> getProductionCandidateRecordList(int startIndex, int numEntriesToReturn) {
        List<ABiCatalogStagingRecordDO> dbRecords = abiStagingMoveRecordsDao.getProductionCandidateRecordList(startIndex, numEntriesToReturn);
        List<ABiCatalogStagingRecord> returnRecords = objectMapper.getList(ABiCatalogStagingRecord[].class, dbRecords);
        return returnRecords;
    }

    public Long getGHXStagingRecordListCount() {
        Long count = abiStagingMoveRecordsDao.getGHXStagingRecordListCount();
        return count;
    }

    public List<ABiCatalogStagingRecord> getGHXStagingRecordList(int startIndex, int numEntriesToReturn) {
        List<ABiCatalogStagingRecordDO> dbRecords = abiStagingMoveRecordsDao.getGHXStagingRecordList(startIndex, numEntriesToReturn);
        List<ABiCatalogStagingRecord> returnRecords = objectMapper.getList(ABiCatalogStagingRecord[].class, dbRecords);
        return returnRecords;
    }

    public Long getStagingRecordsMatchingSiteCatalogCount() {
        List<Integer> prodSeqIdList = siteCatalogRecordDao.getProductSeqIdList();
        List<String> ndcList = siteCatalogRecordDao.getNdcList();
        Long count = abiStagingMoveRecordsDao.getStagingRecordsMatchingSiteCatalogCount(prodSeqIdList, ndcList);
        return count;
    }

    public List<ABiCatalogStagingRecord> getStagingRecordsMatchingSiteCatalogList(int startIndex, int numEntriesToReturn) {
        List<Integer> prodSeqIdList = siteCatalogRecordDao.getProductSeqIdList();
        List<String> ndcList = siteCatalogRecordDao.getNdcList();
        List<ABiCatalogStagingRecordDO> dbRecords = 
                abiStagingMoveRecordsDao.getStagingRecordsMatchingSiteCatalogList(prodSeqIdList, ndcList, startIndex, numEntriesToReturn);
        List<ABiCatalogStagingRecord> returnRecords = objectMapper.getList(ABiCatalogStagingRecord[].class, dbRecords);
        return returnRecords;
    }
    
    public Long getStagingRecordsMatchingSiteCatalogProductSeqIdCount() {
        List<Integer> prodSeqIdList = siteCatalogRecordDao.getProductSeqIdList();
        Long count = abiStagingMoveRecordsDao.getStagingRecordsMatchingSiteCatalogProductSeqIdCount(prodSeqIdList);
        return count;
    }
   
    public List<ABiCatalogStagingRecord> getStagingRecordsMatchingSiteCatalogProductSeqIdList(int startIndex, 
                            int numEntriesToReturn) {
        List<Integer> prodSeqIdList = siteCatalogRecordDao.getProductSeqIdList();
        List<ABiCatalogStagingRecordDO> dbRecords = 
                abiStagingMoveRecordsDao.getStagingRecordsMatchingSiteCatalogProductSeqIdList(prodSeqIdList, startIndex, numEntriesToReturn);
        List<ABiCatalogStagingRecord> returnRecords = objectMapper.getList(ABiCatalogStagingRecord[].class, dbRecords);
        return returnRecords;
    }

    
    public Long getStagingRecordsMatchingSiteCatalogNdcCount() {
        List<String> ndcList = siteCatalogRecordDao.getNdcList();
        Long count = abiStagingMoveRecordsDao.getStagingRecordsMatchingSiteCatalogNdcCount(ndcList);
        return count;
    }
   
    public List<ABiCatalogStagingRecord> getStagingRecordsMatchingSiteCatalogNdcList(int startIndex, 
                            int numEntriesToReturn) {
        List<String> ndcList = siteCatalogRecordDao.getNdcList();
        List<ABiCatalogStagingRecordDO> dbRecords = 
                abiStagingMoveRecordsDao.getStagingRecordsMatchingSiteCatalogNdcList(ndcList, startIndex, numEntriesToReturn);
        List<ABiCatalogStagingRecord> returnRecords = objectMapper.getList(ABiCatalogStagingRecord[].class, dbRecords);
        return returnRecords;
    }

    public Long markGHXStagingRecordsForProduction() {
        Long count = abiStagingMoveRecordsDao.markGHXStagingRecordsForProduction();
        return count;
    }

    public Long markStagingRecordsMatchingSiteCatalogForProduction() {
        List<Integer> prodSeqIdList = siteCatalogRecordDao.getProductSeqIdList();
        List<String> ndcList = siteCatalogRecordDao.getNdcList();
        Long count = abiStagingMoveRecordsDao.markStagingRecordsMatchingSiteCatalogForProduction(prodSeqIdList, ndcList);
        return count;
    }

    public Long markStagingRecordsMatchingSiteCatalogProdSeqIdForProduction() {
        List<Integer> prodSeqIdList = siteCatalogRecordDao.getProductSeqIdList();
        Long count = abiStagingMoveRecordsDao.markStagingRecordsMatchingSiteCatalogProdSeqIdForProduction(prodSeqIdList);
        return count;
    }

    public Long markStagingRecordsMatchingSiteCatalogNdcForProduction() {
        List<String> ndcList = siteCatalogRecordDao.getNdcList();
        Long count = abiStagingMoveRecordsDao.markStagingRecordsMatchingSiteCatalogNdcForProduction(ndcList);
        return count;
    }
                
    public Long resetProductionCandidateRecordList() {
        Long count = abiStagingMoveRecordsDao.resetProductionCandidateRecordList();
        return count;
    }
}
