package dmles.abi.server.staging.datamodel;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.mongodb.morphia.annotations.Embedded;

@Embedded
public class PackagingDetailDO implements Serializable {

    private static final long serialVersionUID = 1L;

    private String enterprisePackageIdentifier;
    private String gtin;
// Removed on 23Mar2017
//    private String niin;
//    private String nsn;
    @Embedded
    private List<ProductIdentifierDO> otherPackageIdentifiers = new ArrayList<>();
    private String packageUnit;
    private Integer packageQuantity;
    private String gudidIdentifierType;
    private List<String> barcodeData = new ArrayList<>();

// Removed on 23Mar2017
//    private String unitDescription;
    
    // Added on 23Mar2017
    private String packageUnitText;
    private String packageUnitDescription;
    private Integer doseOrUseCount;
    private Integer innerPackMultiple;
    private List<String> nsn = new ArrayList<>();
    
    public PackagingDetailDO() {

    }

    public PackagingDetailDO(List<ProductIdentifierDO> otherPackageIdentifiers,
            List<String> barcodeData) {
        this.otherPackageIdentifiers = otherPackageIdentifiers;
        this.barcodeData = barcodeData;
    }

    public String getEnterprisePackageIdentifier() {
        return enterprisePackageIdentifier;
    }

    public void setEnterprisePackageIdentifier(String enterprisePackageIdentifier) {
        this.enterprisePackageIdentifier = enterprisePackageIdentifier;
    }

    public String getGtin() {
        return gtin;
    }

    public void setGtin(String gtin) {
        this.gtin = gtin;
    }

//    public String getNiin() {
//        return niin;
//    }
//
//    public void setNiin(String niin) {
//        this.niin = niin;
//    }
//
//    public String getNsn() {
//        return nsn;
//    }
//
//    public void setNsn(String nsn) {
//        this.nsn = nsn;
//    }

    public List<ProductIdentifierDO> getOtherPackageIdentifiers() {
        return otherPackageIdentifiers;
    }

    public void setOtherPackageIdentifiers(List<ProductIdentifierDO> otherPackageIdentifiers) {
        this.otherPackageIdentifiers = otherPackageIdentifiers;
    }

    public String getPackageUnit() {
        return packageUnit;
    }

    public void setPackageUnit(String packageUnit) {
        this.packageUnit = packageUnit;
    }

    public Integer getPackageQuantity() {
        return packageQuantity;
    }

    public void setPackageQuantity(Integer packageQuantity) {
        this.packageQuantity = packageQuantity;
    }

    public String getGudidIdentifierType() {
        return gudidIdentifierType;
    }

    public void setGudidIdentifierType(String gudidIdentifierType) {
        this.gudidIdentifierType = gudidIdentifierType;
    }

    public List<String> getBarcodeData() {
        return barcodeData;
    }

    public void setBarcodeData(List<String> barcodeData) {
        this.barcodeData = barcodeData;
    }
    
//    public String getUnitDescription() {
//        return unitDescription;
//    }
//    
//    public void setUnitDescription(String unitDescription) {
//        this.unitDescription = unitDescription;
//    }

    public String getPackageUnitText() {
        return this.packageUnitText;
    }
    
    public void setPackageUnitText(String packageUnitText) {
        this.packageUnitText = packageUnitText;
    }
    
    public String getPackageUnitDescription() {
        return this.packageUnitDescription;
    }
    
    public void setPackageUnitDescription(String packageUnitDescription) {
        this.packageUnitDescription = packageUnitDescription;
    }
    
    public Integer getDoseOrUseCount() {
        return this.doseOrUseCount;
    }
    
    public void setDoseOrUseCount(Integer doseOrUseCount) {
        this.doseOrUseCount = doseOrUseCount;
    }
    
    public Integer getInnerPackMultiple() {
        return this.innerPackMultiple;
    }
    
    public void setInnerPackMultiple(Integer innerPackMultiple) {
        this.innerPackMultiple = innerPackMultiple;
    }
    
    public List<String> getNsn() {
        return this.nsn;
    }
    
    public void setNsn(List<String> nsn) {
        this.nsn = nsn;
    }
}
