package dmles.abi.server.rest;

import dmles.abi.core.datamodel.PingData;
import dmles.abi.core.datamodel.staging.ABiCatalogStagingRecord;
import dmles.abi.core.staging.IABiStagingMoveRecordsService;
import dmles.abi.server.staging.business.ABiStagingMoveRecordsManager;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.QueryParam;
import mil.jmlfdc.common.rest.RestApiBase;

@Api(value="ABiStagingMoveRecordsRestApi", description="ABI Staging Move Records to Production REST API")
@ApplicationScoped
public class ABiStagingMoveRecordsRestApi extends RestApiBase implements IABiStagingMoveRecordsService {

    @Inject
    private ABiStagingMoveRecordsManager abiStagingMoveRecordsManager;

    @Override
    @ApiOperation(value = "Test the REST API is functional.")
    public PingData getPing() {
        return abiStagingMoveRecordsManager.getPing();
    }

    @Override
    @ApiOperation(value = "Get a Count of the Staging Records that are currently marked for moving to the Production ABI Catalog.")
    public Long getProductionCandidateRecordListCount() {
        return abiStagingMoveRecordsManager.getProductionCandidateRecordListCount();
    }

    @Override
    @ApiOperation(value = "Get a list of the Staging Records that are currently marked for moving to the Production ABI Catalog.")
    public List<ABiCatalogStagingRecord> getProductionCandidateRecordList(@QueryParam("startIndex") int startIndex, 
                            @QueryParam("numEntriesToReturn") int numEntriesToReturn) {
        return abiStagingMoveRecordsManager.getProductionCandidateRecordList(startIndex, numEntriesToReturn);
    }

    @Override
    @ApiOperation(value = "Get a count of the GHX Records in Staging that have not been marked for Production.")
    public Long getGHXStagingRecordListCount() {
        return abiStagingMoveRecordsManager.getGHXStagingRecordListCount();
    }

    @Override
    @ApiOperation(value = "Get a list of the GHX Records in Staging that have not been marked for Production.")
    public List<ABiCatalogStagingRecord> getGHXStagingRecordList(@QueryParam("startIndex") int startIndex, 
                            @QueryParam("numEntriesToReturn") int numEntriesToReturn) {
        return abiStagingMoveRecordsManager.getGHXStagingRecordList(startIndex, numEntriesToReturn);
    }

    @Override
    @ApiOperation(value = "Get a count of the Staging Records that have matches in the Site Catalog by MMC ID or NDC")
    public Long getStagingRecordsMatchingSiteCatalogCount() {
        return abiStagingMoveRecordsManager.getStagingRecordsMatchingSiteCatalogCount();
    }

    @Override
    @ApiOperation(value = "Get a list of the Staging Records that have matches in the Site Catalog by MMC ID or NDC")
    public List<ABiCatalogStagingRecord> getStagingRecordsMatchingSiteCatalogList(@QueryParam("startIndex") int startIndex, 
                            @QueryParam("numEntriesToReturn") int numEntriesToReturn) {
        return abiStagingMoveRecordsManager.getStagingRecordsMatchingSiteCatalogList(startIndex, numEntriesToReturn);
    }
    
    @Override
    @ApiOperation(value = "Get a list of the Staging Records that have matches in the Site Catalog by MMC ID")
    public Long getStagingRecordsMatchingSiteCatalogProductSeqIdCount() {
        return abiStagingMoveRecordsManager.getStagingRecordsMatchingSiteCatalogProductSeqIdCount();
    }
   
    @Override
    @ApiOperation(value = "Get a list of the Staging Records that have matches in the Site Catalog by MMC ID")
    public List<ABiCatalogStagingRecord> getStagingRecordsMatchingSiteCatalogProductSeqIdList(@QueryParam("startIndex") int startIndex, 
                            @QueryParam("numEntriesToReturn") int numEntriesToReturn) {
        return abiStagingMoveRecordsManager.getStagingRecordsMatchingSiteCatalogProductSeqIdList(startIndex, numEntriesToReturn);
    }

    
    @Override
    @ApiOperation(value = "Get a list of the Staging Records that have matches in the Site Catalog by NDC")
    public Long getStagingRecordsMatchingSiteCatalogNdcCount() {
        return abiStagingMoveRecordsManager.getStagingRecordsMatchingSiteCatalogNdcCount();
    }
   
    @Override
    @ApiOperation(value = "Get a list of the Staging Records that have matches in the Site Catalog by NDC")
    public List<ABiCatalogStagingRecord> getStagingRecordsMatchingSiteCatalogNdcList(@QueryParam("startIndex") int startIndex, 
                            @QueryParam("numEntriesToReturn") int numEntriesToReturn) {
        return abiStagingMoveRecordsManager.getStagingRecordsMatchingSiteCatalogNdcList(startIndex, numEntriesToReturn);
    }

    @Override
    @ApiOperation(value = "Mark the list of GHX Staging Records for Production.")
    public Long markGHXStagingRecordsForProduction() {
        return abiStagingMoveRecordsManager.markGHXStagingRecordsForProduction();
    }

    @Override
    @ApiOperation(value = "Mark the list of Staging Records matching the Site Catalog for Production.")
    public Long markStagingRecordsMatchingSiteCatalogForProduction() {
        return abiStagingMoveRecordsManager.markStagingRecordsMatchingSiteCatalogForProduction();
    }

    @Override
    @ApiOperation(value = "Mark the list of Staging Records matching the Site Catalog by Prod Seq ID for Production.")
    public Long markStagingRecordsMatchingSiteCatalogProdSeqIdForProduction() {
        return abiStagingMoveRecordsManager.markStagingRecordsMatchingSiteCatalogProdSeqIdForProduction();
    }

    @Override
    @ApiOperation(value = "Mark the list of Staging Records matching the Site Catalog by NDC for Production.")
    public Long markStagingRecordsMatchingSiteCatalogNdcForProduction() {
        return abiStagingMoveRecordsManager.markStagingRecordsMatchingSiteCatalogNdcForProduction();
    }

    @Override
    @ApiOperation(value = "Resets the list of records that are marked for moving to Production.")
    public Long resetProductionCandidateRecordList() {
        return abiStagingMoveRecordsManager.resetProductionCandidateRecordList();
    }
}
