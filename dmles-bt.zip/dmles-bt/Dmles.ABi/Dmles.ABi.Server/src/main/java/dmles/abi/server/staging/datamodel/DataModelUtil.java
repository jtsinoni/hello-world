package dmles.abi.server.staging.datamodel;

import com.mongodb.DBObject;

public class DataModelUtil {

    public static void fixNumericFieldErrors(String[] integerFields, DBObject dbObject) {
        for (String fld : integerFields) {
            Object o = dbObject.get(fld);
            if (o == null) {
                continue;
            }
            String objectValue = o.toString();
            boolean canParse = canParseInteger(objectValue);
            if (!canParse) {
                canParse = canParseDouble(objectValue);
                if (canParse) {
                    double val = Double.parseDouble(objectValue);
                    int iVal = (int)val;
                    dbObject.put(fld, iVal);
                } else {
                    dbObject.put(fld, 0);
                }
            }
        }
    }
    
    public static boolean canParseInteger(String value) {
        boolean canParse = true;
        try {
            int val = Integer.parseInt(value);
        } catch (NumberFormatException ex) {
            canParse = false;
        }
        return canParse;
    }
    
    public static boolean canParseDouble(String value) {
        boolean canParse = true;
        try {
            double val = Double.parseDouble(value);
        } catch (NumberFormatException ex) {
            canParse = false;
        }
        return canParse;
    }
}
