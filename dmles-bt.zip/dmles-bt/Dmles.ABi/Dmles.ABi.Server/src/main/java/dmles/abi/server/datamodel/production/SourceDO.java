package dmles.abi.server.datamodel.production;

import org.mongodb.morphia.annotations.Embedded;

import java.io.Serializable;

@Embedded
public class SourceDO implements Serializable {
    private static final long serialVersionUID = 1L;
    private Integer sosSerial;
    private String sosCd;
    private String sosTypeCd;
    private String supplierNm;
    private String typeItemId;
    private String vendItemNum;
    private Integer ipPackSerial;
    private String dropShipFeeInd;
    private String dropShipOnlyInd;

    public SourceDO() {
    }

    public Integer getSosSerial() {
        return sosSerial;
    }

    public void setSosSerial(Integer sosSerial) {
        this.sosSerial = sosSerial;
    }

    public String getSosCd() {
        return sosCd;
    }

    public void setSosCd(String sosCd) {
        this.sosCd = sosCd;
    }

    public String getSosTypeCd() {
        return sosTypeCd;
    }

    public void setSosTypeCd(String sosTypeCd) {
        this.sosTypeCd = sosTypeCd;
    }

    public String getSupplierNm() {
        return supplierNm;
    }

    public void setSupplierNm(String supplierNm) {
        this.supplierNm = supplierNm;
    }

    public String getTypeItemId() {
        return typeItemId;
    }

    public void setTypeItemId(String typeItemId) {
        this.typeItemId = typeItemId;
    }

    public String getVendItemNum() {
        return vendItemNum;
    }

    public void setVendItemNum(String vendItemNum) {
        this.vendItemNum = vendItemNum;
    }

    public Integer getIpPackSerial() {
        return ipPackSerial;
    }

    public void setIpPackSerial(Integer ipPackSerial) {
        this.ipPackSerial = ipPackSerial;
    }

    public String getDropShipFeeInd() {
        return dropShipFeeInd;
    }

    public void setDropShipFeeInd(String dropShipFeeInd) {
        this.dropShipFeeInd = dropShipFeeInd;
    }

    public String getDropShipOnlyInd() {
        return dropShipOnlyInd;
    }

    public void setDropShipOnlyInd(String dropShipOnlyInd) {
        this.dropShipOnlyInd = dropShipOnlyInd;
    }
}
