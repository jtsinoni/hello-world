package dmles.abi.server.dao;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import dmles.abi.server.datamodel.production.ABiProductionDO;
import dmles.common.general.logging.Logger;

import java.util.List;
import javax.enterprise.context.Dependent;
import javax.inject.Inject;

import mil.jmlfdc.common.dao.BaseDao;

@Dependent
public class ABiProductionDao extends BaseDao<ABiProductionDO, String> {

    @Inject
    private Logger logger;

    public ABiProductionDao() {
        super(ABiProductionDO.class);
    }

    public List<String> getCommodityTypes() {
        DBCollection m = this.getDatastore().getCollection(ABiProductionDO.class);
        BasicDBObject bdo = new BasicDBObject("commodityType", new BasicDBObject("$ne", null));        
        List<String> commodityTypeList = m.distinct("commodityType", bdo);
        logger.info("######### getCommodityTypes() Done. Count is " + commodityTypeList.size());
        return commodityTypeList;
    }

    public List<String> getProductNouns() {
        DBCollection m = this.getDatastore().getCollection(ABiProductionDO.class);
        BasicDBObject bdo = new BasicDBObject("productNoun", new BasicDBObject("$ne", null));        
        List<String> productNounList = m.distinct("productNoun", bdo);
        logger.info("######### getProductNouns() Done. Count is " + productNounList.size());
        return productNounList;
    }

    public List<String> getUnspscSegments() {
        DBCollection m = this.getDatastore().getCollection(ABiProductionDO.class);
        BasicDBObject bdo = new BasicDBObject("unspscSegment", new BasicDBObject("$ne", null));        
        List<String> unspscSegmentList = m.distinct("unspscSegment", bdo);
        logger.info("######### getUnspscSegments() Done. Count is " + unspscSegmentList.size());
        return unspscSegmentList;
    }
}
