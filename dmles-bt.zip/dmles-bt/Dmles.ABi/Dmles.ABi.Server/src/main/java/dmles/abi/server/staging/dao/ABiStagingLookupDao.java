package dmles.abi.server.staging.dao;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import dmles.abi.server.staging.datamodel.ABiCatalogStagingRecordDO;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;
import javax.enterprise.context.Dependent;
import javax.inject.Inject;
import mil.jmlfdc.common.dao.BaseDao;
import org.mongodb.morphia.query.Query;
import org.slf4j.Logger;

@Dependent
public class ABiStagingLookupDao extends BaseDao<ABiCatalogStagingRecordDO, String>  {

    @Inject
    private Logger logger;

    public ABiStagingLookupDao() {
        super(ABiCatalogStagingRecordDO.class);
    }

    public List<String> getProductStatusList() {
        String[] valueArray = {"ACTIVE", "INACTIVE", "OBSOLETE", "REPLACED", "OFFMARKET"};
        return buildSortedStringList(getValueList("productStatus", valueArray));
    }

    public List<String> getDisposableReusableList() {
        String[] valueArray = {"DISPOSABLE", "REUSABLE"};
        return buildSortedStringList(getValueList("disposableReusable", valueArray));
    }

    public List<String> getSterileNonSterileList() {
        String[] valueArray = {"STERILE", "NONSTERILE"};
        return buildSortedStringList(getValueList("sterileNonsterile", valueArray));
    }

    public List<String> getHazardCodeList() {
        String[] valueArray = {"HAZARDOUS", "NONHAZARDOUS"};
        return buildSortedStringList(getValueList("hazardCode", valueArray));
    }

    public List<String> getLatexCodeList() {
        String[] valueArray = {"LATEX", "LATEX-FREE"};
        return buildSortedStringList(getValueList("latexCode", valueArray));
    }

    public List<String> getGenderList() {
        String[] valueArray = {"MALE", "FEMALE", "UNISEX"};
        return buildSortedStringList(getValueList("gender", valueArray));
    }

    public List<String> getConfigurableItemList() {
        String[] valueArray = {"YES", "NO"};
        return buildSortedStringList(valueArray);
    }

    public List<String> getCustomizableItemList() {
        String[] valueArray = {"YES", "NO"};
        return buildSortedStringList(valueArray);
    }

    public List<String> getBrandGenericList() {
        String[] valueArray = {"BRANDNAME", "GENERIC"};
        return buildSortedStringList(valueArray);
    }

    public List<String> getDeaCodeList() {
        String[] valueArray = {"II", "III", "IV", "V"};
        return buildSortedStringList(valueArray);
    }

    public List<String> getDosageFormList() {
        String[] valueArray = {"TABLET", "LIQUID", "CREAM"};
        return buildSortedStringList(valueArray);
    }

    public List<String> getDrugCategoryCodeList() {
        String[] valueArray = {"ATC", "RX"};
        return buildSortedStringList(getValueList("drugCategory", valueArray));
    }

    public List<String> getManufacturerTypeaheadList(String filterData) {
        // NOTE: RUNNING Variation 1 or 2 of this code always causes this error:
        // Caused by: java.lang.IllegalArgumentException: The value for key value can not be null

        // Variation 1
        // String[] valueArray = {"ATC", "RX" };
        // return buildSortedStringList(getValueList("manufacturer", valueArray));
        // Variation 2
        // DBCollection m = this.getDatastore().getCollection(ABiCatalogStagingRecordDO.class);
        // List<String> valueList = m.distinct("manufacturer", new BasicDBObject());
        // Variation 3 - this one just blows memory
//        DBCollection m = this.getDatastore().getCollection(ABiCatalogStagingRecordDO.class);
//        List<String> valueList = new ArrayList<>();
//
//        m.find().forEach(record -> {
//            Object obj = record.get("manufacturer");
//            if (obj != null) {
//                String mfr = obj.toString();
//                if (!valueList.contains(mfr)) {
//                    valueList.add(mfr);
//                }
//            }
//        });
        List<String> valueList = new ArrayList<>();
        Query<ABiCatalogStagingRecordDO> query = getQuery(ABiCatalogStagingRecordDO.class);
        query.offset(0).limit(1000).criteria("manufacturer").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE));
        query.forEach(record -> {
            String mfr = record.getManufacturer();
            if (mfr != null) {
                if (!valueList.contains(mfr)) {
                    valueList.add(mfr);
                }
            }
        });

        return valueList;
    }

    public List<String> getDocumentTypeList() {
        String[] valueArray = {"Safety Data Sheet", "User Manual", "Product Literature"};
        return buildSortedStringList(valueArray);
    }

    private List<String> getValueList(String attributeName, String[] requiredValues) {
        DBCollection m = this.getDatastore().getCollection(ABiCatalogStagingRecordDO.class);
        List<String> valueList = m.distinct(attributeName, new BasicDBObject());
        if (requiredValues != null) {
            valueList = addIfNotInCollection(valueList, requiredValues);
        }

        return valueList;
    }

    private List<String> addIfNotInCollection(List<String> stringList, String[] itemArray) {
        for (String item : itemArray) {
            if (!stringList.contains(item)) {
                stringList.add(item);
            }
        }
        return stringList;
    }

    private List<String> buildSortedStringList(String[] valueArray) {
        List<String> list = Arrays.asList(valueArray);
        list.sort((p1, p2) -> p1.compareTo(p2));
        return list;
    }

    private List<String> buildSortedStringList(List<String> valueList) {
        if (!(valueList == null) && !(valueList.isEmpty())) {
            valueList.sort((p1, p2) -> p1.compareTo(p2));
        }
        return valueList;
    }
}
