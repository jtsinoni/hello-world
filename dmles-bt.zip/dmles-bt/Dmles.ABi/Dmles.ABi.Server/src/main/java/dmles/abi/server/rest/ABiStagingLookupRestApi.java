package dmles.abi.server.rest;

import dmles.abi.core.datamodel.PingData;
import dmles.abi.core.datamodel.staging.CommodityClass;
import dmles.abi.core.datamodel.staging.PackageUnit;
import dmles.abi.core.staging.IABiStagingLookupService;
import dmles.abi.server.staging.business.ABiStagingLookupManager;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.QueryParam;
import mil.jmlfdc.common.rest.RestApiBase;

@Api(value="ABiStagingLookupRestApi", description="Manage ABI Staging Lookup REST API")
@ApplicationScoped
public class ABiStagingLookupRestApi extends RestApiBase implements IABiStagingLookupService {

    @Inject
    private ABiStagingLookupManager abiStagingLookupManager;

    @Override
    @ApiOperation(value = "Test the REST API is functional.")
    public PingData getPing() {
        return abiStagingLookupManager.getPing();
    }

    @Override
    @ApiOperation(value = "Get the list of Product Status values.")
    public List<String> getProductStatusList() {
        return abiStagingLookupManager.getProductStatusList();
    }
    
    @Override
    @ApiOperation(value = "Get the list of Disposable/Reusable values.")
    public List<String> getDisposableReusableList() {
        return abiStagingLookupManager.getDisposableReusableList();
    }
    
    @Override
    @ApiOperation(value = "Get the list of Sterile/NonSterile values.")
    public List<String> getSterileNonSterileList() {
        return abiStagingLookupManager.getSterileNonSterileList();
    }
    
    @Override
    @ApiOperation(value = "Get the list of Hazard Code values.")
    public List<String> getHazardCodeList() {
        return abiStagingLookupManager.getHazardCodeList();
    }
    
    @Override
    @ApiOperation(value = "Get the list of Latex Code values.")
    public List<String> getLatexCodeList() {
        return abiStagingLookupManager.getLatexCodeList();
    }
    
    @Override
    @ApiOperation(value = "Get the list of Gender values.")
    public List<String> getGenderList() {
        return abiStagingLookupManager.getGenderList();
    }

    @Override
    @ApiOperation(value = "Get the list of Configurable Item values.")
    public List<String> getConfigurableItemList() {
        return abiStagingLookupManager.getConfigurableItemList();
    }
    
    @Override
    @ApiOperation(value = "Get the list of Customizable values.")
    public List<String> getCustomizableItemList() {
        return abiStagingLookupManager.getCustomizableItemList();
    }
    
    @Override
    @ApiOperation(value = "Get the list of Brand/Generic values.")
    public List<String> getBrandGenericList() {
        return abiStagingLookupManager.getBrandGenericList();
    }
    
    @Override
    @ApiOperation(value = "Get the list of Dea Code values.")
    public List<String> getDeaCodeList() {
        return abiStagingLookupManager.getDeaCodeList();
    }
    
    @Override
    @ApiOperation(value = "Get the list of Dosage Form values.")
    public List<String> getDosageFormList() {
        return abiStagingLookupManager.getDosageFormList();
    }
    
    @Override
    @ApiOperation(value = "Get the list of Drug Category Code values.")
    public List<String> getDrugCategoryCodeList() {
        return abiStagingLookupManager.getDrugCategoryCodeList();
    }
    
    @Override
    @ApiOperation(value = "return a list of manufacturer names that contain the filterData.")
    public List<String> getManufacturerTypeaheadList(@ApiParam(value = "The file ID", required = true) @QueryParam("filterData") String filterData) {
        return abiStagingLookupManager.getManufacturerTypeaheadList(filterData);
    }
        
    @Override
    @ApiOperation(value = "returns a list of valid document types for Product Documentation.")
    public List<String> getDocumentTypeList() {
        return abiStagingLookupManager.getDocumentTypeList();
    }
    
    @Override
    @ApiOperation(value = "returns the list of Package Unit Objects that are in use.")
    public List<PackageUnit> getPackageUnitList() {
        return abiStagingLookupManager.getPackageUnitList();
    }
    
    @Override
    @ApiOperation(value = "returns the list of Commodity Types.")
    public List<String> getCommodityTypeList() {
        return abiStagingLookupManager.getCommodityTypeList();
    }
    
    @Override
    @ApiOperation(value = "returns the list of GUDID Identifier Types.")
    public List<String> getGudidIdentifierTypeList() {
        return abiStagingLookupManager.getGudidIdentifierTypeList();
    }

    @Override
    @ApiOperation(value = "returns the list of Net Content Text values.")
    public List<String> getNetContentTextList() {
        return abiStagingLookupManager.getNetContentTextList();
    }
}
