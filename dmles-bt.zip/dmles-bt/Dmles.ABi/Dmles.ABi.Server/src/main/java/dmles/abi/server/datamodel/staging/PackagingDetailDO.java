package dmles.abi.server.datamodel.staging;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.mongodb.morphia.annotations.Embedded;

@Embedded
public class PackagingDetailDO implements Serializable {

    private static final long serialVersionUID = 1L;

    private String enterprisePackageIdentifier;
    private String gtin;
    private String niin;
    private String nsn;
    @Embedded
    private List<ProductIdentifierDO> otherPackageIdentifiers = new ArrayList<>();
    private String packageUnit;
    private String packageQuantity;
    private String gudidIdentifierType;
    @Embedded
    private List<BarcodeItemDO> barcodeData = new ArrayList<>();

    public PackagingDetailDO() {

    }

    public PackagingDetailDO(List<ProductIdentifierDO> otherPackageIdentifiers,
            List<BarcodeItemDO> barcodeData) {
        this.otherPackageIdentifiers = otherPackageIdentifiers;
        this.barcodeData = barcodeData;
    }

    public String getEnterprisePackageIdentifier() {
        return enterprisePackageIdentifier;
    }

    public void setEnterprisePackageIdentifier(String enterprisePackageIdentifier) {
        this.enterprisePackageIdentifier = enterprisePackageIdentifier;
    }

    public String getGtin() {
        return gtin;
    }

    public void setGtin(String gtin) {
        this.gtin = gtin;
    }

    public String getNiin() {
        return niin;
    }

    public void setNiin(String niin) {
        this.niin = niin;
    }

    public String getNsn() {
        return nsn;
    }

    public void setNsn(String nsn) {
        this.nsn = nsn;
    }

    public List<ProductIdentifierDO> getOtherPackageIdentifiers() {
        return otherPackageIdentifiers;
    }

    public void setOtherPackageIdentifiers(List<ProductIdentifierDO> otherPackageIdentifiers) {
        this.otherPackageIdentifiers = otherPackageIdentifiers;
    }

    public String getPackageUnit() {
        return packageUnit;
    }

    public void setPackageUnit(String packageUnit) {
        this.packageUnit = packageUnit;
    }

    public String getPackageQuantity() {
        return packageQuantity;
    }

    public void setPackageQuantity(String packageQuantity) {
        this.packageQuantity = packageQuantity;
    }

    public String getGudidIdentifierType() {
        return gudidIdentifierType;
    }

    public void setGudidIdentifierType(String gudidIdentifierType) {
        this.gudidIdentifierType = gudidIdentifierType;
    }

    public List<BarcodeItemDO> getBarcodeData() {
        return barcodeData;
    }

    public void setBarcodeData(List<BarcodeItemDO> barcodeData) {
        this.barcodeData = barcodeData;
    }
}
