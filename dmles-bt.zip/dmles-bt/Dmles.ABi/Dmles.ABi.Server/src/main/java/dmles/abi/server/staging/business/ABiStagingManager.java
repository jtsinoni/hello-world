package dmles.abi.server.staging.business;

import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import dmles.abi.core.datamodel.PingData;
import dmles.abi.core.datamodel.staging.ABiCatalogStagingRecord;
import dmles.abi.core.datamodel.staging.ABiCatalogStatistics;
import dmles.abi.core.datamodel.staging.ApprovalResult;
import dmles.abi.core.datamodel.staging.ApprovalStatus;
import dmles.abi.core.datamodel.staging.PackagingDetail;
import dmles.abi.server.staging.dao.ABiCatalogStagingRecordDao;
import dmles.abi.server.dao.PingDataDao;
import dmles.abi.server.datamodel.PingDataDO;
import dmles.abi.server.staging.dao.ABiStagingLookupDao;
import dmles.abi.server.staging.dao.PackageUnitDao;
import dmles.abi.server.staging.datamodel.ABiCatalogStagingRecordDO;
import dmles.abi.server.staging.datamodel.PackagingDetailDO;
import dmles.abi.server.taxonomy.dao.ABiTaxonomyDao;
import mil.jmlfdc.common.business.BusinessManager;
import mil.jmlfdc.common.utils.ObjectMapper;
import org.bson.Document;
import org.slf4j.Logger;

import javax.ejb.Stateless;
import javax.inject.Inject;
import java.util.List;
import mil.jmlfdc.common.utils.StringUtil;
import org.mongodb.morphia.query.ValidationException;

@Stateless
public class ABiStagingManager extends BusinessManager {

    @Inject
    private Logger log;
    
    @Inject
    private PingDataDao pingDataDao;

    @Inject
    private ABiCatalogStagingRecordDao abiCatalogStagingRecordDao;
    
    @Inject
    private PackageUnitDao packageUnitDao;
    
    @Inject
    private ABiTaxonomyDao abiTaxonomyDao;
    
    @Inject
    private ObjectMapper objectMapper;      
    
    public PingData getPing(){
        log.info("Pinged the BT ABi STAGING Manager!");
        log.info("User: {}", currentUserBt.getPkiDn());
        PingDataDO pingDo = pingDataDao.getPingData("Hello from the ABi STAGING Manager...");
        return objectMapper.getObject(PingData.class, pingDo);
    }
    

    public List<ABiCatalogStagingRecord> searchRecords(String mode, String filterData) {
        log.info("inside of searchRecords - mode is *" + mode + "*, query is *" + filterData + "*");
        mode = mode.toUpperCase();
        switch (mode) {
            case "PRODUCTION_CANDIDATES":
            case "MERGED":
            case "AWAITING_APPROVAL":
            case "APPROVED":
            case "PUBLISHED":
            case "ALL":
                break;
            default:
                throw new ValidationException("Invalid search mode specified.");
        }
        log.info("******************************************************************************************");

        List<ABiCatalogStagingRecordDO> dbRecords = abiCatalogStagingRecordDao.searchRecords(mode, filterData);
        log.info("Retrieved: " + dbRecords.size() + " records.");
        log.info("****** CALLING THE OBJECTMAPPER.GETLIST....");
        List<ABiCatalogStagingRecord> returnRecords = objectMapper.getList(ABiCatalogStagingRecord[].class, dbRecords);
        log.info("****** BACK FROM OBJECTMAPPER.GETLIST...");
        return returnRecords;
    }

    // Matt: This can should be moved to the DAO, then you can use "DBCollection m = this.getDatastore().getCollection(ABiCatalogStagingRecordDO.class);"
    // and not hard code the collection name.
//    Look at IEquipmentService > getCatalogSearchResults, then follow it to the DAO.  
//    It doesn't use the object mapper and is pretty close to going from ES to GUI all in either JSON or String format.
//    Save the run around, and look at ElasticSearchManager > getCatalogSearchResults.  
//    and the API response, def different.    
    public String findRecordsJson(int startIndex, int numEntriesToReturn) {
        log.info("inside of findRecordsJson");
        log.info("startIndex is " + startIndex);
        log.info("numEntriesToReturn is " + numEntriesToReturn);

        MongoDatabase db = abiCatalogStagingRecordDao.getMongoDatabase();
        MongoCollection coll = db.getCollection("abiCatalogStaging");

        FindIterable<Document> results = coll.find().skip(startIndex).limit(numEntriesToReturn);
        log.info("Just got back from finding results...");

        // Matt: What happens if there are more permutations to the JSON Data coming from Mongo, such as,
        // $refs, $id, className, etc. I'm worried this could be either fragile or specific to only this area.
        // I recommend using Morphia, or Java MongoClient.

        // Matt: If we are going to this, then, I would recommend passing the JSON data 'as-is'.  Without cleansing or
        // looping.
        StringBuilder sb = new StringBuilder();
        sb.append("[ ");
        for (Document doc : results) {
            log.info("got a document: " + doc.toString());
            log.info("and it's JSON is like " + doc.toJson());
            String jsonStr = doc.toJson();
            jsonStr.replaceAll("\"_id\": \\{", "")
                    .replaceAll("\\},", "")
                    .replaceAll("    \"$oid\"", "\"id\"");
            sb.append(jsonStr);
            sb.append(",");
        }
        sb.deleteCharAt(sb.length() - 1);
        sb.append(" ]");
        String products = sb.toString();
        products = products.replaceAll("private Boolean ", "");
        return products;
    }

    public ABiCatalogStagingRecord updateRecord(ABiCatalogStagingRecord updatedRecord) {
        log.info("inside of updateRecord");
        ABiCatalogStagingRecordDO inputRecord = objectMapper.getObject(ABiCatalogStagingRecordDO.class, updatedRecord);
        abiCatalogStagingRecordDao.updateRecord(inputRecord);
        return objectMapper.getObject(ABiCatalogStagingRecord.class, inputRecord);
    }

    public ABiCatalogStagingRecord createRecord() {
        log.info("inside of createRecord");
        ABiCatalogStagingRecordDO newRecord = abiCatalogStagingRecordDao.createRecord();
        return objectMapper.getObject(ABiCatalogStagingRecord.class, newRecord);
    }

    public ABiCatalogStatistics getStatistics() {
        ABiCatalogStatistics stats = abiCatalogStagingRecordDao.getStatistics();
        return stats;
    }

    public ApprovalStatus canRecordBeApproved(ABiCatalogStagingRecord recordToApprove) {
        ApprovalStatus status = recordCanBeApproved(recordToApprove);
        return status;
    }
    
    public ApprovalResult approveRecord(ABiCatalogStagingRecord recordToApprove) {
        ApprovalStatus status = recordCanBeApproved(recordToApprove);
        ApprovalResult approvalResult = new ApprovalResult();
        approvalResult.isApproved = status.isApproved;
        approvalResult.messageList.addAll(status.messageList);
        approvalResult.approvedRecord = null;
        if (status.isApproved) {
            
            ABiCatalogStagingRecordDO recordToUpdate = objectMapper.getObject(ABiCatalogStagingRecordDO.class, recordToApprove);
            recordToUpdate.setApprovedBy(this.currentUserBt.getFullName());
            recordToUpdate.setRecordStatus("Approved");
            abiCatalogStagingRecordDao.updateRecord(recordToUpdate);
            approvalResult.approvedRecord = objectMapper.getObject(ABiCatalogStagingRecord.class, recordToUpdate);
        }
        return approvalResult;
    }

    private ApprovalStatus recordCanBeApproved(ABiCatalogStagingRecord record) {
        ApprovalStatus status = new ApprovalStatus();
        status.isApproved = true;
        if (StringUtil.isBlankOrNull(record.commodityType)) {
            status.messageList.add("Commodity Type must be specified.");
            status.isApproved = false;
        }
        if (StringUtil.isBlankOrNull(record.enterpriseProductIdentifier)) {
            status.messageList.add("Enterprise Product Identifier must be specified.");
            status.isApproved = false;
        }
        if (record.unspscCode == null) {
            status.messageList.add("A UNSPSC Code must be specified.");
            status.isApproved = false;
        }
        if (!abiTaxonomyDao.doesUnspscCodeExist(record.unspscCode)) {
            status.messageList.add("The specified UNSPSC Code is invalid.");
            status.isApproved = false;
        }
        if (StringUtil.isBlankOrNull(record.packagingDescription)) {
            status.messageList.add("Packaging Description must be specified.");
            status.isApproved = false;
        }
        
        List<PackagingDetail> packaging = record.packaging;
        if (packaging.size() > 0) {
            for (int i = 0; i < packaging.size(); i++) {
                PackagingDetail detail = packaging.get(i);
                if (StringUtil.isBlankOrNull(detail.enterprisePackageIdentifier)) {
                    status.messageList.add(String.format("Packaging entry %d: Enterprise Package Identifier must be specified.", i + 1));
                    status.isApproved = false;
                }
                if (StringUtil.isBlankOrNull(detail.packageUnitDescription)) {
                    status.messageList.add(String.format("Packaging entry %d: Package Unit Description must be specified.", i + 1));
                    status.isApproved = false;
                }
                if (StringUtil.isBlankOrNull(detail.packageUnit)) {
                    status.messageList.add(String.format("Packaging entry %d: A Package Unit must be specified.", i + 1));
                    status.isApproved = false;
                }
                if (!packageUnitDao.doesPackageUnitExist(detail.packageUnit)) {
                    status.messageList.add(String.format("Packaging entry %d: The specified Package Unit is invalid.", i + 1));
                    status.isApproved = false;
                }
            }
        } else {
            status.messageList.add("Packaging details must be specified.");
            status.isApproved = false;
        }
        
        return status;
    }
}
