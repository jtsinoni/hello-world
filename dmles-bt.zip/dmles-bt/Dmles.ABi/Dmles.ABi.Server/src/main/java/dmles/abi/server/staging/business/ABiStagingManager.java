package dmles.abi.server.staging.business;

import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import dmles.abi.core.datamodel.PingData;
import dmles.abi.core.datamodel.staging.ABiCatalogStagingRecord;
import dmles.abi.server.staging.dao.ABiCatalogStagingRecordDao;
import dmles.abi.server.dao.PingDataDao;
import dmles.abi.server.datamodel.PingDataDO;
import dmles.abi.server.staging.datamodel.ABiCatalogStagingRecordDO;
import mil.jmlfdc.common.business.BusinessManager;
import mil.jmlfdc.common.utils.ObjectMapper;
import org.bson.Document;
import org.slf4j.Logger;

import javax.ejb.Stateless;
import javax.inject.Inject;
import java.util.List;

@Stateless
public class ABiStagingManager extends BusinessManager {

    @Inject
    private Logger log;
    
    @Inject
    private PingDataDao pingDataDao;

    @Inject
    private ABiCatalogStagingRecordDao abiCatalogStagingRecordDao;
    
    @Inject
    private ObjectMapper objectMapper;      
    
    public PingData getPing(){
        log.info("Pinged the BT ABi STAGING Manager!");
        log.info("User: {}", currentUserBt.getPkiDn());
        PingDataDO pingDo = pingDataDao.getPingData("Hello from the ABi STAGING Manager...");
        return objectMapper.getObject(PingData.class, pingDo);
    }
    

    public List<ABiCatalogStagingRecord> searchRecords(String filterData) {
        log.info("inside of searchRecords - query is *" + filterData + "*");

        log.info("******************************************************************************************");

        List<ABiCatalogStagingRecordDO> dbRecords = abiCatalogStagingRecordDao.searchRecords(filterData);
        log.info("Retrieved: " + dbRecords.size() + " records.");
        log.info("****** CALLING THE OBJECTMAPPER.GETLIST....");
        List<ABiCatalogStagingRecord> returnRecords = objectMapper.getList(ABiCatalogStagingRecord[].class, dbRecords);
        log.info("****** BACK FROM OBJECTMAPPER.GETLIST...");
        return returnRecords;
    }

    // Matt: This can should be moved to the DAO, then you can use "DBCollection m = this.getDatastore().getCollection(ABiCatalogStagingRecordDO.class);"
    // and not hard code the collection name.
//    Look at IEquipmentService > getCatalogSearchResults, then follow it to the DAO.  
//    It doesn't use the object mapper and is pretty close to going from ES to GUI all in either JSON or String format.
//    Save the run around, and look at ElasticSearchManager > getCatalogSearchResults.  
//    and the API response, def different.    
    public String findRecordsJson(int startIndex, int numEntriesToReturn) {
        log.info("inside of findRecordsJson");
        log.info("startIndex is " + startIndex);
        log.info("numEntriesToReturn is " + numEntriesToReturn);

        MongoDatabase db = abiCatalogStagingRecordDao.getMongoDatabase();
        MongoCollection coll = db.getCollection("abiCatalogStaging");

        FindIterable<Document> results = coll.find().skip(startIndex).limit(numEntriesToReturn);
        log.info("Just got back from finding results...");

        // Matt: What happens if there are more permutations to the JSON Data coming from Mongo, such as,
        // $refs, $id, className, etc. I'm worried this could be either fragile or specific to only this area.
        // I recommend using Morphia, or Java MongoClient.

        // Matt: If we are going to this, then, I would recommend passing the JSON data 'as-is'.  Without cleansing or
        // looping.
        StringBuilder sb = new StringBuilder();
        sb.append("[ ");
        for (Document doc : results) {
            log.info("got a document: " + doc.toString());
            log.info("and it's JSON is like " + doc.toJson());
            String jsonStr = doc.toJson();
            jsonStr.replaceAll("\"_id\": \\{", "")
                    .replaceAll("\\},", "")
                    .replaceAll("    \"$oid\"", "\"id\"");
            sb.append(jsonStr);
            sb.append(",");
        }
        sb.deleteCharAt(sb.length() - 1);
        sb.append(" ]");
        String products = sb.toString();
        products = products.replaceAll("private Boolean ", "");
        return products;
    }

    public ABiCatalogStagingRecord updateRecord(ABiCatalogStagingRecord updatedRecord) {
        log.info("inside of updateRecord");
        ABiCatalogStagingRecordDO inputRecord = objectMapper.getObject(ABiCatalogStagingRecordDO.class, updatedRecord);
        abiCatalogStagingRecordDao.updateRecord(inputRecord);
        return objectMapper.getObject(ABiCatalogStagingRecord.class, inputRecord);
    }

    public ABiCatalogStagingRecord createRecord() {
        log.info("inside of createRecord");
        ABiCatalogStagingRecordDO newRecord = abiCatalogStagingRecordDao.createRecord();
        return objectMapper.getObject(ABiCatalogStagingRecord.class, newRecord);
    }
}
