package dmles.abi.server.staging.dao;

import dmles.abi.server.staging.datamodel.ABiCatalogStagingRecordDO;
import java.lang.reflect.Field;
import java.util.logging.Level;
import org.mongodb.morphia.Datastore;
import org.mongodb.morphia.query.UpdateOperations;
import org.slf4j.Logger;

public class UpdateUtility {
    private Datastore datastore;
    private Logger logger;
    public UpdateUtility(Datastore datastore, Logger logger) {
        this.datastore = datastore;
        this.logger = logger;
    }
    
    public UpdateOperations<ABiCatalogStagingRecordDO> buildUpdateOperations(ABiCatalogStagingRecordDO destRec, 
            ABiCatalogStagingRecordDO srcRec) {
        UpdateOperations<ABiCatalogStagingRecordDO> ops
                = this.datastore.createUpdateOperations(ABiCatalogStagingRecordDO.class);

        int updatedFieldCount = 0;
        try {
            for (Field f : ABiCatalogStagingRecordDO.class.getDeclaredFields()) {
                String fieldName = f.getName();
                Field currentField = ABiCatalogStagingRecordDO.class.getDeclaredField(fieldName);
                currentField.setAccessible(true);
                Object destVal = currentField.get(destRec);
                Object srcVal = currentField.get(srcRec);
                if (valuesAreDifferent(destVal, srcVal)) {
                    ops.set(fieldName, srcVal);
                    this.logger.debug("***** Setting fieldName (" + fieldName + ") to value: " + srcVal.toString());
                    updatedFieldCount++;
                }
            }
        } catch (NoSuchFieldException | SecurityException | IllegalArgumentException | IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ABiCatalogStagingRecordDao.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (updatedFieldCount == 0) {
                ops = null;
            }
            return ops;
        }
    }

    private static boolean valuesAreDifferent(Object destVal, Object srcVal) {
        boolean valuesAreDifferent = false;
        if ((destVal == null) && (srcVal == null)) {
            valuesAreDifferent = false;
        } else if ((destVal == null) && (srcVal != null)) {
            valuesAreDifferent = true;
        } else if ((destVal != null) && (srcVal == null)) {
            valuesAreDifferent = true;
        } else if (!destVal.equals(srcVal)) {
            valuesAreDifferent = true;
        }
        return valuesAreDifferent;
    }
}
