package dmles.abi.server.refactor.business.search;

import java.math.BigDecimal;
import java.util.ArrayList;
import org.elasticsearch.search.aggregations.AggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.enterprise.context.Dependent;
import javax.inject.Inject;
import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import org.elasticsearch.common.xcontent.XContentHelper;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.TermsAggregationBuilder;

////////////////////////////////////////////////////////////////////////////////
// TODO: NEEDS TO BE REFACTORED!!!!!!!!!!!!
// THIS CLASS NEEDS TO BE REFACTORED INTO A COMMON AREA SINCE IT IS/CAN BE USED
// BY MULTIPLE MODULES.
//------------------------------------------------------------------------------
// This class was copied from Dmles.Equipment.Server and repackaged so we 
// will be ready for the March 3 Demo.
////////////////////////////////////////////////////////////////////////////////

@Dependent
public class ElasticSearchAggregations {
    @Inject
    private Logger logger;

    public String processAggregations(String aggs) {
        Map<String, AggregationProperties> aggregationsMap = new HashMap<>();
        JSONParser parser = new JSONParser();
        Object obj;
        try {
            obj = parser.parse(aggs);
            JSONObject jsonObject = (JSONObject) obj;
            JSONArray aggregationsArray = (JSONArray) jsonObject.get("aggregations");
            if (aggregationsArray != null) {
            Iterator<JSONObject> iterator = aggregationsArray.iterator();
                while (iterator.hasNext()) {
                    AggregationProperties currentProperties = new AggregationProperties();
                    JSONObject entry = (JSONObject) iterator.next();
                    currentProperties.setName(entry.get("name").toString());
                    currentProperties.setField(entry.get("field").toString());
                    currentProperties.setSize(entry.get("size").toString());
                    aggregationsMap.put(currentProperties.getName(), currentProperties);
                    // logger.info("Aggregation processed::{}", currentProperties.describe());
                }
            }
        } catch (ParseException ex) {
            logger.error(null, ex);
        }

        return createAggregations(aggregationsMap);
    }

    private String createAggregations(Map<String, AggregationProperties> aggregationsMap) {
        // NOTE: Stopped using the ES Java API to build aggregations.
        JsonObjectBuilder aggregationsBuilder = Json.createObjectBuilder();
        for (Map.Entry<String, AggregationProperties> entry : aggregationsMap.entrySet()) {
            AggregationProperties aggProps = entry.getValue();
            String name = aggProps.getName();
            String field = aggProps.getField();
            String sizeStr = aggProps.getSize();
            Integer size = Integer.parseInt(sizeStr);

// This is the format of ES 5.2 Aggregation object:            
//            "manufacturers": {
//              "terms": {
//                "field": "manufacturer.keyword",
//                "size": 10,
//                "order": {
//                  "_term": "asc"
//                }
//              }
//            }

            aggregationsBuilder
                .add(name, Json.createObjectBuilder()
                    .add("terms", Json.createObjectBuilder()
                        .add("field", field)
                        .add("size", size)
                        .add("order", Json.createObjectBuilder()
                            .add("_term", "asc")
                        )
                    )
                );
        }        
        
        String result = aggregationsBuilder.build().toString();
        return result;
    }

}
