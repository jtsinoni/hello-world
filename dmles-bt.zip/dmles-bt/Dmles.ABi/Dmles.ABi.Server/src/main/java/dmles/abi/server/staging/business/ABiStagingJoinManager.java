package dmles.abi.server.staging.business;

import dmles.abi.core.datamodel.PingData;
import dmles.abi.core.datamodel.staging.ABiCatalogStagingRecord;
import dmles.abi.core.datamodel.staging.join.InitiateJoinSettings;
import dmles.abi.core.datamodel.staging.join.JoinRecordCommand;
import dmles.abi.core.datamodel.staging.join.JoinStagingRecordsState;
import dmles.abi.core.datamodel.staging.join.StagingRecordByMmc;
import dmles.abi.server.staging.dao.ABiCatalogStagingRecordDao;
import dmles.abi.server.staging.dao.ABiStagingJoinDao;
import dmles.abi.server.dao.PingDataDao;
import dmles.abi.server.datamodel.PingDataDO;
import dmles.abi.server.staging.datamodel.ABiCatalogStagingRecordDO;
import java.util.List;
import javax.ejb.Stateless;
import javax.inject.Inject;
import mil.jmlfdc.common.business.BusinessManager;
import mil.jmlfdc.common.utils.ObjectMapper;
import org.slf4j.Logger;

@Stateless
public class ABiStagingJoinManager extends BusinessManager {

    @Inject
    private Logger log;
    
    @Inject
    private PingDataDao pingDataDao;

    @Inject
    private ABiStagingJoinDao abiStagingJoinDao;
    
    @Inject
    private ObjectMapper objectMapper;      
    
    public PingData getPing(){
        log.info("Pinged the BT ABi STAGING JOIN Manager!");
        log.info("User: {}", currentUserBt.getPkiDn());
        PingDataDO pingDo = pingDataDao.getPingData("Hello from the ABi STAGING JOIN Manager...");
        return objectMapper.getObject(PingData.class, pingDo);
    }

    public List<StagingRecordByMmc> getMergePossibilitiesByMmc() {
        return abiStagingJoinDao.getMergePossibilitiesByMmc(objectMapper);
    }

    public JoinStagingRecordsState initiateJoinRecordProcess(InitiateJoinSettings settings) {
        return abiStagingJoinDao.initiateJoinRecordProcess(objectMapper, settings);
    }

    public ABiCatalogStagingRecord processJoinRecordCommand(JoinRecordCommand joinRecordCommand) {
        ABiCatalogStagingRecordDO updatedMasterRecord = abiStagingJoinDao.processJoinRecordCommand(objectMapper, joinRecordCommand);
        return objectMapper.getObject(ABiCatalogStagingRecord.class, updatedMasterRecord);
    }

    public List<ABiCatalogStagingRecord> undoMerge(String masterRecordId) {
        List<ABiCatalogStagingRecordDO> childrenRecords =  abiStagingJoinDao.undoMerge(masterRecordId);
        return objectMapper.getList(ABiCatalogStagingRecord[].class, childrenRecords);
    }
    
    public List<ABiCatalogStagingRecord> getMergedRecordList(String filterData) {
        List<ABiCatalogStagingRecordDO> mergedRecordList = abiStagingJoinDao.getMergedRecordList(filterData);
        return objectMapper.getList(ABiCatalogStagingRecord[].class, mergedRecordList);
    }

}
