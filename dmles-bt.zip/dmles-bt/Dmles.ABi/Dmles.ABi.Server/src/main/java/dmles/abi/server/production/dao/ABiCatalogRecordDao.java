package dmles.abi.server.production.dao;

import dmles.abi.server.production.datamodel.ABiCatalogRecordDO;
import dmles.abi.server.staging.datamodel.ABiCatalogStagingRecordDO;
import javax.enterprise.context.Dependent;
import javax.inject.Inject;
import mil.jmlfdc.common.dao.BaseDao;
import org.slf4j.Logger;

@Dependent
public class ABiCatalogRecordDao extends BaseDao<ABiCatalogRecordDO, String> {

    @Inject
    private Logger logger;

    public ABiCatalogRecordDao() {
        super(ABiCatalogRecordDO.class);
    }
    
}
