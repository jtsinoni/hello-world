package dmles.abi.server.rest;

import dmles.abi.core.ISiteCatalogService;
import dmles.abi.core.datamodel.PingData;
import dmles.abi.core.datamodel.production.SiteCatalogRecord;
import dmles.abi.server.business.SiteCatalogManager;
import io.swagger.annotations.Api;

import java.text.DateFormat;
import java.util.Date;
import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

import mil.jmlfdc.common.rest.RestApiBase;

@Api(value="SiteCatalogRestApi", description="ABI Site Catalog REST API")
@ApplicationScoped
public class SiteCatalogRestApi extends RestApiBase implements ISiteCatalogService {

    @Inject
    private SiteCatalogManager SiteCatalogManager;

    @Override
    public PingData getPing() {
        return SiteCatalogManager.getPing();
    }

    @Override
    public List<SiteCatalogRecord> getSiteCatalogByEnterpriseId(@QueryParam("enterpriseProductIdentifier") String enterpriseProductIdentifier) {

        List<SiteCatalogRecord> recordList = SiteCatalogManager.getSiteCatalogByEnterpriseId(enterpriseProductIdentifier);
        return recordList;
    }

    @Override
    public List<SiteCatalogRecord> getSiteCatalogByProductId(@QueryParam("productSeqId") Integer productSeqId) {

        List<SiteCatalogRecord> recordList = SiteCatalogManager.getSiteCatalogByProductId(productSeqId);
        return recordList;
    }
}
