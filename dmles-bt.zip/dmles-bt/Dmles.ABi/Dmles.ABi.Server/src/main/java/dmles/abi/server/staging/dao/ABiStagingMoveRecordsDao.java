package dmles.abi.server.staging.dao;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoDatabase;
import dmles.abi.server.dao.SiteCatalogRecordDao;
import dmles.abi.server.staging.datamodel.ABiCatalogStagingRecordDO;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import javax.enterprise.context.Dependent;
import javax.inject.Inject;
import mil.jmlfdc.common.dao.BaseDao;
import mil.jmlfdc.common.utils.StringUtil;
import org.mongodb.morphia.Datastore;
import org.mongodb.morphia.query.Query;
import org.mongodb.morphia.query.UpdateOperations;
import org.slf4j.Logger;

@Dependent
public class ABiStagingMoveRecordsDao extends BaseDao<ABiCatalogStagingRecordDO, String>  {

    @Inject
    private Logger logger;
    
    public ABiStagingMoveRecordsDao() {
        super(ABiCatalogStagingRecordDO.class);
    }

    public Long getProductionCandidateRecordListCount() {
        Query<ABiCatalogStagingRecordDO> query = getQuery(ABiCatalogStagingRecordDO.class);
        query
            .criteria("inUseIndicator").equal(createIgnoreCasePattern("Y"))
            .criteria("recordStatus").equal("AwaitingApproval")
            .criteria("mergedTo").equal(null)
            .criteria("catalogSource").notEqual("MERGING");
        
        Long count = query.count();
        return count;
    }

    public List<ABiCatalogStagingRecordDO> getProductionCandidateRecordList(int startIndex, int numEntriesToReturn) {
        Query<ABiCatalogStagingRecordDO> query = getQuery(ABiCatalogStagingRecordDO.class);
        query
            .criteria("inUseIndicator").equal(createIgnoreCasePattern("Y"))
            .criteria("recordStatus").equal("AwaitingApproval")
            .criteria("mergedTo").equal(null)
            .criteria("catalogSource").notEqual("MERGING");
        
        query.offset(startIndex).limit(numEntriesToReturn);
        List<ABiCatalogStagingRecordDO> productionCandidates = query.asList();
        return productionCandidates;
    }
    
    public Long getGHXStagingRecordListCount() {
        Query<ABiCatalogStagingRecordDO> query = createGHXStagingRecordListQuery();
        Long count = query.count();
        return count;
    }
    
    public List<ABiCatalogStagingRecordDO> getGHXStagingRecordList(int startIndex, int numEntriesToReturn) {
        Query<ABiCatalogStagingRecordDO> query = createGHXStagingRecordListQuery();
        query.offset(startIndex).limit(numEntriesToReturn);
        List<ABiCatalogStagingRecordDO> ghxRecords = query.asList();
        return ghxRecords;
    }

    public Long getStagingRecordsMatchingSiteCatalogCount(List<Integer> prodSeqIdList, List<String> ndcList) {
        long count = 0;

        logger.info("########### getStagingRecordsMatchingSiteCatalogCount()  Getting matches on both ndc and mmcID");
        Query<ABiCatalogStagingRecordDO> query = getRecordsMatchingSiteCatalogQuery(prodSeqIdList, ndcList);
        count = query.count();
        logger.info("########### getStagingRecordsMatchingSiteCatalogCount()  Done - found " + count + " records.");
        
        return count;
    }

    public List<ABiCatalogStagingRecordDO> getStagingRecordsMatchingSiteCatalogList(List<Integer> prodSeqIdList, List<String> ndcList, 
            int startIndex, int numEntriesToReturn) {
        Query<ABiCatalogStagingRecordDO> query = getRecordsMatchingSiteCatalogQuery(prodSeqIdList, ndcList);
        query.offset(startIndex).limit(numEntriesToReturn);
        List<ABiCatalogStagingRecordDO> matchingRecords = query.asList();
        return matchingRecords;
    }

    
    public Long getStagingRecordsMatchingSiteCatalogProductSeqIdCount(List<Integer> prodSeqIdList) {
       long count = 0;
        logger.info("########### getStagingRecordsMatchingSiteCatalogProductSeqIdCount() Number of Product Sequence IDs in Site Catalog: " + prodSeqIdList.size());
        
        logger.info("########### getStagingRecordsMatchingSiteCatalogProductSeqIdCount() Getting Matches on MMC Id");
        Query<ABiCatalogStagingRecordDO> query = getRecordsMatchingSiteCatalogMmcIdQuery(prodSeqIdList);
        long mmcMatchCount = query.count();
        logger.info("########### getStagingRecordsMatchingSiteCatalogProductSeqIdCount() Done - found " + mmcMatchCount + " records.");
        
        count = mmcMatchCount;
        
        return count;
    }
   
    public List<ABiCatalogStagingRecordDO> getStagingRecordsMatchingSiteCatalogProductSeqIdList(List<Integer> prodSeqIdList,
            int startIndex, 
                            int numEntriesToReturn) {
        Query<ABiCatalogStagingRecordDO> query = getRecordsMatchingSiteCatalogMmcIdQuery(prodSeqIdList);
        query.offset(startIndex).limit(numEntriesToReturn);
        List<ABiCatalogStagingRecordDO> matchingRecords = query.asList();
        return matchingRecords;
    }

    
    public Long getStagingRecordsMatchingSiteCatalogNdcCount(List<String> ndcList) {
       long count = 0;
        logger.info("########### getStagingRecordsMatchingSiteCatalogNdcCount() Number of NDCs in Site Catalog:" + ndcList.size());
        
        logger.info("########### getStagingRecordsMatchingSiteCatalogNdcCount() Getting Matches on NDC");
        Query<ABiCatalogStagingRecordDO> query = getRecordsMatchingSiteCatalogNdcQuery(ndcList);
        long ndcMatchCount = query.count();
        logger.info("########### getStagingRecordsMatchingSiteCatalogNdcCount() Done - found " + ndcMatchCount + " records.");
        
        count = ndcMatchCount;
        
        return count;
    }
   
    public List<ABiCatalogStagingRecordDO> getStagingRecordsMatchingSiteCatalogNdcList(List<String> ndcList,
            int startIndex, 
                            int numEntriesToReturn) {
        Query<ABiCatalogStagingRecordDO> query = getRecordsMatchingSiteCatalogNdcQuery(ndcList);
        query.offset(startIndex).limit(numEntriesToReturn);
        List<ABiCatalogStagingRecordDO> matchingRecords = query.asList();
        return matchingRecords;
    }
    
    
    
    public Long markGHXStagingRecordsForProduction() {
        UpdateOperations<ABiCatalogStagingRecordDO> ops
                = this.getDatastore().createUpdateOperations(ABiCatalogStagingRecordDO.class);
        ops.set("inUseIndicator", "Y");
        ops.set("recordStatus", "AwaitingApproval");
        Query<ABiCatalogStagingRecordDO> query = createGHXStagingRecordListQuery();
        Integer numRecordsUpdated = this.update(query, ops);
        this.logger.info("*** Marked GHX records for production. Num Records Changed: " + numRecordsUpdated);
        return (Long)(long)numRecordsUpdated;
    }

    public Long markStagingRecordsMatchingSiteCatalogForProduction(List<Integer> prodSeqIdList, List<String> ndcList) {
        UpdateOperations<ABiCatalogStagingRecordDO> ops
                = this.getDatastore().createUpdateOperations(ABiCatalogStagingRecordDO.class);
        ops.set("inUseIndicator", "Y");
        ops.set("recordStatus", "AwaitingApproval");
        
        Query<ABiCatalogStagingRecordDO> query = getRecordsMatchingSiteCatalogQuery(prodSeqIdList, ndcList);
        Integer numRecordsUpdated = this.update(query, ops);
        this.logger.info("*** Marked GHX records for production. Num Records Changed: " + numRecordsUpdated);
        return (Long)(long)numRecordsUpdated;
    }

    public Long markStagingRecordsMatchingSiteCatalogProdSeqIdForProduction(List<Integer> prodSeqIdList) {
        UpdateOperations<ABiCatalogStagingRecordDO> ops
                = this.getDatastore().createUpdateOperations(ABiCatalogStagingRecordDO.class);
        ops.set("inUseIndicator", "Y");
        ops.set("recordStatus", "AwaitingApproval");
        
        Query<ABiCatalogStagingRecordDO> query = getRecordsMatchingSiteCatalogMmcIdQuery(prodSeqIdList);
        Integer numRecordsUpdated = this.update(query, ops);
        this.logger.info("*** Marked GHX records for production. Num Records Changed: " + numRecordsUpdated);
        return (Long)(long)numRecordsUpdated;
    }
    
    public Long markStagingRecordsMatchingSiteCatalogNdcForProduction(List<String> ndcList) {
        UpdateOperations<ABiCatalogStagingRecordDO> ops
                = this.getDatastore().createUpdateOperations(ABiCatalogStagingRecordDO.class);
        ops.set("inUseIndicator", "Y");
        ops.set("recordStatus", "AwaitingApproval");
        
        Query<ABiCatalogStagingRecordDO> query = getRecordsMatchingSiteCatalogNdcQuery(ndcList);
        Integer numRecordsUpdated = this.update(query, ops);
        this.logger.info("*** Marked GHX records for production. Num Records Changed: " + numRecordsUpdated);
        return (Long)(long)numRecordsUpdated;
    }
            
    public Long resetProductionCandidateRecordList() {
        UpdateOperations<ABiCatalogStagingRecordDO> ops
                = this.getDatastore().createUpdateOperations(ABiCatalogStagingRecordDO.class);
        ops.set("inUseIndicator", "N");
        ops.set("recordStatus", "");
        Query<ABiCatalogStagingRecordDO> query = createInUseQuery();
        Integer numRecordsUpdated = this.update(query, ops);
        this.logger.info("*** Reset staging records for production. Num Records Changed: " + numRecordsUpdated);
        return (Long)(long)numRecordsUpdated;
    }
    
    private Pattern createIgnoreCasePattern(String filter) {
        return Pattern.compile(filter, Pattern.CASE_INSENSITIVE);
    }

    private Query<ABiCatalogStagingRecordDO> createGHXStagingRecordListQuery()
    {
        Query<ABiCatalogStagingRecordDO> query = getQuery(ABiCatalogStagingRecordDO.class);
        query.criteria("inUseIndicator").notEqual("Y");
        
        query
            .criteria("catalogSource").equal(createIgnoreCasePattern("GHX"))
            .criteria("mergedTo").equal(null)
            .criteria("catalogSource").notEqual("MERGING");
        return query;
    }
    
    private Query<ABiCatalogStagingRecordDO> getRecordsMatchingSiteCatalogQuery(List<Integer> prodSeqIdList, List<String> ndcList) {
        Query<ABiCatalogStagingRecordDO> query = this.getQuery();
        
        query.criteria("inUseIndicator").notEqual("Y");

        query
            .criteria("mergedTo").equal(null)
            .criteria("catalogSource").notEqual("MERGING");
        query.or(
            query.criteria("ndc").in(ndcList),
            query.criteria("mmcProductIdentifier").in(prodSeqIdList)
        );
        query.order("mmcProductIdentifier");
        return query;
     }

     private Query<ABiCatalogStagingRecordDO> getRecordsMatchingSiteCatalogNdcQuery(List<String> ndcList) {
        Query<ABiCatalogStagingRecordDO> query = this.getQuery();

        query.criteria("inUseIndicator").notEqual("Y");

        query
            .criteria("mergedTo").equal(null)
            .criteria("catalogSource").notEqual("MERGING");
        query.criteria("ndc").in(ndcList);
        query.order("mmcProductIdentifier");
        return query;
     }

     private Query<ABiCatalogStagingRecordDO> getRecordsMatchingSiteCatalogMmcIdQuery(List<Integer> prodSeqIdList) {
        Query<ABiCatalogStagingRecordDO> query = this.getQuery();

        query.criteria("inUseIndicator").notEqual("Y");

        query
            .criteria("mergedTo").equal(null)
            .criteria("catalogSource").notEqual("MERGING");
        query.criteria("mmcProductIdentifier").in(prodSeqIdList);
        query.order("mmcProductIdentifier");
        return query;
     }

     private Query<ABiCatalogStagingRecordDO> createInUseQuery() {
        Query<ABiCatalogStagingRecordDO> query = this.getQuery();
        query.criteria("inUseIndicator").equal("Y");
        return query;
     }
     
     // TODO: Refactor this since several classes now have it
    private MongoDatabase getMongoDatabase() {
        Datastore ds = this.getDatastore();
        MongoClient client = ds.getMongo();
        String dbName = ds.getDB().getName();
        MongoDatabase mongoDb = client.getDatabase(dbName);
        return mongoDb;
    }

}
