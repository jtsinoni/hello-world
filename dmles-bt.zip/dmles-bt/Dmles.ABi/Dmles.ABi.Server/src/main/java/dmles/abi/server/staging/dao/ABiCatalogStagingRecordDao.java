package dmles.abi.server.staging.dao;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoDatabase;
import dmles.abi.server.staging.datamodel.ABiCatalogStagingRecordDO;
import mil.jmlfdc.common.dao.BaseDao;
import mil.jmlfdc.common.utils.StringUtil;
import org.mongodb.morphia.Datastore;
import org.mongodb.morphia.query.Query;
import org.slf4j.Logger;

import javax.enterprise.context.Dependent;
import javax.inject.Inject;
import java.util.List;
import java.util.regex.Pattern;
import mil.jmlfdc.common.utils.DateUtil;
import org.bson.types.ObjectId;
import org.mongodb.morphia.query.UpdateOperations;

@Dependent
public class ABiCatalogStagingRecordDao extends BaseDao<ABiCatalogStagingRecordDO, String> {

    @Inject
    private Logger logger;

    public ABiCatalogStagingRecordDao() {
        super(ABiCatalogStagingRecordDO.class);
    }

    // Matt: This is available in the BaseDao and is not needed, if the DAO logic that uses this is moved into the
    // DAO class (ABiStagingManager > findRecordsJson).
    public MongoDatabase getMongoDatabase() {
        Datastore ds = this.getDatastore();
        MongoClient client = ds.getMongo();
        String dbName = ds.getDB().getName();
        MongoDatabase mongoDb = client.getDatabase(dbName);
        return mongoDb;
    }

    public List<ABiCatalogStagingRecordDO> searchRecords(String filterData) {
        logger.debug("Entering searchRecords. FilterData is ***" + filterData + "***");
        Query<ABiCatalogStagingRecordDO> query = getQuery(ABiCatalogStagingRecordDO.class);
        if (StringUtil.isEmptyOrNull(filterData)) {
            query.offset(0).limit(1000)
            .criteria("catalogSource").notEqual("MERGING")
            .criteria("mergedTo").equal(null);
        } else {
            filterData = filterData.trim();
            query.offset(0).limit(1000)
            .criteria("catalogSource").notEqual("MERGING")
            .criteria("mergedTo").equal(null)
            .or(
                    query.criteria("ndc").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE)),
                    query.criteria("manufacturer").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE)),
                    query.criteria("catalogSource").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE)),
                    query.criteria("longItemDescription").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE)),
                    query.criteria("shortItemDescription").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE)),
                    query.criteria("manufacturerCatalogNumber").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE)),
                    query.criteria("enterpriseProductIdentifier").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE))
            );
        }
        List<ABiCatalogStagingRecordDO> products = query.asList();

        logger.debug("Got results from query. Products size is " + products.size());

        return products;
    }

    public void updateRecord(ABiCatalogStagingRecordDO recordToUpdate) {
        ABiCatalogStagingRecordDO existingRecordDO = null;
        if (recordToUpdate.getId() != null) {
            this.findById(recordToUpdate.getId());
        }
        recordToUpdate.setUpdatedDate(DateUtil.getCurrentUTCDate());
        
        if (existingRecordDO == null) {
            this.logger.info("ABiCatalogStagingRecordDao.updateRecord: INSERTING RECORD...");
            this.insert(recordToUpdate);
        } else {
            this.logger.info("ABiCatalogStagingRecordDao.updateRecord: UPDATING RECORD...");
            Query<ABiCatalogStagingRecordDO> query = this.getQuery(ABiCatalogStagingRecordDO.class);
            ObjectId oid = new ObjectId(existingRecordDO.getId());
            query.criteria("id").equal(oid);
            UpdateUtility uu = new UpdateUtility(this.getDatastore(), this.logger);
            UpdateOperations<ABiCatalogStagingRecordDO> ops = uu.buildUpdateOperations(existingRecordDO, recordToUpdate);
//            UpdateOperations<ABiCatalogStagingRecordDO> ops = buildUpdateOperations(existingMasterRecordDO, updatedMasterRecordDO);
            if (ops != null) {
                Integer numRecordsUpdated = this.update(query, ops);
                this.logger.info("*** Saved Master Record. Num Records Changed: " + numRecordsUpdated);
            }
        }
        
        this.upsert(recordToUpdate);
    }

    public ABiCatalogStagingRecordDO createRecord() {
        ABiCatalogStagingRecordDO newRecord = new ABiCatalogStagingRecordDO();
        newRecord.setCatalogSource("RESEARCH");
        return newRecord;
    }
}
