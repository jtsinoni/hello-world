package dmles.abi.server.staging.dao;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoDatabase;
import dmles.abi.core.datamodel.staging.ABiCatalogStatistics;
import dmles.abi.server.staging.datamodel.ABiCatalogStagingRecordDO;
import java.util.ArrayList;
import mil.jmlfdc.common.dao.BaseDao;
import mil.jmlfdc.common.utils.StringUtil;
import org.mongodb.morphia.Datastore;
import org.mongodb.morphia.query.Query;
import org.slf4j.Logger;

import javax.enterprise.context.Dependent;
import javax.inject.Inject;
import java.util.List;
import java.util.regex.Pattern;
import mil.jmlfdc.common.utils.DateUtil;
import org.bson.types.ObjectId;
import org.mongodb.morphia.query.Criteria;
import org.mongodb.morphia.query.CriteriaContainer;
import org.mongodb.morphia.query.UpdateOperations;

// Field Usage Notes
//
// CatalogSourceFromETL ::= [ 'GHX' | 'SCRIPTPRO' | 'ECRI' ]
// CatalogSourceBTUsage ::= [ 'MERGING' | 'MERGED' ]
// CatalogSource ::= [ CatalogSourceFromETL | CatalogSourceBTUsage ]
//
//
// RecordStatus :: [ 'Verified' | 'Unverified' | 'Published' | 'Approved' | 'AwaitingApproval' ]
//
//

@Dependent
public class ABiCatalogStagingRecordDao extends BaseDao<ABiCatalogStagingRecordDO, String> {

    @Inject
    private Logger logger;

    public ABiCatalogStagingRecordDao() {
        super(ABiCatalogStagingRecordDO.class);
    }

    // Matt: This is available in the BaseDao and is not needed, if the DAO logic that uses this is moved into the
    // DAO class (ABiStagingManager > findRecordsJson).
    public MongoDatabase getMongoDatabase() {
        Datastore ds = this.getDatastore();
        MongoClient client = ds.getMongo();
        String dbName = ds.getDB().getName();
        MongoDatabase mongoDb = client.getDatabase(dbName);
        return mongoDb;
    }

    public List<ABiCatalogStagingRecordDO> searchRecords(String mode, String filterData) {
        logger.debug("Entering searchRecords. FilterData is ***" + filterData + "***");
        Query<ABiCatalogStagingRecordDO> query = getQuery(ABiCatalogStagingRecordDO.class);
        mode = mode.toUpperCase();
        switch (mode) {
            case "PRODUCTION_CANDIDATES":
                query.criteria("inUseIndicator").equal("Y");
                break;
            case "MERGED":
                query.criteria("catalogSource").equal("MERGED");
                break;
            case "AWAITING_APPROVAL":
                query.criteria("recordStatus").equal("AwaitingApproval");
                break;
            case "APPROVED":
                query.criteria("recordStatus").equal("Approved");
                break;
            case "PUBLISHED":
                query.criteria("recordStatus").equal("Published");
                break;
        }
        if (StringUtil.isEmptyOrNull(filterData)) {
            query.offset(0).limit(1000);
            if (!"MERGED".equals(mode)) {
                query.criteria("catalogSource").notEqual("MERGING");
            }
            query.criteria("mergedTo").equal(null);
        } else {
            filterData = filterData.trim();
            query.offset(0).limit(1000)
            .criteria("catalogSource").notEqual("MERGING")
            .criteria("mergedTo").equal(null);

            CriteriaContainer orCriteria = query.or();
            orCriteria.add(query.criteria("ndc").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE)));
            orCriteria.add(query.criteria("manufacturer").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE)));
            if (!"MERGED".equals(mode)) {
                orCriteria.add(query.criteria("catalogSource").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE)));
            }
            orCriteria.add(query.criteria("longItemDescription").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE)));
            orCriteria.add(query.criteria("shortItemDescription").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE)));
            orCriteria.add(query.criteria("manufacturerCatalogNumber").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE)));
            orCriteria.add(query.criteria("enterpriseProductIdentifier").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE)));
            
            query.or(orCriteria);

//            List<Criteria> criteriaList = new ArrayList<Criteria>();
//            criteriaList.add(query.criteria("ndc").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE)));
//            criteriaList.add(query.criteria("manufacturer").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE)));
//            if (!"MERGED".equals(mode)) {
//                criteriaList.add(query.criteria("catalogSource").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE)));
//            }
//            criteriaList.add(query.criteria("longItemDescription").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE)));
//            criteriaList.add(query.criteria("shortItemDescription").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE)));
//            criteriaList.add(query.criteria("manufacturerCatalogNumber").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE)));
//            criteriaList.add(query.criteria("enterpriseProductIdentifier").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE)));
//            
//            query.or(criteriaList.toArray());
//            .or(
//                    query.criteria("ndc").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE)),
//                    query.criteria("manufacturer").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE)),
//                    query.criteria("catalogSource").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE)),
//                    query.criteria("longItemDescription").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE)),
//                    query.criteria("shortItemDescription").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE)),
//                    query.criteria("manufacturerCatalogNumber").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE)),
//                    query.criteria("enterpriseProductIdentifier").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE))
//            );
        }
        List<ABiCatalogStagingRecordDO> products = query.asList();
        products.forEach((product) -> {
            product.removeEmptyBarcodes();
        });
        
        logger.debug("Got results from query. Products size is " + products.size());

        return products;
    }

    public void updateRecord(ABiCatalogStagingRecordDO recordToUpdate) {
        ABiCatalogStagingRecordDO existingRecordDO = null;
        if (recordToUpdate.getId() != null) {
            this.findById(recordToUpdate.getId());
        }
        recordToUpdate.setUpdatedDate(DateUtil.getCurrentUTCTimestamp());
        
        if (existingRecordDO == null) {
            this.logger.debug("ABiCatalogStagingRecordDao.updateRecord: INSERTING RECORD...");
            this.insert(recordToUpdate);
        } else {
            this.logger.debug("ABiCatalogStagingRecordDao.updateRecord: UPDATING RECORD...");
            Query<ABiCatalogStagingRecordDO> query = this.getQuery(ABiCatalogStagingRecordDO.class);
            ObjectId oid = new ObjectId(existingRecordDO.getId());
            query.criteria("id").equal(oid);
            UpdateUtility uu = new UpdateUtility(this.getDatastore(), this.logger);
            UpdateOperations<ABiCatalogStagingRecordDO> ops = uu.buildUpdateOperations(existingRecordDO, recordToUpdate);
//            UpdateOperations<ABiCatalogStagingRecordDO> ops = buildUpdateOperations(existingMasterRecordDO, updatedMasterRecordDO);
            if (ops != null) {
                Integer numRecordsUpdated = this.update(query, ops);
                this.logger.debug("*** Saved Master Record. Num Records Changed: " + numRecordsUpdated);
            }
        }
        
        this.upsert(recordToUpdate);
    }

    public ABiCatalogStagingRecordDO createRecord() {
        ABiCatalogStagingRecordDO newRecord = new ABiCatalogStagingRecordDO();
        newRecord.setCatalogSource("RESEARCH");
        return newRecord;
    }

    public ABiCatalogStatistics getStatistics() {
        ABiCatalogStatistics stats = new ABiCatalogStatistics();
        Query<ABiCatalogStagingRecordDO> query = getQuery(ABiCatalogStagingRecordDO.class);
        stats.stagingRecordCount = query.count();
        
        query.criteria("inUseIndicator").equal("Y");
        stats.productionCandidateCount = query.count();
        
        query = getQuery(ABiCatalogStagingRecordDO.class);
        query.criteria("catalogSource").equal("MERGED");
        query.criteria("mergedTo").equal(null);
        stats.mergedRecordsCount = query.count();
        
        query = getQuery(ABiCatalogStagingRecordDO.class);
        query.criteria("recordStatus").equal("AwaitingApproval");
        stats.awaitingApprovalCount = query.count();
        
        query = getQuery(ABiCatalogStagingRecordDO.class);
        query.criteria("recordStatus").equal("Approved");
        stats.approvedCount = query.count();
        
        query = getQuery(ABiCatalogStagingRecordDO.class);
        query.criteria("recordStatus").equal("Published");
        stats.publishedCount = query.count();

        return stats;
    }
}
