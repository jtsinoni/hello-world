package dmles.abi.server.staging.dao;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoDatabase;
import dmles.abi.core.datamodel.staging.ABiCatalogStatistics;
import dmles.abi.server.staging.datamodel.ABiCatalogStagingRecordDO;
import java.util.ArrayList;
import java.util.Arrays;
import mil.jmlfdc.common.dao.BaseDao;
import mil.jmlfdc.common.utils.StringUtil;
import org.mongodb.morphia.Datastore;
import org.mongodb.morphia.query.Query;
import org.slf4j.Logger;

import javax.enterprise.context.Dependent;
import javax.inject.Inject;
import java.util.List;
import java.util.regex.Pattern;
import mil.jmlfdc.common.utils.DateUtil;
import org.bson.types.ObjectId;
import org.mongodb.morphia.query.Criteria;
import org.mongodb.morphia.query.CriteriaContainer;
import org.mongodb.morphia.query.UpdateOperations;

// Field Usage Notes
//
// CatalogSourceFromETL ::= [ 'GHX' | 'SCRIPTPRO' | 'ECRI' ]
//
//
// RecordStatus :: [ 'Verified' | 'Unverified' | 'Published' | 'Approved' | 'AwaitingApproval', 'Merged', 'Merging' ]
//
//

@Dependent
public class ABiCatalogStagingRecordDao extends BaseDao<ABiCatalogStagingRecordDO, String> {

    @Inject
    private Logger logger;

    public ABiCatalogStagingRecordDao() {
        super(ABiCatalogStagingRecordDO.class);
    }

    // Matt: This is available in the BaseDao and is not needed, if the DAO logic that uses this is moved into the
    // DAO class (ABiStagingManager > findRecordsJson).
    public MongoDatabase getMongoDatabase() {
        Datastore ds = this.getDatastore();
        MongoClient client = ds.getMongo();
        String dbName = ds.getDB().getName();
        MongoDatabase mongoDb = client.getDatabase(dbName);
        return mongoDb;
    }

    public List<ABiCatalogStagingRecordDO> searchRecords(String mode, String filterData) {
        logger.debug("Entering searchRecords. FilterData is ***" + filterData + "***");
        Query<ABiCatalogStagingRecordDO> query = getQuery(ABiCatalogStagingRecordDO.class);
        mode = mode.toUpperCase();
        switch (mode) {
            case "IN_USE":
                query.criteria("inUseIndicator").equal("Y");
                break;
            case "MERGED":
                query.criteria("recordStatus").equal("Merged");
                query.criteria("mergedTo").equal(null);
                query.criteria("recordStatus").notEqual("Approved");
                break;
            case "AWAITING_APPROVAL":
                CriteriaContainer orCriteria = query.or();
                orCriteria.add(query.criteria("recordStatus").equal("AwaitingApproval"));
                orCriteria.add(query.criteria("inUseIndicator").equal("Y"));
                query.or(orCriteria);
                break;
            case "APPROVED":
                query.criteria("recordStatus").equal("Approved");
                break;
            case "PUBLISHED":
                query.criteria("recordStatus").equal("Published");
                break;
        }
        if (StringUtil.isEmptyOrNull(filterData)) {
            query.offset(0).limit(1000);
            if (!"Merged".equals(mode)) {
                query.criteria("recordStatus").notEqual("Merging");
            }
            query.criteria("mergedTo").equal(null);
        } else {
            filterData = filterData.trim();
            query.offset(0).limit(1000)
            .criteria("recordStatus").notEqual("Merging")
            .criteria("mergedTo").equal(null);

            CriteriaContainer orCriteria = query.or();
            orCriteria.add(query.criteria("ndc").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE)));
            orCriteria.add(query.criteria("manufacturer").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE)));
            orCriteria.add(query.criteria("catalogSource").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE)));
            orCriteria.add(query.criteria("longItemDescription").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE)));
            orCriteria.add(query.criteria("shortItemDescription").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE)));
            orCriteria.add(query.criteria("manufacturerCatalogNumber").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE)));
            orCriteria.add(query.criteria("enterpriseProductIdentifier").equal(Pattern.compile(filterData, Pattern.CASE_INSENSITIVE)));
            
            query.or(orCriteria);
        }
        List<ABiCatalogStagingRecordDO> products = query.asList();
        products.forEach((product) -> {
            product.removeEmptyBarcodes();
        });
        
        logger.debug("Got results from query. Products size is " + products.size());

        return products;
    }

    public void updateRecord(ABiCatalogStagingRecordDO recordToUpdate) {
        ABiCatalogStagingRecordDO existingRecordDO = null;
        if (recordToUpdate.getId() != null) {
            this.findById(recordToUpdate.getId());
        }
        recordToUpdate.setUpdatedDate(DateUtil.getCurrentUTCTimestamp());
        
        if (existingRecordDO == null) {
            this.logger.debug("ABiCatalogStagingRecordDao.updateRecord: INSERTING RECORD...");
            this.insert(recordToUpdate);
        } else {
            this.logger.debug("ABiCatalogStagingRecordDao.updateRecord: UPDATING RECORD...");
            Query<ABiCatalogStagingRecordDO> query = this.getQuery(ABiCatalogStagingRecordDO.class);
            ObjectId oid = new ObjectId(existingRecordDO.getId());
            query.criteria("id").equal(oid);
            UpdateUtility uu = new UpdateUtility(this.getDatastore(), this.logger);
            List<String> fieldsToIgnore = Arrays.asList("logger", "id");
            UpdateOperations<ABiCatalogStagingRecordDO> ops = uu.buildUpdateOperations(existingRecordDO, recordToUpdate, fieldsToIgnore);
            if (ops != null) {
                Integer numRecordsUpdated = this.update(query, ops);
                this.logger.debug("*** Saved Master Record. Num Records Changed: " + numRecordsUpdated);
            }
        }
        
        this.upsert(recordToUpdate);
    }

    public ABiCatalogStagingRecordDO createRecord() {
        ABiCatalogStagingRecordDO newRecord = new ABiCatalogStagingRecordDO();
        newRecord.setRecordStatus("Unverified");
        newRecord.setCatalogSource("RESEARCH");
        return newRecord;
    }

    public ABiCatalogStatistics getStatistics() {
        ABiCatalogStatistics stats = new ABiCatalogStatistics();
        Query<ABiCatalogStagingRecordDO> query = getQuery(ABiCatalogStagingRecordDO.class);
        stats.stagingRecordCount = query.count();
        
        query.criteria("inUseIndicator").equal("Y");
        query.criteria("recordStatus").notEqual("Approved");
        query.criteria("recordStatus").notEqual("Published");
        stats.inUseCount = query.count();
        
        query = getQuery(ABiCatalogStagingRecordDO.class);
        query.criteria("recordStatus").equal("Merged");
        query.criteria("mergedTo").equal(null);
        stats.mergedRecordsCount = query.count();
        
        query = getQuery(ABiCatalogStagingRecordDO.class);
//        CriteriaContainer orCriteria = query.or();
//        orCriteria.add(query.criteria("recordStatus").equal("AwaitingApproval"));
//        orCriteria.add(query.criteria("inUseIndicator").equal("Y"));
//        query.or(orCriteria);
        query.criteria("recordStatus").equal("AwaitingApproval");
        stats.awaitingApprovalCount = query.count();
        
        query = getQuery(ABiCatalogStagingRecordDO.class);
        query.criteria("recordStatus").equal("Approved");
        stats.approvedCount = query.count();
        
        query = getQuery(ABiCatalogStagingRecordDO.class);
        query.criteria("recordStatus").equal("Published");
        stats.publishedCount = query.count();

        return stats;
    }
}
