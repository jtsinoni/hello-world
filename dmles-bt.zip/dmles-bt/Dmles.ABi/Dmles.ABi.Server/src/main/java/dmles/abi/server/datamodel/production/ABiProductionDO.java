package dmles.abi.server.datamodel.production;

import java.io.Serializable;

import mil.jmlfdc.common.datamodel.MorphiaEntity;
import org.mongodb.morphia.annotations.*;

@Entity(value = "abiCatalog", noClassnameStored = true)
public class ABiProductionDO extends MorphiaEntity implements Serializable {

    private static long serialVersionUID = 1L;

    private String commodityType;
    private String productNoun;
    private String unspscSegment;

    // Constructors
    public ABiProductionDO() {
    }

    // Getters and Setters
    public String getCommodityType() {
        return commodityType;
    }

    public void setCommodityType(String commodityType) {
        this.commodityType = commodityType;
    }

    public String getProductNoun() {
        return productNoun;
    }

    public void setProductNoun(String productNoun) {
        this.productNoun = productNoun;
    }

    public String getUnspscSegment() {
        return unspscSegment;
    }

    public void setUnspscSegment(String unspscSegment) {
        this.unspscSegment = unspscSegment;
    }
}
