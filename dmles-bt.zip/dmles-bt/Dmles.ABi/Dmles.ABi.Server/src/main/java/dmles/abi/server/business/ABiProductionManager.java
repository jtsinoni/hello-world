package dmles.abi.server.business;

import dmles.abi.core.datamodel.PingData;
import dmles.abi.server.refactor.business.search.ElasticSearchAggregations;
import dmles.abi.server.refactor.dao.ElasticSearch5Dao;
import dmles.abi.server.dao.PingDataDao;
import dmles.abi.server.datamodel.PingDataDO;
import java.util.HashMap;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import mil.jmlfdc.common.business.BusinessManager;
import mil.jmlfdc.common.utils.ObjectMapper;
import org.slf4j.Logger;

@Stateless
public class ABiProductionManager extends BusinessManager {

    @Inject
    private Logger log;
    
    @Inject
    private PingDataDao pingDataDao;

    @Inject 
    private ElasticSearch5Dao esDao;

    @Inject 
    private ElasticSearchAggregations esAggregations;
    
    @Inject
    private ObjectMapper objectMapper;      

    private static final String[] abiCatalogFields = { "age", "brandGeneric", "catalogSource", "clinicalDescription", 
        "color", "deaCode", "diameter", "disposableReusable", "dosageForm",
        "drugCategory", "drugStorageType", "drugStrength", "drugUnit", 
        "enterpriseProductIdentifier", "enterpriseProductIdentifierType",
        "flavor", "fragrance", "fullDescription", "gender", "genericId", 
        "genericName", "ghxManufacturer", "ghxProductIdentifier", "hazardCode", 
        "hcpcsCode", "hcpcsDescription", "hcpcsStatus", "latexCode", 
        "lengthWidthHeight", "lengthWidthHeight2", "locations", 
        "longItemDescription", "manufacturer", "manufacturerCatalogNumber", 
        "miscellaneous", "mmcPreferredProductIdentifier", "mmcProductIdentifier",
        "ndc", "offMarket", "packaging", "productComposition", "productImages", "productLine",
        "productNoun", "productProperties", "productStatus", "productType", 
        "scriptproManufacturer", "shortItemDescription", "sizeShape",
        "spDrugCode", "sterileNonsterile", "trademarkBrandnames",
        "unspscClass", "unspscCode", "unspscCommodity", "unspscFamily",
        "unspscSegment", "volume", "weight" };
 
    private static JsonObject abiCatalogAggregationJsonObject = null;

    public PingData getPing(){
        log.info("Pinged the BT ABi PRODUCTION Manager!");
        log.info("User: {}", currentUserBt.getPkiDn());
        PingDataDO pingDo = pingDataDao.getPingData("Hello from the ABi PRODUCTION Manager...");
        return objectMapper.getObject(PingData.class, pingDo);
    }
    
    public String getABiCatalogRecordSearchResults(String searchValue, String aggregations) {

        String searchVal = (searchValue == null || searchValue.isEmpty()) ? "*" : searchValue;
        String aggs = (aggregations == null || aggregations.isEmpty()) ? "{}" : aggregations;
        log.info("generic aggs - from PT = " + aggs);

        Map<String, Object> templateParams = new HashMap<>();
        templateParams.put("searchValue", searchVal);
        templateParams.put("aggregations", esAggregations.processAggregations(aggs));
        String responseString = esDao.getSearchResults("enterpriseCatalog",
                                                       "abiCatalog",
                                                       abiCatalogFields, 
                                                       templateParams,
                                                       getAbiCatalogAggregationObject());

        return responseString;
    }

    private static JsonObject getAbiCatalogAggregationObject() {
        if (abiCatalogAggregationJsonObject == null) {
            JsonObjectBuilder defaultAggregationStringBuilder = Json.createObjectBuilder()
                    .add("genericNames", Json.createObjectBuilder()
                        .add("terms", Json.createObjectBuilder()
                            .add("field", "genericName.keyword")
                        )
                    )
                    .add("manufNames", Json.createObjectBuilder()
                        .add("terms", Json.createObjectBuilder()
                            .add("field", "manufacturer.keyword")
                        )
                    )
                    .add("drugUnits", Json.createObjectBuilder()
                        .add("terms", Json.createObjectBuilder()
                            .add("field", "drugUnit.keyword")
                        )
                    )
                    .add("drugStrengths", Json.createObjectBuilder()
                        .add("terms", Json.createObjectBuilder()
                            .add("field", "drugStrength.keyword")
                        )
                    )
                    .add("dosageForms", Json.createObjectBuilder()
                        .add("terms", Json.createObjectBuilder()
                            .add("field", "dosageForm.keyword")
                        )
                    )
                    .add("hcpcsCodes", Json.createObjectBuilder()
                        .add("terms", Json.createObjectBuilder()
                            .add("field", "hcpcsCode.keyword")
                        )
                    )
                    .add("hcpcsDescriptions", Json.createObjectBuilder()
                        .add("terms", Json.createObjectBuilder()
                            .add("field", "hcpcsDescription.keyword")
                        )
                    )
                    .add("unspscCommodities", Json.createObjectBuilder()
                        .add("terms", Json.createObjectBuilder()
                            .add("field", "unspscCommodity.keyword")
                        )
                    )
                    .add("sizeShapes", Json.createObjectBuilder()
                        .add("terms", Json.createObjectBuilder()
                            .add("field", "sizeShape.keyword")
                        )
                    )
                    .add("productTypes", Json.createObjectBuilder()
                        .add("terms", Json.createObjectBuilder()
                            .add("field", "productType.keyword")
                        )
                    )
                    .add("tradenames", Json.createObjectBuilder()
                        .add("terms", Json.createObjectBuilder()
                            .add("field", "trademarkBrandnames.keyword")
                        )
                    )
                    .add("packagingUnits", Json.createObjectBuilder()
                        .add("terms", Json.createObjectBuilder()
                            .add("field", "packaging.packageUnit.keyword")
                        )
                    );
            abiCatalogAggregationJsonObject = defaultAggregationStringBuilder.build();
        }
        return abiCatalogAggregationJsonObject;
     }
//    
//    @Override
//    public String getRequestorId() {
//        return currentUserBt.getProfileId();
//    }
//
//    @Override
//    public String getRequestorName() {
//        return currentUserBt.getFullName();
//    }
}
