package dmles.abi.server.business;

import dmles.abi.core.datamodel.PingData;
import dmles.abi.server.dao.PingDataDao;
import dmles.abi.server.datamodel.PingDataDO;
import mil.jmlfdc.common.datamodel.CurrentUserBT;

import javax.ejb.Stateless;
import javax.inject.Inject;
import mil.jmlfdc.common.business.BusinessManager;
import mil.jmlfdc.common.utils.ObjectMapper;
import org.slf4j.Logger;

@Stateless
public class ABiProductionManager extends BusinessManager {

    @Inject
    private Logger log;
    
    @Inject
    private PingDataDao pingDataDao;
    
    @Inject
    private ObjectMapper objectMapper;      
    
    public PingData getPing(){
        log.info("Pinged the BT ABi PRODUCTION Manager!");
        log.info("User: {}", currentUserBt.getPkiDn());
        PingDataDO pingDo = pingDataDao.getPingData("Hello from the ABi PRODUCTION Manager...");
        return objectMapper.getObject(PingData.class, pingDo);
    }
    
}
