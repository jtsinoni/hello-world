package dmles.abi.server.business;

import dmles.abi.core.datamodel.PingData;
import dmles.abi.server.dao.ABiProductionDao;
import dmles.abi.server.dao.PingDataDao;
import dmles.abi.server.datamodel.PingDataDO;
import dmles.common.general.logging.Logger;
import dmles.search.client.SearchService;
import dmles.search.core.ISearchService;
import dmles.search.core.request.DmlesSearchRequest;
import dmles.search.core.request.DmlesSearchSource;
import java.util.List;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.ws.rs.core.Response;
import mil.jmlfdc.common.business.BusinessManager;
import mil.jmlfdc.common.utils.ObjectMapper;

@Stateless
public class ABiProductionManager extends BusinessManager {

    @Inject
    private Logger logger;

    @Inject
    private ObjectMapper objectMapper;

    @Inject
    private PingDataDao pingDataDao;

    @Inject
    private ABiProductionDao abiProductionDao;

    @Inject
    @SearchService
    private ISearchService searchService;

    private static final String[] abiCatalogFields = {"id", "age", "brandGeneric", "catalogSource", "clinicalDescription",
        "color", "deaCode", "diameter", "disposableReusable", "dosageForm",
        "drugCategory", "drugStorageType", "drugStrength", "drugUnit",
        "enterpriseProductIdentifier", "enterpriseProductIdentifierType",
        "flavor", "fragrance", "fullDescription", "gender", "genericId",
        "genericName", "ghxManufacturer", "ghxProductIdentifier", "hazardCode",
        "hcpcsCode", "hcpcsDescription", "hcpcsStatus", "latexCode",
        "lengthWidthHeight", "lengthWidthHeight2", "locations",
        "longItemDescription", "manufacturer", "manufacturerCatalogNumber",
        "miscellaneous", "mmcPreferredProductIdentifier", "mmcProductIdentifier",
        "ndc", "offMarket", "packaging", "productComposition", "productImages", "productLine",
        "productNoun", "productProperties", "productStatus", "productType",
        "scriptproManufacturer", "shortItemDescription", "sizeShape",
        "spDrugCode", "sterileNonsterile", "trademarkBrandnames",
        "unspscClass", "unspscCode", "unspscCommodity", "unspscFamily",
        "unspscSegment", "volume", "weight", "netContentText", "netContentQuantity", "packagingDescription",
        "preferredProductIndicator", "inUseIndicator", "siteCount", "productDocumentation", "secondaryProductIdentifiers",
        "productGroup", "productSubstituteGroup", "commodityType"};

    public String getABiCatalogRecordESResults(String queryString, String aggregations) {
        DmlesSearchRequest searchRequest = new DmlesSearchRequest(queryString, aggregations);
        searchRequest.source = new DmlesSearchSource("enterprisecatalog", "abiCatalog");
        searchRequest.selectFields = abiCatalogFields;
        searchRequest.resultSetOffset = 0;
        searchRequest.resultSetSize = 250;

        Response response = searchService.getSearchResults(searchRequest);
        String entityStr = null;
        if (response.hasEntity()) {

            entityStr = response.readEntity(String.class);
        }
        return entityStr;
    }

    public List<String> getCommodityTypes() {
        List<String> commodityTypeList = abiProductionDao.getCommodityTypes();
        return commodityTypeList;
    }

    public List<String> getProductNouns() {
        List<String> productNounList = abiProductionDao.getProductNouns();
        return productNounList;
    }

    public List<String> getUnspscSegments() {
        List<String> unspscSegmentList = abiProductionDao.getUnspscSegments();
        return unspscSegmentList;
    }

    public PingData getPing() {
        logger.info("Pinged the BT ABi PRODUCTION Manager!");
        logger.info("User: {}", currentUserBt.getPkiDn());
        PingDataDO pingDo = pingDataDao.getPingData("Hello from the ABi PRODUCTION Manager...");
        return objectMapper.getObject(PingData.class, pingDo);
    }
}
