package dmles.abi.server.staging.datamodel;

import dmles.abi.server.datamodel.ABiCatalogBaseMorphiaEntity;
import org.mongodb.morphia.annotations.Entity;


@Entity(value = "abiCatalogStaging", noClassnameStored = true)
public class ABiCatalogStagingRecordDO extends ABiCatalogBaseMorphiaEntity {
}
