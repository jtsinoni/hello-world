package dmles.abi.server.production.datamodel;

import dmles.abi.server.datamodel.ABiCatalogBaseMorphiaEntity;
import dmles.abi.server.staging.datamodel.ABiCatalogStagingRecordDO;
import org.mongodb.morphia.annotations.Entity;

@Entity(value = "abiCatalog", noClassnameStored = true)
public class ABiCatalogRecordDO extends ABiCatalogBaseMorphiaEntity {
    public ABiCatalogRecordDO(ABiCatalogStagingRecordDO source) {
        super(source);
    }
}
