package dmles.abi.server.rest;


public class SiteCatalogRestApiTest {

//    @Mock private SiteCatalogManager mgr;
//    @Mock private SiteCatalogRecord siteCatalogRecord;
//
//    @InjectMocks
//    private SiteCatalogManager api;
//
//    @Before
//    public void setup() {
//        MockitoAnnotations.initMocks(this);
//    }
//
//    @Test
//    public void getSiteCatalogByEnterpriseIdTest() {
//        List<SiteCatalogRecord> apps = new ArrayList<>();
//
//        when(mgr.getSiteCatalogByEnterpriseId("1")).thenReturn(apps);
//
//        api.getSiteCatalogByEnterpriseId("1");
//
//        verify(mgr).getSiteCatalogByEnterpriseId("1");
//    }
//    @Test
//    public void getSiteCatalogByProductIdTest() {
//        List<SiteCatalogRecord> apps = new ArrayList<>();
//
//        when(mgr.getSiteCatalogByProductId(1)).thenReturn(apps);
//
//        api.getSiteCatalogByProductId(1);
//
//        verify(mgr).getSiteCatalogByProductId(1);
//    }
}

