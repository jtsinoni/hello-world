package dmles.abi.server.business;

public class SiteCatalogManagerTest {

//    @Mock
//    private SiteCatalogRecord siteCatalogRecord;
//    @Mock
//    private SiteCatalogRecordDao siteCatalogRecordDao;
//    @Mock
//    private ObjectMapper objectMapper;
//
//    @InjectMocks
//    private SiteCatalogManager mgr;
//
//    @Before
//    public void setup() {
//        MockitoAnnotations.initMocks(this);
//    }
//
//    @Test
//    public void getSiteCatalogByEnterpriseIdTest() {
//        List<SiteCatalogRecordDO> catalogRecord = new ArrayList<>();
//        when(siteCatalogRecordDao.getByEnterpriseId("1")).thenReturn(catalogRecord);
//
//        mgr.getSiteCatalogByEnterpriseId("1");
//
//        verify(siteCatalogRecordDao).getByEnterpriseId("1");
//        verify(objectMapper).getList(SiteCatalogRecord[].class, catalogRecord);
//    }

//    @Test
//    public void getSiteCatalogByProductIdTest() {
//        List<SiteCatalogRecordDO> catalogRecord = new ArrayList<>();
//        when(siteCatalogRecordDao.getByProductSeqId(1)).thenReturn(catalogRecord);
//
//        mgr.getSiteCatalogByProductId(1);
//
//        verify(siteCatalogRecordDao).getByProductSeqId(1);
//        verify(objectMapper).getList(SiteCatalogRecord[].class, catalogRecord);
//    }

}
