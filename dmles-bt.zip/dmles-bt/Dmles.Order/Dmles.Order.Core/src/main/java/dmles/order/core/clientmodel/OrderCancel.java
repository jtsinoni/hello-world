package dmles.order.core.clientmodel;

public class OrderCancel {
    public String dodaac;
    public OrderCancelItem[] cancelOrderItems;
}
