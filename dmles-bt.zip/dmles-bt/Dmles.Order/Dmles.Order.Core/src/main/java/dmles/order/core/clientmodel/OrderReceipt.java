package dmles.order.core.clientmodel;

public class OrderReceipt {
    public String dodaac;
    public ReceiptItem[] receiptAcknowledgements;
}
