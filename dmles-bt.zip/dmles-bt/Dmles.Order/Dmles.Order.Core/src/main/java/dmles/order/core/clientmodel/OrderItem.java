package dmles.order.core.clientmodel;

import java.math.BigDecimal;
import java.util.Calendar;

public class OrderItem {
    public String adviceCode;
    public Address billingAddress;
    public AddressType billingAddressType;
    public String deliveryDate;
    public Calendar deliveryDateCal;
    public String distributionCode;
    public String documentNumber;
    public String expenseCenter;
    public String fundCode;
    public String itemId;
    public String keyIdentifier;
    public String keyscope;
    public String packCode;
    public BigDecimal price;
    public int priorityCode;
    public String projectCode;
    public int quantity;
    public String requiredDeliveryDate;
    public Calendar requiredDeliveryDateCal;
    public Address shippingAddress;
    public AddressType shippingAddressType;
    public String shippingAddressDODAAC;
    public String uopCode;
}
