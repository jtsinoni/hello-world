package dmles.order.core.clientmodel;

public class Advice {
    public String code;
    public String description;
    public String deFault;
}
