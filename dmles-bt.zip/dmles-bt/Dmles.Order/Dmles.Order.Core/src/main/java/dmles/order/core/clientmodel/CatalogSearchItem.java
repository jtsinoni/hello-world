package dmles.order.core.clientmodel;

import java.math.BigDecimal;

public class CatalogSearchItem {
    public String keyIdentifier;
    public String keyScope;
    public String itemId;
    public String shortDescription;
    public String longDescription;
    public Long customerWaitTimeDays;
    public String defaultSupplier;
    public boolean defaultSupplierStocked;
    public BigDecimal defaultPrice;
    public String defaultPackType;
    public Long defaultPackQuantity;
    public String manufacturer;
    public String manufacturerCatalogNumber;

}
