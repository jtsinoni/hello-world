package dmles.order.core.clientmodel;

public class ReceiptItem {
    public String documentNumber;
    public int quantityReceived;
    public String receiptMessage;
    public int receiptResult;
}
