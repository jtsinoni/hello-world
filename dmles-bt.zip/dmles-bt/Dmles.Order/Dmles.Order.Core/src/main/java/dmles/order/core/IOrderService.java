package dmles.order.core;

import dmles.order.core.clientmodel.Customer;
import dmles.order.core.clientmodel.OrderCancel;
import dmles.order.core.clientmodel.OrderQuery;
import dmles.order.core.clientmodel.OrderReceipt;
import dmles.order.core.clientmodel.OrderRequest;
import dmles.order.core.clientmodel.OrderResult;
import dmles.order.core.clientmodel.OrderStatus;
import dmles.order.core.clientmodel.OrderSupportData;

import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;


@Path("/V1/order")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public interface IOrderService {

    @POST
    @Path("/acknowledgeReceipts")
    public OrderResult acknowledgeReceipts(OrderReceipt orderReceipt);

    @POST
    @Path("/cancelOrder")
    public OrderResult cancelOrder(OrderCancel orderCancel);

    @GET
    @Path("/orderPing")
    public String orderPing(@QueryParam("param") String param);

    @GET
    @Path("/getOrderStatus")
    public OrderResult getOrderStatus(OrderQuery orderQuery);

    @GET
    @Path("/getOrderSupportData")
    public OrderSupportData getOrderSupportData(Customer customer);

    @POST
    @Path("/submitOrder")
    public OrderResult submitOrder(OrderRequest orderRequest);


    /**. Order Status
     * @param dodaac dodaac 
     * @param documentNumbers documentNumbers
     * @return  OrderStatus*/
    @GET
    @Path("/queryOrderStatus")
    public OrderStatus queryOrderStatus(@QueryParam("dodaac") String dodaac,
                    @QueryParam("documentNumbers") List<String> documentNumbers);

}
