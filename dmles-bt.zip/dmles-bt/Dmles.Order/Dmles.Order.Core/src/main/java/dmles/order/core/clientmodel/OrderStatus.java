package dmles.order.core.clientmodel;

public class OrderStatus {
    public String dodaac;
    public StatusItemDTO[] results;
}
