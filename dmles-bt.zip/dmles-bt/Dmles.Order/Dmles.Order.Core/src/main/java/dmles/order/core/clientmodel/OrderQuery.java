package dmles.order.core.clientmodel;

public class OrderQuery {
    public String dodaac;
    public String[] documentNumbers;
}
