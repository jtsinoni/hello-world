package dmles.order.core.clientmodel;

import java.util.HashMap;
import java.util.Map;

public class AddressType {
    public String value;
    public static  Map table = new HashMap();
    public static final String PRIMARY = "PRIMARY";
    public static final String SUPPLEMENTAL = "SUPPLEMENTAL";
}
