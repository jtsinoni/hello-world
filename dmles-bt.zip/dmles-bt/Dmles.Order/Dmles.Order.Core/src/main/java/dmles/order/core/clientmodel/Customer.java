package dmles.order.core.clientmodel;

public class Customer {
    public String dodaac;
    public String location;
    public String name;
}
