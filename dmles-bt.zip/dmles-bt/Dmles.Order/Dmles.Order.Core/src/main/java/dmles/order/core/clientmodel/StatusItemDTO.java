package dmles.order.core.clientmodel;

public class StatusItemDTO {
    public int backorderedQuantity;
    public int canceledQuantity;
    public int cancellableMaxQuantity;
    public CatalogSearchItem catalogItem;
    public int dueInQuantity;
    public String note;
    public OrderItem orderItem;
    public Code[] processingErrors;
    public int receiptableMaxQuantity;
    public int receivedQuantity;
    public int shippedQuantity;
    public OrderStatusCode[] statusCodes;
}
