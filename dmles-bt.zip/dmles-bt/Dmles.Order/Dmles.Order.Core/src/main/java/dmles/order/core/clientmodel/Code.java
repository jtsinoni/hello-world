package dmles.order.core.clientmodel;

public class Code {
    public String code;
    public String description;
}
