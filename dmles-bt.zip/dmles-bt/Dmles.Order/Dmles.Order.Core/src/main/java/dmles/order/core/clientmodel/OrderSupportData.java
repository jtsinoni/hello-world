package dmles.order.core.clientmodel;

public class OrderSupportData {
    public Advice[] adviceCodes;
    public Address billingAddresses;
    public String customerName;
    public String dodaac;
    public ExpenseCenter expenseCenter;
    public String mediaCode;
    public String priorityCodes;
    public Address shippingAddress;
}
