package dmles.order.core.clientmodel;

public class OrderRequest {
    public String dodaac;
    public OrderItem[] orders;
}
