package dmles.order.core.clientmodel;


public class OrderResult {
    public String dodaac;
    public OrderStatusItem[] results;
}
