package dmles.order.core.clientmodel;

public class OrderCancelItem {
    public String documentNumber;
    public int quantityCancelled;
}
