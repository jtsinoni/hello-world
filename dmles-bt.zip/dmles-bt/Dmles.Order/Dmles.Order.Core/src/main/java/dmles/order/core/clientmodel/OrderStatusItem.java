package dmles.order.core.clientmodel;

public class OrderStatusItem {
    public int backOrderedQuantity;
    public int cancelledQuantity;
    public int cancellableMaxQuantity;
    public CatalogSearchItem catalogItem;
    public int dueInQuantity;
    public String note;
    public OrderItem orderItem;
    public Code[] processingErrors;
    public int recieptableMaxQuantity;
    public int receivedQuantity;
    public int shippedQuantity;
    public OrderStatusCode[] statusCodes;
}
