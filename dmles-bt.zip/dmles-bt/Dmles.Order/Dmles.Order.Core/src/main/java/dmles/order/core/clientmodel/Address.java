package dmles.order.core.clientmodel;

public class Address {
    public String addrLine1;
    public String addrLine2;
    public String addrSerial;
    public String addressType;
    public String city;
    public String country;
    public String dodaac;
    public String state;
    public String zip;
}
