package dmles.order.client;

import dmles.oauth.core.rest.SecuredRestClientFactory;
import dmles.order.core.IOrderService;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class OrderClientFactory extends SecuredRestClientFactory<IOrderService> {
 
    public OrderClientFactory() {
        super(IOrderService.class, "Dmles.Order.Server");
    }
    
    @Produces 
    @OrderService
    public IOrderService getIOrderService() {
        return createClient();
    }
    
}
