package dmles.order.server.datamodel;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import java.util.Arrays;
import java.util.Objects;

@JsonSerialize
public class OrderQueryDO {
    private String dodaac;
    private String[] documentNumbers;

    
    public String getDodaac() {
        return dodaac;
    }

    public void setDodaac(String dodaac) {
        this.dodaac = dodaac;
    }

    public String[] getDocumentNumbers() {
        return documentNumbers;
    }

    public void setDocumentNumbers(String[] documentNumbers) {
        this.documentNumbers = documentNumbers;
    }
    
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 47 * hash + Objects.hashCode(this.dodaac);
        hash = 47 * hash + Arrays.deepHashCode(this.documentNumbers);
        return hash;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final OrderQueryDO other = (OrderQueryDO) obj;
        if (!Objects.equals(this.dodaac, other.dodaac)) {
            return false;
        }
        if (!Arrays.deepEquals(this.documentNumbers, other.documentNumbers)) {
            return false;
        }
        return true;
    }

}
