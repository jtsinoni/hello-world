package dmles.order.server.datamodel;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import java.util.Objects;

@JsonSerialize
public class ExpenseCenterDO {
    private String code;
    private String description;
    private String deFault;
    private String fundCode;
    private String fundSerial;

   

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDeFault() {
        return deFault;
    }

    public void setDeFault(String deFault) {
        this.deFault = deFault;
    }

    public String getFundCode() {
        return fundCode;
    }

    public void setFundCode(String fundCode) {
        this.fundCode = fundCode;
    }

    public String getFundSerial() {
        return fundSerial;
    }

    public void setFundSerial(String fundSerial) {
        this.fundSerial = fundSerial;
    }
    
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 71 * hash + Objects.hashCode(this.code);
        hash = 71 * hash + Objects.hashCode(this.description);
        hash = 71 * hash + Objects.hashCode(this.deFault);
        hash = 71 * hash + Objects.hashCode(this.fundCode);
        hash = 71 * hash + Objects.hashCode(this.fundSerial);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final ExpenseCenterDO other = (ExpenseCenterDO) obj;
        if (!Objects.equals(this.code, other.code)) {
            return false;
        }
        if (!Objects.equals(this.description, other.description)) {
            return false;
        }
        if (!Objects.equals(this.deFault, other.deFault)) {
            return false;
        }
        if (!Objects.equals(this.fundCode, other.fundCode)) {
            return false;
        }
        if (!Objects.equals(this.fundSerial, other.fundSerial)) {
            return false;
        }
        return true;
    }
}
