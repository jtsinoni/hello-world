package dmles.order.server.datamodel;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import org.mongodb.morphia.annotations.Reference;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Objects;


@JsonSerialize
public class OrderItemDO {
    private String adviceCode;
    @Reference
    private AddressDO billingAddress;
    @Reference
    private AddressTypeDO billingAddressType;
    private String deliveryDate;
    private Calendar deliveryDateCal;
    private String distributionCode;
    private String documentNumber;
    private String expenseCenter;
    private String fundCode;
    private String itemId;
    private String keyIdentifier;
    private String keyscope;
    private String packCode;
    private BigDecimal price;
    private int priorityCode;
    private String projectCode;
    private int quantity;
    private String requiredDeliveryDate;
    private Calendar requiredDeliveryDateCal;
    @Reference
    private AddressDO shippingAddress;
    @Reference
    private AddressTypeDO shippingAddressType;
    private String shippingAddressDODAAC;
    private String uopCode;

    

    public String getAdviceCode() {
        return adviceCode;
    }

    public void setAdviceCode(String adviceCode) {
        this.adviceCode = adviceCode;
    }

    public AddressDO getBillingAddress() {
        return billingAddress;
    }

    public void setBillingAddress(AddressDO billingAddress) {
        this.billingAddress = billingAddress;
    }

    public AddressTypeDO getBillingAddressType() {
        return billingAddressType;
    }

    public void setBillingAddressType(AddressTypeDO billingAddressType) {
        this.billingAddressType = billingAddressType;
    }

    public String getDeliveryDate() {
        return deliveryDate;
    }

    public void setDeliveryDate(String deliveryDate) {
        this.deliveryDate = deliveryDate;
    }

    public Calendar getDeliveryDateCal() {
        return deliveryDateCal;
    }

    public void setDeliveryDateCal(Calendar deliveryDateCal) {
        this.deliveryDateCal = deliveryDateCal;
    }

    public String getDistributionCode() {
        return distributionCode;
    }

    public void setDistributionCode(String distributionCode) {
        this.distributionCode = distributionCode;
    }

    public String getDocumentNumber() {
        return documentNumber;
    }

    public void setDocumentNumber(String documentNumber) {
        this.documentNumber = documentNumber;
    }

    public String getExpenseCenter() {
        return expenseCenter;
    }

    public void setExpenseCenter(String expenseCenter) {
        this.expenseCenter = expenseCenter;
    }

    public String getFundCode() {
        return fundCode;
    }

    public void setFundCode(String fundCode) {
        this.fundCode = fundCode;
    }

    public String getItemId() {
        return itemId;
    }

    public void setItemId(String itemId) {
        this.itemId = itemId;
    }

    public String getKeyIdentifier() {
        return keyIdentifier;
    }

    public void setKeyIdentifier(String keyIdentifier) {
        this.keyIdentifier = keyIdentifier;
    }

    public String getKeyscope() {
        return keyscope;
    }

    public void setKeyscope(String keyscope) {
        this.keyscope = keyscope;
    }

    public String getPackCode() {
        return packCode;
    }

    public void setPackCode(String packCode) {
        this.packCode = packCode;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public int getPriorityCode() {
        return priorityCode;
    }

    public void setPriorityCode(int priorityCode) {
        this.priorityCode = priorityCode;
    }

    public String getProjectCode() {
        return projectCode;
    }

    public void setProjectCode(String projectCode) {
        this.projectCode = projectCode;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getRequiredDeliveryDate() {
        return requiredDeliveryDate;
    }

    public void setRequiredDeliveryDate(String requiredDeliveryDate) {
        this.requiredDeliveryDate = requiredDeliveryDate;
    }

    public Calendar getRequiredDeliveryDateCal() {
        return requiredDeliveryDateCal;
    }

    public void setRequiredDeliveryDateCal(Calendar requiredDeliveryDateCal) {
        this.requiredDeliveryDateCal = requiredDeliveryDateCal;
    }

    public AddressDO getShippingAddress() {
        return shippingAddress;
    }

    public void setShippingAddress(AddressDO shippingAddress) {
        this.shippingAddress = shippingAddress;
    }

    public AddressTypeDO getShippingAddressType() {
        return shippingAddressType;
    }

    public void setShippingAddressType(AddressTypeDO shippingAddressType) {
        this.shippingAddressType = shippingAddressType;
    }

    public String getShippingAddressDODAAC() {
        return shippingAddressDODAAC;
    }

    public void setShippingAddressDODAAC(String shippingAddressDODAAC) {
        this.shippingAddressDODAAC = shippingAddressDODAAC;
    }

    public String getUopCode() {
        return uopCode;
    }

    public void setUopCode(String uopCode) {
        this.uopCode = uopCode;
    }
    
    @Override
    public int hashCode() {
        int hash = 5;
        hash = 97 * hash + Objects.hashCode(this.adviceCode);
        hash = 97 * hash + Objects.hashCode(this.billingAddress);
        hash = 97 * hash + Objects.hashCode(this.billingAddressType);
        hash = 97 * hash + Objects.hashCode(this.deliveryDate);
        hash = 97 * hash + Objects.hashCode(this.deliveryDateCal);
        hash = 97 * hash + Objects.hashCode(this.distributionCode);
        hash = 97 * hash + Objects.hashCode(this.documentNumber);
        hash = 97 * hash + Objects.hashCode(this.expenseCenter);
        hash = 97 * hash + Objects.hashCode(this.fundCode);
        hash = 97 * hash + Objects.hashCode(this.itemId);
        hash = 97 * hash + Objects.hashCode(this.keyIdentifier);
        hash = 97 * hash + Objects.hashCode(this.keyscope);
        hash = 97 * hash + Objects.hashCode(this.packCode);
        hash = 97 * hash + Objects.hashCode(this.price);
        hash = 97 * hash + this.priorityCode;
        hash = 97 * hash + Objects.hashCode(this.projectCode);
        hash = 97 * hash + this.quantity;
        hash = 97 * hash + Objects.hashCode(this.requiredDeliveryDate);
        hash = 97 * hash + Objects.hashCode(this.shippingAddress);
        hash = 97 * hash + Objects.hashCode(this.shippingAddressType);
        hash = 97 * hash + Objects.hashCode(this.shippingAddressDODAAC);
        hash = 97 * hash + Objects.hashCode(this.uopCode);
        return hash;
    }
    
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final OrderItemDO other = (OrderItemDO) obj;
        if (this.priorityCode != other.priorityCode) {
            return false;
        }
        if (this.quantity != other.quantity) {
            return false;
        }
        if (!Objects.equals(this.adviceCode, other.adviceCode)) {
            return false;
        }
        if (!Objects.equals(this.deliveryDate, other.deliveryDate)) {
            return false;
        }
        if (!Objects.equals(this.distributionCode, other.distributionCode)) {
            return false;
        }
        if (!Objects.equals(this.documentNumber, other.documentNumber)) {
            return false;
        }
        if (!Objects.equals(this.expenseCenter, other.expenseCenter)) {
            return false;
        }
        if (!Objects.equals(this.fundCode, other.fundCode)) {
            return false;
        }
        if (!Objects.equals(this.itemId, other.itemId)) {
            return false;
        }
        if (!Objects.equals(this.keyIdentifier, other.keyIdentifier)) {
            return false;
        }
        if (!Objects.equals(this.keyscope, other.keyscope)) {
            return false;
        }
        if (!Objects.equals(this.packCode, other.packCode)) {
            return false;
        }
        if (!Objects.equals(this.projectCode, other.projectCode)) {
            return false;
        }
        if (!Objects.equals(this.requiredDeliveryDate, other.requiredDeliveryDate)) {
            return false;
        }
        if (!Objects.equals(this.shippingAddressDODAAC, other.shippingAddressDODAAC)) {
            return false;
        }
        if (!Objects.equals(this.uopCode, other.uopCode)) {
            return false;
        }
        if (!Objects.equals(this.billingAddress, other.billingAddress)) {
            return false;
        }
        if (!Objects.equals(this.billingAddressType, other.billingAddressType)) {
            return false;
        }
        if (!Objects.equals(this.deliveryDateCal, other.deliveryDateCal)) {
            return false;
        }
        if (!Objects.equals(this.price, other.price)) {
            return false;
        }
        if (!Objects.equals(this.requiredDeliveryDateCal, other.requiredDeliveryDateCal)) {
            return false;
        }
        if (!Objects.equals(this.shippingAddress, other.shippingAddress)) {
            return false;
        }
        if (!Objects.equals(this.shippingAddressType, other.shippingAddressType)) {
            return false;
        }
        return true;
    }
}
