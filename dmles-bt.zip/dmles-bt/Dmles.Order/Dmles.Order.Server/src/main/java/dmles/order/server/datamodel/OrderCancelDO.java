package dmles.order.server.datamodel;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import org.mongodb.morphia.annotations.Reference;

import java.util.Arrays;
import java.util.Objects;


@JsonSerialize
public class OrderCancelDO {
    
    private String dodaac;
    @Reference
    private OrderCancelItemDO[] cancelOrderItems;

   
    public String getDodaac() {
        return dodaac;
    }

    public void setDodaac(String dodaac) {
        this.dodaac = dodaac;
    }

    public OrderCancelItemDO[] getCancelOrderItems() {
        return cancelOrderItems;
    }

    public void setCancelOrderItems(OrderCancelItemDO[] cancelOrderItems) {
        this.cancelOrderItems = cancelOrderItems;
    }
    
    @Override
    public int hashCode() {
        int hash = 5;
        hash = 97 * hash + Objects.hashCode(this.dodaac);
        hash = 97 * hash + Arrays.deepHashCode(this.cancelOrderItems);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final OrderCancelDO other = (OrderCancelDO) obj;
        if (!Objects.equals(this.dodaac, other.dodaac)) {
            return false;
        }
        if (!Arrays.deepEquals(this.cancelOrderItems, other.cancelOrderItems)) {
            return false;
        }
        return true;
    }

}
