package dmles.order.server.datamodel;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import java.util.Arrays;
import java.util.Objects;

@JsonSerialize
public class OrderRequestDO {
    
    private String dodaac;
    private OrderItemDO[] orders;

    
    public String getDodaac() {
        return dodaac;
    }

    public void setDodaac(String dodaac) {
        this.dodaac = dodaac;
    }

    public OrderItemDO[] getOrders() {
        return orders;
    }

    public void setOrders(OrderItemDO[] orders) {
        this.orders = orders;
    }
    
    @Override
    public int hashCode() {
        int hash = 5;
        hash = 53 * hash + Objects.hashCode(this.dodaac);
        hash = 53 * hash + Arrays.deepHashCode(this.orders);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final OrderRequestDO other = (OrderRequestDO) obj;
        if (!Objects.equals(this.dodaac, other.dodaac)) {
            return false;
        }
        if (!Arrays.deepEquals(this.orders, other.orders)) {
            return false;
        }
        return true;
    }

}
