package dmles.order.server.datamodel;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import java.util.Objects;

@JsonSerialize
public class OrderCancelItemDO {
    private String documentNumber;
    private int quantityCancelled;

   
    public String getDocumentNumber() {
        return documentNumber;
    }

    public void setDocumentNumber(String documentNumber) {
        this.documentNumber = documentNumber;
    }

    public int getQuantityCancelled() {
        return quantityCancelled;
    }

    public void setQuantityCancelled(int quantityCancelled) {
        this.quantityCancelled = quantityCancelled;
    }
    
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 89 * hash + Objects.hashCode(this.documentNumber);
        hash = 89 * hash + this.quantityCancelled;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final OrderCancelItemDO other = (OrderCancelItemDO) obj;
        if (this.quantityCancelled != other.quantityCancelled) {
            return false;
        }
        if (!Objects.equals(this.documentNumber, other.documentNumber)) {
            return false;
        }
        return true;
    }

}
