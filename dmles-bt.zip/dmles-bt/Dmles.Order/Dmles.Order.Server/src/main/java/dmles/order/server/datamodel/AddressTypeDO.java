
package dmles.order.server.datamodel;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import java.util.HashMap;
import java.util.Map;

@JsonSerialize
public class AddressTypeDO implements java.io.Serializable {
    private String value;
    private static Map table = new HashMap();

    public static final String PRIMARY = "PRIMARY";
    public static final String SUPPLEMENTAL = "SUPPLEMENTAL";


    public String getValue() {
        return value;
    }


    public void setValue(String value) {
    
        this.value = value;
    }

    public static AddressTypeDO fromValue(String value)
                    throws java.lang.IllegalArgumentException  {
   
        AddressTypeDO enumeration = (AddressTypeDO)
                        table.get(value);
        if (enumeration == null) {
        
            throw new java.lang.IllegalArgumentException();
        }
        return enumeration;
    }

    public static AddressTypeDO fromString(java.lang.String value)
                    throws java.lang.IllegalArgumentException {
    
        return fromValue(value);
    }

    @Override
    public int hashCode() {
    
        final int prime = 31;
        int result = 1;
        result = (prime * result) + ((value == null) ? 0 : value.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
    
        if (this == obj) { 
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof AddressTypeDO)) {
            return false;
        }
        AddressTypeDO other = (AddressTypeDO)obj;
        if (value == null)   {
            if (other.value != null) {
                return false;
            }
        } else if (!value.equals(other.value))   {
            return false;
        }
        return true;
    }

}
