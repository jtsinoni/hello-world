package dmles.order.server.business;

 
import dmles.oauth.core.datamodel.CurrentUserBT;
import dmles.order.core.clientmodel.Customer;
import dmles.order.core.clientmodel.OrderCancel;
import dmles.order.core.clientmodel.OrderQuery;
import dmles.order.core.clientmodel.OrderReceipt;
import dmles.order.core.clientmodel.OrderRequest;
import dmles.order.core.clientmodel.OrderResult;
import dmles.order.core.clientmodel.OrderStatus;
import dmles.order.core.clientmodel.OrderSupportData;
import io.swagger.annotations.Api;
import mil.jmlfdc.common.business.BusinessManager;
import mil.jmlfdc.common.utils.ObjectMapper;
import org.slf4j.Logger;

import java.util.List;


import javax.ejb.Stateless;
import javax.inject.Inject;


@Api
@Stateless
public class OrderManager extends BusinessManager {

    @Inject
    private Logger logger;
    @Inject
    private ObjectMapper objectMapper;
    @Inject
    private CurrentUserBT currentUserBt;

    public OrderResult acknowledgeReceipts(OrderReceipt orderReceipt) {
        //Mock implementation
        OrderResult result = new OrderResult();
        result.dodaac = "dodaac";
        return result;
    }

    
    public OrderResult cancelOrder(OrderCancel orderCancel) {
         
        //Mock implementation
        OrderResult result = new OrderResult();
        result.dodaac = "dodaac";
        return result;
    }

    
    public String orderPing(String param) {
        //Mock implementation
        String result = "success";
        return result;
        
    }

    
    public OrderResult getOrderStatus(OrderQuery orderQuery) {
        //Mock implementation
        OrderResult result = new OrderResult();
        result.dodaac = "dodaac";
        return result;
         
    }


    public OrderSupportData getOrderSupportData(Customer customer) {
        //Mock implementation
        OrderSupportData result = new OrderSupportData();
        result.dodaac = "dodaac";
        return result;
         
    }


    public OrderResult submitOrder(OrderRequest orderRequest) {
        //Mock implementation
        OrderResult result = new OrderResult();
        result.dodaac = "dodaac";
        return result;
    }

    public OrderStatus queryOrderStatus(String dodaac, List<String> documentNumbers) {
        //Mock implementation
        OrderStatus result = new OrderStatus();
        result.dodaac = "dodaac";
        return result;
    }

    @Override
    public String getRequestorId() {
        return currentUserBt.getProfileId();
    }

    @Override
    public String getRequestorName() {
        return currentUserBt.getProfileId();
    }
}
