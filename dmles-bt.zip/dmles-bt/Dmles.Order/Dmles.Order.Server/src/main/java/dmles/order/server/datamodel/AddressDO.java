package dmles.order.server.datamodel; 

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import java.util.Objects;

@JsonSerialize
public class AddressDO {
    private String addrLine1;
    private String addrLine2;
    private String addrSerial;
    private String addressType;
    private String city;
    private String country;
    private String dodaac;
    private String state;
    private String zip;

    public String getAddrLine1() {
        return addrLine1;
    }

    public void setAddrLine1(String addrLine1) {
        this.addrLine1 = addrLine1;
    }

    public String getAddrLine2() {
        return addrLine2;
    }

    public void setAddrLine2(String addrLine2) {
        this.addrLine2 = addrLine2;
    }

    public String getAddrSerial() {
        return addrSerial;
    }

    public void setAddrSerial(String addrSerial) {
        this.addrSerial = addrSerial;
    }

    public String getAddressType() {
        return addressType;
    }

    public void setAddressType(String addressType) {
        this.addressType = addressType;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getDodaac() {
        return dodaac;
    }

    public void setDodaac(String dodaac) {
        this.dodaac = dodaac;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 79 * hash + Objects.hashCode(this.addrLine1);
        hash = 79 * hash + Objects.hashCode(this.addrLine2);
        hash = 79 * hash + Objects.hashCode(this.addrSerial);
        hash = 79 * hash + Objects.hashCode(this.addressType);
        hash = 79 * hash + Objects.hashCode(this.city);
        hash = 79 * hash + Objects.hashCode(this.country);
        hash = 79 * hash + Objects.hashCode(this.dodaac);
        hash = 79 * hash + Objects.hashCode(this.state);
        hash = 79 * hash + Objects.hashCode(this.zip);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final AddressDO other = (AddressDO) obj;
        if (!Objects.equals(this.addrLine1, other.addrLine1)) {
            return false;
        }
        if (!Objects.equals(this.addrLine2, other.addrLine2)) {
            return false;
        }
        if (!Objects.equals(this.addrSerial, other.addrSerial)) {
            return false;
        }
        if (!Objects.equals(this.addressType, other.addressType)) {
            return false;
        }
        if (!Objects.equals(this.city, other.city)) {
            return false;
        }
        if (!Objects.equals(this.country, other.country)) {
            return false;
        }
        if (!Objects.equals(this.dodaac, other.dodaac)) {
            return false;
        }
        if (!Objects.equals(this.state, other.state)) {
            return false;
        }
        if (!Objects.equals(this.zip, other.zip)) {
            return false;
        }
        return true;
    }
}
