package dmles.order.server.datamodel;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import java.math.BigDecimal;
import java.util.Objects;

@JsonSerialize
public class CatalogSearchItemDO {
    private String keyIdentifier;
    private String keyScope;
    private String itemId;
    private String shortDescription;
    private String longDescription;
    private Long customerWaitTimeDays;
    private String defaultSupplier;
    private boolean defaultSupplierStocked;
    private BigDecimal defaultPrice;
    private String defaultPackType;
    private Long defaultPackQuantity;
    private String manufacturer;
    private String manufacturerCatalogNumber;

   
    public String getKeyIdentifier() {
        return keyIdentifier;
    }

    public void setKeyIdentifier(String keyIdentifier) {
        this.keyIdentifier = keyIdentifier;
    }

    public String getKeyScope() {
        return keyScope;
    }

    public void setKeyScope(String keyScope) {
        this.keyScope = keyScope;
    }

    public String getItemId() {
        return itemId;
    }

    public void setItemId(String itemId) {
        this.itemId = itemId;
    }

    public String getShortDescription() {
        return shortDescription;
    }

    public void setShortDescription(String shortDescription) {
        this.shortDescription = shortDescription;
    }

    public String getLongDescription() {
        return longDescription;
    }

    public void setLongDescription(String longDescription) {
        this.longDescription = longDescription;
    }

    public Long getCustomerWaitTimeDays() {
        return customerWaitTimeDays;
    }

    public void setCustomerWaitTimeDays(Long customerWaitTimeDays) {
        this.customerWaitTimeDays = customerWaitTimeDays;
    }

    public String getDefaultSupplier() {
        return defaultSupplier;
    }

    public void setDefaultSupplier(String defaultSupplier) {
        this.defaultSupplier = defaultSupplier;
    }

    public boolean isDefaultSupplierStocked() {
        return defaultSupplierStocked;
    }

    public void setDefaultSupplierStocked(boolean defaultSupplierStocked) {
        this.defaultSupplierStocked = defaultSupplierStocked;
    }

    public BigDecimal getDefaultPrice() {
        return defaultPrice;
    }

    public void setDefaultPrice(BigDecimal defaultPrice) {
        this.defaultPrice = defaultPrice;
    }

    public String getDefaultPackType() {
        return defaultPackType;
    }

    public void setDefaultPackType(String defaultPackType) {
        this.defaultPackType = defaultPackType;
    }

    public Long getDefaultPackQuantity() {
        return defaultPackQuantity;
    }

    public void setDefaultPackQuantity(Long defaultPackQuantity) {
        this.defaultPackQuantity = defaultPackQuantity;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public String getManufacturerCatalogNumber() {
        return manufacturerCatalogNumber;
    }

    public void setManufacturerCatalogNumber(String manufacturerCatalogNumber) {
        this.manufacturerCatalogNumber = manufacturerCatalogNumber;
    }

     @Override
    public int hashCode() {
        int hash = 5;
        hash = 23 * hash + Objects.hashCode(this.keyIdentifier);
        hash = 23 * hash + Objects.hashCode(this.keyScope);
        hash = 23 * hash + Objects.hashCode(this.shortDescription);
        hash = 23 * hash + Objects.hashCode(this.longDescription);
        hash = 23 * hash + Objects.hashCode(this.customerWaitTimeDays);
        hash = 23 * hash + Objects.hashCode(this.defaultSupplier);
        hash = 23 * hash + (this.defaultSupplierStocked ? 1 : 0);
        hash = 23 * hash + Objects.hashCode(this.defaultPrice);
        hash = 23 * hash + Objects.hashCode(this.defaultPackType);
        hash = 23 * hash + Objects.hashCode(this.defaultPackQuantity);
        hash = 23 * hash + Objects.hashCode(this.manufacturer);
        hash = 23 * hash + Objects.hashCode(this.manufacturerCatalogNumber);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final CatalogSearchItemDO other = (CatalogSearchItemDO) obj;
        if (this.defaultSupplierStocked != other.defaultSupplierStocked) {
            return false;
        }
        if (!Objects.equals(this.keyIdentifier, other.keyIdentifier)) {
            return false;
        }
        if (!Objects.equals(this.keyScope, other.keyScope)) {
            return false;
        }
        if (!Objects.equals(this.itemId, other.itemId)) {
            return false;
        }
        if (!Objects.equals(this.shortDescription, other.shortDescription)) {
            return false;
        }
        if (!Objects.equals(this.longDescription, other.longDescription)) {
            return false;
        }
        if (!Objects.equals(this.defaultSupplier, other.defaultSupplier)) {
            return false;
        }
        if (!Objects.equals(this.defaultPackType, other.defaultPackType)) {
            return false;
        }
        if (!Objects.equals(this.manufacturer, other.manufacturer)) {
            return false;
        }
        if (!Objects.equals(this.manufacturerCatalogNumber, other.manufacturerCatalogNumber)) {
            return false;
        }
        if (!Objects.equals(this.customerWaitTimeDays, other.customerWaitTimeDays)) {
            return false;
        }
        if (!Objects.equals(this.defaultPrice, other.defaultPrice)) {
            return false;
        }
        if (!Objects.equals(this.defaultPackQuantity, other.defaultPackQuantity)) {
            return false;
        }
        return true;
    }



}
