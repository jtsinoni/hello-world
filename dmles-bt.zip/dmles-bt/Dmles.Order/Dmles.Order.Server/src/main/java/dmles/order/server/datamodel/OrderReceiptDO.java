package dmles.order.server.datamodel;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import org.mongodb.morphia.annotations.Reference;

import java.util.Arrays;
import java.util.Objects;


@JsonSerialize
public class OrderReceiptDO {
    private String dodaac;
    @Reference
    private ReceiptItemDO[] receiptAcknowledgements;

    
    public String getDodaac() {
        return dodaac;
    }

    public void setDodaac(String dodaac) {
        this.dodaac = dodaac;
    }

    public ReceiptItemDO[] getReceiptAcknowledgements() {
        return receiptAcknowledgements;
    }

    public void setReceiptAcknowledgements(ReceiptItemDO[] receiptAcknowledgements) {
        this.receiptAcknowledgements = receiptAcknowledgements;
    }
    
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 11 * hash + Objects.hashCode(this.dodaac);
        hash = 11 * hash + Arrays.deepHashCode(this.receiptAcknowledgements);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final OrderReceiptDO other = (OrderReceiptDO) obj;
        if (!Objects.equals(this.dodaac, other.dodaac)) {
            return false;
        }
        if (!Arrays.deepEquals(this.receiptAcknowledgements, other.receiptAcknowledgements)) {
            return false;
        }
        return true;
    }

}
