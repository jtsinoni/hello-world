package dmles.order.server.datamodel;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import org.mongodb.morphia.annotations.Reference;

import java.util.Arrays;
import java.util.Objects;


@JsonSerialize
public class OrderResultDO {
    private String dodaac;
    @Reference
    private OrderStatusItemDO[] results;

   
    public String getDodaac() {
        return dodaac;
    }

    public void setDodaac(String dodaac) {
        this.dodaac = dodaac;
    }

    public OrderStatusItemDO[] getResults() {
        return results;
    }

    public void setResults(OrderStatusItemDO[] results) {
        this.results = results;
    }
    
    @Override
    public int hashCode() {
        int hash = 5;
        hash = 97 * hash + Objects.hashCode(this.dodaac);
        hash = 97 * hash + Arrays.deepHashCode(this.results);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final OrderResultDO other = (OrderResultDO) obj;
        if (!Objects.equals(this.dodaac, other.dodaac)) {
            return false;
        }
        if (!Arrays.deepEquals(this.results, other.results)) {
            return false;
        }
        return true;
    }

}
