package dmles.facility.server.business;


import dmles.oauth.core.datamodel.CurrentUserBT;
import mil.jmlfdc.common.business.BusinessManager;
import org.slf4j.Logger;

import javax.ejb.Stateless;
import javax.inject.Inject;

@Stateless
public class FacilityManager extends BusinessManager {

    @Inject
    private Logger logger;
    @Inject
    private CurrentUserBT currentUserBt;

//    @Inject
//    private UserDao userDao;

    public String getVersion(){
        return "1";
    }

    @Override
    public String getRequestorId() {
        return currentUserBt.getProfileId();
    }

    @Override
    public String getRequestorName() {
        return currentUserBt.getFullName();
    }
}
    
