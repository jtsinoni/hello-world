package dmles.facility.server.rest;

import dmles.facility.core.IFacilityService;
import dmles.facility.server.business.FacilityManager;
import io.swagger.annotations.Api;
import mil.jmlfdc.common.rest.RestApiBase;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.core.Context;

@Api
@ApplicationScoped
public class FacilityRestApi extends RestApiBase implements IFacilityService {  

    @Context
    private FacilityManager manager;

    @Override
    public String getVersion() {
        return manager.getVersion();
    }
}
