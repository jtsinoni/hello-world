package dmles.facility.server.utils;

import org.apache.deltaspike.core.api.config.PropertyFileConfig;

import javax.ejb.Singleton;
import javax.ejb.Startup;

@Singleton
@Startup
public class FacilityPropertyFileConfig implements PropertyFileConfig {

    @Override
    public String getPropertyFileName() {
        return "facility.properties";
    }
}
