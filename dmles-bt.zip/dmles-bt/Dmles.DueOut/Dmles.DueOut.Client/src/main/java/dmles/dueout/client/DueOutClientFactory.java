package dmles.dueout.client;

import dmles.dueout.core.IDueOutService;
import dmles.oauth.core.rest.SecuredRestClientFactory;
import mil.jmlfdc.common.business.RestClientFactory;

import javax.enterprise.context.Dependent;
import javax.enterprise.inject.Produces;

@Dependent
//TODO: Need to remove once TOM implements OAuth replacement. Remove OAuth dependency from POM.xml too
//public class DueOutClientFactory extends RestClientFactory <IDueOutService> {
public class DueOutClientFactory extends SecuredRestClientFactory<IDueOutService> {
    public DueOutClientFactory() {
        super(IDueOutService.class, "Dmles.DueOut.Server");
    }

    @Produces
    public IDueOutService getIDueOutService() {
        return createClient();
    }
}
