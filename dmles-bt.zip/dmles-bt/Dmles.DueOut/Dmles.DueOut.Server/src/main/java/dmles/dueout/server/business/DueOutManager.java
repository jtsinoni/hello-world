package dmles.dueout.server.business;

import dmles.dueout.core.datamodel.DueOut;
import dmles.dueout.core.datamodel.TestData;
import dmles.dueout.server.dao.DueOutDao;
import dmles.dueout.server.dao.PingDataDao;
import dmles.dueout.server.datamodel.DueOutDO;
import dmles.dueout.server.datamodel.PingDataDO;
import dmles.order.core.datamodel.DueinItem;
import mil.jmlfdc.common.business.BusinessManager;
import mil.jmlfdc.common.exception.ObjectNotFoundException;
import mil.jmlfdc.common.utils.ObjectMapper;
import dmles.order.core.datamodel.Order;
import org.slf4j.Logger;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.List;

@Stateless
public class DueOutManager extends BusinessManager {

    @Inject
    private Logger log;

    // need a ping dao here
    @Inject
    private PingDataDao pingDataDao;

    @Inject
    private ObjectMapper objectMapper;

    @Inject
    private DueOutDao dueOutDao;

    public TestData getPing() {
        log.info("Pinged the BT DueOut Manager!");
        log.info("User: {}", this.currentUserBt.getPkiDn());
        PingDataDO pingDo = pingDataDao.getPingData("Hello from the DueOut Manager...");
        return objectMapper.getObject(TestData.class, pingDo);
    }


    public List<DueOut> getAllDueInRecords() {
        List<DueOutDO> persistedDueOuts = dueOutDao.getAllDueInRecords();
        List<DueOut> dueOuts = objectMapper.getList(DueOut[].class, persistedDueOuts);
        return dueOuts;

    }

    public List<DueOut> getDueOutsByOwnerOrgNodeId(String ownerOrgNodeId) {
        List<DueOutDO> persistedDueOuts = dueOutDao.getDueOutsByOwnerOrgNodeId(ownerOrgNodeId);
        List<DueOut> dueOuts = objectMapper.getList(DueOut[].class, persistedDueOuts);
        return dueOuts;
    }

    public List<DueOut> getOpenDueOutsByOwnerOrgNodeId(String ownerOrgNodeId) {
        List<DueOutDO> persistedDueOuts = dueOutDao.getOpenDueOutsByOwnerOrgNodeId(ownerOrgNodeId);
        List<DueOut> dueOuts = objectMapper.getList(DueOut[].class, persistedDueOuts);
        return dueOuts;
    }

    public List<DueOut> getBackOrderDueOutsByOwnerOrgNodeId(String ownerOrgNodeId) {
        List<DueOutDO> persistedDueOuts = dueOutDao.getBackOrderDueOutsByOwnerOrgNodeId(ownerOrgNodeId);
        List<DueOut> dueOuts = objectMapper.getList(DueOut[].class, persistedDueOuts);
        return dueOuts;
    }


    public DueOut createDueOut(DueOut dueOut) {

        DueOutDO dueOutDO = objectMapper.getObject(DueOutDO.class, dueOut);
        DueOutDO dueOutDOPersisted = dueOutDao.upsert(dueOutDO);
        return objectMapper.getObject(DueOut.class, dueOutDOPersisted);
    }


    public void acceptIncomingOrder(Order order) {

        List<DueinItem> dueinDatas = order.dueinData;
        for (DueinItem dueinItem : dueinDatas) {

            DueOut dueOut = new DueOut();
            dueOut.orderId = order.id;
            dueOut.orderDocNum = order.documentNumber;
            dueOut.buyerId = order.buyerId;
            dueOut.buyerName = order.buyerName;
            dueOut.createdDate = order.orderCreatedDate;
            dueOut.createdBy = order.userId;
            dueOut.itemId = dueinItem.itemID;
            dueOut.itemDescription = dueinItem.itemDescription;
            dueOut.documentNum = dueinItem.documentNumber;
            dueOut.vendorItemNum = dueinItem.vendorItemNumber;
            dueOut.packCode = dueinItem.packCode;
            dueOut.itemPrice = dueinItem.itemPrice;
            dueOut.packQty = dueinItem.packQuantity;
            dueOut.itemSurchargeAmount = dueinItem.itemSurchargeamount;
            dueOut.orderLineNum = dueinItem.orderLineNumber;
            dueOut.fundId = dueinItem.fundID;
//            dueOut.fiscalYearObligated = dueinItem.fiscalYearObligated;
            dueOut.refundCode = dueinItem.refundCode;
            dueOut.orderQty = dueinItem.orderQuantity;
            dueOut.ownerOrgNodeId = order.sellerId;

            dueOut.isIssueFromInventory = false;
            dueOut.parentDueInId = null;

            dueOut.balanceDueQty = 0;
            dueOut.increaseQty = 0;
            dueOut.cancelQty = 0;
            dueOut.receivedQty = 0;
            dueOut.reversedQty = 0;
            dueOut.backOrderQty = 0;
            dueOut.issueQty = 0;

            dueOut.updatedDate = new Date();
            dueOut.updatedBy = currentUserBt.getFullName();


            DueOut ret = this.createDueOut(dueOut);
        }


    }

}
