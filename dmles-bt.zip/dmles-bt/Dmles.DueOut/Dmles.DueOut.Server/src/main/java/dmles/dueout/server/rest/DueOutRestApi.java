package dmles.dueout.server.rest;


import dmles.dueout.core.IDueOutService;
import dmles.dueout.core.datamodel.DueOut;
import dmles.dueout.server.business.DueOutManager;
import dmles.order.core.datamodel.Order;
import io.swagger.annotations.Api;
import mil.jmlfdc.common.rest.RestApiBase;
import dmles.dueout.core.datamodel.TestData;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.QueryParam;
import java.util.List;

@Api(value = "DueOutRestApi", description = "Due-Out Rest Api")
@ApplicationScoped
public class DueOutRestApi extends RestApiBase implements IDueOutService {

    @Inject
    private DueOutManager manager;

    @Override
    public TestData getPing() {
        return manager.getPing();
    }


    @Override
    public List<DueOut> getDueOutsByOwnerOrgNodeId(@QueryParam("ownerOrgNodeId") String ownerOrgNodeId) {
        return manager.getDueOutsByOwnerOrgNodeId(ownerOrgNodeId);
    }

    @Override
    public List<DueOut> getOpenDueOutsByOwnerOrgNodeId(@QueryParam("ownerOrgNodeId") String ownerOrgNodeId){
        return manager.getOpenDueOutsByOwnerOrgNodeId(ownerOrgNodeId);
    }

    @Override
    public List<DueOut> getBackOrderDueOutsByOwnerOrgNodeId(@QueryParam("ownerOrgNodeId") String ownerOrgNodeId){
        return manager.getBackOrderDueOutsByOwnerOrgNodeId(ownerOrgNodeId);
    }



    @Override
    public void acceptIncomingOrder(Order order){
        manager.acceptIncomingOrder(order);
    }

}
