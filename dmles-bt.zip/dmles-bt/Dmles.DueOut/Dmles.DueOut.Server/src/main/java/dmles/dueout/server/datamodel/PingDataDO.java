package dmles.dueout.server.datamodel;

import com.fasterxml.jackson.annotation.JsonFormat;
import mil.jmlfdc.common.constants.DateAndTime;
import mil.jmlfdc.common.datamodel.MorphiaEntity;

import java.util.Date;

public class PingDataDO extends MorphiaEntity {

    private String message = "Ping!";
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateAndTime.DATE_TIME_PATTERN)
    private Date createdDate = new Date();

    public PingDataDO() {
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

}