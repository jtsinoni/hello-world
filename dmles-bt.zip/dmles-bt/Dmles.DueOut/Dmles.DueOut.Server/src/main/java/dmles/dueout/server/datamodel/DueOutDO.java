package dmles.dueout.server.datamodel;

import mil.jmlfdc.common.datamodel.MorphiaEntity;
import org.mongodb.morphia.annotations.Entity;

import java.io.Serializable;
import java.util.Date;

@Entity(value = "DueOut", noClassnameStored = true)
public class DueOutDO extends MorphiaEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    private String itemId;
    private String vendorItemNum;
    private String itemDescription;
    private String documentNum;
    private String packCode;
    private Float packQty;
    private Integer orderQty;
    private Integer balanceDueQty;
    private Integer increaseQty;
    private Integer cancelQty;
    private Integer receivedQty;
    private Integer reversedQty;
    private Integer backOrderQty;
    private Integer issueQty;
    private Float itemPrice;
    private Float itemSurchargeAmount;
    private Integer orderLineNum;
    private String fundId;
    private String buyerId;
    private String buyerName;
    private Integer fiscalYearObligated;
    private String refundCode;
    private String orderId;
    private String orderDocNum;
    private Date createdDate;
    private String createdBy;
    private Date updatedDate;
    private String updatedBy;
    private Boolean isIssueFromInventory;
    private String parentDueInId;
    private String ownerOrgNodeId;


    public String getItemId() {
        return itemId;
    }

    public void setItemId(String itemId) {
        this.itemId = itemId;
    }

    public String getVendorItemNum() {
        return vendorItemNum;
    }

    public void setVendorItemNum(String vendorItemNum) {
        this.vendorItemNum = vendorItemNum;
    }

    public String getItemDescription() {
        return itemDescription;
    }

    public void setItemDescription(String itemDescription) {
        this.itemDescription = itemDescription;
    }

    public String getDocumentNum() {
        return documentNum;
    }

    public void setDocumentNum(String documentNum) {
        this.documentNum = documentNum;
    }

    public String getPackCode() {
        return packCode;
    }

    public void setPackCode(String packCode) {
        this.packCode = packCode;
    }

    public Float getPackQty() {
        return packQty;
    }

    public void setPackQty(Float packQty) {
        this.packQty = packQty;
    }

    public Integer getOrderQty() {
        return orderQty;
    }

    public void setOrderQty(Integer orderQty) {
        this.orderQty = orderQty;
    }

    public Integer getBalanceDueQty() {
        return balanceDueQty;
    }

    public void setBalanceDueQty(Integer balanceDueQty) {
        this.balanceDueQty = balanceDueQty;
    }

    public Integer getIncreaseQty() {
        return increaseQty;
    }

    public void setIncreaseQty(Integer increaseQty) {
        this.increaseQty = increaseQty;
    }

    public Integer getCancelQty() {
        return cancelQty;
    }

    public void setCancelQty(Integer cancelQty) {
        this.cancelQty = cancelQty;
    }

    public Integer getReceivedQty() {
        return receivedQty;
    }

    public void setReceivedQty(Integer receivedQty) {
        this.receivedQty = receivedQty;
    }

    public Integer getReversedQty() {
        return reversedQty;
    }

    public void setReversedQty(Integer reversedQty) {
        this.reversedQty = reversedQty;
    }

    public Integer getBackOrderQty() {
        return backOrderQty;
    }

    public void setBackOrderQty(Integer backOrderQty) {
        this.backOrderQty = backOrderQty;
    }

    public Integer getIssueQty() {
        return issueQty;
    }

    public void setIssueQty(Integer issueQty) {
        this.issueQty = issueQty;
    }

    public Float getItemPrice() {
        return itemPrice;
    }

    public void setItemPrice(Float itemPrice) {
        this.itemPrice = itemPrice;
    }

    public Float getItemSurchargeAmount() {
        return itemSurchargeAmount;
    }

    public void setItemSurchargeAmount(Float itemSurchargeAmount) {
        this.itemSurchargeAmount = itemSurchargeAmount;
    }

    public Integer getOrderLineNum() {
        return orderLineNum;
    }

    public void setOrderLineNum(Integer orderLineNum) {
        this.orderLineNum = orderLineNum;
    }

    public String getFundId() {
        return fundId;
    }

    public void setFundId(String fundId) {
        this.fundId = fundId;
    }

    public String getBuyerId() {
        return buyerId;
    }

    public void setBuyerId(String buyerId) {
        this.buyerId = buyerId;
    }

    public String getBuyerName() {
        return buyerName;
    }

    public void setBuyerName(String buyerName) {
        this.buyerName = buyerName;
    }

    public Integer getFiscalYearObligated() {
        return fiscalYearObligated;
    }

    public void setFiscalYearObligated(Integer fiscalYearObligated) {
        this.fiscalYearObligated = fiscalYearObligated;
    }

    public String getRefundCode() {
        return refundCode;
    }

    public void setRefundCode(String refundCode) {
        this.refundCode = refundCode;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getOrderDocNum() {
        return orderDocNum;
    }

    public void setOrderDocNum(String orderDocNum) {
        this.orderDocNum = orderDocNum;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Boolean getIssueFromInventory() {
        return isIssueFromInventory;
    }

    public void setIssueFromInventory(Boolean issueFromInventory) {
        isIssueFromInventory = issueFromInventory;
    }

    public String getParentDueInId() {
        return parentDueInId;
    }

    public void setParentDueInId(String parentDueInId) {
        this.parentDueInId = parentDueInId;
    }

    public String getOwnerOrgNodeId() {
        return ownerOrgNodeId;
    }

    public void setOwnerOrgNodeId(String ownerOrgNodeId) {
        this.ownerOrgNodeId = ownerOrgNodeId;
    }
}

