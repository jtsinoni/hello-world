package dmles.dueout.server.dao;


import dmles.dueout.server.datamodel.PingDataDO;
import mil.jmlfdc.common.dao.BaseDao;

import javax.enterprise.context.Dependent;
import java.util.Date;

@Dependent
public class PingDataDao extends BaseDao<PingDataDO, String> {

    public PingDataDao() {
        super(PingDataDO.class);
    }

    public PingDataDO getPingData(String message) {
        PingDataDO test = new PingDataDO();
        test.setMessage(message);
        test.setCreatedDate(new Date());
        return test;
    }

}
