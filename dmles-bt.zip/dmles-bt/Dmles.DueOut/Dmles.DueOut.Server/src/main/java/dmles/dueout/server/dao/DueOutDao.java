package dmles.dueout.server.dao;

import dmles.dueout.server.datamodel.DueOutDO;
import mil.jmlfdc.common.dao.BaseDao;
import org.mongodb.morphia.query.Query;
import org.slf4j.Logger;

import javax.enterprise.context.Dependent;
import javax.inject.Inject;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Dependent
public class DueOutDao extends BaseDao<DueOutDO, String> {

    @Inject
    private Logger logger;

    public DueOutDao() {
        super(DueOutDO.class);
    }

    public List<DueOutDO> getAllDueInRecords() {
        return super.findAll();
    }

    public List<DueOutDO> getDueOutsByOwnerOrgNodeId(String ownerOrgNodeId) {
        Query<DueOutDO> query = this.getQuery(DueOutDO.class).filter("ownerOrgNodeId =", ownerOrgNodeId);
        return query.asList();
    }

    public List<DueOutDO> getOpenDueOutsByOwnerOrgNodeId(String ownerOrgNodeId) {

        Query<DueOutDO> query = this.getQuery(DueOutDO.class).filter("ownerOrgNodeId =", ownerOrgNodeId);
        query.filter("balanceDueQty >",0);
        return query.asList();
    }

    public List<DueOutDO> getBackOrderDueOutsByOwnerOrgNodeId(String ownerOrgNodeId) {

        Query<DueOutDO> query = this.getQuery(DueOutDO.class).filter("ownerOrgNodeId =", ownerOrgNodeId);
        query.filter("isIssueFromInventory =",false);
        query.filter("balanceDueQty >",0);
        return query.asList();
    }


}
