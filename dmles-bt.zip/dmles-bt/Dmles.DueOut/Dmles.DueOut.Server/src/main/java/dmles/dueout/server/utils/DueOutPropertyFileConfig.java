package dmles.dueout.server.utils;

import org.apache.deltaspike.core.api.config.PropertyFileConfig;

import javax.ejb.Singleton;
import javax.ejb.Startup;

@Singleton
@Startup
public class DueOutPropertyFileConfig implements PropertyFileConfig{
    private static final long serialVersionUID = -7762380573887097591L;
    @Override
    public String getPropertyFileName() {
        return "dueout.properties";
    }
}