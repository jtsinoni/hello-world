package dmles.dueout.core.datamodel;

import mil.jmlfdc.common.datamodel.catalog.Item;

import java.util.Date;

public class DueOut {




    public String id;

    public String citemId;
    public String vendorItemNum;
    public String itemDescription;
    public String documentNum;
    public String packCode;
    public Float packQty;
    public Integer orderQty;
    public Integer balanceDueQty;
    public Integer increaseQty;
    public Integer cancelQty;
    public Integer receivedQty;
    public Integer reversedQty;
    public Integer backOrderQty;
    public Integer issueQty;
    public Float itemPrice;
    public Float itemSurchargeAmount;
    public Integer orderLineNum;
    public String fundId;
    public String buyerId;
    public String buyerName;
    public Integer fiscalYearObligated;
    public String refundCode;
    public String orderId;
    public String orderDocNum;
    public Date createdDate;
    public String createdBy;
    public Date updatedDate;
    public String updatedBy;
    public Boolean isIssueFromInventory;
    public String parentDueInId;
    public String ownerOrgNodeId;
    public Item item;



}
