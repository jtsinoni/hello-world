package dmles.dueout.core;

import dmles.dueout.core.datamodel.DueOut;
import dmles.dueout.core.datamodel.TestData;
import dmles.order.core.datamodel.Order;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.util.List;

@Path("/V1/DueOut")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)


public interface IDueOutService {
    @GET
    @Path("/getPing")
    TestData getPing();


    @POST
    @Path("/acceptIncomingOrder")

    public void acceptIncomingOrder(Order order);

    @GET
    @Path("/getDueOutsByOwnerOrgNodeId")
    public List<DueOut> getDueOutsByOwnerOrgNodeId(@QueryParam("ownerOrgNodeId") String ownerOrgNodeId);

    @GET
    @Path("/getOpenDueOutsByOwnerOrgNodeId")
    public List<DueOut> getOpenDueOutsByOwnerOrgNodeId(@QueryParam("ownerOrgNodeId") String ownerOrgNodeId);

    @GET
    @Path("/getBackOrderDueOutsByOwnerOrgNodeId")
    public List<DueOut> getBackOrderDueOutsByOwnerOrgNodeId(@QueryParam("ownerOrgNodeId") String ownerOrgNodeId);

}
