package dmles.duein.client;

import dmles.duein.core.IDueInService;
import mil.jmlfdc.common.business.RestClientFactory;
import dmles.oauth.core.rest.SecuredRestClientFactory;
import javax.enterprise.context.Dependent;
import javax.enterprise.inject.Produces;

@Dependent
//TODO: Need to remove once TOM implements OAuth replacement. Remove OAuth dependency from POM.xml too
//public class DueInClientFactory extends RestClientFactory<IDueInService> {
public class DueInClientFactory extends SecuredRestClientFactory<IDueInService> {
    public DueInClientFactory() {
        super(IDueInService.class, "Dmles.DueIn.Server");
    }

    @Produces
    public IDueInService getIDueInService() {
        return createClient();
    }

}
