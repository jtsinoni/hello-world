package dmles.duein.core.datamodel;

public class TestData {

    public String message;
    public String time;


}

