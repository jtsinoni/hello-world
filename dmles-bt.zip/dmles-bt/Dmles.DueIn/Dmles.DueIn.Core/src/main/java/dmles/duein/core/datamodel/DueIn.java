package dmles.duein.core.datamodel;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class DueIn {

    public String id;
    public String itemId;
    public String vendorItemNum;
    public String itemDescription;
    public String documentNum;
    public String packCode;
    public Float packQty;
    public Integer orderQty;
    public Integer balanceDueQty;
    public Integer increaseQty;
    public Integer cancelQty;
    public Integer receivedQty;
    public Integer reversedQty;
    public Integer shipQty;
    public Float itemPrice;
    public Float itemSurchargeAmount;
    public Integer orderLineNum;
    public String fundId;
    public String sellerId;
    public String sellerName;
    public String buyerId;
    public String buyerName;
    public Integer fiscalYearObligated;
    public String refundCode;
    public String orderId;
    public String orderDocNumber;
    public String orderCallNum;
    public String orderContractNum;
    public String DeliveryTypeCode;
    public String submissionStatus;
    public Date createdDate;
    public String createdBy;
    public Date updatedDate;
    public String updatedBy;
    public String ownerOrgNodeId;
    public String ownerOrgNodeName;
    


//    public String itemId;
//    public String vendorItemNumber;
//    public String itemDescription;
//    public String documentNumber;
//    public String packCode;
//    public Float packQuantity;
//    public Integer orderQuantity;
//    public Integer balanceDueQuantity;
//    public Integer increaseQuantity;
//    public Integer cancelQuantity;
//    public Integer receivedQuantity;
//    public Integer reversedQuantity;
//    public Integer shipQuantity;
//    public Float itemPrice;
//    public Float itemSurchargeAmount;
//    public Integer orderLineNumber;
//    public String fundId;
//    public String sellerId;
//    public String sellerName;
//    public String buyerId;
//    public String buyerName;
//    public String fiscalYearObligated;
//    public String refundCode;
//    public String orderId;
//    public String orderDocNumber;
//    public String orderCallNum;
//    public String orderContractNumber;
//    public String DeliveryTypeCode;
//    public String submissionStatus;
//    public String createDate;
//    public String createUser;
//    public String lastUpdateDate;
//    public String lastUpdateUser;
//    public String ownerOrgNodeId;
//    public String ownerOrgNodeName;

    public List<DueInStatus> status = new ArrayList<>();

}
