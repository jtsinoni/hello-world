package dmles.duein.core;

import dmles.duein.core.datamodel.DueIn;
import dmles.duein.core.datamodel.TestData;
import dmles.order.core.datamodel.Order;
import mil.jmlfdc.common.exception.ObjectNotFoundException;



import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.util.List;

@Path("/V1/DueIn")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)

public interface IDueInService {
    @GET
    @Path("/getPing")
    TestData getPing();

    @GET
    @Path("/getAllDueIns")
    List<DueIn> getAllDueIns();

    @GET
    @Path("/getAllOpenDueIns")
    public List<DueIn> getAllOpenDueIns();

    @GET
    @Path("/getAllClosedDueIns")
    public List<DueIn> getAllClosedDueIns();


    @GET
    @Path("/getAllOpenDueInsSearch")
    public List<DueIn> getAllOpenDueInsSearch(@QueryParam("searchText") String searchText);

    @GET
    @Path("/getDueInById")
    public DueIn getDueInById(@QueryParam("dueInId") String dueInId);


    @GET
    @Path("/getDueInsByOrderId")
    public List<DueIn> getDueInsByOrderId(@QueryParam("orderId") String orderId);



    @GET
    @Path("/getDueInsByOwnerOrgNodeId")
    public List<DueIn> getDueInsByOwnerOrgNodeId(@QueryParam("ownerOrgNodeId") String ownerOrgNodeId);


    @GET
    @Path("/getDueInsByBuyerId")
    public List<DueIn> getDueInsByBuyerId(@QueryParam("buyerId") String buyerId);




    @POST
    @Path("/addDueIn")
    public DueIn addDueIn(DueIn dueIn) throws ObjectNotFoundException;;

    @GET
    @Path("/updateDueInBalanceQty")
    public DueIn updateDueInBalanceQty(@QueryParam("dueInId") String dueInId, @QueryParam("balanceDueQty")  Integer balanceDueQty);

    @GET
    @Path("/changeDueInQuantity")
    public DueIn changeDueInQuantity(@QueryParam("dueInId") String dueInId, @QueryParam("changeQty")  Integer changeQty);

    @GET
    @Path("/updateReceivedQuantity")
    public DueIn updateReceivedQuantity(@QueryParam("dueInId") String dueInId, @QueryParam("quantity")  Integer quantity);

    @GET
    @Path("/changeDueInPrice")
    public DueIn changeDueInPrice(@QueryParam("dueInId") String dueInId, @QueryParam("price")  Float price);

    @POST
    @Path("/saveDueIn")
    public DueIn saveDueIn(DueIn dueIn) throws ObjectNotFoundException;

    @POST
    @Path("/acceptOrder")
    public Integer acceptOrder(Order order) throws ObjectNotFoundException ;

}
