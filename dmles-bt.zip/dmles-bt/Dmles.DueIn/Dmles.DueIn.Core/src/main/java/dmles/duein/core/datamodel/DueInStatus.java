package dmles.duein.core.datamodel;

import mil.jmlfdc.common.constants.DateAndTime;
import mil.jmlfdc.common.utils.DateUtil;

import java.util.Date;


public class DueInStatus
{
    public String code;
    public String description;
    public Integer quantity;
    public Float price;
    public String statusDate;
    public String dateEstimated;
    public String shipmentId;
    public Date createdDate;
    public String createdBy;

}
