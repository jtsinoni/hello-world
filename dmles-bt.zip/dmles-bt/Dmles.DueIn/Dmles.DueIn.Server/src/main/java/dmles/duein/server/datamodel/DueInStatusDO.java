package dmles.duein.server.datamodel;

import mil.jmlfdc.common.constants.DateAndTime;
import mil.jmlfdc.common.utils.DateUtil;

import java.io.Serializable;
import java.util.Date;

public class DueInStatusDO implements Serializable {

    private String code;
    private String description;
    private Integer quantity;
    private Float price;
    private String statusDate;
    private String dateEstimated;
    private String shipmentId;
    private Date createdDate;
    private String createdBy;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Float getPrice() {
        return price;
    }

    public void setPrice(Float price) {
        this.price = price;
    }

    public String getStatusDate() {
        return statusDate;
    }

    public void setStatusDate(String statusDate) {
        this.statusDate = statusDate;
    }

    public String getDateEstimated() {
        return dateEstimated;
    }

    public void setDateEstimated(String dateEstimated) {
        this.dateEstimated = dateEstimated;
    }

    public String getShipmentId() {
        return shipmentId;
    }

    public void setShipmentId(String shipmentId) {
        this.shipmentId = shipmentId;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }
}
