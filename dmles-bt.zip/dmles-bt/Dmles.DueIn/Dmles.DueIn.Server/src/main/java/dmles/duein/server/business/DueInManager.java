package dmles.duein.server.business;


import dmles.duein.core.datamodel.DueIn;
import dmles.duein.core.datamodel.TestData;
import dmles.duein.server.dao.DueInDao;
import dmles.duein.server.dao.PingDataDao;
import dmles.duein.server.datamodel.DueInDO;
import dmles.duein.server.datamodel.DueInStatusDO;
import dmles.duein.server.datamodel.PingDataDO;
import dmles.order.core.IOrderService;
import dmles.order.core.datamodel.DueinItem;
import dmles.order.core.datamodel.Order;
import mil.jmlfdc.common.business.BusinessManager;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.validation.constraints.NotNull;

import mil.jmlfdc.common.constants.DateAndTime;
import mil.jmlfdc.common.exception.ObjectNotFoundException;
import mil.jmlfdc.common.utils.DateUtil;
import mil.jmlfdc.common.utils.ObjectMapper;
import org.slf4j.Logger;

import java.util.Date;
import java.util.List;

@Stateless
public class DueInManager extends BusinessManager {

    @Inject
    private Logger log;
    // need a ping dao here
    @Inject
    private PingDataDao pingDataDao;
    @Inject
    private ObjectMapper objectMapper;
    @Inject
    private DueInDao dueInDao;
    @Inject
    private IOrderService orderService;

    public TestData getPing() {
        log.info("Pinged the BT DueIn Manager!");
        log.info("User: {}", this.currentUserBt.getPkiDn());
        PingDataDO pingDo = pingDataDao.getPingData("Hello from the DueIn Manager...");
        return objectMapper.getObject(TestData.class, pingDo);
    }

    public List<DueIn> getAllDueIns() {
        List<DueInDO> persistedDueIns = dueInDao.getAllDueIns();
        List<DueIn> dueIns = objectMapper.getList(DueIn[].class, persistedDueIns);
        return dueIns;

    }

    public List<DueIn> getAllOpenDueIns() {

        List<DueInDO> persistedDueIns = dueInDao.getAllActiveDueIns();
        List<DueIn> dueIns = objectMapper.getList(DueIn[].class, persistedDueIns);
        return dueIns;
    }

    public List<DueIn> getAllClosedDueIns() {

        List<DueInDO> persistedDueIns = dueInDao.getAllClosedDueIns();
        List<DueIn> dueIns = objectMapper.getList(DueIn[].class, persistedDueIns);
        return dueIns;
    }

    public List<DueIn> getAllOpenDueInsSearch(String searchText) {

        List<DueInDO> persistedDueIns = dueInDao.getAllActiveDueInsSearch(searchText);
        List<DueIn> dueIns = objectMapper.getList(DueIn[].class, persistedDueIns);
        return dueIns;
    }


    public DueIn addDueIn(@NotNull DueIn dueIn) throws ObjectNotFoundException {

        DueInDO dueInDO = objectMapper.getObject(DueInDO.class, dueIn);
        DueInDO dueInDOPersisted = dueInDao.upsert(dueInDO);
        return objectMapper.getObject(DueIn.class, dueInDOPersisted);
    }

    public DueIn updateDueInBalanceQty(String dueInId, Integer balanceDueQty) {
        DueInDO persistedDueIns = dueInDao.updateDueInBalanceDueQty(dueInId, balanceDueQty);
        return objectMapper.getObject(DueIn.class, persistedDueIns);
    }

    public DueIn getDueInById(String dueInId) {
        DueInDO dueInDO = dueInDao.findById(dueInId);
        DueIn retObj = objectMapper.getObject(DueIn.class, dueInDO);
        return retObj;
    }

    public List<DueIn> getDueInsByOrderId(String orderId) {
        List<DueInDO> persistedDueIns = dueInDao.getDueInsByOrderId(orderId);
        List<DueIn> dueIns = objectMapper.getList(DueIn[].class, persistedDueIns);
        return dueIns;

    }


    public List<DueIn> getDueInsByOwnerOrgNodeId(String ownerOrgNodeId) {
        List<DueInDO> persistedDueIns = dueInDao.getDueInsByOwnerOrgNodeId(ownerOrgNodeId);
        List<DueIn> dueIns = objectMapper.getList(DueIn[].class, persistedDueIns);
        return dueIns;
    }


    public List<DueIn> getDueInsByBuyerId(String buyerId) {
        List<DueInDO> persistedDueIns = dueInDao.getDueInsByBuyerId(buyerId);
        List<DueIn> dueIns = objectMapper.getList(DueIn[].class, persistedDueIns);
        return dueIns;
    }


    public DueIn saveDueIn(@NotNull DueIn dueIn) throws ObjectNotFoundException {
        DueInDO dueInDO = objectMapper.getObject(DueInDO.class, dueIn);
        dueInDO.setUpdatedBy(currentUserBt.getFullName());
       // dueInDO.setUpdatedDate(DateUtil.getCurrentUTCDate());
        dueInDO.setUpdatedDate(new Date());
        dueInDao.upsert(dueInDO);
        return objectMapper.getObject(DueIn.class, dueInDO);

    }


    private DueInStatusDO addDueInStatus(String statuscode, Integer quantity, Float price, String statusDescription) {
        DueInStatusDO dueInStatusDO = new DueInStatusDO();
        dueInStatusDO.setCode(statuscode);
        dueInStatusDO.setDescription(statusDescription);
        dueInStatusDO.setQuantity(quantity);
        dueInStatusDO.setStatusDate(new Date().toString());
        dueInStatusDO.setCreatedDate(new Date());
        dueInStatusDO.setCreatedBy(currentUserBt.getFullName());
        dueInStatusDO.setPrice(price);
        return dueInStatusDO;
    }

    public DueIn changeDueInQuantity(String dueInId, Integer chgQty) {


        DueInDO dueInDO = dueInDao.changeDueInQuantity(dueInId, chgQty);
        List<DueInStatusDO> di = dueInDO.getStatus();

        String sstatusCode = "CA";
        if( dueInDO.getBalanceDueQty()> 0 )
            sstatusCode = "BJ";


        DueInStatusDO dueInStatusDO = addDueInStatus(sstatusCode, chgQty, dueInDO.getItemPrice(), "Quantity Change / Complete Cancellation");
        di.add(dueInStatusDO);
        dueInDO.setStatus(di);
        dueInDO.setUpdatedBy(currentUserBt.getFullName());
        dueInDO.setUpdatedDate(new Date());
        dueInDao.upsert(dueInDO);
        return objectMapper.getObject(DueIn.class, dueInDO);
    }


    public DueIn updateReceivedQuantity(String dueInId, Integer quantity) {
        DueInDO dueInDO = dueInDao.updateReceivedQuantity(dueInId, quantity);

        List<DueInStatusDO> di = dueInDO.getStatus();
        DueInStatusDO dueInStatusDO = addDueInStatus("RA", quantity, dueInDO.getItemPrice(), "Item Received");
        di.add(dueInStatusDO);
        dueInDO.setStatus(di);


        dueInDO.setUpdatedBy(currentUserBt.getFullName());
        dueInDO.setUpdatedDate(new Date());
        dueInDao.upsert(dueInDO);
        return objectMapper.getObject(DueIn.class, dueInDO);
    }


    public DueIn changeDueInPrice(String dueInId, Float price) {
        DueInDO dueInDO = dueInDao.changeDueInPrice(dueInId, price);
        List<DueInStatusDO> di = dueInDO.getStatus();
        DueInStatusDO dueInStatusDO = addDueInStatus("IP", dueInDO.getBalanceDueQty(), price, "Price change accepted");
        di.add(dueInStatusDO);
        dueInDO.setStatus(di);

        dueInDO.setUpdatedBy(currentUserBt.getFullName());
        dueInDO.setUpdatedDate(new Date());
        dueInDao.upsert(dueInDO);
        return objectMapper.getObject(DueIn.class, dueInDO);
    }

    public Integer acceptOrder(Order order) throws ObjectNotFoundException {
        List<DueinItem> dueinDatas = order.dueinData;
        for (DueinItem dueinItem : dueinDatas) {

            DueIn dueIn = new DueIn();
            dueIn.orderId = order.id;
            dueIn.orderCallNum = order.callNumber;
            dueIn.orderContractNum = order.contractNumber;
            dueIn.orderDocNumber = order.documentNumber;
            dueIn.buyerId = order.buyerId;
            dueIn.buyerName = order.buyerName;
            dueIn.sellerId = order.sellerId;
            dueIn.sellerName = order.sellerName;
            dueIn.createdDate = order.orderCreatedDate;
            dueIn.createdBy = order.userId;
            dueIn.itemId = dueinItem.itemID;
            dueIn.itemDescription = dueinItem.itemDescription;
            dueIn.documentNum = dueinItem.documentNumber;
            dueIn.vendorItemNum = dueinItem.vendorItemNumber;
            dueIn.packCode = dueinItem.packCode;
            dueIn.itemPrice = dueinItem.itemPrice;
            dueIn.packQty = dueinItem.packQuantity;
            dueIn.itemSurchargeAmount = dueinItem.itemSurchargeamount;
            dueIn.orderLineNum = dueinItem.orderLineNumber;
            dueIn.fundId = dueinItem.fundID;
//            dueIn.fiscalYearObligated = dueinItem.fiscalYearObligated;
            dueIn.refundCode = dueinItem.refundCode;
            dueIn.orderQty = dueinItem.orderQuantity;
            dueIn.balanceDueQty = 0;
            dueIn.increaseQty = 0;
            dueIn.cancelQty = 0;
            dueIn.receivedQty = 0;
            dueIn.reversedQty = 0;
            dueIn.shipQty = 0;
            dueIn.DeliveryTypeCode = "DRS";
            dueIn.submissionStatus = "TEST";
            dueIn.updatedDate = new Date();
            dueIn.updatedBy = currentUserBt.getFullName();

            dueIn.ownerOrgNodeId = "1";
            dueIn.ownerOrgNodeName = order.siteDodaac;


            DueIn ret = this.addDueIn(dueIn);
        }
        return 1;
    }

}
