package dmles.duein.server.dao;

import dmles.duein.server.datamodel.DueInDO;
import mil.jmlfdc.common.dao.BaseDao;
import mil.jmlfdc.common.dao.DataStore;
import org.mongodb.morphia.query.Query;
import org.mongodb.morphia.query.UpdateOperations;
import org.slf4j.Logger;

import javax.enterprise.context.Dependent;
import javax.inject.Inject;
import java.util.List;

@Dependent
public class DueInDao extends BaseDao<DueInDO, String> {

    @Inject
    private Logger logger;

    public DueInDao() {
        super(DueInDO.class);
    }

    public DueInDao(DataStore dataStore) {
        super(DueInDO.class);
    }

    public List<DueInDO> getAllDueIns() {
        return super.findAll();
    }

    public List<DueInDO> getAllActiveDueIns() {
        Query<DueInDO> query = this.getQuery(DueInDO.class);
        query.field("balanceDueQty").greaterThan(0);
        return query.asList();
    }

    public List<DueInDO> getAllClosedDueIns() {
        Query<DueInDO> query = this.getQuery(DueInDO.class);
        query.field("balanceDueQty").equal(0);
        return query.asList();
    }


    //db.getCollection('DueIns').createIndex( { "$**": "text" } ) in order to work.
    public List<DueInDO> getAllActiveDueInsSearch(String searchText) {
        Query<DueInDO> query = this.getQuery(DueInDO.class).search(searchText);
        query.field("balanceDueQty").greaterThan(0);
        return query.asList();
    }

    public List<DueInDO> getDueInsByOrderId(String orderId){
        Query<DueInDO> query = this.getQuery(DueInDO.class).filter("orderId =", orderId);
        return query.asList();
    }




    public List<DueInDO> getDueInsByOwnerOrgNodeId(String ownerOrgNodeId) {
        Query<DueInDO> query = this.getQuery(DueInDO.class).filter("ownerOrgNodeId =", ownerOrgNodeId);
        return query.asList();
    }


    public List<DueInDO> getDueInsByBuyerId(String buyerId) {
        Query<DueInDO> query = this.getQuery(DueInDO.class).filter("buyerId =", buyerId);
        return query.asList();
    }


    public DueInDO updateDueInBalanceDueQty(String dueInId, Integer balanceDueQty) {
        Query<DueInDO> upd = this.getQuery(DueInDO.class).filter("id =", dueInId);

        UpdateOperations<DueInDO> ops = this.getDatabaseOperation();
        ops.set("balanceDueQty", balanceDueQty);

        Integer updatedCount = this.update(upd, ops);
        logger.debug("update completed    " + updatedCount);
        DueInDO dueInDO = this.findById(dueInId);

        return dueInDO;
    }

    public DueInDO changeDueInQuantity(String dueInId, Integer chgQty) {
        DueInDO dueInDO = this.findById(dueInId);

        Integer balqty = dueInDO.getBalanceDueQty();
        Integer increaseQty = dueInDO.getIncreaseQty();
        Integer cancelQty   = dueInDO.getCancelQty();

        if (chgQty > 0) {
            dueInDO.setBalanceDueQty(balqty + chgQty);
            dueInDO.setIncreaseQty(increaseQty + chgQty);
        } else
        {
            dueInDO.setBalanceDueQty(balqty - chgQty);
            dueInDO.setCancelQty(cancelQty+chgQty);
        };

        return dueInDO;
    }

    public DueInDO updateReceivedQuantity(String dueInId, Integer quantity) {
        DueInDO dueInDO = this.findById(dueInId);

        Integer balqty = dueInDO.getBalanceDueQty();
        Integer receivedQty = dueInDO.getReceivedQty();
        Integer reversedQty = dueInDO.getReversedQty();


        if (quantity > 0) {
            dueInDO.setBalanceDueQty(balqty - quantity);
            dueInDO.setReceivedQty(receivedQty + quantity);
        } else
        {
            dueInDO.setBalanceDueQty(balqty + Math.abs(quantity));
            dueInDO.setReceivedQty(receivedQty - Math.abs(quantity));
            dueInDO.setReversedQty(reversedQty+Math.abs(quantity));

        };

        return dueInDO;
    }



    public DueInDO changeDueInPrice(String dueInId, Float price){
        DueInDO dueInDO = this.findById(dueInId);

        if (price > 0){
            dueInDO.setItemPrice(price);
        }

        return dueInDO;

    }




}
