package dmles.duein.server.rest;


import dmles.duein.core.IDueInService;
import dmles.duein.core.datamodel.DueIn;
import dmles.duein.core.datamodel.TestData;
import dmles.duein.server.business.DueInManager;
import dmles.order.core.datamodel.Order;
import io.swagger.annotations.Api;
import mil.jmlfdc.common.exception.ObjectNotFoundException;
import mil.jmlfdc.common.rest.RestApiBase;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.QueryParam;

import java.util.List;

@Api(value = "DueInRestApi", description = "Due-In Rest Api")
@ApplicationScoped
public class DueInRestApi extends RestApiBase implements IDueInService {

    @Inject
    private DueInManager manager;

    @Override
    public TestData getPing() {
        return manager.getPing();
    }

    @Override
    public List<DueIn> getAllDueIns() {
        return manager.getAllDueIns();
    }

    @Override
    public List<DueIn> getAllOpenDueIns() {
        return manager.getAllOpenDueIns();
    }

    @Override
    public List<DueIn> getAllClosedDueIns(){
        return manager.getAllClosedDueIns();
    }

    @Override
    public List<DueIn> getAllOpenDueInsSearch(@QueryParam("searchText") String searchText) {
        return manager.getAllOpenDueInsSearch(searchText);
    }

    @Override
    public List<DueIn> getDueInsByOrderId(@QueryParam("orderId") String orderId) {
        return manager.getDueInsByOrderId(orderId);
    }



    @Override
    public List<DueIn> getDueInsByOwnerOrgNodeId( @QueryParam("ownerOrgNodeId") String ownerOrgNodeId) {
        return manager.getDueInsByOwnerOrgNodeId(ownerOrgNodeId);
    }

    @Override
    public List<DueIn> getDueInsByBuyerId(@QueryParam("buyerId") String buyerId) {
        return manager.getDueInsByBuyerId(buyerId);
    }



    @Override
    public DueIn addDueIn(DueIn dueIn) throws ObjectNotFoundException {
        return manager.addDueIn(dueIn);
    }

    @Override
    public DueIn updateDueInBalanceQty(@QueryParam("dueInId") String dueInId, @QueryParam("balanceDueQty") Integer balanceDueQty) {
        return manager.updateDueInBalanceQty(dueInId, balanceDueQty);
    }


    @Override
    public DueIn changeDueInQuantity(@QueryParam("dueInId") String dueInId, @QueryParam("changeQty") Integer changeQty) {
        return manager.changeDueInQuantity(dueInId, changeQty);
    }

    @Override
    public DueIn updateReceivedQuantity(@QueryParam("dueInId") String dueInId, @QueryParam("quantity")  Integer quantity){
        return manager.updateReceivedQuantity(dueInId,quantity);
    }

    @Override
    public DueIn changeDueInPrice(@QueryParam("dueInId") String dueInId, @QueryParam("price") Float price) {
        return manager.changeDueInPrice(dueInId, price);
    }

    @Override
    public DueIn getDueInById(@QueryParam("dueInId") String dueInId) {
        return manager.getDueInById(dueInId);
    }

    @Override
    public DueIn saveDueIn(DueIn dueIn) throws ObjectNotFoundException {
        return manager.saveDueIn(dueIn);
    }

    @Override
    public Integer acceptOrder(Order order) throws ObjectNotFoundException {
        return manager.acceptOrder(order);
    }

}

