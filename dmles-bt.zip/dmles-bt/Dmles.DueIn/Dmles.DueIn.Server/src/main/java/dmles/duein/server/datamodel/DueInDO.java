package dmles.duein.server.datamodel;

import mil.jmlfdc.common.datamodel.MorphiaEntity;

import org.mongodb.morphia.annotations.Embedded;
import org.mongodb.morphia.annotations.Entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Entity(value = "DueIn", noClassnameStored = true)
public class DueInDO extends MorphiaEntity implements Serializable {


    @Embedded
    private List<DueInStatusDO> status = new ArrayList<>();

    private static final long serialVersionUId = 1L;

    private String itemId;
    private String vendorItemNum;
    private String itemDescription;
    private String documentNum;
    private String packCode;
    private Float packQty;
    private Integer orderQty;
    private Integer balanceDueQty;
    private Integer increaseQty;
    private Integer cancelQty;
    private Integer receivedQty;
    private Integer reversedQty;
    private Integer shipQty;
    private Float itemPrice;
    private Float itemSurchargeAmount;
    private Integer orderLineNum;
    private String fundId;
    private String sellerId;
    private String sellerName;
    private String buyerId;
    private String buyerName;
    private Integer fiscalYearObligated;
    private String refundCode;
    private String orderId;
    private String orderDocNumber;
    private String orderCallNum;
    private String orderContractNum;
    private String DeliveryTypeCode;
    private String submissionStatus;
    private Date createdDate;
    private String createdBy;
    private Date updatedDate;
    private String updatedBy;
    private String ownerOrgNodeId;
    private String ownerOrgNodeName;

    public List<DueInStatusDO> getStatus() {
        return status;
    }

    public void setStatus(List<DueInStatusDO> status) {
        this.status = status;
    }

    public String getItemId() {
        return itemId;
    }

    public void setItemId(String itemId) {
        this.itemId = itemId;
    }

    public String getVendorItemNum() {
        return vendorItemNum;
    }

    public void setVendorItemNum(String vendorItemNum) {
        this.vendorItemNum = vendorItemNum;
    }

    public String getItemDescription() {
        return itemDescription;
    }

    public void setItemDescription(String itemDescription) {
        this.itemDescription = itemDescription;
    }

    public String getDocumentNum() {
        return documentNum;
    }

    public void setDocumentNum(String documentNum) {
        this.documentNum = documentNum;
    }

    public String getPackCode() {
        return packCode;
    }

    public void setPackCode(String packCode) {
        this.packCode = packCode;
    }

    public Float getPackQty() {
        return packQty;
    }

    public void setPackQty(Float packQty) {
        this.packQty = packQty;
    }

    public Integer getOrderQty() {
        return orderQty;
    }

    public void setOrderQty(Integer orderQty) {
        this.orderQty = orderQty;
    }

    public Integer getBalanceDueQty() {
        return balanceDueQty;
    }

    public void setBalanceDueQty(Integer balanceDueQty) {
        this.balanceDueQty = balanceDueQty;
    }

    public Integer getIncreaseQty() {
        return increaseQty;
    }

    public void setIncreaseQty(Integer increaseQty) {
        this.increaseQty = increaseQty;
    }

    public Integer getCancelQty() {
        return cancelQty;
    }

    public void setCancelQty(Integer cancelQty) {
        this.cancelQty = cancelQty;
    }

    public Integer getReceivedQty() {
        return receivedQty;
    }

    public void setReceivedQty(Integer receivedQty) {
        this.receivedQty = receivedQty;
    }

    public Integer getReversedQty() {
        return reversedQty;
    }

    public void setReversedQty(Integer reversedQty) {
        this.reversedQty = reversedQty;
    }

    public Integer getShipQty() {
        return shipQty;
    }

    public void setShipQty(Integer shipQty) {
        this.shipQty = shipQty;
    }

    public Float getItemPrice() {
        return itemPrice;
    }

    public void setItemPrice(Float itemPrice) {
        this.itemPrice = itemPrice;
    }

    public Float getItemSurchargeAmount() {
        return itemSurchargeAmount;
    }

    public void setItemSurchargeAmount(Float itemSurchargeAmount) {
        this.itemSurchargeAmount = itemSurchargeAmount;
    }

    public Integer getOrderLineNum() {
        return orderLineNum;
    }

    public void setOrderLineNum(Integer orderLineNum) {
        this.orderLineNum = orderLineNum;
    }

    public String getFundId() {
        return fundId;
    }
    
    public void setFundId(String fundId) {
        this.fundId = fundId;
    }

    public String getSellerId() {
        return sellerId;
    }

    public void setSellerId(String sellerId) {
        this.sellerId = sellerId;
    }

    public String getSellerName() {
        return sellerName;
    }

    public void setSellerName(String sellerName) {
        this.sellerName = sellerName;
    }

    public String getBuyerId() {
        return buyerId;
    }

    public void setBuyerId(String buyerId) {
        this.buyerId = buyerId;
    }

    public String getBuyerName() {
        return buyerName;
    }

    public void setBuyerName(String buyerName) {
        this.buyerName = buyerName;
    }

    public Integer getFiscalYearObligated() {
        return fiscalYearObligated;
    }

    public void setFiscalYearObligated(Integer fiscalYearObligated) {
        this.fiscalYearObligated = fiscalYearObligated;
    }

    public String getRefundCode() {
        return refundCode;
    }

    public void setRefundCode(String refundCode) {
        this.refundCode = refundCode;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getOrderDocNumber() {
        return orderDocNumber;
    }

    public void setOrderDocNumber(String orderDocNumber) {
        this.orderDocNumber = orderDocNumber;
    }

    public String getOrderCallNum() {
        return orderCallNum;
    }

    public void setOrderCallNum(String orderCallNum) {
        this.orderCallNum = orderCallNum;
    }

    public String getOrderContractNum() {
        return orderContractNum;
    }

    public void setOrderContractNum(String orderContractNum) {
        this.orderContractNum = orderContractNum;
    }

    public String getDeliveryTypeCode() {
        return DeliveryTypeCode;
    }

    public void setDeliveryTypeCode(String deliveryTypeCode) {
        DeliveryTypeCode = deliveryTypeCode;
    }

    public String getSubmissionStatus() {
        return submissionStatus;
    }

    public void setSubmissionStatus(String submissionStatus) {
        this.submissionStatus = submissionStatus;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public String getOwnerOrgNodeId() {
        return ownerOrgNodeId;
    }

    public void setOwnerOrgNodeId(String ownerOrgNodeId) {
        this.ownerOrgNodeId = ownerOrgNodeId;
    }

    public String getOwnerOrgNodeName() {
        return ownerOrgNodeName;
    }

    public void setOwnerOrgNodeName(String ownerOrgNodeName) {
        this.ownerOrgNodeName = ownerOrgNodeName;
    }
}
