package dmles.assetmanagement.core.datamodels;

public class AssetType {
    public String assetTypeId;
    public String assetTypeName;
}
