package dmles.assetmanagement.core;

import dmles.assetmanagement.core.datamodels.RiskFactor;
import dmles.assetmanagement.core.datamodels.AssetRecord;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import java.util.List;

@Path("/V1/AssetManagement")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)

public interface IAssetManagementService {

    @GET
    @Path("/getRiskFactors")
    public List<RiskFactor> getRiskFactors();

    @GET
    @Path("/getMedicalEquipmentAssets")
    public List<AssetRecord> getMedicalEquipmentAssets();

    @GET
    @Path("/getRealPropertyInstalledAssets")
    public List<AssetRecord> getRealPropertyInstalledAssets();

}