package dmles.assetmanagement.core;

import dmles.assetmanagement.core.datamodels.TestData;
import dmles.assetmanagement.core.datamodels.FM.RiskFactor;
import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/V1/AssetManagement")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)

public interface IAssetManagementService {
    @GET
    @Path("/getPing")
    public TestData getPing();
    
    @GET
    @Path("/getRiskFactors")
    public List<RiskFactor> getRiskFactors();
}