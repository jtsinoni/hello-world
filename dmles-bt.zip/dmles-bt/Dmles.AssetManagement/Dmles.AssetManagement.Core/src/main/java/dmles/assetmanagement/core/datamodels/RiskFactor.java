package dmles.assetmanagement.core.datamodels;

public class RiskFactor {
    public String riskFactor;
    public String siteDoDDAC;
    public String isCentrallyManaged;
    
}