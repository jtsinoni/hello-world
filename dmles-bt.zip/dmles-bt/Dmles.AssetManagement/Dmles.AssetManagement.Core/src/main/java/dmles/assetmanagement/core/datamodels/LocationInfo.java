package dmles.assetmanagement.core.datamodels;

public class LocationInfo {
    public String siteDoDDAC;
}
