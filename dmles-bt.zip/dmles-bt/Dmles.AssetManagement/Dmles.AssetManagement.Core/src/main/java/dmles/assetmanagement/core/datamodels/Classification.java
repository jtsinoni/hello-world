package dmles.assetmanagement.core.datamodels;

public class Classification {
    public String assetTypeName;
}
