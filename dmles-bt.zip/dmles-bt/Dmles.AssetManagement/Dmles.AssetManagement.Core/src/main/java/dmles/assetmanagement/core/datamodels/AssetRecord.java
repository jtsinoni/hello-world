package dmles.assetmanagement.core.datamodels;

import java.util.ArrayList;
import java.util.List;

public class AssetRecord {
    public String id;
    public String name;
    public String siteDoDDAC;
    public LookupCollection assetTypeRef;
   // public List<AssetType> assetType = new ArrayList<>();
    //public List<LocationInfo> locationInfo = new ArrayList<>();
}