package dmles.assetmanagement.core.datamodels.FM;

public class RiskFactor {
    public String riskFactor;
    public String siteDoDDAC;
    public String isCentrallyManaged;
    
}