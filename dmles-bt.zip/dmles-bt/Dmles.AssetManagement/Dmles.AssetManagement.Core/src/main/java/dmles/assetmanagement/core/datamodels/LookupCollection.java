package dmles.assetmanagement.core.datamodels;

public class LookupCollection {
    public String id;
    public String code;
    public String name;
    public String description;
    public Boolean isRetired;
}
