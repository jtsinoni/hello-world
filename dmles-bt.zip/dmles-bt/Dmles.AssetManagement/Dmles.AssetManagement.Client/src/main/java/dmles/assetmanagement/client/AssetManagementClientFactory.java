package dmles.assetmanagement.client;

        import dmles.assetmanagement.core.IAssetManagementService;
        import mil.jmlfdc.common.business.RestClientFactory;
        import javax.enterprise.context.Dependent;

@Dependent
public class AssetManagementClientFactory extends RestClientFactory<IAssetManagementService>{
    public AssetManagementClientFactory(){
        super(IAssetManagementService.class, "Dmles.AssetManagement.Server");
    }
}