package dmles.assetmanagement.server.datamodels;

import mil.jmlfdc.common.datamodel.MorphiaEntity;

public class TestDataDO extends MorphiaEntity{
    private String message;
    private String time;
    
    public String getmessage(){
        return message;
    }
    public void setMessage(String message){
        this.message = message;
    }
    public String getTime(){
        return time;
    }
    
    public void setTime(String Time){
        this.time = time;
    }
}
