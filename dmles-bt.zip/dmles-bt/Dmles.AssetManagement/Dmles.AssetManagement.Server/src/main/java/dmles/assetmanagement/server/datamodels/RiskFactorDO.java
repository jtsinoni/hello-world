package dmles.assetmanagement.server.datamodels;
import mil.jmlfdc.common.datamodel.MorphiaEntity;
import org.mongodb.morphia.annotations.Entity;
@Entity("RiskFactor")
public class RiskFactorDO extends MorphiaEntity {
    public String riskFactor;
    public String siteDoDDAC;
    public String isCentrallyManaged;
    
    public String getRiskFactor(){
        return riskFactor;
    }
     public RiskFactorDO() {
    }
    
    public void setRiskFactor(String riskFactor){
        this.riskFactor = riskFactor;
    }
    
    public String getSiteDoDDAC() {
        return siteDoDDAC;
    }

    public void setSiteDoDDAC(String siteDoDDAC) {
        this.siteDoDDAC = siteDoDDAC;
    }
    
    public String getIsCentrallyManaged() {
        return isCentrallyManaged;
    }
    
    public void setIsCentrallyManaged(String isCentrallyManaged) {
        this.isCentrallyManaged = isCentrallyManaged;
    }
}