package dmles.assetmanagement.server.datamodels;

import java.io.Serializable;
import org.mongodb.morphia.annotations.Embedded;

@Embedded
public class ClassificationDO implements Serializable{
    private String assetTypeName;
    
    public String getAssetTypeName(){
        return assetTypeName;
    }
    
    public void setAssetTypeName(String assetTypeName){
        this.assetTypeName = assetTypeName;
    }
}
