package dmles.assetmanagement.server.business;

import dmles.assetmanagement.core.datamodels.FM.RiskFactor;
import dmles.assetmanagement.server.dao.FM.RiskFactorDao;
import dmles.assetmanagement.server.datamodels.FM.RiskFactorDO;

import java.util.List;
import javax.ejb.Stateless;
import javax.inject.Inject;
//import javax.enterprise.context.ApplicationScoped;
import mil.jmlfdc.common.business.BusinessManager;
import mil.jmlfdc.common.utils.ObjectMapper;

@Stateless
public class AssetManager extends BusinessManager{
    @Inject
    private ObjectMapper objectMapper;

    @Inject
    private RiskFactorDao riskFactorDao;

    public List<RiskFactor> getRiskFactors(){
       List<RiskFactorDO> riskFactorDos = riskFactorDao.getRiskFactors();
       List<RiskFactor> riskFactors = objectMapper.getList(RiskFactor[].class, riskFactorDos);
       return riskFactors;
    }    
}
