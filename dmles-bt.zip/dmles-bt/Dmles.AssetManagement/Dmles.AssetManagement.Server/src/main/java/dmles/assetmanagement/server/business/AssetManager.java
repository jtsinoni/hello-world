package dmles.assetmanagement.server.business;

import dmles.assetmanagement.core.datamodels.RiskFactor;
import dmles.assetmanagement.server.dao.RiskFactorDao;
import dmles.assetmanagement.server.datamodels.RiskFactorDO;
import dmles.assetmanagement.core.datamodels.AssetRecord;
import dmles.assetmanagement.server.dao.AssetRecordDao;
import dmles.assetmanagement.server.datamodels.AssetRecordDO;
import mil.jmlfdc.common.business.BusinessManager;
import mil.jmlfdc.common.utils.ObjectMapper;

import javax.ejb.Stateless;
import javax.inject.Inject;
import java.util.List;

@Stateless
public class AssetManager extends BusinessManager{
    @Inject
    private ObjectMapper objectMapper;

    @Inject
    private RiskFactorDao riskFactorDao;

    @Inject
    private AssetRecordDao assetRecordDao;

    public List<RiskFactor> getRiskFactors(){
       List<RiskFactorDO> riskFactorDos = riskFactorDao.getRiskFactors();
       List<RiskFactor> riskFactors = objectMapper.getList(RiskFactor[].class, riskFactorDos);
        return riskFactors;
    }

    public List<AssetRecord> getMedicalEquipmentAssets(){
        List<AssetRecordDO> assetRecordDos = assetRecordDao.getMedicalEquipmentAssets();
        List<AssetRecord> assetRecords = objectMapper.getList(AssetRecord[].class,assetRecordDos);
        return assetRecords;
    }

    public List<AssetRecord> getRealPropertyInstalledAssets(){
        List<AssetRecordDO> assetRecordDos = assetRecordDao.getRealPropertyInstalledAssets();
        List<AssetRecord> assetRecords = objectMapper.getList(AssetRecord[].class,assetRecordDos);
        return assetRecords;
    }
}

