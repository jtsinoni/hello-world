package dmles.assetmanagement.server.dao;

import dmles.assetmanagement.server.datamodels.TestDataDO;
import mil.jmlfdc.common.dao.BaseDao;

import java.text.DateFormat;
import java.util.Date;
import javax.enterprise.context.Dependent;

@Dependent
public class TestDao extends BaseDao<TestDataDO, String>{

    public TestDao(){
        super (TestDataDO.class);
    }

    public TestDataDO getTestData(){
        TestDataDO test = new TestDataDO();
        test.setMessage("Ping!");
        DateFormat timeFormatter = DateFormat.getTimeInstance();
        test.setTime(timeFormatter.format(new Date()));
        return test;   
    }
}
