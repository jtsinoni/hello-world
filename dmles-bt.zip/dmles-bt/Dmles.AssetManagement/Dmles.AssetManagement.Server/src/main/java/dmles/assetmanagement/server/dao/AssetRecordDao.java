package dmles.assetmanagement.server.dao;

import dmles.assetmanagement.server.datamodels.AssetRecordDO;

import java.util.List;
import mil.jmlfdc.common.dao.BaseDao;
import javax.enterprise.context.Dependent;
import mil.jmlfdc.common.dao.DataStore;

@Dependent
public class AssetRecordDao extends BaseDao<AssetRecordDO, String> {
    private static final String medicalEquipmentType = "EQUIPMENT";
    private static final String realPropertyInstalledType = "RPIE";

    public AssetRecordDao(){
        super(AssetRecordDO.class);
    }
    public AssetRecordDao(DataStore datastore){
        super(AssetRecordDO.class, datastore);
    }
    public List<AssetRecordDO>getMedicalEquipmentAssets() {
        return this.query(String.format("assetTypeRef.name=%s", medicalEquipmentType));
    }
    public List<AssetRecordDO>getRealPropertyInstalledAssets() {
        return this.query(String.format("assetTypeRef.name=%s", realPropertyInstalledType));
    }
}