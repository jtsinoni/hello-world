package dmles.assetmanagement.server.datamodels;
import dmles.assetmanagement.core.datamodels.LookupCollection;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import mil.jmlfdc.common.datamodel.MorphiaEntity;
import org.mongodb.morphia.annotations.Embedded;
import org.mongodb.morphia.annotations.Entity;
import org.mongodb.morphia.annotations.Id;
import org.mongodb.morphia.annotations.Field;
import org.mongodb.morphia.annotations.Index;
import org.mongodb.morphia.annotations.IndexOptions;
import org.mongodb.morphia.annotations.Indexes;


@Entity(value = "Asset", noClassnameStored = true)
public class AssetRecordDO extends MorphiaEntity implements Serializable {
    @Id
    private String id;
    public String name;
    public String siteDoDDAC;
    private LookupCollection assetTypeRef;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String assetId) {
        this.name = name;
    }

    public String getSiteDoDDAC() {
        return siteDoDDAC;
    }

    public void setSiteDoDDAC(String siteDoDDAC) {
        this.siteDoDDAC = siteDoDDAC;
    }

    public LookupCollection getAssetTypeRef() {
        return assetTypeRef;
    }

    public void setAssetTypeRef(LookupCollection assetTypeRef) {
        this.assetTypeRef = assetTypeRef;
    }
}

