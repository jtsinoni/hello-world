package dmles.assetmanagement.server.rest;

import dmles.assetmanagement.core.IAssetManagementService;
import dmles.assetmanagement.core.datamodels.RiskFactor;
import dmles.assetmanagement.core.datamodels.AssetRecord;
import dmles.assetmanagement.server.business.AssetManager;
import io.swagger.annotations.Api;
import mil.jmlfdc.common.rest.RestApiBase;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.List;

@Api
@ApplicationScoped
public class AssetManagementRestApi extends RestApiBase implements IAssetManagementService {

    @Inject
    private AssetManager assetManager;

    @Override
    public List<RiskFactor> getRiskFactors() {
        return assetManager.getRiskFactors();
    }

    @Override
    public List<AssetRecord> getMedicalEquipmentAssets() {
        return assetManager.getMedicalEquipmentAssets();
    }

    @Override
    public List<AssetRecord> getRealPropertyInstalledAssets() {
        return assetManager.getRealPropertyInstalledAssets();
    }
}