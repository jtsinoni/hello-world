package dmles.assetmanagement.server.rest;

import dmles.assetmanagement.core.IAssetManagementService;
import dmles.assetmanagement.core.datamodels.TestData;
import dmles.assetmanagement.core.datamodels.FM.RiskFactor;
import dmles.assetmanagement.server.business.AssetManager;
import io.swagger.annotations.Api;
import java.text.DateFormat;
import java.util.Date;
import java.util.List;
import javax.ws.rs.core.Context;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;
import mil.jmlfdc.common.exception.InvalidDataException;
import mil.jmlfdc.common.exception.ObjectNotFoundException;
import mil.jmlfdc.common.exception.ValidationException;
import mil.jmlfdc.common.rest.RestApiBase;
import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.context.Dependent;
import javax.inject.Inject;

@Api
@ApplicationScoped
public class AssetManagementRestApi extends RestApiBase implements IAssetManagementService {
   
  @Inject
    private AssetManager assetManager;
    
  @Override
    public TestData getPing() {
        TestData testData = new TestData();
        
        DateFormat timeFormatter = DateFormat.getTimeInstance();
        testData.time = timeFormatter.format(new Date());
        testData.message = "Ping";
        return testData;
  
    }
    @Override
    public List<RiskFactor> getRiskFactors(){
        return assetManager.getRiskFactors();
    } 
    
}
