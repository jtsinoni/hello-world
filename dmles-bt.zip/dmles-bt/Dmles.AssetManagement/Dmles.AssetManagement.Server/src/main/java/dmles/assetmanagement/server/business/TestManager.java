package dmles.assetmanagement.server.business;

import dmles.assetmanagement.core.datamodels.TestData;
import dmles.assetmanagement.server.dao.TestDao;
import dmles.assetmanagement.server.datamodels.TestDataDO;
import mil.jmlfdc.common.datamodel.CurrentUserBT;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import mil.jmlfdc.common.business.BusinessManager;
import mil.jmlfdc.common.utils.ObjectMapper;

@ApplicationScoped
public class TestManager extends BusinessManager{
    @Inject
    private TestDao testDao;

    @Inject
    private ObjectMapper objectMapper;
    
    public TestData getTestData(){
        TestDataDO testDataDo = testDao.getTestData();
        TestData testData = objectMapper.getObject(TestData.class, testDataDo);
        return testData;
    }
}
