package dmles.assetmanagement.server.dao;

import dmles.assetmanagement.server.datamodels.RiskFactorDO;
import java.util.List;
import mil.jmlfdc.common.dao.BaseDao;
import javax.enterprise.context.Dependent;
import mil.jmlfdc.common.dao.DataStore;

@Dependent
public class RiskFactorDao extends BaseDao<RiskFactorDO, String>{
    public RiskFactorDao(){
        super (RiskFactorDO.class);
    }
    public RiskFactorDao(DataStore datastore){
        super(RiskFactorDO.class, datastore);
    }
    public List<RiskFactorDO>getRiskFactors(){
        return super.findAll();

    }
}