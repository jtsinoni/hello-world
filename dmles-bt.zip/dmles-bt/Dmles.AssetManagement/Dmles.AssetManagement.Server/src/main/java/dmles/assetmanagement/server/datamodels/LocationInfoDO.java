package dmles.assetmanagement.server.datamodels;
import java.io.Serializable;
import org.mongodb.morphia.annotations.Embedded;

@Embedded
public class LocationInfoDO implements Serializable {
    public String siteDoDDAC;
    public String installationName;
    public String siteName;

    public String getSiteName() {
        return siteName;
    }

    public void setSiteName(String siteName) {
        this.siteName = siteName;
    }

    public String getInstallationName() {
        return installationName;
    }

    public void setInstallationName(String installationName) {
        this.installationName = installationName;
    }

    public String getSiteDoDDAC(){
        return siteDoDDAC;
    }
    public void setSiteDoDDAC(String siteDoDDAC){
        this.siteDoDDAC = siteDoDDAC;
    }


}