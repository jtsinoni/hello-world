package dmles.elasticprovider.server.business;

import dmles.elasticprovider.core.datamodels.Ping;
import dmles.elasticprovider.server.datamodels.PingDO;
import mil.jmlfdc.common.business.BusinessManager;

import mil.jmlfdc.common.datamodel.CurrentUserBT;

import javax.ejb.Stateless;
import javax.inject.Inject;
import mil.jmlfdc.common.utils.ObjectMapper;
import org.slf4j.Logger;

@Stateless
public class ElasticProviderManager extends BusinessManager {

    @Inject
    private Logger log;

    @Inject
    private ObjectMapper objectMapper;

    public Ping getPing() {
        log.info("Pinged the BT Manager!");
        log.info("User: {}", currentUserBt.getPkiDn());
        PingDO pingDo = new PingDO();
        return objectMapper.getObject(Ping.class, pingDo);
    }
}
