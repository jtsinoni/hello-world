package dmles.elasticprovider.server.datamodels;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.util.Date;
import mil.jmlfdc.common.constants.DateAndTime;
import mil.jmlfdc.common.datamodel.MorphiaEntity;
import org.mongodb.morphia.annotations.Entity;

@Entity("Example")
public class ExampleDO extends MorphiaEntity {

    private String firstName;
    private String lastName;
    private String comment;
    private String userId;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateAndTime.DATE_TIME_PATTERN)
    private Date created = new Date();

    public ExampleDO() {
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

}
