package dmles.elasticprovider.server.rest;

import dmles.elasticprovider.server.business.ElasticProviderManager;
import dmles.elasticprovider.core.IElasticProviderService;
import dmles.elasticprovider.core.datamodels.Ping;
import io.swagger.annotations.Api;

import mil.jmlfdc.common.rest.RestApiBase;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

@Api
@ApplicationScoped
public class ElasticProviderRestApi extends RestApiBase implements IElasticProviderService {

    @Inject
    private ElasticProviderManager catalogManager;

    @Override
    public Ping getPing() {
        return catalogManager.getPing();
    }

}
