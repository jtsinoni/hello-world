package dmles.elasticprovider.server.datamodels;

import java.util.ArrayList;
import mil.jmlfdc.common.utils.MiscUtils;
import org.junit.Test;

public class TestDataModels {

    @Test
    public void getterSetterTest() {
        MiscUtils.getterSetterTest(ExampleDO.class, new ArrayList<>());
        MiscUtils.getterSetterTest(PingDO.class, new ArrayList<>());
    }

}