package dmles.elasticprovider.core;

import dmles.elasticprovider.core.datamodels.Example;
import dmles.elasticprovider.core.datamodels.Ping;
import mil.jmlfdc.common.utils.MiscUtils;

import org.junit.Test;

import java.util.ArrayList;

public class TestDataModels {

    @Test
    public void getterSetterTest() {
        MiscUtils.getterSetterTest(Example.class, new ArrayList<>());
        MiscUtils.getterSetterTest(Ping.class, new ArrayList<>());
    }
}
