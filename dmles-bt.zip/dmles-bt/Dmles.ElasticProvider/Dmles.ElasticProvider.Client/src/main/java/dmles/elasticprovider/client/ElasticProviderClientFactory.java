package dmles.elasticprovider.client;

import dmles.elasticprovider.core.IElasticProviderService;
import mil.jmlfdc.common.business.RestClientFactory;

import javax.enterprise.context.Dependent;

@Dependent
public class ElasticProviderClientFactory extends RestClientFactory<IElasticProviderService> {

    public ElasticProviderClientFactory() {
        super(IElasticProviderService.class, "Dmles.Elastic.Server");
    }
}
