package dmles.buyer.client;

import dmles.buyer.core.IBuyerService;
import mil.jmlfdc.common.business.RestClientFactory;

import javax.enterprise.context.Dependent;

/**
 * Created by gana.sankaralingam on 1/30/2017.
 */
@Dependent
public class BuyerClientFactory extends RestClientFactory <IBuyerService>{
    public BuyerClientFactory() { super(IBuyerService.class, "Dmles.Buyer.Server");}

}
