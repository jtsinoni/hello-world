package dmles.buyer.core.datamodel;

/**
 * Created by gana.sankaralingam on 1/26/2017.
 */
public class TestData {

    public String message;
    public String time;


}

