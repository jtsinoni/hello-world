package dmles.buyer.core.datamodel;

public class Advice {
    public String code;
    public String description;

}
