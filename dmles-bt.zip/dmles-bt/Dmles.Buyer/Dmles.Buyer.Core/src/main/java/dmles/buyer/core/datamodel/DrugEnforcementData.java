package dmles.buyer.core.datamodel;

import java.util.Date;

public class DrugEnforcementData {
    public String registrationNumber;
    public Date startDate;
    public Date endDate;
}
