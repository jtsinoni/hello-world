package dmles.buyer.core.datamodel;

import java.util.Date;

public class DeaData {
    public String registrationNumber;
    public Date startDate;
    public Date endDate;
}
