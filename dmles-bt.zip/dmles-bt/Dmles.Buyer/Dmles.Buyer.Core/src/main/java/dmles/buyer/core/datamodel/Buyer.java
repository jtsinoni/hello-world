package dmles.buyer.core.datamodel;

import mil.jmlfdc.common.datamodel.Address;
import mil.jmlfdc.common.datamodel.Contact;

import java.util.List;

public class Buyer {

    public String id;
    public String name;
    public String ownerOrgNodeId;
    public String ownerOrgNodeName;
    public String description;
    public Address address;
    public String fieldOperatingAgency;
    public List<DrugEnforcementData> drugEnforcementData;
    public String deliveryLocation;
    public String acceptedDocumentType;
    public Boolean transportationNeeded;
    public Contact contact;
    public String itemFulfillmentInstruction;
    public String shippingBillingInfo;
    public Address shippingAddress;
    public Boolean verifyReceipts;
    public Boolean verifyOrders;
    public Float maxOrderLimit;
    public String statusResponse;
    public String supplementAddress;
    public String defaultSubmissionMethod;

}
