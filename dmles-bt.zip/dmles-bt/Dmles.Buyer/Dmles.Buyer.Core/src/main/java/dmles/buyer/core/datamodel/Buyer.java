package dmles.buyer.core.datamodel;

import mil.jmlfdc.common.datamodel.Address;
import java.util.List;

public class Buyer {

    public String id;
    public String buyerId;
    public String buyerName;
    public Address address;
    public String stateService;
    public String materielCurrencyType;
    public float materielConversionFactor;
    public String serviceCurrencyType;
    public float serviceConversionFactor;
    public String fieldOperatingAgency;
    public List<DeaData> deaData;
    public String deliveryLocation;
    public String issueDocument;
    public boolean transportationNeeded;
    public String pocId;
    public String pocFirstName;
    public String pocLastName;
    public Address shipTo;
    public String verifyReceipt;
    public String verifyOrder;
    public String autoDueout;
    public String pvpDirect;
    public String pvmDirect;



}
