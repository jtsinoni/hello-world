package dmles.buyer.core;

import dmles.buyer.core.datamodel.Advice;
import dmles.buyer.core.datamodel.Signal;
import dmles.buyer.core.datamodel.TestData;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import java.util.List;

@Path("/V1/Buyer")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)

public interface IBuyerService {
    @GET
    @Path("/getPing")
    TestData getPing();

    @GET
    @Path("/getAdviceCode")
    List<Advice> getAdviceCode();
    //Advice getAdviceCode();

    @GET
    @Path("/getSignalCode")
    List<Signal> getSignalCode();
}
