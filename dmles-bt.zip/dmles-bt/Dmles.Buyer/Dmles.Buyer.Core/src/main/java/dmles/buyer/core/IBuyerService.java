package dmles.buyer.core;


import dmles.buyer.core.datamodel.Buyer;
import dmles.buyer.core.datamodel.TestData;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.util.List;

@Path("/V1/Buyer")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)

public interface IBuyerService {
    @GET
    @Path("/getPing")
    TestData getPing();



    @GET
    @Path("/getBuyerById")
    Buyer getBuyer(@QueryParam("id") String id);

    @GET
    @Path("/getMyBuyers")
    List<Buyer> getMyBuyers();

    @POST
    @Path("/createBuyer")
    Buyer createBuyer(Buyer buyer);

    @POST
    @Path("/updateBuyer")
    Buyer updateBuyer(Buyer buyer);

}
