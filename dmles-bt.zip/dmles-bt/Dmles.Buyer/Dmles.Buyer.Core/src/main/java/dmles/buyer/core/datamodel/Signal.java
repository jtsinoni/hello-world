package dmles.buyer.core.datamodel;

public class Signal {
    public String code;
    public String description;
}
