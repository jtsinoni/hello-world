package dmles.buyer.server.datamodel;

import mil.jmlfdc.common.datamodel.MorphiaEntity;
import org.mongodb.morphia.annotations.Entity;

import java.io.Serializable;

@Entity("Advice")
public class AdviceDO extends MorphiaEntity implements Serializable {

    private static final long serialVersionUID = 1L;
    private String code;
    private String description;

    public String getCode() {
        return code;
    }

    public void setCode(String Code) {
        code = Code;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String Descr) {
        description = Descr;
    }



}
