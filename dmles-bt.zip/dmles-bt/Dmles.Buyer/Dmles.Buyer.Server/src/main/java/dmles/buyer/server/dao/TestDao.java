package dmles.buyer.server.dao;

import dmles.buyer.server.datamodel.TestDataDO;
import mil.jmlfdc.common.dao.BaseDao;

import javax.enterprise.context.Dependent;
import java.text.DateFormat;
import java.util.Date;

@Dependent
public class TestDao extends BaseDao<TestDataDO, String> {

    public TestDao() {
        super(TestDataDO.class);
    }

    public TestDataDO getTestData() {
        TestDataDO test = new TestDataDO();
        test.setMessage("Ping");
        DateFormat timeFormatter = DateFormat.getTimeInstance();
        test.setTime(timeFormatter.format(new Date()));
        return test;
    }
}
