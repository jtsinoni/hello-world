package dmles.buyer.server.dao;

import dmles.buyer.server.datamodel.AdviceDO;
import mil.jmlfdc.common.dao.BaseDao;

import javax.enterprise.context.Dependent;

@Dependent
public class AdviceDao extends BaseDao<AdviceDO, String> {

    public AdviceDao() {super(AdviceDO.class); }

//    public List<AdviceDO> getAdviceCode() {
//        return super.findAll();
//    }
//
//     public List<AdviceDO> findCodeAndText() {
//
//        List<AdviceDO> adviceList = (List<AdviceDO>) this.getDatastore().createQuery(AdviceDO.class)
//                .retrievedFields(true, "code","description")
//                .asList();
//        return adviceList;
//    }

}
