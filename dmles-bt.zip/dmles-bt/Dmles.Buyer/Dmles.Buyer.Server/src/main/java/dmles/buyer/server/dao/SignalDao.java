package dmles.buyer.server.dao;

import dmles.buyer.server.datamodel.SignalDO;
import mil.jmlfdc.common.dao.BaseDao;

import javax.enterprise.context.Dependent;

@Dependent
public class SignalDao extends BaseDao<SignalDO, String> {
    public SignalDao() {
        super(SignalDO.class);
    }

//    public List<SignalDO> getSignalCode() {
//        return super.findAll();
//    }

//    public List<SignalDO> findCodeAndText() {
//
//        List<SignalDO> signalList = (List<SignalDO>) this.getDatastore().createQuery(SignalDO.class)
//                .project("code", true).project("description",true)
//                //.retrievedFields(true, "code","description")
//                .asList();
//        return signalList;
//    }
}
