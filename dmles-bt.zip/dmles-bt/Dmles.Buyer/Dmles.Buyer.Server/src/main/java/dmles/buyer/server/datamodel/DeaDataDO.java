package dmles.buyer.server.datamodel;

import mil.jmlfdc.common.datamodel.MorphiaEntity;
import org.mongodb.morphia.annotations.Entity;

import java.io.Serializable;
import java.util.Date;

@Entity("DeaData")
public class DeaDataDO extends MorphiaEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    private String registrationNumber;
    private Date startDate;

    public String getRegistrationNumber() {
        return registrationNumber;
    }

    public void setRegistrationNumber(String registrationNumber) {
        this.registrationNumber = registrationNumber;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    private Date endDate;
}
