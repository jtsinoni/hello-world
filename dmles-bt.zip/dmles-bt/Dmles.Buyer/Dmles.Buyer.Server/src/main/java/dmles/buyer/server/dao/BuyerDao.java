package dmles.buyer.server.dao;

import dmles.buyer.server.datamodel.BuyerDO;
import mil.jmlfdc.common.dao.BaseDao;
import mil.jmlfdc.common.dao.DataStore;

import javax.enterprise.context.Dependent;

@Dependent
public class BuyerDao extends BaseDao<BuyerDO,String> {

    public BuyerDao(){
        super(BuyerDO.class);
    }
    public BuyerDao(DataStore dataStore){
        super(BuyerDO.class,dataStore);
    }
}
