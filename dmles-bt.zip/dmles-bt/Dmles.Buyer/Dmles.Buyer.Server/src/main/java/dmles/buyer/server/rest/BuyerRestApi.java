package dmles.buyer.server.rest;

import dmles.buyer.core.IBuyerService;
import dmles.buyer.core.datamodel.Advice;
import dmles.buyer.core.datamodel.Signal;
import dmles.buyer.core.datamodel.TestData;
import dmles.buyer.server.business.BuyerManager;
import io.swagger.annotations.Api;
import mil.jmlfdc.common.rest.RestApiBase;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.List;

@Api(value = "BuyerRestApi", description = "Buyer Rest Api")
@ApplicationScoped
public class BuyerRestApi extends RestApiBase implements IBuyerService {

    @Inject
    private BuyerManager buyerManager;

    @Override
    public TestData getPing() {return buyerManager.getPing();}

    @Override
    public List<Advice> getAdviceCode (){return buyerManager.getAdviceCode();}


    @Override
    public List<Signal> getSignalCode (){return buyerManager.getSignalCode();}

}



