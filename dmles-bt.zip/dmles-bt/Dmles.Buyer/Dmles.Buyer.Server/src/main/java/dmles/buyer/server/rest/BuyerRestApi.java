package dmles.buyer.server.rest;

import dmles.buyer.core.IBuyerService;

import dmles.buyer.core.datamodel.Buyer;


import dmles.buyer.core.datamodel.TestData;
import dmles.buyer.server.business.BuyerManager;
import io.swagger.annotations.Api;
import mil.jmlfdc.common.rest.RestApiBase;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

import javax.ws.rs.QueryParam;
import java.util.List;

@Api
@ApplicationScoped
public class BuyerRestApi extends RestApiBase implements IBuyerService {

    @Inject
    private BuyerManager buyerManager;

    @Override
    public TestData getPing() {
        return buyerManager.getTestData();
    }


    @Override
    public List<Buyer> getMyBuyers() {
        return buyerManager.getMyBuyers();
    }

    @Override
    public Buyer createBuyer(Buyer buyer) {
        Buyer created = buyerManager.createBuyer(buyer);
        return created;

    }

    @Override
    public Buyer getBuyer(@QueryParam("id") String id) {
        return buyerManager.getBuyer(id);
    }

    ;

    @Override
    public Buyer updateBuyer(Buyer buyer) {
        Buyer updated = buyerManager.updateBuyer(buyer);
        return updated;
    }
}


