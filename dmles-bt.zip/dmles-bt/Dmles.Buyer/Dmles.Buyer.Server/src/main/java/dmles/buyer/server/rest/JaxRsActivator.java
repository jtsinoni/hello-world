package dmles.buyer.server.rest;

import dmles.common.rest.JaxRsModuleApplication;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.ApplicationPath;

@ApplicationPath("/")
@ApplicationScoped
public class JaxRsActivator extends JaxRsModuleApplication {

    public JaxRsActivator() {
        super("Buyer");

        moduleResources.add(BuyerRestApi.class);
    }

}
