package dmles.buyer.server.business;

import dmles.buyer.core.datamodel.Advice;
import dmles.buyer.core.datamodel.Signal;
import dmles.buyer.core.datamodel.TestData;
import dmles.buyer.server.dao.AdviceDao;
import dmles.buyer.server.dao.SignalDao;
import dmles.buyer.server.datamodel.AdviceDO;
import dmles.buyer.server.datamodel.SignalDO;
import dmles.buyer.server.datamodel.TestDataDO;
import mil.jmlfdc.common.business.BusinessManager;
import mil.jmlfdc.common.utils.ObjectMapper;
import org.slf4j.Logger;

import javax.ejb.Stateless;
import javax.inject.Inject;
import java.util.Date;
import java.util.List;

@Stateless
public class BuyerManager extends BusinessManager{

    @Inject
    private Logger log;

    @Inject
    private ObjectMapper objectMapper;

    @Inject
    private AdviceDao adviceDao;

    @Inject
    private SignalDao signalDao;

    public TestData getPing(){
        log.info("Pinged the BT Manager!");
        log.info("User: {}", currentUserBt.getPkiDn());
        TestDataDO pingDo = new TestDataDO();
        pingDo.setMessage("Test");
        Long currTime = new Date().getTime();
        pingDo.setTime(currTime.toString());
        return objectMapper.getObject(TestData.class, pingDo);
    }

    public List<Advice> getAdviceCode() {

        List<AdviceDO> adviceDos = adviceDao.findAll();
        List<Advice> adviceCds = objectMapper.getList(Advice[].class, adviceDos);

        return adviceCds;
    }


    public List<Signal> getSignalCode() {

        List<SignalDO> signalDos = signalDao.findAll();
        List<Signal> signalCds = objectMapper.getList(Signal[].class, signalDos);

        return signalCds;
    }

    /* public Advice updateAdvice(Advice advice) throws ObjectNotFoundException {
        AdviceDO toAdvice = objectMapper.getObject(AdviceDO.class, advice);
        AdviceDO adviceSave = adviceDao.upsert(toAdvice);
        Advice adviceRet = objectMapper.getObject(Advice.class, adviceSave);
        return adviceRet;
    }*/

   /* public Advice insertAdvice(Advice advice) throws ObjectNotFoundException {
        AdviceDO toAdvice = objectMapper.getObject(AdviceDO.class, advice);
        AdviceDO adviceSave = adviceDao.upsert(toAdvice);
        Advice adviceRet = objectMapper.getObject(Advice.class, adviceSave);
        return adviceRet;
    }*/

   /* public Integer deleteAdvice(Advice advice, String sCode) throws ObjectNotFoundException {
        AdviceDO toAdvice = objectMapper.getObject(AdviceDO.class, advice);
        AdviceDO adviceDel = adviceDao.deleteById(sCode);
        //AdviceDO adviceSave = adviceDao.delete(toAdvice);
        Advice adviceRet = objectMapper.getObject(Advice.class, adviceDel);
        return adviceRet;
    }*/

}
