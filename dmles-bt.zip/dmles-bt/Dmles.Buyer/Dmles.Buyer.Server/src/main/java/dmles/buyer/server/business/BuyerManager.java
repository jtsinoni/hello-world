package dmles.buyer.server.business;


import dmles.buyer.core.datamodel.Buyer;
import dmles.buyer.core.datamodel.TestData;
import dmles.buyer.server.dao.BuyerDao;
import dmles.buyer.server.dao.TestDao;
import dmles.buyer.server.datamodel.BuyerDO;
import dmles.buyer.server.datamodel.TestDataDO;
import mil.jmlfdc.common.business.BusinessManager;
import mil.jmlfdc.common.utils.ObjectMapper;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.QueryParam;
import java.util.Date;
import java.util.List;

@ApplicationScoped
public class BuyerManager extends BusinessManager {


    @Inject
    private TestDao testDao;


    @Inject
    private BuyerDao buyerDao;

    @Inject
    private ObjectMapper objectMapper;


    public TestData getTestData() {
        TestDataDO testDataDo = testDao.getTestData();
        TestData testData = objectMapper.getObject(TestData.class, testDataDo);
        return testData;
    }



    public TestData getPing() {
            TestDataDO pingDo = new TestDataDO();
        pingDo.setMessage("Test");
        Long currTime = new Date().getTime();
        pingDo.setTime(currTime.toString());
        return objectMapper.getObject(TestData.class, pingDo);

    }
    public List<Buyer> getMyBuyers() {
        List<BuyerDO> buyers = buyerDao.findAll();
        List<Buyer> Buyers = objectMapper.getList(Buyer[].class, buyers);
        return Buyers;
    }
    public Buyer getBuyer(@QueryParam("id") String id){
        BuyerDO buyerDo = buyerDao.findById(id);
        Buyer buyer = objectMapper.getObject(Buyer.class,buyerDo);
        return buyer;
    }
    public Buyer createBuyer(Buyer buyer) {
        BuyerDO toPersist = objectMapper.getObject(BuyerDO.class, buyer);
        BuyerDO persisted = buyerDao.upsert(toPersist);
        Buyer returnObj = objectMapper.getObject(Buyer.class, persisted);
        return returnObj;
    }

    public Buyer updateBuyer(Buyer buyer) {
        BuyerDO toPersist = objectMapper.getObject(BuyerDO.class, buyer);
        BuyerDO persisted = buyerDao.upsert(toPersist);
        Buyer returnObj = objectMapper.getObject(Buyer.class, persisted);
        return returnObj;
    }

}

