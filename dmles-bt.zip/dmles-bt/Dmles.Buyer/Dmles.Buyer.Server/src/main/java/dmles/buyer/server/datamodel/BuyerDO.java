package dmles.buyer.server.datamodel;

import dmles.buyer.core.datamodel.DrugEnforcementData;
import mil.jmlfdc.common.datamodel.Address;
import mil.jmlfdc.common.datamodel.Contact;
import mil.jmlfdc.common.datamodel.MorphiaEntity;
import org.mongodb.morphia.annotations.Entity;

import java.io.Serializable;
import java.util.List;


@Entity(value = "Buyer", noClassnameStored = true)
public class BuyerDO extends MorphiaEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    private String name;
    private String description;
    private String ownerOrgNodeId;
    private String ownerOrgNodeName;
    private Address address;
    private String fieldOperatingAgency;
    private List<DrugEnforcementData> drugEnforcementData;
    private String deliveryLocation;
    private String acceptedDocumentType;
    private Boolean transportationNeeded;
    private Contact contact;
    private String itemFulfillmentInstruction;
    private String shippingBillingInfo;
    private Address shippingAddress;
    private Boolean verifyReceipts;
    private Boolean verifyOrders;
    private Float maxOrderLimit;
    private String statusResponse;
    private String supplementAddress;
    private String defaultSubmissionMethod;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getOwnerOrgNodeId() {
        return ownerOrgNodeId;
    }

    public void setOwnerOrgNodeId(String ownerOrgNodeId) {
        this.ownerOrgNodeId = ownerOrgNodeId;
    }

    public String getOwnerOrgNodeName() {
        return ownerOrgNodeName;
    }

    public void setOwnerOrgNodeName(String ownerOrgNodeName) {
        this.ownerOrgNodeName = ownerOrgNodeName;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public String getFieldOperatingAgency() {
        return fieldOperatingAgency;
    }

    public void setFieldOperatingAgency(String fieldOperatingAgency) {
        this.fieldOperatingAgency = fieldOperatingAgency;
    }

    public List<DrugEnforcementData> getDrugEnforcementData() {
        return drugEnforcementData;
    }

    public void setDrugEnforcementData(List<DrugEnforcementData> drugEnforcementData) {
        this.drugEnforcementData = drugEnforcementData;
    }

    public String getDeliveryLocation() {
        return deliveryLocation;
    }

    public void setDeliveryLocation(String deliveryLocation) {
        this.deliveryLocation = deliveryLocation;
    }

    public String getAcceptedDocumentType() {
        return acceptedDocumentType;
    }

    public void setAcceptedDocumentType(String acceptedDocumentType) {
        this.acceptedDocumentType = acceptedDocumentType;
    }

    public Boolean isTransportationNeeded() {
        return transportationNeeded;
    }

    public void setTransportationNeeded(Boolean transportationNeeded) {
        this.transportationNeeded = transportationNeeded;
    }

    public Contact getContact() {
        return contact;
    }

    public void setContact(Contact contact) {
        this.contact = contact;
    }

    public String getItemFulfillmentInstruction() {
        return itemFulfillmentInstruction;
    }

    public void setItemFulfillmentInstruction(String itemFulfillmentInstruction) {
        this.itemFulfillmentInstruction = itemFulfillmentInstruction;
    }

    public String getShippingBillingInfo() {
        return shippingBillingInfo;
    }

    public void setShippingBillingInfo(String shippingBillingInfo) {
        this.shippingBillingInfo = shippingBillingInfo;
    }

    public Address getShippingAddress() {
        return shippingAddress;
    }

    public void setShippingAddress(Address shippingAddress) {
        this.shippingAddress = shippingAddress;
    }

    public Boolean isVerifyReceipts() {
        return verifyReceipts;
    }


    public void setVerifyReceipts(Boolean verifyReceipts) {
        this.verifyReceipts = verifyReceipts;
    }

    public Boolean isVerifyOrders() {
        return verifyOrders;
    }

    public void setVerifyOrders(Boolean verifyOrders) {
        this.verifyOrders = verifyOrders;
    }

    public Float getMaxOrderLimit() {
        return maxOrderLimit;
    }

    public void setMaxOrderLimit(Float maxOrderLimit) {
        this.maxOrderLimit = maxOrderLimit;
    }

    public String getStatusResponse() {
        return statusResponse;
    }

    public void setStatusResponse(String statusResponse) {
        this.statusResponse = statusResponse;
    }

    public String getSupplementAddress() {
        return supplementAddress;
    }

    public void setSupplementAddress(String supplementAddress) {
        this.supplementAddress = supplementAddress;
    }

    public String getDefaultSubmissionMethod() {
        return defaultSubmissionMethod;
    }

    public void setDefaultSubmissionMethod(String defaultSubmissionMethod) {
        this.defaultSubmissionMethod = defaultSubmissionMethod;
    }
}








