package dmles.buyer.server.datamodel;

import mil.jmlfdc.common.datamodel.AddressDO;
import mil.jmlfdc.common.datamodel.MorphiaEntity;
import org.mongodb.morphia.annotations.Entity;

import java.io.Serializable;
import java.util.List;

@Entity("Buyer")
public class BuyerDO extends MorphiaEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    private String buyerId;
    private String buyerName;
    private AddressDO address;
    private String stateService;
    private String materielCurrencyType;
    private float materielConversionFactor;
    private String serviceCurrencyType;
    private float serviceConversionFactor;
    private String fieldOperatingAgency;
    private List<DeaDataDO> deaData;
    private String deliveryLocation;
    private String issueDocument;
    private Boolean transportationNeeded;

    public String getBuyerId() {
        return buyerId;
    }

    public void setBuyerId(String buyerId) {
        this.buyerId = buyerId;
    }

    public String getBuyerName() {
        return buyerName;
    }

    public void setBuyerName(String buyerName) {
        this.buyerName = buyerName;
    }

    public AddressDO getAddress() {
        return address;
    }

    public void setAddress(AddressDO address) {
        this.address = address;
    }
    public String getStateService() {
        return stateService;
    }

    public void setStateService(String stateService) {
        this.stateService = stateService;
    }

    public String getMaterielCurrencyType() {
        return materielCurrencyType;
    }

    public void setMaterielCurrencyType(String materielCurrencyType) {
        this.materielCurrencyType = materielCurrencyType;
    }

    public float getMaterielConversionFactor() {
        return materielConversionFactor;
    }

    public void setMaterielConversionFactor(float materielConversionFactor) {
        this.materielConversionFactor = materielConversionFactor;
    }

    public String getServiceCurrencyType() {
        return serviceCurrencyType;
    }

    public void setServiceCurrencyType(String serviceCurrencyType) {
        this.serviceCurrencyType = serviceCurrencyType;
    }

    public float getServiceConversionFactor() {
        return serviceConversionFactor;
    }

    public void setServiceConversionFactor(float serviceConversionFactor) {
        this.serviceConversionFactor = serviceConversionFactor;
    }

    public String getFieldOperatingAgency() {
        return fieldOperatingAgency;
    }

    public void setFieldOperatingAgency(String fieldOperatingAgency) {
        this.fieldOperatingAgency = fieldOperatingAgency;
    }

    public List<DeaDataDO> getDeaData() {
        return deaData;
    }

    public void setDeaData(List<DeaDataDO> deaData) {
        this.deaData = deaData;
    }

    public String getDeliveryLocation() {
        return deliveryLocation;
    }

    public void setDeliveryLocation(String deliveryLocation) {
        this.deliveryLocation = deliveryLocation;
    }

    public String getIssueDocument() {
        return issueDocument;
    }

    public void setIssueDocument(String issueDocument) {
        this.issueDocument = issueDocument;
    }

    public boolean getTransportationNeeded() {
        return transportationNeeded;
    }

    public void setTransportationNeeded(Boolean transportationNeeded) {
        this.transportationNeeded = transportationNeeded;
    }





}

