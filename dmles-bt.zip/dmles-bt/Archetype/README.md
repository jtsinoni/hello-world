Contains the customized archetype-metadata.xml and pom.xml.  These files were modified after being generated via the command:
	mvn archetype:create-from-project 

To install the archetype:
	-- mvn archetype:generate -DarchetypeCatalog=local
	or
	-- mvn archetype:generate -DarchetypeCatalog=https://jwsrv116.ad.dmlss.detrick.army.mil/nexus/content/repositories/snapshots
	
	
 Notes:
 	use -DarchetypeCatalog=local if you have installed the archetype locally
 		-- i.e. mvn install

 	use -DarchetypeCatalog=https://jwsrv116.ad.dmlss.detrick.army.mil/nexus/content/repositories/snapshots if the archetype is installed in the nexus