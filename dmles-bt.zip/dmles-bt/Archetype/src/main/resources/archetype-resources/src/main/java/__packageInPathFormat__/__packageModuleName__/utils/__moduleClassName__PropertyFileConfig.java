#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )

package ${package}.${packageModuleName}.utils;

import org.apache.deltaspike.core.api.config.PropertyFileConfig;
import org.apache.deltaspike.core.api.jmx.JmxManaged;
import org.apache.deltaspike.core.api.jmx.MBean;

@MBean(name="${moduleClassName}PropertyFileConfig", 
description = "Exposes ${moduleClassName} FileConfig via Mbeans.",
objectName = "${moduleClassName}PropertyFileConfig:type=PropertyFileConfig")
public class ${moduleClassName}PropertyFileConfig implements PropertyFileConfig {
	
	private static final long serialVersionUID = -7762369573887097591L;
	
	@JmxManaged(description = "Get ${moduleClassName} property file")
    @Override
    public String getPropertyFileName() {
        return "${packageModuleName}.properties"; 
    }

	@Override
	public boolean isOptional() {
		return false;
	}
}