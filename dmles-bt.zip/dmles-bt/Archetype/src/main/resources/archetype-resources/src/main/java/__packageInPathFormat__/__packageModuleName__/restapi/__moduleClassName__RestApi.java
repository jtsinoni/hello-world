#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )

package ${package}.${packageModuleName}.restapi;

import io.swagger.annotations.Api;

import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import ${package}.${packageModuleName}.datamodel.SampleRequest;
import ${package}.${packageModuleName}.business.${moduleClassName}Manager;

@Api
@Path("/Api")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class ${moduleClassName}RestApi {

    @Inject
    private ${moduleClassName}Manager manager;

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/getAllSampleRequests")
    public List<SampleRequest> getAllSampleRequests() {
        return manager.getSampleRequests();
    }
}
