#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )

package ${package}.${packageModuleName};

import ${package}.${packageModuleName}.business.${moduleClassName}Manager;
import ${package}.${packageModuleName}.dao.SampleRequestDao;
import ${package}.${packageModuleName}.datamodel.SampleRequest;

import java.util.ArrayList;
import java.util.List;
import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.when;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.util.ReflectionTestUtils;

/**
 * 
 * To test:
 *   -- cd to root of project i.e. ../dmles-bt
 *   -- mvn clean test -pl ${artifactId}/ -am
 *   -- coverage reports are located at: ../target/site/jacoco-ut/index.html
 */
public class ${moduleClassName}Test {
	private final static Logger logger = LoggerFactory.getLogger(${moduleClassName}Test.class);
	
	@InjectMocks
	private ${moduleClassName}Manager manager;

    @Mock
    private SampleRequestDao dao;

  	@Before
	public void setUp() throws Exception {
        // this must be called for the @Mock annotations above to be processed.
        MockitoAnnotations.initMocks(this);
	}
  	
    @Test
    public void getSampleRequests() {
        List<SampleRequest> sampleRequests = getMockSampleRequests();

        when(manager.getSampleRequests()).thenReturn(sampleRequests);
        assertEquals(sampleRequests, manager.getSampleRequests());
    }	

    /*
	 * setup our mock sample requests
     */
    private List<SampleRequest> getMockSampleRequests() {
        List<SampleRequest> sampleRequests = new ArrayList<SampleRequest>();
        SampleRequest request = new SampleRequest();
        sampleRequests.add(request);

        return sampleRequests;
    }	
}
