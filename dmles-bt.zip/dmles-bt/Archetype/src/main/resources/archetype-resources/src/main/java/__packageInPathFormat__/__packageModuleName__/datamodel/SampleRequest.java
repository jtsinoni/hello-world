#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )

package ${package}.${packageModuleName}.datamodel;

import org.mongodb.morphia.annotations.Entity;
import ${package}.common.datamodel.MorphiaEntity;


@Entity("SampleRequests")
public class SampleRequest extends MorphiaEntity {
}
