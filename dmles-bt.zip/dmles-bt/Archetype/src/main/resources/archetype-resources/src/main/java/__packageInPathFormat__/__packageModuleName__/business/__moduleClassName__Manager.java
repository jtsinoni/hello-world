#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )

package ${package}.${packageModuleName}.business;

import java.util.List;
import javax.ejb.Stateless;
import javax.inject.Inject;
import ${package}.common.business.BusinessManager;
import ${package}.${packageModuleName}.dao.SampleRequestDao;
import ${package}.${packageModuleName}.datamodel.SampleRequest;


@Stateless
public class ${moduleClassName}Manager extends BusinessManager {
	
    @Inject
    SampleRequestDao sampleRequestDao;
    
    public List<SampleRequest> getSampleRequests() {
        return sampleRequestDao.findAll();
    }	

}
