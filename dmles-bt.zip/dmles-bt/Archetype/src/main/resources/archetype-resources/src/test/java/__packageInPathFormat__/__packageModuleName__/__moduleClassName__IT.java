#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )

package ${package}.${packageModuleName};

import ${package}.${packageModuleName}.dao.SampleRequestDao;
import ${package}.${packageModuleName}.datamodel.SampleRequest;

import java.io.File;
import java.net.MalformedURLException;
import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.spec.WebArchive;
import org.jboss.shrinkwrap.resolver.api.maven.Maven;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
/**
 * Couple of notes here.
 * 
 * ShrinkWrap provides the mechanism to create the war file for
 * deployment/runnning in the container With that, you need to tell
 * shrinkwrap which classes you want to include...this can be done at the
 * specific class level or the package level.
 * 
 * Also if you need specific pieces out of the container the MANIFEST.MF
 * needs to be included which calls out explicitly the items you need...for
 * example, if we needed specific CDI injected elements of the infinispan
 * packs we'd need to the following in the manifest file.
 * 
 * Dependencies: org.infinispan export
 * 
 * To test:
 *   -- cd to root of project i.e. ../dmles-bt
 *   -- change jBoss property in ../${artifactId}/pom.xml to your local instance install directory
 *   -- mvn clean verify -pl ${artifactId}/ -am -Pwildfly-managed,integration-test
 *   -- coverage reports are located at: ../target/site/jacoco-it/index.html
 */
@RunWith(Arquillian.class)
public class ${moduleClassName}IT {
	private final static Logger logger = LoggerFactory.getLogger(${moduleClassName}IT.class);
	
    @Inject
    private SampleRequestDao dao;

	private String id;

  	@Before
	public void setUp() throws MalformedURLException {
		logger.info("setUp::Setting up for SampleRequestDao Tests");
	}
  	
	@Deployment(testable = true)
	public static WebArchive createDeployment() {

		File[] pomLibraryFiles = Maven.resolver().loadPomFromFile("pom.xml").importRuntimeDependencies().resolve()
				.withTransitivity().asFile();

		WebArchive warChive = ShrinkWrap.create(WebArchive.class)
					.addAsLibraries(pomLibraryFiles)
					.addPackages(true, "${package}.${packageModuleName}");
		
		File[] resourceFiles = new File("src/main/resources").listFiles();
		if(resourceFiles != null) {
			for (File file : resourceFiles) {
				warChive.addAsResource(file);
			}
		}
		
		File[] manifestResourceFiles = new File("src/main/webapp/META-INF").listFiles();
		if(manifestResourceFiles != null) {
			for (File file : manifestResourceFiles) {
				warChive.addAsManifestResource(file);
			}
		}
		
		File[] webInfFiles = new File("src/main/webapp/WEB-INF").listFiles();
		if(webInfFiles != null) {
			for (File file : webInfFiles) {
				warChive.addAsWebInfResource(file);
			}
		}
		
		File[] webResourceFiles = new File("src/main/webapp").listFiles();
		if(webResourceFiles != null) {
			for (File file : webResourceFiles) {
				if(!file.isDirectory())
					warChive.addAsWebResource(file);
			}
		}
		
		logger.info(warChive.toString(true));
		return warChive;
	}
    
  	@Test
	public void daoNotNull() {
  		logger.info("daoNotNull():: dao is {}", dao);
		Assert.assertNotNull(dao);
	}

	@Test
	public void persistDao() {
		SampleRequest sampleRequestEntity = new SampleRequest();
		dao.upsert(sampleRequestEntity);
		id = sampleRequestEntity.getId();
		
		SampleRequest found = dao.findById(id);
		
		logger.info("persistDao:: sampleRequestEntity id {} to upload", id);
		Assert.assertEquals(id, found.getId());
	}

	@After
	public void cleanUp() {
		if(id != null) {
			logger.info("cleanUp:: removing id {} from database.", id);
			dao.deleteById(id);
		}
	}   
}
