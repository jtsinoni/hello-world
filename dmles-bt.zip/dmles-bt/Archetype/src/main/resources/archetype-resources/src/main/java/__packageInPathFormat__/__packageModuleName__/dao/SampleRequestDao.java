#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )

package ${package}.${packageModuleName}.dao;

import javax.enterprise.context.Dependent;
import ${package}.common.dao.BaseDao;
import ${package}.${packageModuleName}.datamodel.SampleRequest;


@Dependent
public class SampleRequestDao extends BaseDao<SampleRequest, String>{
    
    public SampleRequestDao() {
        super(SampleRequest.class);
    }
}