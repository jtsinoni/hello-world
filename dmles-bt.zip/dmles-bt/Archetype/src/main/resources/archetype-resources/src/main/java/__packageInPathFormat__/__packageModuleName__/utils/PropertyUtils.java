#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
package ${package}.${packageModuleName}.utils;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PropertyUtils {
	private final static Logger logger = LoggerFactory.getLogger(PropertyUtils.class);
	
	private static Properties properties;
	private static PropertyUtils instance = null;

	private PropertyUtils() { }

	public static PropertyUtils getInstance() {
		if (instance == null) {
			instance = new PropertyUtils();
			
			properties = new Properties();
			
			//default property file
			initPropertyFile("config.properties");
		}
		return instance;
	}

	/**
	 * Gets a value from a property file
	 * 
	 * @param key
	 * @return
	 */
	public String getProperty(String key) {
		return properties.getProperty(key);
	}

	public void setPropertyFile(String propertyFile) {
		initPropertyFile(propertyFile);
	}

	private static void initPropertyFile(String propertyFile) {
		InputStream resourceAsStream = PropertyUtils.class.getClassLoader().getResourceAsStream(propertyFile);
		try {
			properties.load(resourceAsStream);
		} catch (IOException e) {
			logger.error(e.getMessage());
		}
	}
}
