package logicole.gateway.services.system;

import logicole.apis.system.IApplicationNotificationMicroserviceApi;
import logicole.common.datamodels.CurrentUserBT;
import logicole.common.datamodels.notification.ApplicationNotification;
import logicole.common.general.logging.Logger;
import logicole.common.general.util.JSONUtil;
import logicole.gateway.common.GatewayManager;

import java.io.IOException;
import java.util.UUID;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

@ApplicationScoped
public class  ApplicationNotificationService extends GatewayManager<IApplicationNotificationMicroserviceApi> {

    public ApplicationNotificationService(){
        super("Notification");
    }

    @Inject
    private CurrentUserBT currentUserBT;
    @Inject
    private JSONUtil jsonUtil;
    @Inject
    private Logger logger;

    public ApplicationNotification addNotification(ApplicationNotification applicationNotification) throws IOException {
        applicationNotification.id = UUID.randomUUID().toString();
        String notificationString = jsonUtil.serialize(applicationNotification);
        logger.info("new Notification received - " + applicationNotification);
        return applicationNotification;
    }
}

