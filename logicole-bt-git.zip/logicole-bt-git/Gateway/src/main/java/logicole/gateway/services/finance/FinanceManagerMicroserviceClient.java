package logicole.gateway.services.finance;

import logicole.apis.finance.IFinanceManagerMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class FinanceManagerMicroserviceClient extends MicroserviceClient<IFinanceManagerMicroserviceApi> {
    public FinanceManagerMicroserviceClient(){
        super(IFinanceManagerMicroserviceApi.class, "logicole-finance");
    }

    @Produces
    public IFinanceManagerMicroserviceApi getMicroserviceApi() {
        return createClient();
    }

}
