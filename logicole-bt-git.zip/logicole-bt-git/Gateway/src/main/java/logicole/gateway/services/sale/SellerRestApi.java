package logicole.gateway.services.sale;

import io.swagger.annotations.Api;
import logicole.common.datamodels.sale.seller.Seller;
import logicole.common.datamodels.user.CurrentUser;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import java.util.List;

@Api(tags = {"seller"})
@ApplicationScoped
@Path("/seller")
public class SellerRestApi extends ExternalRestApi<SellerService> {

    @GET
    @Path("/getCurrentUser")
    public CurrentUser getCurrentUser() {
        return service.getCurrentUser();
    }

    @GET
    @Path("/getMySellerList")
    public List<Seller> getMySellerList() {
        return service.getMySellerList();
    }

    @GET
    @Path("/getSellerById")
    public Seller getSellerById(@QueryParam("Id") String sellerId) {
        return service.getSellerById(sellerId);

    }

    @POST
    @Path("/saveSeller")
    public Seller saveSeller(Seller seller) {
        return service.saveSeller(seller);

    }

    @GET
    @Path("/deleteSeller")
    public Seller deletSeller(@QueryParam("Id") String sellerId) {
        return service.deleteSeller(sellerId);
    }

}
