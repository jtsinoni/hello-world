package logicole.gateway.lock;

import logicole.gateway.security.LogicoleCache;

import java.lang.reflect.Method;
import javax.enterprise.context.ApplicationScoped;
import javax.interceptor.InvocationContext;
import javax.transaction.Transactional;

@ApplicationScoped
public class LockManager extends LogicoleCache<Object> {

    public LockManager() {
        super("/infinispan/cache/lockCacheContainer/lockCache");
    }
    @Transactional
    public void lock(String lockObject) {
        putObjectTransactional(lockObject, lockObject);
    }
    @Transactional
    public void unLock(String lockObject) {
        remove(lockObject);
    }

    public String getLockString(InvocationContext ctx) {
        String retVal = "";
        if (isTransactional(ctx)) {
            Method method = ctx.getMethod();
            String methodName = method.getName();
            Object target = ctx.getTarget();
            String targetName = target.getClass().getSimpleName();
            retVal = targetName + methodName;
        }
        return retVal;
    }

    private boolean isTransactional(InvocationContext ctx) {
        Method method = ctx.getMethod();
        return method.isAnnotationPresent(Transactional.class);
    }
}
