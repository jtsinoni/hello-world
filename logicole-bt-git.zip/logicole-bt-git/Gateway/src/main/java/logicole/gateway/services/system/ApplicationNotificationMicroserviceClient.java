package logicole.gateway.services.system;

import logicole.apis.system.IApplicationNotificationMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class ApplicationNotificationMicroserviceClient extends MicroserviceClient<IApplicationNotificationMicroserviceApi> {
    public ApplicationNotificationMicroserviceClient(){
        super(IApplicationNotificationMicroserviceApi.class, "logicole-finance");
    }

    @Produces
    public IApplicationNotificationMicroserviceApi getMicroserviceApi() {
        return createClient();
    }

}
