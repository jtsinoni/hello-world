package logicole.gateway.services.user;

import logicole.gateway.rest.MicroserviceClient;
import logicole.apis.user.IInvitationMicroserviceApi;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class InvitationMicroserviceClient extends MicroserviceClient<IInvitationMicroserviceApi> {
    public InvitationMicroserviceClient(){
        super(IInvitationMicroserviceApi.class, "user");
    }

    @Produces
    public IInvitationMicroserviceApi getIUserMicroserviceApi() {
        return createClient();
    }

}
