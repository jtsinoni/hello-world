package logicole.gateway.services.sale;

import io.swagger.annotations.Api;
import logicole.common.datamodels.user.CurrentUser;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.Path;

@Api(tags = {"Sale"})
@ApplicationScoped
@Path("/sale")
public class SaleRestApi extends ExternalRestApi<SaleService> {

    @GET
    @Path("/getCurrentUser")
    public CurrentUser getCurrentUser() {
        return service.getCurrentUser();
    }

}
