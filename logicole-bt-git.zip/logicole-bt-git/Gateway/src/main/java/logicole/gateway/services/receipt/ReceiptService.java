package logicole.gateway.services.receipt;

import logicole.common.datamodels.CurrentUserBT;
import logicole.common.datamodels.user.CurrentUser;
import logicole.gateway.common.GatewayManager;
import logicole.apis.receipt.IReceiptMicroserviceApi;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

@ApplicationScoped
public class ReceiptService extends GatewayManager<IReceiptMicroserviceApi> {

    @Inject
    private CurrentUserBT currentUserBT;

    public ReceiptService() {
        super("Receipt");
    }


    public CurrentUser getCurrentUser() {
        CurrentUser currentUser = currentUserBT.getCurrentUser();
        return currentUser;
    }



}
