**REST**

This area contains classes related to REST functionality