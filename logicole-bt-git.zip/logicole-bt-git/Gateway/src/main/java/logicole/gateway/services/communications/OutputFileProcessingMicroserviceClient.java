package logicole.gateway.services.communications;

import logicole.apis.communications.IOutputFileProcessingMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class OutputFileProcessingMicroserviceClient extends MicroserviceClient<IOutputFileProcessingMicroserviceApi> {
    public OutputFileProcessingMicroserviceClient(){
        super(IOutputFileProcessingMicroserviceApi.class, "logicole-communications");
    }

    @Produces
    public IOutputFileProcessingMicroserviceApi getMicroserviceApi() {
        return createClient();
    }

}
