package logicole.gateway.services.organization;

import logicole.common.datamodels.CurrentUserBT;
import logicole.common.datamodels.organization.*;
import logicole.common.datamodels.user.CurrentUser;
import logicole.gateway.common.GatewayManager;
import logicole.apis.organization.IOrganizationMicroserviceApi;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.validation.constraints.NotNull;

@ApplicationScoped
public class OrganizationService extends GatewayManager<IOrganizationMicroserviceApi> {

    @Inject
    private CurrentUserBT currentUserBT;

    public OrganizationService() {
        super("Organization");
    }


    public CurrentUser getCurrentUser() {
        CurrentUser currentUser = currentUserBT.getCurrentUser();
        return currentUser;
    }

    public List<Node> getChildren(@NotNull String parentId) {
        return microservice.getChildren(parentId);
    }

    public Node getParent(String nodeId) {
        return microservice.getParent(nodeId);
    }

    public Node getNode(String nodeGuid) {
        return microservice.getNode(nodeGuid);
    }

    public Node getNodeById(String nodeId) {
        return microservice.getNodeById(nodeId);
    }

    public List<String> getNodeRoleIds(String nodeId) {
        return microservice.getNodeRoleIds(nodeId);
    }

    public NodeTypeRef getNodeTypeRef(String nodeId) {
        return microservice.getNodeTypeRef(nodeId);
    }

    public List<NodeType> getNodeTypes() {
        return microservice.getNodeTypes();
    }


    public List<NodeType> getNodeTypesReduced(String includeRoot) {
        return microservice.getNodeTypesReduced(includeRoot);
    }

    public List<Node> getNodesInScope(ScopeQuery scopeNode) {
//        return microservice.getNodesInScope(scopeNode.nodeTypeId, scopeNode.scopeList);
        return null;
    }

    public List<Node> getScopedNodeList(String startingNodeId) {
        return microservice.getScopedNodeList(startingNodeId);
    }

    public List<String> getScopedNodeIdList(String startingNodeId) {
        return microservice.getScopedNodeIdList(startingNodeId);
    }


    public NodeTree getPublicNodeTree() {
        try {
            NodeTree myNode = microservice.getPublicNodeTree();
        } catch (Exception ex) {
//            logger.info(ex.getMessage());
        }
        return microservice.getPublicNodeTree();
    }

    public NodeTree getScopedNodeTree(String startingNodeId, String endingNodeTypeId) {
        return microservice.getScopedNodeTree(startingNodeId, endingNodeTypeId);
    }

    public List<Node> getScopeUsingAncestry(AncestryQuery ancestryQuery) {
        return microservice.getScopeUsingAncestry(ancestryQuery);
    }


    public List<String> getOrgIdsForNode(String startingNodeId) {
        return microservice.getOrgIdsForNode(startingNodeId);
    }


    public List<ServiceProvider> getServiceProviders() {
        return microservice.getServiceProviders();
    }


    public ServiceProvider getServiceProviderById(String id) {
        return microservice.getServiceProviderById(id);
    }


    public String refreshNodeTree() {
//        microservice.refreshNodeTreeData();
//        return null;
        return "OK";
    }


    public ServiceProvider saveProviderConsumer(ServiceProvider provider) {
        return microservice.saveProviderConsumer(provider);
    }


    public NodeRef getNodeRefById(String id) {
//        return microservice..getNodeRef(id);
        return null;
    }

    public List<NodeRef> determineNodeAccess(String nodeTypeId, List<NodeRef> scopeNodeRefs) {
        List<NodeRef> returnList = new ArrayList<>();

        AncestryQuery ancestryQuery = new AncestryQuery();
        ancestryQuery.nodeTypeId = nodeTypeId;
        ancestryQuery.scopeNodeIds.addAll(scopeNodeRefs.stream().map(NodeRef::getId).collect(Collectors.toList()));

        List<Node> accessToNodes = microservice.getScopeUsingAncestry(ancestryQuery);

        // TODO: This is very inefficient, ObjectMapper list conversion was not working though
        for (Node node : accessToNodes) {
            returnList.add(new NodeRef(node.id, node.name, node.orgId));
        }

        return returnList;
    }

}
