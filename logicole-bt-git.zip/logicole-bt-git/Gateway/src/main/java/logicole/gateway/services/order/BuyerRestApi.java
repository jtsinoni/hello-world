package logicole.gateway.services.order;

import io.swagger.annotations.Api;
import logicole.common.datamodels.order.buyer.Buyer;
import logicole.common.datamodels.order.buyer.BuyerDTO;
import logicole.common.datamodels.user.CurrentUser;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import java.util.List;

@Api(tags = {"Buyer"})
@ApplicationScoped
@Path("/buyer")
public class BuyerRestApi extends ExternalRestApi<BuyerService> {

    @GET
    @Path("/getCurrentUser")
    public CurrentUser getCurrentUser() {
        return service.getCurrentUser();
    }

    @GET
    @Path("/getMyBuyerList")
    public List<BuyerDTO> getMyBuyerList() {
        return service.getMyBuyerList();
    }

    @GET
    @Path("/getBuyerById")
    public BuyerDTO getBuyerById(@QueryParam("Id") String buyerId) {
        return service.getBuyerById(buyerId);

    }


      @POST
    @Path("/saveBuyer")
    public BuyerDTO saveBuyer(BuyerDTO buyerDTO) {
        return service.saveBuyer(buyerDTO);

    }

    @GET
    @Path("/deleteBuyer")
    public BuyerDTO deleteBuyer(@QueryParam("Id") String buyerId) {
        return service.deleteBuyer(buyerId);
    }

}

