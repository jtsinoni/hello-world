package logicole.gateway.security;

import logicole.common.general.exception.InvalidCredentialsException;
import logicole.common.general.logging.Logger;
import logicole.gateway.services.user.CurrentUserManager;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

@ApplicationScoped
public class GatewaySecurity {

    private static final String DN_HEADER = "X-SSL-Client-S-DN";

    @Inject
    private HttpServletRequest request;
    @Inject
    private Logger logger;
    @Inject
    private CurrentUserManager currentUserManager;

    public void verifyRequest() {
        String dnHeader = request.getHeader(DN_HEADER);
        if (dnHeader == null) {
            throw new InvalidCredentialsException("credentials not found or invalid");
        }
        currentUserManager.setCurrentUserForRequest(dnHeader);
    }
}
