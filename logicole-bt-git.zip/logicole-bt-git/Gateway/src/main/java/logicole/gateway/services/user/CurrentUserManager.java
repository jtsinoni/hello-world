package logicole.gateway.services.user;

import logicole.common.datamodels.CurrentUserBT;
import logicole.common.datamodels.user.CurrentUser;
import logicole.gateway.security.CurrentUserCache;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

@ApplicationScoped
public class CurrentUserManager {

    @Inject
    private CurrentUserBT currentUserBT;
    @Inject
    private UserService userService;
    @Inject
    private CurrentUserCache cache;

    public void setCurrentUserForRequest(String userName) {
        CurrentUser currentUser = null;

        if (cache.exists(userName)) {
            currentUser = cache.getObject(userName);
        } else {
            currentUser = userService.getUsersCurrentProfile(userName);
            cache.putObject(userName, currentUser);
        }
        currentUserBT.setCurrentUser(currentUser);
    }
}
