package logicole.gateway;

import logicole.common.datamodels.ref.Refs;
import logicole.common.general.util.IntrospectionUtil;
import logicole.gateway.services.user.UserService;
import org.infinispan.Cache;

import java.util.*;
import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class DataReferenceManager {
    private static final Map<String, Refs.References[]> staticSubscriptions = new HashMap<>();

    static {
        Refs.References[] userRefa = {Refs.References.ROLE, Refs.References.ORG_NODE};
        staticSubscriptions.put(
                IntrospectionUtil.getClassName(UserService.class), userRefa);
    }

    @Resource(name = "dataReferenceSubscriberCache")
    private Cache<String, Object> cache;

    @PostConstruct
    public void postConstruct() {
        for (Map.Entry<String, Refs.References[]>  entry : staticSubscriptions.entrySet()) {
            for (Refs.References ref : entry.getValue()) {
                addSubscription(ref.toString(), entry.getKey());
            }
        }
    }

    List<String> getSubscriptionsFor(String collectionName) {
        List<String> subs;
        if (cache.containsKey(collectionName)) {
            subs = (List<String>) cache.get(collectionName);
        } else {
            subs = new ArrayList<String>();
        }
        return subs;
    }

    public void addSubscription(String collectionName, String queueName) {

        List<String> list = getSubscriptionsFor(collectionName);
        if (collectionName != null && queueName != null && !list.contains(queueName)) {
            list.add(queueName);
            cache.put(collectionName, list);
        }
    }


}
