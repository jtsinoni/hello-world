package logicole.gateway.services.asset;

import logicole.apis.asset.IEquipmentRecordMicroserviceApi;
import logicole.common.datamodels.CurrentUserBT;
import logicole.common.datamodels.equipment.EquipmentRecord;
import logicole.common.datamodels.equipment.SearchInputEquipmentRecord;
import logicole.common.datamodels.search.request.DmlesSearchRequest;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.general.exception.InvalidDataException;
import logicole.gateway.common.GatewayManager;
import logicole.gateway.services.organization.OrganizationService;
import logicole.gateway.services.search.SearchService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

@ApplicationScoped
public class EquipmentRecordService extends GatewayManager<IEquipmentRecordMicroserviceApi> {

    @Inject
    private CurrentUserBT currentUserBT;

    @Inject
    private OrganizationService organizationService;

    @Inject
    private SearchService searchService;

    public EquipmentRecordService() {
        super("EquipmentRecord");
    }

    public CurrentUser getCurrentUser() {
        return currentUserBT.getCurrentUser();
    }

    public String getEquipmentRecordESResults(SearchInputEquipmentRecord searchInputEquipmentRecord) throws InvalidDataException {
        //TODO - Once Organization code is ported over, make call below
        searchInputEquipmentRecord.orgIds.add("W33DME");
        //List<String> orgIds = organizationService.getOrgIdsForNode(currentUserBT.getCurrentNodeId());
        DmlesSearchRequest searchRequest = microservice.buildEquipmentSearchRequest(searchInputEquipmentRecord);
        String searchResults = searchService.getSearchResults(searchRequest);
        return searchResults;
    }

    public EquipmentRecord getEquipmentRecord(String dodaac, int meId) {
        EquipmentRecord record = microservice.getEquipmentRecord(dodaac, meId);
        return record;
    }
}
