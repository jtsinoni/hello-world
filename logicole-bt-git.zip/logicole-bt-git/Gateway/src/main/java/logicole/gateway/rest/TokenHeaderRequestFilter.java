package logicole.gateway.rest;


import logicole.common.datamodels.CurrentUserBT;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.datamodels.user.CurrentUserBtRef;
import logicole.common.general.logging.Logger;
import logicole.common.general.util.JSONUtil;
import logicole.common.restserver.http.RequestUtil;

import java.io.IOException;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.client.ClientRequestContext;
import javax.ws.rs.client.ClientRequestFilter;
import javax.ws.rs.core.MultivaluedMap;

@RequestScoped
public class TokenHeaderRequestFilter implements ClientRequestFilter {

    @Inject
    private Logger logger;
    @Inject
    private RequestUtil requestUtil;
    @Inject
    private CurrentUserBT currentUserBT;
    @Inject
    private JSONUtil jsonUtil;

    @Override
    public void filter(ClientRequestContext requestContext) throws IOException {
        
            MultivaluedMap<String,Object> headers = requestContext.getHeaders();

            CurrentUser currentUser = currentUserBT.getCurrentUser();
            String refString = null;

            if (currentUser != null) {
                CurrentUserBtRef ref = (CurrentUserBtRef) currentUser.getRef();
                refString = jsonUtil.serialize(ref);
                headers.add(RequestUtil.CURRENT_USER, refString);
            }

    }
    
}
