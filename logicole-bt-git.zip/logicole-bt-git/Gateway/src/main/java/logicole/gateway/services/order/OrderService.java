package logicole.gateway.services.order;

import logicole.common.datamodels.CurrentUserBT;
import logicole.common.datamodels.user.CurrentUser;
import logicole.gateway.common.GatewayManager;
import logicole.apis.order.IOrderMicroserviceApi;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

@ApplicationScoped
public class OrderService extends GatewayManager<IOrderMicroserviceApi> {

    @Inject
    private CurrentUserBT currentUserBT;

    public OrderService() {
        super("Order");
    }


    public CurrentUser getCurrentUser() {
        CurrentUser currentUser = currentUserBT.getCurrentUser();
        return currentUser;
    }



}
