package logicole.gateway.services.asset;

import io.swagger.annotations.Api;
import logicole.common.datamodels.equipment.EquipmentRecord;
import logicole.common.datamodels.equipment.SearchInputEquipmentRecord;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.general.exception.InvalidDataException;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;

@Api(tags = {"EquipmentRecord"})
@ApplicationScoped
@Path("/equipment")
public class EquipmentRecordRestApi extends ExternalRestApi<EquipmentRecordService> {

    @GET
    @Path("/getCurrentUser")
    public CurrentUser getCurrentUser() {
        return service.getCurrentUser();
    }

    @POST
    @Path("/getEquipmentRecordESResults")
    public String getEquipmentRecordESResults(SearchInputEquipmentRecord searchInputEquipmentRecord) throws InvalidDataException {
        return service.getEquipmentRecordESResults(searchInputEquipmentRecord);
    }

    @GET
    @Path("/getEquipmentRecord")
    public EquipmentRecord getEquipmentRecord(@QueryParam("dodaac") String dodaac, @QueryParam("meId") int meId) {
        return service.getEquipmentRecord(dodaac, meId);
    }

}
