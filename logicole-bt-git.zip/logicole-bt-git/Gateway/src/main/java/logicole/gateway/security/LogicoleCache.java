package logicole.gateway.security;

import logicole.common.general.logging.Logger;
import logicole.gateway.common.ResourceFinder;
import org.infinispan.Cache;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.naming.NamingException;
import javax.transaction.Transactional;

public abstract class LogicoleCache<T extends Object> {

    public LogicoleCache() {}

    public LogicoleCache(String resourceName) {
        this.resourceName = resourceName;
    }

    private Cache<String, T> cache;
    private String resourceName = null;
    @Inject
    private Logger logger;
    @Inject
    private ResourceFinder resourceFinder;

    @PostConstruct
    public void postConstruct() {
        try {
            this.cache = resourceFinder.getResource(resourceName);
        } catch (NamingException e) {
           logger.warn("Cache definition not found - {}. Creating a disabled cache.", resourceName);
           this.cache = new DisabledCache<>();
        }
    }

    public boolean exists(String userId) {
        return cache.containsKey(userId);
    }

    public T getObject(String key) {
        T cachedObject = null;
        if (exists(key)) {
            cachedObject = cache.get(key);
        }
        return cachedObject;
    }

    public void putObject(String id, T objectToCache) {
        cache.put(id, objectToCache);
    }

    @Transactional
    public void putObjectTransactional(String key, T objectToCache) {
        if (key != null && !key.isEmpty()) {
            cache.put(key, objectToCache);
        }
    }

    @Transactional
    public void remove(String key) {
        if (key != null && !key.isEmpty()) {
            cache.remove(key);
        }
    }
}
