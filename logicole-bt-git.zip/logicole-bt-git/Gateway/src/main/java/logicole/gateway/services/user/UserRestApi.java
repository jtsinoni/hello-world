package logicole.gateway.services.user;

import io.swagger.annotations.Api;
import logicole.common.datamodels.user.*;
import logicole.gateway.rest.ExternalRestApi;

import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

@Api(tags = {"User"})
@ApplicationScoped
@Path("/user")
public class UserRestApi extends ExternalRestApi<UserService> {

    @GET
    @Path("/getCurrentUser")
    public CurrentUser getCurrentUser(){
        return service.getCurrentUser();
    }

    @GET
    @Path("/getUserProfileById")
    public UserProfile getUserProfileById(@QueryParam("id") String id) {
        return service.getUserProfileById(id);
    }

    @GET
    @Path("/getUsersCurrentProfile")
    public CurrentUser getUsersCurrentProfile(@QueryParam("pkiDn") String pkiDn) {
        return service.getUsersCurrentProfile(pkiDn);
    }

    @GET
    @Path("/signIn")
    public CurrentUser signIn() {
        return service.signIn();
    }

    @GET
    @Produces(MediaType.TEXT_PLAIN)
    @Path(("/getCntActiveUserProfiles"))
    public String getCntActiveUserProfiles(@QueryParam("pkiDn") String pkiDn){
        return service.getCntActiveUserProfiles(pkiDn);
    }

    @GET
    @Path("/getActiveUserProfiles")
    public List<UserProfile> getActiveUserProfiles() {
        return service.getActiveUserProfiles();
    }

    @GET
    @Path("/getCurrentProfileRoleRefs")
    public List<RoleRef> getCurrentProfileRoleRefs() {
        return service.getCurrentProfileRoleRefs();
    }

    @GET
    @Path("/getUserProfilesByPkiDn")
    public List<UserProfile> getUserProfilesByPkiDn(@QueryParam("pkiDn") String pkiDn) {
        return service.getUserProfilesByPkiDn(pkiDn);
    }

    @GET
    @Path("/logout")
    public Boolean logout() {
        return service.logout();
    }

    @GET
    @Path("/setCurrentProfile")
    public CurrentUser setCurrentProfile(@QueryParam("id") String id) {
        return service.setCurrentProfile(id);
    }

}
