package logicole.gateway.services.product;

import logicole.gateway.rest.MicroserviceClient;
import logicole.apis.product.IProductMicroserviceApi;


import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class ProductMicroserviceClient extends MicroserviceClient<IProductMicroserviceApi> {
    public ProductMicroserviceClient(){
        super(IProductMicroserviceApi.class, "logicole-product");
    }

    @Produces
    public IProductMicroserviceApi getIProductMicroserviceApi() {
        return createClient();
    }

}
