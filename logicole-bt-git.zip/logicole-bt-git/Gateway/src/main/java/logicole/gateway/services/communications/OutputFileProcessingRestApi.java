package logicole.gateway.services.communications;

import io.swagger.annotations.Api;
import logicole.common.datamodels.communications.CommunicationRequest;
import logicole.gateway.rest.ExternalRestApi;

import java.io.IOException;
import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.POST;
import javax.ws.rs.Path;

@Api(tags = {"Communications"})
@ApplicationScoped
@Path("/outputFileProcessing")
public class OutputFileProcessingRestApi extends ExternalRestApi<OutputFileProcessingService> {

    @POST
    @Path("/sendFileData")
    public void sendFileData(CommunicationRequest communicationRequest) throws IOException {
        service.sendFileData(communicationRequest);
    }
}

