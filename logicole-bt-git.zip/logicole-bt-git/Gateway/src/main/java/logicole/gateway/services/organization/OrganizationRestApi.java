package logicole.gateway.services.organization;

import io.swagger.annotations.Api;
import logicole.common.datamodels.organization.*;
import logicole.common.datamodels.user.CurrentUser;
import logicole.gateway.rest.ExternalRestApi;

import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

@Api(tags = {"Organization"})
@ApplicationScoped
@Path("/organization")
public class OrganizationRestApi extends ExternalRestApi<OrganizationService> {

    @GET
    @Path("/getCurrentUser")
    public CurrentUser getCurrentUser() {
        return service.getCurrentUser();
    }


    @GET
    @Path("/getChildren")
    public List<Node> getChildren(@QueryParam("parentId") String parentId) {
        return service.getChildren(parentId);
    }

    @GET
    @Path("/getParent")
    public Node getParent(@QueryParam("nodeId") String nodeId) {
        return service.getParent(nodeId);
    }

    @GET
    @Path("/getNode")
    public Node getNode(@QueryParam("nodeGuid") String nodeGuid) {
        return service.getNode(nodeGuid);
    }


    @GET
    @Path("/getNodeById")
    public Node getNodeById(@QueryParam("nodeId") String nodeId) {
        return service.getNodeById(nodeId);
    }


    @GET
    @Path("/getNodeRoleIds")
    public List<String> getNodeRoleIds(@QueryParam("nodeId") String nodeId) {
        return service.getNodeRoleIds(nodeId);
    }

    @GET
    @Path("/getNodeTypeRef")
    public NodeTypeRef getNodeTypeRef(@QueryParam("nodeId") String nodeId) {
        return service.getNodeTypeRef(nodeId);
    }

    @GET
    @Path("/getNodeTypes")
    public List<NodeType> getNodeTypes() {
        return service.getNodeTypes();
    }

    @GET
    @Path("/getNodeTypesReduced")
    public List<NodeType> getNodeTypesReduced(@QueryParam("includeRoot") String includeRoot) {
        return service.getNodeTypesReduced(includeRoot);
    }

    @POST
    @Path("/getNodesInScope")
    public List<Node> getNodesInScope(ScopeQuery scopeNode) {
        return service.getNodesInScope(scopeNode);
    }

    @GET
    @Path("/getScopedNodeList")
    public List<Node> getScopedNodeList(@QueryParam("startingNodeId") String startingNodeId) {
        return service.getScopedNodeList(startingNodeId);
    }

    @GET
    @Path("/getScopedNodeIdList")
    public List<String> getScopedNodeIdList(@QueryParam("startingNodeId") String startingNodeId) {
        return service.getScopedNodeIdList(startingNodeId);
    }

    @GET
    @Path("/getPublicNodeTree")
    public NodeTree getPublicNodeTree() {
        return service.getPublicNodeTree();
    }

    @GET
    @Path("/getScopedNodeTree")
    public NodeTree getScopedNodeTree(@QueryParam("startingNodeId") String startingNodeId, @QueryParam("endingNodeTypeId") String endingNodeTypeId) {
        return service.getScopedNodeTree(startingNodeId, endingNodeTypeId);
    }

    @POST
    @Path("/getScopeUsingAncestry")
    public List<Node> getScopeUsingAncestry(AncestryQuery ancestryQuery) {
        return service.getScopeUsingAncestry(ancestryQuery);
    }

    @GET
    @Path("/getServiceProviders")
    public List<ServiceProvider> getServiceProviders() {
        return service.getServiceProviders();
    }

    @GET
    @Path("/getServiceProviderById")
    public ServiceProvider getServiceProviderById(@QueryParam("id") String id) {
        return service.getServiceProviderById(id);
    }

    @GET
    @Path("/getOrgIdsForNode")
    public List<String> getOrgIdsForNode(@QueryParam("startingNodeId") String startingNodeId) {
        return service.getOrgIdsForNode(startingNodeId);
    }

    @Produces(MediaType.TEXT_PLAIN)
    @GET
    @Path("/refreshNodeTree")
    public String refreshNodeTree() {
        return service.refreshNodeTree();
    }

    @POST
    @Path("/saveProviderConsumer")
    public ServiceProvider saveProviderConsumer(ServiceProvider provider) {
        return service.saveProviderConsumer(provider);
    }

    @GET
    @Path("/getNodeRefById")
    public NodeRef getNodeRefById(@QueryParam("id") String id) {
        return service.getNodeRefById(id);
    }


}
