package logicole.gateway.services.asset;

import logicole.apis.asset.IAssetMicroserviceApi;
import logicole.common.datamodels.CurrentUserBT;
import logicole.common.datamodels.user.CurrentUser;
import logicole.gateway.common.GatewayManager;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

@ApplicationScoped
public class AssetService extends GatewayManager<IAssetMicroserviceApi> {

    @Inject
    private CurrentUserBT currentUserBT;

    public AssetService() {
        super("Asset");
    }


    public CurrentUser getCurrentUser() {
        CurrentUser currentUser = currentUserBT.getCurrentUser();
        return currentUser;
    }



}
