package logicole.gateway.services.order;


import logicole.apis.order.ICartMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class CartMicroserviceClient extends MicroserviceClient<ICartMicroserviceApi> {
    public CartMicroserviceClient() {
        super(ICartMicroserviceApi.class, "logicole-order");
    }

    @Produces
    public ICartMicroserviceApi getICartMicroserviceApi() {
        return createClient();
    }
}
