package logicole.gateway.common;

import javax.enterprise.context.ApplicationScoped;
import javax.naming.*;

@ApplicationScoped
public class ResourceFinder {

    public <T extends Object> T getResource(String resourceName) throws NamingException {
        Context initContext = new InitialContext();
        Context webContext = (Context)initContext.lookup("java:jboss");        T resource = null;
        resource = (T) webContext.lookup(resourceName);
        return resource;
    }
}
