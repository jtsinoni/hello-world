package logicole.gateway.services.inventory;

import logicole.apis.inventory.IInventoryMicroserviceApi;
import logicole.common.datamodels.CurrentUserBT;
import logicole.common.datamodels.inventory.*;
import logicole.common.datamodels.user.CurrentUser;
import logicole.gateway.common.GatewayManager;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.QueryParam;
import java.util.List;

@ApplicationScoped
public class InventoryService extends GatewayManager<IInventoryMicroserviceApi> {

    @Inject
    private CurrentUserBT currentUserBT;

    public InventoryService() {
        super("Inventory");
    }


    public CurrentUser getCurrentUser() {
        CurrentUser currentUser = currentUserBT.getCurrentUser();
        return currentUser;
    }

    public InventoryRecord getInventoryRecordById(@QueryParam("inventoryRecordId") String inventoryRecordId) {
        return microservice.getInventoryRecordById(inventoryRecordId);
    }

    public List<InventoryOwner> getInventoryOwners() {
        return microservice.getInventoryOwners();
    }

    public InventoryOwner getInventoryOwnerById(@QueryParam("inventoryOwnerId") String inventoryOwnerId) {
        return microservice.getInventoryOwnerById(inventoryOwnerId);
    }

    public List<StorageArea> getStorageAreas() {
        return microservice.getStorageAreas();
    }

    public StorageArea getStorageAreaById(@QueryParam("storageAreaId") String storageAreaId) {
        return microservice.getStorageAreaById(storageAreaId);
    }

    public List<InventoryLocation> getInventoryLocations() {
        return microservice.getInventoryLocations();
    }

    public InventoryLocation getInventoryLocationById(@QueryParam("inventoryLocationId") String inventoryLocationId) {
        return microservice.getInventoryLocationById(inventoryLocationId);
    }

    public List<Shipment> getShipments() {
        return microservice.getShipments();
    }

    public Shipment getShipmentById(@QueryParam("shipmentId") String shipmentId) {
        return microservice.getShipmentById(shipmentId);
    }

    public List<Shipment> getInShipments() {
        return microservice.getInShipments();
    }

    public List<Shipment> getOutShipments() {
        return microservice.getOutShipments();
    }

    public List<Shipper> getShippers() {
        return microservice.getShippers();
    }

    public Shipper getShipperById(@QueryParam("shipperId") String shipperId) {
        return microservice.getShipperById(shipperId);
    }
}
