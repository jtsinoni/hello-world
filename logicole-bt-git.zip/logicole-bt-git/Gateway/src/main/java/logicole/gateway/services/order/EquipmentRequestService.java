package logicole.gateway.services.order;


import logicole.apis.order.ICartMicroserviceApi;
import logicole.apis.order.IEquipmentRequestMicroserviceApi;
import logicole.common.datamodels.CurrentUserBT;
import logicole.common.datamodels.user.CurrentUser;
import logicole.gateway.common.GatewayManager;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;


@ApplicationScoped
public class EquipmentRequestService extends GatewayManager<IEquipmentRequestMicroserviceApi> {

    @Inject
    private CurrentUserBT currentUserBT;


    public EquipmentRequestService() {
        super("EquipmentRequest");
    }


    public CurrentUser getCurrentUser() {
        CurrentUser currentUser = currentUserBT.getCurrentUser();
        return currentUser;
    }





}
