package logicole.gateway.services.user;

import io.swagger.annotations.Api;
import logicole.common.datamodels.user.*;
import logicole.gateway.rest.ExternalRestApi;

import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

@Api(tags = {"Invitation"})
@ApplicationScoped
@Path("/user")
public class InvitationRestApi extends ExternalRestApi<InvitationService> {

    @POST
    @Path("/acceptGroupInvitation")
    public UserProfile acceptGroupInvitation(UserProfile userProfile){
        return service.acceptGroupInvitation(userProfile);
    }

    @GET
    @Path("/acceptInvitation")
    public UserProfile acceptInvitation(@QueryParam("invitationId") String invitationId){
        return service.acceptInvitation(invitationId);
    }

    @POST
    @Path("/acceptInvitationByPendingUser")
    public UserProfile acceptInvitationByPendingUser(UserProfile userProfile){
        return service.acceptInvitationByPendingUser(userProfile);
    }

    @POST
    @Path("/approveInvitationByManager")
    public UserProfile approveInvitationByManager(UserProfile userProfile) {
        return service.approveInvitationByManager(userProfile);
    }

    @POST
    @Path("/createInvitation")
    public GroupInvitation createInvitation(GroupInvitation groupInvitation){
        return service.createInvitation(groupInvitation);
    }

    @POST
    @Path("/denyGroupInvitationByManager")
    public Boolean denyGroupInvitationByManager(UserProfile userProfile) {
        return service.denyGroupInvitationByManager(userProfile);
    }

    @GET
    @Path("/denyGroupInvitationByUser")
    public boolean denyGroupInvitationByUser(@QueryParam("userProfileId") String userProfileId){
        return service.denyGroupInvitationByUser(userProfileId);
    }

    @GET
    @Path("/denySingleInvitationByAdmin")
    public boolean denySingleInvitationByAdmin(@QueryParam("invitationId") String invitationId){
        return service.denySingleInvitationByAdmin(invitationId);
    }

    @GET
    @Path("/denySingleInvitationByUser")
    public boolean denySingleInvitationByUser(@QueryParam("invitationId") String invitationId) {
        return service.denySingleInvitationByUser(invitationId);
    }

    @GET
    @Path("/getAllGroupInvitations")
    public List<GroupInvitation> getAllGroupInvitations() {
        return service.getAllGroupInvitations();
    }

    @GET
    @Path("/getGroupInvitation")
    public GroupInvitation getGroupInvitation(@QueryParam("invitationId") String invitationId) {
        return service.getGroupInvitation(invitationId);
    }

    @Produces(MediaType.TEXT_PLAIN)
    @GET
    @Path("/getGroupInvitationUrl")
    public String getGroupInvitationUrl(@QueryParam("invitationId") String invitationId) {
        return service.getGroupInvitationUrl(invitationId);
    }

    @GET
    @Path("/getProfilesByGroupInvitationId")
    public List<GroupInvitationProfileTableData> getProfilesByGroupInvitationId(@QueryParam("groupInvitationId") String groupInvitationId) {
        return service.getProfilesByGroupInvitationId(groupInvitationId);
    }


}
