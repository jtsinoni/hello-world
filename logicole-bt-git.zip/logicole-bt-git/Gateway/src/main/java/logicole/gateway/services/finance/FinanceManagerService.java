package logicole.gateway.services.finance;

import com.fasterxml.jackson.databind.ObjectMapper;
import logicole.apis.finance.IFinanceManagerMicroserviceApi;
import logicole.common.datamodels.CurrentUserBT;
import logicole.common.datamodels.communications.*;
import logicole.common.datamodels.finance.*;
import logicole.common.datamodels.finance.request.CommonFinanceRequest;
import logicole.common.datamodels.finance.response.*;
import logicole.common.datamodels.notification.ApplicationNotification;
import logicole.gateway.common.GatewayManager;
import logicole.gateway.services.communications.OutputFileProcessingService;
import logicole.gateway.services.system.ApplicationNotificationService;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.*;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

@ApplicationScoped
public class FinanceManagerService extends GatewayManager<IFinanceManagerMicroserviceApi> {

    public FinanceManagerService(){
        super("FinanceManager");
    }

    FinanceManagerService(IFinanceManagerMicroserviceApi microservice,
                          OutputFileProcessingService outputFileProcessingService,
                          ApplicationNotificationService applicationNotificationService){
        super("FinanceManager");
        super.microservice = microservice;
        this.outputFileProcessingService = outputFileProcessingService;
        this.applicationNotificationService = applicationNotificationService;
    }

    @Inject
    private CurrentUserBT currentUserBT;
    @Inject
    private OutputFileProcessingService outputFileProcessingService;
    @Inject
    private ApplicationNotificationService applicationNotificationService;
    @Inject
    private FinanceAdminService financeAdminService;

    public List<FinanceDecision> getFinanceDecisionss() {
        return microservice.getFinanceDecisionss();
    }

    public CommonFinanceResponse processBusinessEvent(CommonFinanceRequest commonFinanceRequest) throws IOException {

        CommonFinanceResponse response = microservice.processBusinessEvent(commonFinanceRequest);

        CommunicationRequest communicationRequest = new CommunicationRequest();

        //TODO: figure out how to handle the exception
        try {
            formatOutputRequest(response, communicationRequest);
        } catch (IllegalAccessException | NoSuchMethodException | InvocationTargetException e) {
            e.printStackTrace();
        }

        outputFileProcessingService.sendFileData(communicationRequest);

        List<FundingNodeRef> negativeBalanceNodes = microservice.checkForNegativeFundsNotification(response.responseGroups);
        sendNegativeBalanceNotification(negativeBalanceNodes);
        return response;

    }

    void sendNegativeBalanceNotification(List<FundingNodeRef> negativeBalanceNodes) throws IOException {
        for (FundingNodeRef ref : negativeBalanceNodes) {
            ApplicationNotification notification = new ApplicationNotification();
            notification.content = "Balance exceeded for funds - " + ref.name;
            applicationNotificationService.addNotification(notification);
        }
    }

    void formatOutputRequest(CommonFinanceResponse response, CommunicationRequest communicationRequest) throws IllegalAccessException, NoSuchMethodException, InvocationTargetException {

        for (ResponseGroup responseGroup : response.responseGroups) {
            FundingNodeRef fundingNodeRef = responseGroup.fundingNodeRef;

            OutputFileGroup ofg = new OutputFileGroup();
            ofg.fundingNodeRef = fundingNodeRef;
            ofg.items = buildComsItems(responseGroup.responseItems);
            communicationRequest.outputFileGroups.add(ofg);
        }
    }

    List<CommsItem> buildComsItems(List<ResponseItem> items) throws IllegalAccessException, NoSuchMethodException, InvocationTargetException {

        ObjectMapper mapper = new ObjectMapper();

        List<CommsItem> list = new ArrayList<>();

        for (ResponseItem item: items) {
            CommsItem commsItem = new CommsItem();
            Map<String, Object> objectMap = mapper.convertValue(item, Map.class);
            Map<String, String> fieldMap = new HashMap<>();
            Map<String,Object> itemMap = (Map<String,Object>) objectMap.get("item");
            getStringMap(itemMap, fieldMap);
            commsItem.commsFields = fieldMap;
            list.add(commsItem);
        }
        return list;
    }

    private void getStringMap(Map<String,Object> itemMap, Map<String, String> fieldMap) {

        for (Map.Entry<String, Object> entry : itemMap.entrySet()) {
            if (entry.getValue() instanceof Map) {
                Map<String,Object> value = (Map<String,Object>) entry.getValue();
                getStringMap(value, fieldMap);
            } else {
                if (entry != null && entry.getKey() != null && entry.getValue() != null) {
                    fieldMap.put(entry.getKey(), entry.getValue().toString());
                }
            }
        }
    }
}

