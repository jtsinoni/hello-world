package logicole.gateway.security;

import logicole.common.datamodels.user.CurrentUser;

import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class CurrentUserCache extends LogicoleCache<CurrentUser>{

    public CurrentUserCache() {
        //super("currentUserBTCache");
        super("/infinispan/cache/currentUserBTContainer/currentUserBTCache");
    }

//    @Resource(name = "currentUserBTCache")
//    private Cache<String, Object> cache;
//
//    public boolean exists(String userId) {
//        return cache.containsKey(userId);
//    }
//
//    public CurrentUser getCurrentUser(String userId) {
//        CurrentUser currentUser = null;
//        if (exists(userId)) {
//            currentUser = (CurrentUser) cache.get(userId);
//        }
//        return currentUser;
//    }
//
//    public void setCurrentUser(String userId, CurrentUser currentUser) {
//        cache.put(userId, currentUser);
//    }
}
