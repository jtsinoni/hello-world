package logicole.gateway.services.product;

import io.swagger.annotations.Api;
import logicole.common.datamodels.product.*;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import java.util.List;

@Api(tags = {"Product"})
@ApplicationScoped
@Path("/product")
public class ProductRestApi extends ExternalRestApi<ProductService> {

    @GET
    @Path("/getSiteCatalogByEnterpriseId")
    public List<SiteCatalogRecord> getSiteCatalogByEnterpriseId(@QueryParam("siteId") String siteId, @QueryParam("enterpriseProductIdentifier") String enterpriseProductIdentifier) {
        return service.getSiteCatalogByEnterpriseId(siteId, enterpriseProductIdentifier);
    }

    @GET
    @Path("/getSiteCatalogByProductId")
    public List<SiteCatalogRecord> getSiteCatalogByProductId(@QueryParam("siteId") String siteId, @QueryParam("productSeqId") Integer productSeqId){
        return service.getSiteCatalogByProductId(siteId, productSeqId);
    }

    @GET
    @Path("/getSiteCatalogItem")
    public SiteCatalogRecord getSiteCatalogItem(@QueryParam("siteId") String siteId, @QueryParam("itemId") String itemId){
        return service.getSiteCatalogItem(siteId, itemId);
    }

    @GET
    @Path("/getSiteCatalogRecord")
    public SiteCatalogRecord getSiteCatalogRecord(@QueryParam("enterpriseItemIdentifier") String enterpriseItemIdentifier){
        return service.getSiteCatalogRecord(enterpriseItemIdentifier);
    }

    @GET
    @Path("/getSiteCatalogByBarcode")
    public List<SiteCatalogRecord> getSiteCatalogByBarcode(@QueryParam("siteId") String siteId, @QueryParam("barcode") String barcode){
        return service.getSiteCatalogByBarcode(siteId, barcode);
    }

    @GET
    @Path("/getSiteCatalog")
    public List<SiteCatalogRecord> getSiteCatalog(@QueryParam("siteId") String siteId){
        return service.getSiteCatalog(siteId);
    }

    @GET
    @Path("/getCustomerCatalog")
    public List<SiteCatalogRecord> getCustomerCatalog(@QueryParam("siteId") String siteId, @QueryParam("customerId") String customerId){
        return service.getCustomerCatalog(siteId, customerId);
    }

    @GET
    @Path("/getSupplierCatalog")
    public List<SiteCatalogRecord> getSupplierCatalog(@QueryParam("siteId") String siteId, @QueryParam("supplierNm") String supplierNm){
        return service.getSupplierCatalog(siteId, supplierNm);
    }

    @GET
    @Path("/getSiteCatalogByCommType")
    public List<SiteCatalogRecord> getSiteCatalogByCommType(@QueryParam("siteId") String siteId, @QueryParam("commType") String commType){
        return service.getSiteCatalogByCommType(siteId, commType);
    }

    @GET
    @Path("/getCustomerCatalogByCommType")
    public List<SiteCatalogRecord> getCustomerCatalogByCommType(@QueryParam("siteId") String siteId, @QueryParam("customerId") String customerId, @QueryParam("commType") String commType){
        return service.getCustomerCatalogByCommType(siteId, customerId, commType);
    }

    @GET
    @Path("/getSupplierCatalogByCommType")
    public List<SiteCatalogRecord> getSupplierCatalogByCommType(@QueryParam("siteId") String siteId, @QueryParam("supplierNm") String supplierNm, @QueryParam("commType") String commType){
        return service.getSupplierCatalogByCommType(siteId, supplierNm, commType);
    }

    @GET
    @Path("/getEquipmentByItemId")
    public List<SiteCatalogRecord> getEquipmentByItemId(@QueryParam("siteId") String siteId, @QueryParam("partialItemId") String partialItemId){
        return service.getEquipmentByItemId(siteId, partialItemId);
    }

    @GET
    @Path("/searchEquipment")
    public List<SiteCatalogRecord> searchEquipment(@QueryParam("siteId") String siteId, @QueryParam("itemId") String itemId, @QueryParam("shortItemDesc") String shortItemDesc, @QueryParam("longItemDesc") String longItemDesc, @QueryParam("manufacturerNm") String manufacturerNm, @QueryParam("manufCatNum") String manufCatNum, @QueryParam("deviceText") String deviceText){
        return service.searchEquipment(siteId, itemId, shortItemDesc, longItemDesc, manufacturerNm, manufCatNum, deviceText);
    }

    @GET
    @Path("/textSearch")
    public List<SiteCatalogRecord> textSearch(@QueryParam("siteId") String siteId, @QueryParam("searchString") String searchString){
        return service.textSearch(siteId, searchString);
    }

    @GET
    @Path("/textSearchCommType")
    public List<SiteCatalogRecord> textSearchCommType(@QueryParam("siteId") String siteId, @QueryParam("commType") String commType, @QueryParam("searchString") String searchString){
        return service.textSearchCommType(siteId, commType, searchString);
    }

    @GET
    @Path("/getCommodityClassList")
    public List<CommodityClass> getCommodityClassList(@QueryParam("militaryServiceCode") String militaryServiceCode){
        return service.getCommodityClassList(militaryServiceCode);
    }

    @GET
    @Path("/getEquipmentItemIdList")
    public List<ItemId> getEquipmentItemIdList(@QueryParam("siteId") String siteId, @QueryParam("partialItemId") String partialItemId){
        return service.getEquipmentItemIdList(siteId, partialItemId);
    }

    @GET
    @Path("/getProductSeqIdList")
    public List<Integer> getProductSeqIdList(){
        return service.getProductSeqIdList();
    }

    @GET
    @Path("/getNdcList")
    public List<String> getNdcList(){
        return service.getNdcList();
    }

    @GET
    @Path("/getMedicalSupplyProductSeqIdInfo")
    public List<ProductSeqIdInfo> getMedicalSupplyProductSeqIdInfo(){
        return service.getMedicalSupplyProductSeqIdInfo();
    }

    @GET
    @Path("/getEnterpriseProductIdentifier")
    @Produces(MediaType.TEXT_PLAIN)
    public String getEnterpriseProductIdentifier(@QueryParam("enterpriseItemIdentifier") String enterpriseItemIdentifier){
        return service.getEnterpriseProductIdentifier(enterpriseItemIdentifier);
    }

    @GET
    @Path("/getSiteCount")
    @Produces(MediaType.TEXT_PLAIN)
    public Integer getSiteCount(@QueryParam("enterpriseProductIdentifier") String enterpriseProductIdentifier){
        return service.getSiteCount(enterpriseProductIdentifier);
    }

    @GET
    @Path("/updateEnterpriseProductIdentifier")
    @Produces(MediaType.TEXT_PLAIN)
    public Integer updateEnterpriseProductIdentifier(@QueryParam("enterpriseItemIdentifier") String enterpriseItemIdentifier, @QueryParam("enterpriseProductIdentifier") String enterpriseProductIdentifier){
        return service.updateEnterpriseProductIdentifier(enterpriseItemIdentifier, enterpriseProductIdentifier);
    }

    @GET
    @Path("/updateMmcProductIdentifier")
    @Produces(MediaType.TEXT_PLAIN)
    public Integer updateMmcProductIdentifier(@QueryParam("enterpriseItemIdentifier") String enterpriseItemIdentifier, @QueryParam("mmcProductIdentifier") Integer mmcProductIdentifier){
        return service.updateMmcProductIdentifier(enterpriseItemIdentifier, mmcProductIdentifier);
    }

    @GET
    @Path("/updateProductSeqId")
    @Produces(MediaType.TEXT_PLAIN)
    public Integer updateProductSeqId(@QueryParam("oldProductSeqId") Integer oldProductSeqId, @QueryParam("newProductSeqId") Integer newProductSeqId){
        return service.updateProductSeqId(oldProductSeqId, newProductSeqId);
    }

    @GET
    @Path("/updateSiteCatalogRecordFromABi")
    @Produces(MediaType.TEXT_PLAIN)
    public Integer updateSiteCatalogRecordFromABi(@QueryParam("oldEnterpriseProductIdentifier") String oldEnterpriseProductIdentifier,
                                           @QueryParam("newEnterpriseProductIdentifier") String newEnterpriseProductIdentifier,
                                           @QueryParam("oldProductSeqId") Integer oldProductSeqId,
                                           @QueryParam("newProductSeqId") Integer newProductSeqId){
        return service.updateSiteCatalogRecordFromABi(oldEnterpriseProductIdentifier, newEnterpriseProductIdentifier, oldProductSeqId, newProductSeqId);
    }

    @GET
    @Path("/getOfferById")
    public Offer getOfferById(@QueryParam("id") String id){
        return service.getOfferById(id);
    }

    @GET
    @Path("/getOfferByOrganizationIdentifier")
    public List<Offer> getOfferByOrganizationIdentifier(@QueryParam("organizationIdentifier") String organizationIdentifier){
        return service.getOfferByOrganizationIdentifier(organizationIdentifier);
    }

    @GET
    @Path("/getOfferBySellerName")
    public List<Offer> getOfferBySellerName(@QueryParam("organizationIdentifier") String organizationIdentifier, @QueryParam("sellerName") String sellerName){
        return service.getOfferBySellerName(organizationIdentifier,sellerName);
    }

    @GET
    @Path("/getOfferByEnterpriseProductIdentifier")
    public List<Offer> getOfferByEnterpriseProductIdentifier( @QueryParam("organizationIdentifier") String organizationIdentifier, @QueryParam("enterpriseProductIdentifier") String enterpriseProductIdentifier){
        return service.getOfferByEnterpriseProductIdentifier(organizationIdentifier,enterpriseProductIdentifier);
    }

    @GET
    @Path("/getOfferByPartialEnterpriseProductIdentifier")
    public List<Offer> getOfferByPartialEnterpriseProductIdentifier(@QueryParam("organizationIdentifier") String organizationIdentifier, @QueryParam("partialProductIdentifier")  String partialProductIdentifier){
        return service.getOfferByPartialEnterpriseProductIdentifier(organizationIdentifier,partialProductIdentifier);
    }

}
