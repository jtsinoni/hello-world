package logicole.gateway.services.sale;


import logicole.apis.sale.ISellerMicroserviceApi;
import logicole.common.datamodels.CurrentUserBT;
import logicole.common.datamodels.sale.seller.Seller;
import logicole.common.datamodels.user.CurrentUser;
import logicole.gateway.common.GatewayManager;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.List;

@ApplicationScoped
public class SellerService extends GatewayManager<ISellerMicroserviceApi> {

    @Inject
    private CurrentUserBT currentUserBT;

    public SellerService() {
        super("seller");
    }


    public CurrentUser getCurrentUser() {
        CurrentUser currentUser = currentUserBT.getCurrentUser();
        return currentUser;
    }

    public List<Seller> getMySellerList() {
        return microservice.getMySellerList();
    }

    public Seller getSellerById(String id) {
        return microservice.getSellerById(id);
    }

    public Seller saveSeller(Seller seller) { return microservice.saveSeller(seller); }

    public Seller deleteSeller(String id) { return microservice.deleteSeller(id); }



}
