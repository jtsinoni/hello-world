package logicole.gateway.rest;

import logicole.common.restserver.JaxRsModuleApplication;
import logicole.gateway.services.asset.AssetRestApi;
import logicole.gateway.services.asset.EquipmentRecordRestApi;
import logicole.gateway.services.communications.OutputFileProcessingRestApi;
import logicole.gateway.services.finance.FinanceAdminRestApi;
import logicole.gateway.services.finance.FinanceManagerRestApi;
import logicole.gateway.services.inventory.InventoryRestApi;
import logicole.gateway.services.order.BuyerRestApi;
import logicole.gateway.services.order.CartRestApi;
import logicole.gateway.services.order.EquipmentRequestRestApi;
import logicole.gateway.services.order.OrderRestApi;
import logicole.gateway.services.organization.OrganizationRestApi;
import logicole.gateway.services.product.ProductRestApi;
import logicole.gateway.services.receipt.ReceiptRestApi;
import logicole.gateway.services.sale.SaleRestApi;
import logicole.gateway.services.sale.SellerRestApi;
import logicole.gateway.services.search.SearchRestApi;
import logicole.gateway.services.system.SystemNotificationRestApi;
import logicole.gateway.services.system.SystemRestApi;
import logicole.gateway.services.user.RoleRestApi;
import logicole.gateway.services.user.UserRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.ApplicationPath;

@ApplicationPath("/")
@ApplicationScoped
public class JaxRsActivator extends JaxRsModuleApplication {

    public JaxRsActivator() {
        super("gateway");

        moduleResources.add(FinanceAdminRestApi.class);
        moduleResources.add(FinanceManagerRestApi.class);
        moduleResources.add(UserRestApi.class);
        moduleResources.add(RoleRestApi.class);
        moduleResources.add(SystemRestApi.class);
        moduleResources.add(OrganizationRestApi.class);
        moduleResources.add(OrderRestApi.class);
        moduleResources.add(BuyerRestApi.class);
        moduleResources.add(SaleRestApi.class);
        moduleResources.add(SellerRestApi.class);
        moduleResources.add(ReceiptRestApi.class);
        moduleResources.add(ProductRestApi.class);
        moduleResources.add(InventoryRestApi.class);
        moduleResources.add(CartRestApi.class);
        moduleResources.add(EquipmentRequestRestApi.class);
        moduleResources.add(EquipmentRecordRestApi.class);
        moduleResources.add(SearchRestApi.class);
        moduleResources.add(AssetRestApi.class);
        moduleResources.add(OutputFileProcessingRestApi.class);
        moduleResources.add(SystemNotificationRestApi.class);



    }

}
