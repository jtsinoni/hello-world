package logicole.gateway.services.finance;

import logicole.apis.finance.IFinanceAdminMicroserviceApi;
import logicole.common.datamodels.CurrentUserBT;
import logicole.common.datamodels.finance.*;
import logicole.common.datamodels.finance.fundingsource.FundingSource;
import logicole.common.datamodels.organization.OrgRef;
import logicole.gateway.common.GatewayManager;

import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

@ApplicationScoped
public class FinanceAdminService extends GatewayManager<IFinanceAdminMicroserviceApi> {

    public FinanceAdminService(){
        super("FinanceAdmin");
    }

    @Inject
    private CurrentUserBT currentUserBT;

    public List<FinancialSystem> getFinancialSystems() {
        return microservice.getFinancialSystems();
    }

    public List<FundingSourceFieldConfig> getFinancialSystemFieldConfigListByType(String financialSystem, String fieldType) {
        return microservice.getFinancialSystemFieldConfigListByType(financialSystem, fieldType);
    }

    public List<FundingSourceFieldConfig> getFinancialSystemFieldConfigList(String financialSystem) {
        return microservice.getFinancialSystemFieldConfigList(financialSystem);
    }

    public  List<SalesCodeType> getSalesCodeTypes() {
        return microservice.getSalesCodeTypes();
    }

    public List<SubAllocationHolder> getSubAllocationHolders() {  return microservice.getSubAllocationHolders();  }

    public List<FundCode> getFundCodes() {  return microservice.getFundCodes();  }

    public List<ForeignCurrency> getForeignCurrencies() {  return microservice.getForeignCurrencies();  }

    public List<MainAccount> getMainAccountCodes() {  return microservice.getMainAccountCodes();  }

    public List<CommodityCode> getCommodityCodes() {  return microservice.getCommodityCodes();  }

    public List<FundUsageType> getFundUsageTypes() {  return microservice.getFundUsageTypes();  }

    public List<SubClass> getSubClasses() {  return microservice.getSubClasses();  }

    public List<MainAccountType> getMainAccountTypeCodes() {  return microservice.getMainAccountTypeCodes();  }

    public FundingSource createFundingSource(FundingSource fundingSource) {
        return microservice.createFundingSource(fundingSource);
    }

    public FundingSource getFundingSourceById(String id) {
        return microservice.getFundingSourceById(id);
    }

    public List<FundingSource> getAllFundingSources() {
        return microservice.getAllFundingSources();
    }

    public List<FundingNode> getFundingNodesByFundingSource(String id) {
        return microservice.getFundingNodesByFundingSource(id);
    }

    public FundingNode updateFundingNode(FundingNode node) {
        return microservice.updateFundingNode(node);
    }

    public FundingNode updateExpenseCenter(String id, FundingNode node)  {
        return microservice.updateExpenseCenter(id, node);
    }

    public FundingNode addBuyerToFund(String id, FundingNode node)  {
        return microservice.addBuyerToFund(id, node);
    }

    public List<FundingNode> getAllFundingNodes() { return microservice.getAllFundingNodes(); }

    public List<ProcessingBalance> getFundingNodesByBuyer(String id) {
        return microservice.getFundingNodesByBuyer(id);
    }

    public FundingNode removeBuyerFromFund(String fundParentId, String buyerId) {
        return microservice.removeBuyerFromFund(fundParentId, buyerId);
    }

    public FundingNode updateBuyer(String id, OrgRef buyer) {
        return microservice.updateBuyer(id, buyer);
    }

    public List<RefDataList> getRefDataList(String module) { return microservice.getRefDataList(module); }
}

