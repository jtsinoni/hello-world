package logicole.gateway.services.user;

import logicole.common.datamodels.CurrentUserBT;
import logicole.common.datamodels.user.*;
import logicole.gateway.common.GatewayManager;
import logicole.apis.user.IInvitationMicroserviceApi;

import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

@ApplicationScoped
public class InvitationService extends GatewayManager<IInvitationMicroserviceApi> {

    public InvitationService(){
        super("User");
    }
    @Inject
    private CurrentUserBT currentUserBT;

    public UserProfile acceptGroupInvitation(UserProfile userProfile) {
        return microservice.acceptGroupInvitation(userProfile);
    }

    public UserProfile acceptInvitation(String invitationId) {
        return microservice.acceptInvitation(invitationId);
    }

    public UserProfile acceptInvitationByPendingUser(UserProfile userProfile) {
        return microservice.acceptInvitationByPendingUser(userProfile);
    }

    public UserProfile approveInvitationByManager(UserProfile userProfile) {
        return microservice.approveInvitationByManager(userProfile);
    }

    public GroupInvitation createInvitation(GroupInvitation groupInvitation) {
        return microservice.createInvitation(groupInvitation);
    }

    public Boolean denyGroupInvitationByManager(UserProfile userProfile) {
        return microservice.denyGroupInvitationByManager(userProfile);
    }

    public boolean denyGroupInvitationByUser(String userProfileId) {
        return microservice.denyGroupInvitationByUser(userProfileId);
    }

    public boolean denySingleInvitationByAdmin(String invitationId) {
        return microservice.denySingleInvitationByAdmin(invitationId);
    }

    public boolean denySingleInvitationByUser(String invitationId) {
        return microservice.denySingleInvitationByUser(invitationId);
    }

    public List<GroupInvitation> getAllGroupInvitations() {
        return microservice.getAllGroupInvitations();
    }

    public GroupInvitation getGroupInvitation(String invitationId) {
        return microservice.getGroupInvitation(invitationId);
    }

    public String getGroupInvitationUrl(String invitationId) {
        return microservice.getGroupInvitationUrl(invitationId);
    }

    public List<GroupInvitationProfileTableData> getProfilesByGroupInvitationId(String groupInvitationId) {
        return microservice.getProfilesByGroupInvitationId(groupInvitationId);
    }
}
