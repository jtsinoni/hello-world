package logicole.gateway.rest;

import logicole.common.general.ConfigurationManager;
import org.jboss.resteasy.client.jaxrs.ResteasyClient;
import org.jboss.resteasy.client.jaxrs.ResteasyClientBuilder;
import org.jboss.resteasy.client.jaxrs.ResteasyWebTarget;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

public abstract class MicroserviceClient<T extends Object> {

    @Inject
    private ConfigurationManager configurationManager;
    @Inject
    private TokenHeaderRequestFilter filter;

    protected String businessApiUrl;

    protected final Class<T> classType;
    private final String serviceName;

    @Inject
    public MicroserviceClient(Class<T> classType, String serviceName) {
        this.classType = classType;
        this.serviceName = serviceName;
    }

    @PostConstruct
    public void postConstruct() {
        businessApiUrl = configurationManager.getDmlesAppHost();
    }

    public T createClient() {
        ResteasyWebTarget target = buildTarget();
        target.register(filter);

        T client = target.proxy(classType);
        return client;
    }

    protected ResteasyWebTarget buildTarget() {
        ResteasyClientBuilder resteasyClientBuilder = new ResteasyClientBuilder();
        resteasyClientBuilder.connectionPoolSize(20);
        ResteasyClient resteasyClient = resteasyClientBuilder.build();

        String url = getUrl();

        ResteasyWebTarget target = resteasyClient.target(url);

        return target;
    }

    private String getUrl() {
        String url = businessApiUrl.trim();
        if (url != null && !url.endsWith("/")) {
            url += "/";
        }
        return url + serviceName;
    }
}
