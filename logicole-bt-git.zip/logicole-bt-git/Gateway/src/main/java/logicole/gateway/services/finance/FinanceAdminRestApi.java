package logicole.gateway.services.finance;

import io.swagger.annotations.Api;
import logicole.common.datamodels.finance.*;
import logicole.common.datamodels.finance.fundingsource.FundingSource;
import logicole.common.datamodels.organization.OrgRef;
import logicole.gateway.rest.ExternalRestApi;

import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.*;

@Api(tags = {"financeAdmin"})
@ApplicationScoped
@Path("/financeAdmin")
public class FinanceAdminRestApi extends ExternalRestApi<FinanceAdminService> {

    @GET
    @Path("/getFinancialSystems")
    public List<FinancialSystem> getFinancialSystems() {
        return service.getFinancialSystems();

    }

    @GET
    @Path("/getFinancialSystemFieldConfigListByType")
    public List<FundingSourceFieldConfig> getFinancialSystemFieldConfigListByType(
            @QueryParam("financialSystem") String financialSystem,
            @QueryParam("fieldType") String fieldType) {
        return service.getFinancialSystemFieldConfigListByType(financialSystem, fieldType);

    }

    @GET
    @Path("/getFinancialSystemFieldConfigList")
    public List<FundingSourceFieldConfig> getFinancialSystemFieldConfigList(
            @QueryParam("financialSystem") String financialSystem) {
        return service.getFinancialSystemFieldConfigList(financialSystem);

    }

    @GET
    @Path("/getSubAllocationHolders")
    public List<SubAllocationHolder> getSubAllocationHolders() {
        return service.getSubAllocationHolders();
    }

    @GET
    @Path("/getFundCodes")
    public List<FundCode> getFundCodes() {
        return service.getFundCodes();
    }

    @GET
    @Path("/getForeignCurrencies")
    public List<ForeignCurrency> getForeignCurrencies() {
        return service.getForeignCurrencies();
    }

    @GET
    @Path("/getMainAccountCodes")
    public List<MainAccount> getMainAccountCodes() {
        return service.getMainAccountCodes();
    }

    @GET
    @Path("/getSalesCodeTypes")
    public List<SalesCodeType> getSalesCodeTypes() {
        return service.getSalesCodeTypes();
    }

    @GET
    @Path("/getCommodityCodes")
    public List<CommodityCode> getCommodityCodes() {
        return service.getCommodityCodes();
    }

    @GET
    @Path("/getFundUsageTypes")
    public List<FundUsageType> getFundUsageTypes() {
        return service.getFundUsageTypes();
    }

    @GET
    @Path("/getSubClasses")
    public List<SubClass> getSubClasses() {
        return service.getSubClasses();
    }

    @GET
    @Path("/getMainAccountTypeCodes")
    public List<MainAccountType> getMainAccountTypeCodes() {
        return service.getMainAccountTypeCodes();
    }

    @POST
    @Path("/createFundingSource")
    public FundingSource createFundingSource(FundingSource fundingSource) { return service.createFundingSource(fundingSource);};

    @GET
    @Path("/getFundingSourceById")
    public FundingSource getFundingSourceById(@QueryParam("id") String id) { return service.getFundingSourceById(id);};

    @GET
    @Path("/getAllFundingSources")
    public List<FundingSource> getAllFundingSourcse() { return service.getAllFundingSources();};

    @GET
    @Path(("/getFundingNodesByFundingSource"))
    public List<FundingNode> getFundingNodesByFundingSource(@QueryParam("id") String id) {
        return service.getFundingNodesByFundingSource(id);
    }

    @GET
    @Path("/getAllFundingNodes")
    public List<FundingNode> getAllFundingNodes() { return service.getAllFundingNodes();};

    @POST
    @Path(("/updateFundingNode"))
    public FundingNode updateFundingNode(FundingNode node) {
        return service.updateFundingNode(node);
    }

    @POST
    @Path(("/updateExpenseCenter"))
    public FundingNode updateExpenseCenter(@QueryParam("id") String id, FundingNode node) {
        return service.updateExpenseCenter(id, node);
    }

    @GET
    @Path(("/getFundingNodesByBuyer"))
    public List<ProcessingBalance> getFundingNodesByBuyer(@QueryParam("id") String id) {
        return service.getFundingNodesByBuyer(id);
    }

    @GET
    @Path("/getRefDataList")
    public List<RefDataList> getRefDataList(@QueryParam("module") String module) {
        return service.getRefDataList(module);
    }

    @POST
    @Path(("/addBuyerToFund"))
    public FundingNode addBuyerToFund(@QueryParam("id") String id, FundingNode node) {
        return service.addBuyerToFund(id, node);
    }

    @DELETE
    @Path(("/removeBuyerFromFund"))
    public FundingNode removeBuyerFromFund(@QueryParam("fundParentId") String fundParentId, @QueryParam("buyerId") String buyerId) {
        return service.removeBuyerFromFund(fundParentId, buyerId);
    }

    @PUT
    @Path(("/updateBuyer"))
    public FundingNode updateBuyer(@QueryParam("id") String id, OrgRef buyer) {
        return service.updateBuyer(id, buyer);
    }
}

