package logicole.gateway.services.asset;


import logicole.apis.asset.IAssetMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class AssetMicroserviceClient extends MicroserviceClient<IAssetMicroserviceApi> {
    public AssetMicroserviceClient(){
        super(IAssetMicroserviceApi.class, "logicole-asset");
    }

    @Produces
    public IAssetMicroserviceApi getIAssetMicroserviceApi() {
        return createClient();
    }

}
