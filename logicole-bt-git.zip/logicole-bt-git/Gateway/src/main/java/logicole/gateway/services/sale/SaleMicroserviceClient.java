package logicole.gateway.services.sale;

import logicole.gateway.rest.MicroserviceClient;
import logicole.apis.sale.ISaleMicroserviceApi;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class SaleMicroserviceClient extends MicroserviceClient<ISaleMicroserviceApi> {
    public SaleMicroserviceClient(){
        super(ISaleMicroserviceApi.class, "logicole-sale");
    }

    @Produces
    public ISaleMicroserviceApi getISaleMicroserviceApi() {
        return createClient();
    }

}
