package logicole.gateway.services.search;

import logicole.apis.search.ISearchMicroserviceApi;
import logicole.common.datamodels.CurrentUserBT;
import logicole.common.datamodels.search.request.DmlesSearchRequest;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.general.exception.InvalidDataException;
import logicole.gateway.common.GatewayManager;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

@ApplicationScoped
public class SearchService extends GatewayManager<ISearchMicroserviceApi> {

    @Inject
    private CurrentUserBT currentUserBT;

    public SearchService() {
        super("Search");
    }

    public CurrentUser getCurrentUser() {
        return currentUserBT.getCurrentUser();
    }

    public String getSearchResults(DmlesSearchRequest dmlesSearchRequest) throws InvalidDataException {
        return microservice.getSearchResults(dmlesSearchRequest);
    }

}
