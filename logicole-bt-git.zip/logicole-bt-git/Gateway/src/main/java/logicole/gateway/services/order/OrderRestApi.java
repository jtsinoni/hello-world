package logicole.gateway.services.order;

import io.swagger.annotations.Api;
import logicole.common.datamodels.user.CurrentUser;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.Path;

@Api(tags = {"Order"})
@ApplicationScoped
@Path("/order")
public class OrderRestApi extends ExternalRestApi<OrderService> {

    @GET
    @Path("/getCurrentUser")
    public CurrentUser getCurrentUser() {
        return service.getCurrentUser();
    }

}
