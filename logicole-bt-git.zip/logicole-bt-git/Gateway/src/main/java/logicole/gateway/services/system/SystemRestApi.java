package logicole.gateway.services.system;

import io.swagger.annotations.Api;
import logicole.common.datamodels.HealthCheckResult;
import logicole.common.datamodels.VersionInformation;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Api(tags = {"System"})
@ApplicationScoped
@Path("/system")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class SystemRestApi extends ExternalRestApi<SystemService> {

    @GET
    @Path("/getHealthCheck")
    public HealthCheckResult getHealthCheck(){
        return null;
    }

    @GET
    @Path("/getSystemVersionInformation")
    public VersionInformation getSystemVersionInformation(){
        return service.getSystemVersionInformation();
    }

}
