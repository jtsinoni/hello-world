package logicole.gateway.services.order;

import io.swagger.annotations.Api;
import logicole.common.datamodels.general.CountDTO;
import logicole.common.datamodels.order.cart.BuyerCart;
import logicole.common.datamodels.order.cart.CartDTO;
import logicole.common.datamodels.order.cart.CartItem;
import logicole.common.datamodels.order.cart.UserCart;
import logicole.common.datamodels.user.CurrentUser;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.*;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import java.util.List;

@Api(tags = {"Cart"})
@ApplicationScoped
@Path("/cart")
public class CartRestApi extends ExternalRestApi<CartService> {

    @GET
    @Path("/getCurrentUser")
    public CurrentUser getCurrentUser() {
        return service.getCurrentUser();
    }


    @GET
    @Path("/getBuyerCartList")
    public List<BuyerCart> getMyBuyerList() {
        return service.getBuyerCartList();
    }

    @GET
    @Path("/getBuyerCartListByBuyerId")
    public List<BuyerCart> getBuyerCartListByBuyerId(@QueryParam("buyerId") String buyerId) {
        return service.getBuyerCartListByBuyerId(buyerId);
    }

    @GET
    @Path("/getUserCartListByUserId")
    public List<UserCart> getUserCartListByUserId(@QueryParam("userId") String userId) {
        return service.getUserCartListByUserId(userId);
    }

    @GET
    @Path("/getBuyerCartByBuyerId")
    public CartDTO getBuyerCartByBuyerId(@QueryParam("buyerId") String buyerId) {
        return service.getBuyerSellerCartListByBuyerId(buyerId);
    }


    @GET
    @Path("/addToUserCartByBuyerCartId")
    public CartDTO addToUserCartByBuyerCartId(@QueryParam("userId") String userId, @QueryParam("buyerCartId") String buyerCartId) {
        return service.addToUserCartByBuyerCartId(userId, buyerCartId);
    }

    @GET
    @Path("/addBuyerCart")
    public BuyerCart addBuyerCart(BuyerCart buyerCart) {
        return service.addBuyerCart(buyerCart);
    }


    @GET
    @Path("/removeItemFromUserCart")
    public CartDTO removeItemFromUserCart(@QueryParam("userCartId") String userCartId, @QueryParam("cartItemId") String cartItemId) {
        return service.removeItemFromUserCart(userCartId, cartItemId);

    }

    @GET
    @Path("/moveItemToActiveCart")
    public CartDTO moveItemToActiveCart(@QueryParam("userCartId") String userCartId, @QueryParam("cartItemId") String cartItemId) {
        return service.moveItemToActiveCart(userCartId, cartItemId);

    }

    @GET
    @Path("/moveItemToSaveForLater")
    public CartDTO moveItemToSaveForLater(@QueryParam("userCartId") String userCartId, @QueryParam("cartItemId") String cartItemId) {
        return service.moveItemToSaveForLater(userCartId, cartItemId);

    }

    @GET
    @Path("/getUserCartByUserId")
    public CartDTO getUserCartByUserId(@QueryParam("userId") String userId, @QueryParam("buyerId") String buyerId){
        return service.getUserCartByUserId(userId, buyerId);
    }

    @POST
    @Path("/addCartItemToUserCart")
    public CartDTO addCartItemToUserCart(@QueryParam("buyerId") String buyerId, CartItem cartItem){
        return service.addCartItemToUserCart(buyerId,cartItem);
    }

    @GET
    @Path("/updateCartItemQuantity")
    public CartItem updateCartItemQuantity(@QueryParam("userCartId") String userCartId, @QueryParam("cartItemId") String cartItemId, @QueryParam("quantity") Long quantity ) {
        return service.updateCartItemQuantity(userCartId, cartItemId, quantity);

    }

    @GET
    @Path("/updateCartItemPrice")
    public  CartItem updateCartItemPrice(@QueryParam("userCartId") String userCartId, @QueryParam("cartItemId") String cartItemId, @QueryParam("price") Float price ){
        return service.updateCartItemPrice(userCartId, cartItemId, price);
    }

    @GET
    @Path("/addOfferToUserCart")
    public CartDTO addOfferToUserCart(@QueryParam("buyerId") String buyerId, @QueryParam("offerId") String offerId, @QueryParam("quantity")Long quantity, @QueryParam("cartPrice") Float cartPrice){
        return service.addOfferToUserCart(buyerId,offerId,quantity,cartPrice);
    }

    @GET
    @Path("/addOfferToBuyerCart")
    public BuyerCart addOfferToBuyerCart(@QueryParam("buyerId") String buyerId, @QueryParam("offerId") String offerId, @QueryParam("quantity")Long quantity, @QueryParam("cartPrice") Float cartPrice,@QueryParam("isReplenishmentItem") Boolean isReplenishmentItem  ){
        return service.addOfferToBuyerCart(buyerId,offerId,quantity,cartPrice,isReplenishmentItem);
    }


    @GET
    @Path("/getUserCartActiveItemCount")
    public CountDTO getUserCartActiveItemCount(@QueryParam("userId") String userId, @QueryParam("buyerId") String buyerId){
        return service.getUserCartActiveItemCount(userId,buyerId);
    }

}

