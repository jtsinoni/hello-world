package logicole.gateway.common;

import logicole.common.api.IMicroserviceApi;
import logicole.common.datamodels.HealthCheckResult;
import logicole.common.datamodels.VersionInformation;
import logicole.common.general.logging.Logger;
import logicole.gateway.services.asset.AssetService;
import logicole.gateway.services.asset.EquipmentRecordService;
import logicole.gateway.services.communications.OutputFileProcessingService;
import logicole.gateway.services.finance.FinanceAdminService;
import logicole.gateway.services.finance.FinanceManagerService;
import logicole.gateway.services.inventory.InventoryService;
import logicole.gateway.services.system.ApplicationNotificationService;
import logicole.gateway.services.order.*;
import logicole.gateway.services.organization.OrganizationService;
import logicole.gateway.services.product.ProductService;
import logicole.gateway.services.receipt.ReceiptService;
import logicole.gateway.services.sale.SaleService;
import logicole.gateway.services.sale.SellerService;
import logicole.gateway.services.search.SearchService;
import logicole.gateway.services.system.SystemNotificationService;
import logicole.gateway.services.system.SystemService;
import logicole.gateway.services.user.InvitationService;
import logicole.gateway.services.user.UserService;

import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.inject.Inject;


public abstract class GatewayManager<T extends IMicroserviceApi> {
    protected static List<GatewayManager> allManagers = new ArrayList<>();
    private static boolean initialized = false;

    private final String name;
    private final String apiType = "Gateway Manager";

    @Inject
    protected Logger logger;
    @Inject
    protected FinanceAdminService financeAdminService;
    @Inject
    protected FinanceManagerService financeManagerService;
    @Inject
    protected UserService userService;
    @Inject
    protected SystemService systemService;
    @Inject
    protected OrganizationService organizationService;
    @Inject
    protected InvitationService invitationService;
    @Inject
    protected OrderService orderService;
    @Inject
    protected SaleService saleService;
    @Inject
    protected ProductService productService;
    @Inject
    protected ReceiptService receiptService;
    @Inject
    protected InventoryService inventoryService;
    @Inject
    protected BuyerService buyerService;
    @Inject
    protected SellerService sellerService;
    @Inject
    protected CartService cartService;
    @Inject
    protected AssetService assetService;
    @Inject
    protected SearchService searchService;
    @Inject
    protected EquipmentRecordService equipmentRecordService;
    @Inject
    protected OutputFileProcessingService outputFileProcessingService;
    @Inject
    protected ApplicationNotificationService applicationNotificationService;
    @Inject
    protected SystemNotificationService systemNotificationService;

    @Inject
    protected T microservice;

    @Inject
    public GatewayManager(String name) {
        this.name = name;
    }

    @PostConstruct
    private void initialize() {
        if (!initialized) {
            initialized = true;
            allManagers.add(systemService);
            allManagers.add(userService);
            allManagers.add(financeAdminService);
            allManagers.add(financeManagerService);
            allManagers.add(organizationService);
            allManagers.add(invitationService);
            allManagers.add(orderService);
            allManagers.add(saleService);
            allManagers.add(productService);
            allManagers.add(receiptService);
            allManagers.add(inventoryService);
            allManagers.add(buyerService);
            allManagers.add(sellerService);
            allManagers.add(cartService);
            allManagers.add(assetService);
            allManagers.add(searchService);
            allManagers.add(equipmentRecordService);
            allManagers.add(outputFileProcessingService);
            allManagers.add(applicationNotificationService);
            allManagers.add(systemNotificationService);

        }
    }

    public HealthCheckResult checkHealth() {
        HealthCheckResult result = createHealthCheckResult("Good");
        result.nestedHealthChecks.add(microservice.checkHealth());
        return result;
    }

    public VersionInformation getMicroserviceVersionInformation() {
        return microservice.getVersionInformation();
    }

    public String getName() {
        return name;
    }

    public String getApiType() {
        return apiType;
    }

    protected HealthCheckResult createHealthCheckResult(String status) {
        return new HealthCheckResult(name, apiType, status);
    }

    protected VersionInformation createVersionInformation(String version) {
        VersionInformation versionInformation = new VersionInformation();
        versionInformation.version = version;
        versionInformation.name = name;
        versionInformation.componentType = apiType;
        return versionInformation;
    }


}
