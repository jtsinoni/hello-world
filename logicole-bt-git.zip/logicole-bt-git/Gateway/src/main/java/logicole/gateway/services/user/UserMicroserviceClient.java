package logicole.gateway.services.user;

import logicole.gateway.rest.MicroserviceClient;
import logicole.apis.user.IUserMicroserviceApi;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class UserMicroserviceClient extends MicroserviceClient<IUserMicroserviceApi> {
    public UserMicroserviceClient(){
        super(IUserMicroserviceApi.class, "logicole-user");
    }

    @Produces
    public IUserMicroserviceApi getIUserMicroserviceApi() {
        return createClient();
    }

}
