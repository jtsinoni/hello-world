package logicole.gateway.rest;

import io.swagger.annotations.Api;
import logicole.common.general.exception.*;
import logicole.common.general.logging.Logger;
import logicole.common.restserver.logging.MethodLogger;
import logicole.gateway.common.*;
import logicole.gateway.common.UnauthorizedException;
import logicole.gateway.lock.LockManager;
import logicole.gateway.security.GatewaySecurity;
import org.jboss.resteasy.util.HttpResponseCodes;

import javax.inject.Inject;
import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

@Api
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public abstract class ExternalRestApi<T extends GatewayManager> {

    public static final Integer APP_EXCEPTION = 470;
    public static final Integer UNAUTHORIZED_ENDPOINT_EXCEPTION = 471;

    @Inject
    protected T service;
    @Inject
    private GatewaySecurity gatewaySecurity;
    @Context
    private HttpServletResponse response;
    @Inject
    private LockManager lockManager;
    @Inject
    private EndpointAccessFilter endpointAccessFilter;
    @Inject
    private MethodLogger methodLogger;
    @Inject
    private Logger logger;

    @AroundInvoke
    public Object aroundLogic(InvocationContext ctx) throws Exception {
        Object retVal = null;

        try {
            gatewaySecurity.verifyRequest();
            endpointAccessFilter.checkAccess(ctx);
            String lockString = lockManager.getLockString(ctx);
            lockManager.putObjectTransactional(lockString, ctx);

            methodLogger.invoke(logger, ctx);
            retVal = ctx.proceed();
            lockManager.remove(lockString);

        } catch (UserNotFoundException userEx) {
            logger.error("error processing request", userEx);
            response.sendError(HttpResponseCodes.SC_UNAUTHORIZED, userEx.getMessage());
        } catch (ApplicationException appEx) {
            logger.error("error processing request", appEx);
            response.sendError(APP_EXCEPTION, appEx.getMessage());
        } catch (UnauthorizedException unAuth) {
            logger.error("error processing request", unAuth);
            response.sendError(UNAUTHORIZED_ENDPOINT_EXCEPTION, unAuth.getMessage());
        } catch (NotFoundException ex) {
            logger.error("error processing request", ex);
            response.sendError(HttpResponseCodes.SC_NOT_FOUND, ex.getMessage());
        } catch (InvalidFileTypeException ex) {
            logger.error("error processing request", ex);
            response.sendError(HttpResponseCodes.SC_BAD_REQUEST, ex.getMessage());
        } catch (Exception ex) {
            logger.error("error processing request", ex);
            String msg = UserExceptionMessages.GENERIC.toString();
            response.sendError(HttpResponseCodes.SC_INTERNAL_SERVER_ERROR, msg);
        }
        return retVal;
    }
}
