package logicole.gateway.services.inventory;

import io.swagger.annotations.Api;
import logicole.common.datamodels.inventory.*;
import logicole.common.datamodels.user.CurrentUser;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import java.util.List;

@Api(tags = {"Inventory"})
@ApplicationScoped
@Path("/inventory")
public class InventoryRestApi extends ExternalRestApi<InventoryService> {

    @GET
    @Path("/getCurrentUser")
    public CurrentUser getCurrentUser() {
        return service.getCurrentUser();
    }

    @GET
    @Path("/getInventoryRecordById")
    public InventoryRecord getInventoryRecordById(@QueryParam("inventoryRecordId") String inventoryRecordId) {
        return service.getInventoryRecordById(inventoryRecordId);
    }

    @GET
    @Path("/getInventoryOwners")
    public List<InventoryOwner> getInventoryOwners() {
        return service.getInventoryOwners();
    }

    @GET
    @Path("/getInventoryOwnerById")
    public InventoryOwner getInventoryOwnerById(@QueryParam("inventoryOwnerId") String inventoryOwnerId) {
        return service.getInventoryOwnerById(inventoryOwnerId);
    }

    @GET
    @Path("/getStorageAreas")
    public List<StorageArea> getStorageAreas() {
        return service.getStorageAreas();
    }

    @GET
    @Path("/getStorageAreaById")
    public StorageArea getStorageAreaById(@QueryParam("storageAreaId") String storageAreaId) {
        return service.getStorageAreaById(storageAreaId);
    }

    @GET
    @Path("/getInventoryLocations")
    public List<InventoryLocation> getInventoryLocations() {
        return service.getInventoryLocations();
    }

    @GET
    @Path("/getInventoryLocationById")
    public InventoryLocation getInventoryLocationById(@QueryParam("inventoryLocationId") String inventoryLocationId) {
        return service.getInventoryLocationById(inventoryLocationId);
    }

    @GET
    @Path("/getShipments")
    public List<Shipment> getShipments() {
        return service.getShipments();
    }

    @GET
    @Path("/getShipmentById")
    public Shipment getShipmentById(@QueryParam("shipmentId") String shipmentId) {
        return service.getShipmentById(shipmentId);
    }

    @GET
    @Path("/getInShipments")
    public List<Shipment> getInShipments() {
        return service.getInShipments();
    }

    @GET
    @Path("/getOutShipments")
    public List<Shipment> getOutShipments() {
        return service.getOutShipments();
    }

    @GET
    @Path("/getShippers")
    public List<Shipper> getShippers() {
        return service.getShippers();
    }

    @GET
    @Path("/getShipperById")
    public Shipper getShipperById(@QueryParam("shipperId") String shipperId) {
        return service.getShipperById(shipperId);
    }

}
