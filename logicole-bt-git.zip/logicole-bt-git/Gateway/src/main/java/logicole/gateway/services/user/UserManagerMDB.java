package logicole.gateway.services.user;

import logicole.common.datamodels.ref.DataReferenceUpdate;
import logicole.common.datamodels.dataref.AbstractDataReferenceMDB;
import logicole.common.general.jms.JmsClient;
import logicole.common.general.logging.Logger;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.inject.Inject;
import javax.jms.MessageListener;

@MessageDriven(name = "UserManagerMDB", activationConfig = {
        @ActivationConfigProperty(propertyName = "destinationLookup", propertyValue = "java:/topic/DataReferenceTopic"),
        @ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Topic"),
        @ActivationConfigProperty(propertyName= "subscriptionDurability", propertyValue="Durable"),
        @ActivationConfigProperty(propertyName= "subscriptionName", propertyValue="UserManagerMDB"),
        @ActivationConfigProperty(propertyName= "clientId", propertyValue = "UserManagerMDB"),
        @ActivationConfigProperty(propertyName = "messageSelector", propertyValue = "UpdateType = 'NodeRef' OR UpdateType = 'RoleRef'"),
        @ActivationConfigProperty(propertyName = "acknowledgeMode", propertyValue = "Auto-acknowledge")})
public class UserManagerMDB extends AbstractDataReferenceMDB implements MessageListener {

    @Inject
    private Logger logger;
    @Inject
    private JmsClient jmsClient;
    @Inject
    private UserReferenceUpdateManager userReferenceUpdateManager;


    @Override
    protected void processDataReferenceUpdate(DataReferenceUpdate dataReferenceUpdate) {
        userReferenceUpdateManager.processDataReferenceUpdate(dataReferenceUpdate);
    }


}