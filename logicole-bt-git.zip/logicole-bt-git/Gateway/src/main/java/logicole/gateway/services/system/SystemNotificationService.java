package logicole.gateway.services.system;

import logicole.apis.system.ISystemNotificationMicroserviceApi;
import logicole.common.datamodels.system.SystemNotification;
import logicole.gateway.common.GatewayManager;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.QueryParam;
import java.util.List;

@ApplicationScoped
public class SystemNotificationService 	extends GatewayManager<ISystemNotificationMicroserviceApi> {



    public SystemNotificationService() {
        super("SystemNotification");
    }

    public List<SystemNotification> getActiveSystemNotifications() {
        return microservice.getActiveSystemNotifications();
    }

    public List<SystemNotification> getAllSystemNotifications() {
        return microservice.getAllSystemNotifications();
    }

    public SystemNotification getSystemNotificationById(@QueryParam("notificationId") String notificationId) {
        return microservice.getSystemNotificationById(notificationId);
    }

    public SystemNotification addSystemNotification(SystemNotification systemNotification) {
        return microservice.addSystemNotification(systemNotification);
    }

    public SystemNotification saveSystemNotification(SystemNotification systemNotification) {
        return microservice.saveSystemNotification(systemNotification);
    }

}
