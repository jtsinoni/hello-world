package logicole.gateway.services.system;

import logicole.common.datamodels.HealthCheckResult;
import logicole.common.datamodels.VersionInformation;
import logicole.gateway.common.GatewayManager;
import logicole.apis.system.ISystemMicroserviceApi;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

@ApplicationScoped
public class SystemService extends GatewayManager<ISystemMicroserviceApi> {

    @Inject
    public SystemService(){
        super("System");
    }

    public HealthCheckResult getHealthCheck(){
        HealthCheckResult result = new HealthCheckResult("LogiCole", "Application", "Good");

        for (GatewayManager gatewayManager : allManagers){
            result.nestedHealthChecks.add(gatewayManager.checkHealth());
        }

        return result;
    }

    public VersionInformation getSystemVersionInformation() {
        VersionInformation versionInformation = new VersionInformation();
        versionInformation.componentType = "Application";
        versionInformation.name = "LogiCole";
        versionInformation.version = "1.0";

        for (GatewayManager gatewayManager : allManagers){
            VersionInformation nestedVersionInfo = gatewayManager.getMicroserviceVersionInformation();
            if (nestedVersionInfo != null) {
                versionInformation.nestedVersionInformation.add(nestedVersionInfo);
            }
        }
        return versionInformation;
    }
}
