package logicole.gateway.services.communications;

import logicole.apis.communications.IOutputFileProcessingMicroserviceApi;
import logicole.common.datamodels.CurrentUserBT;
import logicole.common.datamodels.communications.CommunicationRequest;
import logicole.common.general.logging.Logger;
import logicole.common.general.util.JSONUtil;
import logicole.gateway.common.GatewayManager;

import java.io.IOException;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

@ApplicationScoped
public class OutputFileProcessingService extends GatewayManager<IOutputFileProcessingMicroserviceApi> {

    public OutputFileProcessingService(){
        super("OutputFileProcessing");
    }

    @Inject
    private CurrentUserBT currentUserBT;
    @Inject
    private Logger logger;
    @Inject
    private JSONUtil jsonUtil;

    public void sendFileData(CommunicationRequest communicationRequest) throws IOException {

        String input = jsonUtil.serialize(communicationRequest);
        String id = currentUserBT.getCurrentUser().profile.id;
        logger.info("id - {} sent output request {}", id, input);
    }
}

