package logicole.gateway.common;

import logicole.common.datamodels.CurrentUserBT;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.datamodels.user.UserProfile;
import logicole.common.general.ConfigurationManager;
import logicole.common.general.logging.Logger;

import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.interceptor.InvocationContext;

@ApplicationScoped
public class EndpointAccessFilter {

    private static final String LOG_ONLY = "LogOnly";

    @Inject
    private CurrentUserBT currentUserBt;
    @Inject
    private Logger logger;
    @Inject
    private ConfigurationManager configurationManager;

    public void checkAccess(InvocationContext ctx) throws UnauthorizedException {

        if (currentUserBt.isAlreadySecure() || isInitialFilterCall(ctx)) {
            return;
        }
        CurrentUser cUser = currentUserBt.getCurrentUser();
        String pkiDn = cUser.profile.pkiDn;
        if (pkiDn == null || pkiDn.equals("TokenService")) {
            return;
        }
        
        List<String> endpoints = cUser.effectiveEndpoints;

        boolean endpointFound = false;
        String methodName = ctx.getMethod().getName();
        String className = ctx.getMethod().getDeclaringClass().getSimpleName();

        for (String endpoint : endpoints) {
            if (endpoint.equals(className + "." + methodName)) {
                endpointFound = true;
                currentUserBt.setAlreadySecure(true);
                break;
            }
        }

        if (!endpointFound){
            String permissionsCheck = configurationManager.getBtPermissionCheckMode();
            UserProfile profile = cUser.profile;
            this.logger.warn(String.format("Endpoint Access Filter: Endpoint permission missing: profileId=%s name=%s %s, called method %s.%s", profile.id, profile.firstName, profile.lastName, className, methodName));
            if (!LOG_ONLY.equalsIgnoreCase(permissionsCheck)) {
                throw new UnauthorizedException("You are not authorized to perform the requested action");
            }
        }
    }

    private boolean isInitialFilterCall(InvocationContext ctx) {
        String methodName = ctx.getMethod().getName();
        String className = ctx.getMethod().getDeclaringClass().getSimpleName();
        boolean retVal = false;
        if ("UserService.getUsersCurrentProfile".equals(className + "." + methodName)) {
            retVal = true;
            this.currentUserBt.setAlreadySecure(true);
        }
        return retVal;
    }
}
