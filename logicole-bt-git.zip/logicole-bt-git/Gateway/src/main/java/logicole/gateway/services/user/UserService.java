package logicole.gateway.services.user;

import logicole.apis.user.IUserMicroserviceApi;
import logicole.common.datamodels.CurrentUserBT;
import logicole.common.datamodels.organization.NodeRef;
import logicole.common.datamodels.user.*;
import logicole.gateway.common.GatewayManager;
import logicole.gateway.security.CurrentUserCache;
import logicole.gateway.services.organization.OrganizationService;

import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.QueryParam;

@ApplicationScoped
public class UserService extends GatewayManager<IUserMicroserviceApi> {

    public UserService(){
        super("User");
    }

    @Inject
    private OrganizationService organizationService;
    @Inject
    private CurrentUserBT currentUserBT;
    @Inject
    private CurrentUserCache currentUserCache;

    public CurrentUser getCurrentUser() {
        CurrentUser currentUser = currentUserBT.getCurrentUser();
        return currentUser;
    }

    public UserProfile getUserProfileById(String id) {
        return microservice.getUserProfileById(id);
    }

    public CurrentUser getUsersCurrentProfile(String pkiDn) {
        CurrentUser currentUser = null;
        if (currentUserCache.exists(pkiDn)) {
            currentUser = currentUserCache.getObject(pkiDn);
        } else {
            currentUser = microservice.getUsersCurrentProfile(pkiDn);
            UserProfile profile = currentUser.profile;
            List<NodeRef> accessNodes = organizationService.determineNodeAccess(profile.nodeTypeRef.id, profile.scopeNodeRefs);
            currentUser.accessToNodes = accessNodes;
            currentUserCache.putObject(pkiDn, currentUser);
        }

        return currentUser;
    }

    public List<UserProfile> getUsersForNodeId(String id) {
        return microservice.getUsersForNodeId(id);
    }

    public List<UserProfile> getUsersForRoleId(String id) {
        return microservice.getUsersForRoleId(id);
    }

    public void updateReference(UserProfile user) {
        microservice.updateReference(user);
    }

    public CurrentUser signIn() {

        return getCurrentUser();
    }

    public String getCntActiveUserProfiles(String pkiDn) {
        String val = currentUserBT.getCurrentUser().profile.pkiDn;
        logger.info("getting getCntActiveUserProfiles for id - " + val);
        return microservice.getCntActiveUserProfiles(val);
    }

    public List<UserProfile> getActiveUserProfiles() {
        String pkiDn = this.currentUserBT.getCurrentUser().profile.pkiDn;
        return microservice.getActiveUserProfiles(pkiDn);
    }

    public List<RoleRef> getCurrentProfileRoleRefs() {
        CurrentUser currentUser = getCurrentUser();
        return currentUser.profile.roleRefs;
    }

    public List<UserProfile> getUserProfilesByPkiDn(@QueryParam("pkiDn") String pkiDn) {
        return microservice.getUserProfilesByPkiDn(pkiDn);
    }

    public CurrentUser setCurrentProfile(String id) {
        CurrentUser user = microservice.setCurrentProfile(id);
        if (user != null) {
            currentUserCache.remove(user.profile.pkiDn);
        }
        return user;
    }

    public Boolean logout() {
        return true;
    }
}

