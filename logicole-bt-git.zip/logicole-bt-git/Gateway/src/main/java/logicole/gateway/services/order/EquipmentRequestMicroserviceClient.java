package logicole.gateway.services.order;



import logicole.apis.order.IEquipmentRequestMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class EquipmentRequestMicroserviceClient extends MicroserviceClient<IEquipmentRequestMicroserviceApi> {
    public EquipmentRequestMicroserviceClient() {
        super(IEquipmentRequestMicroserviceApi.class, "logicole-order");
    }

    @Produces
    public IEquipmentRequestMicroserviceApi getIEquipmentRequestMicroserviceApi() {
        return createClient();
    }
}
