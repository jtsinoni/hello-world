package logicole.gateway.services.order;

import logicole.common.datamodels.CurrentUserBT;
import logicole.common.datamodels.order.AuthorizedSupplier;
import logicole.common.datamodels.sale.seller.Seller;
import logicole.common.datamodels.order.buyer.Buyer;
import logicole.common.datamodels.order.buyer.BuyerDTO;
import logicole.common.datamodels.sale.seller.SellerRef;
import logicole.common.datamodels.user.CurrentUser;
import logicole.gateway.common.GatewayManager;
import logicole.apis.order.IBuyerMicroserviceApi;
import logicole.gateway.services.sale.SellerService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;


@ApplicationScoped
public class BuyerService extends GatewayManager<IBuyerMicroserviceApi> {

    @Inject
    private CurrentUserBT currentUserBT;
    @Inject
    private SellerService sellerService;


    public BuyerService() {
        super("Buyer");
    }


    public CurrentUser getCurrentUser() {
        CurrentUser currentUser = currentUserBT.getCurrentUser();
        return currentUser;
    }


    public List<BuyerDTO> getMyBuyerList() {
        List<Buyer> buyers = microservice.getMyBuyerList();
        List<BuyerDTO> buyerDtos = new ArrayList<>();
        for (Buyer buyer : buyers) {
            BuyerDTO buyerDTO = new BuyerDTO(buyer);
            this.addAuthorizedSuppliers(buyerDTO, buyer);
            buyerDtos.add(buyerDTO);
        }
        return buyerDtos;
    }

    public Buyer getBuyerByBuyerId(String id){
        return  microservice.getBuyerById(id);
    }

    public BuyerDTO getBuyerById(String id) {
        Buyer buyer = microservice.getBuyerById(id);
        BuyerDTO buyerDTO = new BuyerDTO(buyer);
        this.addAuthorizedSuppliers(buyerDTO, buyer);
        return buyerDTO;
    }

    public BuyerDTO saveBuyer(BuyerDTO buyerDTO) {
        Buyer buyer = this.getBuyerFromDTO(buyerDTO);
        Buyer savedBuyer = microservice.saveBuyer(buyer);
        BuyerDTO returnDTO = new BuyerDTO(savedBuyer);
        this.addAuthorizedSuppliers(returnDTO, savedBuyer);
        return returnDTO;
    }

    public BuyerDTO deleteBuyer(String id) {
        Buyer deletedBuyer = microservice.deleteBuyer(id);
        BuyerDTO returnDTO = new BuyerDTO(deletedBuyer);
        this.addAuthorizedSuppliers(returnDTO, deletedBuyer);
        return returnDTO;
    }

    private Buyer getBuyerFromDTO(BuyerDTO buyerDTO) {
        Buyer buyer = new Buyer();
        buyer.id = buyerDTO.id;
        buyer.name = buyerDTO.name;
        buyer.description = buyerDTO.description;
        buyer.isVerifyReceipts = buyerDTO.isVerifyReceipts;
        buyer.isVerifyOrders = buyerDTO.isVerifyOrders;
        buyer.isIssueIndicator = buyerDTO.isIssueIndicator;
        buyer.isRetired = buyerDTO.isRetired;
        buyer.drugEnforcementData = buyerDTO.drugEnforcementData;
        buyer.acceptedDocumentType = buyerDTO.acceptedDocumentType;
        buyer.maxOrderLimit = buyerDTO.maxOrderLimit;
        buyer.createdBy = buyerDTO.createdBy;
        buyer.createdDate = buyerDTO.createdDate;
        buyer.updatedBy = buyerDTO.updatedBy;
        buyer.updatedDate = buyerDTO.updatedDate;
        buyer._isDeleted = buyerDTO._isDeleted;
        buyer.currentNodeRef = buyerDTO.currentNodeRef;
        buyer.managedByNodeRef = buyerDTO.managedByNodeRef;
        buyer.Address = buyerDTO.Address;
        buyer.Contact = buyerDTO.Contact;
        buyer.sellerRefs = new ArrayList<>();
        if (buyerDTO.AuthorizedSupplier != null && buyerDTO.AuthorizedSupplier.size() > 0) {
            for (AuthorizedSupplier supplier : buyerDTO.AuthorizedSupplier) {
                SellerRef seller = new SellerRef();
                seller.id = supplier.id;
                seller.name = supplier.name;
                buyer.sellerRefs.add(seller);
            }
        }
        return buyer;
    }

    private void addAuthorizedSuppliers(BuyerDTO buyerDTO, Buyer buyer) {
        buyerDTO.AuthorizedSupplier = new ArrayList<>();
        if (buyer != null && buyer.sellerRefs.size() > 0) {
            for (SellerRef sellerRef : buyer.sellerRefs) {
                AuthorizedSupplier as = new AuthorizedSupplier();
                Seller seller = sellerService.getSellerById(sellerRef.id);
                as.id = seller.id;
                as.name = seller.name;
                as.description = seller.description;
                as.org = seller.org;
                as.orgName = seller.orgName;
                as.siteName = seller.siteName;
                buyerDTO.AuthorizedSupplier.add(as);
            }
        }
    }

}
