package logicole.gateway.services.user;

import logicole.common.datamodels.organization.NodeRef;
import logicole.common.datamodels.ref.DataReferenceUpdate;
import logicole.common.datamodels.user.RoleRef;
import logicole.common.datamodels.user.UserProfile;
import logicole.common.general.exception.FatalProcessingException;
import logicole.common.general.logging.Logger;
import logicole.common.general.util.DBConstants;
import logicole.common.general.util.JSONUtil;

import java.io.IOException;
import java.util.*;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

@ApplicationScoped
public class UserReferenceUpdateManager {
    @Inject
    private Logger logger;
    @Inject
    private JSONUtil jsonUtil;
    @Inject
    private UserService userService;

    public void processDataReferenceUpdate(DataReferenceUpdate dataReferenceUpdate) {
        String whatWasUpdated = dataReferenceUpdate.getRefObjectName();
        switch (whatWasUpdated) {
            case "NodeRef":
                processUpdatedNode(dataReferenceUpdate.getObject(), dataReferenceUpdate.getEntityDeleted());
                break;
            case "RoleRef":
                processUpdatedRole(dataReferenceUpdate.getObject(), dataReferenceUpdate.getEntityDeleted());
                break;
            default:
                String msg = String.format("Skipping update of %s. Id - %s", whatWasUpdated, dataReferenceUpdate.getObject());
                logger.info(msg);
        }
    }

    void processUpdatedNode(String entity, boolean entityDeleted) {
        NodeRef nodeRef;
        try {
            nodeRef = jsonUtil.deserialize(entity, NodeRef.class);
        } catch (IOException e) {
            throw new FatalProcessingException("Failed to deserialize JSON");
        }
        List<UserProfile> users = userService.getUsersForNodeId(nodeRef.id);

        if (users.size() == 0) {
            String msg = String.format("No User records found for Node id = %s", nodeRef.id);
            logger.info(msg);
        }
        for (UserProfile user : users) {
            updateUserNodeRefs(user, nodeRef);
            String msg = String.format("Updating User %s from node %s", user.id, nodeRef.id);
            logger.info(msg);
        }
    }

    void processUpdatedRole(String entity, boolean entityDeleted) {
        try {
            RoleRef roleRef = jsonUtil.deserialize(entity, RoleRef.class);
            List<UserProfile> users = userService.getUsersForRoleId(roleRef.id);

            if (users.size() == 0) {
                logger.info("No User records found for Node id = {}", roleRef.id);
            }
            for (UserProfile user : users) {
                updateUserRoleRefs(user, roleRef);
                logger.info("Updating User {} from node {}", user.id, roleRef.id);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    boolean checkNodeRef(NodeRef persistedRef, NodeRef nodeRef) {
        boolean updated = false;
        if (persistedRef != null && persistedRef.getHashValue() == nodeRef.getHashValue()) {
            updated = true;
        }
        return updated;
    }

    void updateUserNodeRefs(UserProfile user, NodeRef nodeRef) {
        boolean updated = false;

        if (checkNodeRef(user.currentNodeRef, nodeRef)) {
            user.currentNodeRef = nodeRef;
            updated = true;
        }
        if (checkNodeRef(user.managedByNodeRef, nodeRef)) {
            user.managedByNodeRef = nodeRef;
            updated = true;
        }
        for (ListIterator<NodeRef> persistedRefs = user.scopeNodeRefs.listIterator(); persistedRefs.hasNext(); ) {
            if (checkNodeRef(persistedRefs.next(), nodeRef)) {
                persistedRefs.set(nodeRef);
                updated = true;
            }
        }

        if (updated) {
            user.updatedBy = DBConstants.DB_SYNC;
            user.updatedDate = new Date();
            userService.updateReference(user);
        }
    }

    void updateUserRoleRefs(UserProfile user, RoleRef roleRef) {
        boolean updated = false;

        List<RoleRef> roleRefs = user.roleRefs;
        for (int i = 0; i < roleRefs.size(); i++) {
            RoleRef dbRoleRef = roleRefs.get(i);
            if (updateThisRole(dbRoleRef, roleRef)) {
                roleRefs.set(i, roleRef);
                updated = true;
            }
        }

        if (updated) {
            user.updatedBy = DBConstants.DB_SYNC;
            user.updatedDate = new Date();
            userService.updateReference(user);
        }
    }

    boolean updateThisRole(RoleRef dbRoleRef, RoleRef newRoleRef) {
        boolean updated = false;
        if (newRoleRef != null && newRoleRef.getId() != null && newRoleRef.getId().equals(dbRoleRef.id)) {
            updated = true;
        }
        return updated;
    }

}
