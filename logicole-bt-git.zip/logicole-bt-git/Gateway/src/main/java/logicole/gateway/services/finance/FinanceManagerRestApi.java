package logicole.gateway.services.finance;

import io.swagger.annotations.Api;
import logicole.common.datamodels.finance.FinancialSystem;
import logicole.common.datamodels.finance.request.CommonFinanceRequest;
import logicole.common.datamodels.finance.response.CommonFinanceResponse;
import logicole.gateway.rest.ExternalRestApi;

import java.io.IOException;
import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.*;

@Api(tags = {"financeManager"})
@ApplicationScoped
@Path("/financeManager")
public class FinanceManagerRestApi extends ExternalRestApi<FinanceManagerService> {

    @GET
    @Path("/getAllFinanceSystems")
    public List<FinancialSystem> getFinanceSystems() {
        return null; //service.getFinanceSystems();
    }

    @POST
    @Path("/processBusinessEvent")
    public CommonFinanceResponse processBusinessEvent(CommonFinanceRequest commonFinanceRequest) throws IOException {
        return service.processBusinessEvent(commonFinanceRequest);
    }
}
