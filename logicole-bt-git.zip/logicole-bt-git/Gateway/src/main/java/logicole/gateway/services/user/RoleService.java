package logicole.gateway.services.user;

import logicole.common.datamodels.CurrentUserBT;
import logicole.common.datamodels.user.*;
import logicole.common.general.exception.ObjectNotFoundException;
import logicole.gateway.common.GatewayManager;
import logicole.gateway.security.CurrentUserCache;
import logicole.apis.user.IRoleMicroserviceApi;

import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

@ApplicationScoped
public class RoleService extends GatewayManager<IRoleMicroserviceApi> {

    public RoleService(){
        super("Role");
    }
    @Inject
    private CurrentUserBT currentUserBT;
    @Inject
    private CurrentUserCache currentUserCache;

    public Role renameRole(String roleId, String newRoleName) throws ObjectNotFoundException {
        return microservice.renameRole(roleId, newRoleName);
    }

	public List<RoleFunctionalArea> getAllPermissions() {
		return microservice.getAllPermissions();
	}

	public List<Permission> getAllPermissionsFull() {
		return microservice.getAllPermissionsFull();
    }
    
    public Permission savePermission(Permission permission) throws ObjectNotFoundException {
        return microservice.savePermission(permission);
    }

    public Permission savePermissionElements(Permission permission) throws ObjectNotFoundException {
        return microservice.savePermissionElements(permission);
    }
    
    public Permission savePermissionStates(Permission permission) throws ObjectNotFoundException {
        return microservice.savePermissionStates(permission);
    }
    
    public Permission savePermissionEndpoints(Permission permission) throws ObjectNotFoundException {
        return microservice.savePermissionEndpoints(permission);
    }     
}
