package logicole.gateway.services.sale;

import logicole.common.datamodels.CurrentUserBT;
import logicole.common.datamodels.user.CurrentUser;
import logicole.gateway.common.GatewayManager;
import logicole.apis.sale.ISaleMicroserviceApi;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

@ApplicationScoped
public class SaleService extends GatewayManager<ISaleMicroserviceApi> {

    @Inject
    private CurrentUserBT currentUserBT;

    public SaleService() {
        super("Sale");
    }


    public CurrentUser getCurrentUser() {
        CurrentUser currentUser = currentUserBT.getCurrentUser();
        return currentUser;
    }



}
