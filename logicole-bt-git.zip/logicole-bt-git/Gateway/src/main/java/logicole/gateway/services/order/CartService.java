package logicole.gateway.services.order;


import logicole.apis.order.ICartMicroserviceApi;
import logicole.common.datamodels.CurrentUserBT;
import logicole.common.datamodels.general.CountDTO;
import logicole.common.datamodels.order.buyer.BuyerRef;
import logicole.common.datamodels.order.cart.*;
import logicole.common.datamodels.product.Offer;
import logicole.common.datamodels.product.OfferRef;
import logicole.common.datamodels.ref.DataRef;
import logicole.common.datamodels.user.CurrentUser;
import logicole.gateway.common.GatewayManager;
import logicole.gateway.services.product.ProductService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.List;


@ApplicationScoped
public class CartService extends GatewayManager<ICartMicroserviceApi> {

    @Inject
    private CurrentUserBT currentUserBT;
    @Inject
    private ProductService productService;
    @Inject
    private BuyerService buyerService;


    public CartService() {
        super("Cart");
    }


    public CurrentUser getCurrentUser() {
        CurrentUser currentUser = currentUserBT.getCurrentUser();
        return currentUser;
    }


    public CartDTO addOffer(CartDTO cartDTO){
        for(CartSellerItemsDTO cartSellerItemsDTO : cartDTO.sellerGroups){

            for(CartItem cartItem : cartSellerItemsDTO.items){
                cartItem.offer = productService.getOfferById(cartItem.offerRef.id);
            }
        }
        return cartDTO;
    }

    public CartItem addOffer(CartItem cartItem){
         cartItem.offer = productService.getOfferById(cartItem.offerRef.id);
         return cartItem;
    }




    public List<BuyerCart> getBuyerCartList() {
        return microservice.getBuyerCartList();
    }

    public List<BuyerCart> getBuyerCartListByBuyerId(String buyerId) {
        List<BuyerCart> buyerCartList = microservice.getBuyerCartListByBuyerId(buyerId);

        for (BuyerCart buyerCart : buyerCartList){
            buyerCart.offer = productService.getOfferById(buyerCart.offerRef.id);
        }
        return buyerCartList;
    }


    public List<UserCart> getUserCartListByUserId(String userId) {
        return microservice.getUserCartListByUserId(userId);
    }

    public CartDTO getBuyerSellerCartListByBuyerId(String buyerId) {
        CartDTO cartDTO = microservice.getBuyerCartByBuyerId(buyerId);
        return addOffer(cartDTO);
    }

    public CartDTO addToUserCartByBuyerCartId(String userId, String buyerCartId) {
        CartDTO cartDTO = microservice.addToUserCartByBuyerCartId(userId, buyerCartId);
        return addOffer(cartDTO);
    }

    public BuyerCart addBuyerCart(BuyerCart buyerCart) {
        return microservice.addBuyerCart(buyerCart);
    }


    public CartDTO removeItemFromUserCart(String userCartId, String cartItemId) {
        CartDTO cartDTO = microservice.removeItemFromUserCart(userCartId, cartItemId);
        return addOffer(cartDTO);
    }

    public CartDTO moveItemToActiveCart(String userCartId, String cartItemId) {
        CartDTO cartDTO = microservice.moveItemToActiveCart(userCartId, cartItemId);
        return addOffer(cartDTO);
    }


    public CartDTO moveItemToSaveForLater(String userCartId, String cartItemId) {
        CartDTO cartDTO =  microservice.moveItemToSaveForLater(userCartId, cartItemId);
        return addOffer(cartDTO);
    }

    public CartDTO getUserCartByUserId(String userId, String buyerId) {

        CartDTO cartDTO = microservice.getUserCartByUserId(userId, buyerId);
        return addOffer(cartDTO);
    }

    public CartDTO addCartItemToUserCart(String buyerId, CartItem cartItem) {
        CartDTO cartDTO = microservice.addCartItemToUserCart(buyerId, cartItem);
        return addOffer(cartDTO);
    }

    public CartItem updateCartItemQuantity(String userCartId, String cartItemId, Long quantity) {
        CartItem cartItem =  microservice.updateCartItemQuantity(userCartId,cartItemId,quantity);
        return addOffer(cartItem);
    }

    public CartItem updateCartItemPrice(String userCartId, String cartItemId, Float price) {
        CartItem cartItem = microservice.updateCartItemPrice(userCartId,cartItemId,price);
        return addOffer(cartItem);
    }

    public CartDTO addOfferToUserCart(String buyerId, String offerId, Long quantity, Float cartPrice){
        CartItem cartItem = new CartItem();
        cartItem.quantityRequested = quantity;
        cartItem.cartPrice = cartPrice;
        cartItem.quantity = quantity;
        cartItem.offerRef = (OfferRef) productService.getOfferById(offerId).getRef();
        cartItem.isReplenishmentItem = false;
        cartItem.isPassThroughItem = false;
        cartItem.isSavedForLater = false;
        CartDTO cartDTO = microservice.addCartItemToUserCart(buyerId, cartItem);
        return cartDTO;
    }

    public BuyerCart addOfferToBuyerCart(String buyerId, String offerId, Long quantity, Float cartPrice, Boolean isReplenishmentItem) {
        BuyerCart buyerCart = new BuyerCart();
        buyerCart.quantityRequested = quantity;
        buyerCart.quantity = quantity;
        buyerCart.cartPrice = cartPrice;

        if (isReplenishmentItem) {
            buyerCart.isReplenishmentItem = isReplenishmentItem;
            buyerCart.isPassThroughItem = false;
        }
        else
        {
            buyerCart.isReplenishmentItem = false;
            buyerCart.isPassThroughItem = true;
        }
        buyerCart.buyerRef = (BuyerRef) buyerService.getBuyerByBuyerId(buyerId).getRef();
        buyerCart.offerRef = (OfferRef) productService.getOfferById(offerId).getRef();

        return microservice.addBuyerCart(buyerCart);
    }


    public CountDTO getUserCartActiveItemCount(String userId, String buyerId) {
        return microservice.getUserCartActiveItemCount(userId,buyerId);
    }
}
