package logicole.gateway.services.receipt;

import io.swagger.annotations.Api;
import logicole.common.datamodels.user.CurrentUser;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.Path;

@Api(tags = {"Receipt"})
@ApplicationScoped
@Path("/receipt")
public class ReceiptRestApi extends ExternalRestApi<ReceiptService> {

    @GET
    @Path("/getCurrentUser")
    public CurrentUser getCurrentUser() {
        return service.getCurrentUser();
    }

}
