package logicole.gateway.services.asset;


import logicole.apis.asset.IEquipmentRecordMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class EquipmentRecordMicroserviceClient extends MicroserviceClient<IEquipmentRecordMicroserviceApi> {
    public EquipmentRecordMicroserviceClient(){
        super(IEquipmentRecordMicroserviceApi.class, "logicole-asset");
    }

    @Produces
    public IEquipmentRecordMicroserviceApi getIEquipmentRecordMicroserviceApi() {
        return createClient();
    }

}
