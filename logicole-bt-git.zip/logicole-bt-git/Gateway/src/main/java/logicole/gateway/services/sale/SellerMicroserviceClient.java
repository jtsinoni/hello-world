package logicole.gateway.services.sale;


import logicole.apis.sale.ISellerMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class SellerMicroserviceClient extends MicroserviceClient<ISellerMicroserviceApi> {
    public SellerMicroserviceClient(){
        super(ISellerMicroserviceApi.class, "logicole-sale");
    }

    @Produces
    public ISellerMicroserviceApi getISellerMicroserviceApi() {
        return createClient();
    }

}
