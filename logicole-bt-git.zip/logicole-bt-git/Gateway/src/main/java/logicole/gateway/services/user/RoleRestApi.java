package logicole.gateway.services.user;

import io.swagger.annotations.Api;
import logicole.common.datamodels.user.Permission;
import logicole.common.datamodels.user.Role;
import logicole.common.datamodels.user.RoleFunctionalArea;
import logicole.common.general.exception.ObjectNotFoundException;
import logicole.gateway.rest.ExternalRestApi;

import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.*;

@Api(tags = {"Role"})
@ApplicationScoped
@Path("/role")
public class RoleRestApi extends ExternalRestApi<RoleService> {

    @Inject
    private RoleService roleService;

    @GET
    @Path("/renameRole")
    public Role renameRole(@QueryParam("roleId") String roleId,
                           @QueryParam("newRoleName") String newRoleName) throws ObjectNotFoundException {
        return roleService.renameRole(roleId, newRoleName);
    }

    @GET
    @Path("/getAllPermissions")
    public List<RoleFunctionalArea> getAllPermissions() {
        return roleService.getAllPermissions();
    }
    
    @GET
    @Path("/getAllPermissionsFull")
    public List<Permission> getAllPermissionsFull() {
        return roleService.getAllPermissionsFull();
    }
    
    @POST
    @Path("/savePermissionDetailed")
    public Permission savePermission(Permission permission) throws ObjectNotFoundException {
        return roleService.savePermission(permission);
    }
    
    @POST
    @Path("/savePermissionElements")
    public Permission savePermissionElements(Permission permission) throws ObjectNotFoundException {
        return roleService.savePermissionElements(permission);
    }
    
    @POST
    @Path("/savePermissionStates")
    public Permission savePermissionStates(Permission permission) throws ObjectNotFoundException {
        return roleService.savePermissionStates(permission);
    }
    
    @POST
    @Path("/savePermissionEndpoints")
    public Permission savePermissionEndpoints(Permission permission) throws ObjectNotFoundException {
        return roleService.savePermissionEndpoints(permission);
    }    

}
