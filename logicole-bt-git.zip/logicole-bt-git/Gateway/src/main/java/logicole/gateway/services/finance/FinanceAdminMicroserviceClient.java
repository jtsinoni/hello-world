package logicole.gateway.services.finance;

import logicole.apis.finance.IFinanceAdminMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class FinanceAdminMicroserviceClient extends MicroserviceClient<IFinanceAdminMicroserviceApi> {
    public FinanceAdminMicroserviceClient(){
        super(IFinanceAdminMicroserviceApi.class, "logicole-finance");
    }

    @Produces
    public IFinanceAdminMicroserviceApi getMicroserviceApi() {
        return createClient();
    }

}
