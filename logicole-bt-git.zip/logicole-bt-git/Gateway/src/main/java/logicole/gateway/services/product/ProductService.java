package logicole.gateway.services.product;

import logicole.common.datamodels.product.*;
import logicole.gateway.common.GatewayManager;
import logicole.apis.product.IProductMicroserviceApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.QueryParam;
import java.util.List;

@ApplicationScoped
public class ProductService extends GatewayManager<IProductMicroserviceApi> {

    public ProductService() {
        super("Product");
    }

    public List<SiteCatalogRecord> getSiteCatalogByEnterpriseId(@QueryParam("siteId") String siteId, @QueryParam("enterpriseProductIdentifier") String enterpriseProductIdentifier) {
        List<SiteCatalogRecord> recordList = microservice.getSiteCatalogByEnterpriseId(siteId, enterpriseProductIdentifier);
        return recordList;
    }

    public List<SiteCatalogRecord> getSiteCatalogByProductId(@QueryParam("siteId") String siteId, @QueryParam("productSeqId") Integer productSeqId) {
        List<SiteCatalogRecord> recordList = microservice.getSiteCatalogByProductId(siteId, productSeqId);
        return recordList;
    }

    public SiteCatalogRecord getSiteCatalogItem(@QueryParam("siteId") String siteId, @QueryParam("itemId") String itemId) {
        return microservice.getSiteCatalogItem(siteId, itemId);
    }

    public SiteCatalogRecord getSiteCatalogRecord(@QueryParam("enterpriseItemIdentifier") String enterpriseItemIdentifier) {
        return microservice.getSiteCatalogRecord(enterpriseItemIdentifier);
    }

    public List<SiteCatalogRecord> getSiteCatalogByBarcode(@QueryParam("siteId") String siteId, @QueryParam("barcode") String barcode) {
        List<SiteCatalogRecord> recordList = microservice.getSiteCatalogByBarcode(siteId, barcode);
        return recordList;
    }

    public List<SiteCatalogRecord> getSiteCatalog(@QueryParam("siteId") String siteId) {
        List<SiteCatalogRecord> recordList = microservice.getSiteCatalog(siteId);
        return recordList;
    }

    public List<SiteCatalogRecord> getCustomerCatalog(@QueryParam("siteId") String siteId, @QueryParam("customerId") String customerId) {
        List<SiteCatalogRecord> recordList = microservice.getCustomerCatalog(siteId, customerId);
        return recordList;
    }

    public List<SiteCatalogRecord> getSupplierCatalog(@QueryParam("siteId") String siteId, @QueryParam("supplierNm") String supplierNm) {
        List<SiteCatalogRecord> recordList = microservice.getSupplierCatalog(siteId, supplierNm);
        return recordList;
    }

    public List<SiteCatalogRecord> getSiteCatalogByCommType(@QueryParam("siteId") String siteId, @QueryParam("commType") String commType) {
        List<SiteCatalogRecord> recordList = microservice.getSiteCatalogByCommType(siteId, commType);
        return recordList;
    }

    public List<SiteCatalogRecord> getCustomerCatalogByCommType(@QueryParam("siteId") String siteId, @QueryParam("customerId") String customerId, @QueryParam("commType") String commType) {
        List<SiteCatalogRecord> recordList = microservice.getCustomerCatalogByCommType(siteId, customerId, commType);
        return recordList;
    }

    public List<SiteCatalogRecord> getSupplierCatalogByCommType(@QueryParam("siteId") String siteId, @QueryParam("supplierNm") String supplierNm, @QueryParam("commType") String commType) {
        List<SiteCatalogRecord> recordList = microservice.getSupplierCatalogByCommType(siteId, supplierNm, commType);
        return recordList;
    }

    // Get equipment Site Catalog Records for a given partial Item ID.")
    public List<SiteCatalogRecord> getEquipmentByItemId(@QueryParam("siteId") String siteId, @QueryParam("partialItemId") String partialItemId) {
        List<SiteCatalogRecord> recordList = microservice.getEquipmentByItemId(siteId, partialItemId);
        return recordList;
    }

    // Get equipment Site Catalog Records for a given criteria.")
    public List<SiteCatalogRecord> searchEquipment(@QueryParam("siteId") String siteId, @QueryParam("itemId") String itemId, @QueryParam("shortItemDesc") String shortItemDesc, @QueryParam("longItemDesc") String longItemDesc, @QueryParam("manufacturerNm") String manufacturerNm, @QueryParam("manufCatNum") String manufCatNum, @QueryParam("deviceText") String deviceText) {
        List<SiteCatalogRecord> recordList = microservice.searchEquipment(siteId, itemId, shortItemDesc, longItemDesc, manufacturerNm, manufCatNum, deviceText);
        return recordList;
    }

    // Perform a keyword search within the given criteria.")
    public List<SiteCatalogRecord> textSearch(@QueryParam("siteId") String siteId, @QueryParam("searchString") String searchString) {
        List<SiteCatalogRecord> recordList = microservice.textSearch(siteId, searchString);
        return recordList;
    }

    // Perform a keyword search within the given criteria.")
    public List<SiteCatalogRecord> textSearchCommType(@QueryParam("siteId") String siteId, @QueryParam("commType") String commType, @QueryParam("searchString") String searchString) {
        List<SiteCatalogRecord> recordList = microservice.textSearchCommType(siteId, commType, searchString);
        return recordList;
    }

    // Return a list of Commodity Classes for the given Military Service Code.")
    public List<CommodityClass> getCommodityClassList(@QueryParam("militaryServiceCode") String militaryServiceCode) {
        List<CommodityClass> recordList = microservice.getCommodityClassList(militaryServiceCode);
        return recordList;
    }

    // Get a list of Item IDs for equipment matching a given partial Item ID.")
    public List<ItemId> getEquipmentItemIdList(@QueryParam("siteId") String siteId, @QueryParam("partialItemId") String partialItemId) {
        List<ItemId> recordList = microservice.getEquipmentItemIdList(siteId, partialItemId);
        return recordList;
    }

    // Get a Distinct List of the ProductSeqIds contained in the Site Catalog.")
    public List<Integer> getProductSeqIdList() {
        List<Integer> recordList = microservice.getProductSeqIdList();
        return recordList;
    }

    // Get a distinct list of the NDCs contained in the Site Catalog.")
    public List<String> getNdcList() {
        List<String> recordList = microservice.getNdcList();
        return recordList;
    }

    // Gets a list of Medical Supply Product Seq Info objects..")
    public List<ProductSeqIdInfo> getMedicalSupplyProductSeqIdInfo() {
        return microservice.getMedicalSupplyProductSeqIdInfo();
    }

    // Gets enterpriseProductIdentifier for given enterpriseItemIdentifier")
    public String getEnterpriseProductIdentifier(@QueryParam("enterpriseItemIdentifier") String enterpriseItemIdentifier) {
        return microservice.getEnterpriseProductIdentifier(enterpriseItemIdentifier);
    }

    // Gets count of sites using the given enterprise product")
    public Integer getSiteCount(@QueryParam("enterpriseProductIdentifier") String enterpriseProductIdentifier) {
        return microservice.getSiteCount(enterpriseProductIdentifier);
    }

    // Updates the enterpriseProductIdentifier in the Site Catalog.")
    public Integer updateEnterpriseProductIdentifier(@QueryParam("enterpriseItemIdentifier") String enterpriseItemIdentifier, @QueryParam("enterpriseProductIdentifier") String enterpriseProductIdentifier) {
        return microservice.updateEnterpriseProductIdentifier(enterpriseItemIdentifier, enterpriseProductIdentifier);
    }

    // Updates the productSeqId for a single record in the Site Catalog.")
    public Integer updateMmcProductIdentifier(@QueryParam("enterpriseItemIdentifier") String enterpriseItemIdentifier, @QueryParam("mmcProductIdentifier") Integer mmcProductIdentifier) {
        return microservice.updateMmcProductIdentifier(enterpriseItemIdentifier, mmcProductIdentifier);
    }

    // Updates the productSeqId for all matching records in the Site Catalog.")
    public Integer updateProductSeqId(@QueryParam("oldProductSeqId") Integer oldProductSeqId, @QueryParam("newProductSeqId") Integer newProductSeqId) {
        return microservice.updateProductSeqId(oldProductSeqId, newProductSeqId);
    }

    // Updates the EnterpriseProductIdentifier and the ProductSeqId in the Site Catalog from the ABi Values.")
    public Integer updateSiteCatalogRecordFromABi(@QueryParam("oldEnterpriseProductIdentifier") String oldEnterpriseProductIdentifier,
                                                  @QueryParam("newEnterpriseProductIdentifier") String newEnterpriseProductIdentifier,
                                                  @QueryParam("oldProductSeqId") Integer oldProductSeqId,
                                                  @QueryParam("newProductSeqId") Integer newProductSeqId) {
        return microservice.updateSiteCatalogRecordFromABi(oldEnterpriseProductIdentifier, newEnterpriseProductIdentifier, oldProductSeqId, newProductSeqId);
    }

    public Offer getOfferById(String id) {
        return microservice.getOfferById(id);
    }


    public List<Offer> getOfferByOrganizationIdentifier(String organizationIdentifier) {
        return microservice.getOfferByOrganizationIdentifier(organizationIdentifier);
    }


    public List<Offer> getOfferBySellerName(String organizationIdentifier, String sellerName) {
        return microservice.getOfferBySellerName(organizationIdentifier,sellerName);
    }


    public List<Offer> getOfferByEnterpriseProductIdentifier(String organizationIdentifier, String enterpriseProductIdentifier) {
        return microservice.getOfferByEnterpriseProductIdentifier(organizationIdentifier,enterpriseProductIdentifier);
    }


    public List<Offer> getOfferByPartialEnterpriseProductIdentifier(String organizationIdentifier, String partialProductIdentifier) {
        return microservice.getOfferByPartialEnterpriseProductIdentifier(organizationIdentifier,partialProductIdentifier);
    }
}
