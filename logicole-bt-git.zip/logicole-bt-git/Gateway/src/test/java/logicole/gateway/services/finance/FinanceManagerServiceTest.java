package logicole.gateway.services.finance;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

import logicole.apis.finance.IFinanceManagerMicroserviceApi;
import logicole.common.datamodels.communications.CommunicationRequest;
import logicole.common.datamodels.finance.FundingNodeRef;
import logicole.common.datamodels.finance.request.CommonFinanceRequest;
import logicole.common.datamodels.finance.response.CommonFinanceResponse;
import logicole.common.datamodels.finance.response.ResponseGroup;
import logicole.common.datamodels.notification.ApplicationNotification;
import logicole.gateway.services.communications.OutputFileProcessingService;
import logicole.gateway.services.system.ApplicationNotificationService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

@RunWith(MockitoJUnitRunner.class)
public class FinanceManagerServiceTest {

    @Mock
    private ApplicationNotificationService applicationNotificationService;
    @Mock
    private IFinanceManagerMicroserviceApi microservice;
    @Mock
    private OutputFileProcessingService outputFileProcessingService;

    private FinanceManagerService fms;
    private FinanceManagerService spy;

    @Before
    public void setup() {

        fms = new FinanceManagerService(microservice, outputFileProcessingService, applicationNotificationService);
        spy = Mockito.spy(fms);
    }
    @Test
    public void processBusinessEventTest() throws IOException, IllegalAccessException, NoSuchMethodException, InvocationTargetException {
        CommonFinanceRequest req = new CommonFinanceRequest();
        CommonFinanceResponse response = new CommonFinanceResponse();
        List<ResponseGroup> responseGroups = new ArrayList<>();
        response.responseGroups = responseGroups;
        List<FundingNodeRef> negativeBalanceNodes = new ArrayList<>();

        when(microservice.processBusinessEvent(req)).thenReturn(response);
        doNothing().when(spy).formatOutputRequest(eq(response), any(CommunicationRequest.class));

        when(microservice.checkForNegativeFundsNotification(responseGroups)).thenReturn(negativeBalanceNodes);
        doNothing().when(spy).sendNegativeBalanceNotification(negativeBalanceNodes);

        spy.processBusinessEvent(req);

        verify(microservice).processBusinessEvent(req);
        verify(spy).formatOutputRequest(eq(response), any(CommunicationRequest.class));
        verify(outputFileProcessingService).sendFileData(any(CommunicationRequest.class));
        verify(microservice).checkForNegativeFundsNotification(responseGroups);
        verify(spy).sendNegativeBalanceNotification(negativeBalanceNodes);
    }

    @Test
    public void sendNegativeBalanceNotificationTestNone() throws IOException {

        List<FundingNodeRef> list = new ArrayList<>();

        spy.sendNegativeBalanceNotification(list);

        verify(applicationNotificationService, times(0)).addNotification(any(ApplicationNotification.class));

    }

    @Test
    public void sendNegativeBalanceNotificationTestTwo() throws IOException {

        List<FundingNodeRef> list = new ArrayList<>();
        FundingNodeRef fn1 = new FundingNodeRef();
        fn1.name = "fn1";
        list.add(fn1);
        FundingNodeRef fn2 = new FundingNodeRef();
        fn1.name = "fn2";
        list.add(fn2);

        spy.sendNegativeBalanceNotification(list);

        verify(applicationNotificationService, times(2)).addNotification(any(ApplicationNotification.class));

    }
//    public void checkForNegativeFundsNotificationTest() throws IOException {
//        CommonFinanceResponse resp = new CommonFinanceResponse();
//        ResponseGroup rg1 = new ResponseGroup();
//        resp.responseGroups.add(rg1);
//        Balances b1 = new Balances();
//        rg1.endingBalance = b1;
//        b1.total = 2d;
//        FundingNodeRef fnr1 = new FundingNodeRef();
//        fnr1.target = 1d;
//        rg1.fundingNodeRef = fnr1;
//
//        ResponseGroup rg2 = new ResponseGroup();
//        resp.responseGroups.add(rg2);
//        Balances b2 = new Balances();
//        rg2.endingBalance = b2;
//        b2.total = 1d;
//        FundingNodeRef fnr2 = new FundingNodeRef();
//        fnr2.target = 2d;
//        rg2.fundingNodeRef = fnr2;
//
//        spy.checkForNegativeFundsNotification(resp);
//
//        verify(applicationNotificationService, times(1))
//                .addNotification(any(SystemNotification.class));
//
//    }
}
