package logicole.common.servers.persistence;

import org.mongodb.morphia.query.UpdateOperations;

import java.util.List;

interface IGenericPersistedDao<T extends PersistedEntity, PK> {

    List<T> findAll();

    T findById(PK pk);

    List<T> query(String queryString);

    T upsert(T t);

    T insert(T t);

    T update(T t);

    T merge(T t);

    UpdateOperations<T> getDatabaseOperation();

}
