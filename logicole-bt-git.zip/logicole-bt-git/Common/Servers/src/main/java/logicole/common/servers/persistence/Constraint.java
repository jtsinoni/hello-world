package logicole.common.servers.persistence;

import logicole.common.general.exception.FatalProcessingException;
import org.mongodb.morphia.query.Criteria;
import org.mongodb.morphia.query.CriteriaContainer;
import org.mongodb.morphia.utils.Assert;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public class Constraint {

    private Query query;
    private org.mongodb.morphia.query.Query morphiaQuery;
    private List<Constraint> constraints = new ArrayList<>();
    private String fieldName = null;
    private FilterOperator filterOperator = null;
    private boolean isApplyNot = false;
    private Object value;

    String getFieldName() {
        return fieldName;
    }

    FilterOperator getFilterOperator() {
        return filterOperator;
    }

    boolean getIsApplyNot() {
        return isApplyNot;
    }

    Object getValue() {
        return value;
    }

    public Constraint(Query query, String fieldName) {
        this.query = query;
        this.morphiaQuery = query.getDecoratedQuery();
        this.fieldName = fieldName;
    }

    public Constraint(Query query, List<Constraint> constraints, FilterOperator filterOperator) {
        if (filterOperator == null || !(filterOperator == FilterOperator.AND || filterOperator == FilterOperator.OR)) {
            throw new FatalProcessingException("Filter operator must be And or Or for a list of Constraints");
        }
        this.query = query;
        this.morphiaQuery = query.getDecoratedQuery();
        this.constraints = constraints;
        this.filterOperator = filterOperator;
    }

    CriteriaContainer getCriteria() {
        org.mongodb.morphia.query.FieldEnd fe = null;
        CriteriaContainer container = null;
        if (fieldName == null) {
            switch (filterOperator) {
                case AND:
                    container = morphiaQuery.and();
                    for (Constraint constraint : constraints) {
                        container.add((Criteria) constraint.getCriteria());
                    }
                    //morphiaQuery.and(container);
                    break;
                case OR:
                    container = morphiaQuery.or();
                    for (Constraint constraint : constraints) {
                        container.add((Criteria) constraint.getCriteria());
                    }
                    //morphiaQuery.or(container);
                    break;
            }
        } else {
            fe = morphiaQuery.criteria(fieldName);
            switch (filterOperator) {
                case EQUAL:
                    if (isApplyNot) {
                        container = (CriteriaContainer) fe.notEqual(value);
                    } else {
                        container = (CriteriaContainer) fe.equal(value);
                    }
                    break;
                case EXISTS:
                    if (isApplyNot) {
                        container = (CriteriaContainer) fe.doesNotExist();
                    } else {
                        container = (CriteriaContainer) fe.exists();
                    }
                    break;
                case GREATER_THAN:
                    container = (CriteriaContainer) fe.greaterThan(value);
                    break;
                case GREATER_THAN_OR_EQUAL:
                    container = (CriteriaContainer) fe.greaterThanOrEq(value);
                    break;
                case LESS_THAN:
                    container = (CriteriaContainer) fe.lessThan(value);
                    break;
                case IN:
                    container = (CriteriaContainer) fe.in((Iterable) value);
                    break;
            }
        }
        return container;
    }

    public Constraint contains(final String token) {
        Assert.parametersNotNull("val", token);
        this.filterOperator = FilterOperator.EQUAL;
        this.value = Pattern.compile(token);
        return this;
    }

    public Constraint containsIgnoreCase(final String token) {
        Assert.parametersNotNull("val", token);
        this.filterOperator = FilterOperator.EQUAL;
        this.value = Pattern.compile(token, 2);
        return this;
    }

    public Constraint doesNotExist() {
        this.filterOperator = FilterOperator.EXISTS;
        this.isApplyNot = true;
        return this;
    }

    public Constraint equal(Object o) {
        this.filterOperator = FilterOperator.EQUAL;
        this.value = o;
        return this;
    }

    public Constraint equalIgnoreCase(String o) {
        this.filterOperator = FilterOperator.EQUAL;
        this.value = Pattern.compile(o, Pattern.CASE_INSENSITIVE);
        return this;
    }

    public Constraint exists() {
        this.filterOperator = FilterOperator.EXISTS;
        return this;
    }

    public Constraint greaterThan(Object o) {
        this.filterOperator = FilterOperator.GREATER_THAN;
        this.value = o;
        return this;
    }

    public Constraint greaterThanOrEq(Object o) {
        this.filterOperator = FilterOperator.GREATER_THAN_OR_EQUAL;
        this.value = o;
        return this;
    }

    public Constraint lessThan(Object o) {
        this.filterOperator = FilterOperator.LESS_THAN;
        this.value = o;
        return this;
    }

    public Constraint notEqual(Object o) {
        this.filterOperator = FilterOperator.EQUAL;
        this.value = o;
        this.isApplyNot = true;
        return this;
    }

    public Constraint in(Iterable iterable) {
        this.filterOperator = FilterOperator.IN;
        this.value = iterable;
        return this;
    }

    public Constraint hasAnyOf(Iterable iterable) {
        return in(iterable);
    }

    public Constraint startsWith(String prefix) {
        Assert.parametersNotNull("val", new Object[]{prefix});
        this.filterOperator = FilterOperator.EQUAL;
        this.value = Pattern.compile("^" + prefix);
        return this;
    }

    public Constraint startsWithIgnoreCase(String prefix) {
        Assert.parametersNotNull("val", new Object[]{prefix});
        this.filterOperator = FilterOperator.EQUAL;
        this.value = Pattern.compile("^" + prefix, 2);
        return this;
    }
}
