package logicole.common.servers.persistence;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import logicole.common.datamodels.ref.*;
import logicole.common.datamodels.dataref.DataReferenceSubmitter;
import logicole.common.general.logging.Logger;
import logicole.common.general.util.IntrospectionUtil;
import logicole.common.general.util.JSONUtil;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.mongodb.morphia.Datastore;
import org.mongodb.morphia.query.UpdateOperations;
import org.mongodb.morphia.query.UpdateResults;

import java.io.IOException;
import java.util.*;
import javax.annotation.PostConstruct;
import javax.enterprise.context.Dependent;
import javax.inject.Inject;

@Dependent
public abstract class BasePersistedDao<T extends PersistedEntity, PK> implements IGenericPersistedDao<T, PK> {

    @Inject
    protected Logger logger;
    @Inject
    private DataStore datastore;
    @Inject
    private IntrospectionUtil introspectionUtil;
    @Inject
    private JSONUtil jsonUtil;
    @Inject
    private DataReferenceSubmitter dataReferenceSubmitter;


    private final boolean allowDelete;
    protected final Class<T> classType;
    private Refs.References dataRef = null;
    protected String className;
    private String databaseName;

    public BasePersistedDao(Class<T> persistentClass, String databaseName, Refs.References ref) {
        this(persistentClass, databaseName, true);
        this.dataRef = ref;
    }

    public BasePersistedDao(Class<T> persistentClass, String databaseName) {
        this(persistentClass, databaseName, true);
    }

    public BasePersistedDao(Class<T> persistentClass, String databaseName, boolean allowDelete) {
        classType = persistentClass;
        this.allowDelete = allowDelete;
        this.databaseName = databaseName;
    }

    @PostConstruct
    public void postConstruct() {
        datastore.setDatabase(databaseName);
        if (classType != null) {
            className = classType.getSimpleName();
        }
    }
//    public void setMicroservice(IMicroservice microservice) {
//        this.microService = microservice;
//    }

    public T getFromQueryList(List<T> queryList, int i) {
        T retval = null;
        if (!queryList.isEmpty()) {
            retval = queryList.get(i);
        }
        return retval;
    }

    @Override
    public T upsert(T t) {
        T retval = null;
        if (t.getId() == null) {
            insert(t);
        } else {
            t = update(t);
        }
        retval = t;
        return retval;
    }

    @Override
    public T insert(T t) {
        getDatastore().save(t);
        return t;
    }

    public void delete(T t) {
        int previousHash = t.getRefHash();

        t.set_isDeleted(true);
        if (allowDelete) {
            getDatastore().delete(t);
        } else {
            updateIsDeleted(t);
        }
        sendUpdate(t, previousHash);
    }

    protected void updateIsDeleted(T t) {
        t.set_isDeleted(true);
        getDatastore().save(t);
    }

    protected Integer delete(Query query) {
        Integer result;
        org.mongodb.morphia.query.Query<T> mQuery = query.getDecoratedQueryWithCriteria();
        if (allowDelete) {
            result = getDatastore().delete(mQuery).getN();
        } else {
            UpdateOperations<T> ops = getDatabaseOperation();
            ops.set("_isDeleted", true);
            result = getDatastore().update(mQuery, ops).getUpdatedCount();
        }

        return result;
    }

    public void deleteById(PK id) {
        T item = findById(id);
        if (item != null) {
            delete(item);
        }
    }

    @Override
    public T update(T t) {

        int oldRefHash = t.getRefHash();
        getDatastore().save(t);

        sendUpdate(t, oldRefHash);

        return t;
    }

    public T updateReference(T t) {
        getDatastore().save(t);
        return t;
    }

    protected void sendUpdate(T obj, int previousHash) {
        boolean isDeleted = obj.get_isDeleted();
        DataRef ref = obj.getRef();
        if (ref != null && previousHash != ref.getHashValue()) {
            try {
                if (obj != null && ref != null) {
                    String objString = jsonUtil.serialize(ref);
                    String objClassname = introspectionUtil.getClassName(ref);
                    DataReferenceUpdate update = DataReferenceUpdate.create(objClassname, objString, isDeleted);
                    dataReferenceSubmitter.submitUpdate(update, this.dataRef);
                }
            } catch (IOException e) {
                String msg = String.format("Could not serialize %s", obj.getClass());
                logger.warn(msg);
            }
        }
    }

    public Integer update(Query<T> query, UpdateOperations<T> ops) {
        org.mongodb.morphia.query.Query mQuery = query.getDecoratedQueryWithCriteria();
        UpdateResults results = getDatastore().update(mQuery, ops);
        return results.getUpdatedCount();
    }

    @Override
    public T merge(T t) {
        int previousHash = t.getRefHash();
        getDatastore().merge(t);
        sendUpdate(t, previousHash);
        return t;
    }

    @Override
    public List<T> findAll() {
        Query query = getQuery();
        return query.asList();
    }

    public long countAll() {
        Query query = getQuery();
        return query.count();
    }

    public List<T> findByIds(List<String> ids) {
        List<ObjectId> keys = new ArrayList<>();

        Query query = getQuery();
        for (String id : ids) {
            keys.add(new ObjectId(id));
        }

        query.field("_id").hasAnyOf(keys);

        return query.asList();
    }

    @Override
    public T findById(PK id) {
        String sid = id.toString();

        if (!ObjectId.isValid(sid)) {
            throw new IllegalArgumentException("primary key provided was not found");
        }
        ObjectId oid = new ObjectId(sid);

        return getDatastore().find(classType).field("_id").equal(oid).get();

    }

    @Override
    public List<T> query(String queryString) {
        Query query = getQuery();
        return query.asList(queryString);
    }

    public List<T> query(Map<String, ?> fieldFilter) {
        org.mongodb.morphia.query.Query<T> query = getDatastore().createQuery(classType);
        fieldFilter.forEach((key, value) -> {
            query.field(key).equal(value);
        });

        return query.asList();
    }

    public UpdateOperations<T> getDatabaseOperation() {
        return getDatastore().createUpdateOperations(classType);
    }

    Datastore getDatastore() {
        return datastore.getMorphiaDataStore();
    }

    protected void setDatastore(DataStore datastore) {
        this.datastore = datastore;
    }

    protected Query<T> getQuery() {
        return new Query(this.datastore.getMorphiaDataStore(), this.classType, this.allowDelete);
    }

    public T get(Class<?> clazz, ObjectId objectId) {
        return (T) getDatastore().get(clazz, objectId);
    }

    protected MongoCollection<Document> getCollection(String abiCatalogStaging) {
        Datastore ds = this.getDatastore();
        MongoClient client = ds.getMongo();
        String dbName = ds.getDB().getName();
        MongoDatabase mongoDb = client.getDatabase(dbName);
        return mongoDb.getCollection(abiCatalogStaging);
    }

    protected MongoDatabase getMongoDatabase() {
        Datastore ds = this.getDatastore();
        MongoClient client = ds.getMongo();
        String dbName = ds.getDB().getName();
        MongoDatabase mongoDb = client.getDatabase(dbName);
        return mongoDb;
    }

    protected boolean doesCollectionExist(String collectionName) {
        boolean exists = false;
        for (String collection : this.getMongoDatabase().listCollectionNames()) {
            if (collection.equalsIgnoreCase(collectionName)) {
                exists = true;
                break;
            }
        }
        return exists;
    }

}
