package logicole.common.servers.servers;

import logicole.common.api.IMicroserviceApi;

public abstract class Microservice implements IMicroserviceApi {

    private Microservice() {
        name = null;
    }

    public Microservice(String name) {
        this.name = name;
    }

    private final String name;


    public String getName() {
        return name;
    }

}
