package logicole.common.servers.persistence;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import org.mongodb.morphia.Datastore;
import org.mongodb.morphia.query.*;

import java.util.*;
import java.util.function.Consumer;

public class Query<T> implements Cloneable {

    private Datastore dataStore;
    private Class<T> classType;
    private boolean allowDelete = false;
    private List<Constraint> constraints = new ArrayList<>();
    private Map<String, Object> filters = new HashMap<>();
    private int limit = 0;
    private int offset = 0;
    private String order = null;
    private Sort[] sorts = null;
    private Map<String, Boolean> projections = new HashMap<>();
    private String search = null;

    public Query(Datastore dataStore, Class<T> classType, boolean allowDelete) {
        this.dataStore = dataStore;
        this.classType = classType;
        this.allowDelete = allowDelete;
    }

    public Constraint criteria(String s) {
        return field(s);
    }

    public Constraint field(String s) {
        Constraint constraint = new Constraint(this, s);
        this.constraints.add(constraint);
        return constraint;
    }

    public Query filter(String s, Object o) {
        filters.put(s, o);
        return this;
    }

    public Query limit(int i) {
        this.limit = i;
        return this;
    }

    public Query offset(int i) {
        this.offset = i;
        return this;
    }

    public Constraint or(Constraint... constraints) {
        List<Constraint> list = Arrays.asList(constraints);
        removeDuplicates(list);
        Constraint fe = new Constraint(this, list, FilterOperator.OR);
        this.constraints.add(fe);
        return fe;
    }

    public Constraint and(Constraint... constraints) {
        List<Constraint> list = Arrays.asList(constraints);
        removeDuplicates(list);
        Constraint fe = new Constraint(this, list, FilterOperator.AND);
        this.constraints.add(fe);
        return fe;
    }

    private void removeDuplicates(List<Constraint> constraints) {
        this.constraints.removeAll(constraints);
    }

    public Query order(String s) {
        this.order = s;
        return this;
    }

    public Query order(Sort... sorts) {
        this.sorts = sorts;
        return this;
    }

    public Query project(String s, boolean b) {
        projections.put(s, b);
        return this;
    }

    public Query search(String s) {
        this.search = s;
        return this;
    }

    public List<T> asList() {
        org.mongodb.morphia.query.Query<T> morphiaQuery = getMorphiaQuery();
        return morphiaQuery.asList();
    }

    public List<T> asList(String queryString) {

        org.mongodb.morphia.query.Query<T> morphiaQuery = getMorphiaQuery();
        List<MorphiaFieldFilter> fieldFilters = MorphiaFieldFilter.Parse(queryString);

        fieldFilters.forEach(filter -> {
            morphiaQuery.field(filter.fieldName).equal(filter.fieldValue);
        });

        List<T> results = morphiaQuery.asList();
        return results;

    }

    public long count() {
        org.mongodb.morphia.query.Query<T> morphiaQuery = getMorphiaQuery();
        return morphiaQuery.count();
    }

    public Iterable<T> fetch() {
        org.mongodb.morphia.query.Query<T> morphiaQuery = getMorphiaQuery();
        return morphiaQuery.fetch();
    }

    public T get() {
        org.mongodb.morphia.query.Query<T> morphiaQuery = getMorphiaQuery();
        return (T) morphiaQuery.get();
    }


    public T get(FindOptions findOptions) {
        org.mongodb.morphia.query.Query<T> morphiaQuery = getMorphiaQuery();
        return (T) morphiaQuery.get(findOptions);
    }

    public Iterator iterator() {
        org.mongodb.morphia.query.Query<T> morphiaQuery = getMorphiaQuery();
        return morphiaQuery.iterator();
    }

    org.mongodb.morphia.query.Query getDecoratedQuery() {
        org.mongodb.morphia.query.Query<T> morphiaQuery = getMorphiaQuery();
        return morphiaQuery;
    }

    org.mongodb.morphia.query.Query getDecoratedQueryWithCriteria() {
        org.mongodb.morphia.query.Query<T> morphiaQuery = getMorphiaQuery();
        return morphiaQuery;
    }


    public void forEach(Consumer<T> action) {
        org.mongodb.morphia.query.Query<T> morphiaQuery = getMorphiaQuery();
        morphiaQuery.forEach(action);
    }

    public List<String> distinct(String fieldName, BasicDBObject bdo) {
        DBCollection m = this.dataStore.getCollection(this.classType);
        List<String> list = m.distinct(fieldName, bdo);
        return list;
    }

    public T findAndModify(Query<T> query, UpdateOperations<T> ops) {
        org.mongodb.morphia.query.Query<T> morphiaQuery = getMorphiaQuery();
        T updatedDocument = dataStore.findAndModify(morphiaQuery, ops);
        return updatedDocument;
    }

    private org.mongodb.morphia.query.Query<T> getMorphiaQuery() {
        org.mongodb.morphia.query.Query mQuery = this.dataStore.createQuery(classType);
        applyConstraints(mQuery);
        applyFilters(mQuery);
        mQuery.limit(this.limit);
        mQuery.offset(this.offset);

        applySorts(mQuery);
        applyProjections(mQuery);
        if (this.search != null) {
            mQuery.search(this.search);
        }

        return mQuery;
    }

    private void applyFilters(org.mongodb.morphia.query.Query mQuery) {
        if (this.filters != null) {
            for (Map.Entry<String, Object> entry : this.filters.entrySet()) {
                mQuery.filter(entry.getKey(), entry.getValue());
            }
        }
    }

    private void applySorts(org.mongodb.morphia.query.Query mQuery) {
        if (this.order != null) {
            mQuery.order(this.order);
        }
        if (this.sorts != null) {
            for (Sort sort : this.sorts) {
                mQuery.order(sort);
            }
        }
    }

    private void applyProjections(org.mongodb.morphia.query.Query mQuery) {
        if (this.projections != null) {
            for (Map.Entry<String, Boolean> entry : this.projections.entrySet()) {
                mQuery.project(entry.getKey(), entry.getValue());
            }
        }
    }

    private void applyConstraints(org.mongodb.morphia.query.Query<T> morphiaQuery) {
        if (!this.allowDelete) {
            morphiaQuery.and(
                    morphiaQuery.or(
                            morphiaQuery.criteria("_isDeleted").doesNotExist(),
                            morphiaQuery.criteria("_isDeleted").equal(false)
                    )
            );
        }
        for (Constraint fe : constraints) {
            morphiaQuery.and(fe.getCriteria());
        }

    }

}
