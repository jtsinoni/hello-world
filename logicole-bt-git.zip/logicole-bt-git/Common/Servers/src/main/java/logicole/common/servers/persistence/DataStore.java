package logicole.common.servers.persistence;

import com.mongodb.*;
import logicole.common.general.ConfigurationManager;
import logicole.common.general.logging.Logger;
import logicole.common.general.util.StringUtil;
import org.mongodb.morphia.Datastore;
import org.mongodb.morphia.Morphia;

import java.io.IOException;
import java.io.InputStream;
import java.net.UnknownHostException;
import java.util.*;
import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

@ApplicationScoped
public class DataStore {

    private static final String LOG_FORMAT = "DB Hosts: %s, DB Replica-Set: %s, Database: %s";
    private Datastore datastore;


    @Inject
    private ConfigurationManager configurationManager;
    @Inject
    private Logger logger;

    private String mapPackage;
    private String database;


    private String mongoDbHosts = null;

    private String mongoDbRepSet = null;

    private String mongoUserId = null;

    private String mongoUserPw = null;

    private String mongoAdminDb = "admin";

    private String mongoSsl = "true";

    private int mongoConnectTimeoutMS = 30000;

    private int mongoSocketTimeoutMS = 30000;

    private String mongoW = "majority";

    private String mongoJournal = null;

    public DataStore() {
    }

    @PostConstruct
    public void start() throws IOException {
        ClassLoader classLoader = this.getClass().getClassLoader();
        InputStream stream = classLoader.getResourceAsStream("db.properties");

        mongoDbHosts = configurationManager.getMongoHosts();
        mongoDbRepSet = configurationManager.getMongoRepSet();
        mongoUserId = configurationManager.getMongoUserId();
        mongoUserPw = configurationManager.getMongoUserPassword();
        mongoAdminDb = configurationManager.getMongoAdminDb();
        logger.info(String.format(LOG_FORMAT, mongoDbHosts, mongoDbRepSet, database));

        if (mongoAdminDb.isEmpty()) {
            mongoAdminDb = "admin";
        }

        mongoJournal = configurationManager.getMongoJournal();
        mongoW = configurationManager.getMongoW();
        mongoConnectTimeoutMS = configurationManager.getMongoConnectTimeoutMS();
        mongoSocketTimeoutMS = configurationManager.getMongoSocketTimeoutMS();
        mongoSsl = configurationManager.getMongoSsl();

    }

    public Datastore getMorphiaDataStore() {
        if (datastore == null) {
            try {

                List<ServerAddress> hosts = getDmlesHosts();

                MongoClient client;
                if (!StringUtil.isEmptyOrNull(mongoUserId) && !StringUtil.isEmptyOrNull(mongoUserPw) && StringUtil.isEmptyOrNull(mongoDbRepSet)) {
                    List<MongoCredential> credentialList = getDmlesCredentials();
                    client = new MongoClient(hosts, credentialList);
                } else if (!StringUtil.isEmptyOrNull(mongoUserId) && !StringUtil.isEmptyOrNull(mongoUserPw) && !StringUtil.isEmptyOrNull(mongoDbRepSet)) {
                    List<MongoCredential> credentialList = getDmlesCredentials();
                    client = new MongoClient(hosts, credentialList, getClientOptions());
                } else {
                    client = new MongoClient(hosts);
                }

                final Morphia morphia = new Morphia();
                //morphia.mapPackage(mapPackage);
                datastore = morphia.createDatastore(client, database);
                datastore.ensureIndexes();

                logger.debug("Hosts: {}, Replica-Set: {}, Database: {}", mongoDbHosts, mongoDbRepSet, database);
            } catch (UnknownHostException ex) {
                logger.error("{}", ex);
            }

        }
        return datastore;
    }

    public String getConnectionProperties() {
        return String.format("package: %s, database: %s, hosts: %s, replica-set: %s, ssl: %s, connectTimeoutMS: %d, socketTimeoutMS: %d, w:%s, journal: %s",
                mapPackage, database, mongoDbHosts, mongoDbRepSet, mongoSsl, mongoConnectTimeoutMS,
                mongoSocketTimeoutMS, mongoW, mongoJournal);
    }


    protected MongoClientOptions getClientOptions() {
        MongoClientOptions.Builder builder = MongoClientOptions.builder();


        if (!StringUtil.isEmptyOrNull(mongoDbRepSet)) {
            builder.requiredReplicaSetName(mongoDbRepSet);
        }

        if (!StringUtil.isEmptyOrNull(mongoSsl)) {
            Boolean sslEnabled = Boolean.parseBoolean(mongoSsl);
            builder.sslEnabled(sslEnabled);
        }

        if (!StringUtil.isEmptyOrNull(mongoJournal)) {
            if (Boolean.parseBoolean(mongoJournal)) {
                builder.writeConcern(WriteConcern.JOURNALED);
            }
        }

        if (!StringUtil.isEmptyOrNull(mongoW) && mongoW.toUpperCase().equals(ReadConcernLevel.MAJORITY.toString())) {
            if (!StringUtil.isEmptyOrNull(mongoJournal) && Boolean.parseBoolean(mongoJournal)) {
                builder.writeConcern(WriteConcern.MAJORITY.withJournal(true));
            } else {
                builder.writeConcern(WriteConcern.MAJORITY.withJournal(false));
            }
        }


        builder.connectTimeout(mongoConnectTimeoutMS);
        builder.socketTimeout(mongoSocketTimeoutMS);

        return builder.build();
    }

    private List<MongoCredential> getDmlesCredentials() {
        List<MongoCredential> credentialList = new ArrayList<>();

        MongoCredential credential = MongoCredential.createScramSha1Credential(mongoUserId,
                mongoAdminDb,
                mongoUserPw.toCharArray());
        credentialList.add(credential);

        return credentialList;
    }

    private List<ServerAddress> getDmlesHosts() throws UnknownHostException {
        List<ServerAddress> hosts = new ArrayList<>();

        List<String> itemss = Arrays.asList(mongoDbHosts.split("\\s*,\\s*"));
        for (String item : itemss) {
            String[] host = item.split(":", 2);
            String hostName = host[0];
            Integer portNumber = Integer.parseInt(host[1]);
            hosts.add(new ServerAddress(hostName, portNumber));
        }

        return hosts;
    }

    void setMapPackage(String mapPackage) {
        this.mapPackage = mapPackage;
    }

    void setDatabase(String database) {
        this.database = database;
    }

}
