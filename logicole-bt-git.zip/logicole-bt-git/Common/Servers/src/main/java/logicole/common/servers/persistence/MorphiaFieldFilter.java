package logicole.common.servers.persistence;

import java.util.*;

public class MorphiaFieldFilter {

    public static List<MorphiaFieldFilter> Parse(String queryString) {
        List<MorphiaFieldFilter> filterList = new ArrayList<>();

        List<String> filters = new ArrayList<String>(Arrays.asList(queryString.split("&")));

        filters.forEach(filter -> {
            String[] parts = filter.split("=");

            MorphiaFieldFilter newFilter = new MorphiaFieldFilter();
            newFilter.fieldName = parts[0];
            newFilter.fieldValue = parts[1];

            filterList.add(newFilter);
        });

        return filterList;
    }

    public String fieldName;
    public Object fieldValue;

    public MorphiaFieldFilter() {
    }
}

