package logicole.common.servers.persistence;

import logicole.common.datamodels.ref.DataRef;
import org.mongodb.morphia.annotations.PrePersist;

public class PersistedEntityListener {
    @PrePersist
    public void prePersist(PersistedEntity entity) {
        DataRef ref = entity.getRef();
        if (ref != null) {
            entity.setRefHash(ref.getHashValue());
        }
    }
}
