package logicole.common.servers.business;

import logicole.common.datamodels.user.CurrentUserBtRef;

import javax.enterprise.context.RequestScoped;

@RequestScoped
    public class RequestData {

    private CurrentUserBtRef currentUserRef = null;

    public CurrentUserBtRef getCurrentUserRef() {
        return currentUserRef;
    }

    public void setCurrentUserRef(CurrentUserBtRef currentUserRef) {
        this.currentUserRef = currentUserRef;
    }
}
