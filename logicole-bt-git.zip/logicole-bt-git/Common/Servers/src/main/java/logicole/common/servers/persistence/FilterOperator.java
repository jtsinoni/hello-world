package logicole.common.servers.persistence;

public enum FilterOperator {
    EXISTS, GREATER_THAN, GREATER_THAN_OR_EQUAL, LESS_THAN, IN, AND, OR, EQUAL

}
