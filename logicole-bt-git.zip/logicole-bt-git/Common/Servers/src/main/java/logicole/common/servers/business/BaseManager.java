package logicole.common.servers.business;

public abstract class BaseManager {

}
