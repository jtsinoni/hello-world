package logicole.common.servers.rest;

import logicole.common.datamodels.user.CurrentUserBtRef;
import logicole.common.general.util.JSONUtil;
import logicole.common.general.util.StringUtil;
import logicole.common.restserver.http.RequestUtil;
import logicole.common.servers.business.RequestData;

import java.io.IOException;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

@ApplicationScoped
public class MicroserviceRequestUtil {

    @Inject
    private RequestData requestData;
    @Inject
    private RequestUtil requestUtil;
    @Inject
    private JSONUtil jsonUtil;

    public void getCurrentUserFromRequest() throws IOException {
        String currentUser = requestUtil.getHeaderValue(RequestUtil.CURRENT_USER);
        if (!StringUtil.isEmptyOrNull(currentUser)) {
            CurrentUserBtRef ref = jsonUtil.deserialize(currentUser, CurrentUserBtRef.class);
             requestData.setCurrentUserRef(ref);
        }
    }
}
