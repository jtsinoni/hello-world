package logicole.common.servers.persistence;

import logicole.common.datamodels.ref.DataRef;
import logicole.common.general.util.StringUtil;
import org.bson.types.ObjectId;

public interface PersistedEntity {

    String getId();

    void setId(String id);

    void setObjectId(ObjectId id);

    Boolean get_isDeleted();

    void set_isDeleted(Boolean _isDeleted);

    int getRefHash();

    void setRefHash(int refHash);

    default ObjectId getIdFromString(String id) {
        ObjectId objectId;
        if (StringUtil.isBlankOrNull(id)) {
            objectId = new ObjectId();
        } else {
            objectId = new ObjectId(id);
        }
        return objectId;
    }

    default DataRef getRef() {
        return null;
    }
}
