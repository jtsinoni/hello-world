package logicole.common.general.util;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.json.simple.JSONObject;

import java.io.IOException;
import java.util.*;
import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class JSONUtil {

    public <T> T deserialize(String json, Class<T> clazz) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.readValue(json, clazz);
    }

    public String serialize(Object object) throws IOException {

        ObjectMapper mapper = new ObjectMapper();
        return mapper.writeValueAsString(object);

    }
    public String serializeIgnoreNull(Object object) throws IOException {

        ObjectMapper mapper = new ObjectMapper();
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        return mapper.writeValueAsString(object);

    }
    public String toJSONString(Map<String, Object> payloadMap) {
        String retval = JSONObject.toJSONString(payloadMap);
        return retval;
    }

    public <T> List<T> deserializeList(String json, Class<T[]> aClass) throws IOException {

        T[] array = deserialize(json, aClass);

        return Arrays.asList(array);
    }
}