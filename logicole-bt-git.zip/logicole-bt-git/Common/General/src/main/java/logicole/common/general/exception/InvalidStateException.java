package logicole.common.general.exception;

public class InvalidStateException extends ApplicationException {

    public InvalidStateException(String message) {
        super(message);
    }

    public InvalidStateException(String message, Throwable cause) {
        super(message, cause);
    }

}
