package logicole.common.general.exception;

public class InvalidDataException extends ApplicationException {

    public InvalidDataException(String message) {
        super(message);
    }

    public InvalidDataException(String message, Throwable cause) {
        super(message, cause);
    }

}
