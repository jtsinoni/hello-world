package logicole.common.general.util;

import logicole.common.general.exception.FatalProcessingException;

import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.xml.bind.annotation.adapters.HexBinaryAdapter;

@ApplicationScoped
public class HashUtil {

    @Inject
    private JSONUtil jsonUtil;

    public HashUtil() {};

    @Inject
    public HashUtil(JSONUtil jsonUtil) {
        this.jsonUtil = jsonUtil;
    }

    public String getMD5(Object object) {
        MessageDigest digest;
        String retVal = null;
        try {
            String objString = jsonUtil.serialize(object);
            digest = MessageDigest.getInstance("MD5");
            digest.update(objString.getBytes());
            byte[] hash = digest.digest();
            String hex = (new HexBinaryAdapter()).marshal(hash);
            retVal = hex;
        } catch (NoSuchAlgorithmException noAlg) {
            throw new FatalProcessingException("MD5 is not a valid algorithm");
        } catch (IOException e) {
            throw new FatalProcessingException("Failed to deserialize object");
        }

        return retVal;
    }
}
