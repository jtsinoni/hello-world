package logicole.common.general.jms;

import logicole.common.general.logging.Logger;

import java.io.Serializable;
import java.util.Map;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.jms.*;

@ApplicationScoped
public class JmsClient {
    @Inject
    private JMSContext jmsContext;

    @Inject
    private Logger logger;

    public void sendRequest(String request, String destination) {
        Queue queue = jmsContext.createQueue(destination);
        sendRequest(request, queue);
    }

    public void sendRequest(String request, Queue queue) {
        TextMessage textMessage = jmsContext.createTextMessage(request);
        jmsContext.createProducer().send(queue, textMessage);
        logger.info("Sent message to queue");
    }

    public void sendRequestObject(Serializable requestObject, String destination) throws JMSException {
        Topic topic = jmsContext.createTopic(destination);
        ObjectMessage objectMessage = jmsContext.createObjectMessage(requestObject);
        objectMessage.setObject(requestObject);
        sendRequestObject(objectMessage, topic);
    }

    public void sendRequestObject(Serializable requestObject, String destination, Map<String, String> properties) throws JMSException {
        Topic topic = jmsContext.createTopic(destination);
        ObjectMessage objectMessage = jmsContext.createObjectMessage(requestObject);
        objectMessage.setObject(requestObject);
        for (Map.Entry<String,String> entry: properties.entrySet()) {
            objectMessage.setStringProperty(entry.getKey(), entry.getValue());
        }
        sendRequestObject(objectMessage, topic);
    }

    public void sendRequestObject(ObjectMessage objectMessage, Topic topic) throws JMSException {
        JMSProducer producer = jmsContext.createProducer();
        producer.send(topic, objectMessage);
        logger.info("Sent object message to queue");
    }
}
 

