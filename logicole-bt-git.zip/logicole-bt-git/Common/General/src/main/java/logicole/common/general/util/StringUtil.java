package logicole.common.general.util;


import logicole.common.general.logging.Logger;

import java.util.EmptyStackException;
import java.util.UUID;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

@ApplicationScoped
public class StringUtil {
    
    @Inject
    private Logger logger;
    
    public Double convertStringToDouble(String doubleS){
        Double retDouble = null;
        try{
            retDouble = new Double(doubleS);
        }catch(Exception ex){
            logger.error("Error converting string to double: " + ex.getMessage());
            // TODO: Throw user friendly error
            throw new EmptyStackException();            
        }          
        
        return retDouble;
    }    
    
    public Float convertStringToFloat(String floatS){
        Float retFloat = null;
        try{
            retFloat = new Float(floatS);
        }catch(Exception ex){
            logger.error("Error converting string to float: " + ex.getMessage());
            // TODO: Throw user friendly error
            throw new EmptyStackException();            
        }          
        
        return retFloat;
    }
    
    public Integer convertStringToInteger(String intS){
        Integer retInt = null;
        try{
            retInt = Integer.parseInt(intS);
        }catch(Exception ex){
            logger.error("Error converting string to integer: " + ex.getMessage());
            // TODO: Throw user friendly error
            throw new EmptyStackException();            
        }        
        
        return retInt;
    }    

    public Boolean convertStringToBoolean(String value) {
        Boolean retBoolean = null;
        try {
            retBoolean = Boolean.parseBoolean(value);
        } catch (Exception ex) {
            logger.error("Error converting string to boolean: " + ex.getMessage());
            // TODO: Throw user friendly error consistent with other convertStringToXXX methods
            throw new EmptyStackException();
        }
        return retBoolean;
    }
    
    public static boolean isEmptyOrNull(String val){
        boolean isEmpty = false;
        
        if(val == null || val.isEmpty()){
            isEmpty = true;
        }
        
        return isEmpty;
    }
 
    public static boolean isBlankOrNull(String val){
        boolean isBlank = false;
        
        if(val == null || val.trim().length() == 0){
        	isBlank = true;
        }
        
        return isBlank;
    }
    
    public static String getFullName(String first, String last){
        return first + " " + last;
    }

    public String getUUID(){
        UUID uuid = UUID.randomUUID();
        return uuid.toString();
    }
}