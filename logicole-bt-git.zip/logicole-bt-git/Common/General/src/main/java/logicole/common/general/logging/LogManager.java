package logicole.common.general.logging;

import logicole.common.general.ConfigurationManager;
import org.apache.log4j.PropertyConfigurator;

import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Default;
import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;
import javax.inject.Inject;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

@ApplicationScoped
public class LogManager {

    public static final String HISTORY = "appHistoryLogger";
    public static final String DEVELOPER = "developerLogger";
    //private PropertyConfigurator config;
    @Inject
    private ConfigurationManager configurationManager;

    public LogManager(){
    }

    @PostConstruct
    public void postConstruct() {
        try {
            String log4JPropertyFile = System.getenv("JBOSS_HOME") +
                    configurationManager.getLoggingConfigurationFile();
            Properties properties = new Properties();
            System.out.println("log4JPropertyFile " + log4JPropertyFile);
            properties.load(new FileInputStream(log4JPropertyFile));
            PropertyConfigurator.configure(properties);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

/*
    public static Logger getLogger(){
        return new LogManager().getDevelopmentLogger();
    }
*/

    private Logger getDevelopmentLogger(){
        Logger logger = new Logger(DEVELOPER);
        return logger;
    }

    @Produces
    @BusinessTierLog
    Logger getBusinessTierLogger(InjectionPoint ip){
        Logger logger = new Logger(HISTORY);
        return logger;
    }

    @Produces
    @Default
    Logger getDevelopmentLogger(InjectionPoint ip){
        String category = ip.getMember()
                .getDeclaringClass()
                .getName();

//        Logger logger = new Logger(category);
        Logger logger = new Logger(DEVELOPER);

        return logger;
    }

}
