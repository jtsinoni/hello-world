package logicole.common.general.util;

import java.lang.reflect.Proxy;
import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class IntrospectionUtil {

    public String getClassName(Object object) {
        Class<?> clazz = object.getClass();
        return checkForProxy(clazz).getSimpleName();
    }

    public static String getClassName(Class<?> clazz) {
        return checkForProxy(clazz).getSimpleName();
    }

    private static Class<?> checkForProxy(Class<?> clazz) {
        Class<?> retVal = clazz;
        String name = clazz.getSimpleName();

        int indexOf = name.indexOf("Weld");
        if (Proxy.isProxyClass(clazz) || indexOf >= 0) {
            retVal = clazz.getSuperclass();
        }
        return retVal;
    }
}
