package logicole.common.general.util;

import java.beans.*;
import java.lang.reflect.Method;
import java.util.List;

public class MiscUtils {

    /**
     * This methods takes a Bean.class and invokes it's getter and setter
     * methods. Except, if propertiesNotToTest contains the list of properties
     * not to test.
     *
     * Huge help when it comes to code coverage, no need test each individual
     * method
     *
     * @param bean
     * @param propertiesNotToTest
     */
    public static <T> void getterSetterTest(Class<T> bean, List<String> propertiesNotToTest) {
        try {
            BeanInfo beanInfo = Introspector.getBeanInfo(bean);
            PropertyDescriptor[] propertyDescriptors = beanInfo.getPropertyDescriptors();

            Method readMethod = null;
            Method writeMethod = null;
            for (PropertyDescriptor propertyDescriptor : propertyDescriptors) {
                String propertyName = propertyDescriptor.getName();
                if (propertiesNotToTest.contains(propertyName)) {
                    System.out.println("Skipping:" + propertyName);
                    continue;
                }
                 System.out.println("Testing:" + propertyName);

                readMethod = propertyDescriptor.getReadMethod();
                writeMethod = propertyDescriptor.getWriteMethod();
                T beanInstance = bean.newInstance();

                // Invoke read methods
                if (readMethod != null) {
                    readMethod.invoke(beanInstance, new Object[0]);
                }

                // Invoke write methods
                if (writeMethod != null) {
                    Class<?> propertyType = propertyDescriptor.getPropertyType();
                    Object propertyTypeInstance = propertyType.newInstance();

                    writeMethod.invoke(beanInstance, propertyTypeInstance);
                }
            }

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
