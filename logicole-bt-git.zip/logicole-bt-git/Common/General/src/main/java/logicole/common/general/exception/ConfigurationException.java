package logicole.common.general.exception;

public class ConfigurationException extends ApplicationException {

    public ConfigurationException(String message) {
        super(message);
    }

    public ConfigurationException(String message, Throwable cause) {
        super(message, cause);
    }

}
