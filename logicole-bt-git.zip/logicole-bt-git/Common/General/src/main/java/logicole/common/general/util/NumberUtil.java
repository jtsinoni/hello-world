package logicole.common.general.util;

public final class NumberUtil {
   
    public static boolean canParseInteger(String value) {
        boolean canParse = true;
        try {
            int val = Integer.parseInt(value);
        } catch (NumberFormatException ex) {
            canParse = false;
        }
        return canParse;
    }
    
    public static boolean canParseDouble(String value) {
        boolean canParse = true;
        try {
            double val = Double.parseDouble(value);
        } catch (NumberFormatException ex) {
            canParse = false;
        }
        return canParse;
    }
    
    public static boolean canParseFloat(String value) {
        boolean canParse = true;
        try { 
            float val = Float.parseFloat(value);
        } catch (NumberFormatException ex) {
            canParse = false;
        }
        return canParse;
    }
    
}
