package logicole.common.general.exception;

public class FatalProcessingException extends RuntimeException {

    public FatalProcessingException(String message) {
        super(message);
    }

    public FatalProcessingException(String message, Throwable cause) {
        super(message, cause);
    }

}
