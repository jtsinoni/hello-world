package logicole.common.general.util;

import java.util.ArrayList;
import java.util.List;

public class Stack<T> {

    private List<T> items = new ArrayList<>();

    public T pop() {
        T retVal = null;
        if (items.size() > 0) {
            retVal = peek();
            items.remove(0);
        }
        return retVal;
    }

    public T peek() {
        T item = peek(0);
        return item;
    }

    public T peek(int level) {
        T retVal = null;

        if ((items.size() - 1) >= level) {
            retVal = items.get(level);
        }
        return retVal;
    }

    public void push(T item) {
        items.add(0, item);
    }

    public int size() {
        return items.size();
    }
}
