package logicole.common.general.util;

import org.apache.commons.io.IOUtils;

import java.io.IOException;
import java.io.InputStream;
import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class IOUtil {

    public String toStringFromInputStream(InputStream stream) throws IOException {
        return IOUtils.toString(stream);
    }
}
