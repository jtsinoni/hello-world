package logicole.common.general.constants;

public final class DateAndTime {
    public static final String DATE_TIME_PATTERN = "yyyy-MM-dd'T'HH:mm:ss.SSSX";
    public static final String DATE_PATTERN = "yyyy-MM-dd";
    public static final String TIME_PATTERN = "HH:mm:ss.SSSX";
    //public static final String TIMEZONE = "America/New_York";  // TODO: Change to UTC
    public static final String TIMEZONE = "UTC";  
}
