package logicole.common.general.util;

import logicole.common.general.exception.FatalProcessingException;

import java.util.Iterator;
import java.util.Set;
import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.context.spi.CreationalContext;
import javax.enterprise.inject.spi.*;

@ApplicationScoped
public class CdiUtil {

//    @Inject
//    private BeanManager beanManager;

    public <T> T getNamedClass(String name, Class<T> clazz) {
        BeanManager beanManager = CDI.current().getBeanManager();

        Set<Bean<?>> beans = beanManager.getBeans(name);
        if (beans.size() == 0) {
            throw new FatalProcessingException("CDI bean not found - " + name);
        }
        Iterator<?> iterator = beans.iterator();
        Bean<T> bean = (Bean<T>) iterator.next();

        CreationalContext<T> ctx = beanManager.createCreationalContext(bean);
        T expectedBean = (T) beanManager.getReference(bean, clazz, ctx);

        return expectedBean;
    }
}
