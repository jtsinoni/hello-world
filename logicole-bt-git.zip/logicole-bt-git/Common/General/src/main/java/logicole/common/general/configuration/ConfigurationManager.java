package logicole.common.general.configuration;

import com.netflix.config.*;

import java.util.Collections;
import java.util.List;
import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class ConfigurationManager {
    // this can't use dmles logger because it would be a circular dependency

    protected List<String> getDynamicStrings(String key) {
        DynamicStringListProperty listProperty = new DynamicStringListProperty(key, Collections.emptyList());
        return listProperty.get();
    }

    protected String getDynamicString(String key) {
        DynamicStringProperty property = DynamicPropertyFactory.getInstance().getStringProperty(key, "");
        String val = property.get();
        //this.logger.debug(String.format("retrieved value %s for key %s", key, val));
        return val;
    }

    protected boolean getDynamicBoolean(String key, boolean defaultIfNotFound) {
        DynamicBooleanProperty property = DynamicPropertyFactory.getInstance().getBooleanProperty(key, defaultIfNotFound);
        return property.get();
    }

    protected boolean getDynamicBoolean(String key) {
        return getDynamicBoolean(key, false);
    }

    protected int getDynamicInt(String key) {
        DynamicIntProperty property = DynamicPropertyFactory.getInstance().getIntProperty(key, 0);
        return property.get();
    }

    public String getProjectVersion() {
        DynamicStringProperty property = DynamicPropertyFactory.getInstance().getStringProperty("project.version", "1.0-SNAPSHOT");
        return property.get();
    }

    public String getSwaggerHost() {
        DynamicStringProperty property = DynamicPropertyFactory.getInstance().getStringProperty("swagger.host", "localhost");
        return property.get();
    }

    public String getSwaggerPort() {
        DynamicStringProperty property = DynamicPropertyFactory.getInstance().getStringProperty("swagger.port", "8080");
        return property.get();
    }

    public String getSwaggerSchemes() {
        DynamicStringProperty property = DynamicPropertyFactory.getInstance().getStringProperty("swagger.schemes", "http,https");
        return property.get();
    }

    public String getMongoHosts() {
        return getDynamicString("dmles.mongo.hosts");
    }

    public String getLoggingConfigurationFile() {
        return getDynamicString("dmles.logging.configuration.file");
    }

    public String getMongoRepSet() {
        return getDynamicString("dmles.mongo.repset");
    }

    public String getMongoUserId() {
        return getDynamicString("dmles.mongo.user.id");
    }

    public String getMongoUserPassword() {
        return getDynamicString("dmles.mongo.user.pw");
    }

    public String getDmlesAppHost() {
        return getDynamicString("dmles.app.host");
    }

    public int getEsPort() {
        return getDynamicInt("dmles.es.db.port");
    }

    public List<String> getEsHost() {
        return getDynamicStrings("dmles.es.db.host");
    }

    public String getEsVersion() {
        return getDynamicString("dmles.es.db.version");
    }

    public String getEsUserId() {
        return getDynamicString("dmles.es.db.userId");
    }

    public String getEsPassword() {
        return getDynamicString("dmles.es.db.password");
    }

    public String getEsCommunicationProtocol() {
        return getDynamicString("dmles.es.protocol");
    }

    public String getEsKeyStorePath() {
        return getDynamicString("dmles.es.keystore.path");
    }
    public String getEsKeyStorePassword() {
        return getDynamicString("dmles.es.keystore.password");
    }
    public String getMailHost() {
        return getDynamicString("dmles.email.host");
    }

    public String getMailPort() {
        return getDynamicString("dmles.email.port");
    }

    public String getMailProtocol() {
        return getDynamicString("dmles.email.protocol");
    }

    public String getAdminEmail() {
        return getDynamicString("dmles.email.admin.email");
    }

    public int getInvitationExpirationDays() {
        return getDynamicInt("dmles.invitation.expiration.days");
    }

    public int getLoginLockDays() {
        return getDynamicInt("dmles.login.lock.days");
    }

    public int getLoginRelockedDays() {
        return getDynamicInt("dmles.login.relocked.days");
    }

    public int getProfileExpirationDays() {
        return getDynamicInt("dmles.profile.expiration.days");
    }

    public String getMailInviteURL() {
        return getDynamicString("dmles.invitation.url");
    }

    public String getPkiDnUpdateURL() {
        return getDynamicString("dmles.updatePkiDn.url");
    }

    public String getGroupMailInviteURL() {
        return getDynamicString("dmles.groupInvitation.url");
    }

    public int getEsMaxResults() {
        return getDynamicInt("dmles.es.maxResults");
    }

    public String getClusterName() {
        return getDynamicString("dmles.es.cluster.name");
    }

    public String getBtPermissionCheckMode() {
        return getDynamicString("dmles.bt.permission.check");
    }

    public String getMongoSsl() {
        return getDynamicString("dmles.mongo.ssl");
    }

    public int getMongoConnectTimeoutMS() {
        return getDynamicInt("dmles.mongo.connect.timeout.ms");
    }

    public int getMongoSocketTimeoutMS() {
        return getDynamicInt("dmles.mongo.socket.timeout.ms");
    }

    public String getMongoW() {
        return getDynamicString("dmles.mongo.w");
    }

    public String getMongoJournal() {
        return getDynamicString("dmles.mongo.journal");
    }

    public String getMongoAdminDb() {
        return getDynamicString("dmles.mongo.admin.db");
    }

    public boolean getABiDeltaAutoMoveToStagingEnabled() {
        return getDynamicBoolean("dmles.abi.delta.autoMoveToStagingEnabled", true);
    }

    public String getABiUtilitiesGhxExtractUploadRelativePath() {
        return this.getDynamicString("dmles.abi.utilities.etl.ghxExtractUploadRelativePath");
    }

    public String getABiUtilitiesScriptProExtractUploadRelativePath() {
        return this.getDynamicString("dmles.abi.utilities.etl.scriptProExtractUploadRelativePath");
    }

    public String getABiUtilitiesGhxDownloadRelativePath() {
        return this.getDynamicString("dmles.abi.utilities.export.ghxDownloadRelativePath");
    }

    public String getABiTempDirectory() {
        return this.getDynamicString("dmles.abi.tempDirectory");
    }

    public String getFileManagerManagedPath() {
        return getDynamicString("dmles.filemanager.managed.path");
    }

    public String getFileManagerUnManagedPath() {
        return getDynamicString("dmles.filemanager.unmanaged.path");
    }

    public Integer getFileManagerMaxPostSize() {
        return getDynamicInt("dmles.filemanager.file.max.size");
    }

    public List<String> getFileManagerForbiddenFileExtensions() {
        return getDynamicStrings("dmles.filemanager.forbidden.file.extensions");
    }

}
