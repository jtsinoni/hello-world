package logicole.common.general.util;

import java.sql.Timestamp;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class DateUtil {

    public Timestamp getCurrentUTCTimestamp() {
        ZonedDateTime utc = ZonedDateTime.now(ZoneOffset.UTC);
        Date date = Date.from(utc.toInstant());
        return new Timestamp(date.getTime());
    }
    
    public Date getCurrentUTCDate() {
        ZonedDateTime utc = ZonedDateTime.now(ZoneOffset.UTC);
        return Date.from(utc.toInstant());
    }

    public static long getMillis(Date unlockedDate) {
        long millis = 0;

        if(null != unlockedDate){
            millis = unlockedDate.getTime();
        }

        return millis;
    }

    /*
    dateVar: Date to be manipulated
    calendarType: Calendar.YEAR, Calendar.MONTH, Calendar.DATE, Calendar.HOUR, Calendar.MINUTE, Calendar.SECOND
    i: amount to add or subtract from the date
     */
    public Date manipulateDate(Date dateVar, int calendarType, int i){
        Calendar c = Calendar.getInstance();
        c.setTime(dateVar);
        c.add(calendarType, i);
        return c.getTime();
    }

    public long getDaysSince(Date checkDate) {
        Date today = new Date();
        long days = today.getTime() - checkDate.getTime();

        return TimeUnit.DAYS.convert(days, TimeUnit.MILLISECONDS);
    }

    public boolean isDateInPast(Date expirationDate) {
        return expirationDate.before(getCurrentUTCDate());
}

}
