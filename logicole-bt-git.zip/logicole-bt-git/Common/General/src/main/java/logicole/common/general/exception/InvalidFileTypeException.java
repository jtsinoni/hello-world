package logicole.common.general.exception;

public class InvalidFileTypeException extends Exception {

    public InvalidFileTypeException(String message) {
        super(message);
    }

    public InvalidFileTypeException(String message, Throwable cause) {
        super(message, cause);
    }

}
