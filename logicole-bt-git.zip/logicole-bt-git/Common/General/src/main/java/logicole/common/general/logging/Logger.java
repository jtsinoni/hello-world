package logicole.common.general.logging;

import org.slf4j.LoggerFactory;

public class Logger {
    private org.slf4j.Logger logger = null;

    public Logger(String category) {
        logger = LoggerFactory.getLogger(category);
    }

    public void info(String message){
        logger.info(createMessage(message));
    }

    public void info(String message, Object... objects){
        logger.info(createMessage(message), objects);
    }

    public void debug(String message){
        logger.debug(createMessage(message));
    }

    public void debug(String message, Object... objects){
        logger.debug(createMessage(message), objects);
    }


    public void warn(String message){
        logger.warn(createMessage(message));
    }

    public void warn(String message, Object... objects){
        logger.warn(createMessage(message), objects);
    }


    public void error(String message){
        logger.error(createMessage(message));
    }

    public void error(String message, Object... objects){
        logger.error(createMessage(message), objects);
    }


    private String createMessage(String message) {
        return message;  //String.format("LogiCole: %s", message);
    }

    public static Logger getInstance(String category) {
        return new Logger(category);
    }
}
