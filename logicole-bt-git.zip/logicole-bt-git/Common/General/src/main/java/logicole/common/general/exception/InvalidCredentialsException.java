package logicole.common.general.exception;

public class InvalidCredentialsException extends FatalProcessingException {
    public InvalidCredentialsException(String message) {
        super(message);
    }

    public InvalidCredentialsException(String message, Throwable cause) {
        super(message, cause);
    }
}
