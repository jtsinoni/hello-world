package logicole.common.general.util;

public enum FutureRequestStatus {
    DONE,CANCELLED,WAITING;
}
