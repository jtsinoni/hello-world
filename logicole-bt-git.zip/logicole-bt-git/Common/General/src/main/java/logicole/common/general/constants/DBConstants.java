package logicole.common.general.constants;

import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class DBConstants {
    public static final String DB_SYNC = "DBSync";
}
