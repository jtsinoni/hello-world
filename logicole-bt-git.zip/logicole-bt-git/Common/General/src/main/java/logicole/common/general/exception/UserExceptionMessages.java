package logicole.common.general.exception;

public enum UserExceptionMessages {

    GENERIC("There was a problem processing your request. If the problem persists please contact application support personnel"),
    USER_NOT_FOUND("The user profile, %s, is unregistered or not enabled"),
    ;

    private final String message;

    private UserExceptionMessages(String s) {
        this.message = s;
    }

    public boolean equalsMessage(String otherMessage) {
        return (otherMessage == null) ? false : message.equals(otherMessage);
    }

    @Override
    public String toString() {
        return this.message;
    }
    
}
