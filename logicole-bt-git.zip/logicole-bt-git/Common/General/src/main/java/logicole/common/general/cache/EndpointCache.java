package logicole.common.general.cache;

import java.lang.reflect.Field;
import java.util.*;
import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class EndpointCache {
    private Class<?> cachedClass = null; 
    private Map<String, Object> objectMap = Collections.synchronizedMap(new HashMap<>());

    public <T> void clearCache() {
        objectMap.clear();
    }
    // method optimizes the use of the HashMap by providing an initial size 
    public <T> void clearCache(int size) {
        double val = Math.ceil((size / .75) + 1);
        int intVal = (int) val;
        objectMap = Collections.synchronizedMap(new HashMap<>(intVal));
    }

    public <T> void setCachedObject(String key, T value) {
        objectMap.put(key, value);
    }
    
    public <T> T getCachedObject(String key) {
        T result = null;
        
        if (objectMap.containsKey(key)) {
            Object object = objectMap.get(key);
            result = (T) object;
        }
        return result;
    }

    public <T> List<T> getAllCachedObjects() {
        List<T> items = new ArrayList<>();
        Collection<?> values = objectMap.values();
        for (Object value : values) {
            if (value != null) {
                items.add((T) value);
            }
        }
        return items;
    }
    // limited this to no-argument methods for now
    public String getCachedValue(String key, String method) throws NoSuchFieldException, IllegalAccessException {
        Object obj = objectMap.get(key);
        String stringValue = null;
        if (obj != null) {
            Field objField = obj.getClass().getDeclaredField(method);
            Object valueObj = objField.get(obj);
            if (valueObj != null) {
                stringValue =  valueObj.toString();
            }
        }
        return stringValue;
    }
    
    public Class getCachedClass(){
        return cachedClass;
    }
    public void setClass(Class cachedClass) {
        this.cachedClass = cachedClass;
    }

}
