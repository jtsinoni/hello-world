package logicole.common.general.util;

import org.apache.commons.codec.binary.Base64;

import java.io.*;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class FileUtil {

    public String fullPath(String fileName) {
        URL url = Thread.currentThread().getContextClassLoader().getResource(fileName);
        if (url == null) {
            url = ClassLoader.getSystemResource(fileName);
            if (url == null) {
                url = ClassLoader.getSystemClassLoader().getResource(fileName);
            }
        }
        String val = null;
        if (url != null) {
            val = url.getFile();
        }
        return val;
    }

    public List<String> getClasspathFileLines(String fileName)
            throws FileNotFoundException, IOException {
        InputStream inStream = Thread.currentThread().getContextClassLoader().getResourceAsStream(fileName);
        if (inStream == null) {
            inStream = Thread.currentThread().getContextClassLoader().getResourceAsStream("/" + fileName);
            throw new FileNotFoundException(fileName);
        }
        return getFileLines(inStream);
    }

    public String getClasspathFileString(String fileName) throws FileNotFoundException, IOException {
        List<String> fileLines = getClasspathFileLines(fileName);
        return String.join(" ", fileLines);
    }


    public List<String> getFileLines(InputStream stream)
            throws FileNotFoundException, IOException {
        List<String> lines = null;
        if (stream != null) {
            lines = new ArrayList<>();
            BufferedReader bufRead = new BufferedReader(new InputStreamReader(stream));
            String line;
            while ((line = bufRead.readLine()) != null) {
                lines.add(line);
            }
        }
        return lines;
    }

    public String safeBase64Encode(byte[] byteArray) {
        return Base64.encodeBase64URLSafeString(byteArray);
    }

    public String base64EncodeString(byte[] byteArray) {
        String b64str = Base64.encodeBase64String(byteArray);
        return b64str;
    }
}
