package logicole.common.general.configuration;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;


import java.util.List;

@RunWith(MockitoJUnitRunner.class)
public class ConfigurationManagerTestIT {

    private ConfigurationManager mgr = new ConfigurationManager();

    @Test
    public void getProjectVersionTest() {
        String val = mgr.getProjectVersion();
        assertNotNull(val);
        assertEquals("1", val);
    }

    @Test
    public void getSwaggerHostTest() {
        String val = mgr.getSwaggerHost();
        assertNotNull(val);
        assertEquals("ahost", val);
    }

    @Test
    public void getSwaggerPortTest() {
        String val = mgr.getSwaggerPort();
        assertNotNull(val);
        assertEquals("aport", val);
    }

    @Test
    public void getSwaggerSchemesTest() {
        String val = mgr.getSwaggerSchemes();
        assertNotNull(val);
        assertEquals("ascheme", val);
    }

    @Test
    public void getMongoHostsTest() {
        String val = mgr.getMongoHosts();
        assertNotNull(val);
        assertEquals("host", val);
    }

    @Test
    public void getMongoRepSetTest() {
        String val = mgr.getMongoRepSet();
        assertNotNull(val);
        assertEquals("5", val);
    }

    @Test
    public void getMongoUserIdTest() {
        String val = mgr.getMongoUserId();
        assertNotNull(val);
        assertEquals("uid", val);
    }

    @Test
    public void getMongoUserPasswordTest() {
        String val = mgr.getMongoUserPassword();
        assertNotNull(val);
        assertEquals("password", val);
    }

    @Test
    public void getDmlesAppHostTest() {
        String val = mgr.getDmlesAppHost();
        assertNotNull(val);
        assertEquals("apphost", val);
    }

    @Test
    public void getEsPortTest() {
        int val = mgr.getEsPort();
        assertNotNull(val);
        assertEquals(15, val);
    }

    @Test
    public void getEsHostTest() {
        List<String> vals = mgr.getEsHost();
        assertNotNull(vals);
        assertEquals("eshost", vals.get(0));
    }

    @Test
    public void getEsVersionTest() {
        String val = mgr.getEsVersion();
        assertNotNull(val);
        assertEquals("esversion", val);
    }
}
