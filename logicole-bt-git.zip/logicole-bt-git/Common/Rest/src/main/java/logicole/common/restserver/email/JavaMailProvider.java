package logicole.common.restserver.email;

import logicole.common.general.ConfigurationManager;
import logicole.common.general.logging.Logger;

import java.util.Properties;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

@ApplicationScoped
public class JavaMailProvider {

    @Inject
    private Logger logger;
    @Inject
    private ConfigurationManager configurationManager;
    @Inject
    private EmailTransportFacade transport;

    public void sendMail(String subject, String body, InternetAddress from, InternetAddress[] to,
                         InternetAddress[] cc, InternetAddress[] bcc)
            throws MessagingException {

        String host = configurationManager.getMailHost();
        String port = configurationManager.getMailPort();
        String protocol = configurationManager.getMailProtocol();

        if (host == null || "".equals(host)) {
            logger.warn("Email SMTP server configuration is required in order to send emails. Mail not sent");
        } else {
            final Properties properties = new Properties();
            properties.put("mail.transport.protocol", protocol);
            properties.put("mail.smtp.host", host);
            properties.put("mail.smtp.port", port);
            final Message msg = new MimeMessage(Session.getDefaultInstance(properties));

            msg.setFrom(from);

            addRecipients(msg, Message.RecipientType.TO, to);
            addRecipients(msg, Message.RecipientType.CC, cc);
            addRecipients(msg, Message.RecipientType.BCC, bcc);

            msg.setSubject(subject);
            msg.setContent(body,"text/html");
            transport.send(msg);
        }
    }

    private void addRecipients(Message msg, Message.RecipientType type, InternetAddress[] recipients) throws MessagingException {
        if (recipients != null && recipients.length > 0) {
            msg.setRecipients(type, recipients);
        }
    }
}
