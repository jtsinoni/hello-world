package logicole.common.restserver.email;

import logicole.common.general.ConfigurationManager;

import java.io.InputStream;
import javax.mail.MessagingException;
import javax.mail.internet.MimeBodyPart;
import javax.xml.bind.ValidationException;


public class EmailMessageBuilder {


    private EmailMessage message = new EmailMessage();

    private void setFrom() {
        ConfigurationManager configurationManager = new ConfigurationManager();
        message.from = configurationManager.getAdminEmail();
    }

    public EmailMessageBuilder addTo(String to) {
        message.to.add(to);
        return this;
    }

    public EmailMessageBuilder addCC(String cc) {
        message.cc.add(cc);
        return this;
    }

    public EmailMessageBuilder addBCC(String bcc) {
        message.bcc.add(bcc);
        return this;
    }

    public EmailMessageBuilder setSubject(String subject) {
        message.subject = subject;
        return this;
    }

    public EmailMessageBuilder addAttachment(InputStream is) throws MessagingException {
        message.attachments.add(new MimeBodyPart(is));
        return this;
    }

    public EmailMessageBuilder setBody(String body) {
        message.body = body;
        return this;
    }

    public EmailMessage build() throws ValidationException {

        this.setFrom();

        if (message.from == null ||
                message.to == null ||
                message.subject == null) {
            throw new ValidationException("Email messages must contain from, to and subject");
        }
        return message;
    }
}
