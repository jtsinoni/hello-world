package logicole.common.restserver.email;

import javax.enterprise.context.ApplicationScoped;
import javax.mail.*;

@ApplicationScoped
public class EmailTransportFacade {

    public void send(Message msg) throws MessagingException {
        Transport.send(msg);
    }
}
