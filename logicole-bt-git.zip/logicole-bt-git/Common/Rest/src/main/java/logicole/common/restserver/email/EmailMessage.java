package logicole.common.restserver.email;

import java.util.ArrayList;
import java.util.List;
import javax.mail.internet.MimeBodyPart;

public class EmailMessage {
    public List<String> to = new ArrayList<>();
    public String from;
    public List<String> cc = new ArrayList<>();
    public List<String> bcc = new ArrayList<>();
    public String subject;
    public List<MimeBodyPart> attachments = new ArrayList<>();
    public String body;

}
