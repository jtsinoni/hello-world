package logicole.common.restserver.http;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

@RequestScoped
public class RequestUtil {

    public static final String CURRENT_USER = "CurrentUser";

    @Inject
    private HttpServletRequest httpServletRequest;

    public static final String CLIENT_IP_ADDRESS = "X-Forwarded-For";

    public String getInvitationId(){
        return getHeaderValue("InvitationId");
    }

    public String getUpdateId() {
        return getHeaderValue("UpdateId");
    }

    public String getInvitationType() { return getHeaderValue("InvitationType"); }

    public String getHeaderValue(String headerName){

        String retVal = null;
        if (httpServletRequest != null) {
            retVal = httpServletRequest.getHeader(headerName);
        }
        return retVal;

    }

    public String getLastLoginIP() { return getHeaderValue(CLIENT_IP_ADDRESS);   }

    public int getNestLevel() {
        String nestLevel = getHeaderValue("NestLevel");
        if (nestLevel == null) return 0;

        int i = Integer.parseInt(nestLevel);
        return i;
    }
}
