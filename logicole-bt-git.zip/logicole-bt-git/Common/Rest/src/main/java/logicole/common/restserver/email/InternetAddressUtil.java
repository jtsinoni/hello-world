package logicole.common.restserver.email;

import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;

@ApplicationScoped
public class InternetAddressUtil {

    public InternetAddress toInternetAddress(String address) throws AddressException {
        return new InternetAddress(address);
    }

    public InternetAddress[] toInternetAddress(List<String> list) throws AddressException {
        InternetAddress[] addresses = new InternetAddress[list.size()];
        int i = 0;

        for (String item: list) {
            InternetAddress address = new InternetAddress(item);
            addresses[i] = address;
            i++;
        }
        return addresses;
    }

}
