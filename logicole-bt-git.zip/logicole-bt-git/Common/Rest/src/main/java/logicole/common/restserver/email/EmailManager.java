package logicole.common.restserver.email;

import logicole.common.general.ConfigurationManager;
import logicole.common.general.logging.Logger;

import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.mail.MessagingException;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.xml.bind.ValidationException;

@ApplicationScoped
public class EmailManager {

    @Inject
    private JavaMailProvider mailProvider;
    @Inject
    private InternetAddressUtil internetAddressUtil;
    @Inject
    private ConfigurationManager configurationManager;
    @Inject
    private Logger logger;

    private InternetAddress fromEmailAddress = null;

    @PostConstruct
    void init(){
        String adminEmail = configurationManager.getAdminEmail();
        try {
            fromEmailAddress = internetAddressUtil.toInternetAddress(adminEmail);
        } catch (AddressException e) {
            logger.warn("A valid 'from' email address could not be established for the LogiCole system");
        }
    }

    public void sendMessageWithBuilder(EmailMessageBuilder builder) throws MessagingException, ValidationException {
        EmailMessage msg = builder.build();
        sendMessage(msg);
    }

    public void sendMessage(EmailMessage message) throws MessagingException {

        if (fromEmailAddress == null){
            logger.warn("A valid 'from' email address has not been established for the LogiCole system. Email NOT sent.");
            return;
        }

        mailProvider.sendMail(
                message.subject,
                message.body,
                fromEmailAddress,
                internetAddressUtil.toInternetAddress(message.to),
                internetAddressUtil.toInternetAddress(message.cc),
                internetAddressUtil.toInternetAddress(message.bcc)
        );
    }

}
