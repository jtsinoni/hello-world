package logicole.common.restserver.logging;

import logicole.common.general.logging.Logger;

import javax.enterprise.context.ApplicationScoped;
import javax.interceptor.InvocationContext;

@ApplicationScoped
public class MethodLogger {

    public void invoke(Logger logger, InvocationContext ctx) throws Exception {
        try {
            logger.info("Starting method {}", ctx.getMethod());
        }catch(Exception e){
            logger.error("Error method {}", ctx.getMethod());
            logger.error(e.toString());
            logger.error(e.getMessage(), e);
            throw e;
        }finally{
            logger.info("Finishing method {}", ctx.getMethod());
        }
    }
}
