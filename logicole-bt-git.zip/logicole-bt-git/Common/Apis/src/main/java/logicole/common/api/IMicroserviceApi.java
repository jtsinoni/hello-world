package logicole.common.api;

import logicole.common.datamodels.HealthCheckResult;
import logicole.common.datamodels.VersionInformation;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public interface IMicroserviceApi {

    @GET
    @Path("/checkHealth")
    HealthCheckResult checkHealth();

    @GET
    @Path("/getVersionInformation")
    VersionInformation getVersionInformation();
}
