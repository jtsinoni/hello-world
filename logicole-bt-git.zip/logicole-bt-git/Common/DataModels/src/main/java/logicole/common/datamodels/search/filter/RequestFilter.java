package logicole.common.datamodels.search.filter;

import java.util.ArrayList;
import java.util.List;

public class RequestFilter {
    public String operator;
    public List<FilterElement> fieldValues  = new ArrayList<>();
    public FilterElement fromDate;
    public FilterElement toDate;
    public FilterElement fromValue;
    public FilterElement toValue;

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("operator:");
        sb.append(operator);
        sb.append("|");
        for (FilterElement entry: fieldValues) {
            sb.append(entry.field + ":" + entry.value + "||");
        }
        return sb.toString();
    }
}
