package logicole.common.datamodels.equipment;


public class Components {
    public Integer cMeID;
    public String cMeEcnID;
    public Integer cMEItemSerial;
    public String cItemID;
    public String cDeviceText;
    public Integer cManuOrgSerial;
    public String cOrgName;
    public String cMeManufModelID;
    public String cMeMfgSerialID;
    public Integer cManufMdlSerID;
    public String cManufMdlComnID;
    public Double cTotalAcqCost;
    public String nameplateModel;
    public String federalSupplyClass;
}