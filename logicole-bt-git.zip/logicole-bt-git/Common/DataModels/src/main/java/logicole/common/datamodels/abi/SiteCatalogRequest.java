package logicole.common.datamodels.abi;

import java.io.Serializable;

public class SiteCatalogRequest implements Serializable {
    private String requestId;
    private String requestType;
    private String siteCatalogId;
    private String enterpriseItemIdentifier;

    public SiteCatalogRequest() {
    }

    public SiteCatalogRequest(String requestId, String requestType, String siteCatalogId, String enterpriseItemIdentifier) {
        this.requestId = requestId;
        this.requestType = requestType;
        this.siteCatalogId = siteCatalogId;
        this.enterpriseItemIdentifier = enterpriseItemIdentifier;
    }

    public static SiteCatalogRequest create(String requestId, String requestType, String siteCatalogId, String enterpriseItemIdentifier) {
        return new SiteCatalogRequest(requestId, requestType, siteCatalogId, enterpriseItemIdentifier);
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getRequestType() {
        return requestType;
    }

    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    public String getSiteCatalogId() {
        return siteCatalogId;
    }

    public void setSiteCatalogId(String siteCatalogId) {
        this.siteCatalogId = siteCatalogId;
    }

    public String getEnterpriseItemIdentifier() {
        return enterpriseItemIdentifier;
    }

    public void setEnterpriseItemIdentifier(String enterpriseItemIdentifier) {
        this.enterpriseItemIdentifier = enterpriseItemIdentifier;
    }
}
