package logicole.common.datamodels.equipment;


public class LocationInventory {
    public String building;
    public String roomFloorNum;
    public String room;
    public String pltPermntLocTx;
    public String onlnEquipLoanDt;
    public String onlnEquipDayQty;
    public String eqpmtInvMthdTx;
    public String eqptInvReasonTx;
    public String inacctSerial;
    public String locID;
    public String subLocID;
    public String equipmentReturnDate;
}