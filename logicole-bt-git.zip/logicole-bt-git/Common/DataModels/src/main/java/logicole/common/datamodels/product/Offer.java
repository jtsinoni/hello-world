package logicole.common.datamodels.product;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import logicole.common.datamodels.ref.DataRef;
import logicole.common.datamodels.ref.ReferencedData;
import logicole.common.general.constants.DateAndTime;

import java.util.Date;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Offer  extends ReferencedData {
    public String id;
    public String enterpriseItemIdentifier;
    public String packageUnit;
    public Integer packageQuantity;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateAndTime.DATE_TIME_PATTERN)
    public Date effectiveDate;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateAndTime.DATE_TIME_PATTERN)
    public Date expirationDate;
    public String gtin;
    public Integer maximumOrderQuantity;
    public Integer minimumOrderQuantity;
    public Integer multipleOrderQuantity;
    public String nsn;
    public String organizationIdentifier;
    public String packageUnitDescription;
    public Double price;
    public String pricingAgreementIdentifier;
    public String pricingAgreementType;
    public String sellerName;
    public String sellerType;
    public String sellerProductIdentifier;
    public String enterpriseProductIdentifier;
    public Product product = new Product();

    @Override
    @JsonIgnore
    public DataRef getRef() {
        OfferRef ref = new OfferRef();
        ref.id = id;
//        ref.sellerId = sellerId;
        ref.sellerId = sellerName;
        ref.sellerName = sellerName;
        ref.productId = product.id;
        ref.productDescription = product.fullDescription;
        ref.manufacturer = product.manufacturer;
        ref.sellerProductIdentifier = sellerProductIdentifier;
        return ref;
    }
}
