package logicole.common.datamodels.finance;

import logicole.common.datamodels.general.FundType;
import logicole.common.datamodels.ref.DataRef;

import java.util.Objects;

public class FundingSourceRef extends DataRef {
    public FundType fundType;
    public FinancialSystemRef financialSystemRef;

    @Override
    protected int generateHashCode() {
        return Objects.hash(id, name, fundType, financialSystemRef);
    }
}
