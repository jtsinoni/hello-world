package logicole.common.datamodels.order.cart;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import logicole.common.datamodels.order.buyer.BuyerRef;
import logicole.common.datamodels.user.CurrentUserBtRef;

import java.util.ArrayList;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CartDTO {
    public String id = "";
    public BuyerRef buyerRef = new BuyerRef();
    public List<CartSellerItemsDTO> sellerGroups = new ArrayList<>();
}
