package logicole.common.datamodels.finance;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.ArrayList;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class FinancialSystem {
    public String id;
    public String name;
    public String description;
    public String status;
    public List<FundingSourceFieldConfig> fields = new ArrayList();

}
