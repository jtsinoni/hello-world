package logicole.common.datamodels.general;

public class Address {
    public Boolean isPrimary;
    public String title;
    public String line1;
    public String line2;
    public String city;
    public String state;
    public String zip;
    public String country;
}
