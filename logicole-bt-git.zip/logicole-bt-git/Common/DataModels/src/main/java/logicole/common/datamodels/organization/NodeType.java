package logicole.common.datamodels.organization;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class NodeType {
    public static final String CUSTOMER = "Customer";
    public static final String ORGANIZATION = "Organization";
    public static final String SITE = "Site";
    public static final String REGION = "Region";
    public static final String SERVICE = "Service";
    public static final String AGENCY = "Agency";
    public static final String ROOT = "Root";

    public String id;
    public String name;
    public Integer level;
}
