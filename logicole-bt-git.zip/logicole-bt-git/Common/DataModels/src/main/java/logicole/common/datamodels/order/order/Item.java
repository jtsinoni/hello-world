package logicole.common.datamodels.order.order;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import logicole.common.datamodels.finance.FundingNodeRef;
import logicole.common.datamodels.product.Offer;
import logicole.common.datamodels.product.Product;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Item {
    public Integer orderQuantity;
    public Integer requestedQuantity;
    public Integer remainingQuantity;
    public Integer cancelledQuantity;
    public Integer receivedQuantity;
    public Double price;
    public String documentNumber;
    public Integer lineNumber;
    public Integer fiscalYear;
    public FundingNodeRef fundingNodeRef;
    public Product product;
    public Offer offer;

}
