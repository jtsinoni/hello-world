package logicole.common.datamodels.abi;

import java.util.ArrayList;
import java.util.List;

public class PackagingDetail {

    public String enterprisePackageIdentifier;
    public String gtin;
    public List<String> otherPackageIdentifiers = new ArrayList<>();
    public String packageUnit;
    public Integer packageQuantity;
    public String gudidIdentifierType;
    public List<String> barcodes = new ArrayList<>();
    public String packageUnitText;
    public String packageUnitDescription;
    public Integer doseOrUseCount;
    public Integer innerPackMultiple;
    public List<String> nsn = new ArrayList<>();
    
    public PackagingDetail() { }
    
    public PackagingDetail(PackagingDetail source) {
        this.enterprisePackageIdentifier = source.enterprisePackageIdentifier;
        this.gtin = source.gtin;
        this.packageUnit = source.packageUnit;
        this.packageQuantity = source.packageQuantity;
        this.gudidIdentifierType = source.gudidIdentifierType;
        
        if (source.otherPackageIdentifiers != null) {
            for (String pi : source.otherPackageIdentifiers) {
                this.otherPackageIdentifiers.add(pi);
            }
        }
        
        if (source.barcodes != null) {
            for (String bd : source.barcodes) {
                this.barcodes.add(bd);
            }
        }
        
        this.packageUnitText = source.packageUnitText;
        this.packageUnitDescription = source.packageUnitDescription;
        this.doseOrUseCount = source.doseOrUseCount;
        this.innerPackMultiple = source.innerPackMultiple;
        
        if (source.nsn != null) {
            for (String nsn : source.nsn) {
                this.nsn.add(nsn);
            }
        }
    }
}
