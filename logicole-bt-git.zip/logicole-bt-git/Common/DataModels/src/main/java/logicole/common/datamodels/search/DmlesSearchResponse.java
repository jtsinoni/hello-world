package logicole.common.datamodels.search;

import java.util.LinkedHashMap;
import java.util.Map;

public class DmlesSearchResponse {
    public String total;
    public Long took;
    public Field hits = new Field();
    public Map<String, Map<String, Object>> aggregations = new LinkedHashMap<>();

}
