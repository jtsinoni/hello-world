package logicole.common.datamodels.notification;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.Date;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ApplicationNotification {
    public String id;
    public String displayType;
    public String name;
    public String content;
    public Date startDate;
    public Date endDate;
    public String updateBy;
    public Date updateDate;
    public Boolean  isActive;
}
