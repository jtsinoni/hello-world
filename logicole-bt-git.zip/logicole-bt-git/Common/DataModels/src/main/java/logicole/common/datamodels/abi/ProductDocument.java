package logicole.common.datamodels.abi;

public class ProductDocument {
    public String documentType;
    public String documentName;
    public String fileName;
    public String documentURL;
    
    public ProductDocument() {
    
    }
    
    public ProductDocument(ProductDocument source) {
        this.documentType = source.documentType;
        this.documentName = source.documentName;
        this.fileName = source.fileName;
        this.documentURL = source.documentURL;
    }
}
