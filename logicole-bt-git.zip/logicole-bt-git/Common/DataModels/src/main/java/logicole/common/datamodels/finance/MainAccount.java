package logicole.common.datamodels.finance;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class MainAccount {
    public String  id;
    public String  code;
    public String  description;
    public String  departmentRegularCode;
    public Boolean isFederal;
    public String  status;

//    public String  id;
//    public String  code;
//    public String  type;
//    public String  name;
//    public String  description;
//    public Boolean isFederal;
}
