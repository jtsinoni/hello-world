package logicole.common.datamodels.user;

import java.util.Date;

public class GroupInvitationProfileTableData {
    public String id;
    public String profileId;
    public String invitationStatus;
    public String pkiDn;
    public String profileName;
    public String lastName;
    public String firstName;
    public String email;
    public String managedByNodeRefName;
    public Date lastLoginDate;
    public Date updatedDate;
}
