package logicole.common.datamodels.organization;

import logicole.common.datamodels.ref.DataRef;

import java.util.Objects;

public class OrgRef extends DataRef {
    public static String orgId;

    @Override
    protected int generateHashCode() {
        return Objects.hash(id, name);
    }
}
