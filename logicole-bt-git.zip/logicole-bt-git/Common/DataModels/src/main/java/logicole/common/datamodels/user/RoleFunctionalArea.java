package logicole.common.datamodels.user;

import java.util.List;

public class RoleFunctionalArea {
    
    public String functionalArea;
    public List<Permission> permissions;
    
}
