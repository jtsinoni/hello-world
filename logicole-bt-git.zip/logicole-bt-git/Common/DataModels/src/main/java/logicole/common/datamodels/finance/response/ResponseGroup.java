package logicole.common.datamodels.finance.response;

import logicole.common.datamodels.finance.FundingNodeRef;
import logicole.common.datamodels.finance.ProcessingBalance;

import java.util.ArrayList;
import java.util.List;

public class ResponseGroup {

    public FundingNodeRef fundingNodeRef;
    public List<ResponseItem> responseItems = new ArrayList<>();
    public List<ProcessingBalance> endingBalances = new ArrayList<>();

}
