package logicole.common.datamodels.user;

public interface NamedItem {
    
    public String getName();
    
}
