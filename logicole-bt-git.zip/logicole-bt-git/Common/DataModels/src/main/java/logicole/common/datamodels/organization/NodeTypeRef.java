package logicole.common.datamodels.organization;

import logicole.common.datamodels.ref.DataRef;

import java.util.Objects;

public class NodeTypeRef extends DataRef {
    public Integer level;

    @Override
    protected int generateHashCode() {
        return Objects.hash(id, name, level);
    }
}