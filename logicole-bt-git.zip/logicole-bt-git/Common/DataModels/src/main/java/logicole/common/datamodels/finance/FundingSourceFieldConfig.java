package logicole.common.datamodels.finance;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class FundingSourceFieldConfig {
    public String name;
    public FundingSourceFieldType type;
    public String label;
    public int position;
    public String dataType;
    public int length;
    public String defaultValue;
    public Boolean isRequired;
    public Boolean isEditable;
    public String validation;
}
