package logicole.common.datamodels.finance;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SubAllocationHolder{

    public String  id;
    public String  code;
    public String  description;
    public String  limitCode;
    public String  financialSystem;
    public String  status;
}
