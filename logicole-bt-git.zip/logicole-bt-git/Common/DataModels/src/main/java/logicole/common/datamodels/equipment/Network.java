package logicole.common.datamodels.equipment;


public class Network {
    public String operatingSystem;
    public String connectedToLan;
    public String machineName;
    public String ipv4Address;
    public String ipv4Address2;
    public String ipv6Address;
    public String ipv6Address2;
    public String macAddress;
    public String applicationEntityTitle;
    public String connectionType;
    public String wirelessFrequency;
    public String dateAtoIssued;
    public String dateAtoExpires;
}