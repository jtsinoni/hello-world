package logicole.common.datamodels.order.cart;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import logicole.common.datamodels.order.buyer.BuyerRef;
import logicole.common.datamodels.user.CurrentUserBtRef;


import java.util.ArrayList;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class UserCart {
    public String id;
    public CurrentUserBtRef userRef = new CurrentUserBtRef();
    public BuyerRef buyerRef = new BuyerRef();
    public List<CartItem> items = new ArrayList<>();

}
