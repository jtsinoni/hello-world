package logicole.common.datamodels.organization;

import java.util.ArrayList;
import java.util.List;

public class NodeDetail {
    public String id;
    public String guid;
    public List<String> children;
    public String parent;
    public String name;
    public String milServiceId;
    public String providerCode;
    public Boolean isPrimaryHost;
    public String orgId;
    public String orgRef;
    public String parentRef;
    public Integer treeLevel;
    public NodeTypeRef nodeTypeRef;
    public List<ServiceProviderRef> serviceProviderRefs = new ArrayList<>();




}
