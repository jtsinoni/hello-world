package logicole.common.datamodels.product;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CommodityClass{
    public String id;
    public String commodityClassName;
    public String commodityType;
    public String militaryServiceCode;
}
