package logicole.common.datamodels.user;

public enum UserStatus {
    
    ACTIVE("Active"),
    DELETED("Deleted"),
    DENIED("Denied"),
    EXPIRED("Expired"),
    INACTIVE("Inactive"),
    LOCKED("Locked"),
    RELOCKED("Relocked"),
    PENDING("Pending"),
    REJECTED("Rejected"),
    CANCELLED("Cancelled"),
    SUSPENDED("Suspended");

    private final String userStatus;

    UserStatus(String userStatus) {
        this.userStatus = userStatus;
    }
}
