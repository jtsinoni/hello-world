package logicole.common.datamodels.user;

public class AssignedPermission {

    public String name;
    public boolean allowed;
    public PermissionRef permissionRef;
    public Permission permission;

}
