package logicole.common.datamodels.order.buyer;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import logicole.common.datamodels.general.Address;
import logicole.common.datamodels.general.Contact;
import logicole.common.datamodels.order.AuthorizedSupplier;
import logicole.common.datamodels.organization.NodeRef;
import logicole.common.datamodels.ref.DataRef;
import logicole.common.datamodels.ref.ReferencedData;
import logicole.common.datamodels.sale.seller.SellerRef;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Buyer extends ReferencedData {

    public String id;
    public String name;
    public String description;
    public Boolean isVerifyReceipts;
    public Boolean isVerifyOrders;
    public Boolean isIssueIndicator;
    public Boolean isRetired;
    public String drugEnforcementData;
    public String acceptedDocumentType;
    public Float maxOrderLimit;
    public String createdBy;
    public Date createdDate;
    public String updatedBy;
    public Date updatedDate;
    public Boolean _isDeleted;

    public NodeRef currentNodeRef = new NodeRef();
    public NodeRef managedByNodeRef = new NodeRef();

    public List<Address> Address = new ArrayList<>();
    public List<Contact> Contact = new ArrayList<>();
    public List<SellerRef> sellerRefs = new ArrayList<>();

    @Override
    @JsonIgnore
    public DataRef getRef() {
        BuyerRef ref = new BuyerRef();
        ref.id = id;
        ref.name = name;
        return ref;
    }

}
