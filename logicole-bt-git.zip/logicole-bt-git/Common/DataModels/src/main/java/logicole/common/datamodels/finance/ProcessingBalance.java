package logicole.common.datamodels.finance;

import logicole.common.datamodels.finance.response.Balances;

import java.util.Date;

public class ProcessingBalance {
    public FundingNodeRef fundingNodeRef;
    public Balances balances;
    public Double availableBalance = 0d;
    public Double consumptionRate = 0d;
    public Date exhaustionDate;
}
