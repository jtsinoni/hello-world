package logicole.common.datamodels.communications;

import java.util.ArrayList;
import java.util.List;

public class CommunicationRequest {

    public List<OutputFileGroup> outputFileGroups = new ArrayList<>();

}
