package logicole.common.datamodels.equipment;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class EquipmentRecordStatistics {
    public Long totalActiveRecordCount;
    public Long totalActiveAccoutableRecordCount;
    public Long totalActiveMaintenanceRequiredRecordCount;

    public Double totalActiveEquipmentRecordCost;

}

