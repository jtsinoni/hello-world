package logicole.common.datamodels.finance.request;

import logicole.common.datamodels.general.EventType;
import logicole.common.datamodels.general.EventSubType;

import java.util.List;

public class CommonFinanceRequest {

    public EventType eventType;
    public EventSubType eventSubType;
    public List<RequestGroup> requestGroups;

}
