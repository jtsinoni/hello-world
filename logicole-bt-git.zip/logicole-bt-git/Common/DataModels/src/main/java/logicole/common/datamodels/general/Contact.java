package logicole.common.datamodels.general;

public class Contact {
    public Boolean isDefault;
    public String firstName;
    public String lastName;
    public String title;
    public String dutyTitle;
    public String mobilePhone;
    public String workPhone;
    public String email;
    public String website;

}
