package logicole.common.datamodels.user;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.Date;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Permission {
    public String id = null;
    public String name = null;
    public String functionalArea = null;
    public String description = null;
    public Date updatedDate = null;
    public String updatedBy = null;
    public Boolean active;    
    public List<EndpointRef> endpointRefs;
    public List<StateRef> stateRefs;
    public List<ElementRef> elementRefs;
}
