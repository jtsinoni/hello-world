package logicole.common.datamodels.search.util;

import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class QueryStringCleanup {

    private static final String WILDCARD_PATTERN = "(([\\S*])+)";

    // Query reserved characters are: + - = && || > < ! ( ) { } [ ] ^ " ~ * ? : \ /
    private static final String ESCAPE_PATTERN = "([\\+\\-\\=\\&\\|\\!\\(\\)\\{\\}\\[\\]\\^\\\\\"\\~\\*\\?\\:\\/])";

    // < and > can’t be escaped the only way to prevent from attempting to create a range query is to remove them
    private static final String REMOVE_PATTERN = "([\\>\\<])";

    public String cleanQueryString(String inString) {
        inString = inString.replaceAll(REMOVE_PATTERN,"");
        inString = inString.replaceAll(ESCAPE_PATTERN,"");
        return inString;
    }

    public String escapeQueryString(String inString) {
        inString = inString.replaceAll(REMOVE_PATTERN,"");
        inString = inString.replaceAll(ESCAPE_PATTERN,"\\\\$1");
        return inString;
    }

    public String addWildcard(String inString) {
        return inString.replaceAll(WILDCARD_PATTERN,"*$1*");
    }

    public String addTrailingWildcard(String inString) {
        return inString.replaceAll(WILDCARD_PATTERN,"$1*");
    }
}
