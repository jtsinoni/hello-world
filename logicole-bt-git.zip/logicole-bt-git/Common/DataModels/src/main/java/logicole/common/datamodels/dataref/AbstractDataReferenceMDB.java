package logicole.common.datamodels.dataref;

import com.fasterxml.jackson.databind.ObjectMapper;
import logicole.common.datamodels.ref.DataReferenceUpdate;
import logicole.common.general.logging.Logger;

import java.io.IOException;
import javax.inject.Inject;
import javax.jms.*;

public abstract class AbstractDataReferenceMDB implements MessageListener {
    @Inject
    protected Logger logger;

    protected String className;

    public AbstractDataReferenceMDB() {
        className = this.getClass().getSimpleName();
    }

    @Override
    public void onMessage(Message message) {

//        String jmsType = null;
//        try {
//            jmsType = message.getJMSType();
//        } catch (JMSException e) {
//            jmsType = "Unknown";
//        }
//
//        if (jmsType == null){
//            jmsType = "Unknown";
//        }
//
//        switch (jmsType) {
//            case "Unknown":
                processDataReferenceUpdateMessage(message);
//                break;
//            case "BusinessEvent":
//                processBusinessEventMessage(message);
//                break;
//        }
    }

//    private void processBusinessEventMessage(Message message) {
//        if (message instanceof ObjectMessage) {
//            ObjectMessage objMessage = (ObjectMessage) message;
//            Object obj = null;
//            try {
//                obj = objMessage.getObject();
//            } catch (JMSException e) {
//                throw new RuntimeException(e);
//            }
//            BusinessEvent businessEvent = (BusinessEvent) obj;
//            try {
//                processBusinessEvent(businessEvent, message.getJMSReplyTo());
//            } catch (JMSException e) {
//                throw new RuntimeException("Error processing business event", e);
//            }
//        }else{
//            throw new RuntimeException("BusinessEvent message in JMS queue was not of type ObjectMessage");
//        }
//    }

//    protected void processBusinessEvent(BusinessEvent businessEvent, Destination jmsReplyTo) {
//        logger.info("!!!!!! Override this method in your particular MDB");
//    }

    private void processDataReferenceUpdateMessage(Message message) {
        DataReferenceUpdate dataReferenceUpdate = null;

        try {
            if (message instanceof TextMessage) {
                TextMessage textMessage = (TextMessage) message;
                String messageText = textMessage.getText();
                ObjectMapper mapper = new ObjectMapper();
                try {
                    dataReferenceUpdate = mapper.readValue(messageText, DataReferenceUpdate.class);
                } catch (IOException e) {
                    logger.error(className + ", IOException in onMessage() for TextMessage: " + e.getMessage() + ", ABORT");
                }
            } else if (message instanceof ObjectMessage) {
                ObjectMessage objMessage = (ObjectMessage) message;
                Object obj = objMessage.getObject();
                if (obj instanceof DataReferenceUpdate) {
                    dataReferenceUpdate = (DataReferenceUpdate) obj;
                    logger.info("Processing message for " + dataReferenceUpdate.getRefObjectName());
//                } else {
//                    this.processBusinessEventMessage(message);
                }
            } else {
                logger.warn(className + ", onMessage() called with unsupported message: " + message + ", ABORT");
            }
        } catch (JMSException e) {
            logger.error(className + ", JMSException in onMessage(): " + e.getMessage() + ", ABORT");
        }

        if (dataReferenceUpdate != null) {
            processDataReferenceUpdate(dataReferenceUpdate);
        }
    }

    protected abstract void processDataReferenceUpdate(DataReferenceUpdate dataReferenceUpdate);

}
