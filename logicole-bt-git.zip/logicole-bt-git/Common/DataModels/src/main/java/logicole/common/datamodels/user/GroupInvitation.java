package logicole.common.datamodels.user;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.Date;

@JsonIgnoreProperties(ignoreUnknown = true)
public class GroupInvitation {
    public String id;
    public String name;
    public Date expirationDate;
    public String reason;
    public Date deletedDate;
    public Date updatedDate;
    public String updatedBy;
    public UserProfileTemplate userProfileTemplate;
    public long pendingCount;
    public long activeCount;
    public long deniedCount;
}
