package logicole.common.datamodels.search.request;

public enum SearchOperator {
    AND("and"), OR("or");

    private String oper;


    SearchOperator(String s) {
        this.oper = s;
    }

    public String getOper() {
        return this.oper;
    }

    public static SearchOperator getValue(String val) {
        return SearchOperator.valueOf(val.toUpperCase());
    }
}
