package logicole.common.datamodels.finance;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.ArrayList;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class FinanceDecision {
    public String id;
    public String decisionCriteriaHash;
    public FinanceDecisionCriteria financeDecisionCriteria;
    public List<String> actions = new ArrayList<>();
}
