package logicole.common.datamodels.system;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.Date;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SystemNotification {

    public String id;
    public String displayType;
    public String name;
    public String content;
    public Date startDate;
    public Date endDate;
    public String updateBy;
    public Date updateDate;
    public Boolean  isActive;
}
