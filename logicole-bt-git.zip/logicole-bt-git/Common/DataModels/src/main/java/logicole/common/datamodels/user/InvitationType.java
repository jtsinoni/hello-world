package logicole.common.datamodels.user;

public enum InvitationType {
    SINGLE("SINGLE"),
    GROUP("GROUP");

    private final String invitationType;

    InvitationType(String invitationType) {
        this.invitationType = invitationType;
    }

}
