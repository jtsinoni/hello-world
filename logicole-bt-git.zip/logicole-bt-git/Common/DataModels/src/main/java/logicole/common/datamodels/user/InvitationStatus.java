package logicole.common.datamodels.user;

public enum InvitationStatus {

    ACTIVE("Active"),
    DELETED("Deleted"),
    EXPIRED("Expired"),
    INACTIVE("Inactive"),
    LOCKED("Locked"),
    REJECTED("Rejected"),
    CANCELLED("Cancelled"),
    SUSPENDED("Suspended"),
    USER_DECLINED("User Declined"),
    USER_ACCEPTED("User Accepted"),
    PENDING_USER_ACCEPTANCE("Pending User Acceptance"),
    PENDING_MNG_APPROVAL("Pending Manager Approval"),
    MNG_APPROVED("Manager Approved"),
    MNG_DECLINED("Manager Declined");

    private final String name;

    private InvitationStatus(String status) {
        this.name = status;
    }

    public boolean equalsName(String otherName) {
        return (otherName == null) ? false : name.equals(otherName);
    }

    @Override
    public String toString() {
        return this.name;
    }
}
