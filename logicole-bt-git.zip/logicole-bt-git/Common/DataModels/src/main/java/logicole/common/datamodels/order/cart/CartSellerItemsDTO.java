package logicole.common.datamodels.order.cart;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.ArrayList;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CartSellerItemsDTO {

    public String sellerName;
    public String sellerId;
    public List<CartItem> items = new ArrayList<>();


}
