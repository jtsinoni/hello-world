package logicole.common.datamodels.finance;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import logicole.common.datamodels.finance.fundingsource.FundingSourceStatus;
import logicole.common.datamodels.finance.response.Balances;
import logicole.common.datamodels.organization.OrgRef;

import java.util.ArrayList;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class FundingNode {
    public String id;
    public String name;
    public String description;
    public List<FundingSourceRef> fundingSourceRefs = new ArrayList<>();
    public List<FundingNode> children;
    public List<OrgRef> buyers;
    public List<FundingCategory> categories;
    public FinancialSystemRef financialSystemRef;
    public Double target;
    public FundingSourceStatus status;
    public Balances balances;

    @JsonIgnore
    public FundingNodeRef getRef() {
        FundingNodeRef ref = new FundingNodeRef();
        ref.fundingSourceRefs = this.fundingSourceRefs;
        ref.id = id;
        ref.name = name;
        ref.target = target;
        return ref;
    }
}
