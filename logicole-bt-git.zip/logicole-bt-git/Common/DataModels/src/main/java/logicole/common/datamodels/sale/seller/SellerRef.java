package logicole.common.datamodels.sale.seller;

import logicole.common.datamodels.ref.DataRef;

import java.util.Objects;

public class SellerRef extends DataRef {
    public Boolean isExternal;
    public String type;

    public SellerRef() {}
    public SellerRef(String id, String name, Boolean isExternal, String type) {
        this.id = id;
        this.name = name;
        this.isExternal = isExternal;
        this.type = type;
        this.createNewHashCode();
    }

    @Override
    protected int generateHashCode() {
        return Objects.hash(id, name, isExternal);
    }

}