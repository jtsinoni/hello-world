package logicole.common.datamodels.search.filter;

public enum FieldValueComparitor {
    GREATER_THAN("gt"),
    GREATER_THAN_EQUALS("gte"),
    LESS_THAN("lt"),
    LESS_THAN_EQUALS("lte");

    private final String oper;

    private FieldValueComparitor(String s) {
        this.oper = s;
    }

    public boolean equalsName(String otherName) {
        return (otherName == null) ? false : oper.equals(otherName);
    }

    @Override
    public String toString() {
        return this.oper;
    }

}
