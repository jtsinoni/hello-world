package logicole.common.datamodels.organization;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ServiceProvider {
    public String id;
    public String name;
    public Consumer consumer = new Consumer();
    public Provider provider = new Provider();
    public Boolean isEnabled;


}