package logicole.common.datamodels.dataref;

import logicole.common.datamodels.ref.DataReferenceUpdate;
import logicole.common.datamodels.ref.Refs;
import logicole.common.general.jms.JmsClient;
import logicole.common.general.logging.Logger;

import java.util.HashMap;
import java.util.Map;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.jms.JMSException;

@ApplicationScoped
public class DataReferenceSubmitter {

    private final static String DATA_REFERENCE_TOPIC = "DataReferenceTopic";
    private final static String UPDATE_TYPE = "UpdateType";

    @Inject
    private JmsClient jmsClient;
    @Inject
    private Logger logger;

    public void submitUpdate(DataReferenceUpdate dataReferenceUpdate, Refs.References reference){
        try {
            Map<String,String> properties = new HashMap<>();
            properties.put(UPDATE_TYPE, reference.toString());
            jmsClient.sendRequestObject(dataReferenceUpdate, DATA_REFERENCE_TOPIC, properties);
        } catch (JMSException ex) {
            logger.error(ex.getMessage(), ex);
        }
    }
}
