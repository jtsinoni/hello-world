package logicole.common.datamodels.general;

public enum FundType {
    LOG("Log"),
    STOCK("Stock"),
    CUSTOMER("Customer");

    private final String fundType;

    FundType(String fundType) {
        this.fundType = fundType;
    }

}
