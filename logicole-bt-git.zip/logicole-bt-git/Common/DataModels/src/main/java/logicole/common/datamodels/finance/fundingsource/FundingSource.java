package logicole.common.datamodels.finance.fundingsource;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import logicole.common.datamodels.finance.FinancialSystemRef;
import logicole.common.datamodels.finance.FundingSourceField;
import logicole.common.datamodels.organization.OrgRef;
import logicole.common.datamodels.ref.DataRef;
import logicole.common.datamodels.ref.ReferencedData;

import java.util.ArrayList;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class FundingSource extends ReferencedData {

    public String id;
    public String name;
    public String description;
    public OrgRef owningOrg;
    public FundingSourceStatus status = FundingSourceStatus.ACTIVE; // calculated field?
    public String type;
    public FundingSourceSubType subType;
    public int duration;
    public String beginDate;
    public String endDate;
    public String startFiscalYear;
    public String endFiscalYear;
    public String expirationDate;
    public String memorandumReason;
    public Double target;
    public FinancialSystemRef financialSystemRef;
    public SLOA sloa;
    public List<FundingSourceField> financialSystemFields = new ArrayList<>();
    // add list fields from map with configuration (label, fieldName, isRequired, validation)
    public boolean isEditable; // transient
    public Double cumulativeFundAmount; // transient or separate call

    @Override
    @JsonIgnore
    public DataRef getRef() {
        FundingSourceRef ref = new FundingSourceRef();
        ref.fundType = type;
        ref.id = id;
        ref.name = name;
        return ref;
    }

}
