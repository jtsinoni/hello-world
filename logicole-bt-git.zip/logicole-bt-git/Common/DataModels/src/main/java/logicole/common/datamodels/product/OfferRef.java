package logicole.common.datamodels.product;

import logicole.common.datamodels.ref.DataRef;

import java.util.Objects;

public class OfferRef extends DataRef {
    public String sellerId;
    public String sellerName;
    public String productId;
    public String productDescription;
    public String manufacturer;
    public String sellerProductIdentifier;

    public OfferRef() {}
    public OfferRef(String id, String sellerId, String sellerName, String productId, String productDescription, String manufacturer, String sellerProductIdentifier) {
        this.id = id;
        this.sellerId = sellerId;
        this.sellerName = sellerName;
        this.productId = productId;
        this.productDescription = productDescription;
        this.manufacturer = manufacturer;

        this.sellerProductIdentifier = sellerProductIdentifier;

        this.createNewHashCode();
    }

    @Override
    protected int generateHashCode() {
        return Objects.hash(id, sellerId,sellerName,productId,sellerProductIdentifier);
    }

}