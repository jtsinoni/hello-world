package logicole.common.datamodels.general;

public class GeoCoordinates {
    public String latitude;
    public String longitude;
}
