package logicole.common.datamodels.user;

public class PhoneNumber {

    public PhoneNumberType phoneNumberType;
    public String value;

}
