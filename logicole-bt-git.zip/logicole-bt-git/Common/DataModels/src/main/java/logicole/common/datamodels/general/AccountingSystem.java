package logicole.common.datamodels.general;

public enum AccountingSystem {
    GFEBS("GFEBS");

    private final String accountingSystem;

    AccountingSystem(String accountingSystem) {
        this.accountingSystem = accountingSystem;
    }

}
