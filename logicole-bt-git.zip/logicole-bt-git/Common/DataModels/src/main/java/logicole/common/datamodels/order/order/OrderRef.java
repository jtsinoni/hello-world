package logicole.common.datamodels.order.order;

import logicole.common.datamodels.ref.DataRef;

import java.util.Objects;

public class OrderRef extends DataRef {

    @Override
    protected int generateHashCode() {
        return Objects.hash(id, name);
    }
}
