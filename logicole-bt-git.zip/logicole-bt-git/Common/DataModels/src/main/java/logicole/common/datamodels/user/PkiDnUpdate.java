package logicole.common.datamodels.user;

import java.util.Date;

public class PkiDnUpdate {
    public String id;
    public String requestersPkiDn;
    public Date expirationDate;
    public Date sentDate;

}
