package logicole.common.datamodels.finance.response;

import logicole.common.datamodels.finance.ProcessingBalance;

import java.util.ArrayList;
import java.util.List;

public class CommonFinanceResponse {

    public List<ProcessingBalance> processingBalances;
    public Integer responseCode = 0;
    public List<ResponseGroup> responseGroups = new ArrayList<>();
}
