package logicole.common.datamodels.product;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ProductSeqIdInfo {
    public String id;
    public Integer productSeqId;
    public Double orderCost;
    public Integer siteCount;
    public Integer orderCount;
}
