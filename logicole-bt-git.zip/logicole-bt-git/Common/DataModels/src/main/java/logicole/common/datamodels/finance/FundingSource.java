package logicole.common.datamodels.finance;

public class FundingSource {
}
