package logicole.common.datamodels.equipment;


public class Maintenance {

    public String deviceCd;
    public String ertReadinessCdAndText;
    public String meEcnId;
    public Integer maSerial;
    public Integer meId;
    public Double mel;
    public Double mrlc;
    public Integer mpId;
    public Integer workOrderCount;
    public String contractorNm;
    public String eiTmdeInd;
    public String maintActivityOrgNm;
    public String maintAssmntTyTx;
    public String operationalStatus;
    public String operationalStatusTx;
    public String otherGovtMaintSrc;
    public String rltDescTx;
    public String schedFactorTx;
    public String schedTeamOrgNm;
    public String unschedTeamOrgNm;
}