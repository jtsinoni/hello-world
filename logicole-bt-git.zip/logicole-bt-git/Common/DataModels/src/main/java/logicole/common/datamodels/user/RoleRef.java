package logicole.common.datamodels.user;

import logicole.common.datamodels.ref.DataRef;

import java.util.Objects;

public class RoleRef extends DataRef {
    public Boolean isActive;

    @Override
    protected int generateHashCode() {
        int code = Objects.hash(id, name, isActive);
        return code;
    }
}
