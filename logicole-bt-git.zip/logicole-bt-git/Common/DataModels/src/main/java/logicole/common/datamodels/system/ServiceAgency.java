package logicole.common.datamodels.system;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.ArrayList;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ServiceAgency {
    public String id;
    public String code;
    public String name;
    public List<ServiceAgencyRegion> regions = new ArrayList<>();

}
