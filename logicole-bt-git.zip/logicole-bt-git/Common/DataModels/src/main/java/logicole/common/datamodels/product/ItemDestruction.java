package logicole.common.datamodels.product;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ItemDestruction {
    public String id;
    public String destructCd;
    public String destructDesc;
}
