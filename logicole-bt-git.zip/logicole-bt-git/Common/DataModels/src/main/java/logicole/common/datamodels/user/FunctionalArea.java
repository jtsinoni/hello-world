package logicole.common.datamodels.user;

public class FunctionalArea {
    public String id;
    public String option;
    public String displayName;
}
