package logicole.common.datamodels.organization;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.ArrayList;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Node {
    public String id;
    public String guid;
    public String name;
    public Integer treeLevel;
    public String orgId;

    public String milServiceId;
    public String providerCode;
    public Boolean isPrimaryHost;

    public String orgRef;
    public String parentRef;

    public String nodeChain;
    public String ancestry;

    public List<String> children;
    public String parent;
    public NodeTypeRef nodeTypeRef = new NodeTypeRef();
    public List<ServiceProviderRef> serviceProviderRefs = new ArrayList<>();
}