package logicole.common.datamodels.user;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import logicole.common.datamodels.organization.NodeTypeRef;
import logicole.common.datamodels.ref.ReferencedData;

import java.util.*;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Role extends ReferencedData {
    public String id;
    public String name;
    public List<AssignedPermission> assignedPermissions = new ArrayList<>();
    public List<Role> roles = new ArrayList<>();
    public String functionalArea;
    public String description;
    public Date updatedDate;
    public String updatedBy;
    public Boolean systemRole;
    public Boolean isActive;
    public List<NodeTypeRef> nodeTypeRefs = new ArrayList<>();

}