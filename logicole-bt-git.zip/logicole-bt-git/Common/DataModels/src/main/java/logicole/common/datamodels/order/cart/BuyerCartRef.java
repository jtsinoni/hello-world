package logicole.common.datamodels.order.cart;

import logicole.common.datamodels.ref.DataRef;

import java.util.Objects;

public class BuyerCartRef extends DataRef {

    public BuyerCartRef() {
    }

    public BuyerCartRef(String id) {
        this.id = id;
        this.createNewHashCode();
    }

    @Override
    protected int generateHashCode() {
        return Objects.hash(id);
    }

}