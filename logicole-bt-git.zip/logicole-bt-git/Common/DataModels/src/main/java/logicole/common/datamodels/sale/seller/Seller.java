package logicole.common.datamodels.sale.seller;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import logicole.common.datamodels.general.Address;
import logicole.common.datamodels.general.Contact;
import logicole.common.datamodels.organization.NodeRef;
import logicole.common.datamodels.ref.DataRef;
import logicole.common.datamodels.ref.ReferencedData;
import logicole.common.datamodels.sale.seller.SellerRef;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Seller extends ReferencedData {

    public String id;
    public String name;
    public String description;
    public Boolean isExternal;
    public Boolean isAutoFullFillmentEnabled;
    public Float maximumOrderValue;
    public Float minimumOrderValue;
    public String createdBy;
    public Date createdDate;
    public String updatedBy;
    public Date updatedDate;
    public String dmlssType;
    public String dmlssCode;
    public String orgName;
    public String org;
    public String siteName;
    public Boolean _isDeleted;

    public NodeRef currentNodeRef = new NodeRef();
    public NodeRef managedByNodeRef = new NodeRef();

    public List<logicole.common.datamodels.general.Address> Address = new ArrayList<>();
    public List<logicole.common.datamodels.general.Contact> Contact = new ArrayList<>();

    @Override
    @JsonIgnore
    public DataRef getRef() {
        SellerRef ref = new SellerRef();
        ref.id = id;
        ref.name = name;
        ref.isExternal = isExternal;
        return ref;
    }
}
