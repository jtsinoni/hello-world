package logicole.common.datamodels.finance;

public enum FundingSourceFieldType {
    ACCOUNTING, SLOA;
}
