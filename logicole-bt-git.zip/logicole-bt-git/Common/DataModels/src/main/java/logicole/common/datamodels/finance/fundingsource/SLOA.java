package logicole.common.datamodels.finance.fundingsource;

import logicole.common.datamodels.finance.*;

public class SLOA {
    public String activity;
    public String agencyAccountingId;
    public String agencyDisbursingId;
    public String availabilityType;
    public String budgetAllotmentLineItemId;
    public String budgetLineItemId;
    public String budgetActivity;
    public String budgetSubActivity;
    public String businessEventType;
    public String costCenter;
    public String costElement;
    public String departmentRegular;
    public String departmentTransfer;
    public Integer endingPeriodYear;
    public String functionalArea;
    public String fundingCenter;
    public MainAccountRef mainAccountRef;
    public MainAccountTypeRef mainAccountTypeRef;
    public String objectClass;
    public Integer programYear;
    public String projectIdentifier;
    public String fundingCreationSource;
    public String reimbursable;
    public Integer startingPeriodYear;
    public String subAccount;
    public String subAllocationHolder;
    public String subClass;
    public String workOrderId;
    public String fundCode;
}
