package logicole.common.datamodels.order.cart;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


import logicole.common.datamodels.order.buyer.BuyerRef;
import logicole.common.datamodels.product.Offer;
import logicole.common.datamodels.product.OfferRef;
import logicole.common.datamodels.ref.DataRef;
import logicole.common.datamodels.ref.ReferencedData;
import logicole.common.datamodels.sale.seller.SellerRef;

import javax.persistence.Transient;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


@JsonIgnoreProperties(ignoreUnknown = true)
public class BuyerCart extends ReferencedData {
    
    public String id;
    public BuyerRef buyerRef = new BuyerRef();
    public OfferRef offerRef = new OfferRef();
    public Long quantityRequested;
    public Long quantity;
    public Float cartPrice;
    public Date delayedDeliveryDate;
    public String deliveryType;
    public String specialHandling;
    public Boolean isPassThroughItem;
    public Boolean isReplenishmentItem;
    public Boolean isInUserCart;

    @Transient
    public Offer offer = new Offer();

    @Override
    @JsonIgnore
    public DataRef getRef() {
        BuyerCartRef ref = new BuyerCartRef();
        ref.id = id;
        return ref;
    }



}
