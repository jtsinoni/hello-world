
package logicole.common.datamodels.search.request;

public enum SearchProvider {
    ELASTIC, HADOOP

}
