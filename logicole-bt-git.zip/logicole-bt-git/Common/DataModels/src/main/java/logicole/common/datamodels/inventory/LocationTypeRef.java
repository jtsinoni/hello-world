package logicole.common.datamodels.inventory;

import logicole.common.datamodels.ref.DataRef;

import java.util.Objects;

public class LocationTypeRef extends DataRef {

    public LocationTypeRef() {
    }

    public LocationTypeRef(String id, String name) {
        this.createNewHashCode();
    }

    @Override
    protected int generateHashCode() {
        return Objects.hash(id, name);
    }
}
