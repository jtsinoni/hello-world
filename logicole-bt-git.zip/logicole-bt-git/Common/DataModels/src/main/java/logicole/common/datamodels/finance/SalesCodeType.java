package logicole.common.datamodels.finance;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SalesCodeType {
    public String id;
    public String code;
    public String description;
    public String tradingPartner;
    public String status;

}
