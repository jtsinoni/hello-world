package logicole.common.datamodels.equipment;


public class Product {
    public Integer meId;
    public String ecn;
    public String nameplateModel;
    public Integer systemId;
    public String systemType;
    public String accessControlNumber;
    public String equipmentRequestId;
    public String networkConnectionType;
    public String networkConnected;
    public String ehrIndicator;
    public Double acquisitionCost;
    public String acquisitionDate;
    public String equipmentManufacturer;
    public String commonModel;
    public String deviceCode;
    public String deviceText;
    public String federalSupplyClass;
    public String deviceClassCode;
    public String deviceClassText;
    public Integer itemSerial;
    public String itemId;
    public String shortItemDescription;
    public String longItemDescription;
    public String nsn;
    public String manufacturer;
    public Integer productSeqId;
    public Integer preferredProductSeqId;
    public String productMatch;
    public String supplierName;
    public String sosTypeCode;
    public String commodityClass;
}