package logicole.common.datamodels.order.order;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import logicole.common.datamodels.general.EventSubType;
import logicole.common.datamodels.order.buyer.BuyerRef;
import logicole.common.datamodels.organization.NodeRef;
import logicole.common.datamodels.ref.DataRef;
import logicole.common.datamodels.ref.ReferencedData;
import logicole.common.datamodels.sale.seller.SellerRef;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Order extends ReferencedData {
    public String id;
    public EventSubType eventSubType;
    public BuyerRef buyerRef;
    public NodeRef buyerNodeRef;
    public NodeRef managedByNodeRef;
    public SellerRef sellerRef;
    public String docNum;
    public List<Item> items;

    @Override
    public DataRef getRef() {
        OrderRef ref = new OrderRef();
        ref.id = id;
        ref.name = docNum;
        ref.generateHashCode();
        return ref;
    }
}
