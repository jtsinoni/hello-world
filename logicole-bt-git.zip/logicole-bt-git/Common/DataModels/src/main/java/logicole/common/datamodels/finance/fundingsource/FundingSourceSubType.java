package logicole.common.datamodels.finance.fundingsource;

import com.fasterxml.jackson.annotation.JsonProperty;

public enum FundingSourceSubType {

    LOG("LOG"),
    SUPPLEMENTAL("SUPPLEMENTAL"),
    CUSTOMER("CUSTOMER"),
    MEMORANDUM("MEMORANDUM");

    private final String value;

    FundingSourceSubType(String value) {
        this.value = value;
    }

    public String getValue() {
        return this.value;
    }
}
