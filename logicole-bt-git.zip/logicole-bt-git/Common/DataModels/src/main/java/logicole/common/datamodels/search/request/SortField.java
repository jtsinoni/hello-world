package logicole.common.datamodels.search.request;

public class SortField {

    public String fieldName;
    public String sortOrder;

    public SortField() {}

    public SortField(String fieldName, SortOrder sortOrder) {
        this.fieldName = fieldName;
        this.sortOrder = sortOrder.toString();
    }
}
