package logicole.common.datamodels.equipment;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import logicole.common.datamodels.search.filter.RequestFilter;

import java.util.ArrayList;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SearchInputEquipmentRecord {

    public String queryString;
    public List<RequestFilter> filters;
    public List<String> searchWithinResults;
    public String operator;
    public List<String> orgIds = new ArrayList<>();
}
