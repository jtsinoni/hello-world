package logicole.common.datamodels.organization;

import java.util.ArrayList;
import java.util.List;

public class NodeTree {
    public String id;
    public String guid;
    public String name;
    public Integer treeLevel;
    public String nodeChain;
    public NodeTypeRef nodeTypeRef;
    public List<NodeTree> childNodes = new ArrayList<>();
    public List<String> children;
    public Boolean expanded = true;
    public Boolean checked = false;
}