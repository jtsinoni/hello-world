package logicole.common.datamodels.inventory;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import logicole.common.datamodels.ref.DataRef;
import logicole.common.datamodels.ref.ReferencedData;

@JsonIgnoreProperties(ignoreUnknown = true)
public class LocationType extends ReferencedData {
    public String id;
    public String name;

    @Override
    @JsonIgnore
    public DataRef getRef() {
        LocationTypeRef ref = new LocationTypeRef();
        ref.id = id;
        ref.name = name;
        return ref;
    }
}
