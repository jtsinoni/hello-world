package logicole.common.datamodels.product;

import java.util.ArrayList;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Source {
    public String id;
    public Integer sosSerial;
    public String sosCd;
    public String sosTypeCd;
    public String supplierNm;
    public String typeItemId;
    public String vendItemNum;
    public Integer ipPackSerial;
    public String dropShipFeeInd;
    public String dropShipOnlyInd;

    // Embedded object arrays
    public List<Packaging> packaging = new ArrayList<>();
}
