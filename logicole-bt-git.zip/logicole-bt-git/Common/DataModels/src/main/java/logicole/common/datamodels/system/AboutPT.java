package logicole.common.datamodels.system;

public class AboutPT {
    public String version;
    public String buildDate;
    }

