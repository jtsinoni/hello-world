package logicole.common.datamodels.ref;

public abstract class DataRef {
    public String id;
    public String name;
    private int hashValue;

    public String getId() {
        return id;
    }

    protected abstract int generateHashCode();

    public void createNewHashCode() {
        hashValue = generateHashCode();
    }
    public int getHashValue() {
        if (hashValue == 0) {
            hashValue = generateHashCode();
        }
        return hashValue;
    }

}
