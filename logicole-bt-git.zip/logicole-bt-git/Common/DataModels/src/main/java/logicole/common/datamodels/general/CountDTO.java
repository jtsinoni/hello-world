package logicole.common.datamodels.general;

public class CountDTO {
    public Long count;
//    public CountDTO(){};
//    public CountDTO(Long value){
//        this.count = value;
//    }

}
