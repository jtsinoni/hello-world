package logicole.common.datamodels.inventory;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.Date;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Shipment {
    public String id;
    public Date shipmentDate;
    public String trackingNumber;
    public String shipperName;
    public String shipFrom;
    public String shipTo;
    public String shipDesc;
    public String shipStatus;
    public String shipType;
    public Integer shipCount;
    public String shipmentDirection;
    public Boolean isHazardous;
    public Boolean requiresSignatureTally;
    public Boolean isRefrigerated;
    public Boolean isFrozen;
}
