package logicole.common.datamodels.general;

public enum EventSubType {
    PURCHASE_REQUEST,
    PURCHASE_ORDER,
    CONTRACT_AWARDED,
    CONTRACT_NOT_AWARDED,
    REIMBURSABLE,
    NON_REIMBURSABLE;

}
