package logicole.common.datamodels.abi;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import logicole.common.general.constants.DateAndTime;
import logicole.common.general.exception.ApplicationException;

public class BarcodeInformation {

    public String originalString;
    public String gtin14;
    public String lotNumber;
    public String version;
    public String quantity;
    public boolean hasGtin14;
    public boolean hasBarcodes;
    public boolean couldNotParseOriginalString;
    public boolean isCode39Barcode;
    public boolean isUpcBarcode;
    public boolean isEanBarcode;
    public boolean checkDigitVerified;
    
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateAndTime.DATE_TIME_PATTERN)
    public Date productionDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateAndTime.DATE_TIME_PATTERN)
    public Date dueDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateAndTime.DATE_TIME_PATTERN)
    public Date packagingDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateAndTime.DATE_TIME_PATTERN)
    public Date bestBeforeDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateAndTime.DATE_TIME_PATTERN)
    public Date sellByDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateAndTime.DATE_TIME_PATTERN)
    public Date expirationDate;

    public List<String> barcodes;
    
    public HashMap<String, String> unprocessed;

    public List<String> unhandled;
    
    public BarcodeInformation() {
        barcodes = new ArrayList<>();
        unprocessed = new HashMap<>();
        unhandled = new ArrayList<>();
        hasGtin14 = false;
        hasBarcodes = false;
        couldNotParseOriginalString = false;
        isCode39Barcode = false;
    }

    public void setValue(String applicationIdentifier, String value) throws ApplicationException {
        switch (applicationIdentifier) {
            case "01":
                this.gtin14 = value;
                break;
            case "10":
                this.lotNumber = value;
                break;
            case "11":
                this.productionDate = this.convertGS1Date(value);
                break;
            case "12":
                this.dueDate = this.convertGS1Date(value);
                break;
            case "13":
                this.packagingDate = this.convertGS1Date(value);
                break;
            case "15":
                this.bestBeforeDate = this.convertGS1Date(value);
                break;
            case "16":
                this.sellByDate = this.convertGS1Date(value);
                break;
            case "17":
                this.expirationDate = this.convertGS1Date(value);
                break;
            case "20":
                this.version = value;
                break;
            case "30":
                this.quantity = value;
                break;
            default:
                this.unprocessed.put(applicationIdentifier, value);
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");

        sb.append("{ ");
        sb.append(" originalString='");
        sb.append(originalString);
        sb.append("', ");
        sb.append("gtin14='");
        sb.append(gtin14);
        sb.append("', ");
        sb.append("lotNumber='");
        sb.append(lotNumber);
        sb.append("', ");
        sb.append("productionDate='");
        sb.append((productionDate != null) ? dateFormat.format(productionDate) : null);
        sb.append("', ");
        sb.append("dueDate='");
        sb.append((dueDate != null) ? dateFormat.format(dueDate) : null);
        sb.append("', ");
        sb.append("packagingDate='");
        sb.append((packagingDate != null) ? dateFormat.format(packagingDate) : null);
        sb.append("', ");
        sb.append("bestBeforeDate='");
        sb.append((bestBeforeDate != null) ? dateFormat.format(bestBeforeDate) : null);
        sb.append("', ");
        sb.append("sellByDate='");
        sb.append((sellByDate != null) ? dateFormat.format(sellByDate) : null);
        sb.append("', ");
        sb.append("expirationDate='");
        sb.append((expirationDate != null) ? dateFormat.format(expirationDate) : null);
        sb.append("', ");
        sb.append("barcodes='");
        sb.append(barcodes);
        sb.append("', ");
        sb.append("unprocessed='");
        sb.append(unprocessed);
        sb.append("', ");
        sb.append("unhandled='");
        sb.append(unhandled);
        sb.append("'");
        sb.append("}");
        return sb.toString();
    }
    
    private Date convertGS1Date(String value) {
        String yearStr = value.substring(0, 2);
        String monthStr = value.substring(2, 4);
        String dayStr = value.substring(4, 6);
        
        int year = 100 + Integer.parseInt(yearStr);
        int month = Integer.parseInt(monthStr);
        int day = Integer.parseInt(dayStr);
        
        if (day == 0) {
            day = 1;
        }
        
        Calendar c = Calendar.getInstance();
        c.set(year, month, day);
        Date date = c.getTime();
        return date;
    }
}
