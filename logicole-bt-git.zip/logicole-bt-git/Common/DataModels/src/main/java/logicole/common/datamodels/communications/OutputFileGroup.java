package logicole.common.datamodels.communications;

import logicole.common.datamodels.finance.FundingNodeRef;

import java.util.ArrayList;
import java.util.List;

public class OutputFileGroup {
    public String outputAction;
    public FundingNodeRef fundingNodeRef;
    public List<CommsItem> items = new ArrayList<>();
}
