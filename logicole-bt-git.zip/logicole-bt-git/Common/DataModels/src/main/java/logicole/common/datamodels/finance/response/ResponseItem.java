package logicole.common.datamodels.finance.response;

import logicole.common.datamodels.finance.FinanceItem;
import logicole.common.datamodels.order.buyer.BuyerRef;

public class  ResponseItem {
    public FinanceItem item;
    public BuyerRef buyerRef;
}
