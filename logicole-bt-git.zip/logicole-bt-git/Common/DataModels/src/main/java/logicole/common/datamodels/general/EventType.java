package logicole.common.datamodels.general;

public enum EventType {
    ORDER;

}
