package logicole.common.datamodels.ref;

public class Refs {

    public static enum References {
        ROLE("RoleRef"),
        ORG_NODE("NodeRef"),
        FUNDING_SOURCE("FundingSourceRef"),
        FUNDING_NODE("FundingNodeRef");

        private final String doName;
        
        References(String doName) {
            this.doName = doName;
        }
        
        public String toString() {
            return doName;
        }
    }
}
