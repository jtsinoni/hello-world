package logicole.common.datamodels.inventory;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import logicole.common.datamodels.general.Contact;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Shipper {
    public String id;
    public String shipperName;
    public String shipperCode;
    public String shipperAccountNumber;
    public Contact shipperPointOfContact = new Contact();
    public String shipperUrl;
    public Boolean isActive;
}
