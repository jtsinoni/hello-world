package logicole.common.datamodels.finance.response;

public class Balances {
    public Double commitments = 0d;
    public Double obligations = 0d;
    public Double credits = 0d;
    public Double nSales = 0d;
    public Double rSales = 0d;
    public Double expenses = 0d;
    public Double surcharges = 0d;
    public Double total = 0d;
}
