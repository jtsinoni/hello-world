package logicole.common.datamodels.finance;

import logicole.common.datamodels.ref.DataRef;

import java.util.Objects;

public class FinancialSystemRef extends DataRef {
    @Override
    protected int generateHashCode() {
        return Objects.hash(id, name);
    }
}
