package logicole.common.datamodels.order;

public class Packaging {
    public String id;
    public String packageUnit;
    public String packageQuantity;
    public String packageUnitText;
    public String packageUnitDescription;
}
