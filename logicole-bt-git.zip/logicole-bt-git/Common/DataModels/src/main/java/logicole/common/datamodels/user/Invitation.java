package logicole.common.datamodels.user;

import java.util.Date;

public class Invitation {
    public String id;
    public Date acceptedDate;
    public Date deniedDate;
    public Date expirationDate;
    public Date sentDate;
    public String status;
}
