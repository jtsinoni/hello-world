package logicole.common.datamodels.system;

import java.util.ArrayList;
import java.util.List;

public class ServiceAgencyRegion { 
    
    public String code;
    public String name;
    public List<Site> sites = new ArrayList<>();

}
