package logicole.common.datamodels.user;

import logicole.common.datamodels.ref.DataRef;

import java.util.Objects;

public class StateRef extends DataRef implements NamedItem {

    @Override
    protected int generateHashCode() {
        return Objects.hash(id, name);
    }

    @Override
    public String getName() {
        return name;
    }
}
