package logicole.common.datamodels;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class HealthCheckResult {
    public final String componentName;
    public final String componentType;
    public final String overallResult;
    public final Date checkDate = new Date();

    public final List<HealthCheckResult> nestedHealthChecks = new ArrayList<>();

    public HealthCheckResult(){
        this("Unknown", "Unknown", "Good");

    }

    public HealthCheckResult(String componentName, String componentType, String status){
        this.componentName = componentName;
        this.componentType = componentType;
        this.overallResult = status;
    }
}
