package logicole.common.datamodels.finance;

import logicole.common.datamodels.ref.DataRef;

import java.util.List;
import java.util.Objects;

public class FundingNodeRef extends DataRef {
    public List<FundingSourceRef> fundingSourceRefs;
    public Double target;

    @Override
    protected int generateHashCode() {
        return Objects.hash(id, name, fundingSourceRefs, target);
    }
}
