package logicole.common.datamodels.abi;

public class GtinPackaging {
//    @FieldOrder(fieldNumber = 1)
    public String id;
//    @FieldOrder(fieldNumber = 2)
    public String discernmentStatus;
//    @FieldOrder(fieldNumber = 3)
    public String itemStatus;
//    @FieldOrder(fieldNumber = 4)
    public String resourceId;
//    @FieldOrder(fieldNumber = 5)
    public Integer mmcProductIdentifier;
//    @FieldOrder(fieldNumber = 6)
    public String customerItemDescription;
//    @FieldOrder(fieldNumber = 7)
    public String itemDescription;
//    @FieldOrder(fieldNumber = 8)
    public String customerVendorName;
//    @FieldOrder(fieldNumber = 9)
    public String customerVendorPartNumber;
//    @FieldOrder(fieldNumber = 10)
    public String ghxManufacturer;
//    @FieldOrder(fieldNumber = 11)
    public String ghxManufacturerPartNumber;
//    @FieldOrder(fieldNumber = 12)
    public String gtin1;
//    @FieldOrder(fieldNumber = 13)
    public String hibcc1;
//    @FieldOrder(fieldNumber = 14)
    public String gudidIdentifierType1;
//    @FieldOrder(fieldNumber = 15)
    public String packageUnit1;
//    @FieldOrder(fieldNumber = 16)
    public Integer packageQuantity1;
//    @FieldOrder(fieldNumber = 17)
    public String gtin2;
//    @FieldOrder(fieldNumber = 18)
    public String hibcc2;
//    @FieldOrder(fieldNumber = 19)
    public String gudidIdentifierType2;
//    @FieldOrder(fieldNumber = 20)
    public String packageUnit2;
//    @FieldOrder(fieldNumber = 21)
    public Integer packageQuantity2;
//    @FieldOrder(fieldNumber = 22)
    public String gtin3;
//    @FieldOrder(fieldNumber = 23)
    public String hibcc3;
//    @FieldOrder(fieldNumber = 24)
    public String gudidIdentifierType3;
//    @FieldOrder(fieldNumber = 25)
    public String packageUnit3;
//    @FieldOrder(fieldNumber = 26)
    public Integer packageQuantity3;
//    @FieldOrder(fieldNumber = 27)
    public String secondaryProductIdentifier;
//    @FieldOrder(fieldNumber = 28)
    public String netContentText;
//    @FieldOrder(fieldNumber = 29)
    public Integer netContentQuantity;
}
