package logicole.common.datamodels.inventory;

import logicole.common.datamodels.ref.DataRef;

import java.util.Objects;

public class StorageRestrictionRef extends DataRef {

    public StorageRestrictionRef() {
    }

    public StorageRestrictionRef(String id, String name) {
        this.createNewHashCode();
    }

    @Override
    protected int generateHashCode() {
        return Objects.hash(id, name);
    }
}
