package logicole.common.datamodels.inventory;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import logicole.common.datamodels.ref.DataRef;
import logicole.common.datamodels.ref.ReferencedData;

import java.util.ArrayList;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class InventoryLocation extends ReferencedData {
    public String id;
    public String name;
    public String description;
    public InventoryOwnerRef invOwnerRef = new InventoryOwnerRef();
    public StorageAreaRef storageAreaRef = new StorageAreaRef();
    public LocationTypeRef locationTypeRef = new LocationTypeRef();
    public List<String> locationAttributes = new ArrayList<>();
    public List<StorageRestrictionRef> storageRestrictionRefs = new ArrayList<>();

    @Override
    @JsonIgnore
    public DataRef getRef() {
        InventoryLocationRef ref = new InventoryLocationRef();
        ref.id = id;
        ref.name = name;
        return ref;
    }
}
