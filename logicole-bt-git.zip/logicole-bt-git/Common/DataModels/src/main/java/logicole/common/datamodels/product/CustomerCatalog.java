package logicole.common.datamodels.product;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CustomerCatalog {
    public String id;
    public String catalogName;
    public String orgId;
    public String orgNm;
}
