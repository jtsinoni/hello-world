package logicole.common.datamodels.finance.fundingsource;

import com.fasterxml.jackson.annotation.JsonProperty;

public enum FundingSourceStatus {
    ACTIVE("ACTIVE"),
    CLOSED("CLOSED"),
    DELETED("DELETED"),
    EXPIRED("EXPIRED"),
    RETIRED("RETIRED");


    private final String value;

    FundingSourceStatus(String value) {
        this.value = value;
    }

    public String getValue() {
        return this.value;
    }
}
