package logicole.common.datamodels.ref;

import java.io.Serializable;

public class DataReferenceUpdate implements Serializable {
    
    private String refObjectName;
    private boolean entityDeleted = false;
    private String object;
    
    public DataReferenceUpdate() {
    }
    
    public DataReferenceUpdate(String name, String object, boolean isDeleted) {
        this.refObjectName = name;
        if (isDeleted) {
            this.entityDeleted = isDeleted;
        }
        this.object = object;
    }
    
    public void setRefObjectName(String name) {
        this.refObjectName = name;
    }  
    
    public String getRefObjectName() {
        return this.refObjectName;
    }
    
    public void setEntityDeleted(boolean isDeleted) {
        this.entityDeleted = isDeleted;
    }
    
    public boolean getEntityDeleted() {
        return this.entityDeleted;
    }
    
    public String getObject() {return this.object;}
    public void setObject(String object)  {this.object = object;}

    public static DataReferenceUpdate create(String collection, String t, boolean isDeleted) {
        return new DataReferenceUpdate(collection, t, isDeleted);
    }
    
}
