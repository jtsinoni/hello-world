package logicole.common.datamodels.user;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import logicole.common.datamodels.organization.NodeRef;
import logicole.common.datamodels.organization.NodeTypeRef;

import java.util.*;

@JsonIgnoreProperties(ignoreUnknown = true)
public class UserProfile {
    public String id;
    public String email;
    public String firstName;
    public String lastName;

    public String pkiDn;
    public Date lastLoginDate;
    public Date previousLoginDate;

    public String profileName;
    public String lastLoginIP;
    public String previousLoginIP;

    public List<AssignedPermission> assignedPermissions;
    public Boolean current;
    public String reasonForAccess;
    public Boolean isSystemProfile;

    public List<PhoneNumber> phoneNumbers;

    public Date lockStartDate;
    public Date lockEndDate;
    public Date unlockedDate;

    public Date updatedDate;
    public String updatedBy;
    public Date createdDate;
    public String createdBy;
    public String reason;
    public Date deletedDate;
    public String userProfileStatus;
    public Date profileExpirationDate;

    public Invitation invitation = new Invitation();
    public PkiDnUpdate pkiDnUpdate = new PkiDnUpdate();
    public NodeRef currentNodeRef = new NodeRef();
    public NodeRef managedByNodeRef = new NodeRef();
    public NodeTypeRef nodeTypeRef = new NodeTypeRef();
    public List<NodeRef> scopeNodeRefs = new ArrayList<>();
    public List<RoleRef> roleRefs = new ArrayList<>();

    public String getFullName() {
        return String.format("%s, %s", this.lastName, this.firstName);
    }
    public List<String> statuses = new ArrayList<>();
    public String statusDescription = null;
}
