package logicole.common.datamodels.inventory;

import logicole.common.datamodels.ref.DataRef;

import java.util.Objects;

public class StorageAreaRef extends DataRef {

    public StorageAreaRef() {
    }

    public StorageAreaRef(String id, String name) {
        this.createNewHashCode();
    }

    @Override
    protected int generateHashCode() {
        return Objects.hash(id, name);
    }
}
