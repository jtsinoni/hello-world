package logicole.common.datamodels.ref;

public abstract class ReferencedData {
    public DataRef getRef() {
        return null;
    }
}
