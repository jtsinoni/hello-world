package logicole.common.datamodels.user;

import logicole.common.datamodels.ref.DataRef;
import logicole.common.datamodels.ref.ReferencedData;

public class State extends ReferencedData implements NamedItem {

    public String id;
    public String name;
    public String functionalArea;

    @Override
    public String getName() {
        return name;
    }

    @Override
    public DataRef getRef() {
        StateRef ref = new StateRef();
        ref.name = this.name;
        ref.id = this.id;
        return ref;
    }
}
