package logicole.common.datamodels.general;

public enum SourceType {
    DPV("PrimeVendor");

    private final String sourceType;

    SourceType(String sourceType) {
        this.sourceType = sourceType;
    }

}
