package logicole.common.datamodels.search.request;

import java.util.ArrayList;
import java.util.List;

public class DmlesSearchSource {

    public String from = "";
    public List<String> type = new ArrayList<>();

    public DmlesSearchSource() {

    }

    public DmlesSearchSource(String from) {
        this.from = from;
    }

    public DmlesSearchSource(String from, String type) {
        this.from = from;
        this.type.add(type);
    }

    public DmlesSearchSource(String from, List<String> type) {
        this.type = type;
        this.from = from;
    }

    @Override
    public String toString() {
        return "DmlesSearchSource [" + "FROM: " + from + " " + "TYPE(s): " + type + "]";
    }
}
