package logicole.common.datamodels.user;

import java.util.List;

public class Endpoint {

    public String id;
    public String businessMethod;
    public List<String> parameters;
    public String userMessage;
    public String logMessage;
    
}
