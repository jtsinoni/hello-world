package logicole.common.datamodels.organization;

public class ServiceProviderRef extends ServiceProvider {

}
