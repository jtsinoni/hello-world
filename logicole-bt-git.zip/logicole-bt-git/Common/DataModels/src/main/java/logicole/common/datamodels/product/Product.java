package logicole.common.datamodels.product;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import logicole.common.datamodels.abi.AbiCatalogBase;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Product extends AbiCatalogBase {
    public Product() {
        super();
    }

    public Product(Product source) {
        super(source);
    }
}

