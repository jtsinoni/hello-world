package logicole.common.datamodels.search.request;

public class Aggregation {
    public String name;
    public String field;
    public int size;
    public String order;

    public Aggregation() {
    }

    public Aggregation(String name, String field, int size, String order) {
        this.name = name;
        this.field = field;
        this.size = size;
        this.order = order;
    }

    @Override
    public String toString() {
        return String.format("name:%s;field:%s;size%s;order:%s", name, field, size, order);
    }
}
