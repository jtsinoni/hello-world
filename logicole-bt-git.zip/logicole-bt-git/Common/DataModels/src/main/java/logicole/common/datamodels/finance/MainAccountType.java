package logicole.common.datamodels.finance;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class MainAccountType {
    public String id;
    public String code;
    public String description;
    public String duration;
    public String availabilityTypeCode;
}
