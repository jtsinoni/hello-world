package logicole.common.datamodels;

import logicole.common.datamodels.user.CurrentUser;

import javax.enterprise.context.RequestScoped;

@RequestScoped
public class CurrentUserBT {

    private boolean isAlreadySecure = false;
    private CurrentUser currentUser;
    private String currentNodeId;

    public boolean isAlreadySecure() {
        return isAlreadySecure;
    }

    public void setAlreadySecure(boolean alreadySecure) {
        isAlreadySecure = alreadySecure;
    }

    public CurrentUser getCurrentUser() {
        return currentUser;
    }

    public void setCurrentUser(CurrentUser currentUser) {
        this.currentUser = currentUser;
    }

    public String getFullName() {
        return String.format("%s, %s", currentUser.profile.lastName, currentUser.profile.firstName);
    }

    public String getCurrentNodeId() {
        return currentNodeId;
    }

    public void setCurrentNodeId(String currentNodeId) {
        this.currentNodeId = currentNodeId;
    }
}
