package logicole.common.datamodels.finance;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CommodityCode {

    public String  id;
    public String  financialSystem;
    public String  financialCommodityCode;
    public String  financialCommodityCodeType;
    public String  eorNomen;
    public String  commodityClsName;
    public String  objectClassCode;
    public String  objectSubClassCode;
    public String  costcenterFinancialCode;
    public String  costcenterAccountReqCode;
    public String  costcentEorCommType;
    public String  costcenterCapitalEquip;
    public String  costcenterFunctionID;
    public String  costcenterSgManaged;
    public String  centrallyMgInd;
    public String  corLogFundID;
    public String  corOpFundInd;
    public String  mmUsageInd;
    public String  fmUsageInd;
    public String  eorRetiredInd;
    public String  costcenterDelInd;
    public String  recordID;
}
