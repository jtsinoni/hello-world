package logicole.common.datamodels.system;

import com.fasterxml.jackson.annotation.JsonFormat;
import logicole.common.datamodels.search.filter.RequestFilter;
import logicole.common.general.constants.DateAndTime;


import java.util.Date;
import java.util.List;

public class ApplicationHistorySearch {

    @JsonFormat(shape = JsonFormat.Shape.STRING,
            pattern = DateAndTime.DATE_TIME_PATTERN,
            timezone = DateAndTime.TIMEZONE)
    public Date startDate;
    @JsonFormat(shape = JsonFormat.Shape.STRING,
            pattern = DateAndTime.DATE_TIME_PATTERN,
            timezone = DateAndTime.TIMEZONE)
    public Date endDate;
    public String searchString;
    public List<RequestFilter> filters;

}
