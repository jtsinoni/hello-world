package logicole.common.datamodels.system;

public class HealthCheck {
    public String serviceName;
    public String status;
    public String dmlesAppHost;
    public String mongoHosts;
    public String mongoUserId;
    public String hostName;
    public String databaseConnectionInfo;
    public boolean connectedToDatabase;
}
