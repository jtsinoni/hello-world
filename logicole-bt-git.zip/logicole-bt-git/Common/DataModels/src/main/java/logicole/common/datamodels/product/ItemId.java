package logicole.common.datamodels.product;

public class ItemId {
    public String id;
    public String itemId;
}
