package logicole.common.datamodels.order.buyer;

import logicole.common.datamodels.general.Address;
import logicole.common.datamodels.general.Contact;
import logicole.common.datamodels.order.AuthorizedSupplier;
import logicole.common.datamodels.organization.NodeRef;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class BuyerDTO {
    public String id;
    public String name;
    public String description;
    public Boolean isVerifyReceipts;
    public Boolean isVerifyOrders;
    public Boolean isIssueIndicator;
    public Boolean isRetired;
    public String drugEnforcementData;
    public String acceptedDocumentType;
    public Float maxOrderLimit;
    public String createdBy;
    public Date createdDate;
    public String updatedBy;
    public Date updatedDate;
    public Boolean _isDeleted;
    public NodeRef currentNodeRef = new NodeRef();
    public NodeRef managedByNodeRef = new NodeRef();

    public List<Address> Address = new ArrayList<>();
    public List<Contact> Contact = new ArrayList<>();
    public List<AuthorizedSupplier> AuthorizedSupplier = new ArrayList<>();

    public BuyerDTO() {}
    public BuyerDTO(Buyer buyer) {
        this.id = buyer.id;
        this.name = buyer.name;
        this.description = buyer.description;
        this.isVerifyReceipts = buyer.isVerifyReceipts;
        this.isVerifyOrders = buyer.isVerifyOrders;
        this.isIssueIndicator = buyer.isIssueIndicator;
        this.isRetired = buyer.isRetired;
        this.drugEnforcementData = buyer.drugEnforcementData;
        this.acceptedDocumentType = buyer.acceptedDocumentType;
        this.maxOrderLimit = buyer.maxOrderLimit;
        this.createdBy = buyer.createdBy;
        this.createdDate = buyer.createdDate;
        this.updatedBy = buyer.updatedBy;
        this.updatedDate = buyer.updatedDate;
        this._isDeleted = buyer._isDeleted;
        this.currentNodeRef = buyer.currentNodeRef;
        this.managedByNodeRef = buyer.managedByNodeRef;
        this.Address = buyer.Address;
        this.Contact = buyer.Contact;
    }

}
