package logicole.common.datamodels.order.cart;



import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import logicole.common.datamodels.product.Offer;
import logicole.common.datamodels.product.OfferRef;

import javax.persistence.Transient;
import java.util.Date;


@JsonIgnoreProperties(ignoreUnknown = true)
public class CartItem  {
    public String id;
    public Long quantityRequested;
    public Long quantity;
    public Float cartPrice;
    public Date delayedDeliveryDate;
    public String deliveryType;
    public String specialHandling;
    public Date addedDate;
    public String addedBy;
    public Boolean isSavedForLater;
    public Boolean isPassThroughItem;
    public Boolean isReplenishmentItem;
    public Boolean isInUserCart;
    public BuyerCartRef buyerCartRef = new BuyerCartRef();
    public OfferRef offerRef = new OfferRef();

    @Transient
    public Offer offer = new Offer();

}
