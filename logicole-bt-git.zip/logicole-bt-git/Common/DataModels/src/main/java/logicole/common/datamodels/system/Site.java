package logicole.common.datamodels.system;

public class Site { 
    public String dodaac;
    public String name;
}
