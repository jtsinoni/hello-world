package logicole.common.datamodels.search;

import com.fasterxml.jackson.annotation.JsonFormat;
import logicole.common.general.constants.DateAndTime;

import java.util.Date;

public class Example {
    public Long id;
    public String firstName;
    public String lastName;
    public String comment;
    public String userId;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateAndTime.DATE_TIME_PATTERN)
    public Date created = new Date();
}