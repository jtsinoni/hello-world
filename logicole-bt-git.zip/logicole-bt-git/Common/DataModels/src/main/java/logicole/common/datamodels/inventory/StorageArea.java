package logicole.common.datamodels.inventory;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import logicole.common.datamodels.general.Address;
import logicole.common.datamodels.general.Contact;
import logicole.common.datamodels.general.GeoCoordinates;
import logicole.common.datamodels.organization.NodeRef;
import logicole.common.datamodels.ref.DataRef;
import logicole.common.datamodels.ref.ReferencedData;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class StorageArea extends ReferencedData {
    public String id;
    public String name;
    public String description;
    public String storageAreaGuid;
    public NodeRef orgNodeRef = new NodeRef();
    public List<InventoryOwnerRef> invOwnerRefs = new ArrayList<>();
    public Address address = new Address();
    public Contact pointOfContact = new Contact();
    public Boolean hasWifiConnectivity;
    public Integer squareFootage;
    public GeoCoordinates geoCoordinates = new GeoCoordinates();
    public Date deactivationDate;

    @Override
    @JsonIgnore
    public DataRef getRef() {
        StorageAreaRef ref = new StorageAreaRef();
        ref.id = id;
        ref.name = name;
        return ref;
    }
}
