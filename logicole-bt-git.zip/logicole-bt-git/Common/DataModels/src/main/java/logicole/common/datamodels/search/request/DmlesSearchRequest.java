package logicole.common.datamodels.search.request;

import logicole.common.datamodels.search.filter.RequestFilter;

import java.util.ArrayList;
import java.util.List;

public class DmlesSearchRequest {
    public String queryString;

    public List<Aggregation> aggregations = new ArrayList<>();

    public SearchOperator searchOperator = SearchOperator.OR;

    public List<String> searchFields = new ArrayList<>();
    public List<String> responseFields = new ArrayList<>();

    public int resultSetOffset = 0;

    public int resultSetSize = 10;

    public DmlesSearchSource source = new DmlesSearchSource();

    public SearchProvider searchProvider = SearchProvider.ELASTIC;

    public List<SortField> sortFields = new ArrayList<>();

    public List<RequestFilter> filters = new ArrayList<>();
    public List<String> searchWithinResults = new ArrayList<>();
    public List<String> numericSearchSortFields = new ArrayList<>();
    public boolean wholeWordsOnly = false;
    public boolean trailingWildcardOnly = false;
    public boolean escapeSpecialCharacters = false;

    public DmlesSearchRequest() {
    }

    public DmlesSearchRequest(String queryString, List<Aggregation> aggregations) {
        this.queryString = queryString;
        this.aggregations = aggregations;
    }

    @Override
    public String toString() {

        StringBuilder aggs = new StringBuilder();
        if (aggregations != null) {
            for (Aggregation ag : aggregations) {
                aggs.append(ag.toString());
                aggs.append(",");
            }
        }

        StringBuilder filterString = new StringBuilder();
        if (filters != null) {
            for (RequestFilter filter : filters) {
                filterString.append(filter.toString());
                filterString.append(",");
            }
        }

        return "DmlesSearchRequest [" + "aggregations " + aggs.toString() + " "
                + "searchOperator " + searchOperator + " "
                + "queryString " + queryString + " "
                + "searchFields " + searchFields + " "
                + "filters " + filterString + " "
                + "resultSetOffset " + resultSetOffset + " "
                + "resultSetSize " + resultSetSize + " "
                + "searchProvider " + searchProvider + " "
                + "searchFields " + searchFields + " "
                + "source " + source + "]";
    }


}
