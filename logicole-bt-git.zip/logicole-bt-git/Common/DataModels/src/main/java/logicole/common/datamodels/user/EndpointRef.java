package logicole.common.datamodels.user;

public class EndpointRef extends Endpoint {

}
