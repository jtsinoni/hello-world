package logicole.common.datamodels.finance.fundingsource;

public enum FundingSourceType {
    APPROPRIATION, VENDOR_CREDIT;
}
