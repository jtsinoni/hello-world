package logicole.common.datamodels.user;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import logicole.common.datamodels.ref.DataRef;
import logicole.common.datamodels.ref.ReferencedData;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Element extends ReferencedData implements NamedItem {
    
    public String id;
    public String name;
    public String functionalArea;

    @Override
    public String getName() {
        return name;
    }

    @Override
    public DataRef getRef() {
        ElementRef ref = new ElementRef();
        ref.name = this.name;
        ref.id = this.id;
        return ref;
    }
}
