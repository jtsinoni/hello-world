package logicole.common.datamodels.product;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ItemRestriction {
    public String id;
    public String restrictCd;
    public String restrictDescription;
    public String restrictType;
}
