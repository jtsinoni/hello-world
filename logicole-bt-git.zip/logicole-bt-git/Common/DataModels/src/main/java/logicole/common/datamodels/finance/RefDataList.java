package logicole.common.datamodels.finance;

        import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class RefDataList {
    public String  id;
    public String collectionName;
    public String description;
    public String module;
}
