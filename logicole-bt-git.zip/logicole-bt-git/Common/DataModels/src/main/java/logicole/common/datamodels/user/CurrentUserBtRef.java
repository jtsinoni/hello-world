package logicole.common.datamodels.user;

import logicole.common.datamodels.ref.DataRef;

import java.util.Objects;

public class CurrentUserBtRef extends DataRef {
    public String fullName;
    public String pkiDn;

    @Override
    protected int generateHashCode() {
        int code = Objects.hash(id, pkiDn, fullName);
        return code;    }
}
