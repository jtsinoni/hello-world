package logicole.common.datamodels.abi;

import logicole.common.general.constants.DateAndTime;
import com.fasterxml.jackson.annotation.JsonFormat;
import java.util.Date;

public class ABiTaskHistory {
    public String category;
    public String requestId;
    public String logLevel;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DateAndTime.DATE_TIME_PATTERN)
    public Date entryDate;
    public String message;
    public String userPkiDn;
    public String exceptionText;
}
