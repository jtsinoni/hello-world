package logicole.common.datamodels.search;

import com.fasterxml.jackson.databind.node.ObjectNode;

import java.util.ArrayList;
import java.util.List;

public class Field {
    public Float max_score;
    public List<ObjectNode> fields = new ArrayList<>();
}
