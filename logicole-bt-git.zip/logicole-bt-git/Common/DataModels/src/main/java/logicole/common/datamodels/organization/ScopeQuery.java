package logicole.common.datamodels.organization;

import java.util.List;

public class ScopeQuery {
    public String nodeTypeId;
    public List<String> scopeList;
}
