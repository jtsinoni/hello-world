package logicole.common.datamodels.finance.request;

import logicole.common.datamodels.finance.*;
import logicole.common.datamodels.order.order.OrderRef;
import logicole.common.datamodels.order.buyer.BuyerRef;

import java.util.List;

public class RequestGroup {

    public FundingNodeRef fundingNodeRef;
    public BuyerRef buyerRef;
    public List<FinanceItem> items;
    public OrderRef orderRef;
}
