package logicole.common.datamodels.user;

public enum PhoneNumberType {
    
    MOBILE, WORK, HOME
}
