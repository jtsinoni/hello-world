package logicole.common.datamodels.user;

import logicole.common.datamodels.ref.DataRef;

import java.util.Objects;

public class ElementRef extends DataRef implements NamedItem {

    @Override
    protected int generateHashCode() {
        int hcode = Objects.hash(id, name);
        return hcode;
    }

    @Override
    public String getName() {
        return name;
    }
}
