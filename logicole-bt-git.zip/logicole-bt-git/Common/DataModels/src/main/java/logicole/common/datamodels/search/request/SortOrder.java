package logicole.common.datamodels.search.request;

public enum SortOrder {
    ASC("asc"),
    DESC("desc");

    private final String name;

    private SortOrder(String s) {
        this.name = s;
    }

    public boolean equalsName(String otherName) {
        return (otherName == null) ? false : name.equals(otherName);
    }

    @Override
    public String toString() {
        return this.name;
    }
}
