package logicole.common.datamodels.abi;

public enum ABiUploadType {
    NotSpecified,
    GHX,
    SCRIPTPRO,
    HCPCS_IMPLANT,
    GTIN_PACKAGING,
}
