package logicole.common.datamodels.order.buyer;

import logicole.common.datamodels.ref.DataRef;

import java.util.Objects;

public class BuyerRef extends DataRef {

    public BuyerRef() {}
    public BuyerRef(String id, String name) {

        this.createNewHashCode();
    }

    @Override
    protected int generateHashCode() {
        return Objects.hash(id, name);
    }

}