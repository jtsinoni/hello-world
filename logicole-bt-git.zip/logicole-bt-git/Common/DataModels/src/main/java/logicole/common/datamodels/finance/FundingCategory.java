package logicole.common.datamodels.finance;

public class FundingCategory {
    public String id;
    public String description;
    public String elementCode;
    public String classCode;
    public String resourceCode;
    public Double target;
    public String categoryType;
    public String categoryId;

}
