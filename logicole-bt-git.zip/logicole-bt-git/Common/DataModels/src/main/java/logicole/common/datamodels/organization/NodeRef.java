package logicole.common.datamodels.organization;

import logicole.common.datamodels.ref.DataRef;

import java.util.Objects;

public class NodeRef extends DataRef {
    public String orgId;

    public NodeRef() {}
    public NodeRef(String id, String name, String orgId) {
        this.id = id;
        this.name = name;
        this.orgId = orgId;
        this.createNewHashCode();
    }

    @Override
    protected int generateHashCode() {
        return Objects.hash(id, name, orgId);
    }

}