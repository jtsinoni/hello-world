package logicole.common.datamodels.abi;

public class HcpcsImplant {
    public String id;
    public String hcpcsCode;
    public String implant;
}
