package logicole.common.datamodels.inventory;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import logicole.common.datamodels.ref.ReferencedData;

@JsonIgnoreProperties(ignoreUnknown = true)
public class InventoryRecord extends ReferencedData{
        public String id;
        public String orgNodeRefId;
        public String orgName;				// customer Reference
        public String itemId;					// Item Reference to Catalog.guid
        public String localName	;				// Customized Name given to the Inventory Record;
        public String shortItemDesc;			// Short Item Description; carried from Site Catalog Record?
        public String longItemDesc;				// Long Item Description; carried from Site Catalog Record?
        public String unitOfInventory;			// U/S; Move it to Location?
        public Float unitOfInventoryPrice;		// U/S Price ; Move it to Location?
        public Integer unitOfInventoryQty;		// U/S Qty; Move it to Location?
        public Integer queuedForPutQty;
        public Integer queuedForPickQty;
        public Boolean isCriticalItem = false;			    // Critical Item Indicator; questions about this.
        public Integer estimatedMonthlyUsageQty;
        public Integer maximumReleaseQty;
        public Integer defaultReorderPointQty;
        public Integer defaultLevelQty;
        public String defaultLevelType;
        public String defaultLevelMethod;
        public boolean defaultIsResellable;
        public boolean defaultIsFreeIssue;
}
