package logicole.common.datamodels.equipment;


public class MaintCost {
    public String mcFiscalYearTm;
    public Integer mcDownTime;
    public Integer mcUnschdWoQty;
    public Double mcOPartCostAmt;
    public Float mcOUTimeQty;
    public Double mcOULabCstAmt;
    public Float mcOSTimeQty;
    public Double mcOSLabCstAmt;
    public Double mcCPartCostAmt;
    public Integer mcCUTimeQty;
    public Double mcCULabCstAmt;
    public Integer mcCSTimeQty;
    public Double mcCSLabCstAmt;
}