package logicole.common.datamodels.inventory;

import logicole.common.datamodels.ref.DataRef;

import java.util.Objects;

public class InventoryLocationRef extends DataRef {

    public InventoryLocationRef() {
    }

    public InventoryLocationRef(String id, String name) {
        this.createNewHashCode();
    }

    @Override
    protected int generateHashCode() {
        return Objects.hash(id, name);
    }
}
