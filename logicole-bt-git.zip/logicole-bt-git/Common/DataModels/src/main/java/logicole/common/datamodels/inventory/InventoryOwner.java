package logicole.common.datamodels.inventory;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import logicole.common.datamodels.general.Contact;
import logicole.common.datamodels.organization.NodeRef;
import logicole.common.datamodels.ref.DataRef;
import logicole.common.datamodels.ref.ReferencedData;

@JsonIgnoreProperties(ignoreUnknown = true)
public class InventoryOwner extends ReferencedData {
    public String id;
    public String name;
    public String description;
    public NodeRef orgNodeRef = new NodeRef();
    public String materialOwnershipType;
    public String valuationMethod;
    public String defaultLevelingMethod;
    public String defaultLevelingType;
    public Integer defaultInventoryDays;
    public Contact pointOfContact = new Contact();

    @Override
    @JsonIgnore
    public DataRef getRef() {
        InventoryOwnerRef ref = new InventoryOwnerRef();
        ref.id = id;
        ref.name = name;
        return ref;
    }
}
