package logicole.common.datamodels.finance;

import logicole.common.datamodels.general.EventType;
import logicole.common.datamodels.general.EventSubType;

public class FinanceDecisionCriteria {
    public String accountingSystem;
    public EventType eventType;
    public EventSubType eventSubType;
}
