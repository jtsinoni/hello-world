package logicole.common.datamodels.organization;


import logicole.common.datamodels.user.RoleRef;

import java.util.ArrayList;
import java.util.List;

public class Consumer {
    public List<RoleRef> roleRefs = new ArrayList<>();
}