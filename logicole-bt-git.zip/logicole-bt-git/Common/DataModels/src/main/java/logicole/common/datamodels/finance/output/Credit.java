package logicole.common.datamodels.finance.output;

import logicole.common.datamodels.finance.FundingSourceRef;
import logicole.common.datamodels.order.buyer.BuyerRef;
import logicole.common.datamodels.order.order.OrderRef;
import logicole.common.datamodels.product.Offer;

import java.util.Date;

public class Credit {
    public String externalCoordinationId;
    public boolean isUpdate;
    //public SellerRef sellerRef; not needed if in the offer
    public Offer offer;
    public Integer quantity;
    //public Double price; not needed if in the offer
    public Date requestedDelivery;
    public OrderRef orderRef;
    public FundingSourceRef fundingSourceRef;
    public BuyerRef buyerRef;
    public boolean isDebit;

}
