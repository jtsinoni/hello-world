package logicole.common.datamodels.organization;

import java.util.ArrayList;
import java.util.List;

public class AncestryQuery {
    public String nodeTypeId;
    public List<String> scopeNodeIds = new ArrayList<>();
}
