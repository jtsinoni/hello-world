package logicole.common.datamodels.equipment;


public class NetworkSoftware {
    public String softwareTitle;
    public String version;
    public String installedBy;
    public String dateInstalled;
}