package logicole.common.datamodels.abi;

public class PackageUnit {
    public String id;
    public String ansiPackUnit;
    public String dodPackUnit;
    public String packText;
    public boolean inUse;
}
