package logicole.common.datamodels.equipment;


public class Notes {
    public Integer meId;
    public Integer meNotesID;
    public String meNoteAuthrNm;
    public String meNotesDate;
    public String meNotesText;
    public String meNotesTypeCD;

}