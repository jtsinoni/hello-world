package logicole.common.datamodels.finance;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import logicole.common.datamodels.product.Offer;
import logicole.common.datamodels.product.Product;

@JsonIgnoreProperties(ignoreUnknown = true)
public class FinanceItem {
    public Integer quantity;
    public String documentNumber;
    public Integer lineNumber;
    public Integer fiscalYear;
    public Product product;
    public Offer offer;
}
