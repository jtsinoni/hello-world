package logicole.common.datamodels.order;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import logicole.common.datamodels.ref.ReferencedData;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AuthorizedSupplier {
    public String id;
    public String name;
    public String description;
    public String org;
    public String orgName;
    public String siteName;
}
