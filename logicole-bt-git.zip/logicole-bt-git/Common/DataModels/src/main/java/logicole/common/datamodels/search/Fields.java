package logicole.common.datamodels.search;

import com.fasterxml.jackson.databind.node.ObjectNode;

import java.util.ArrayList;
import java.util.List;


public class Fields {
    public List<ObjectNode> hits = new ArrayList<>();
}
