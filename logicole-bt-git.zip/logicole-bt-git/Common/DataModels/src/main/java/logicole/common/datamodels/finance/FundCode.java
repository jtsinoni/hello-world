package logicole.common.datamodels.finance;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class FundCode{

    public String  id;
    public String  code;
    public String  billedService;
    public String  description;
    public Boolean displayEquipment;
    public String  status;
}