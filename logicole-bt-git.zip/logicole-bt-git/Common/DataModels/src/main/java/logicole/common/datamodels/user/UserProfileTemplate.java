package logicole.common.datamodels.user;

import logicole.common.datamodels.organization.NodeRef;
import logicole.common.datamodels.organization.NodeTypeRef;

import java.util.*;

public class UserProfileTemplate {
    //public String id;
    public Date profileExpirationDate;
    public NodeRef currentNodeRef;
    public NodeRef managedByNodeRef;
    public NodeTypeRef nodeTypeRef;
    public List<NodeRef> scopeNodeRefs;
    public List<RoleRef> roleRefs;
    public List<AssignedPermission> assignedPermissions = new ArrayList<>();
}
