package logicole.common.datamodels.finance.fundingsource;

import logicole.common.datamodels.ref.DataRef;

import java.util.Objects;

public class FundingSourceRef extends DataRef {
    public String fundType;

    @Override
    protected int generateHashCode() {
        return Objects.hash(id, name, fundType);
    }
}
