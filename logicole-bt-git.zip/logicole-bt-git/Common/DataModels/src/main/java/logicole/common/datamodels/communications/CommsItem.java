package logicole.common.datamodels.communications;

import java.util.Map;

public class CommsItem {

    public Map<String, String> commsFields;

}
