package logicole.common.datamodels.search.filter;

import java.util.Date;

public class FilterElement {
    public String field;
    public String value;
    public Date dateValue;
    public Float numericValue;
    public FieldValueComparitor operator;

    public FilterElement(){}
    public FilterElement(String field, String value) {
        this.field = field;
        this.value = value;
    }
    public FilterElement(String field, String value, FieldValueComparitor operator) {
        this.field = field;
        this.value = value;
    }
    public FilterElement(String field, Float value) {
        this.field = field;
        this.numericValue = value;
    }
    public FilterElement(String field, Float value, FieldValueComparitor operator) {
        this.field = field;
        this.numericValue = value;
        this.operator = operator;
    }
    public FilterElement(String field, Date value) {
        this.field = field;
        this.dateValue = value;
    }
    public FilterElement(String field, Date value, FieldValueComparitor operator) {
        this.field = field;
        this.dateValue = value;
        this.operator = operator;
    }
}
