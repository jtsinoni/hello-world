package logicole.common.datamodels.user;

import com.fasterxml.jackson.annotation.JsonIgnore;
import logicole.common.datamodels.organization.NodeRef;
import logicole.common.datamodels.ref.DataRef;
import logicole.common.datamodels.ref.ReferencedData;

import java.util.List;

public class CurrentUser extends ReferencedData {
    public UserProfile profile;
    public List<String> effectiveEndpoints;
    public List<String> states;
    public List<String> elements;
    public List<NodeRef> accessToNodes;

    @Override
    @JsonIgnore
    public DataRef getRef() {
        CurrentUserBtRef ref = new CurrentUserBtRef();
        ref.id = this.profile.id;
        ref.fullName = this.profile.getFullName();
        ref.pkiDn = this.profile.pkiDn;
        ref.id = this.profile.id;
        return ref;
    }
}
