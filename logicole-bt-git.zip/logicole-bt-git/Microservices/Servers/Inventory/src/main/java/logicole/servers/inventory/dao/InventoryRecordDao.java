package logicole.servers.inventory.dao;

import logicole.servers.inventory.datamodel.InventoryRecordDO;

import javax.enterprise.context.Dependent;

@Dependent
public class InventoryRecordDao extends BaseInventoryDao<InventoryRecordDO, String>
 {
     public InventoryRecordDao() {
         super(InventoryRecordDO.class);
     }

 }
