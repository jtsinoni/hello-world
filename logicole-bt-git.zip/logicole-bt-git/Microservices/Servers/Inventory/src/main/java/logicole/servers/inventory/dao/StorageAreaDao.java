package logicole.servers.inventory.dao;

import logicole.servers.inventory.datamodel.StorageAreaDO;

import javax.enterprise.context.Dependent;

@Dependent
public class StorageAreaDao extends BaseInventoryDao<StorageAreaDO, String> {

    public StorageAreaDao() {
        super(StorageAreaDO.class);
    }

}
