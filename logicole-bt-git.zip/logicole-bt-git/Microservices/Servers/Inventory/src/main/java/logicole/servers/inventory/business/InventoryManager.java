package logicole.servers.inventory.business;

import logicole.common.datamodels.inventory.*;
import logicole.common.general.logging.Logger;
import logicole.common.servers.business.BaseManager;
import logicole.servers.inventory.dao.*;
import logicole.servers.inventory.datamodel.*;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.List;

@ApplicationScoped
public class InventoryManager extends BaseManager {

    @Inject
    InventoryRecordDao inventoryRecordDao;
    @Inject
    InventoryOwnerDao inventoryOwnerDao;
    @Inject
    StorageAreaDao storageAreaDao;
    @Inject
    InventoryLocationDao inventoryLocationDao;
    @Inject
    ShipmentDao shipmentDao;
    @Inject
    ShipperDao shipperDao;
    @Inject
    private Logger logger;

    public InventoryRecord getInventoryRecordById(String inventoryRecordId) {
        InventoryRecordDO inventoryRecordDO = inventoryRecordDao.findById(inventoryRecordId);
        return (InventoryRecord) inventoryRecordDO;
    }

    public List<InventoryOwner> getInventoryOwners() {
        List<? extends InventoryOwner> inventoryOwner = inventoryOwnerDao.findAll();
        return (List<InventoryOwner>) inventoryOwner;
    }

    public InventoryOwner getInventoryOwnerById(String inventoryOwnerId) {
        InventoryOwnerDO inventoryOwnerDO = inventoryOwnerDao.findById(inventoryOwnerId);
        return (InventoryOwner) inventoryOwnerDO;
    }

    public List<StorageArea> getStorageAreas() {
        List<? extends StorageArea> storageArea = storageAreaDao.findAll();
        return (List<StorageArea>) storageArea;
    }

    public StorageArea getStorageAreaById(String storageAreaId) {
        StorageAreaDO storageAreaDO = storageAreaDao.findById(storageAreaId);
        return (StorageArea) storageAreaDO;
    }

    public List<InventoryLocation> getInventoryLocations() {
        List<? extends InventoryLocation> inventoryLocation = inventoryLocationDao.findAll();
        return (List<InventoryLocation>) inventoryLocation;
    }

    public InventoryLocation getInventoryLocationById(String inventoryLocationId) {
        InventoryLocationDO inventoryLocationDO = inventoryLocationDao.findById(inventoryLocationId);
        return (InventoryLocation) inventoryLocationDO;
    }

    public List<Shipment> getShipments() {
        List<? extends Shipment> shipments = shipmentDao.findAll();
        return (List<Shipment>) shipments;
    }

    public Shipment getShipmentById(String shipmentId) {
        ShipmentDO shipmentDO = shipmentDao.findById(shipmentId);
        return (Shipment) shipmentDO;
    }

    public List<Shipment> getInShipments() {
        logger.info("calling shipmentDao.getInShipments()");
        List<? extends Shipment> inShipments = shipmentDao.getInShipments();
        return (List<Shipment>) inShipments;
    }

    public List<Shipment> getOutShipments() {
        logger.info("calling shipmentDao.getOutShipments()");
        List<? extends Shipment> outShipments = shipmentDao.getOutShipments();
        return (List<Shipment>) outShipments;
    }

    public List<Shipper> getShippers() {
        List<? extends Shipper> shipper = shipperDao.findAll();
        return (List<Shipper>) shipper;
    }

    public Shipper getShipperById(String shipperId) {
        ShipperDO shipperDO = shipperDao.findById(shipperId);
        return (Shipper) shipperDO;
    }
}
