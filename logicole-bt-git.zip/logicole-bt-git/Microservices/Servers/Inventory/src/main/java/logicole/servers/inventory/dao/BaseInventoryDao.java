package logicole.servers.inventory.dao;

import logicole.common.servers.persistence.BasePersistedDao;
import logicole.common.servers.persistence.PersistedEntity;

public abstract class BaseInventoryDao<T extends PersistedEntity, PK>
        extends BasePersistedDao<T, PK> {

    private static final String DBNAME = "dmlesInventory";

    public BaseInventoryDao(Class<T> persistentClass) {
        super(persistentClass, DBNAME);
    }

    public BaseInventoryDao(Class<T> persistentClass, boolean allowDelete) {
        super(persistentClass, DBNAME, allowDelete);
    }
}
