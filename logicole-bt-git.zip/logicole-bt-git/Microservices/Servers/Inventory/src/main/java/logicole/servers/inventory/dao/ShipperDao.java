package logicole.servers.inventory.dao;

import logicole.servers.inventory.datamodel.ShipperDO;

import javax.enterprise.context.Dependent;

@Dependent
public class ShipperDao extends BaseInventoryDao<ShipperDO, String> {

    public ShipperDao() {
        super(ShipperDO.class);
    }

}
