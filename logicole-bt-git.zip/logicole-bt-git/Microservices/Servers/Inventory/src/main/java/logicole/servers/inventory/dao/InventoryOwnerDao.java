package logicole.servers.inventory.dao;

import logicole.servers.inventory.datamodel.InventoryOwnerDO;

import javax.enterprise.context.Dependent;

@Dependent
public class InventoryOwnerDao extends BaseInventoryDao<InventoryOwnerDO, String> {

    public InventoryOwnerDao() {
        super(InventoryOwnerDO.class);
    }

}
