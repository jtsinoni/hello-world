package logicole.servers.inventory.dao;

import logicole.servers.inventory.datamodel.InventoryLocationDO;

import javax.enterprise.context.Dependent;

@Dependent
public class InventoryLocationDao extends BaseInventoryDao<InventoryLocationDO, String> {

    public InventoryLocationDao() {
        super(InventoryLocationDO.class);
    }

}
