package logicole.servers.inventory.dao;

import logicole.common.servers.persistence.Query;
import logicole.servers.inventory.datamodel.ShipmentDO;

import javax.enterprise.context.Dependent;
import java.util.List;

@Dependent
public class ShipmentDao extends BaseInventoryDao<ShipmentDO, String> {

    public ShipmentDao() {
        super(ShipmentDO.class);
    }

    public List<ShipmentDO> getInShipments() {
        Query<ShipmentDO> query = getQuery();
        query.field("shipmentDirection").equal("INBOUND");
        return query.asList();
    }

    public List<ShipmentDO> getOutShipments() {
        Query<ShipmentDO> query = getQuery();
        query.field("shipmentDirection").equal("OUTBOUND");
        return query.asList();
    }

}
