package logicole.servers.communications.dao;

import logicole.common.servers.persistence.BasePersistedDao;
import logicole.common.servers.persistence.PersistedEntity;

public abstract class BaseCommunicationsDao<T extends PersistedEntity, PK>
        extends BasePersistedDao<T, PK> {

    private static final String DBNAME = "dmlesCommunications";

    public BaseCommunicationsDao(Class<T> persistentClass) {
        super(persistentClass, DBNAME);
    }

    public BaseCommunicationsDao(Class<T> persistentClass, boolean allowDelete) {
        super(persistentClass, DBNAME, allowDelete);
    }
}
