package logicole.servers.communications;

import logicole.common.restserver.JaxRsModuleApplication;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.ApplicationPath;

@ApplicationPath("/")
@ApplicationScoped
public class JaxRsActivator extends JaxRsModuleApplication {

    public JaxRsActivator() {
        super("communications");
        moduleResources.add(CommunicationsMicroservice.class);
    }

}
