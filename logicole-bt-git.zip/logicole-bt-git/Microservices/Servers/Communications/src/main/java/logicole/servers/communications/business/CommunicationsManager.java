package logicole.servers.communications.business;


import logicole.common.servers.business.BaseManager;


import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class CommunicationsManager extends BaseManager {


}

