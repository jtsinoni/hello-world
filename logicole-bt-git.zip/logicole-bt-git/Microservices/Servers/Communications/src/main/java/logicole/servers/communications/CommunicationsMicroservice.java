package logicole.servers.communications;


import logicole.common.datamodels.HealthCheckResult;
import logicole.common.datamodels.VersionInformation;
import logicole.common.servers.servers.Microservice;
import logicole.apis.communications.ICommunicationsMicroserviceApi;
import logicole.servers.communications.business.CommunicationsManager;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;


@ApplicationScoped
public class CommunicationsMicroservice extends Microservice implements ICommunicationsMicroserviceApi {


    @Inject
    private CommunicationsManager communicationsManager;

    public CommunicationsMicroservice(){super ("Communications");}


    @Override
    public HealthCheckResult checkHealth() {
        return null;
    }

    @Override
    public VersionInformation getVersionInformation() {
        return null;
    }
}
