
package logicole.servers.asset.business;


import logicole.common.datamodels.CurrentUserBT;
import logicole.common.general.util.ObjectMapper;
import logicole.servers.asset.dao.EquipmentRecordDao;
import org.junit.Before;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

public class EquipmentRecordBaseTest {

    @Mock
    protected CurrentUserBT user;
    @Mock
    protected EquipmentRecordDao equipmentRecordDao;
    @Mock
    protected ObjectMapper objectMapper;

    @InjectMocks
    protected EquipmentRecordManager equipmentRecordManager;

    @InjectMocks
    protected EquipmentRecordAggregations equipmentRecordAggregations;


    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

}