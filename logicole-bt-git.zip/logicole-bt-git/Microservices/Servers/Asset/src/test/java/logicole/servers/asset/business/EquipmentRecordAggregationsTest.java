package logicole.servers.asset.business;

import logicole.common.datamodels.search.request.Aggregation;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class EquipmentRecordAggregationsTest extends EquipmentRecordBaseTest {


    @InjectMocks
    protected EquipmentRecordAggregations equipmentRecordAggregations;


    @Test
    public void testInit() {
        EquipmentRecordAggregations equipmentRecordAggregationsSpy = spy(equipmentRecordAggregations);
        equipmentRecordAggregationsSpy.init();
        verify(equipmentRecordAggregationsSpy, times(1)).init();
    }

    @Test
    public void getAggregations1() {
        // test that non-initialized class returns null
        EquipmentRecordAggregations equipmentRecordAggregationsSpy = spy(equipmentRecordAggregations);
        List<Aggregation> aggregations = equipmentRecordAggregationsSpy.getAggregations();
        verify(equipmentRecordAggregationsSpy, times(1)).getAggregations();
        assertEquals(aggregations, null);
    }

    @Test
    public void getAggregations2() {
        // test that initialized class returns list of aggregations
        EquipmentRecordAggregations equipmentRecordAggregationsSpy = spy(equipmentRecordAggregations);
        equipmentRecordAggregationsSpy.init();
        List<Aggregation> aggregations = equipmentRecordAggregationsSpy.getAggregations();
        verify(equipmentRecordAggregationsSpy, times(1)).getAggregations();
        assertNotNull(aggregations);
    }
}
