package logicole.servers.asset.business;

import logicole.common.datamodels.equipment.EquipmentRecord;
import logicole.servers.asset.datamodel.EquipmentRecordDO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.*;


@RunWith(MockitoJUnitRunner.class)
public class GetEquipmentRecordTest extends EquipmentRecordBaseTest {

    private static String dodaac = "dodaac";
    private static int meId = 1;
    private static int systemId = 11;

    @Test
    public void test0() {
        List<EquipmentRecordDO> doList = new ArrayList<>();

        when(equipmentRecordDao.getEquipmentRecord(dodaac, meId)).thenReturn(doList);

        EquipmentRecord equipmentRecord = new EquipmentRecord();
        when(objectMapper.getObject(eq(EquipmentRecord.class), any(EquipmentRecordDO.class))).thenReturn(equipmentRecord);

        equipmentRecordManager.getEquipmentRecord(dodaac, meId);

        verify(equipmentRecordDao).getEquipmentRecord(dodaac, meId);
        verify(objectMapper).getObject(eq(EquipmentRecord.class), any(EquipmentRecordDO.class));
    }

    @Test
    public void test1() {
        List<EquipmentRecordDO> doList = new ArrayList<>();
        EquipmentRecordDO equipmentRecordDO = mock(EquipmentRecordDO.class);
        doList.add(equipmentRecordDO);

        when(equipmentRecordDao.getEquipmentRecord(dodaac, meId)).thenReturn(doList);
        EquipmentRecord equipmentRecord = new EquipmentRecord();
        when(objectMapper.getObject(eq(EquipmentRecord.class), any(EquipmentRecordDO.class))).thenReturn(equipmentRecord);

        equipmentRecordManager.getEquipmentRecord(dodaac, meId);

        verify(equipmentRecordDao).getEquipmentRecord(dodaac, meId);
        verify(objectMapper).getObject(eq(EquipmentRecord.class), any(EquipmentRecordDO.class));
        verify(objectMapper).getObject(EquipmentRecord.class, equipmentRecordDO);
    }

    @Test
    public void test2() {
        EquipmentRecordManager equipmentRecordManagerSpy = spy(equipmentRecordManager);

        List<EquipmentRecordDO> doList = new ArrayList<>();
        EquipmentRecordDO equipmentRecordDO = mock(EquipmentRecordDO.class);
        doList.add(equipmentRecordDO);
        EquipmentRecord er = mock(EquipmentRecord.class);
        er.meSystemId = systemId;

        when(equipmentRecordDao.getEquipmentRecord(dodaac, meId)).thenReturn(doList);
        EquipmentRecord equipmentRecord = new EquipmentRecord();
        equipmentRecord.meSystemId = systemId;
        when(objectMapper.getObject(eq(EquipmentRecord.class), any(EquipmentRecordDO.class))).thenReturn(equipmentRecord);

        equipmentRecordManagerSpy.getEquipmentRecord(dodaac, meId);

        verify(equipmentRecordDao).getEquipmentRecord(dodaac, meId);
        verify(objectMapper).getObject(eq(EquipmentRecord.class), any(EquipmentRecordDO.class));
        verify(objectMapper).getObject(EquipmentRecord.class, equipmentRecordDO);
    }
}


