package logicole.servers.asset.dao;

import logicole.common.servers.persistence.BasePersistedDao;
import logicole.common.servers.persistence.PersistedEntity;

public abstract class BaseAssetDao<T extends PersistedEntity, PK>
        extends BasePersistedDao<T, PK> {

    private static final String DBNAME = "dmlesEquipment";

    public BaseAssetDao(Class<T> persistentClass) {
        super(persistentClass, DBNAME);
    }

    public BaseAssetDao(Class<T> persistentClass, boolean allowDelete) {
        super(persistentClass, DBNAME, allowDelete);
    }
}
