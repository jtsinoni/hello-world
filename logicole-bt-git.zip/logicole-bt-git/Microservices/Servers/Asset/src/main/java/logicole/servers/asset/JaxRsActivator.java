package logicole.servers.asset;

import logicole.common.restserver.JaxRsModuleApplication;


import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.ApplicationPath;

@ApplicationPath("/")
@ApplicationScoped
public class JaxRsActivator extends JaxRsModuleApplication {

    public JaxRsActivator() {
        super("asset");
        moduleResources.add(AssetMicroservice.class);
        moduleResources.add(EquipmentRecordMicroservice.class);
    }

}
