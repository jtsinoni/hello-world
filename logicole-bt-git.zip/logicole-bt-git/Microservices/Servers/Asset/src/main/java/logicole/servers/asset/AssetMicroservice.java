package logicole.servers.asset;


import logicole.apis.asset.IAssetMicroserviceApi;
import logicole.common.datamodels.HealthCheckResult;
import logicole.common.datamodels.VersionInformation;
import logicole.common.servers.servers.Microservice;
import logicole.servers.asset.business.AssetManager;


import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;


@ApplicationScoped
public class AssetMicroservice extends Microservice implements IAssetMicroserviceApi {


    @Inject
    private AssetManager assetManager;

    public AssetMicroservice(){super ("Asset");}


    @Override
    public HealthCheckResult checkHealth() {
        return null;
    }

    @Override
    public VersionInformation getVersionInformation() {
        return null;
    }
}
