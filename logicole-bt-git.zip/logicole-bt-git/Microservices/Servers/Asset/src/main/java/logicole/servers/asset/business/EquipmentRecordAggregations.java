package logicole.servers.asset.business;

import logicole.common.datamodels.search.request.Aggregation;

import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import java.util.ArrayList;
import java.util.List;

@ApplicationScoped
public class EquipmentRecordAggregations {

    private List<Aggregation> aggregations;

    @PostConstruct
    public void init() {
        aggregations = new ArrayList<>();
        aggregations.add(new Aggregation("deviceText", "deviceText", 5000, "asc"));
        aggregations.add(new Aggregation("manufOrgSerial", "manufOrgSerial", 5000, "asc"));
        aggregations.add(new Aggregation("mtfOrgSerial", "mtfOrgSerial", 5000, "asc"));
        aggregations.add(new Aggregation("meEcnId", "meEcnId", 250, "asc"));
        aggregations.add(new Aggregation("orgID", "orgID", 5000, "asc"));
        aggregations.add(new Aggregation("itemId", "itemId", 500, "asc"));
        aggregations.add(new Aggregation("custOrgNM", "custOrgNM", 5000, "asc"));
        aggregations.add(new Aggregation("custodianName", "custodianName", 5000, "asc"));
        aggregations.add(new Aggregation("custOrgSerial", "custOrgSerial", 5000, "asc"));
        aggregations.add(new Aggregation("meAcqCostQty", "meAcqCostQty", 5000, "asc"));
        aggregations.add(new Aggregation("meAcqDt", "meAcqDt", 5000, "asc"));
        aggregations.add(new Aggregation("siteDoDDAC", "siteDoDDAC", 5000, "asc"));
        aggregations.add(new Aggregation("equipmentManufacturer", "product.equipmentManufacturer", 5000, "asc"));
        aggregations.add(new Aggregation("commonModel", "product.commonModel", 5000, "asc"));
        aggregations.add(new Aggregation("nameplateModel", "meManufModelId", 5000, "asc"));
        aggregations.add(new Aggregation("manufacturerSerialNumber", "meMfgSerialId", 5000, "asc"));
        aggregations.add(new Aggregation("equipmentLocation", "locationInventory.pltPermntLocTx", 5000, "asc"));
        aggregations.add(new Aggregation("assemblageDescription", "assmDescrDetail", 5000, "asc"));
        aggregations.add(new Aggregation("assemblageNumber", "assmNumDetail", 5000, "asc"));
        aggregations.add(new Aggregation("maintenanceActivity", "maintenance.maintActivityOrgNm", 5000, "asc"));
        aggregations.add(new Aggregation("scheduledTeam", "maintenance.schedTeamOrgNm", 5000, "asc"));
        aggregations.add(new Aggregation("unscheduledTeam", "maintenance.unschedTeamOrgNm", 5000, "asc"));
        aggregations.add(new Aggregation("contractor", "maintenance.contractorNm", 5000, "asc"));
        aggregations.add(new Aggregation("ownership", "eqpmtOwnerTypCd", 5000, "asc"));
    }

    public List<Aggregation> getAggregations() {
        return this.aggregations;
    }
}
