package logicole.servers.asset.dao;

import logicole.common.servers.persistence.DataStore;
import logicole.servers.asset.datamodel.EquipmentRecordDO;

import javax.enterprise.context.Dependent;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Dependent
public class EquipmentRecordDao extends BaseAssetDao<EquipmentRecordDO, String> {

    public EquipmentRecordDao() {
        super(EquipmentRecordDO.class);
    }

    protected void setDatastore(DataStore datastore) {
        super.setDatastore(datastore);
    }

    public <T> List<EquipmentRecordDO> getEquipmentRecord(T dodaac, T meId) {
        Map<String, T> fieldFilter = new HashMap<>();
        fieldFilter.put("siteDoDDAC", dodaac);
        fieldFilter.put("meId", meId);
        return this.query(fieldFilter);
    }

}