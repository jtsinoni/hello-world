package logicole.servers.asset.business;

import logicole.common.datamodels.CurrentUserBT;
import logicole.common.datamodels.equipment.EquipmentRecord;
import logicole.common.datamodels.equipment.SearchInputEquipmentRecord;
import logicole.common.datamodels.search.filter.FilterElement;
import logicole.common.datamodels.search.filter.RequestFilter;
import logicole.common.datamodels.search.request.DmlesSearchRequest;
import logicole.common.datamodels.search.request.DmlesSearchSource;
import logicole.common.datamodels.search.request.SearchOperator;
import logicole.common.datamodels.search.request.SortField;
import logicole.common.general.util.ObjectMapper;
import logicole.common.servers.business.BaseManager;
import logicole.servers.asset.dao.EquipmentRecordDao;
import logicole.servers.asset.datamodel.EquipmentRecordDO;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


@ApplicationScoped
public class EquipmentRecordManager extends BaseManager {

    //@Inject
    //private OrganizationManager organizationManager;
    @Inject
    protected CurrentUserBT currentUserBt;
    @Inject
    private EquipmentRecordAggregations equipmentRecordAggregations;
    @Inject
    private EquipmentRecordDao equipmentRecordDao;
    @Inject
    private ObjectMapper objectMapper;


    static final String[] RESPONSE_FIELDS = {
            "id",
            "deviceText",
            "orgID",
            "meId",
            "meEcnId",
            "manufOrgName",
            "meManufModelId",
            "nameplateModel",
            "meMfgSerialId",
            "itemId",
            "mtfOrgID",
            "mtfOrgNM",
            "siteDoDDAC",
            "deleteInd",
            "custOrgNM",
            "custOrgId",
            "pltPermntLocTx",
            "eqptOwnershipDesc",
            "eqpmtOwnerTypCd",
            "assmDescrDetail",
            "assmNumDetail",
            "meAcqDt",
            "maOrgNm",
            "schedTeamName",
            "unschedTeamName",
            "contractor",
            "eiAccntblCd",
            "eiMaintReqrCd",
            "isSentToEhr",
            "meAcqCostQty",
            "custodianName",
            "notes",
            "locationInventory",
            "maintenance",
            "product",
            "maintenance",
    };

    static final String[] SEARCH_FIELDS = {
            "_searchall"
    };

    static final List<String> NUMERIC_FIELDS;
    static final List<SortField> SORT_FIELDS;

    static {
        SORT_FIELDS = new ArrayList<>();

        NUMERIC_FIELDS = new ArrayList<>();
        NUMERIC_FIELDS.add("meAcqCostQty");
        NUMERIC_FIELDS.add("eqpmtOwnerTypCd");
    }

    public DmlesSearchRequest buildEquipmentSearchRequest(SearchInputEquipmentRecord searchInputEquipmentRecord) {
        DmlesSearchRequest searchRequest = new DmlesSearchRequest();

        if (searchInputEquipmentRecord != null) {

            List<RequestFilter> filters = new ArrayList<>();
            if (searchInputEquipmentRecord.filters != null) {
                for (RequestFilter f : searchInputEquipmentRecord.filters) {
                    filters.add(f);
                }
            }

            // append the appropriate filters for orgId/dodaac
            if (filters.size() > 0) {
                // see if there is already a filter for orgId/siteDoDDAC passed in from the user (if so, search for that specific orgId)
                boolean filterExists = this.doesFilterExist(filters, "siteDoDDAC");
                if (!filterExists) {
                    // there is no search clause for siteDoDDAC/orgId, so append all of the orgIds that this user can see
                    createDodaacFilter(filters, searchInputEquipmentRecord.orgIds);
                }
            } else {
                // there is no search clause for siteDoDDAC/orgId, append all that apply to this user
                createDodaacFilter(filters, searchInputEquipmentRecord.orgIds);
            }


            searchRequest.queryString = searchInputEquipmentRecord.queryString;
            searchRequest.filters = filters;
            searchRequest.searchWithinResults = searchInputEquipmentRecord.searchWithinResults;
            searchRequest.numericSearchSortFields = NUMERIC_FIELDS;
            searchRequest.responseFields = Arrays.asList(RESPONSE_FIELDS);
            searchRequest.aggregations = equipmentRecordAggregations.getAggregations();
            searchRequest.source = new DmlesSearchSource("equipmentrecords");
            searchRequest.searchFields = Arrays.asList(SEARCH_FIELDS);
            searchRequest.sortFields = SORT_FIELDS;
            if (searchInputEquipmentRecord.operator == null) {
                searchRequest.searchOperator = SearchOperator.AND;
            } else {
                searchRequest.searchOperator = SearchOperator.getValue(searchInputEquipmentRecord.operator);
            }
            searchRequest.wholeWordsOnly = false;
            searchRequest.trailingWildcardOnly = true;
            searchRequest.escapeSpecialCharacters = false;
            searchRequest.resultSetOffset = 0;
            searchRequest.resultSetSize = 250;


        }
        return searchRequest;
    }

    boolean doesFilterExist(List<RequestFilter> filters, String field) {
        boolean found = false;
        if (filters != null && filters.size() > 0) {
            for (RequestFilter filter : filters) {
                if (filter.fieldValues != null) {
                    for (FilterElement element : filter.fieldValues) {
                        if (element.field.equalsIgnoreCase(field)) {
                            found = true;
                            break;
                        }
                    }
                }
            }
        }
        return found;
    }

    void createDodaacFilter(List<RequestFilter> filters, List<String> orgIds) {
        if (orgIds != null && orgIds.size() > 0 && filters != null) {
            filters.add(createRequestFilter("siteDoDDAC", orgIds, "or"));
        }
    }

    RequestFilter createRequestFilter(String field, List<String> values, String operator) {
        RequestFilter filter = new RequestFilter();
        filter.operator = operator;
        filter.fieldValues = new ArrayList<>();
        for (String value : values) {
            FilterElement filterElement = new FilterElement();
            filterElement.field = field;
            filterElement.value = value;
            filter.fieldValues.add(filterElement);
        }
        return filter;
    }

    public EquipmentRecord getEquipmentRecord(String dodaac, int meId) {
        List<EquipmentRecordDO> recordsFound = equipmentRecordDao.getEquipmentRecord(dodaac, meId);
        EquipmentRecordDO returnRecord = new EquipmentRecordDO();
        if (recordsFound.size() > 0) {
            returnRecord = recordsFound.get(0);
        }

        EquipmentRecord equipmentRecord = objectMapper.getObject(EquipmentRecord.class, returnRecord);
        if (equipmentRecord != null && equipmentRecord.meSystemId != null) {
            equipmentRecord.meSystemEcn = getEcnByMeId(dodaac, equipmentRecord.meSystemId);
        }
        return equipmentRecord;

    }

    String getEcnByMeId(String dodaac, int meId) {
        String ecn = "";
        List<EquipmentRecordDO> recordsFoundSystemId = equipmentRecordDao.getEquipmentRecord(dodaac, meId);
        if (recordsFoundSystemId.size() > 0) {
            EquipmentRecordDO returnRecordSystemId = recordsFoundSystemId.get(0);
            ecn = returnRecordSystemId.meEcnId;
        }

        return ecn;
    }

}

