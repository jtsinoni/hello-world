package logicole.servers.asset;


import logicole.apis.asset.IEquipmentRecordMicroserviceApi;
import logicole.common.datamodels.HealthCheckResult;
import logicole.common.datamodels.VersionInformation;
import logicole.common.datamodels.equipment.EquipmentRecord;
import logicole.common.datamodels.equipment.SearchInputEquipmentRecord;
import logicole.common.datamodels.search.request.DmlesSearchRequest;
import logicole.common.servers.servers.Microservice;
import logicole.servers.asset.business.EquipmentRecordManager;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.List;


@ApplicationScoped
public class EquipmentRecordMicroservice extends Microservice implements IEquipmentRecordMicroserviceApi {


    @Inject
    private EquipmentRecordManager equipmentRecordManager;

    public EquipmentRecordMicroservice() {
        super("EquipmentRecord");
    }


    @Override
    public HealthCheckResult checkHealth() {
        return null;
    }

    @Override
    public VersionInformation getVersionInformation() {
        return null;
    }

    @Override
    public DmlesSearchRequest buildEquipmentSearchRequest(SearchInputEquipmentRecord searchInputEquipmentRecord) {
        return equipmentRecordManager.buildEquipmentSearchRequest(searchInputEquipmentRecord);
    }

    @Override
    public EquipmentRecord getEquipmentRecord(String dodaac, int meId) {
        return equipmentRecordManager.getEquipmentRecord(dodaac, meId);
    }
}

