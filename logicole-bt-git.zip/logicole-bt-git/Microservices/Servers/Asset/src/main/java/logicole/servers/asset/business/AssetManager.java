package logicole.servers.asset.business;


import logicole.common.servers.business.BaseManager;
import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class AssetManager extends BaseManager {


}

