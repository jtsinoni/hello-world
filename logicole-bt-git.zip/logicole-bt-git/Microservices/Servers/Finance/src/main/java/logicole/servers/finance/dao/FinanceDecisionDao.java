package logicole.servers.finance.dao;

import logicole.common.servers.persistence.Query;
import logicole.servers.finance.datamodel.FinanceDecisionDO;

import java.util.List;
import javax.enterprise.context.Dependent;

@Dependent
public class FinanceDecisionDao extends BaseFinanceDao<FinanceDecisionDO, String> {

    public FinanceDecisionDao() {
        super(FinanceDecisionDO.class);
    }

    public FinanceDecisionDO findByHashValue(String hashValue) {
        Query<FinanceDecisionDO> query = getQuery();
        query.field("decisionCriteriaHash").equal(hashValue);

        List<FinanceDecisionDO> fddos = query.asList();

        FinanceDecisionDO retVal = null;

        if (fddos.size() > 0) {
            retVal = fddos.get(0);
        }
        return retVal;
    }

}
