package logicole.servers.finance.business.processor;

import logicole.common.datamodels.finance.FinanceItem;
import logicole.common.datamodels.finance.FundingNode;
import logicole.common.datamodels.finance.response.Balances;

import java.util.List;

public abstract class BaseFinanceProcessor implements IFinanceProcessor{

    public void logProcessorActivity() {

    }
    @Override
    public void process(List<FundingNode> fundingNodes, FinanceItem item) {
        for (FundingNode node : fundingNodes) {
            applyValues(node, item);
        }
    }

    protected abstract void applyValues(FundingNode node, FinanceItem item);

    protected void checkInit(FundingNode node) {
        if (node.balances == null) {
            node.balances = new Balances();
        }
    }

    public Double getCurrentValue(Double value) {
        Double currentVal = 0d;
        if (value != null) {
            currentVal = value;
        }
        return currentVal;
    }

}
