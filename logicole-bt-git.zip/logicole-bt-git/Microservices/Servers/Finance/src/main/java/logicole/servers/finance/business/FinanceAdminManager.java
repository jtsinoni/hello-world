package logicole.servers.finance.business;

import logicole.common.datamodels.finance.*;
import logicole.common.datamodels.finance.fundingsource.FundingSource;
import logicole.common.datamodels.general.FundType;
import logicole.common.datamodels.organization.OrgRef;
import logicole.common.general.exception.FatalProcessingException;
import logicole.common.general.util.ObjectMapper;
import logicole.common.servers.business.BaseManager;
import logicole.common.servers.business.RequestData;
import logicole.servers.finance.dao.*;
import logicole.servers.finance.datamodel.FundingNodeDO;
import logicole.servers.finance.datamodel.FundingSourceDO;
import org.bson.types.ObjectId;

import java.util.*;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;


@ApplicationScoped
public class FinanceAdminManager extends BaseManager {

    @Inject
    private FinancialSystemDao financeSystemDao;
    @Inject
    private FundingNodeDao fundingNodeDao;
    @Inject
    private SubAllocationHolderDao subAllocationHolderDao;
    @Inject
    private FundCodeDao fundCodeDao;
    @Inject
    private ForeignCurrencyDao foreignCurrencyDao;
    @Inject
    private MainAccountCodeDao MainAccountCodeDao;
    @Inject
    private CommodityCodeDao commodityCodeDao;
    @Inject
    private FundUsageTypeDao fundUsageTypeDao;
    @Inject
    private SubClassDao subClassDao;
    @Inject
    private SalesCodeTypeDao salesCodeTypeDao;
    @Inject
    private MainAccountTypeCodeDao mainAccountTypeCodeDao;
    @Inject
    private FundingSourceDao fundingSourceDao;
    @Inject
    private ObjectMapper objectMapper;
    @Inject
    private RequestData requestData;
    @Inject
    private ProcessingBalanceFactory processingBalanceFactory;
    @Inject
    private RefDataListDao refDataListDao;


    public List<FinancialSystem> getFinancialSystems() {
        List<? extends FinancialSystem> finsys = financeSystemDao.findAll();
        return (List<FinancialSystem>) finsys;
    }

    public List<FundingSourceFieldConfig> getFinancialSystemFieldConfigList(
            String financialSystemName) {
        List<? extends FundingSourceFieldConfig> retList =
                financeSystemDao.getFinancialSystemFieldConfigList(financialSystemName);
        return (List<FundingSourceFieldConfig>) retList;
    }

    public List<FundingSourceFieldConfig> getFinancialSystemFieldConfigListByType(
            String financialSystemName, String fieldType) {
        List<? extends FundingSourceFieldConfig> retList =
                financeSystemDao.getFinancialSystemFieldConfigListByType(financialSystemName, fieldType);
        return (List<FundingSourceFieldConfig>) retList;
    }

    public List<FundingNode> getFundingNodes(String id) {

        FundingNode topNode = fundingNodeDao.getFundingNodes(id);
        List<FundingNode> nodes = new ArrayList<>();
        nodes = getNodes(id, topNode, nodes);

        return nodes;
    }

    private List<FundingNode> getNodes(String id, FundingNode currentNode, List<FundingNode> nodes) {

        FundingNode parent = currentNode;

        for (FundingNode child : currentNode.children) {
            if (child.id.equalsIgnoreCase(id)) {
                nodes.add(parent);
                nodes.add(child);
                break;
            } else {
                if (child.children != null) {
                    nodes = getNodes(id, child, nodes);
                }
            }
        }
        return nodes;
    }


    public List<SubAllocationHolder> getSubAllocationHolders() {
        List<? extends SubAllocationHolder> suball = subAllocationHolderDao.findAll();
        return (List<SubAllocationHolder>) suball;
    }

    public List<FundCode> getFundCodes() {
        List<? extends FundCode> fundcode = fundCodeDao.findAll();
        return (List<FundCode>) fundcode;
    }

    public List<ForeignCurrency> getForeignCurrencies() {
        List<? extends ForeignCurrency> foreigncurr = foreignCurrencyDao.findAll();
        return (List<ForeignCurrency>) foreigncurr;
    }

    public List<MainAccount> getMainAccountCodes() {
        List<? extends MainAccount> mainaccount = MainAccountCodeDao.findAll();
        return (List<MainAccount>) mainaccount;
    }

    public List<CommodityCode> getCommodityCodes() {
        List<? extends CommodityCode> commodity = commodityCodeDao.findAll();
        return (List<CommodityCode>) commodity;
    }

    public List<FundUsageType> getFundUsageTypes() {
        List<? extends FundUsageType> fundusage = fundUsageTypeDao.findAll();
        return (List<FundUsageType>) fundusage;
    }

    public List<SalesCodeType> getSalesCodeTypes() {
        List<? extends SalesCodeType> salesCodes = salesCodeTypeDao.findAll();

        return (List<SalesCodeType>) salesCodes;
    }

    public List<SubClass> getSubClasses() {
        List<? extends SubClass> subclass = subClassDao.findAll();
        return (List<SubClass>) subclass;
    }

    public List<MainAccountType> getMainAccountTypeCodes() {
        List<? extends MainAccountType> fundusage = mainAccountTypeCodeDao.findAll();
        return (List<MainAccountType>) fundusage;
    }

    public FundingSource createFundingSource(FundingSource fundingSource) {

        FundingSource createFunding = null;
        List<FundingSourceDO> projectLst = fundingSourceDao.getFundingSourceDOByProjectId(fundingSource.sloa.projectIdentifier);

        if(projectLst != null  && !projectLst.isEmpty()) {

            if(projectLst.size() > 1) {
                String msg = String.format("%d Funding Source documents found with the ID: %s",projectLst.size(), fundingSource.sloa.projectIdentifier);
                throw new FatalProcessingException(msg);
            }

            FundingSourceDO updateFunding = projectLst.get(0);
            updateFunding.target = fundingSource.target;
            createFunding =  fundingSourceDao.update(updateFunding);
        }
        else {
            FundingSourceDO  fundingSourceDO = objectMapper.getObject(FundingSourceDO.class, fundingSource);
            if(fundingSourceDO != null) {
                createFunding = fundingSourceDao.insert(fundingSourceDO);
            }
        }

        return createFunding;
    }


    public FundingSource getFundingSourceById(String id) {
        return fundingSourceDao.findById(id);
    }

    public List<FundingSource> getAllFundingSource() {

        List<? extends FundingSource> fundingSources = fundingSourceDao.findAll();

        return (List<FundingSource>) fundingSources;
    }

    public List<FundingNode> getFundingNodesWithFundingSourceId(String id) {
        List<? extends FundingNode> nodes = fundingNodeDao.getFundingNodesWithFundingSourceId(id);

        return (List<FundingNode>) nodes;
    }

    public FundingNode updateFundingNode(FundingNode node) {
        FundingNode updatedNodes;
        if (node.id == null) {
            FundingNodeDO fndo = objectMapper.getObject(FundingNodeDO.class, node);
            FundingNode newNode = fundingNodeDao.insert(fndo);
            updatedNodes = newNode;
        } else {
            FundingNodeDO fndo = fundingNodeDao.findById(node.id);
            fndo.name = node.name;
            fndo.status = node.status;
            fndo = fundingNodeDao.update(fndo);
            updatedNodes = fndo;
        }
        return updatedNodes;
    }

    public FundingNode updateExpenseCenter(String id, FundingNode node) {
        ObjectId objectId = null;
        FundingNodeDO fndo = new FundingNodeDO();
        FundingNodeDO parent = fundingNodeDao.findById(id);
        List<FundingNode> children = parent.children;
        String node_id = node.id;
        String msg = String.format("System could not found the Expense Center.");

        if (children == null && node.id != null) {
            throw new FatalProcessingException(msg);
        }

        if (children != null) {
            boolean isfound = false;
            int index = 0;
            for (Iterator<FundingNode> iter = children.iterator(); iter.hasNext(); ) {
                FundingNode celement = iter.next();
                String celement_id = celement.id;

                //node found then update the node
                if(node_id != null && node_id.equals(celement_id)){
                    isfound = true;

                    fndo.id = node_id;
                    fndo.name = node.name;
                    fndo.description = node.description;
                    fndo.target = node.target;
                    children.set(index, fndo);

                }
                index++;
            }
            //if canont found child then error
            if(!isfound && node_id != null){
                throw new FatalProcessingException(msg);
            }

            if(node_id == null){
                 objectId = new ObjectId();
                 fndo.id = objectId.toString();
                 fndo.name = node.name;
                 fndo.description = node.description;
                 fndo.target = node.target;
                 children.add(index, fndo);
             }

        } else { //children is null
            children = new ArrayList<FundingNode>();
            objectId = new ObjectId();
            fndo.id = objectId.toString();
            fndo.name = node.name;
            fndo.description = node.description;
            fndo.target = node.target;
            children.add(fndo);
        }

        parent.children = children;
        FundingNode retval = fundingNodeDao.update(parent);

        return retval;

    }

    public FundingNode addBuyerToFund(String id, FundingNode node) {
        ObjectId objectId = null;
        FundingNodeDO fndo = new FundingNodeDO();
        FundingNodeDO parent = fundingNodeDao.findById(id);
        List<FundingNode> children = parent.children;
        String node_id = node.id;
        String msg = String.format("System could not found the Expense Center.");
        return fndo;
    }

    public List<ProcessingBalance> getFundingNodesByBuyer(String id) {
        Map<String, String> map = new HashMap<>();
        map.put("children.buyers.id", id);
        List<? extends FundingNode> buyers = fundingNodeDao.query(map);
        List<ProcessingBalance> responses = getProcessingBalancees(buyers);
        return responses;

    }

    List<ProcessingBalance> getProcessingBalancees(List<? extends FundingNode> nodes) {

        List<ProcessingBalance> balances = new ArrayList<>();

        for (FundingNode node : nodes) {
            FundType fundType = node.fundingSourceRefs.get(0).fundType;
            ProcessingBalance balance = processingBalanceFactory.getProcessingBalance(node, fundType);
            balances.add(balance);
        }

        return balances;
    }

    public FundingNode removeBuyerFromFund(String expenseId, String buyerId) {
        FundingNodeDO parent  =   fundingNodeDao.getFundingNodes(expenseId);
        Object[] vals = getChildFromParentWithBuyerId(parent, buyerId);
        FundingNode child = (FundingNode) vals[0];
        OrgRef buyer = (OrgRef) vals[1];
        child.buyers.remove(buyer);
        FundingNode retval = fundingNodeDao.update(parent);
        return retval;
    }

    Object[] getChildFromParentWithBuyerId(FundingNodeDO parent, String buyerId) {
        Object[] vals = null;
        for (FundingNode child: parent.children) {
            for (OrgRef buyer: child.buyers) {
                if (buyerId.equals(buyer.id)) {
                    vals = new Object[2];
                    vals[0] = child;
                    vals[1] = buyer;
                    break;
                }
            }
            if (vals != null) {
                break;
            }
        }
        return vals;
    }

    public FundingNode updateBuyer(String expenseCenterId, OrgRef buyerIn) {
        FundingNodeDO parent = fundingNodeDao.getFundingNodes(expenseCenterId);
        FundingNode child = getChildFromParent(expenseCenterId, parent);
        updateBuyerRef(buyerIn, child);

        FundingNode retval = fundingNodeDao.update(parent);

        return retval;
    }

    void updateBuyerRef(OrgRef buyerIn, FundingNode child) {
        boolean foundBuyer = false;
        for (OrgRef orgRef : child.buyers) {
            if (buyerIn.id.equals(orgRef.id)) {
                orgRef.name = buyerIn.name;
                foundBuyer = true;
                break;
            }
        }
        if (!foundBuyer) {   child.buyers.add(buyerIn);

        }
    }

    FundingNode getChildFromParent(String expenseCenterId, FundingNodeDO parent) {
        FundingNode found = null;

        for (FundingNode child: parent.children) {
            if (child.id.equals(expenseCenterId)) {
                found = child;
                break;
            }
        }
        if (found == null) {
            throw new FatalProcessingException("Child node not found - " + expenseCenterId);
        }
        return found;
    }


    public List<FundingNode> getAllFundingNodes() {

        List<? extends FundingNode> fundingNodes = fundingNodeDao.findAll();

        return (List<FundingNode>) fundingNodes;
    }

    public List<RefDataList> getRefDataList(String module) {
        List<? extends RefDataList> retList =
                refDataListDao.getRefDatListByCollectionName(module);
        return (List<RefDataList>) retList;
    }


}