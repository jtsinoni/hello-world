package logicole.servers.finance.dao;

import logicole.servers.finance.datamodel.SubAllocationHolderDO;

import javax.enterprise.context.Dependent;

@Dependent
public class SubAllocationHolderDao extends BaseFinanceDao<SubAllocationHolderDO, String> {

    public SubAllocationHolderDao() {
        super(SubAllocationHolderDO.class);
    }

}