package logicole.servers.finance.dao;

import logicole.common.datamodels.finance.FundingSourceFieldConfig;
import logicole.common.servers.persistence.Query;
import logicole.servers.finance.datamodel.FinancialSystemDO;

import javax.enterprise.context.Dependent;
import java.util.ArrayList;
import java.util.List;

@Dependent
public class FinancialSystemDao extends BaseFinanceDao<FinancialSystemDO, String> {

    public FinancialSystemDao() {
        super(FinancialSystemDO.class);
    }

    public List<? extends FundingSourceFieldConfig> getFinancialSystemFieldConfigListByType(
            String financialSystemName,
            String fieldType) {

        Query<FinancialSystemDO> query = getQuery();
        query.field("name").equal(financialSystemName);

        List<FinancialSystemDO> financialSystemList = query.asList();

        List<FundingSourceFieldConfig> retVal = new ArrayList<>();
        if (financialSystemList != null && financialSystemList.size() > 0) {
            List<FundingSourceFieldConfig> fieldConfigList = financialSystemList.get(0).fields;

            if (fieldType != null) {
                for (FundingSourceFieldConfig field : fieldConfigList) {
                    if (field.type.toString().equals(fieldType)) {
                        retVal.add(field);
                    }
                }
            } else {
                retVal = fieldConfigList;
            }
        }

        return retVal;
    }

    public List<? extends FundingSourceFieldConfig> getFinancialSystemFieldConfigList(
            String financialSystemName) {

        return getFinancialSystemFieldConfigListByType(financialSystemName, null);
    }

}
