package logicole.servers.finance.dao;

import logicole.common.datamodels.ref.Refs;
import logicole.common.servers.persistence.BasePersistedDao;
import logicole.common.servers.persistence.PersistedEntity;

public abstract class BaseFinanceDao<T extends PersistedEntity, PK>
        extends BasePersistedDao<T, PK> {

    private static final String DBNAME = "dmlesFinance";

    public BaseFinanceDao(Class<T> persistentClass) {
        super(persistentClass, DBNAME);
    }

    public BaseFinanceDao(Class<T> persistentClass, Refs.References ref) {
        super(persistentClass, DBNAME, ref);
    }

    public BaseFinanceDao(Class<T> persistentClass, boolean allowDelete) {
        super(persistentClass, DBNAME, allowDelete);
    }
}
