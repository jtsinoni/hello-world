package logicole.servers.finance.dao;

import logicole.servers.finance.datamodel.SubClassDO;

import javax.enterprise.context.Dependent;

@Dependent
public class SubClassDao extends BaseFinanceDao<SubClassDO, String> {

    public SubClassDao() {
        super(SubClassDO.class);
    }

}
