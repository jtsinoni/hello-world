package logicole.servers.finance.business;

import logicole.common.datamodels.finance.*;
import logicole.common.datamodels.finance.request.CommonFinanceRequest;
import logicole.common.datamodels.finance.request.RequestGroup;
import logicole.common.datamodels.finance.response.*;
import logicole.common.datamodels.general.*;
import logicole.common.general.util.*;
import logicole.common.servers.business.BaseManager;
import logicole.servers.finance.business.decision.DecisionManager;
import logicole.servers.finance.business.processor.IFinanceProcessor;
import logicole.servers.finance.dao.*;
import logicole.servers.finance.datamodel.FundingNodeDO;

import java.util.*;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

@ApplicationScoped
public class FinanceManager extends BaseManager {

    @Inject
    private FinanceDecisionDao financeDecisionDao;
    @Inject
    private HashUtil hashUtil;
    @Inject
    private FinanceAdminManager financeAdminManager;
    @Inject
    private CdiUtil cdiUtil;
    @Inject
    private DecisionManager decisionManager;
    @Inject
    private FundingNodeDao fundingNodeDao;
    @Inject
    private ObjectMapper mapper;
    @Inject
    private ProcessingBalanceFactory processingBalanceFactory;

    public List<FinanceDecision> getFinanceDecisions() {
        List<? extends FinanceDecision> financeDecisions =  financeDecisionDao.findAll();
        return (List<FinanceDecision>) financeDecisions;
    }

    public CommonFinanceResponse processBusinessEvent(CommonFinanceRequest commonFinanceRequest) {

        EventType eventType = commonFinanceRequest.eventType;
        CommonFinanceResponse retVal = new CommonFinanceResponse();

        Map<String, FundingNode> fundingNodeMap = new HashMap<>();

        for (RequestGroup requestGroup: commonFinanceRequest.requestGroups) {
            FundingNodeRef fundingNodeRef = requestGroup.fundingNodeRef;
            FundingSourceRef fundingSourceRef = fundingNodeRef.fundingSourceRefs.get(0);
            String accountingSystem = fundingSourceRef.financialSystemRef.name;
            EventSubType eventSubType = commonFinanceRequest.eventSubType;
            FundType fundType = fundingSourceRef.fundType;

            ResponseGroup responseGroup = new ResponseGroup();

            List<FundingNode> fundingNodes = financeAdminManager.getFundingNodes(requestGroup.fundingNodeRef.id);
            FundingNode parentNode = fundingNodes.get(0);
            FundingNode childNode = fundingNodes.get(1);
            fundingNodeMap.put(parentNode.id, parentNode);
            fundingNodeMap.put(childNode.id, childNode);

            for (FinanceItem item : requestGroup.items) {
                String finsysName = childNode.financialSystemRef.name;
                List<String> actions = decisionManager.getFinanceDecisions(eventType, eventSubType, finsysName, item);
                List<IFinanceProcessor> financeProcessors = getFinanceProcessors(actions);

                // apply finances
                applyFinances(financeProcessors, fundingNodes, item);

                FundingNodeDO fundingNodeDO = mapper.getObject(FundingNodeDO.class, parentNode);
                fundingNodeDao.update(fundingNodeDO);
                // get output decisions
                ResponseItem fItem = new ResponseItem();
                fItem.item = item;
                responseGroup.responseItems.add(fItem);
            }
            ProcessingBalance parentProcessingBalance = processingBalanceFactory.getProcessingBalance(parentNode, fundType);
            responseGroup.endingBalances.add(parentProcessingBalance);
            ProcessingBalance childProcessingBalance = processingBalanceFactory.getProcessingBalance(childNode, fundType);
            responseGroup.endingBalances.add(childProcessingBalance);
            retVal.responseGroups.add(responseGroup);
        }

        return retVal;
    }

    List<ProcessingBalance> getProcessingBalances(Map<String, FundingNode> fundingNodeMap) {
        List<ProcessingBalance> list = new ArrayList<>();

        for (FundingNode node : fundingNodeMap.values()) {
            ProcessingBalance bal = new ProcessingBalance();
            bal.fundingNodeRef = node.getRef();
            bal.balances = node.balances;
            list.add(bal);
        }
        return list;
    }

    void applyFinances(List<IFinanceProcessor> financeProcessors, List<FundingNode> fundingNodes, FinanceItem item) {

        for (IFinanceProcessor processor: financeProcessors) {
            processor.process(fundingNodes, item);
        }
    }

    List<IFinanceProcessor> getFinanceProcessors(List<String> actions) {

        List<IFinanceProcessor> processors = new ArrayList<>();
        for (String action: actions) {
            IFinanceProcessor processor = cdiUtil.getNamedClass(action, IFinanceProcessor.class);
            processors.add(processor);
        }

        return processors;
    }

    public List<FundingNodeRef> checkForNegativeFundsNotification(List<ResponseGroup> responseGroups) {
        List<FundingNodeRef> negativeBalanceNodeRefs = new ArrayList<>();
        for (ResponseGroup group : responseGroups) {
            for (ProcessingBalance processingBalance : group.endingBalances) {
                Balances balances = processingBalance.balances;
                FundingNodeRef fundingNodeRef = group.fundingNodeRef;

                if (balances.total > fundingNodeRef.target) {
                    negativeBalanceNodeRefs.add(fundingNodeRef);
                }
            }
        }
        return negativeBalanceNodeRefs;
    }
}