package logicole.servers.finance.dao;

import logicole.servers.finance.datamodel.MainAccountTypeDO;

import javax.enterprise.context.Dependent;

@Dependent
public class MainAccountTypeCodeDao extends BaseFinanceDao<MainAccountTypeDO, String> {

    public MainAccountTypeCodeDao() {
        super(MainAccountTypeDO.class);
    }

}
