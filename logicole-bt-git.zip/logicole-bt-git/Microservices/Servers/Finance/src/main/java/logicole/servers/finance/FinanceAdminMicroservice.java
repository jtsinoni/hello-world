package logicole.servers.finance;

import logicole.apis.finance.IFinanceAdminMicroserviceApi;
import logicole.common.datamodels.HealthCheckResult;
import logicole.common.datamodels.VersionInformation;
import logicole.common.datamodels.finance.FinancialSystem;
import logicole.common.datamodels.finance.SalesCodeType;
import logicole.common.datamodels.finance.*;
import logicole.common.datamodels.finance.fundingsource.FundingSource;
import logicole.common.datamodels.organization.OrgRef;
import logicole.common.servers.servers.Microservice;
import logicole.servers.finance.business.FinanceAdminManager;

import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.QueryParam;

@ApplicationScoped
public class FinanceAdminMicroservice extends Microservice implements IFinanceAdminMicroserviceApi {

    public FinanceAdminMicroservice() {
        super("FinanceAdmin");
    }

    @Inject
    private FinanceAdminManager financeAdminManager;

    @Override
    public List<FinancialSystem> getFinancialSystems() {
        return financeAdminManager.getFinancialSystems();
    }

    @Override
    public List<FundingSourceFieldConfig> getFinancialSystemFieldConfigListByType(String financialSystem, String fieldType) {
        return financeAdminManager.getFinancialSystemFieldConfigListByType(financialSystem, fieldType);
    }

    @Override
    public List<FundingSourceFieldConfig> getFinancialSystemFieldConfigList(String financialSystem) {
        return financeAdminManager.getFinancialSystemFieldConfigList(financialSystem);
    }

    @Override
    public HealthCheckResult checkHealth() {
        return null;
    }

    @Override
    public VersionInformation getVersionInformation() {
        return null;
    }

    @Override
    public  List<SalesCodeType> getSalesCodeTypes() { return financeAdminManager.getSalesCodeTypes();}

    @Override
    public List<SubAllocationHolder> getSubAllocationHolders() {
        return financeAdminManager.getSubAllocationHolders();
    }

    @Override
    public List<FundCode> getFundCodes() {
        return financeAdminManager.getFundCodes();
    }

    @Override
    public List<ForeignCurrency> getForeignCurrencies() {
        return financeAdminManager.getForeignCurrencies();
    }

    @Override
    public List<MainAccount> getMainAccountCodes() {
        return financeAdminManager.getMainAccountCodes();
    }

    @Override
    public List<CommodityCode> getCommodityCodes() {
        return financeAdminManager.getCommodityCodes();
    }

    @Override
    public List<FundUsageType> getFundUsageTypes() {
        return financeAdminManager.getFundUsageTypes();
    }

    @Override
    public List<SubClass> getSubClasses() {
        return financeAdminManager.getSubClasses();
    }

    @Override
    public List<MainAccountType> getMainAccountTypeCodes() {
        return financeAdminManager.getMainAccountTypeCodes();
    }

    @Override
    public FundingSource createFundingSource(FundingSource fundingSource) {
        return financeAdminManager.createFundingSource(fundingSource);
    }

    @Override
    public FundingSource getFundingSourceById(String id) {
        return financeAdminManager.getFundingSourceById(id);

    }

    @Override
    public List<FundingSource> getAllFundingSources() {
        return financeAdminManager.getAllFundingSource();
    }

    @Override
    public List<FundingNode> getFundingNodesByFundingSource(String id) {
        return financeAdminManager.getFundingNodesWithFundingSourceId(id);
    }

    @Override
    public FundingNode updateFundingNode(FundingNode node) {
        return financeAdminManager.updateFundingNode(node);
    }

    @Override
    public FundingNode updateExpenseCenter(String id, FundingNode node) {
        return financeAdminManager.updateExpenseCenter(id, node);
    }

    @Override
    public FundingNode addBuyerToFund(String id, FundingNode node) {
        return financeAdminManager.addBuyerToFund(id, node);
    }

    @Override
    public List<ProcessingBalance> getFundingNodesByBuyer(String id) {
        return financeAdminManager.getFundingNodesByBuyer(id);
    }
    @Override
    public FundingNode removeBuyerFromFund(String fundParentId, String buyerId) {
        return financeAdminManager.removeBuyerFromFund(fundParentId, buyerId);
    }

    @Override
    public List<FundingNode> getAllFundingNodes() { return financeAdminManager.getAllFundingNodes(); }

    @Override
    public List<RefDataList>  getRefDataList(String module) {
        return financeAdminManager.getRefDataList(module);

    }

    @Override
    public FundingNode updateBuyer(@QueryParam("id") String id, OrgRef buyer) {

        return financeAdminManager.updateBuyer(id, buyer);
    }

}
