package logicole.servers.finance.dao;

import logicole.common.datamodels.finance.FundingNode;
import logicole.common.datamodels.ref.Refs;
import logicole.common.servers.persistence.Query;
import logicole.servers.finance.datamodel.FundingNodeDO;

import java.util.List;
import javax.enterprise.context.Dependent;

@Dependent
public class FundingNodeDao extends BaseFinanceDao<FundingNodeDO, String> {

    public FundingNodeDao() {
        super(FundingNodeDO.class, Refs.References.FUNDING_NODE);
    }

    public FundingNodeDO getFundingNodes(String id) {

        Query<FundingNodeDO> query = getQuery();
        query.or(
                query.and(query.criteria("children.id").exists(),
                        query.criteria("children.id").equal(id)),
                query.and(query.criteria("children.children.id").exists(),
                        query.criteria("children.children.id").equal(id)),
                query.and(query.criteria("children.children.children.id").exists(),
                        query.criteria("children.children.children.id").equal(id))
        );

        List<FundingNodeDO> fddos = query.asList();

        FundingNodeDO retVal = null;
        if (fddos != null && fddos.size() > 0) {
            retVal = fddos.get(0);
        }
        return retVal;
    }

    public List<? extends FundingNode> getFundingNodesWithFundingSourceId(String id) {

        Query<FundingNodeDO> query = getQuery();
        query.field("fundingSourceRefs.id").equal(id);

        List<FundingNodeDO> fddos = query.asList();

        return fddos;
    }

}
