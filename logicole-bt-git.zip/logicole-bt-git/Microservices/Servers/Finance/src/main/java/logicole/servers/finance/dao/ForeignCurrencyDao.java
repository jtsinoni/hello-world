package logicole.servers.finance.dao;

import logicole.servers.finance.datamodel.ForeignCurrencyDO;

import javax.enterprise.context.Dependent;

@Dependent
public class ForeignCurrencyDao extends BaseFinanceDao<ForeignCurrencyDO, String> {

    public ForeignCurrencyDao() {
        super(ForeignCurrencyDO.class);
    }

}
