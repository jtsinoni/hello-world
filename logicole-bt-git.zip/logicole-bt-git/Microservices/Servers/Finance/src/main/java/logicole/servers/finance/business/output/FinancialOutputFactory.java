package logicole.servers.finance.business.output;

import logicole.common.datamodels.finance.FinanceItem;
import logicole.common.datamodels.finance.output.*;
import logicole.common.datamodels.finance.request.RequestGroup;

import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class FinancialOutputFactory {

    public Obligation buildObligation(RequestGroup requestGroup, FinanceItem item, boolean isDebit, boolean isUpdate) {
        Obligation ob = new Obligation();
        ob.buyerRef = requestGroup.buyerRef;
        ob.externalCoordinationId = item.documentNumber;
        ob.fundingSourceRef = requestGroup.fundingNodeRef.fundingSourceRefs.get(0);
        ob.isDebit = isDebit;
        ob.isUpdate = isUpdate;
        ob.offer = item.offer;
        ob.orderRef = requestGroup.orderRef;
        ob.quantity = item.quantity;

        return ob;
    }

    public Commitment buildCommitment(RequestGroup requestGroup, FinanceItem item, boolean isDebit, boolean isUpdate) {
        Commitment commitment = new Commitment();
        commitment.buyerRef = requestGroup.buyerRef;
        commitment.externalCoordinationId = item.documentNumber;
        commitment.fundingSourceRef = requestGroup.fundingNodeRef.fundingSourceRefs.get(0);
        commitment.isDebit = isDebit;
        commitment.isUpdate = isUpdate;
        commitment.offer = item.offer;
        commitment.orderRef = requestGroup.orderRef;
        commitment.quantity = item.quantity;

        return commitment;
    }

    public Credit buildCredit(RequestGroup requestGroup, FinanceItem item, boolean isDebit, boolean isUpdate) {
        Credit credit = new Credit();
        credit.buyerRef = requestGroup.buyerRef;
        credit.externalCoordinationId = item.documentNumber;
        credit.fundingSourceRef = requestGroup.fundingNodeRef.fundingSourceRefs.get(0);
        credit.isDebit = isDebit;
        credit.isUpdate = isUpdate;
        credit.offer = item.offer;
        credit.orderRef = requestGroup.orderRef;
        credit.quantity = item.quantity;

        return credit;
    }

    public NSale buildNSale(RequestGroup requestGroup, FinanceItem item, boolean isDebit, boolean isUpdate) {
        NSale nSale = new NSale();
        nSale.buyerRef = requestGroup.buyerRef;
        nSale.externalCoordinationId = item.documentNumber;
        nSale.fundingSourceRef = requestGroup.fundingNodeRef.fundingSourceRefs.get(0);
        nSale.isDebit = isDebit;
        nSale.isUpdate = isUpdate;
        nSale.offer = item.offer;
        nSale.orderRef = requestGroup.orderRef;
        nSale.quantity = item.quantity;

        return nSale;
    }

    public RSale buildRSale(RequestGroup requestGroup, FinanceItem item, boolean isDebit, boolean isUpdate) {
        RSale rSale = new RSale();
        rSale.buyerRef = requestGroup.buyerRef;
        rSale.externalCoordinationId = item.documentNumber;
        rSale.fundingSourceRef = requestGroup.fundingNodeRef.fundingSourceRefs.get(0);
        rSale.isDebit = isDebit;
        rSale.isUpdate = isUpdate;
        rSale.offer = item.offer;
        rSale.orderRef = requestGroup.orderRef;
        rSale.quantity = item.quantity;

        return rSale;
    }

    public Expense buildExpense(RequestGroup requestGroup, FinanceItem item, boolean isDebit, boolean isUpdate) {
        Expense expense = new Expense();
        expense.buyerRef = requestGroup.buyerRef;
        expense.externalCoordinationId = item.documentNumber;
        expense.fundingSourceRef = requestGroup.fundingNodeRef.fundingSourceRefs.get(0);
        expense.isDebit = isDebit;
        expense.isUpdate = isUpdate;
        expense.offer = item.offer;
        expense.orderRef = requestGroup.orderRef;
        expense.quantity = item.quantity;

        return expense;
    }

    public Surcharge buildSurcharge(RequestGroup requestGroup, FinanceItem item, boolean isDebit, boolean isUpdate) {
        Surcharge surcharge = new Surcharge();
        surcharge.buyerRef = requestGroup.buyerRef;
        surcharge.externalCoordinationId = item.documentNumber;
        surcharge.fundingSourceRef = requestGroup.fundingNodeRef.fundingSourceRefs.get(0);
        surcharge.isDebit = isDebit;
        surcharge.isUpdate = isUpdate;
        surcharge.offer = item.offer;
        surcharge.orderRef = requestGroup.orderRef;
        surcharge.quantity = item.quantity;

        return surcharge;
    }
}
