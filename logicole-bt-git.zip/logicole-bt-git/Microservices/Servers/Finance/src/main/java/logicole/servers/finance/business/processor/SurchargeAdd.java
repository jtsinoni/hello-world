package logicole.servers.finance.business.processor;

import logicole.common.datamodels.finance.FinanceItem;
import logicole.common.datamodels.finance.FundingNode;
import logicole.common.datamodels.finance.output.Surcharge;
import logicole.common.datamodels.finance.request.RequestGroup;
import logicole.common.general.logging.Logger;
import logicole.servers.finance.business.output.FinancialOutputFactory;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.inject.Named;

@ApplicationScoped
@Named("surchargeAdd")
public class SurchargeAdd extends BaseFinanceProcessor implements IFinanceProcessor {

    @Inject
    private Logger logger;
    @Inject
    private FinancialOutputFactory outputFactory;

    @Override
    protected void applyValues(FundingNode node, FinanceItem item) {

        logger.info("SurchargeAdd - going to apply the data");
        Double itemTotal = item.offer.price * item.quantity;
        checkInit(node);

        Double currentVal = getCurrentValue(node.balances.surcharges);
        node.balances.surcharges = currentVal + itemTotal;

        Double totalVal = getCurrentValue(node.balances.total);
        node.balances.total = totalVal + itemTotal;

    }

    @Override
    public Object generateOutput(RequestGroup requestGroup, FinanceItem item) {
        Surcharge surcharge = outputFactory.buildSurcharge(requestGroup, item, true, false);
        return surcharge;
    }
}
