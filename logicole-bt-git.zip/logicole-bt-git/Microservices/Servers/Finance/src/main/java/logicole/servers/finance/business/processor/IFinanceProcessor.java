package logicole.servers.finance.business.processor;

import logicole.common.datamodels.finance.FinanceItem;
import logicole.common.datamodels.finance.FundingNode;
import logicole.common.datamodels.finance.request.RequestGroup;

import java.util.List;

public interface IFinanceProcessor {

    void process(List<FundingNode> fundingNodes, FinanceItem item);

    Object generateOutput(RequestGroup requestGroup, FinanceItem item);
}
