package logicole.servers.finance.dao;

import logicole.servers.finance.datamodel.CommodityCodeDO;

import javax.enterprise.context.Dependent;

@Dependent
public class CommodityCodeDao extends BaseFinanceDao<CommodityCodeDO, String> {

    public CommodityCodeDao() {
        super(CommodityCodeDO.class);
    }

}
