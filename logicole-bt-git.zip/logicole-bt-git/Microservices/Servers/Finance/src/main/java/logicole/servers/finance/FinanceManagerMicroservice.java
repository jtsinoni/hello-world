package logicole.servers.finance;

import logicole.apis.finance.IFinanceManagerMicroserviceApi;
import logicole.common.datamodels.HealthCheckResult;
import logicole.common.datamodels.VersionInformation;
import logicole.common.datamodels.finance.FinanceDecision;
import logicole.common.datamodels.finance.FundingNodeRef;
import logicole.common.datamodels.finance.request.CommonFinanceRequest;
import logicole.common.datamodels.finance.response.CommonFinanceResponse;
import logicole.common.datamodels.finance.response.ResponseGroup;
import logicole.common.servers.servers.Microservice;
import logicole.servers.finance.business.FinanceManager;

import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

@ApplicationScoped
public class FinanceManagerMicroservice extends Microservice implements IFinanceManagerMicroserviceApi {

    public FinanceManagerMicroservice() {
        super("FinanceManager");
    }

    @Inject
    private FinanceManager financeManager;

    @Override
    public List<FinanceDecision> getFinanceDecisionss() {
        return financeManager.getFinanceDecisions();
    }

    @Override
    public CommonFinanceResponse processBusinessEvent(CommonFinanceRequest commonFinanceRequest) {
        return financeManager.processBusinessEvent(commonFinanceRequest);
    }

    @Override
    public List<FundingNodeRef> checkForNegativeFundsNotification(List<ResponseGroup> responseGroups) {
        return financeManager.checkForNegativeFundsNotification(responseGroups);
    }

    @Override
    public HealthCheckResult checkHealth() {
        return null;
    }

    @Override
    public VersionInformation getVersionInformation() {
        return null;
    }
}
