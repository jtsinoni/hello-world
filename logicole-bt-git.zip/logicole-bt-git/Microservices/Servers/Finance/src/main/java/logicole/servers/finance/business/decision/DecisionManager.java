package logicole.servers.finance.business.decision;

import logicole.common.datamodels.finance.FinanceDecisionCriteria;
import logicole.common.datamodels.finance.FinanceItem;
import logicole.common.datamodels.general.*;
import logicole.common.general.logging.Logger;
import logicole.common.general.util.HashUtil;
import logicole.common.general.util.JSONUtil;
import logicole.servers.finance.dao.FinanceDecisionDao;
import logicole.servers.finance.datamodel.FinanceDecisionDO;

import java.util.ArrayList;
import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

@ApplicationScoped
public class DecisionManager {

    @Inject
    private HashUtil hashUtil;
    @Inject
    private FinanceDecisionDao financeDecisionDao;
    @Inject
    private JSONUtil jsonUtil;
    @Inject
    private Logger logger;

    public List<String> getFinanceDecisions(EventType eventType, EventSubType eventSubType, String accountingSystemName, FinanceItem item) {

        FinanceDecisionCriteria fdc = new FinanceDecisionCriteria();
        fdc.eventType = eventType;
        fdc.accountingSystem = accountingSystemName;
        fdc.eventSubType = eventSubType;
        String hash =  hashUtil.getMD5(fdc);
        FinanceDecisionDO financeDecision = financeDecisionDao.findByHashValue(hash);

        List<String> retVal;
        if (financeDecision != null && financeDecision.actions != null) {
            retVal = financeDecision.actions;
        } else {
            retVal = new ArrayList<>();
        }
        return retVal;
    }

}
