package logicole.servers.finance.business;

import logicole.common.datamodels.finance.FundingNode;
import logicole.common.datamodels.finance.ProcessingBalance;
import logicole.common.datamodels.finance.response.Balances;
import logicole.common.datamodels.general.FundType;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class ProcessingBalanceFactory {
    public ProcessingBalance getProcessingBalance(FundingNode node, FundType fundType) {
        ProcessingBalance balance = new ProcessingBalance();
        balance.fundingNodeRef = node.getRef();
        balance.balances = node.balances;
        balance.availableBalance = calculateAvailableBalance(node.target, node.balances, fundType);
        long days = getDaysSinceFyStart(9);
        balance.consumptionRate = calculateConsumptionRate(days, balance.fundingNodeRef.target, balance.availableBalance);
        balance.exhaustionDate = calculateExhaustionDate(balance.availableBalance, balance.consumptionRate);
        return balance;

    }

    Date calculateExhaustionDate(Double availableBalance, Double consumptionRate) {
        Date exhaustionDate = null;
        if (consumptionRate > 0) {
            Double days = availableBalance / consumptionRate;
            Long longDays = days.longValue();
            LocalDate projectedExhaustion = LocalDate.now().plusDays(longDays);
            exhaustionDate = java.sql.Date.valueOf(projectedExhaustion);
        }
        return exhaustionDate;
    }

    long getDaysSinceFyStart(int fyStartMonth) {
        LocalDate today = LocalDate.now();
        LocalDate fyStart;

        if (today.getMonth().getValue() >= fyStartMonth) {
            fyStart = LocalDate.of(today.getYear(), fyStartMonth, 1);
        } else {
            fyStart = LocalDate.of(today.getYear() - 1, 9, 1);
        }
        // the plus 1 is so the current day is counted in the calculation
        long days = ChronoUnit.DAYS.between(fyStart, today) + 1;
        return days;
    }

    Double calculateConsumptionRate(long daysSinceFYStart, Double target, Double availableBalance) {
        Double consumptionRate = 0d;
        Double amountSpent = (target - availableBalance);
        if (amountSpent > 0) {
            consumptionRate = amountSpent / daysSinceFYStart;
        }
        return consumptionRate;
    }

    Double calculateAvailableBalance(Double target, Balances balances, FundType fundType) {
        Double availableBalance;
        if (FundType.STOCK.equals(fundType)) {
            availableBalance = target - (balances.obligations + balances.commitments);
        } else {
            availableBalance = target
                    + (balances.credits + balances.rSales)
                    - (balances.obligations + balances.commitments + balances.surcharges);
        }
        return availableBalance;
    }


}
