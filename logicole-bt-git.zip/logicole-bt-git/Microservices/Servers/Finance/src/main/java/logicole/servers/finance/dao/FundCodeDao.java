package logicole.servers.finance.dao;

import logicole.servers.finance.datamodel.FundCodeDO;

import javax.enterprise.context.Dependent;

@Dependent
public class FundCodeDao extends BaseFinanceDao<FundCodeDO, String> {

    public FundCodeDao() {
        super(FundCodeDO.class);
    }

}
