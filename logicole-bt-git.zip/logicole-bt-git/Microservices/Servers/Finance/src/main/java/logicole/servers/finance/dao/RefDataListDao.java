package logicole.servers.finance.dao;

        import logicole.common.datamodels.finance.RefDataList;
        import logicole.common.servers.persistence.Query;
        import logicole.servers.finance.datamodel.RefDataListDO;
        import javax.enterprise.context.Dependent;
        import java.util.List;

@Dependent
public class RefDataListDao extends BaseFinanceDao<RefDataListDO, String> {

    public RefDataListDao() {
        super(RefDataListDO.class);
    }

    public List<? extends RefDataList> getRefDatListByCollectionName(String module) {
        Query<RefDataListDO> query = getQuery();
        query.field("module").equal(module);

        List<RefDataListDO> refDataList = query.asList();

        return refDataList;
    }

}
