package logicole.servers.finance.datamodel;

import logicole.common.datamodels.finance.RefDataList;
import logicole.common.servers.persistence.PersistedEntity;
import logicole.common.servers.persistence.PersistedEntityListener;
import org.bson.types.ObjectId;
import org.mongodb.morphia.annotations.Entity;
import org.mongodb.morphia.annotations.EntityListeners;
import org.mongodb.morphia.annotations.Id;

@Entity(value = "RefDataList", noClassnameStored = true)
@EntityListeners(PersistedEntityListener.class)
public class RefDataListDO extends RefDataList implements PersistedEntity {
    @Id
    private ObjectId _id;
    private Boolean _isDeleted = Boolean.FALSE;
    private int refHash;

    @Override
    public String getId() {
        if (id == null && _id != null) {
            id = _id.toString();
        }
        return id;
    }

    @Override
    public void setId(String id) {
        this._id = getIdFromString(id);
        this.id = id;
    }

    @Override
    public void setObjectId(ObjectId id) {
        this._id = id;
        this.id = id.toString();
    }

    @Override
    public Boolean get_isDeleted() {
        return _isDeleted;
    }

    @Override
    public void set_isDeleted(Boolean _isDeleted) {
        this._isDeleted = _isDeleted;
    }

    @Override
    public int getRefHash() {
        return refHash;
    }

    @Override
    public void setRefHash(int refHash) {
        this.refHash = refHash;
    }
}
