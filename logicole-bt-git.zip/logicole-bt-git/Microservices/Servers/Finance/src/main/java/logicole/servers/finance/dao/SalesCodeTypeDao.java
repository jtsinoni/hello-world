package logicole.servers.finance.dao;


import logicole.servers.finance.datamodel.SalesCodeTypeDO;

import javax.enterprise.context.Dependent;

@Dependent
public class SalesCodeTypeDao extends BaseFinanceDao<SalesCodeTypeDO, String>  {

    public SalesCodeTypeDao() {
        super(SalesCodeTypeDO.class);
    }
}
