package logicole.servers.finance.dao;

import logicole.servers.finance.datamodel.MainAccountDO;

import javax.enterprise.context.Dependent;

@Dependent
public class MainAccountCodeDao extends BaseFinanceDao<MainAccountDO, String> {

    public MainAccountCodeDao() {
        super(MainAccountDO.class);
    }

}
