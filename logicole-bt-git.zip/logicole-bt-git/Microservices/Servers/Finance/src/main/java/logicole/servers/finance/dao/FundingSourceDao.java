package logicole.servers.finance.dao;

import logicole.common.datamodels.ref.Refs;
import logicole.servers.finance.datamodel.FundingSourceDO;

import javax.enterprise.context.Dependent;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Dependent
public class FundingSourceDao  extends BaseFinanceDao<FundingSourceDO, String> {

    public FundingSourceDao() {
        super(FundingSourceDO.class, Refs.References.FUNDING_SOURCE);
    }

    public List<FundingSourceDO> getFundingSourceDOByProjectId(String id) {
        Map<String, String> map = new HashMap<>();
        map.put("sloa.projectIdentifier", id);

        return  query(map);

    }


}
