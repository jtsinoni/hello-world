package logicole.servers.finance;

import logicole.common.restserver.JaxRsModuleApplication;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.ApplicationPath;

@ApplicationPath("/")
@ApplicationScoped
public class JaxRsActivator extends JaxRsModuleApplication {

    public JaxRsActivator() {
        super("finance");

        moduleResources.add(FinanceAdminMicroservice.class);
        moduleResources.add(FinanceManagerMicroservice.class);
    }

}
