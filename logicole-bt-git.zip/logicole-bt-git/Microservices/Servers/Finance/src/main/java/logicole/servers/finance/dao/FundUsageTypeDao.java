package logicole.servers.finance.dao;

import logicole.servers.finance.datamodel.FundUsageTypeDO;

import javax.enterprise.context.Dependent;

@Dependent
public class FundUsageTypeDao extends BaseFinanceDao<FundUsageTypeDO, String> {

    public FundUsageTypeDao() {
        super(FundUsageTypeDO.class);
    }

}
