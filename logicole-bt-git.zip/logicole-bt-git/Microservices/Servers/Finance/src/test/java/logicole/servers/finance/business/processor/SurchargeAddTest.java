package logicole.servers.finance.business.processor;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;

import logicole.common.datamodels.finance.FinanceItem;
import logicole.common.datamodels.finance.request.RequestGroup;
import logicole.servers.finance.business.output.FinancialOutputFactory;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class SurchargeAddTest extends ProcessorTestBase {

    @Mock
    private FinancialOutputFactory factory;
    @InjectMocks
    private SurchargeAdd mockProcessor;

    private SurchargeAdd spy;

    @Before
    public void setup() {
        super.setup();
        spy = spy(mockProcessor);
        doNothing().when(spy).checkInit(node);
    }

    @Test
    public void subtractZero() {

        doReturn(0d).when(spy).getCurrentValue(0d);
        item.offer.price = 5d;
        item.quantity = 4;
        Double expected = 20d;

        spy.applyValues(node, item);

        verify(spy, times(2)).getCurrentValue(0d);
        verify(spy).checkInit(node);
        assertEquals(expected, node.balances.surcharges);
        assertEquals(expected, node.balances.total);
    }

    @Test
    public void subtractPos() {

        doReturn(25d).when(spy).getCurrentValue(25d);
        node.balances.surcharges = 25d;
        node.balances.total = 25d;
        item.offer.price = 5d;
        item.quantity = 4;
        Double expected = 45d;

        spy.applyValues(node, item);

        verify(spy, times(2)).getCurrentValue(25d);
        verify(spy).checkInit(node);
        assertEquals(expected, node.balances.surcharges);
        assertEquals(expected, node.balances.total);
    }

    @Test
    public void generateOutputTest() {
        RequestGroup requestGroup = new RequestGroup();
        FinanceItem item = new FinanceItem();

        mockProcessor.generateOutput(requestGroup, item);

        verify(factory).buildSurcharge(requestGroup, item, true, false);

    }
}
