package logicole.servers.finance.business.output;

import logicole.common.datamodels.finance.*;
import logicole.common.datamodels.finance.output.*;
import logicole.common.datamodels.finance.request.RequestGroup;
import logicole.common.datamodels.order.buyer.BuyerRef;
import logicole.common.datamodels.order.order.OrderRef;
import logicole.common.datamodels.product.Offer;
import logicole.servers.finance.business.processor.ProcessorTestBase;
import org.junit.*;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

@RunWith(MockitoJUnitRunner.class)
public class FinanceOutputFactoryTest extends ProcessorTestBase {

    @InjectMocks
    private FinancialOutputFactory factory;

    @Before
    public void setup() {
        super.setup();
    }

    @Test
    public void buildObligationTest() {
        RequestGroup requestGroup = new RequestGroup();
        BuyerRef buyerRef = new BuyerRef();
        requestGroup.buyerRef = buyerRef;

        FundingNodeRef fundingNodeRef = new FundingNodeRef();
        requestGroup.fundingNodeRef = fundingNodeRef;
        List<FundingSourceRef> fundingSourceRefs = new ArrayList<>();
        fundingNodeRef.fundingSourceRefs = fundingSourceRefs;
        FundingSourceRef fundingSourceRef = new FundingSourceRef();
        fundingSourceRefs.add(fundingSourceRef);

        OrderRef orderRef = new OrderRef();
        requestGroup.orderRef = orderRef;

        FinanceItem item = new FinanceItem();
        String documentNumber = "externalCoordinationId";
        item.documentNumber = documentNumber;
        Offer offer = new Offer();
        item.offer = offer;
        Integer quantity = 5;
        item.quantity = quantity;

        boolean isDebit = true;
        boolean isUpdate = false;


        Obligation ob = factory.buildObligation(requestGroup, item, isDebit, isUpdate);

        Assert.assertEquals(buyerRef, ob.buyerRef);
        Assert.assertEquals(documentNumber, ob.externalCoordinationId);
        Assert.assertEquals(fundingSourceRef, ob.fundingSourceRef);
        Assert.assertEquals(isDebit, ob.isDebit);
        Assert.assertEquals(isUpdate, ob.isUpdate);
        Assert.assertEquals(offer, ob.offer);
        Assert.assertEquals(quantity, ob.quantity);
        Assert.assertEquals(orderRef, ob.orderRef);
    }

    @Test
    public void buildCommitmentTest() {
        RequestGroup requestGroup = new RequestGroup();
        BuyerRef buyerRef = new BuyerRef();
        requestGroup.buyerRef = buyerRef;

        FundingNodeRef fundingNodeRef = new FundingNodeRef();
        requestGroup.fundingNodeRef = fundingNodeRef;
        List<FundingSourceRef> fundingSourceRefs = new ArrayList<>();
        fundingNodeRef.fundingSourceRefs = fundingSourceRefs;
        FundingSourceRef fundingSourceRef = new FundingSourceRef();
        fundingSourceRefs.add(fundingSourceRef);

        OrderRef orderRef = new OrderRef();
        requestGroup.orderRef = orderRef;

        FinanceItem item = new FinanceItem();
        String documentNumber = "externalCoordinationId";
        item.documentNumber = documentNumber;
        Offer offer = new Offer();
        item.offer = offer;
        Integer quantity = 5;
        item.quantity = quantity;

        boolean isDebit = true;
        boolean isUpdate = false;


        Commitment comm = factory.buildCommitment(requestGroup, item, isDebit, isUpdate);

        Assert.assertEquals(buyerRef, comm.buyerRef);
        Assert.assertEquals(documentNumber, comm.externalCoordinationId);
        Assert.assertEquals(fundingSourceRef, comm.fundingSourceRef);
        Assert.assertEquals(isDebit, comm.isDebit);
        Assert.assertEquals(isUpdate, comm.isUpdate);
        Assert.assertEquals(offer, comm.offer);
        Assert.assertEquals(quantity, comm.quantity);
        Assert.assertEquals(orderRef, comm.orderRef);
    }

    @Test
    public void buildCreditTest() {
        RequestGroup requestGroup = new RequestGroup();
        BuyerRef buyerRef = new BuyerRef();
        requestGroup.buyerRef = buyerRef;

        FundingNodeRef fundingNodeRef = new FundingNodeRef();
        requestGroup.fundingNodeRef = fundingNodeRef;
        List<FundingSourceRef> fundingSourceRefs = new ArrayList<>();
        fundingNodeRef.fundingSourceRefs = fundingSourceRefs;
        FundingSourceRef fundingSourceRef = new FundingSourceRef();
        fundingSourceRefs.add(fundingSourceRef);

        OrderRef orderRef = new OrderRef();
        requestGroup.orderRef = orderRef;

        FinanceItem item = new FinanceItem();
        String documentNumber = "externalCoordinationId";
        item.documentNumber = documentNumber;
        Offer offer = new Offer();
        item.offer = offer;
        Integer quantity = 5;
        item.quantity = quantity;

        boolean isDebit = true;
        boolean isUpdate = false;


        Credit credit = factory.buildCredit(requestGroup, item, isDebit, isUpdate);

        Assert.assertEquals(buyerRef, credit.buyerRef);
        Assert.assertEquals(documentNumber, credit.externalCoordinationId);
        Assert.assertEquals(fundingSourceRef, credit.fundingSourceRef);
        Assert.assertEquals(isDebit, credit.isDebit);
        Assert.assertEquals(isUpdate, credit.isUpdate);
        Assert.assertEquals(offer, credit.offer);
        Assert.assertEquals(quantity, credit.quantity);
        Assert.assertEquals(orderRef, credit.orderRef);
    }

    @Test
    public void buildNSaleTest() {
        RequestGroup requestGroup = new RequestGroup();
        BuyerRef buyerRef = new BuyerRef();
        requestGroup.buyerRef = buyerRef;

        FundingNodeRef fundingNodeRef = new FundingNodeRef();
        requestGroup.fundingNodeRef = fundingNodeRef;
        List<FundingSourceRef> fundingSourceRefs = new ArrayList<>();
        fundingNodeRef.fundingSourceRefs = fundingSourceRefs;
        FundingSourceRef fundingSourceRef = new FundingSourceRef();
        fundingSourceRefs.add(fundingSourceRef);

        OrderRef orderRef = new OrderRef();
        requestGroup.orderRef = orderRef;

        FinanceItem item = new FinanceItem();
        String documentNumber = "externalCoordinationId";
        item.documentNumber = documentNumber;
        Offer offer = new Offer();
        item.offer = offer;
        Integer quantity = 5;
        item.quantity = quantity;

        boolean isDebit = true;
        boolean isUpdate = false;


        NSale nSale = factory.buildNSale(requestGroup, item, isDebit, isUpdate);

        Assert.assertEquals(buyerRef, nSale.buyerRef);
        Assert.assertEquals(documentNumber, nSale.externalCoordinationId);
        Assert.assertEquals(fundingSourceRef, nSale.fundingSourceRef);
        Assert.assertEquals(isDebit, nSale.isDebit);
        Assert.assertEquals(isUpdate, nSale.isUpdate);
        Assert.assertEquals(offer, nSale.offer);
        Assert.assertEquals(quantity, nSale.quantity);
        Assert.assertEquals(orderRef, nSale.orderRef);
    }

    @Test
    public void buildRSaleTest() {
        RequestGroup requestGroup = new RequestGroup();
        BuyerRef buyerRef = new BuyerRef();
        requestGroup.buyerRef = buyerRef;

        FundingNodeRef fundingNodeRef = new FundingNodeRef();
        requestGroup.fundingNodeRef = fundingNodeRef;
        List<FundingSourceRef> fundingSourceRefs = new ArrayList<>();
        fundingNodeRef.fundingSourceRefs = fundingSourceRefs;
        FundingSourceRef fundingSourceRef = new FundingSourceRef();
        fundingSourceRefs.add(fundingSourceRef);

        OrderRef orderRef = new OrderRef();
        requestGroup.orderRef = orderRef;

        FinanceItem item = new FinanceItem();
        String documentNumber = "externalCoordinationId";
        item.documentNumber = documentNumber;
        Offer offer = new Offer();
        item.offer = offer;
        Integer quantity = 5;
        item.quantity = quantity;

        boolean isDebit = true;
        boolean isUpdate = false;


        RSale rSale = factory.buildRSale(requestGroup, item, isDebit, isUpdate);

        Assert.assertEquals(buyerRef, rSale.buyerRef);
        Assert.assertEquals(documentNumber, rSale.externalCoordinationId);
        Assert.assertEquals(fundingSourceRef, rSale.fundingSourceRef);
        Assert.assertEquals(isDebit, rSale.isDebit);
        Assert.assertEquals(isUpdate, rSale.isUpdate);
        Assert.assertEquals(offer, rSale.offer);
        Assert.assertEquals(quantity, rSale.quantity);
        Assert.assertEquals(orderRef, rSale.orderRef);
    }

    @Test
    public void buildExpenseTest() {
        RequestGroup requestGroup = new RequestGroup();
        BuyerRef buyerRef = new BuyerRef();
        requestGroup.buyerRef = buyerRef;

        FundingNodeRef fundingNodeRef = new FundingNodeRef();
        requestGroup.fundingNodeRef = fundingNodeRef;
        List<FundingSourceRef> fundingSourceRefs = new ArrayList<>();
        fundingNodeRef.fundingSourceRefs = fundingSourceRefs;
        FundingSourceRef fundingSourceRef = new FundingSourceRef();
        fundingSourceRefs.add(fundingSourceRef);

        OrderRef orderRef = new OrderRef();
        requestGroup.orderRef = orderRef;

        FinanceItem item = new FinanceItem();
        String documentNumber = "externalCoordinationId";
        item.documentNumber = documentNumber;
        Offer offer = new Offer();
        item.offer = offer;
        Integer quantity = 5;
        item.quantity = quantity;

        boolean isDebit = true;
        boolean isUpdate = false;


        Expense expense = factory.buildExpense(requestGroup, item, isDebit, isUpdate);

        Assert.assertEquals(buyerRef, expense.buyerRef);
        Assert.assertEquals(documentNumber, expense.externalCoordinationId);
        Assert.assertEquals(fundingSourceRef, expense.fundingSourceRef);
        Assert.assertEquals(isDebit, expense.isDebit);
        Assert.assertEquals(isUpdate, expense.isUpdate);
        Assert.assertEquals(offer, expense.offer);
        Assert.assertEquals(quantity, expense.quantity);
        Assert.assertEquals(orderRef, expense.orderRef);
    }

    @Test
    public void buildSurchargeTest() {
        RequestGroup requestGroup = new RequestGroup();
        BuyerRef buyerRef = new BuyerRef();
        requestGroup.buyerRef = buyerRef;

        FundingNodeRef fundingNodeRef = new FundingNodeRef();
        requestGroup.fundingNodeRef = fundingNodeRef;
        List<FundingSourceRef> fundingSourceRefs = new ArrayList<>();
        fundingNodeRef.fundingSourceRefs = fundingSourceRefs;
        FundingSourceRef fundingSourceRef = new FundingSourceRef();
        fundingSourceRefs.add(fundingSourceRef);

        OrderRef orderRef = new OrderRef();
        requestGroup.orderRef = orderRef;

        FinanceItem item = new FinanceItem();
        String documentNumber = "externalCoordinationId";
        item.documentNumber = documentNumber;
        Offer offer = new Offer();
        item.offer = offer;
        Integer quantity = 5;
        item.quantity = quantity;

        boolean isDebit = true;
        boolean isUpdate = false;


        Surcharge surcharge = factory.buildSurcharge(requestGroup, item, isDebit, isUpdate);

        Assert.assertEquals(buyerRef, surcharge.buyerRef);
        Assert.assertEquals(documentNumber, surcharge.externalCoordinationId);
        Assert.assertEquals(fundingSourceRef, surcharge.fundingSourceRef);
        Assert.assertEquals(isDebit, surcharge.isDebit);
        Assert.assertEquals(isUpdate, surcharge.isUpdate);
        Assert.assertEquals(offer, surcharge.offer);
        Assert.assertEquals(quantity, surcharge.quantity);
        Assert.assertEquals(orderRef, surcharge.orderRef);
    }
}
