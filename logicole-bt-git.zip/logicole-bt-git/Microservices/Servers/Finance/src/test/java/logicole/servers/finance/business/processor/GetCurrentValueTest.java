package logicole.servers.finance.business.processor;

import static org.junit.Assert.assertEquals;

import logicole.common.general.logging.Logger;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class GetCurrentValueTest {

    @InjectMocks
    private ObligationAdd obAdd;
    @Mock
    private Logger logger;

    @Test
    public void getCurrentValueNull() {

        Double expected = 0d;

        Double returned = obAdd.getCurrentValue(null);

        assertEquals(expected, returned);
    }

    @Test
    public void getCurrentValue5() {

        Double expected = 5d;

        Double returned = obAdd.getCurrentValue(expected);

        assertEquals(expected, returned);
    }
}
