import logicole.common.datamodels.finance.*;
import logicole.common.datamodels.general.EventSubType;
import logicole.common.datamodels.general.EventType;
import logicole.common.general.util.*;

import java.io.*;
import java.nio.file.*;
import java.util.*;

public class MatrixTest {

    static boolean firstAction = true;
    static String fileDir = "c:/workspace/tempFiles/";
    static String finFile = fileDir + "financeDecision.json";
    static String outputFile = fileDir + "outputDecision.json";
    static Map<String, String> findecMap = new HashMap<>();
    static Map<String, String> outdecMap = new HashMap<>();
    static JSONUtil jsonUtil = new JSONUtil();
    static HashUtil hashUtil = new HashUtil(jsonUtil);
    static Map<Integer, String> outputActionMap = new HashMap<>();

    public static void main(String[] args) throws IOException {

        init();
        InputStream stream = ClassLoader.getSystemResourceAsStream("matrixtestpipe.csv");
        Scanner scanner = new Scanner(stream);

        List<String> financeDecisionRecords = new ArrayList<>();
        List<String> outputDecisionRecords = new ArrayList<>();

        while (scanner.hasNext()) {
            String line = scanner.nextLine();
            String[] parts = line.split("\\|");

            processFinancialDecision(financeDecisionRecords, parts);

        }
        scanner.close();

        writeRecords(financeDecisionRecords, finFile);
        writeRecords(outputDecisionRecords, outputFile);
    }

    private static void init() {
        File file = new File(fileDir);
        file.mkdirs();
        outputActionMap.put(39,"GFEBS-Cost-Realloc");
        outputActionMap.put(40,"GFEBS-Commitment");
        outputActionMap.put(41,"GFEBS-Obligation");
        outputActionMap.put(42,"GFEBS-Depreciation");
        outputActionMap.put(43,"850-PV-Obligation-BSM");
        outputActionMap.put(44,"EDI-527M-Receipt");
        outputActionMap.put(45,"EDI-527E-Receipt");
        outputActionMap.put(46,"EDI-527V-TVR-Receipt");
        outputActionMap.put(47,"EDI-527D-Customer-Receipt-Acknowledgement");
        outputActionMap.put(48,"EDI-810-Purchase-Card");
        outputActionMap.put(49,"EDI-947A-Inventory");
        outputActionMap.put(50,"EDI-846A-Inventory");
        outputActionMap.put(51,"EDI-861N-Receipt-IRAPT");
        outputActionMap.put(52,"EDI-867I-Sales");
        outputActionMap.put(53,"EDI-832-Catalog-BSM-Prime-Vendor-Receipt");
        outputActionMap.put(54,"850-PV Obligaion-SOS");
        outputActionMap.put(55,"EDI-A0A");
        outputActionMap.put(56,"EDI-511R");
        outputActionMap.put(57,"DD-1155");

    }
    private static void processFinancialDecision(List<String> financeDecisionRecords, String[] parts) throws IOException {
        FinanceDecision decision = getFinanceDecisionDocument(parts);
        String docHash = decision.decisionCriteriaHash;
        String document = jsonUtil.serializeIgnoreNull(decision);

        if (!findecMap.containsKey(docHash)) {
            findecMap.put(docHash, null);
            financeDecisionRecords.add(document);
            System.out.println(document);
        } else {
            System.out.println("Duplicate - " + document);
        }
    }

    private static List<String> getOutputActions(String[] parts) {
        List<String> retVal = new ArrayList<>();
        for (Map.Entry<Integer, String> entry : outputActionMap.entrySet()) {
            String part = parts[entry.getKey()].trim();
            if (!StringUtil.isEmptyOrNull(part)) {
                retVal.add(entry.getValue());
            }
        }
        return retVal;
    }

    private static List<String> getValueAsList(String[] parts, Integer position) {
        String valueString = parts[position];
        String[] values = valueString.split(",");
        return Arrays.asList(values);
    }

    private static FinanceDecision getFinanceDecisionDocument(String[] parts) {
        String accountingSystem = getAccountingSystem(parts);
        String eventType = getEventType(parts);
        String eventSubType = getEventSubType(eventType, parts);
        List<String> actions = getFinanceActions(parts);

        FinanceDecision findec = new FinanceDecision();
        FinanceDecisionCriteria crit = new FinanceDecisionCriteria();
        findec.financeDecisionCriteria = crit;
        crit.accountingSystem = accountingSystem;
        crit.eventType = EventType.valueOf(eventType);
        crit.eventSubType = EventSubType.valueOf(eventSubType);
        findec.actions = actions;

        String hash = hashUtil.getMD5(crit);
        findec.decisionCriteriaHash = hash;

        return findec;
    }

    private static void writeRecords(List<String> records, String fileName) throws IOException {
        String outdecString = String.join("\n", records);
        Path path = Paths.get(fileName);
        File file = path.toFile();
        if (file.exists()) {
            file.delete();
        }
        Files.write(path, outdecString.getBytes());
    }


    private static List<String> getFinanceActions(String[] parts) {
        firstAction = true;

        List<String> list = new ArrayList<>();

        if (parts[18].contains("+") || parts[23].contains("+")) {
            list.add("commitmentAdd");
        } else if (parts[18].contains("-") || parts[23].contains("-"))
            list.add("commitmentSubtract");

        if (parts[19].contains("+") || parts[24].contains("+")) {
            list.add("obligationAdd");
        } else if (parts[19].contains("-") || parts[24].contains("-"))
            list.add("obligationSubtract");

        if (parts[20].contains("+") || parts[25].contains("+")) {
            list.add("creditAdd");
        } else if (parts[20].contains("-") || parts[25].contains("-"))
            list.add("creditSubtract");

        if (parts[21].contains("+") || parts[26].contains("+")) {
            list.add("reimbSaleAdd");
        } else if (parts[21].contains("-") || parts[26].contains("-"))
            list.add("reimbSaleSubtract");

        if (parts[22].contains("+") || parts[27].contains("+")) {
            list.add("nonReimbSaleAdd");
        } else if (parts[22].contains("-") || parts[27].contains("-"))
            list.add("nonReimbSaleSubtract");

        if (parts[23].contains("+") || parts[29].contains("+")) {
            list.add("expenseAdd");
        } else if (parts[23].contains("-") || parts[29].contains("-"))
            list.add("expenseSubtract");

        if (parts[24].contains("+") || parts[29].contains("+")) {
            list.add("surchargeAdd");
        } else if (parts[23].contains("-") || parts[29].contains("-"))
            list.add("surchargeSubtract");

        return list;
    }

    private static String getEventSubType(String event, String[] parts) {
        String subType = null;
        if (event.equalsIgnoreCase("ORDER")) {
            if (parts[14].contains("CON")) {
                subType = "PURCHASE_REQUEST";
            } else {
                subType = "PURCHASE_ORDER";
            }
        }
        return subType;
    }

    private static String getEventType(String[] parts) {
        String type = null;
        if (parts[4].contains("Order")) {
            type = "ORDER";
        }
        return type;
    }

    private static String getAccountingSystem(String[] parts) {
        String acctSys = parts[1];
        return acctSys;
    }
}
