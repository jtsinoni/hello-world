package logicole.servers.finance.business.processor;

import logicole.common.datamodels.finance.FinanceItem;
import logicole.common.datamodels.finance.FundingNode;
import logicole.common.datamodels.finance.response.Balances;
import logicole.common.datamodels.product.Offer;
import logicole.common.general.logging.Logger;
import org.mockito.Mock;

public class ProcessorTestBase {
    FinanceItem item;
    FundingNode node;

    @Mock
    Logger logger;

    public void setup() {
        item = new FinanceItem();
        item.offer = new Offer();
        node = new FundingNode();
        node.balances = new Balances();
    }

}
