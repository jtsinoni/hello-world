package logicole.servers.finance.business;


import logicole.common.datamodels.finance.FundingNode;
import logicole.common.datamodels.finance.fundingsource.FundingSource;
import logicole.common.datamodels.finance.fundingsource.SLOA;
import logicole.common.general.exception.FatalProcessingException;
import logicole.common.general.util.ObjectMapper;
import logicole.servers.finance.dao.FundingNodeDao;
import logicole.servers.finance.dao.FundingSourceDao;
import logicole.servers.finance.datamodel.FundingNodeDO;
import logicole.servers.finance.datamodel.FundingSourceDO;
import org.bson.types.ObjectId;
import org.junit.*;
import org.junit.runner.RunWith;
import org.mockito.*;


import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.stubbing.Answer;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.*;


@RunWith(MockitoJUnitRunner.class)
public class FinanceAdminManagerTest {


    private List<FundingSourceDO> projectLst;

    @Spy
    @InjectMocks
    private FinanceAdminManager spy;


    @Mock
    private SLOA sloa;

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private FundingSourceDao fundingSourceDao;

    @Mock
    private FundingSourceDO fundingSourceDO;

    @Mock
    private FundingSource fundingSource;

    @Mock
    private FundingNode fundingNode;

    @Mock
    private FundingNodeDao fundingNodeDao;

    @Mock
    private FundingNodeDO fundingNodeDO;

    @Captor
    ArgumentCaptor<String> stringArgumentCaptor;

    @BeforeClass
    public static void beforeClass()
    {


    }

    @AfterClass
    public static void afterClass() {

    }

    @Before
    public void setup() {

        sloa.projectIdentifier = "1";
        fundingSource.sloa = sloa;

        fundingSourceDO.target = 1000.00;

        fundingSourceDO.id = "1";
        fundingSourceDO.sloa = sloa;
        projectLst = Arrays.asList(fundingSourceDO);

    }

    @After
    public void after() {


    }



    @Test
    public void createFundingSource_ProjectLst_NotNull() {

        when(fundingSourceDao.getFundingSourceDOByProjectId(fundingSource.sloa.projectIdentifier)).thenReturn(projectLst);

        spy.createFundingSource(fundingSource);

        verify(fundingSourceDao).update(fundingSourceDO);
    }



    @Test
    public void createFundingSource_ProjectLst_Null() {


        when(fundingSourceDao.getFundingSourceDOByProjectId(fundingSource.sloa.projectIdentifier)).thenReturn(null);

        when(objectMapper.getObject(FundingSourceDO.class, fundingSource)).thenReturn(fundingSourceDO);

        spy.createFundingSource(fundingSource);

        verify(fundingSourceDao).insert(fundingSourceDO);

    }

    @Test(expected=FatalProcessingException.class)
    public void createFundingSource_ProjectLst_Exception() {


        List<FundingSourceDO> projects = Arrays.asList(new FundingSourceDO(),new FundingSourceDO());

        when(fundingSourceDao.getFundingSourceDOByProjectId(fundingSource.sloa.projectIdentifier)).thenReturn(projects);

        spy.createFundingSource(fundingSource);

    }


    @Test
    public void updateFundingNode_WithNoID() {

        FundingNodeDO node = new FundingNodeDO();

        node.name = null;
        node.id = null;

        when(objectMapper.getObject(FundingNodeDO.class, node)).thenReturn(fundingNodeDO);

        when(fundingNodeDao.insert(fundingNodeDO)).thenReturn(fundingNodeDO);

        spy.updateFundingNode(node);

        verify(fundingNodeDao).insert(fundingNodeDO);
    }





    @Test
    public void getFinancialSystems() {


    }

    @Test
    public void getFundingNodes() {


    }

    @Test
    public void getSubAllocationHolders() {
    }

    @Test
    public void getFundCodes() {
    }

    @Test
    public void getForeignCurrencies() {
    }

    @Test
    public void getMainAccountCodes() {
    }

    @Test
    public void getCommodityCodes() {
    }

    @Test
    public void getFundUsageTypes() {
    }

    @Test
    public void getSalesCodeTypes() {
    }

    @Test
    public void getSubClasses() {
    }

    @Test
    public void getMainAccountTypeCodes() {
    }



    @Test
    public void getFundingSourceById() {
    }

    @Test
    public void getAllFundingSource() {
    }

    @Test
    public void getFundingNodesWithFundingSourceId() {
    }






}