package logicole.servers.finance.business;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import logicole.common.datamodels.finance.response.Balances;
import logicole.common.datamodels.general.FundType;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import java.time.LocalDate;

@RunWith(MockitoJUnitRunner.class)
public class ProcessingBalanceFactoryTest {

    @InjectMocks
    private ProcessingBalanceFactory factory;

    @Test
    public void calculateAvailableBalanceStockTest() {
        Double target = 100d;
        Balances balances = getBalances();

        Double result = factory.calculateAvailableBalance(target, balances, FundType.STOCK);

        assertTrue(91d == result);

    }

    @Test
    public void calculateAvailableBalanceOtherTest() {
        Double target = 100d;
        Balances balances = getBalances();

        Double result = factory.calculateAvailableBalance(target, balances, FundType.CUSTOMER);

        assertTrue(90d == result);

    }

    @Test
    public void calculateConsumptionRate1() {

        long days = 50;
        Double target = 300d;
        Double availableBalance = 200d;

        Double result = factory.calculateConsumptionRate(days, target, availableBalance);

        assertNotNull(result);
        assertEquals(new Double(2), result);
    }

    @Test
    public void calculateConsumptionRate2() {

        long days = 0;
        Double target = 300d;
        Double availableBalance = 300d;

        Double result = factory.calculateConsumptionRate(days, target, availableBalance);

        assertNotNull(result);
        assertEquals(new Double(0), result);
    }

    @Test
    public void getDaysSinceFyStartTest() {

        LocalDate today = LocalDate.now();
        long result = factory.getDaysSinceFyStart(today.getMonth().getValue());

        assertEquals(today.getDayOfMonth(), result);
    }

    private Balances getBalances() {

        Balances balances = new Balances();
        balances.obligations = 5d;
        balances.commitments = 4d;
        balances.credits = 2d;
        balances.rSales = 3d;
        balances.surcharges = 6d;

        return balances;
    }
}
