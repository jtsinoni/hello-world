package logicole.servers.finance.business.processor;

import static org.junit.Assert.assertNotNull;

import logicole.common.datamodels.finance.FundingNode;
import logicole.common.datamodels.finance.response.Balances;
import logicole.common.general.logging.Logger;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class CheckInitTest {

    @InjectMocks
    private ObligationAdd obAdd;
    @Mock
    private Logger logger;

    @Test
    public void checkInitNull() {
        FundingNode node = new FundingNode();
        obAdd.checkInit(node);

        assertNotNull(node.balances);
    }

    @Test
    public void checkInitNotNull() {
        FundingNode node = new FundingNode();
        node.balances = new Balances();

        obAdd.checkInit(node);

        assertNotNull(node.balances);
    }

}
