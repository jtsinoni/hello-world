package logicole.servers.finance.business;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.spy;

import logicole.common.datamodels.finance.FundingNodeRef;
import logicole.common.datamodels.finance.ProcessingBalance;
import logicole.common.datamodels.finance.response.Balances;
import logicole.common.datamodels.finance.response.ResponseGroup;
import logicole.common.general.util.*;
import logicole.servers.finance.business.decision.DecisionManager;
import logicole.servers.finance.dao.FinanceDecisionDao;
import logicole.servers.finance.dao.FundingNodeDao;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

@RunWith(MockitoJUnitRunner.class)
public class FinanceManagerTest {

    @Mock
    private FinanceDecisionDao financeDecisionDao;
    @Mock
    private HashUtil hashUtil;
    @Mock
    private FinanceAdminManager financeAdminManager;
    @Mock
    private CdiUtil cdiUtil;
    @Mock
    private DecisionManager decisionManager;
    @Mock
    private FundingNodeDao fundingNodeDao;
    @Mock
    private ObjectMapper mapper;

    @InjectMocks
    private FinanceManager financeManager;

    private FinanceManager financeManagerSpy;

    @Before
    public void setup() {
        financeManagerSpy = spy(financeManager);
    }


    @Test
    public void checkForNegativeFundsNotificationTest0() {
        List<ResponseGroup> list = new ArrayList<>();
        ResponseGroup grp1 = new ResponseGroup();
        list.add(grp1);
        Balances bal1 = new Balances();
        bal1.total = 5d;
        ProcessingBalance processingBalance = new ProcessingBalance();
        processingBalance.balances = bal1;
        List<ProcessingBalance> balances = new ArrayList<>();
        balances.add(processingBalance);
        grp1.endingBalances = balances;

        FundingNodeRef node1 = new FundingNodeRef();
        grp1.fundingNodeRef = node1;
        node1.target = 5d;

        ResponseGroup grp2 = new ResponseGroup();
        list.add(grp2);
        Balances bal2 = new Balances();
        bal2.total = 4d;
        ProcessingBalance processingBalance2 = new ProcessingBalance();
        processingBalance2.balances = bal2;
        List<ProcessingBalance> balances2 = new ArrayList<>();
        balances2.add(processingBalance2);
        grp2.endingBalances = balances2;
        FundingNodeRef node2 = new FundingNodeRef();
        grp2.fundingNodeRef = node2;
        node2.target = 5d;

        ResponseGroup grp3 = new ResponseGroup();
        list.add(grp3);
        Balances bal3 = new Balances();
        bal3.total = 6d;
        ProcessingBalance processingBalance3 = new ProcessingBalance();
        processingBalance3.balances = bal3;
        List<ProcessingBalance> balances3 = new ArrayList<>();
        balances3.add(processingBalance3);
        grp3.endingBalances = balances3;
        FundingNodeRef node3 = new FundingNodeRef();
        grp3.fundingNodeRef = node3;
        node3.target = 5d;

        List<FundingNodeRef> refs = financeManagerSpy.checkForNegativeFundsNotification(list);

        assertNotNull(refs);
        assertEquals(1, refs.size());
    }


}
