package logicole.apis.search;

import logicole.common.api.IMicroserviceApi;
import logicole.common.datamodels.search.request.DmlesSearchRequest;
import logicole.common.general.exception.InvalidDataException;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/search")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public interface ISearchMicroserviceApi extends IMicroserviceApi {

    @POST
    @Path("/getSearchResults")
    String getSearchResults(DmlesSearchRequest dmlesSearchRequest) throws InvalidDataException;

}
