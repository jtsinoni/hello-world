package logicole.apis.asset;


import logicole.common.api.IMicroserviceApi;
import logicole.common.datamodels.equipment.EquipmentRecord;
import logicole.common.datamodels.equipment.SearchInputEquipmentRecord;
import logicole.common.datamodels.search.request.DmlesSearchRequest;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

@Path("/equipment")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public interface IEquipmentRecordMicroserviceApi extends IMicroserviceApi {

    @POST
    @Path("/buildEquipmentSearchRequest")
    DmlesSearchRequest buildEquipmentSearchRequest(SearchInputEquipmentRecord searchInputEquipmentRecord);

    @GET
    @Path("/getEquipmentRecord")
    EquipmentRecord getEquipmentRecord(@QueryParam("dodaac") String dodaac, @QueryParam("meId") int meId);

}
