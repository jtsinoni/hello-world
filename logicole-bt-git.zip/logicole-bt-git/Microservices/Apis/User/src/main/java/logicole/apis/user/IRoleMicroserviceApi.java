package logicole.apis.user;

import logicole.common.api.IMicroserviceApi;
import logicole.common.datamodels.user.Permission;
import logicole.common.datamodels.user.Role;
import logicole.common.datamodels.user.RoleFunctionalArea;
import logicole.common.general.exception.ObjectNotFoundException;

import java.util.List;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

@Path("/role")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public interface IRoleMicroserviceApi extends IMicroserviceApi {

    @GET
    @Path("/renameRole")
    Role renameRole(@QueryParam("roleId") String roleId,
                    @QueryParam("newRoleName") String newRoleName) throws ObjectNotFoundException;

    @GET
    @Path("/getAllPermissions")                    
    List<RoleFunctionalArea> getAllPermissions();

    @GET
    @Path("/getAllPermissionsFull")     
    List<Permission> getAllPermissionsFull();
    
    @POST
    @Path("/savePermissionDetailed")
    public Permission savePermission(Permission permission) throws ObjectNotFoundException;
    
    @POST
    @Path("/savePermissionElements")
    public Permission savePermissionElements(Permission permission) throws ObjectNotFoundException;
    
    @POST
    @Path("/savePermissionStates")
    public Permission savePermissionStates(Permission permission) throws ObjectNotFoundException;
    
    @POST
    @Path("/savePermissionEndpoints")
    public Permission savePermissionEndpoints(Permission permission) throws ObjectNotFoundException;    
}
