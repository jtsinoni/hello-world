package logicole.apis.user;

import logicole.common.api.IMicroserviceApi;
import logicole.common.datamodels.user.*;

import java.util.List;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

@Path("/invitation")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public interface IInvitationMicroserviceApi extends IMicroserviceApi {

    @POST
    @Path("/acceptGroupInvitation")
    UserProfile acceptGroupInvitation(UserProfile userProfile);

    @GET
    @Path("/acceptInvitation")
    UserProfile acceptInvitation(String invitationId);

    @POST
    @Path("/acceptInvitationByPendingUser")
    UserProfile acceptInvitationByPendingUser(UserProfile userProfile);

    @POST
    @Path("/approveInvitationByManager")
    UserProfile approveInvitationByManager(UserProfile userProfile);

    @POST
    @Path("/createInvitation")
    GroupInvitation createInvitation(GroupInvitation groupInvitation);

    @POST
    @Path("/denyGroupInvitationByManager")
    Boolean denyGroupInvitationByManager(UserProfile userProfile);

    @GET
    @Path("/denyGroupInvitationByUser")
    boolean denyGroupInvitationByUser(String userProfileId);

    @GET
    @Path("/denySingleInvitationByAdmin")
    boolean denySingleInvitationByAdmin(String invitationId);

    @GET
    @Path("/denySingleInvitationByUser")
    boolean denySingleInvitationByUser(String invitationId);

    @GET
    @Path("/getAllGroupInvitations")
    List<GroupInvitation> getAllGroupInvitations();

    @GET
    @Path("/getGroupInvitation")
    GroupInvitation getGroupInvitation(String invitationId);

    @Produces(MediaType.TEXT_PLAIN)
    @GET
    @Path("/getGroupInvitationUrl")
    String getGroupInvitationUrl(String invitationId);

    @GET
    @Path("/getProfilesByGroupInvitationId")
    List<GroupInvitationProfileTableData> getProfilesByGroupInvitationId(String groupInvitationId);
}
