package logicole.apis.user;

import logicole.common.api.IMicroserviceApi;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.datamodels.user.Element;
import logicole.common.datamodels.user.UserProfile;

import java.util.List;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

@Path("/user")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public interface IUserMicroserviceApi extends IMicroserviceApi {

    @GET
    @Path("/getUserProfileById")
    UserProfile getUserProfileById(@QueryParam("id") String id);

    @GET
    @Path("/getUsersCurrentProfile")
    CurrentUser getUsersCurrentProfile(@QueryParam("pkiDn") String pkiDn);

    @GET
    @Path("/getUsersForNodeId")
    List<UserProfile> getUsersForNodeId(@QueryParam("id") String id);

    @GET
    @Path("/getUsersForRoleId")
    List<UserProfile> getUsersForRoleId(@QueryParam("id") String id);

    @POST
    @Path("/updateReference")
    void updateReference(UserProfile user);

    @GET
    @Path("/requestPkiDnUpdate")
    UserProfile requestPkiDnUpdate(@QueryParam("userEmail") String userEmail);

    @GET
    @Path("/getCntActiveUserProfiles")
    @Produces(MediaType.TEXT_PLAIN)
    String getCntActiveUserProfiles(@QueryParam("pkiDn") String pkiDn);

    @GET
    @Path("/getActiveUserProfiles")
    List<UserProfile> getActiveUserProfiles(@QueryParam("pkiDn") String pkiDn);

    @GET
    @Path("/getUserProfilesByPkiDn")
    List<UserProfile> getUserProfilesByPkiDn(@QueryParam("pkiDn") String pkiDn);

    @GET
    @Path("/setCurrentProfile")
    CurrentUser setCurrentProfile(@QueryParam("id") String id);

}
