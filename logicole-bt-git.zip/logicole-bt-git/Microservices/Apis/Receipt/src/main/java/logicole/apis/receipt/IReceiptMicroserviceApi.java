package logicole.apis.receipt;


import logicole.common.api.IMicroserviceApi;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

@Path("/receipt")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public interface IReceiptMicroserviceApi extends IMicroserviceApi {


}
