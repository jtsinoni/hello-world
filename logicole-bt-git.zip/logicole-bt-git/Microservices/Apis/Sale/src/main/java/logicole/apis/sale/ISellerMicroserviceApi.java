package logicole.apis.sale;


import logicole.common.api.IMicroserviceApi;
import logicole.common.datamodels.sale.seller.Seller;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.util.List;

@Path("/seller")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public interface ISellerMicroserviceApi extends IMicroserviceApi {

    @GET
    @Path("/getMySellerList")
    List<Seller> getMySellerList();

    @GET
    @Path("/getSellerById")
    Seller getSellerById(@QueryParam("Id") String sellerId);

    @POST
    @Path("/saveSeller")
    Seller saveSeller(Seller seller);

    @GET
    @Path("/deleteSeller")
    Seller deleteSeller(@QueryParam("Id") String sellerId);


}
