package logicole.apis.system;

import logicole.common.api.IMicroserviceApi;
import logicole.common.datamodels.system.*;
import logicole.common.general.exception.InvalidDataException;

import java.io.IOException;
import java.util.List;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

@Path("/System")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public interface ISystemMicroserviceApi extends IMicroserviceApi {

    @GET
    @Path("/getServices")
    public List<ServiceAgency> getServices();

    @GET
    @Path("/healthChecks")
    public List<HealthCheck> getHealthChecks();

    @POST
    @Path("/applicationHistory")
    public String getApplicationHistory(ApplicationHistorySearch applicationHistorySearch) throws InvalidDataException;

    @GET
    @Path("/getVersion")
    public AboutPT getBuildVersion() throws IOException;

}
