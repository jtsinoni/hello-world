package logicole.apis.system;

import logicole.common.api.IMicroserviceApi;
import logicole.common.datamodels.notification.ApplicationNotification;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

@Path("/notification")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public interface IApplicationNotificationMicroserviceApi extends IMicroserviceApi {

    @POST
    @Path("/addSystemNotification")
    public ApplicationNotification addSystemNotification(ApplicationNotification applicationNotification);
}
