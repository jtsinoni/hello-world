package logicole.apis.system;

import logicole.common.api.IMicroserviceApi;
import logicole.common.datamodels.system.SystemNotification;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.util.List;

@Path("/SystemNotification")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public interface ISystemNotificationMicroserviceApi extends IMicroserviceApi {

    @GET
    @Path("/getAllSystemNotifications")
    public List<SystemNotification> getAllSystemNotifications();

    @GET
    @Path("/getActiveSystemNotifications")
    public List<SystemNotification> getActiveSystemNotifications();

    @GET
    @Path("/getSystemNotificationById")
    public SystemNotification getSystemNotificationById(@QueryParam("notificationId") String notificationId);

    @POST
    @Path("/addSystemNotification")
    public SystemNotification addSystemNotification(SystemNotification systemNotification);

    @POST
    @Path("/saveSystemNotification")
    public SystemNotification saveSystemNotification(SystemNotification systemNotification);


}
