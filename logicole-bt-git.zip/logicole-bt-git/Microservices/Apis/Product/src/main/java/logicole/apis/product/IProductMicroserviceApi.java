package logicole.apis.product;

import logicole.common.api.IMicroserviceApi;
import logicole.common.datamodels.product.*;

import java.util.List;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

@Path("/product")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public interface IProductMicroserviceApi extends IMicroserviceApi {

    @GET
    @Path("/getSiteCatalogByEnterpriseId")
    List<SiteCatalogRecord> getSiteCatalogByEnterpriseId(@QueryParam("siteId") String siteId, @QueryParam("enterpriseProductIdentifier") String enterpriseProductIdentifier);

    @GET
    @Path("/getSiteCatalogByProductId")
    List<SiteCatalogRecord> getSiteCatalogByProductId(@QueryParam("siteId") String siteId, @QueryParam("productSeqId") Integer productSeqId);

    @GET
    @Path("/getSiteCatalogItem")
    SiteCatalogRecord getSiteCatalogItem(@QueryParam("siteId") String siteId, @QueryParam("itemId") String itemId);

    @GET
    @Path("/getSiteCatalogRecord")
    SiteCatalogRecord getSiteCatalogRecord(@QueryParam("enterpriseItemIdentifier") String enterpriseItemIdentifier);

    @GET
    @Path("/getSiteCatalogByBarcode")
    List<SiteCatalogRecord> getSiteCatalogByBarcode(@QueryParam("siteId") String siteId, @QueryParam("barcode") String barcode);

    @GET
    @Path("/getSiteCatalog")
    List<SiteCatalogRecord> getSiteCatalog(@QueryParam("siteId") String siteId);

    @GET
    @Path("/getCustomerCatalog")
    List<SiteCatalogRecord> getCustomerCatalog(@QueryParam("siteId") String siteId, @QueryParam("customerId") String customerId);

    @GET
    @Path("/getSupplierCatalog")
    List<SiteCatalogRecord> getSupplierCatalog(@QueryParam("siteId") String siteId, @QueryParam("supplierNm") String supplierNm);

    @GET
    @Path("/getSiteCatalogByCommType")
    List<SiteCatalogRecord> getSiteCatalogByCommType(@QueryParam("siteId") String siteId, @QueryParam("commType") String commType);

    @GET
    @Path("/getCustomerCatalogByCommType")
    List<SiteCatalogRecord> getCustomerCatalogByCommType(@QueryParam("siteId") String siteId, @QueryParam("customerId") String customerId, @QueryParam("commType") String commType);

    @GET
    @Path("/getSupplierCatalogByCommType")
    List<SiteCatalogRecord> getSupplierCatalogByCommType(@QueryParam("siteId") String siteId, @QueryParam("supplierNm") String supplierNm, @QueryParam("commType") String commType);

    @GET
    @Path("/getEquipmentByItemId")
    List<SiteCatalogRecord> getEquipmentByItemId(@QueryParam("siteId") String siteId, @QueryParam("partialItemId") String partialItemId);

    @GET
    @Path("/searchEquipment")
    List<SiteCatalogRecord> searchEquipment(@QueryParam("siteId") String siteId, @QueryParam("itemId") String itemId, @QueryParam("shortItemDesc") String shortItemDesc, @QueryParam("longItemDesc") String longItemDesc, @QueryParam("manufacturerNm") String manufacturerNm, @QueryParam("manufCatNum") String manufCatNum, @QueryParam("deviceText") String deviceText);

    @GET
    @Path("/textSearch")
    List<SiteCatalogRecord> textSearch(@QueryParam("siteId") String siteId, @QueryParam("searchString") String searchString);

    @GET
    @Path("/textSearchCommType")
    List<SiteCatalogRecord> textSearchCommType(@QueryParam("siteId") String siteId, @QueryParam("commType") String commType, @QueryParam("searchString") String searchString);

    @GET
    @Path("/getCommodityClassList")
    List<CommodityClass> getCommodityClassList(@QueryParam("militaryServiceCode") String militaryServiceCode);

    @GET
    @Path("/getEquipmentItemIdList")
    List<ItemId> getEquipmentItemIdList(@QueryParam("siteId") String siteId, @QueryParam("partialItemId") String partialItemId);

    @GET
    @Path("/getProductSeqIdList")
    List<Integer> getProductSeqIdList();

    @GET
    @Path("/getNdcList")
    List<String> getNdcList();

    @GET
    @Path("/getMedicalSupplyProductSeqIdInfo")
    List<ProductSeqIdInfo> getMedicalSupplyProductSeqIdInfo();

    @GET
    @Path("/getEnterpriseProductIdentifier")
    @Produces(MediaType.TEXT_PLAIN)
    String getEnterpriseProductIdentifier(@QueryParam("enterpriseItemIdentifier") String enterpriseItemIdentifier);

    @GET
    @Path("/getSiteCount")
    @Produces(MediaType.TEXT_PLAIN)
    Integer getSiteCount(@QueryParam("enterpriseProductIdentifier") String enterpriseProductIdentifier);

    @GET
    @Path("/updateEnterpriseProductIdentifier")
    @Produces(MediaType.TEXT_PLAIN)
    Integer updateEnterpriseProductIdentifier(@QueryParam("enterpriseItemIdentifier") String enterpriseItemIdentifier, @QueryParam("enterpriseProductIdentifier") String enterpriseProductIdentifier);

    @GET
    @Path("/updateMmcProductIdentifier")
    @Produces(MediaType.TEXT_PLAIN)
    Integer updateMmcProductIdentifier(@QueryParam("enterpriseItemIdentifier") String enterpriseItemIdentifier, @QueryParam("mmcProductIdentifier") Integer mmcProductIdentifier);

    @GET
    @Path("/updateProductSeqId")
    @Produces(MediaType.TEXT_PLAIN)
    Integer updateProductSeqId(@QueryParam("oldProductSeqId") Integer oldProductSeqId, @QueryParam("newProductSeqId") Integer newProductSeqId);

    @GET
    @Path("/updateSiteCatalogRecordFromABi")
    @Produces(MediaType.TEXT_PLAIN)
    Integer updateSiteCatalogRecordFromABi(@QueryParam("oldEnterpriseProductIdentifier") String oldEnterpriseProductIdentifier,
                                           @QueryParam("newEnterpriseProductIdentifier") String newEnterpriseProductIdentifier,
                                           @QueryParam("oldProductSeqId") Integer oldProductSeqId,
                                           @QueryParam("newProductSeqId") Integer newProductSeqId);



    @GET
    @Path("/getOfferById")
    Offer getOfferById(@QueryParam("id") String id);

    @GET
    @Path("/getOfferByOrganizationIdentifier")
    public List<Offer> getOfferByOrganizationIdentifier(@QueryParam("organizationIdentifier") String organizationIdentifier);

    @GET
    @Path("/getOfferBySellerName")
    public List<Offer> getOfferBySellerName(@QueryParam("organizationIdentifier") String organizationIdentifier, @QueryParam("sellerName") String sellerName);

    @GET
    @Path("/getOfferByEnterpriseProductIdentifier")
    public List<Offer> getOfferByEnterpriseProductIdentifier( @QueryParam("organizationIdentifier") String organizationIdentifier, @QueryParam("enterpriseProductIdentifier") String enterpriseProductIdentifier);

    @GET
    @Path("/getOfferByPartialEnterpriseProductIdentifier")
    public List<Offer> getOfferByPartialEnterpriseProductIdentifier(@QueryParam("organizationIdentifier") String organizationIdentifier, @QueryParam("partialProductIdentifier")  String partialProductIdentifier);

}
