package logicole.apis.organization;

import logicole.common.api.IMicroserviceApi;
import logicole.common.datamodels.organization.*;

import java.util.List;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

@Path("/organization")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public interface IOrganizationMicroserviceApi extends IMicroserviceApi {

    @GET
    @Path("/getChildren")
    List<Node> getChildren(@QueryParam("parentId") String parentId);

    @GET
    @Path("/getParent")
    Node getParent(@QueryParam("nodeId") String nodeId);

    @GET
    @Path("/getNode")
    Node getNode(@QueryParam("nodeGuid") String nodeGuid);

    @GET
    @Path("/getNodeById")
    Node getNodeById(@QueryParam("nodeId") String nodeId);

    @GET
    @Path("/getNodeRoleIds")
    List<String> getNodeRoleIds(@QueryParam("nodeId") String nodeId);

    @GET
    @Path("/getNodeTypeRef")
    NodeTypeRef getNodeTypeRef(@QueryParam("nodeId") String nodeId);

    @GET
    @Path("/getNodeTypes")
    List<NodeType> getNodeTypes();

    @GET
    @Path("/getNodeTypesReduced")
    List<NodeType> getNodeTypesReduced(@QueryParam("includeRoot") String includeRoot);

    @POST
    @Path("/getNodesInScope")
    List<Node> getNodesInScope(ScopeQuery scopeNode);

    @GET
    @Path("/getScopedNodeList")
    List<Node> getScopedNodeList(@QueryParam("startingNodeId") String startingNodeId);

    @GET
    @Path("/getScopedNodeIdList")
    List<String> getScopedNodeIdList(@QueryParam("startingNodeId") String startingNodeId);

    @GET
    @Path("/getPublicNodeTree")
    NodeTree getPublicNodeTree();

    @GET
    @Path("/getScopedNodeTree")
    NodeTree getScopedNodeTree(@QueryParam("startingNodeId") String startingNodeId, @QueryParam("endingNodeTypeId") String endingNodeTypeId);

//    @POST
//    @Path("/getScopeUsingAncestry")
//    List<Node> getScopeUsingAncestry(AncestryQuery ancestryQuery);

    @GET
    @Path("/getServiceProviders")
    List<ServiceProvider> getServiceProviders();

    @GET
    @Path("/getServiceProviderById")
    ServiceProvider getServiceProviderById(@QueryParam("id") String id);

    @GET
    @Path("/getOrgIdsForNode")
    List<String> getOrgIdsForNode(@QueryParam("startingNodeId") String startingNodeId);

    @Produces(MediaType.TEXT_PLAIN)
    @GET
    @Path("/refreshNodeTree")
    String refreshNodeTree();

    @POST
    @Path("/saveProviderConsumer")
    ServiceProvider saveProviderConsumer(ServiceProvider provider);

    @GET
    @Path("/getNodeRefById")
    NodeRef getNodeRefById(@QueryParam("id") String id);

    @POST
    @Path("/getScopeUsingAncestry")
    List<Node> getScopeUsingAncestry(AncestryQuery ancestryQuery);

}
