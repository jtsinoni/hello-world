package logicole.apis.order;


import logicole.common.api.IMicroserviceApi;
import logicole.common.datamodels.general.CountDTO;
import logicole.common.datamodels.order.cart.*;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.util.List;

@Path("/cart")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public interface ICartMicroserviceApi extends IMicroserviceApi {

    @GET
    @Path("/getBuyerCartList")
    List<BuyerCart> getBuyerCartList();

    @GET
    @Path("/getBuyerCartListByBuyerId")
    List<BuyerCart> getBuyerCartListByBuyerId(@QueryParam("buyerId") String buyerId);

    @GET
    @Path("/getUserCartListByUserId")
    List<UserCart> getUserCartListByUserId(@QueryParam("userId") String userId);

    @GET
    @Path("/getBuyerCartByBuyerId")
    CartDTO getBuyerCartByBuyerId(@QueryParam("buyerId") String buyerId);

    @GET
    @Path("/addToUserCartByBuyerCartId")
    CartDTO addToUserCartByBuyerCartId(@QueryParam("userId") String userId, @QueryParam("buyerCartId") String buyerCartId);

    @GET
    @Path("/addBuyerCart")
    BuyerCart addBuyerCart(BuyerCart buyerCart);

    @POST
    @Path("/addCartItemToUserCart")
    CartDTO addCartItemToUserCart(@QueryParam("buyerId") String buyerId, CartItem cartItem);

    @GET
    @Path("/removeItemFromUserCart")
    CartDTO removeItemFromUserCart(@QueryParam("userCartId") String userCartId, @QueryParam("cartItemId") String cartItemId);

    @GET
    @Path("/moveItemToActiveCart")
    CartDTO moveItemToActiveCart(@QueryParam("userCartId") String userCartId, @QueryParam("cartItemId") String cartItemId);

    @GET
    @Path("/moveItemToSaveForLater")
    CartDTO moveItemToSaveForLater(@QueryParam("userCartId") String userCartId, @QueryParam("cartItemId") String cartItemId);

    @GET
    @Path("/getUserCartByUserId")
    CartDTO getUserCartByUserId(@QueryParam("userId") String userId,@QueryParam("buyerId") String buyerId);

    @GET
    @Path("/updateCartItemQuantity")
    CartItem updateCartItemQuantity(@QueryParam("userCartId") String userCartId, @QueryParam("cartItemId") String cartItemId, @QueryParam("quantity") Long quantity );

    @GET
    @Path("/updateCartItemPrice")
    CartItem updateCartItemPrice(@QueryParam("userCartId") String userCartId, @QueryParam("cartItemId") String cartItemId, @QueryParam("price") Float price );

    @GET
    @Path("/getUserCartActiveItemCount")
    CountDTO getUserCartActiveItemCount(@QueryParam("userId") String userId, @QueryParam("buyerId") String buyerId);

}
