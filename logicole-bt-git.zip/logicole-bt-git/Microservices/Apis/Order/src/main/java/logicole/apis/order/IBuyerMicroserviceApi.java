package logicole.apis.order;


import logicole.common.datamodels.order.buyer.Buyer;
import logicole.common.api.IMicroserviceApi;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.util.List;

@Path("/buyer")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public interface IBuyerMicroserviceApi extends IMicroserviceApi {

    @GET
    @Path("/getMyBuyerList")
    List<Buyer> getMyBuyerList();

    @GET
    @Path("/getBuyerById")
    Buyer getBuyerById(@QueryParam("Id") String buyerId);

    @POST
    @Path("/saveBuyer")
    Buyer saveBuyer(Buyer buyer);

    @GET
    @Path("/deleteBuyer")
    Buyer deleteBuyer(@QueryParam("Id") String buyerId);

}
