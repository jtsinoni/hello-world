package logicole.apis.finance;

import logicole.common.api.IMicroserviceApi;
import logicole.common.datamodels.finance.*;
import logicole.common.datamodels.finance.request.CommonFinanceRequest;
import logicole.common.datamodels.finance.response.CommonFinanceResponse;
import logicole.common.datamodels.finance.response.ResponseGroup;

import java.util.List;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

@Path("/financeManager")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public interface IFinanceManagerMicroserviceApi extends IMicroserviceApi {

    @GET
    @Path("/getFinanceDecisionss")
    List<FinanceDecision> getFinanceDecisionss();

    @POST
    @Path("/processBusinessEvent")
    CommonFinanceResponse processBusinessEvent(CommonFinanceRequest commonFinanceRequest);

    @POST
    @Path("/checkForNegativeFundsNotification")
    List<FundingNodeRef> checkForNegativeFundsNotification(List<ResponseGroup> responseGroups);
}
