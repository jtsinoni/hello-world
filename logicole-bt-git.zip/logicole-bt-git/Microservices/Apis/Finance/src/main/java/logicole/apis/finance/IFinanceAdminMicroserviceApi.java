package logicole.apis.finance;

import logicole.common.api.IMicroserviceApi;
import logicole.common.datamodels.finance.*;
import logicole.common.datamodels.finance.fundingsource.FundingSource;
import logicole.common.datamodels.organization.OrgRef;

import java.util.List;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

@Path("/financeAdmin")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public interface IFinanceAdminMicroserviceApi extends IMicroserviceApi {

    @GET
    @Path("/getFinancialSystems")
    List<FinancialSystem> getFinancialSystems();

    @GET
    @Path("/getFinancialSystemFieldConfigListByType")
    List<FundingSourceFieldConfig> getFinancialSystemFieldConfigListByType(
            @QueryParam("financialSystem") String financialSystem,
            @QueryParam("fieldType") String fieldType);

    @GET
    @Path("/getFinancialSystemFieldConfigList")
    List<FundingSourceFieldConfig> getFinancialSystemFieldConfigList(
            @QueryParam("financialSystem") String financialSystem);

    @GET
    @Path("/getSalesCodeTypes")
    List<SalesCodeType> getSalesCodeTypes();

    @GET
    @Path("/getSubAllocationHolders")
    List<SubAllocationHolder> getSubAllocationHolders();

    @GET
    @Path("/getFundCodes")
    List<FundCode> getFundCodes();

    @GET
    @Path("/getForeignCurrencies")
    List<ForeignCurrency> getForeignCurrencies();

    @GET
    @Path("/getMainAccountCodes")
    List<MainAccount> getMainAccountCodes();

    @GET
    @Path("/getCommodityCodes")
    List<CommodityCode> getCommodityCodes();

    @GET
    @Path("/getFundUsageTypes")
    List<FundUsageType> getFundUsageTypes();

    @GET
    @Path("/getSubClasses")
    List<SubClass> getSubClasses();

    @GET
    @Path("/getMainAccountTypeCodes")
    List<MainAccountType> getMainAccountTypeCodes();

    @POST
    @Path("/createFundingSource")
    FundingSource createFundingSource(FundingSource fundingSource);

    @GET
    @Path("/getFundingSourceById")
    FundingSource getFundingSourceById(@QueryParam("id") String id);

    @GET
    @Path("/getAllFundingSources")
    List<FundingSource> getAllFundingSources();

    @GET
    @Path("/getFundingNodesByFundingSource")
    List<FundingNode> getFundingNodesByFundingSource(@QueryParam("id") String id);

    @GET
    @Path("/getAllFundingNodes")
    List<FundingNode> getAllFundingNodes();

    @POST
    @Path(("/updateFundingNode"))
    FundingNode updateFundingNode(FundingNode node);

    @POST
    @Path(("/updateExpenseCenter"))
    FundingNode updateExpenseCenter(@QueryParam("id") String id, FundingNode node);

    @POST
    @Path(("/addBuyerToFund"))
    FundingNode addBuyerToFund(@QueryParam("id") String id, FundingNode node);

    @GET
    @Path("/getFundingNodesByBuyer")
    List<ProcessingBalance> getFundingNodesByBuyer(@QueryParam("id") String id);

    @GET
    @Path("/getRefDataList")
    List<RefDataList> getRefDataList(@QueryParam("collectionName") String collectionName);

    @DELETE
    @Path("/removeBuyerFromFund")
    FundingNode removeBuyerFromFund(@QueryParam("fundParentId")String fundParentId, @QueryParam("buyerOrgId")String buyerOrgId);

    @PUT
    @Path("/updateBuyer")
    FundingNode updateBuyer(@QueryParam("id") String id, OrgRef buyer);
}
