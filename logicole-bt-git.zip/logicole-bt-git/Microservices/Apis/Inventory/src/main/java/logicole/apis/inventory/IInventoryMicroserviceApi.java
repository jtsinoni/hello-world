package logicole.apis.inventory;

import logicole.common.api.IMicroserviceApi;
import logicole.common.datamodels.inventory.*;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.util.List;

@Path("/inventory")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public interface IInventoryMicroserviceApi extends IMicroserviceApi {

    @GET
    @Path("/getInventoryRecordById")
    InventoryRecord getInventoryRecordById(@QueryParam("inventoryRecordId") String inventoryRecordId);

    @GET
    @Path("/getInventoryOwners")
    List<InventoryOwner> getInventoryOwners();

    @GET
    @Path("/getInventoryOwnerById")
    InventoryOwner getInventoryOwnerById(@QueryParam("inventoryOwnerId") String inventoryOwnerId);

    @GET
    @Path("/getStorageAreas")
    List<StorageArea> getStorageAreas();

    @GET
    @Path("/getStorageAreaById")
    StorageArea getStorageAreaById(@QueryParam("storageAreaId") String storageAreaId);

    @GET
    @Path("/getInventoryLocations")
    List<InventoryLocation> getInventoryLocations();

    @GET
    @Path("/getInventoryLocationById")
    InventoryLocation getInventoryLocationById(@QueryParam("inventoryLocationId") String inventoryLocationId);

    @GET
    @Path("/getShipments")
    List<Shipment> getShipments();

    @GET
    @Path("/getShipmentById")
    Shipment getShipmentById(@QueryParam("shipmentId") String shipmentId);

    @GET
    @Path("/getInShipments")
    List<Shipment> getInShipments();

    @GET
    @Path("/getOutShipments")
    List<Shipment> getOutShipments();

    @GET
    @Path("/getShippers")
    List<Shipper> getShippers();

    @GET
    @Path("/getShipperById")
    Shipper getShipperById(@QueryParam("shipperId") String shipperId);
}
