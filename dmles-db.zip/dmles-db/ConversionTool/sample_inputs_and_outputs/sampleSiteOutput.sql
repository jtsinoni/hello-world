CREATE TABLE sampleSite 
(
  _id    VARCHAR2(200),
   CONSTRAINT sampleSite_pk PRIMARY KEY(_id),
  siteName    VARCHAR2(200),
  emOrgID    VARCHAR2(200),
  emOrgName    VARCHAR2(200),
  emOrgSerial    VARCHAR2(200),
  createdDttm    DATE,
  updatedDttm    DATE
);

CREATE TABLE emAssociatedORGIDS 
(
  _id    VARCHAR2(200),
   CONSTRAINT emAssociatedORGIDS_pk PRIMARY KEY(_id),
  organizationSerial    VARCHAR2(200),
  organizationID    VARCHAR2(200),
  organizationOrgName    VARCHAR2(200)
  sampleSite_id    VARCHAR2(200),
    CONSTRAINT emAssociatedORGIDS_sampleS_fk FOREIGN KEY (sampleSite_id) REFERENCES sampleSite(_id)
);

CREATE TABLE customerIDs 
(
  _id    VARCHAR2(200),
   CONSTRAINT customerIDs_pk PRIMARY KEY(_id),
  customerID    VARCHAR2(200),
  customerName    VARCHAR2(200),
  customerSerial    VARCHAR2(200)
  emAssociatedORGIDS_id    VARCHAR2(200),
    CONSTRAINT customerIDs_emAssociatedOR_fk FOREIGN KEY (emAssociatedORGIDS_id) REFERENCES emAssociatedORGIDS(_id)
);
