/*
 // ==========================================================================
 //       Sample Mongoose input File
 // ==========================================================================
 //
 */

/* File: sampleSite.js
 * Author: Software Engineering Team
 * Description: This is the mongoose Site Organization Schema Model.
 * This schema maps to the sampleSites collection.
 */

var mongoose = require('mongoose');

var sampleSiteSchema = new mongoose.Schema({
        siteName: {
            type: String
        },
        emOrgID: {
            type: String
        },
        emOrgName: {
            type: String
        },
        emOrgSerial: {
            type: String
        },
        emAssociatedORGIDS: {
            organizationSerial: {
                type: String
            },
            organizationID: {
                type: String
            },
            organizationOrgName: {
                type: String
            },
            customerIDs: {
                customerID: {
                    type: String
                },
                customerName: {
                    type: String
                },
                customerSerial: {
                    type: String
                }
            }
        }
    }, {timestamps: {createdAt: 'createdDttm', updatedAt: 'updatedDttm'}}
);

mongoose.model('sampleSite', sampleSiteSchema, 'SiteEquipOrganizations');
//(model name, schema name, collection name)

/*
 * NOTE: The collection name is optional.  Mongoose pluralizes the model
 * name by default.  For instance, a model named [car] would map to a 
 * collection named [cars], by default.  To override this, you can add the 
 * collection name as the third parameter.
 */