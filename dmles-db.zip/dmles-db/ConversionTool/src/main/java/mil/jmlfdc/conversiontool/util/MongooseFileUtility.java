package mil.jmlfdc.conversiontool.util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 * Class that extends FileUtility, adding additional functionality for dealing
 * with Mongoose schema definition files.
 *
 */
public class MongooseFileUtility extends FileUtility {

    private Boolean keepProcessingLines;

    /**
     * No-argument constructor
     */
    public MongooseFileUtility() {
        super();
    }

    /**
     * Determines whether or not a given line in a Mongoose file should be
     * "deleted" from a file in order to convert it into valid JSON text.
     *
     * @param line the line text
     * @return true or false
     */
    private boolean shouldMongooseLineBeDeleted(String line) {
        boolean retval = false;
        String lt = line.trim();
        if (lt.startsWith("/")
                || lt.startsWith("*")
                || lt.startsWith("mongoose.model")
                || (lt.startsWith("var ") && lt.contains("require("))) {
            retval = true;
        }
        return retval;
    }

    /**
     * Fixes the top line of a Mongoose file---part of process of converting
     * Mongoose into valid JSON text.
     *
     * @param line the line to be fixed
     * @return the fixed line
     */
    private String fixMongooseTopLine(String line) {
        String retval;
        String lt = line.trim();
        String line1 = "{" + lfChar;
        String line2;
        line2 = lt.replace("var ", "").replace("Schema", "").replace(" = new mongoose.({", "");
        line2 = line2.trim();
        line2 = "\"" + line2 + "\": {";
        retval = line1 + line2;
        return retval;
    }

    /**
     * Fixes a middle line of a Mongoose file (i.e. not the top line)---part of
     * process of converting Mongoose into valid JSON text.
     *
     * @param line the line to be fixed
     * @return the fixed line
     */
    private String fixMongooseMiddleLine(String line) {
        String retval = line.trim();
        if (retval.length() == 0) {
            retval = "";
        } else if (retval.contains("timestamps") && retval.contains("createdAt") && retval.contains("createdDttm")
                && retval.contains("updatedAt") && retval.contains("updatedDttm")) {
            retval = ",\"createdDttm\": {" + lfChar
                    + "\"type\": \"Date\"" + lfChar
                    + "}," + lfChar
                    + "\"updatedDttm\": {" + lfChar
                    + "\"type\": \"Date\"" + lfChar
                    + "}";
        } else if (retval.contains("type:Object") || retval.contains("type: Object") || retval.contains("type : Object")) {
            retval = "\"type\": \"Object\"";
        } else if (!retval.startsWith("}")) {
            if (retval.contains(": Number")) {
                retval = retval.replace(": Number", ": \"Number\"");
            } else if (retval.contains("timestamps") && retval.contains("createdAt") && retval.contains("createdDttm")
                    && retval.contains("updatedAt") && retval.contains("updatedDttm")) {
            } else {
                retval = retval.replace("String", "\"String\"");
                retval = retval.replace("Array", "\"Array\"");
                retval = retval.replace("Boolean", "\"Boolean\"");
                retval = retval.replace("Date,", "\"Date\",");

                if (retval.contains("Date.now")) {
                    retval = retval.replace("Date.now", "\"Date.now\"");
                } else {
                    retval = retval.replace(": Date", ": \"Date\"");
                }

                retval = retval.replace("mongoose.Schema.Types.ObjectId", "\"mongoose.Schema.Types.ObjectId\"");
                retval = retval.replace("true", "\"true\"");
                retval = retval.replace("false", "\"false\"");
                retval = retval.replace("0", "\"0\"");
            }
            if (retval.contains("// TODO")) {
                retval = retval.substring(0, retval.indexOf("// TODO") - 1);
            }
            retval = retval.replace(":", "\":");
            retval = "\"" + retval;

            if (retval.contains("{type\"")) {
                retval = retval.replace("{type\"", "{\"type\"");
            }
            if (retval.contains(", default")) {
                retval = retval.replace(", default", ", \"default");
            }
        }
        return retval;
    }

    /**
     * Processes an individual line in a Mongoose file (calls appropriate "fix"
     * method depending on whether this is the top line or a middle line). Part
     * of process of converting Mongoose into valid JSON text.
     *
     * @param line the line to be processed
     * @return the fixed line
     */
    private String processMongooseLine(String line) {
        String retval = "";
        String lt = line.trim();

        if (shouldMongooseLineBeDeleted(lt)) {
            retval = "";
        } else {
            if (lt.startsWith("var ")) {
                retval = fixMongooseTopLine(lt);
            } else if (lt.startsWith("});") || lt.startsWith(");")) {
                retval = "}" + lfChar + "}" + lfChar;
                // This is the last line of the schema definition
                keepProcessingLines = false;
            } else if (lt.contains("createdAt")
                    && lt.contains("updatedAt")
                    && lt.endsWith("}});")) {  // last line of schema def including timestamps
                retval = ",\"createdDttm\": {" + lfChar
                        + "\"type\": \"Date\"" + lfChar
                        + "}," + lfChar
                        + "\"updatedDttm\": {" + lfChar
                        + "\"type\": \"Date\"" + lfChar
                        + "}" + lfChar + "}" + lfChar + "}" + lfChar;
                keepProcessingLines = false;
            } else {
                retval = fixMongooseMiddleLine(lt);
            }
            if (retval.length() > 0) {
                retval = retval + lfChar;
            }
        }
        return retval;
    }

    /**
     * Converts a Mongoose file to a valid JSON String
     *
     * @param inputFile the input Mongoose filename, including path
     * @return the JSON String
     */
    public String convertMongooseFileToJSONString(String inputFile) {
        keepProcessingLines = true;
        String retval;
        try {
            BufferedReader br = new BufferedReader(new FileReader(inputFile));
            StringBuilder sb = new StringBuilder();
            String line = br.readLine();
            while (line != null && keepProcessingLines) {
                sb.append(processMongooseLine(line));
                line = br.readLine();
            }
            retval = sb.toString();
            retval = retval.replace(",,", ",");
            retval = retval.replace(("," + lfChar + ","), ("," + lfChar));
            return retval;
        } catch (IOException ie) {
            return ie.getMessage();
        } catch (Exception e) {
            return e.getMessage();
        }
    }

    /**
     * Converts a Mongoose schema definition file to a valid JSON file
     *
     * @param inputFile the input Mongoose filename, including path
     * @param outputFile the output JSON filename, including path
     */
    public void convertMongooseFileToJSONFile(String inputFile, String outputFile) {
        String mongooseString = convertMongooseFileToJSONString(inputFile);
        writeStringToFile(mongooseString, outputFile);
    }
}
