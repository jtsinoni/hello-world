package mil.jmlfdc.conversiontool;

import mil.jmlfdc.conversiontool.gui.GUIInterface;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        GUIInterface.main(args);
    }
}
