package mil.jmlfdc.conversiontool.gui;

import java.io.IOException;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import mil.jmlfdc.conversiontool.processor.Converter;

/**
 * GUIInterface Provides a basic GUI interface (a JFrame) for kicking off
 * conversion of Mongoose or JSON file (or files) to SQL file, or Mongoose file
 * to Java Persistence API (JAP) file(s).
 *
 */
public class GUIInterface extends JFrame {

    private static final String OPERATING_SYSTEM = System.getProperty("os.name");
    private static final String TITLE = "Mongoose/MongoDB to SQL/JPA Converter";
    private String lfChar;
    private Container mainContainer;
    private ConversionTypeEnum conversionTypeEnum;
    private UserActionListener userActionListener;
    private JLabel titleLabel;
    private JLabel titleSpace;
    private JLabel chooseConversionTypeLabel;
    private JComboBox chooseConversionTypeCombo;
    private JTextField inputFilenameOrDirectoryName;
    private JTextField outputFilenameOrDirectoryName;
    private JTextField logFilename;
    private JTextField inputFilenameLabelText;
    private JTextField outputFilenameLabelText;
    private JTextField logFilenameLabelText;
    private JTextField mongoDBConnectionString;
    private JTextField mongoDBServerLabelText;
    private JTextField mongoDBDatabaseName;
    private JTextField mongoDBDatabaseLabelText;
    private JTextField mongoDBCollectionName;
    private JTextField mongoDBCollectionLabelText;
    private JTextField mongoDBUsername;
    private JTextField mongoDBUsernameLabelText;
    private JPasswordField mongoDBPassword;
    private JTextField mongoDBPasswordLabelText;
    private JButton clearChoicesButton;
    private JButton runConversionButton;
    private JButton exitProgramButton;
    private String confirmMsg;
    private int confirmRun;
    private Font textLabelFont;
    private Font titleLabelFont;
    private Color backgroundColor;
    private Color dataEntryFieldColor;

    /**
     * No-argument Constructor method to set up the GUI.
     */
    public GUIInterface() {
        super(TITLE);
        setLinefeedChar();
        setColorsAndFonts();

        userActionListener = new UserActionListener();
        mainContainer = super.getContentPane();
        mainContainer.setLayout(new FlowLayout());
        mainContainer.setBackground(backgroundColor);

        setLabelsAndText();

        super.setSize(575, 850);
        super.setResizable(false);
        super.setVisible(true);

        disableMongoDBFields();
        enableInputFilenameField();
        setInputLabelForFilename();
        setOutputLabelForFilename();
    }

    private void setColorsAndFonts() {
        textLabelFont = new Font("Arial", Font.BOLD, 12);
        titleLabelFont = new Font("Arial", Font.BOLD, 18);
        backgroundColor = new Color(173, 223, 240);
        dataEntryFieldColor = new Color(255, 255, 255);
    }

    private void setLinefeedChar() {
        if (OPERATING_SYSTEM.startsWith("Window") || OPERATING_SYSTEM.startsWith("WINDOW")) {
            this.lfChar = "\r\n";
        } else {
            this.lfChar = "\n";
        }
    }

    /**
     * Adds blank space line(s) to the JFrame
     *
     * @param numberOfSpaces the number of spaces to add
     */
    private void addBlankSpace(int numberOfSpaces) {
        for (int i = 0; i < numberOfSpaces; i++) {
            titleSpace = new JLabel("                                            "
                    + "                                                          "
                    + "                                                          ");
            mainContainer.add(titleSpace);
        }
    }

    private JTextField getLabelTextField(String labelText) {
        JTextField retval = new JTextField(55);
        retval.setEditable(false);
        retval.setFont(textLabelFont);
        retval.setHorizontalAlignment(JTextField.CENTER);
        retval.setBorder(javax.swing.BorderFactory.createEmptyBorder());
        retval.setBackground(backgroundColor);
        retval.setText(labelText);
        return retval;
    }

    private void setLabelsAndText() {
        addBlankSpace(1);
        titleLabel = new JLabel(TITLE);
        titleLabel.setFont(titleLabelFont);
        mainContainer.add(titleLabel);
        addBlankSpace(1);
        chooseConversionTypeLabel = new JLabel("Choose Conversion Type");
        mainContainer.add(chooseConversionTypeLabel);
        chooseConversionTypeCombo = new JComboBox();
        chooseConversionTypeCombo.setModel(new DefaultComboBoxModel(ConversionTypeEnum.values()));
        chooseConversionTypeCombo.addActionListener(userActionListener);
        mainContainer.add(chooseConversionTypeCombo);
        addBlankSpace(2);
        inputFilenameLabelText = getLabelTextField("Enter input filename w/full path");
        mainContainer.add(inputFilenameLabelText);
        inputFilenameOrDirectoryName = new JTextField(35);
        inputFilenameOrDirectoryName.setEditable(true);
        mainContainer.add(inputFilenameOrDirectoryName);
        addBlankSpace(1);
        outputFilenameLabelText = getLabelTextField("");
        mainContainer.add(outputFilenameLabelText);
        outputFilenameOrDirectoryName = new JTextField(35);
        mainContainer.add(outputFilenameOrDirectoryName);
        addBlankSpace(1);
        logFilenameLabelText = getLabelTextField("Enter output log file name w/full path");
        mainContainer.add(logFilenameLabelText);
        logFilename = new JTextField(35);
        logFilename.setEditable(true);
        mainContainer.add(logFilename);
        addBlankSpace(3);
        mongoDBServerLabelText = getLabelTextField("");
        mainContainer.add(mongoDBServerLabelText);
        mongoDBConnectionString = new JTextField(35);
        mainContainer.add(mongoDBConnectionString);
        addBlankSpace(1);
        mongoDBDatabaseLabelText = getLabelTextField("");
        mainContainer.add(mongoDBDatabaseLabelText);
        mongoDBDatabaseName = new JTextField(35);
        mainContainer.add(mongoDBDatabaseName);
        addBlankSpace(1);

        mongoDBCollectionLabelText = getLabelTextField("");
        mainContainer.add(mongoDBCollectionLabelText);
        mongoDBCollectionName = new JTextField(35);
        mainContainer.add(mongoDBCollectionName);
        addBlankSpace(1);

        mongoDBUsernameLabelText = getLabelTextField("");
        mainContainer.add(mongoDBUsernameLabelText);
        mongoDBUsername = new JTextField(35);
        mainContainer.add(mongoDBUsername);
        addBlankSpace(1);

        mongoDBPasswordLabelText = getLabelTextField("");
        mainContainer.add(mongoDBPasswordLabelText);
        mongoDBPassword = new JPasswordField(35);
        mainContainer.add(mongoDBPassword);
        addBlankSpace(2);

        clearChoicesButton = new JButton("Clear all choices");
        mainContainer.add(clearChoicesButton);
        clearChoicesButton.addActionListener(userActionListener);
        runConversionButton = new JButton("Run conversion");
        mainContainer.add(runConversionButton);
        runConversionButton.addActionListener(userActionListener);
        exitProgramButton = new JButton("Exit Application");
        exitProgramButton.addActionListener(userActionListener);
        mainContainer.add(exitProgramButton);
    }

    /**
     * Enables the "inputFilenameOrDirectoryName" field---needed for conversions
     * that involve an input file, or files (as opposed to a MongoDB connection)
     */
    private void enableInputFilenameField() {
        inputFilenameOrDirectoryName.setText("");
        inputFilenameOrDirectoryName.setEnabled(true);
        inputFilenameOrDirectoryName.setBackground(dataEntryFieldColor);
    }

    /**
     * Disables the "inputFilenameOrDirectoryName" field---needed for
     * conversions that involve an input file, or files (as opposed to a MongoDB
     * connection)
     */
    private void disableInputFilenameField() {
        inputFilenameLabelText.setText("");
        inputFilenameOrDirectoryName.setText("");
        inputFilenameOrDirectoryName.setEnabled(false);
        inputFilenameOrDirectoryName.setBackground(backgroundColor);
    }

    /**
     * Adjusts the label above the inputFilenameOrDirectoryName to prompt for a
     * filename
     */
    private void setInputLabelForFilename() {
        inputFilenameLabelText.setText("Enter input filename w/full path");
    }

    /**
     * Adjusts the label above the inputFilenameOrDirectoryName to prompt for a
     * directory name
     */
    private void setInputLabelForDirectory() {
        inputFilenameLabelText.setText("Enter input file directory (w/full path)");
    }

    /**
     * Adjusts the label above the outputFilenameOrDirectoryName to prompt for a
     * filename
     */
    private void setOutputLabelForFilename() {
        outputFilenameLabelText.setText("Enter output filename w/full path");
    }

    /**
     * Adjusts the label above the outputFilenameOrDirectoryName to prompt for a
     * directory name
     */
    private void setOutputLabelForDirectory() {
        outputFilenameLabelText.setText("Enter output directory w/full path");
    }

    /**
     * Enables the input fields that are needed for a MongoDB-related
     * conversion.
     */
    private void enableMongoDBFields() {
        mongoDBServerLabelText.setText("Enter Hostname:Port...or Replica Set Connection String...for MongoDB server(s)");
        mongoDBConnectionString.setEnabled(true);
        mongoDBConnectionString.setBackground(dataEntryFieldColor);
        mongoDBDatabaseLabelText.setText("Enter MongoDB Database Name to use");
        mongoDBDatabaseName.setEnabled(true);
        mongoDBDatabaseName.setBackground(dataEntryFieldColor);
        mongoDBCollectionLabelText.setText("Enter name of MongoDB Collection");
        mongoDBCollectionName.setEnabled(true);
        mongoDBCollectionName.setBackground(dataEntryFieldColor);

        mongoDBUsernameLabelText.setText("Enter MongoDB username (enter NOT_APPLICABLE for DBs w/out security)");
        mongoDBUsernameLabelText.setEnabled(true);

        mongoDBUsername.setText("NOT_APPLICABLE");
        mongoDBUsername.setEnabled(true);
        mongoDBUsername.setBackground(dataEntryFieldColor);

        mongoDBPasswordLabelText.setText("Enter MongoDB password (enter NOT_APPLICABLE (default) for DBs w/out security)");
        mongoDBPasswordLabelText.setEnabled(true);

        mongoDBPassword.setText("NOT_APPLICABLE");
        mongoDBPassword.setEnabled(true);
        mongoDBPassword.setBackground(dataEntryFieldColor);
    }

    /**
     * Enables the input fields needed for a MongoDB conversion of multiple
     * collections/tables to a big SQL script.
     */
    private void enableMongoDBFieldsMultiCollection() {
        enableMongoDBFields();
        mongoDBCollectionLabelText.setText("");
        mongoDBCollectionName.setEnabled(false);
        mongoDBCollectionName.setBackground(backgroundColor);
    }

    /**
     * Disables the input fields that are needed for a MongoDB-related
     * conversion.
     */
    private void disableMongoDBFields() {
        mongoDBServerLabelText.setText("");
        mongoDBConnectionString.setText("");
        mongoDBConnectionString.setEnabled(false);
        mongoDBConnectionString.setBackground(backgroundColor);
        mongoDBConnectionString.setText("");
        mongoDBDatabaseLabelText.setText("");
        mongoDBDatabaseName.setText("");
        mongoDBDatabaseName.setEnabled(false);
        mongoDBDatabaseName.setBackground(backgroundColor);
        mongoDBDatabaseName.setText("");
        mongoDBCollectionLabelText.setText("");
        mongoDBCollectionName.setEnabled(false);
        mongoDBCollectionName.setBackground(backgroundColor);
        mongoDBUsernameLabelText.setText("");
        mongoDBUsername.setText("");
        mongoDBUsername.setEnabled(false);
        mongoDBUsername.setBackground(backgroundColor);
        mongoDBPasswordLabelText.setText("");
        mongoDBPassword.setText("");
        mongoDBPassword.setEnabled(false);
        mongoDBPassword.setBackground(backgroundColor);
    }

    /**
     * Clears all the input fields on the JFrame, returns display back to
     * default
     */
    private void clearChoices() {
        inputFilenameOrDirectoryName.setText("");
        outputFilenameOrDirectoryName.setText("");
        logFilename.setText("");
        mongoDBConnectionString.setText("");
        mongoDBDatabaseName.setText("");
        mongoDBCollectionName.setText("");
        chooseConversionTypeCombo.setSelectedIndex(0);
        disableMongoDBFields();
        enableInputFilenameField();
        setInputLabelForFilename();
        setOutputLabelForFilename();
    }

    /**
     * Reacts appropriately when user picks a different conversion option from
     * the drop-down combo box.
     */
    private void handleComboBoxChange() {
        ConversionTypeEnum conversionType = (ConversionTypeEnum) chooseConversionTypeCombo.getSelectedItem();
        if (ConversionTypeEnum.SINGLE_JSON_FILE_TO_SINGLE_SQL_SCRIPT.equals(conversionType)
                || ConversionTypeEnum.SINGLE_MONGOOSE_FILE_TO_SINGLE_JSON_FILE.equals(conversionType)
                || ConversionTypeEnum.SINGLE_MONGOOSE_FILE_TO_SINGLE_SQL_SCRIPT.equals(conversionType)) {
            enableInputFilenameField();
            setInputLabelForFilename();
            setOutputLabelForFilename();
            disableMongoDBFields();
        } else if (ConversionTypeEnum.MULTI_MONGOOSE_FILES_TO_SINGLE_SQL_SCRIPT.equals(conversionType)) {
            enableInputFilenameField();
            setInputLabelForDirectory();
            setOutputLabelForFilename();
            disableMongoDBFields();
        } else if (ConversionTypeEnum.SINGLE_MONGOOSE_FILE_TO_MULTI_JPA_FILES.equals(conversionType)) {
            enableInputFilenameField();
            setInputLabelForFilename();
            setOutputLabelForDirectory();
            disableMongoDBFields();
        } else if (ConversionTypeEnum.SINGLE_MONGODB_COLLECTION_TO_SINGLE_SQL_SCRIPT.equals(conversionType)
                || ConversionTypeEnum.SINGLE_MONGODB_COLLECTION_TO_SINGLE_MONGOOSE_FILE.equals(conversionType)
                || ConversionTypeEnum.SINGLE_MONGODB_COLLECTION_TO_SINGLE_JSON_FILE.equals(conversionType)
                || ConversionTypeEnum.SINGLE_MONGODB_COLLECTION_TO_SINGLE_VALIDATOR_SCRIPT.equals(conversionType)) {
            disableInputFilenameField();
            setOutputLabelForFilename();
            enableMongoDBFields();
        } else if (ConversionTypeEnum.MULTI_MONGODB_COLLECTIONS_TO_SINGLE_SQL_SCRIPT.equals(conversionType)
                || ConversionTypeEnum.MULTI_MONGODB_COLLECTIONS_TO_SINGLE_VALIDATOR_SCRIPT.equals(conversionType)
                || ConversionTypeEnum.MULTI_MONGODB_COLLECTIONS_TO_SINGLE_JSON_FILE.equals(conversionType)) {
            disableInputFilenameField();
            setOutputLabelForFilename();
            enableMongoDBFieldsMultiCollection();
        } else if (ConversionTypeEnum.MULTI_MONGODB_COLLECTIONS_TO_MULTIPLE_VALIDATOR_SCRIPTS.equals(conversionType)
                || ConversionTypeEnum.MULTI_MONGODB_COLLECTIONS_TO_MULTIPLE_JSON_FILES.equals(conversionType)) {
            disableInputFilenameField();
            setOutputLabelForDirectory();
            enableMongoDBFieldsMultiCollection();
        } else if (ConversionTypeEnum.SINGLE_MONGODB_COLLECTION_TO_MULTI_JPA_FILES.equals(conversionType)) {
            disableInputFilenameField();
            setOutputLabelForDirectory();
            enableMongoDBFields();
        }
    }

    /**
     * Determines if the input values are good---validates.
     *
     * @return true or false
     */
    private boolean valuesAreGood() {

        boolean retval = true;
        ConversionTypeEnum conversionType = (ConversionTypeEnum) chooseConversionTypeCombo.getSelectedItem();

        if (ConversionTypeEnum.SINGLE_JSON_FILE_TO_SINGLE_SQL_SCRIPT.equals(conversionType)
                || ConversionTypeEnum.SINGLE_MONGOOSE_FILE_TO_SINGLE_JSON_FILE.equals(conversionType)
                || ConversionTypeEnum.SINGLE_MONGOOSE_FILE_TO_SINGLE_SQL_SCRIPT.equals(conversionType)
                || ConversionTypeEnum.MULTI_MONGOOSE_FILES_TO_SINGLE_SQL_SCRIPT.equals(conversionType)
                || ConversionTypeEnum.SINGLE_MONGOOSE_FILE_TO_MULTI_JPA_FILES.equals(conversionType)) {

            if (inputFilenameOrDirectoryName.getText().length() == 0) {
                retval = false;
            }
        } else if (ConversionTypeEnum.SINGLE_MONGODB_COLLECTION_TO_SINGLE_SQL_SCRIPT.equals(conversionType)
                || ConversionTypeEnum.SINGLE_MONGODB_COLLECTION_TO_SINGLE_MONGOOSE_FILE.equals(conversionType)
                || ConversionTypeEnum.SINGLE_MONGODB_COLLECTION_TO_MULTI_JPA_FILES.equals(conversionType)
                || ConversionTypeEnum.SINGLE_MONGODB_COLLECTION_TO_SINGLE_JSON_FILE.equals(conversionType)
                || ConversionTypeEnum.SINGLE_MONGODB_COLLECTION_TO_SINGLE_VALIDATOR_SCRIPT.equals(conversionType)) {

            if (mongoDBConnectionString.getText().length() == 0
                    || mongoDBDatabaseName.getText().length() == 0
                    || mongoDBCollectionName.getText().length() == 0
                    || mongoDBUsername.getText().length() == 0
                    || mongoDBPassword.getPassword().length == 0) {
                retval = false;
            }
        } else if (ConversionTypeEnum.MULTI_MONGODB_COLLECTIONS_TO_SINGLE_SQL_SCRIPT.equals(conversionType)
                || ConversionTypeEnum.MULTI_MONGODB_COLLECTIONS_TO_SINGLE_JSON_FILE.equals(conversionType)
                || ConversionTypeEnum.MULTI_MONGODB_COLLECTIONS_TO_MULTIPLE_JSON_FILES.equals(conversionType)
                || ConversionTypeEnum.MULTI_MONGODB_COLLECTIONS_TO_MULTIPLE_VALIDATOR_SCRIPTS.equals(conversionType)
                || ConversionTypeEnum.MULTI_MONGODB_COLLECTIONS_TO_SINGLE_VALIDATOR_SCRIPT.equals(conversionType)) {

            if (mongoDBConnectionString.getText().length() == 0
                    || mongoDBDatabaseName.getText().length() == 0
                    || mongoDBUsername.getText().length() == 0
                    || mongoDBPassword.getPassword().length == 0) {
                retval = false;
            }
        }
        if (outputFilenameOrDirectoryName.getText().length() == 0
                || logFilename.getText().length() == 0) {
            retval = false;
        }
        if (chooseConversionTypeCombo.getSelectedIndex() == 0) {
            retval = false;
        }
        return retval;
    }

    /**
     * Method that kicks off the conversion process
     */
    private void runConversion() {
        try {
            String statusMsg = "Process complete";
            String statusDetail = "";
            Converter converter = new Converter();
            ConversionTypeEnum conversionType = (ConversionTypeEnum) chooseConversionTypeCombo.getSelectedItem();

            String inputFileOrDir = inputFilenameOrDirectoryName.getText().trim();
            String connectionString = mongoDBConnectionString.getText().trim();
            String mongoDBDatabase = mongoDBDatabaseName.getText().trim();
            String mongoDBCollection = mongoDBCollectionName.getText().trim();
            String outputFileOrDir = outputFilenameOrDirectoryName.getText().trim();
            String logFile = logFilename.getText().trim();
            String username = mongoDBUsername.getText().trim();
            String password = new String(mongoDBPassword.getPassword());

            if (ConversionTypeEnum.SINGLE_JSON_FILE_TO_SINGLE_SQL_SCRIPT.equals(conversionType)) {
                converter.convertSingleJSONFileToSQLFile(inputFileOrDir, outputFileOrDir, logFile);

            } else if (ConversionTypeEnum.SINGLE_MONGOOSE_FILE_TO_SINGLE_JSON_FILE.equals(conversionType)) {
                converter.convertSingleMongooseFileToJSONFile(inputFileOrDir, outputFileOrDir, logFile);

            } else if (ConversionTypeEnum.SINGLE_MONGOOSE_FILE_TO_MULTI_JPA_FILES.equals(conversionType)) {
                converter.convertSingleMongooseFileToJPAFiles(inputFileOrDir, outputFileOrDir, logFile);

            } else if (ConversionTypeEnum.SINGLE_MONGOOSE_FILE_TO_SINGLE_SQL_SCRIPT.equals(conversionType)) {
                converter.convertSingleMongooseFileToSQLFile(inputFileOrDir, outputFileOrDir, logFile);

            } else if (ConversionTypeEnum.MULTI_MONGOOSE_FILES_TO_SINGLE_SQL_SCRIPT.equals(conversionType)) {
                converter.convertMultiMongooseFilesToSQLFile(inputFileOrDir, outputFileOrDir, logFile);

            } else if (ConversionTypeEnum.SINGLE_MONGODB_COLLECTION_TO_SINGLE_JSON_FILE.equals(conversionType)) {
                converter.convertSingleMongoDBCollectionToJSONFile(connectionString, mongoDBDatabase, mongoDBCollection, outputFileOrDir, logFile, username, password);

            } else if (ConversionTypeEnum.SINGLE_MONGODB_COLLECTION_TO_SINGLE_MONGOOSE_FILE.equals(conversionType)) {
                converter.convertSingleMongoDBCollectionToMongooseFile(connectionString, mongoDBDatabase, mongoDBCollection, outputFileOrDir, logFile, username, password);

            } else if (ConversionTypeEnum.SINGLE_MONGODB_COLLECTION_TO_MULTI_JPA_FILES.equals(conversionType)) {
                converter.convertSingleMongoDBCollectionToJPAFiles(connectionString, mongoDBDatabase, mongoDBCollection, outputFileOrDir, logFile, username, password);

            } else if (ConversionTypeEnum.SINGLE_MONGODB_COLLECTION_TO_SINGLE_VALIDATOR_SCRIPT.equals(conversionType)) {
                converter.convertSingleMongoDBCollectionToMongoDBValidator(connectionString, mongoDBDatabase, mongoDBCollection, outputFileOrDir, logFile, username, password);

            } else if (ConversionTypeEnum.SINGLE_MONGODB_COLLECTION_TO_SINGLE_SQL_SCRIPT.equals(conversionType)) {
                converter.convertSingleMongoDBCollectionToSQLFile(connectionString, mongoDBDatabase, mongoDBCollection, outputFileOrDir, logFile, username, password);

            } else if (ConversionTypeEnum.MULTI_MONGODB_COLLECTIONS_TO_SINGLE_JSON_FILE.equals(conversionType)) {
                converter.convertMultiMongoDBCollectionsToJSONFile(connectionString, mongoDBDatabase, outputFileOrDir, logFile, username, password);

            } else if (ConversionTypeEnum.MULTI_MONGODB_COLLECTIONS_TO_MULTIPLE_JSON_FILES.equals(conversionType)) {
                converter.convertMultiMongoDBCollectionsToJSONFiles(connectionString, mongoDBDatabase, outputFileOrDir, logFile, username, password);

            } else if (ConversionTypeEnum.MULTI_MONGODB_COLLECTIONS_TO_SINGLE_VALIDATOR_SCRIPT.equals(conversionType)) {
                converter.convertMultiMongoDBCollectionsToMongoDBValidatorFile(connectionString, mongoDBDatabase, outputFileOrDir, logFile, username, password);

            } else if (ConversionTypeEnum.MULTI_MONGODB_COLLECTIONS_TO_MULTIPLE_VALIDATOR_SCRIPTS.equals(conversionType)) {
                converter.convertMultiMongoDBCollectionsToMongoDBValidatorFiles(connectionString, mongoDBDatabase, outputFileOrDir, logFile, username, password);

            } else if (ConversionTypeEnum.MULTI_MONGODB_COLLECTIONS_TO_SINGLE_SQL_SCRIPT.equals(conversionType)) {
                converter.convertMultiMongoDBCollectionsToSQLFile(connectionString, mongoDBDatabase, outputFileOrDir, logFile, username, password);
            }

            statusDetail = "All done.  Review log file for QA results (look for the word 'ALERT').";
            if (ConversionTypeEnum.SINGLE_MONGOOSE_FILE_TO_SINGLE_JSON_FILE.equals(conversionType)
                    || ConversionTypeEnum.SINGLE_MONGODB_COLLECTION_TO_SINGLE_JSON_FILE.equals(conversionType)
                    || ConversionTypeEnum.SINGLE_MONGODB_COLLECTION_TO_SINGLE_MONGOOSE_FILE.equals(conversionType)
                    || ConversionTypeEnum.MULTI_MONGODB_COLLECTIONS_TO_SINGLE_JSON_FILE.equals(conversionType)
                    || ConversionTypeEnum.MULTI_MONGODB_COLLECTIONS_TO_MULTIPLE_JSON_FILES.equals(conversionType)
                    || ConversionTypeEnum.SINGLE_MONGODB_COLLECTION_TO_SINGLE_VALIDATOR_SCRIPT.equals(conversionType)
                    || ConversionTypeEnum.MULTI_MONGODB_COLLECTIONS_TO_SINGLE_VALIDATOR_SCRIPT.equals(conversionType)
                    || ConversionTypeEnum.MULTI_MONGODB_COLLECTIONS_TO_MULTIPLE_VALIDATOR_SCRIPTS.equals(conversionType)) {
                statusDetail += lfChar + "For output JSON, Mongoose or Validator file, use a tool like Brackets to beautify (add indents)."
                        + lfChar + "Brackets may require a .js or .json file extension to work correctly.";
            }
            JOptionPane.showMessageDialog(null, statusDetail, statusMsg, JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException ioe) {
            JOptionPane.showMessageDialog(
                    null, ioe.getMessage(), "IO Exception occurred", JOptionPane.WARNING_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(
                    null, e.getMessage(), "Exception occurred", JOptionPane.WARNING_MESSAGE);
        }
    }

    /**
     * Method that validates inputs, and then runs the conversion if they are
     * valid.
     */
    private void verifyValuesAndRunConversion() {
        if (valuesAreGood()) {
            runConversion();
        } else {
            JOptionPane.showMessageDialog(null,
                    "Sorry, some info is not filled in.",
                    "Fix values and try again!",
                    JOptionPane.INFORMATION_MESSAGE);
        }
    }

    /**
     * Main method
     *
     * @param args the standard args for main method (Expect null)
     */
    public static void main(String args[]) {
        GUIInterface application = new GUIInterface();
        application.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }

    /**
     * Enum that breaks out the types of conversions that can be run
     */
    enum ConversionTypeEnum {
        NO_CHOICE {
            @Override
            public String toString() {
                return "";
            }
        },
        SINGLE_JSON_FILE_TO_SINGLE_SQL_SCRIPT {
            @Override
            public String toString() {
                return "Convert a single JSON file to a SQL script";
            }
        },
        SINGLE_MONGOOSE_FILE_TO_SINGLE_JSON_FILE {
            @Override
            public String toString() {
                return "Convert a single Mongoose file to a JSON file";
            }
        },
        SINGLE_MONGOOSE_FILE_TO_MULTI_JPA_FILES {
            @Override
            public String toString() {
                return "Convert a single Mongoose file to one or more Java JPA files";
            }
        },
        SINGLE_MONGOOSE_FILE_TO_SINGLE_SQL_SCRIPT {
            @Override
            public String toString() {
                return "Convert a single Mongoose file to a SQL script";
            }
        },
        MULTI_MONGOOSE_FILES_TO_SINGLE_SQL_SCRIPT {
            @Override
            public String toString() {
                return "Convert multiple Mongoose files to one big SQL script";
            }
        },
        SINGLE_MONGODB_COLLECTION_TO_SINGLE_JSON_FILE {
            @Override
            public String toString() {
                return "Convert a single MongoDB collection to a JSON file";
            }
        },
        SINGLE_MONGODB_COLLECTION_TO_SINGLE_MONGOOSE_FILE {
            @Override
            public String toString() {
                return "Convert a single MongoDB collection to a Mongoose file";
            }
        },
        SINGLE_MONGODB_COLLECTION_TO_MULTI_JPA_FILES {
            @Override
            public String toString() {
                return "Convert a single MongoDB collection to one or more Java JPA files";
            }
        },
        SINGLE_MONGODB_COLLECTION_TO_SINGLE_VALIDATOR_SCRIPT {
            @Override
            public String toString() {
                return "Convert a single MongoDB collection to a MongoDB collMod Validation script";
            }
        },
        SINGLE_MONGODB_COLLECTION_TO_SINGLE_SQL_SCRIPT {
            @Override
            public String toString() {
                return "Convert a single MongoDB collection to a SQL script";
            }
        },
        MULTI_MONGODB_COLLECTIONS_TO_SINGLE_JSON_FILE {
            @Override
            public String toString() {
                return "Convert multiple MongoDB collections to a single JSON file";
            }
        },
        MULTI_MONGODB_COLLECTIONS_TO_MULTIPLE_JSON_FILES {
            @Override
            public String toString() {
                return "Convert multiple MongoDB collections to multiple JSON files";
            }
        },
        MULTI_MONGODB_COLLECTIONS_TO_SINGLE_VALIDATOR_SCRIPT {
            @Override
            public String toString() {
                return "Convert multiple MongoDB collections to one big MongoDB collMod Validation script";
            }
        },
        MULTI_MONGODB_COLLECTIONS_TO_MULTIPLE_VALIDATOR_SCRIPTS {
            @Override
            public String toString() {
                return "Convert multiple MongoDB collections to multiple MongoDB collMod Validation scripts";
            }
        },
        MULTI_MONGODB_COLLECTIONS_TO_SINGLE_SQL_SCRIPT {
            @Override
            public String toString() {
                return "Convert multiple MongoDB collections to one big SQL script";
            }
        }
    }

    /**
     * The UserActionListener class
     */
    private class UserActionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent event) {
            if (event.getSource() == exitProgramButton) {
                System.exit(0);
            } else if (event.getSource() == clearChoicesButton) {
                clearChoices();
            } else if (event.getSource() == runConversionButton) {
                verifyValuesAndRunConversion();
            } else if (event.getSource() == chooseConversionTypeCombo) {
                handleComboBoxChange();
            }
        }
    }
}
