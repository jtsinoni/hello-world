package mil.jmlfdc.conversiontool.util;

import com.mongodb.client.MongoDatabase;
import com.mongodb.client.MongoIterable;
import com.mongodb.MongoClient;
import com.mongodb.DBRef;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;
import org.bson.Document;
import java.util.List;
import java.util.ArrayList;
import com.mongodb.client.FindIterable;
import java.util.Arrays;
import java.util.Set;
import java.util.Collection;
import java.util.UUID;

/**
 * This class provides utilities for connecting to a MongoDB Database and
 * getting information that is required to perform conversion operations. (For
 * example, to convert from a MongoDB collection to a SQL script that creates a
 * similar structure, and which can then be reverse-engineered into Erwin, as
 * well as JPA formats and others).
 *
 * @author david.caglarcan
 */
public class MongoDBUtility {

    private static final String OPERATING_SYSTEM = System.getProperty("os.name");
    private static final String PARSE_TYPE_JSON = "parseTypeJSON";
    private static final String PARSE_TYPE_MONGOOSE = "parseTypeMongoose";
    private static final String DEFAULT_VALIDATOR_DATA_TYPE = "string";
    public static final String USER_CREDENTIALS_NOT_APPLICABLE = "NOT_APPLICABLE";
    private String validatorRepeatElements;
    private String lfChar;
    private String connectionString;
    private String username;
    private String password;
    private MongoCredential credential;
    private List<ServerAddress> serverAddresses;
    private MongoClient mongoClient;
    private String dbName;
    private MongoDatabase db;
    private DataTypeConversion dataTypeConversionBsonToMongoose;
    private DataTypeConversion dataTypeConversionBsonToJPA;
    private DataTypeConversion dataTypeConversionBsonToMongoDBValidator;

    private void setup(String connectionString, String dbName,
            String username, String password) throws Exception {

        this.connectionString = connectionString;

        if (username != null && !username.equals("") && password != null && !password.equals("")) {
            this.username = username;
            this.password = password;
        } else {
            this.username = this.USER_CREDENTIALS_NOT_APPLICABLE;
            this.password = this.USER_CREDENTIALS_NOT_APPLICABLE;
        }

        setListOfServerAddresses();
        setMongoClient();

        this.dbName = dbName;
        this.db = mongoClient.getDatabase(this.dbName);
        this.validatorRepeatElements = "";
        this.dataTypeConversionBsonToMongoose = new DataTypeConversion(DataTypeConversion.CONVERSION_TYPE_BSON_TO_MONGOOSE);
        this.dataTypeConversionBsonToJPA = new DataTypeConversion(DataTypeConversion.CONVERSION_TYPE_BSON_TO_JPA);
        this.dataTypeConversionBsonToMongoDBValidator = new DataTypeConversion(DataTypeConversion.CONVERSION_TYPE_BSON_TO_MONGODB_VALIDATOR);

        if (OPERATING_SYSTEM.startsWith("Window") || OPERATING_SYSTEM.startsWith("WINDOW")) {
            this.lfChar = "\r\n";
        } else {
            this.lfChar = "\n";
        }
    }

    /**
     * Encloses the String in double quotes.
     *
     * @param input the input String
     * @return the String with quotes around it.
     */
    private String quoteStr(String input) {
        String retval = "\"" + input + "\"";
        return retval;
    }

    /**
     * Removes quotes from a String. Useful when you need to transform straight
     * JSON into Mongoose schema definition.
     *
     * @param input the input String
     * @return the String with quotes removed.
     */
    private String removeQuotes(String input) {
        String retval = input;
        retval = retval.replace("\"", "");
        return retval;
    }

    /**
     * Cleans up extra symbols and junk left from the initial parse of the BSON
     * into JSON, so that the end result can be parsed by Jackson later.
     *
     * @param roughJSON the non-cleaned-up JSON
     * @return the cleaned-up JSON
     */
    private String cleanupJSON(String roughJSON) {
        String retval = roughJSON;
        retval = retval.replace(
                ("[{" + lfChar + "}]"), "{" + lfChar + quoteStr("type") + ": " + quoteStr("Array") + lfChar + "}");

        while (retval.contains(("}," + lfChar + "}"))) {
            retval = retval.replace(("}," + lfChar + "}"), ("}" + lfChar + "}"));
        }
        retval = retval.replace(("}]," + lfChar), ("}]" + lfChar));
        retval = retval.replace(("}]" + lfChar + "\""), ("}]," + lfChar + "\""));
        return retval;
    }

    /**
     * Cleans up any extra junk created by the initial parsing of the BSON into
     * Validator code.
     *
     * @param roughCode the non-cleaned-up Validator code
     * @return the cleaned-up Validator code
     */
    private String cleanupValidatorCode(String roughCode) {
        String retval = roughCode;
        retval = retval.replace("}," + lfChar + "]", "}" + lfChar + "]");
        return retval;
    }

    private void setListOfServerAddresses() {

        this.serverAddresses = new ArrayList<ServerAddress>();
        if (this.connectionString.contains("/")) {  // this is a replica set
            List<String> connectionStringPieces = Arrays.asList(this.connectionString.split("/"));
            String replicaSetName = connectionStringPieces.get(0).trim();
            String serverStringsConcat = connectionStringPieces.get(1).trim();
            List<String> serverStrings = Arrays.asList(serverStringsConcat.split(","));
            for (String serverString : serverStrings) {
                serverString = serverString.trim();
                String hostName = Arrays.asList(serverString.split(":")).get(0).trim();
                Integer port = Integer.parseInt(Arrays.asList(serverString.split(":")).get(1).trim());
                this.serverAddresses.add(new ServerAddress(hostName, port));
            }
        } else {  //single host---NOT a replica set
            String hostName = Arrays.asList(connectionString.split(":")).get(0).trim();
            Integer port = Integer.parseInt(Arrays.asList(connectionString.split(":")).get(1).trim());
            this.serverAddresses.add(new ServerAddress(hostName, port));
        }
    }

    private void setMongoClient() {

        if (this.username != null && !this.username.equals("") && !this.username.equalsIgnoreCase(this.USER_CREDENTIALS_NOT_APPLICABLE)
                && this.password != null && !this.password.equals("") && !this.password.equalsIgnoreCase(this.USER_CREDENTIALS_NOT_APPLICABLE)) {
            this.credential = MongoCredential.createCredential(this.username, "admin",
                    this.password.toCharArray());
            this.mongoClient = new MongoClient(this.serverAddresses, Arrays.asList(this.credential));
        } else {
            this.credential = null;
            this.mongoClient = new MongoClient(this.serverAddresses);
        }
    }

    /**
     * Generates generic error message to indicate that the "get one doc"
     * process failed to return a single document (i.e. the table/collection has
     * 0 records in it)
     *
     * @param connectionString the server name
     * @param dbName the database name
     * @param collectionName the collection name
     * @return the error message String
     */
    private String getEmptyCollectionExceptionMsg(String connectionString, String dbName, String collectionName) {
        return String.format("Nothing returned...server %s, database %s, collection %s must contain at least 1 record!", connectionString, dbName, collectionName);
    }

    /**
     * Parses through the BSON document, builds a JSON string into the
     * StringBuilder that is passed in as a parameter. Depending on the
     * parseType, will include a JSON-style header, or a Mongoose schema
     * creation style header. Makes recursive calls back to itself as it works
     * its way through the nested BSON structures.
     *
     * @param doc the BSON document
     * @param collectionName the name of the collection in the DB
     * @param builder the StringBuilder object into which the JSON string should
     * be written.
     * @param dataTypeConversion the data type conversion (e.g.
     * DataTypeConversoin.CONVERSION_TYPE_BSON_TO_JPA, or
     * CONVERSION_TYPE_BSON_TO_MONGOOSE).
     * @param parseType the type of parsing (e.g. PARSE_TYPE_JSON or
     * PARSE_TYPE_MONGOOSE)
     * @throws Exception if problem occurs
     */
    private void parseBSONDocForJSONOrMongoose(Document doc, String collectionName,
            StringBuilder builder, DataTypeConversion dataTypeConversion, String parseType)
            throws Exception {
        // At very top, first time through, append header-type text
        if (collectionName != null && !collectionName.equals("")) {
            if (PARSE_TYPE_JSON.equals(parseType)) {
                builder.append("{" + lfChar + quoteStr(collectionName) + ": {" + lfChar);
            } else if (PARSE_TYPE_MONGOOSE.equals(parseType)) {
                builder.append("var " + collectionName + "Schema = new mongoose.Schema({" + lfChar);
            } else {
                throw new Exception("Invalid parseType parameter passed in!");
            }
        }
        // Now press ahead with logic
        Set<String> keys = doc.keySet();
        List<String> keysList = new ArrayList<String>();
        keysList.addAll(keys);
        Collection<Object> vals = doc.values();
        List<Object> valsList = new ArrayList<Object>();
        valsList.addAll(vals);

        for (int i = 0; i < keysList.size(); i++) {
            String key = keysList.get(i);
            Object valObject = valsList.get(i);

            if (valObject != null) {

                if (valObject instanceof ArrayList) {
                    builder.append(quoteStr(key) + ": [{" + lfChar);

                    if (((ArrayList) valObject).size() > 0) {
                        Object firstItem = ((ArrayList) valObject).get(0);
                        if (firstItem instanceof Document) {
                            parseBSONDocForJSONOrMongoose((Document) firstItem, null, builder, dataTypeConversion, parseType);
                        } else if (firstItem instanceof DBRef) {
                            builder.append(quoteStr("$ref") + ": {" + lfChar
                                    + quoteStr("type") + ": " + quoteStr(((DBRef) firstItem).getCollectionName()) + lfChar + "}," + lfChar
                                    + quoteStr("$id") + ": {" + lfChar
                                    + quoteStr("type") + ": " + quoteStr("ObjectId") + lfChar + "}," + lfChar);
                        }
                    }
                    builder.append("}]," + lfChar);
                } else if (valObject instanceof Document) {

                    builder.append(quoteStr(key) + ": {" + lfChar);
                    parseBSONDocForJSONOrMongoose((Document) valObject, null, builder, dataTypeConversion, parseType);
                    builder.append("}," + lfChar);

                } else if (valObject instanceof DBRef) {
                    builder.append(quoteStr(key) + ": {" + lfChar
                            + quoteStr("$ref") + ": {" + lfChar
                            + quoteStr("type") + ": " + quoteStr(((DBRef) valObject).getCollectionName()) + lfChar + "}," + lfChar
                            + quoteStr("$id") + ": {" + lfChar
                            + quoteStr("type") + ": " + quoteStr("ObjectId") + lfChar + "}," + lfChar
                            + "}," + lfChar);
                } else {
                    String dataType = dataTypeConversion.convert(valObject.getClass().toString());
                    builder.append(quoteStr(key) + ": {" + lfChar
                            + quoteStr("type") + ": " + quoteStr(dataType) + lfChar + "}," + lfChar);
                }
            } else { // value is null, cannot determine datatype, therefore use default
                builder.append(quoteStr(key) + ": {" + lfChar
                        + quoteStr("type") + ": " + quoteStr(this.DEFAULT_VALIDATOR_DATA_TYPE) + lfChar + "}," + lfChar);
            }
        }
        // At very bottom, at the end of the last time through, add footer text
        if (collectionName != null && !collectionName.equals("")) {
            if (PARSE_TYPE_JSON.equals(parseType)) {
                builder.append("}" + lfChar + "}" + lfChar);
            } else if (PARSE_TYPE_MONGOOSE.equals(parseType)) {
                builder.append("}" + lfChar + ");" + lfChar);
            }
        }
    }

    /**
     * Parses through the BSON document, builds an appropriate MongoDB Validator
     * string into the StringBuilder that is passed in as a parameter. Makes
     * recursive calls back to itself as it works its way through the nested
     * BSON structures.
     *
     * @param doc the BSON document
     * @param collectionName the name of the collection in the DB
     * @param builder the StringBuilder object into which the JSON string should
     * be written.
     * @throws Exception if problem occurs
     */
    private void parseBSONDocForValidator(Document doc, String collectionName,
            StringBuilder builder)
            throws Exception {
        // At very top, first time through, append header-type text
        if (collectionName != null && !collectionName.equals("")) {
            // Initial statement to remove any existing validation
            builder.append("db.runCommand( { " + lfChar
                    + "collMod: " + quoteStr(collectionName) + "," + lfChar
                    + "validator: {}" + lfChar + "})" + lfChar + lfChar);
            // Now start to build new validation
            builder.append("db.runCommand( { " + lfChar
                    + "collMod: " + quoteStr(collectionName) + "," + lfChar
                    + "validator: { $and:" + lfChar
                    + "[" + lfChar);
        }
        // Now press ahead with logic
        Set<String> keys = doc.keySet();
        List<String> keysList = new ArrayList<String>();
        keysList.addAll(keys);
        Collection<Object> vals = doc.values();
        List<Object> valsList = new ArrayList<Object>();
        valsList.addAll(vals);

        for (int i = 0; i < keysList.size(); i++) {
            String key = keysList.get(i);
            Object valObject = valsList.get(i);

            if (valObject != null) {

                if (valObject instanceof ArrayList) {
                    /* ArrayList corresponds to an array within the MongoDB document.
                       If ArrayList contains at least one element, will grab the first element and evaluate.
                     */
                    if (((ArrayList) valObject).size() > 0) {
                        Object obj = ((ArrayList) valObject).get(0);
                        if (((ArrayList) valObject).get(0) instanceof Document) {
                            /* First element is a Document (i.e. a nested object type). Handle it the same
                               as a non-array nested object type.
                             */
                            validatorRepeatElements = validatorRepeatElements + key + ".";
                            Document jDoc = (Document) ((ArrayList) valObject).get(0);
                            parseBSONDocForValidator(jDoc, null, builder); //recursive call to evaluate child element

                        } else if (((ArrayList) valObject).get(0) instanceof DBRef) {   //MongoDB/Morphia DBRef!
                            /* First element is a MongoDB/Morphia DBRef
                               For the Validator, we just need to grab the datatype of the actual thing that is stored, which we 
                               get from the dbRef.getId().
                             */
                            DBRef dbRef = (DBRef) ((ArrayList) valObject).get(0);
                            Object jObject = dbRef.getId();
                            String dataType = dataTypeConversionBsonToMongoDBValidator.convert(jObject.getClass().toString());
                            builder.append("{" + quoteStr(validatorRepeatElements + key) + ": {" + lfChar
                                    + "$type : " + quoteStr(dataType) + "}" + lfChar + "}," + lfChar);
                        } else {
                            /* First element NOT a Document or DBRef, just a "primitive" value, like a string or a number. Grab that data type
                               and use it, just as if it were not an array.
                               (Unfortunately, "array" data type doesn't with MongoDB Validator, based on lots of 
                               testing done by Dave C. April 2016 w/MongoDB 3.2).
                             */
                            Object jObject = ((ArrayList) valObject).get(0);
                            String dataType = dataTypeConversionBsonToMongoDBValidator.convert(jObject.getClass().toString());
                            builder.append("{" + quoteStr(validatorRepeatElements + key) + ": {" + lfChar
                                    + "$type : " + quoteStr(dataType) + "}" + lfChar + "}," + lfChar);
                        }
                    } else { // No elements in the array---it is empty. Can't determine data type, so just go with $exists: true
                        builder.append("{ " + quoteStr(validatorRepeatElements + key) + ": { $exists: true }," + lfChar + "}," + lfChar);
                    }
                } else if (valObject instanceof Document) {
                    // Document...therefore it is a nested object type.
                    if (((Document) valObject).size() >= 0) {
                        validatorRepeatElements = validatorRepeatElements + key + ".";
                    } else {
                        builder.append(key + ": {" + lfChar);
                    }
                    parseBSONDocForValidator((Document) valObject, null, builder); //recursive call to evaluate child element

                } else if (valObject instanceof DBRef) {
                    /* MongoDB/Morphia DBRef
                       For the Validator, we just need to grab the datatype of the actual thing that is stored, which we 
                       get from the dbRef.getId().
                     */
                    Object jObject = ((DBRef) valObject).getId();
                    String dataType = dataTypeConversionBsonToMongoDBValidator.convert(jObject.getClass().toString());
                    builder.append("{" + quoteStr(validatorRepeatElements + key) + ": {" + lfChar
                            + "$type : " + quoteStr(dataType) + "}" + lfChar + "}," + lfChar);

                } else if (valObject instanceof UUID) {
                    /* Value is a Java UUID...no Mongodb $type alias...therefore just use $exists: true
                     */
                    builder.append("{ " + quoteStr(validatorRepeatElements + key) + ": { $exists: true }," + lfChar + "}," + lfChar);
                } else {
                    /*
                       Not an ArrayList, not a BSON Document, not a DBRef...just a "primitive" value, like a String or Number. Get proper
                       data type and press ahead...
                     */
                    String dataType = dataTypeConversionBsonToMongoDBValidator.convert(valObject.getClass().toString());
                    builder.append("{" + quoteStr(validatorRepeatElements + key) + ": {" + lfChar
                            + "$type : " + quoteStr(dataType) + "}" + lfChar + "}," + lfChar);
                }
            } else { // value is null, cannot determine datatype, therefore use $exists: true
                builder.append("{ " + quoteStr(validatorRepeatElements + key) + ": { $exists: true }," + lfChar + "}," + lfChar);
            }

            if (i == keysList.size() - 1) {  // Reached rightmost element in nested structure, work our way back!
                if (validatorRepeatElements.contains(".")) {
                    // Strip last period
                    validatorRepeatElements = validatorRepeatElements.substring(0, validatorRepeatElements.lastIndexOf("."));
                    /* Still have a period? If Yes, we've navigated back one level but still are within
                    a nested structure...trip things up appropriately. If No, we're back to a root element and
                    we need to null out the validatorRepeatElements.
                     */
                    if (validatorRepeatElements.contains(".")) {
                        validatorRepeatElements = validatorRepeatElements.substring(0, (validatorRepeatElements.lastIndexOf(".") + 1));
                    } else {
                        validatorRepeatElements = "";
                    }
                } else { //
                    validatorRepeatElements = "";
                }
            }
        }
        // At very bottom, at the end of the last time through, add footer text
        if (collectionName != null && !collectionName.equals("")) {
            builder.append("]" + lfChar + "}" + lfChar + "}" + lfChar + ")");
        }
    }

    /**
     * Converts a BSON Document to a straight JSON String
     *
     * @param doc the BSON Document
     * @param collectionName the name of the collection (for proper labeling
     * within the output)
     * @return the JSON String
     * @throws Exception if problem occurs
     */
    private String convertBSONDocToJSONString(Document doc, String collectionName)
            throws Exception {
        String retval = "";
        StringBuilder builder = new StringBuilder();
        parseBSONDocForJSONOrMongoose(doc, collectionName, builder, dataTypeConversionBsonToMongoose, PARSE_TYPE_JSON);
        retval = builder.toString();
        retval = cleanupJSON(retval);
        return retval;
    }

    /**
     * Converts a BSON Document to a straight JSON String with JPA-focused
     * datatypes (i.e. datatypes as you'd see in Java, rather than what you'd
     * see in Mongoose).
     *
     * @param doc the BSON Document
     * @param collectionName the name of the collection (for proper labeling
     * within the output)
     * @return the JSON String
     * @throws Exception if problem occurs
     */
    private String convertBSONDocToJSONStringWithJPADatatypes(Document doc, String collectionName)
            throws Exception {
        String retval = "";
        StringBuilder builder = new StringBuilder();
        parseBSONDocForJSONOrMongoose(doc, collectionName, builder, dataTypeConversionBsonToJPA, PARSE_TYPE_JSON);
        retval = builder.toString();
        retval = cleanupJSON(retval);
        return retval;
    }

    /**
     * Converts a BSON Document to a boilerplate Mongoose schema definition
     * String.
     *
     * @param doc the BSON Document
     * @param collectionName the name of the collection (for proper labeling
     * within the output)
     * @return the JSON String
     * @throws Exception if problem occurs
     */
    private String convertBSONDocToMongooseString(Document doc, String collectionName)
            throws Exception {
        String retval = "";
        StringBuilder builder = new StringBuilder();
        parseBSONDocForJSONOrMongoose(doc, collectionName, builder, dataTypeConversionBsonToMongoose, PARSE_TYPE_MONGOOSE);
        retval = builder.toString();
        retval = cleanupJSON(retval);
        retval = removeQuotes(retval);
        retval = cleanupJSON(retval);
        return retval;
    }

    /**
     * Converts a BSON document into boilerplate MongoDB Validator code
     *
     * @param doc the BSON document
     * @param collectionName the name of the collection
     * @return the MongoDB Validator string
     * @throws Exception if problem occurs
     */
    private String convertBSONDocToValidatorString(Document doc, String collectionName)
            throws Exception {
        String retval = "";
        StringBuilder builder = new StringBuilder();
        parseBSONDocForValidator(doc, collectionName, builder);
        retval = builder.toString();
        retval = cleanupValidatorCode(retval);
        return retval;
    }

    /**
     * Returns a list of the names of all the collections in a given MongoDB
     * database. Should return an empty ArrayList if no collections are found.
     *
     * @param connectionString hostname of the DB server
     * @param dbName DB name to query
     * @return the ArrayList containing the collection names
     * @throws Exception if problem occurs
     */
    public List<String> getCollectionNames(String connectionString, String dbName,
            String username, String password)
            throws Exception {
        setup(connectionString, dbName, username, password);
        List<String> collectionNameList = new ArrayList<String>();
        MongoIterable<String> collectionIterable = db.listCollectionNames();
        for (String ci : collectionIterable) {
            collectionNameList.add(ci);
        }
        return collectionNameList;
    }

    /**
     * Gets a single BSON Document (equivalent to running a findOne() query in
     * MongoDB).
     *
     * @param connectionString hostname of the DB server
     * @param dbName DB name to query
     * @param collectionName collection name to query
     * @return the single BSON Document
     * @throws Exception if problem occurs
     */
    public Document getOneBSONDoc(String connectionString, String dbName, String collectionName,
            String username, String password)
            throws Exception {
        setup(connectionString, dbName, username, password);
        Document retval;
        FindIterable<Document> iterable = db.getCollection(collectionName).find();
        retval = iterable.first();
        return retval;
    }

    /**
     * Gets a single BSON Document (equivalent to running a findOne() query in
     * Mongo DB), and returns it in a "raw" JSON-type format that is provided in
     * the Document API.
     *
     * @param connectionString hostname of the DB server
     * @param dbName DB name to query
     * @param collectionName collection name to query
     * @return the single raw JSON String
     * @throws Exception if problem occurs
     */
    public String getOneDocAsRawJSONString(String connectionString, String dbName, String collectionName,
            String username, String password)
            throws Exception {
        setup(connectionString, dbName, username, password);
        String retval;
        Document doc;
        FindIterable<Document> iterable = db.getCollection(collectionName).find();
        doc = iterable.first();
        if (doc == null) { //no documents/records in that collection
            throw new Exception(getEmptyCollectionExceptionMsg(connectionString, dbName, collectionName));
        }
        retval = doc.toJson();
        return retval;
    }

    /**
     * Gets a single BSON Document (equivalent to running a findOne() query in
     * Mongo DB), converts it to a schema definition in the form of a straight
     * JSON String.
     *
     * @param connectionString hostname of the DB server
     * @param dbName DB name to query
     * @param collectionName collection name to query
     * @return the JSON String
     * @throws Exception if problem occurs
     */
    public String getOneDocBuildJSONString(String connectionString, String dbName, String collectionName,
            String username, String password)
            throws Exception {
        String retval;
        setup(connectionString, dbName, username, password);
        Document doc = getOneBSONDoc(connectionString, dbName, collectionName, username, password);
        if (doc == null) { //no documents/records in that collection
            throw new Exception(getEmptyCollectionExceptionMsg(connectionString, dbName, collectionName));
        }
        retval = convertBSONDocToJSONString(doc, collectionName);
        return retval;
    }

    /**
     * Gets a single BSON Document (equivalent to running a findOne() query in
     * Mongo DB), converts it to a schema definition in the form of a straight
     * JSON String with JPA-focused data types defined.
     *
     * @param connectionString hostname of the DB server
     * @param dbName DB name to query
     * @param collectionName collection name to query
     * @return the JSON String
     * @throws Exception if problem occurs
     */
    public String getOneDocBuildJSONStringWithJPADatatypes(String connectionString, String dbName, String collectionName,
            String username, String password)
            throws Exception {
        String retval;
        setup(connectionString, dbName, username, password);
        Document doc = getOneBSONDoc(connectionString, dbName, collectionName, username, password);
        if (doc == null) { //no documents/records in that collection
            throw new Exception(getEmptyCollectionExceptionMsg(connectionString, dbName, collectionName));
        }
        retval = convertBSONDocToJSONStringWithJPADatatypes(doc, collectionName);
        return retval;
    }

    /**
     * Gets a single BSON Document (equivalent to running a findOne() query in
     * Mongo DB), converts it to a boilerplate Mongoose schema definition
     * String, and returns it.
     *
     * @param connectionString hostname of the DB server
     * @param dbName DB name to query
     * @param collectionName collection name to query
     * @return the Mongoose String
     * @throws Exception if problem occurs
     */
    public String getOneDocBuildMongooseString(String connectionString, String dbName, String collectionName,
            String username, String password)
            throws Exception {
        String retval;
        setup(connectionString, dbName, username, password);
        Document doc = getOneBSONDoc(connectionString, dbName, collectionName, username, password);
        if (doc == null) { //no documents/records in that collection
            throw new Exception(getEmptyCollectionExceptionMsg(connectionString, dbName, collectionName));
        }
        retval = convertBSONDocToMongooseString(doc, collectionName);
        return retval;
    }

    /**
     * Gets a single BSON Document (equivalent to running a findOne() query in
     * Mongo DB), converts it to a MongoDB Validator string (to be used in
     * building MongoDB Validator for that collection
     *
     * @param connectionString hostname of the DB server
     * @param dbName DB name to query
     * @param collectionName collection name to query
     * @return the Validator string
     * @throws Exception if problem occurs
     */
    public String getOneDocBuildValidatorString(String connectionString, String dbName, String collectionName,
            String username, String password)
            throws Exception {
        String retval;
        setup(connectionString, dbName, username, password);
        Document doc = getOneBSONDoc(connectionString, dbName, collectionName, username, password);
        if (doc == null) { //no documents/records in that collection
            throw new Exception(getEmptyCollectionExceptionMsg(connectionString, dbName, collectionName));
        }
        retval = convertBSONDocToValidatorString(doc, collectionName);
        return retval;
    }
}
