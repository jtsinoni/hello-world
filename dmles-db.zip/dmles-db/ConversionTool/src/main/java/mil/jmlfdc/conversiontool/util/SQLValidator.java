package mil.jmlfdc.conversiontool.util;

import mil.jmlfdc.conversiontool.model.DBTable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;

/**
 * This class contains methods that perform validation against SQL-related
 * objects that have been created during the process of converting JSON to SQL.
 * This helps alert the user of certain possible problems with the final,
 * resultant SQL script.
 *
 * @author Dave Caglarcan
 */
public class SQLValidator {

    private static final String OPERATING_SYSTEM = System.getProperty("os.name");
    private String lfChar;
    private HashMap oracleReservedWords;

    /**
     * Creates a HashMap of Oracle Reserved Words, for matching against. Oracle
     * Reserved Words list taken from
     * https://docs.oracle.com/cd/B28359_01/server.111/b28286/ap_keywd.htm and
     * added "KEY" as well.
     */
    private void setOracleReservedWords() {
        oracleReservedWords = new HashMap();
        oracleReservedWords.put("ACCESS", "");
        oracleReservedWords.put("ADD", "");
        oracleReservedWords.put("ALL", "");
        oracleReservedWords.put("ALTER", "");
        oracleReservedWords.put("AND", "");
        oracleReservedWords.put("ANY", "");
        oracleReservedWords.put("AS", "");
        oracleReservedWords.put("ASC", "");
        oracleReservedWords.put("AUDIT", "");
        oracleReservedWords.put("BETWEEN", "");
        oracleReservedWords.put("BY", "");
        oracleReservedWords.put("CHAR", "");
        oracleReservedWords.put("CHECK", "");
        oracleReservedWords.put("CLUSTER", "");
        oracleReservedWords.put("COLUMN", "");
        oracleReservedWords.put("COMMENT", "");
        oracleReservedWords.put("COMPRESS", "");
        oracleReservedWords.put("CONNECT", "");
        oracleReservedWords.put("CREATE", "");
        oracleReservedWords.put("CURRENT", "");
        oracleReservedWords.put("DATE", "");
        oracleReservedWords.put("DECIMAL", "");
        oracleReservedWords.put("DEFAULT", "");
        oracleReservedWords.put("DELETE", "");
        oracleReservedWords.put("DESC", "");
        oracleReservedWords.put("DISTINCT", "");
        oracleReservedWords.put("DROP", "");
        oracleReservedWords.put("ELSE", "");
        oracleReservedWords.put("EXCLUSIVE", "");
        oracleReservedWords.put("EXISTS", "");
        oracleReservedWords.put("FILE", "");
        oracleReservedWords.put("FLOAT", "");
        oracleReservedWords.put("FOR", "");
        oracleReservedWords.put("FROM", "");
        oracleReservedWords.put("GRANT", "");
        oracleReservedWords.put("GROUP", "");
        oracleReservedWords.put("HAVING", "");
        oracleReservedWords.put("IDENTIFIED", "");
        oracleReservedWords.put("IMMEDIATE", "");
        oracleReservedWords.put("IN", "");
        oracleReservedWords.put("INCREMENT", "");
        oracleReservedWords.put("INDEX", "");
        oracleReservedWords.put("INITIAL", "");
        oracleReservedWords.put("INSERT", "");
        oracleReservedWords.put("INTEGER", "");
        oracleReservedWords.put("INTERSECT", "");
        oracleReservedWords.put("INTO", "");
        oracleReservedWords.put("IS", "");
        oracleReservedWords.put("KEY", "");
        oracleReservedWords.put("LEVEL", "");
        oracleReservedWords.put("LIKE", "");
        oracleReservedWords.put("LOCK", "");
        oracleReservedWords.put("LONG", "");
        oracleReservedWords.put("MAXEXTENTS", "");
        oracleReservedWords.put("MINUS", "");
        oracleReservedWords.put("MLSLABEL", "");
        oracleReservedWords.put("MODE", "");
        oracleReservedWords.put("MODIFY", "");
        oracleReservedWords.put("NOAUDIT", "");
        oracleReservedWords.put("NOCOMPRESS", "");
        oracleReservedWords.put("NOT", "");
        oracleReservedWords.put("NOWAIT", "");
        oracleReservedWords.put("NULL", "");
        oracleReservedWords.put("NUMBER", "");
        oracleReservedWords.put("OF", "");
        oracleReservedWords.put("OFFLINE", "");
        oracleReservedWords.put("ON", "");
        oracleReservedWords.put("ONLINE", "");
        oracleReservedWords.put("OPTION", "");
        oracleReservedWords.put("OR", "");
        oracleReservedWords.put("ORDER", "");
        oracleReservedWords.put("PCTFREE", "");
        oracleReservedWords.put("PRIOR", "");
        oracleReservedWords.put("PRIVILEGES", "");
        oracleReservedWords.put("PUBLIC", "");
        oracleReservedWords.put("RAW", "");
        oracleReservedWords.put("RENAME", "");
        oracleReservedWords.put("RESOURCE", "");
        oracleReservedWords.put("REVOKE", "");
        oracleReservedWords.put("ROW", "");
        oracleReservedWords.put("ROWID", "");
        oracleReservedWords.put("ROWNUM", "");
        oracleReservedWords.put("ROWS", "");
        oracleReservedWords.put("SELECT", "");
        oracleReservedWords.put("SESSION", "");
        oracleReservedWords.put("SET", "");
        oracleReservedWords.put("SHARE", "");
        oracleReservedWords.put("SIZE", "");
        oracleReservedWords.put("SMALLINT", "");
        oracleReservedWords.put("START", "");
        oracleReservedWords.put("SUCCESSFUL", "");
        oracleReservedWords.put("SYNONYM", "");
        oracleReservedWords.put("SYSDATE", "");
        oracleReservedWords.put("TABLE", "");
        oracleReservedWords.put("THEN", "");
        oracleReservedWords.put("TO", "");
        oracleReservedWords.put("TRIGGER", "");
        oracleReservedWords.put("UID", "");
        oracleReservedWords.put("UNION", "");
        oracleReservedWords.put("UNIQUE", "");
        oracleReservedWords.put("UPDATE", "");
        oracleReservedWords.put("USER", "");
        oracleReservedWords.put("VALIDATE", "");
        oracleReservedWords.put("VALUES", "");
        oracleReservedWords.put("VARCHAR", "");
        oracleReservedWords.put("VARCHAR2", "");
        oracleReservedWords.put("VIEW", "");
        oracleReservedWords.put("WHENEVER", "");
        oracleReservedWords.put("WHERE", "");
        oracleReservedWords.put("WITH", "");
    }

    /**
     * Sets important values that need to be in place before processing can take
     * place.
     */
    private void setup() {
        if (OPERATING_SYSTEM.startsWith("Window") || OPERATING_SYSTEM.startsWith("WINDOW")) {
            lfChar = "\r\n";
        } else {
            lfChar = "\n";
        }
        setOracleReservedWords();
    }

    /**
     * No-argument constructor. Calls the setup() method to get stuff
     * established.
     */
    public SQLValidator() {
        super();
        this.setup();
    }

    /**
     * Determines if the value is an Oracle reserved word.
     *
     * @param theWord = the word to check on
     * @return true or false
     */
    public boolean isOracleReservedWord(String theWord) {
        boolean retval = false;
        if (theWord == null) {
            return retval;
        }
        String theWordUpper = theWord.toUpperCase();
        if (oracleReservedWords.containsKey(theWordUpper)) {
            retval = true;
        }
        return retval;
    }

    /**
     * Checks for reserved words for the entire DBTable object
     *
     * @param dbTable the DBTable object
     * @return a String describing what was found
     */
    public String checkForReservedWords(DBTable dbTable) {
        String retval = "";
        boolean anyFound = false;

        StringBuilder retvalBuilder = new StringBuilder();
        retvalBuilder.append(String.format("Starting reserved word check for table %s" + lfChar, dbTable.getTableName()));

        if (isOracleReservedWord(dbTable.getTableName())) {
            retvalBuilder.append(
                    String.format("ALERT!  Possible problem with table name %s.  This is an Oracle Reserved Word." + lfChar,
                            dbTable.getTableName()));
        }
        ArrayList<String> columnNames = dbTable.getColumnNames();
        if (columnNames != null && columnNames.size() > 0) {
            for (String columnName : columnNames) {
                if (isOracleReservedWord(columnName)) {
                    anyFound = true;
                    retvalBuilder.append(
                            String.format("...ALERT!  Possible problem with column name %s.  This is an Oracle Reserved Word." + lfChar,
                                    columnName));
                }
            }
        }
        if (!anyFound) {
            retvalBuilder.append(
                    String.format("...No Oracle Reserved Words detected among columns for table %s." + lfChar,
                            dbTable.getTableName()));
        }
        retval = retvalBuilder.toString();
        return retval;
    }

    /**
     * Checks for duplicate table names, based on the HashMap passed in. (Just
     * loops through the HashMap).
     *
     * @param tableNamesMap  the tableNamesMap
     * @return a String describing the result
     */
    public String checkForDupeTableNames(HashMap<String, Integer> tableNamesMap) {
        String retval = "";
        StringBuilder retvalBuilder = new StringBuilder();
        retvalBuilder.append(lfChar + "Checking for dupe table names..." + lfChar);
        boolean anyDupesFound = false;

        Iterator it = tableNamesMap.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pair = (Map.Entry) it.next();
            String tableName = (String) pair.getKey();
            Integer occurrences = (Integer) pair.getValue();
            if (occurrences > 1) {
                retvalBuilder.append(
                        String.format("...ALERT!  Dupe table name %s occurs %d times." + lfChar,
                                tableName, occurrences));
                anyDupesFound = true;
            }
        }
        if (!anyDupesFound) {
            retvalBuilder.append("No dupes found." + lfChar);
        }
        retval = retvalBuilder.toString();
        return retval;
    }

    /**
     * Performs validation on the "standard set" of things that comprise a
     * DataObject: a root DBTable, an ArrayList of DBTable objects associated
     * with complex nested types, and an ArrayList of DBTable objects associated
     * with simple nested array types.
     *
     * @param rootTable the root DBOBject table
     * @param nestedTablesComplexTypes the ArrayList of complex nested table
     * types
     * @param nestedTablesSimpleArrays the ArrayList of simple nested array
     * types
     * @return a String containing the overall, complete validation results
     */
    public String validateStandardSet(DBTable rootTable, ArrayList<DBTable> nestedTablesComplexTypes,
            ArrayList<DBTable> nestedTablesSimpleArrays) {
        String retval = "";
        StringBuilder retvalBuilder = new StringBuilder();
        retvalBuilder.append(String.format(lfChar + "Running Standard Set validation for rootTable %s" + lfChar + lfChar,
                rootTable.getTableName()));
        String rootReservedWordsCheck = checkForReservedWords(rootTable);
        retvalBuilder.append(rootReservedWordsCheck);

        for (DBTable x : nestedTablesComplexTypes) {
            retvalBuilder.append(checkForReservedWords(x));
        }
        for (DBTable y : nestedTablesSimpleArrays) {
            retvalBuilder.append(checkForReservedWords(y));
        }
        retval = retvalBuilder.toString();
        return retval;
    }

    /**
     * Performs validation on the "standard set" of things that comprise a
     * DataObject: a root DBTable, an ArrayList of DBTable objects associated
     * with complex nested types, and an ArrayList of DBTable objects associated
     * with simple nested array types. his version also performs dupe checking
     * to see if there are dupe table names.
     *
     * @param rootTable the root DBOBject table
     * @param nestedTablesComplexTypes the ArrayList of complex nested table
     * types
     * @param nestedTablesSimpleArrays the ArrayList of simple nested array
     * types
     * @return a String containing the overall, complete validation results
     */
    public String validateStandardSetWithDupeChecking(DBTable rootTable, ArrayList<DBTable> nestedTablesComplexTypes,
            ArrayList<DBTable> nestedTablesSimpleArrays) {
        String retval = "";
        StringBuilder retvalBuilder = new StringBuilder();
        // Perform initial, Standard Validation
        String initialValidation = validateStandardSet(
                rootTable, nestedTablesComplexTypes, nestedTablesSimpleArrays);
        retvalBuilder.append(initialValidation);
        // Now perform Dupe Check
        // Build HashMap including all table names, then check for dupes
        HashMap<String, Integer> tableNamesMap = new HashMap<>();
        tableNamesMap.merge(
                rootTable.getTableName().toUpperCase(), 1, Integer::sum);

        for (DBTable x : nestedTablesComplexTypes) {
            tableNamesMap.merge(
                    x.getTableName().toUpperCase(), 1, Integer::sum);
        }
        for (DBTable y : nestedTablesSimpleArrays) {
            tableNamesMap.merge(
                    y.getTableName().toUpperCase(), 1, Integer::sum);
        }
        String dupeCheck = checkForDupeTableNames(tableNamesMap);
        retvalBuilder.append(dupeCheck);
        // Finally, Done!
        retval = retvalBuilder.toString();
        return retval;
    }
}
