package mil.jmlfdc.conversiontool.processor;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Map;
import java.text.SimpleDateFormat;
import java.util.logging.Level;

import mil.jmlfdc.conversiontool.model.DataObject;
import mil.jmlfdc.conversiontool.model.DBTable;
import mil.jmlfdc.conversiontool.util.FileUtility;
import mil.jmlfdc.conversiontool.util.MongooseFileUtility;
import mil.jmlfdc.conversiontool.util.MongoDBUtility;
import mil.jmlfdc.conversiontool.util.logging.SimpleLogger;
import mil.jmlfdc.conversiontool.util.DataTypeConversion;
import mil.jmlfdc.conversiontool.util.SQLValidator;

/**
 * This class contains methods that perform the actual conversion work,
 * including the following possible types of conversions: 1) Mongoose schema
 * gile(s) to SQL script, 2) JSON file to SQL script, and 3) Mongoose schema
 * file(s) to Java Persistence API (JPA) file(s).
 *
 * See sample input and output files under processor.doc-files.samples!
 */
public class Converter {

    private static final String OPERATING_SYSTEM = System.getProperty("os.name");
    private static final String DEFAULT_PK_COLUMN_NAME = "_id";
    private static final String DEFAULT_PK_DATA_TYPE = "VARCHAR2(32)";
    private String lfChar;
    private String inputFilename;
    private String inputDirectoryMultipleFiles;
    private String outputFilename;
    private String outputDirectoryMultipleFiles;
    private SimpleLogger logger;
    private String logfileName;
    private DataObject rootDataObject;
    private DBTable rootDBTable;
    private ArrayList<DBTable> nestedTablesComplexTypes;
    private ArrayList<DBTable> nestedTablesComplexTypesReproJPA;
    private ArrayList<DBTable> nestedTablesSimpleArrays;
    private ArrayList<DBTable> nestedTablesSimpleArraysReproJPA;
    private SimpleDateFormat simpleDateFormat;
    private DataTypeConversion dataTypeConverterMongooseToSQL;
    private DataTypeConversion dataTypeConverterMongooseToJPA;
    private DataTypeConversion dataTypeConverterBsonToMongoose;
    private DataTypeConversion dataTypeConverterBsonToJPA;
    private DataTypeConversion dataTypeConverterNoChoice;

    /**
     * Sets things up for a conversion process to run.
     *
     * @param inputFile the input JSON or Mongoose file (if converting from 1
     * input file)
     * @param outputFile the output SQL file that will be generated
     * @param inputDirectoryMultiFiles for converting multiple Mongoose files,
     * this is the input directory where the files are located
     * @param logfile the logfile that will be generated
     */
    private void setup(String inputFile, String outputFile,
            String inputDirectoryMultiFiles, String outputDirectoryMultiFiles,
            String logfile) throws Exception {
        if (OPERATING_SYSTEM.startsWith("Window") || OPERATING_SYSTEM.startsWith("WINDOW")) {
            this.lfChar = "\r\n";
        } else {
            this.lfChar = "\n";
        }
        this.inputFilename = inputFile;
        this.outputFilename = outputFile;
        this.inputDirectoryMultipleFiles = inputDirectoryMultiFiles;
        this.outputDirectoryMultipleFiles = outputDirectoryMultiFiles;
        this.logfileName = logfile;
        this.logger = new SimpleLogger(logfileName);
        this.simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy kk:mm:ss");
        this.dataTypeConverterMongooseToSQL = new DataTypeConversion(DataTypeConversion.CONVERSION_TYPE_MONGOOSE_TO_SQL);
        this.dataTypeConverterMongooseToJPA = new DataTypeConversion(DataTypeConversion.CONVERSION_TYPE_MONGOOSE_TO_JPA);
        this.dataTypeConverterBsonToMongoose = new DataTypeConversion(DataTypeConversion.CONVERSION_TYPE_BSON_TO_MONGOOSE);
        this.dataTypeConverterBsonToJPA = new DataTypeConversion(DataTypeConversion.CONVERSION_TYPE_BSON_TO_JPA);
        this.dataTypeConverterNoChoice = new DataTypeConversion(DataTypeConversion.CONVERSION_TYPE_NO_CHOICE);
        resetSQLStuff();
    }

    /**
     * Encloses the String in double quotes.
     *
     * @param input the input String
     * @return the String with quotes around it.
     */
    private String quoteStr(String input) {
        String retval = "\"" + input + "\"";
        return retval;
    }

    /**
     * Resets DB-related variables. When processing multiple Mongoose files,
     * this needs to be run in between each file that is processed.
     */
    private void resetSQLStuff() {
        this.rootDataObject = new DataObject("TBD");
        this.rootDBTable = new DBTable();
        this.nestedTablesComplexTypes = new ArrayList<DBTable>();
        this.nestedTablesComplexTypesReproJPA = new ArrayList<DBTable>();
        this.nestedTablesSimpleArrays = new ArrayList<DBTable>();
        this.nestedTablesSimpleArraysReproJPA = new ArrayList<DBTable>();
    }

    /**
     * Parses JSON String into the root DataObject, then calls setNodes to
     * populate the Members of the DataObject.
     *
     * @param json the JSON String
     * @param dataObject the initial DataObject
     * @return the updated DataObject
     * @throws Exception if problem occurs
     */
    private DataObject parseJSONIntoDataObject(String json, DataObject dataObject) throws IOException {
        JsonFactory factory = new JsonFactory();
        ObjectMapper mapper = new ObjectMapper(factory);
        JsonNode rootNode = mapper.readTree(json);
        Iterator<Map.Entry<String, JsonNode>> fieldsIterator = rootNode.fields();
        int increment = 0;

        while (fieldsIterator.hasNext()) {
            Map.Entry<String, JsonNode> field = fieldsIterator.next();
            increment++;
            if (increment == 1) {
                dataObject.setDataKey(field.getKey().trim());
                dataObject.setNode(field.getValue());
            }
        }
        //Iterator<Map.Entry<String, JsonNode>> fieldsInterator = dataObject.getNode().fields();
        setNodes(dataObject.getNode(), dataObject);
        //setNodes(dataObject);
        return dataObject;
    }

    /**
     * Populates the Members of the DataObject, based on the JSON passed in.
     * Makes recursive calls in order to populate all the nested stuff.
     *
     * @param jsonNode the JSON to be converted into a new DataOBject
     * @param dataObject the parent DataObject into which the new DataObject
     * will be added as a Member.
     */
    private void setNodes(JsonNode jsonNode, DataObject dataObject) {
        //private void setNodes(DataObject dataObject) {

        if (!dataObject.getNode().isArray()) {

            Iterator<Map.Entry<String, JsonNode>> fieldsInterator = jsonNode.fields();

            while (fieldsInterator.hasNext()) {
                Map.Entry<String, JsonNode> nestedField = fieldsInterator.next();

                if (nestedField.getValue().isObject()) {
                    DataObject nestedDO = new DataObject("TBD");
                    nestedDO.setDataKey(nestedField.getKey().trim());
                    nestedDO.setNode(nestedField.getValue());
                    dataObject.getMembers().add(nestedDO);
                    setNodes(nestedField.getValue(), nestedDO);
                    //setNodes(nestedDO);
                } else if (nestedField.getValue().isArray()) {
                    DataObject nestedDO = new DataObject("TBD");
                    nestedDO.setDataKey(nestedField.getKey().trim());
                    JsonNode nestedNode = nestedField.getValue();
                    nestedDO.setNode(nestedNode);

                    if (nestedNode.isArray()) {
                        for (JsonNode nestedNestedNode : nestedNode) {

                            Iterator<Map.Entry<String, JsonNode>> fieldsIterator3 = nestedNestedNode.fields();

                            while (fieldsIterator3.hasNext()) {
                                Map.Entry<String, JsonNode> nestedNestedField = fieldsIterator3.next();

                                if (nestedNestedField.getValue().isObject()) {
                                    DataObject nestedNestedDO = new DataObject("TBD");
                                    nestedNestedDO.setDataKey(nestedNestedField.getKey().trim());
                                    nestedNestedDO.setNode(nestedNestedField.getValue());
                                    nestedDO.getMembers().add(nestedNestedDO);
                                    //setNodes(nestedNestedField.getValue(), nestedNestedDO);
                                }
                            }
                        }
                    }
                    dataObject.getMembers().add(nestedDO);
                    setNodes(nestedField.getValue(), nestedDO);
                }
            }
        } else {
            //System.out.println("It was an array!");
        }
    }

    /**
     * Method to use for debugging and testing.
     */
    private void displayDataObjectInfo(DataObject dataObject) {
        logger.log("dataObject dataKey = " + dataObject.getDataKey(), Level.INFO);
        logger.log("dataObject members:", Level.INFO);
        for (int i = 0; i < dataObject.getMembers().size(); i++) {
            Object member = dataObject.getMembers().get(i);
            Class classType = member.getClass();

            if (DataObject.class
                    .equals(classType)) {
                DataObject memberDataObject = (DataObject) member;
                logger.log("dataKey = " + memberDataObject.getDataKey() + " node = " + memberDataObject.getNode().toString(), Level.INFO);
            }
        }
    }

    private void genTableColumnOrNestedTable(DataObject nestedDataObject, String parentTableName)
            throws Exception {
        String sqlDataType = "";
        String jpaDataType = "";
        DBTable arrayTable = new DBTable();
        if (nestedDataObject.getMembers().size() > 0) {
            // nestedDataObject has complexity...therefore need to create nested DBTable object
            DBTable nestedDBTable = new DBTable();
            nestedDBTable.setTableName(nestedDataObject.getDataKey());
            nestedDBTable.setParentTableName(parentTableName);
            nestedDBTable.setColumnNames(new ArrayList<String>());
            nestedDBTable.setDataTypes(new ArrayList<String>());
            nestedDBTable.setJPADataTypes(new ArrayList<String>());
            nestedDBTable.setSQLBuilt(Boolean.FALSE);

            for (int i = 0; i < nestedDataObject.getMembers().size(); i++) {
                DataObject member = (DataObject) nestedDataObject.getMembers().get(i);

                if (member.getNode().isObject() || member.getNode().isArray()) {
                    if (member.getMembers().size() > 0) {
                        // If needed, make recursive call to this method, to drill down 
                        genTableColumnOrNestedTable(member, nestedDBTable.getTableName());
                    } else {
                        sqlDataType = dataTypeConverterMongooseToSQL.convert(member.getNode().toString());
                        jpaDataType = dataTypeConverterMongooseToJPA.convert(member.getNode().toString());
                        if (sqlDataType.equals("Array")) {
                            // If datatype is "Array", must create additional nested "child" table
                            arrayTable = new DBTable();
                            arrayTable.setTableName(member.getDataKey());
                            arrayTable.setParentTableName(nestedDataObject.getDataKey());
                            nestedTablesSimpleArrays.add(arrayTable);
                        } else {
                            nestedDBTable.getColumnNames().add(member.getDataKey());
                            nestedDBTable.getDataTypes().add(sqlDataType);
                            nestedDBTable.getJPADataTypes().add(jpaDataType);
                        }
                    }
                }
            }
            nestedTablesComplexTypes.add(nestedDBTable);
        } else {
            // If datatype is "Array", must create additional nested "child" table
            sqlDataType = dataTypeConverterMongooseToSQL.convert(nestedDataObject.getNode().toString());
            jpaDataType = dataTypeConverterMongooseToJPA.convert(nestedDataObject.getNode().toString());

            if (sqlDataType.equals("Array")) {
                arrayTable = new DBTable();
                arrayTable.setTableName(nestedDataObject.getDataKey());
                arrayTable.setParentTableName(parentTableName);
                nestedTablesSimpleArrays.add(arrayTable);
            } else {
                // nestedDataObject lacks complexity and is not an Array, so just make it a "column" of the rootDBTable
                rootDBTable.getColumnNames().add(nestedDataObject.getDataKey());
                rootDBTable.getDataTypes().add(sqlDataType);
                rootDBTable.getJPADataTypes().add(jpaDataType);
            }
        }
    }

    /**
     * Based on the DataObject passed in, this method generates the root DBTable
     * object. Then, it loops through the Member objects of the DataObject, andt
     * calls genTableColumnOrNestedTable method to generate nested DBTable(s)
     * appropriately.
     *
     * @param dataObject the DataObject from which to generate the root and
     * nested DBTable objects
     */
    private void genRootAndNestedDBTables(DataObject dataObject) throws Exception {
        rootDBTable.setTableName(dataObject.getDataKey());
        rootDBTable.setColumnNames(new ArrayList<String>());
        rootDBTable.setDataTypes(new ArrayList<String>());
        rootDBTable.setJPADataTypes(new ArrayList<String>());
        for (int i = 0; i < dataObject.getMembers().size(); i++) {
            DataObject nestedDO = (DataObject) dataObject.getMembers().get(i);
            genTableColumnOrNestedTable(nestedDO, rootDBTable.getTableName());
        }
    }

    /**
     * Generates the SQL 'CREATE TABLE' statement, given the DBTable object
     * provided.
     *
     * @param dbTable the DBTable
     * @return the SQL Statement String
     */
    private String genSQLCreateTableStmt(DBTable dbTable) {
        String retval = "";
        StringBuilder sqlStmtBuild = new StringBuilder();
        String createTableStart = String.format("CREATE TABLE %s " + lfChar + "(" + lfChar, dbTable.getTableName());
        String createTableEnd = ");" + lfChar + lfChar;
        String fkColumnName;
        String fkConstraintName;
        String fkColumnLine;
        String fkConstraintLine;
        String pkConstraintName;
        String pkColumnLine;
        String pkConstraintLine;
        sqlStmtBuild.append(createTableStart);
        boolean alreadyContainsPkCol = false;

        // Set PK info
        if (dbTable.getTableName().length() <= 27) {
            pkConstraintName = dbTable.getTableName() + "_pk";
        } else {
            pkConstraintName = dbTable.getTableName().substring(0, 26) + "_pk";
        }
        pkColumnLine = String.format("  %s    %s," + lfChar, DEFAULT_PK_COLUMN_NAME, DEFAULT_PK_DATA_TYPE);
        pkConstraintLine = String.format("   CONSTRAINT %s PRIMARY KEY(%s)," + lfChar, pkConstraintName, DEFAULT_PK_COLUMN_NAME);

        // Check to see if the default PK column already exists.  If not, add it.
        if (dbTable.getColumnNames() != null && dbTable.getColumnNames().size() > 0) {
            for (int i = 0; i < dbTable.getColumnNames().size(); i++) {
                if (dbTable.getColumnNames().get(i).equals(DEFAULT_PK_COLUMN_NAME)) {
                    alreadyContainsPkCol = true;
                }
            }
        }
        if (!alreadyContainsPkCol) {
            sqlStmtBuild.append(pkColumnLine);
            sqlStmtBuild.append(pkConstraintLine);
        }
        // Loop through the columns and append them to the CREATE TABLE statement.
        if (dbTable.getColumnNames() != null && dbTable.getColumnNames().size() > 0) {

            for (int i = 0; i < dbTable.getColumnNames().size(); i++) {

                if (dbTable.getColumnNames().get(i).equals(DEFAULT_PK_COLUMN_NAME)) {
                    sqlStmtBuild.append(pkColumnLine);
                    sqlStmtBuild.append(pkConstraintLine);
                } else {
                    String columnLine;
                    if (!dbTable.getDataTypes().get(i).equals("Array")) {
                        columnLine = String.format("  %s    %s", dbTable.getColumnNames().get(i), dbTable.getDataTypes().get(i));
                        if (i < dbTable.getColumnNames().size() - 1) {
                            columnLine = columnLine + "," + lfChar;
                        } else {
                            columnLine = columnLine + lfChar;
                        }
                        sqlStmtBuild.append(columnLine);
                    }
                }
            }
        }
        // If we have a FK constraint to add, do it here
        if (dbTable.getParentTableName() != null) {
            if (dbTable.getParentTableName().length() <= 27) {
                fkColumnName = dbTable.getParentTableName() + DEFAULT_PK_COLUMN_NAME;
            } else {
                fkColumnName = dbTable.getParentTableName().substring(0, 26) + DEFAULT_PK_COLUMN_NAME;
            }
            fkConstraintName = dbTable.getTableName() + "_" + dbTable.getParentTableName();
            if (fkConstraintName.length() <= 27) {
                fkConstraintName = fkConstraintName + "_fk";
            } else {
                fkConstraintName = fkConstraintName.substring(0, 26) + "_fk";
            }

            if (sqlStmtBuild.toString().endsWith(",") || sqlStmtBuild.toString().endsWith("," + lfChar)) {
                fkColumnLine = "";
            } else {
                fkColumnLine = ",";
            }
            fkColumnLine = fkColumnLine + String.format("  %s    %s," + lfChar, fkColumnName, DEFAULT_PK_DATA_TYPE);
            fkConstraintLine = String.format("    CONSTRAINT %s FOREIGN KEY (%s) REFERENCES %s(%s)" + lfChar,
                    fkConstraintName, fkColumnName, dbTable.getParentTableName(), DEFAULT_PK_COLUMN_NAME);
            sqlStmtBuild.append(fkColumnLine);
            sqlStmtBuild.append(fkConstraintLine);
        }
        // Wrap up the big SQL statement and finish up
        sqlStmtBuild.append(createTableEnd);
        retval = sqlStmtBuild.toString();
        return retval;
    }

    /**
     * Generates SQL for all of the nested complex tables. In a Mongoose file,
     * this would be the nested objects within the Mongoose schema that are,
     * themselves, complex (containing multiple attributes).
     *
     * @return a big String containing SQL for all the nested complex tables.
     */
    private String genSQLForNestedComplexTables() {
        String retval = "";
        StringBuilder nestedComplexBuild = new StringBuilder();
        String parentTableName = "";
        HashMap<DBTable, String> childrenOfTheRoot = new HashMap();

        // Add tables that are children of the root table
        for (DBTable dbTable : nestedTablesComplexTypes) {
            parentTableName = dbTable.getParentTableName();

            if (parentTableName != null && parentTableName == rootDBTable.getTableName()) {
                nestedComplexBuild.append(genSQLCreateTableStmt(dbTable));
                childrenOfTheRoot.put(dbTable, "");
                dbTable.setSQLBuilt(true);
            }
        }
        // Add tables for children of the children of the root
        for (DBTable dbTable : nestedTablesComplexTypes) {
            if (!dbTable.isSQLBuilt()) {
                parentTableName = dbTable.getParentTableName();
                if (parentTableName != null && childrenOfTheRoot.containsKey(parentTableName)) {
                    nestedComplexBuild.append(genSQLCreateTableStmt(dbTable));
                    childrenOfTheRoot.put(dbTable, "");
                    dbTable.setSQLBuilt(true);
                }
            }
        }
        // Add the rest of the nested complex tables
        for (DBTable dbTable : nestedTablesComplexTypes) {
            if (!dbTable.isSQLBuilt()) {
                nestedComplexBuild.append(genSQLCreateTableStmt(dbTable));
                dbTable.setSQLBuilt(true);
            }
        }
        retval = nestedComplexBuild.toString();
        return retval;
    }

    /**
     * Generates SQL for all the simple arrays. In a Mongoose file, this would
     * be the attributes defined as "Array" types, or the attributes that are
     * indicated as an array with "[]" but are relatively simple (i.e. don't
     * have multiple attributes themselves)
     *
     * @return a big String containing SQL for all the simple array types
     */
    private String genSQLForSimpleArrays() {
        String retval = "";
        StringBuilder sqlStmtBuild = new StringBuilder();
        if (nestedTablesSimpleArrays.size() > 0) {
            for (DBTable dbTable : nestedTablesSimpleArrays) {
                sqlStmtBuild.append(genSQLCreateTableStmt(dbTable));
            }
            retval = sqlStmtBuild.toString();
        }
        return retval;
    }

    /**
     * Generates the complete SQL String for a given root table and child tables
     *
     * @return the SQL String
     */
    private String genSQLComplete() {
        String retval;
        String sqlForRootTable;
        String sqlForNestedComplexTables;
        String sqlForSimpleArrays;

        sqlForRootTable = genSQLCreateTableStmt(rootDBTable);
        sqlForNestedComplexTables = genSQLForNestedComplexTables();
        sqlForSimpleArrays = genSQLForSimpleArrays();

        StringBuilder sqlStmtBuild = new StringBuilder();
        sqlStmtBuild.append(sqlForRootTable);
        sqlStmtBuild.append(sqlForNestedComplexTables);
        sqlStmtBuild.append(sqlForSimpleArrays);
        retval = sqlStmtBuild.toString();
        /* Trim any cases where final column in the CREATE TABLE script ended with a comma
          (which can occur if the final element in the Mongoose schema is an Array type or 
           nested complex type 
         */
        retval = retval.replace(("," + lfChar + ");"), (lfChar + ");"));
        return retval;
    }

    /**
     * Generates the Java Persistence API (JPA) code defining a boilerplate
     * sample class containing variable definitions.
     *
     * @param dbTable the inbound DBTable object
     * @param nestedTablesComplex inbound nested complex tables
     * @param nestedArrays inbound nested simple arrays
     * @return String with boilerplate Java JPA class definition code.
     */
    private String genJPA(DBTable dbTable, ArrayList<DBTable> nestedTablesComplex,
            ArrayList<DBTable> nestedArrays) {
        String retval;
        String className = dbTable.getTableName().substring(0, 1).toUpperCase() + dbTable.getTableName().substring(1);
        String jpaStart = String.format("public class %s { " + lfChar + lfChar, className);
        String jpaEnd = lfChar + "}" + lfChar + lfChar + lfChar + lfChar;
        String variableLine;
        String nestedTableName;
        String nestedTableType;
        StringBuilder jpaBuild = new StringBuilder();

        // Start building the String
        jpaBuild.append(jpaStart);

        // Turn column names into variable names and add them
        if (dbTable.getColumnNames() != null && dbTable.getColumnNames().size() > 0) {
            for (int i = 0; i < dbTable.getColumnNames().size(); i++) {
                variableLine = String.format(
                        "  private %s %s;" + lfChar, dbTable.getJPADataTypes().get(i), dbTable.getColumnNames().get(i));
                jpaBuild.append(variableLine);
            }
        }
        jpaBuild.append(lfChar);

        // Append nested complex objects as member variables if they are children of the dbTable.  Otherwise, mark them for re-attack later.
        if (nestedTablesComplex != null && nestedTablesComplex.size() > 0) {
            for (int j = 0; j < nestedTablesComplex.size(); j++) {
                String parentTableName = nestedTablesComplex.get(j).getParentTableName();
                if (parentTableName != null && parentTableName.equals(dbTable.getTableName())) {
                    nestedTableName = nestedTablesComplex.get(j).getTableName();
                    nestedTableType = nestedTableName.substring(0, 1).toUpperCase() + nestedTableName.substring(1);
                    variableLine = String.format(
                            "  private %s %s;" + lfChar, nestedTableType, nestedTableName);
                    jpaBuild.append(variableLine);
                } else if (parentTableName != null) {
                    nestedTablesComplexTypesReproJPA.add(nestedTablesComplex.get(j));
                }
            }
        }
        jpaBuild.append(lfChar);

        // Append nested simple arrays as member variables if they are children of the dbTable.  Otherwise, mark them for re-attack later.
        if (nestedArrays != null && nestedArrays.size() > 0) {
            for (int k = 0; k < nestedArrays.size(); k++) {
                String parentTableName = nestedArrays.get(k).getParentTableName();
                if (parentTableName != null && parentTableName.equals(dbTable.getTableName())) {
                    nestedTableName = nestedArrays.get(k).getTableName();
                    nestedTableType = nestedTableName.substring(0, 1).toUpperCase() + nestedTableName.substring(1);
                    variableLine = String.format(
                            "  private ArrayList<%s> %s;" + lfChar, nestedTableType, nestedTableName);
                    jpaBuild.append(variableLine);
                } else if (parentTableName != null) {
                    nestedTablesSimpleArraysReproJPA.add(nestedArrays.get(k));
                }
            }
        }

        // Finished, so now append the closing bracket and spaces to end the java class
        jpaBuild.append(jpaEnd);
        // Assemble final return value and return
        retval = jpaBuild.toString();
        return retval;
    }

    /**
     * Writes out the actual JPA Java class files...writes them into separate
     * .java files for each prospective Java class
     */
    private void writeJPAFiles() {
        String tableName;
        String className;
        String outputJPAFileName;
        String jpaText;
        MongooseFileUtility fileUtil = new MongooseFileUtility();

        // Write jpa file for root DB table
        tableName = rootDBTable.getTableName();
        className = tableName.substring(0, 1).toUpperCase() + tableName.substring(1);
        outputJPAFileName = outputDirectoryMultipleFiles + "/" + className + ".java";
        jpaText = genJPA(rootDBTable, nestedTablesComplexTypes, nestedTablesSimpleArrays);
        fileUtil.writeStringToFile(jpaText, outputJPAFileName);

        // For each complex nested type, write out jpa file
        if (nestedTablesComplexTypes != null && nestedTablesComplexTypes.size() > 0) {
            for (int i = 0; i < nestedTablesComplexTypes.size(); i++) {
                className = nestedTablesComplexTypes.get(i).getTableName().substring(0, 1).toUpperCase() + nestedTablesComplexTypes.get(i).getTableName().substring(1);
                outputJPAFileName = outputDirectoryMultipleFiles + "/" + className + ".java";
                jpaText = genJPA(nestedTablesComplexTypes.get(i), null, null);
                fileUtil.writeStringToFile(jpaText, outputJPAFileName);
            }
        }
        // For each nested array type, write out jpa file
        if (nestedTablesSimpleArrays != null && nestedTablesSimpleArrays.size() > 0) {
            for (int j = 0; j < nestedTablesSimpleArrays.size(); j++) {
                className = nestedTablesSimpleArrays.get(j).getTableName().substring(0, 1).toUpperCase() + nestedTablesSimpleArrays.get(j).getTableName().substring(1);
                outputJPAFileName = outputDirectoryMultipleFiles + "/" + className + ".java";
                jpaText = genJPA(nestedTablesSimpleArrays.get(j), null, null);
                fileUtil.writeStringToFile(jpaText, outputJPAFileName);
            }
        }
        // For DBTables 'Nested Complex Types' nested more than one deep, perform re-attack to update its parent file
        if (nestedTablesComplexTypesReproJPA != null && nestedTablesComplexTypesReproJPA.size() > 0) {
            for (int nct = 0; nct < nestedTablesComplexTypesReproJPA.size(); nct++) {
                tableName = nestedTablesComplexTypesReproJPA.get(nct).getTableName();
                className = tableName.substring(0, 1).toUpperCase() + tableName.substring(1);
                String parentName = nestedTablesComplexTypesReproJPA.get(nct).getParentTableName();
                String parentClass = parentName.substring(0, 1).toUpperCase() + parentName.substring(1);
                String parentFileName = outputDirectoryMultipleFiles + "/" + parentClass + ".java";
                String parentString = fileUtil.readFileIntoString(parentFileName);
                String parentStringNew;
                String jpaEnd = lfChar + "}" + lfChar + lfChar + lfChar + lfChar;
                String jpaEndNew = String.format("  private %s %s;" + lfChar + jpaEnd, className, tableName);
                parentStringNew = parentString.replace(jpaEnd, jpaEndNew);
                fileUtil.writeStringToFile(parentStringNew, parentFileName);
            }
        }
        // For DBTables 'Nested Simple Arrays' nested more than one deep, perform re-attack to update its parent file
        if (nestedTablesSimpleArraysReproJPA != null && nestedTablesSimpleArraysReproJPA.size() > 0) {
            for (int nar = 0; nar < nestedTablesSimpleArraysReproJPA.size(); nar++) {
                tableName = nestedTablesSimpleArraysReproJPA.get(nar).getTableName();
                className = tableName.substring(0, 1).toUpperCase() + tableName.substring(1);
                String parentName = nestedTablesSimpleArraysReproJPA.get(nar).getParentTableName();
                String parentClass = parentName.substring(0, 1).toUpperCase() + parentName.substring(1);
                String parentFileName = outputDirectoryMultipleFiles + "/" + parentClass + ".java";
                String parentString = fileUtil.readFileIntoString(parentFileName);
                String parentStringNew;
                String jpaEnd = lfChar + "}" + lfChar + lfChar + lfChar + lfChar;
                String jpaEndNew = String.format("  private %s %s;" + lfChar + jpaEnd, className, tableName);
                parentStringNew = parentString.replace(jpaEnd, jpaEndNew);
                fileUtil.writeStringToFile(parentStringNew, parentFileName);
            }
        }
    }

    /**
     * Writes initial entry to logfile
     *
     * @param callerName the name of the calling method
     */
    private void writeInitialLogEntry(String callerName) {
        Calendar calendar = new GregorianCalendar();
        String calendarFormatted = simpleDateFormat.format(calendar.getTime());
        logger.log(
                String.format(
                        "Starting %s on %s",
                        callerName,
                        calendarFormatted), Level.INFO);
    }

    /**
     * Converts a single JSON String to a SQL String. Of note, this only works
     * well for relatively simple JSON formats, not for complex ones.
     *
     * @param jsonString the JSON String
     * @return the SQL String
     * @throws Exception if problem occurs
     */
    public String convertSingleJSONStringToSQLString(String jsonString)
            throws Exception {
        String retval;
        rootDataObject = parseJSONIntoDataObject(jsonString, rootDataObject);
        genRootAndNestedDBTables(rootDataObject);
        retval = genSQLComplete();
        return retval;
    }

    /**
     * Converts a single Mongoose schema definition file to a single JSON file.
     * Results are written to logfile.
     *
     * @param inputFile the input Mongoose schema file name (including path)
     * @param outputFile the output JSON file name (including path)
     * @param logfile the output log file name (including path)
     * @throws Exception if problem occurs
     */
    public void convertSingleMongooseFileToJSONFile(String inputFile, String outputFile, String logfile)
            throws Exception {
        // Initial setup and logging
        setup(inputFile, outputFile, null, null, logfile);
        writeInitialLogEntry(Thread.currentThread().getStackTrace()[1].getMethodName());
        logger.log("Reading from Mongoose file " + this.inputFilename, Level.INFO);
        logger.log("Writing to JSON file " + this.outputFilename, Level.INFO);
        // Read Mongoose file from disk and process it
        MongooseFileUtility fileUtil = new MongooseFileUtility();
        fileUtil.convertMongooseFileToJSONFile(this.inputFilename, this.outputFilename);
        // Finally, close log
        logger.closeLog();
    }

    /**
     * Converts a single JSON file to a SQL file. Of note, this only works well
     * for relatively simple JSON formats, not for complex ones. See sample
     * inputs.
     *
     * @param inputFile the input JSON file name (including path)
     * @param outputFile the output SQL file name (including path)
     * @param logfile the output log file name (including path)
     * @throws Exception if problem occurs
     */
    public void convertSingleJSONFileToSQLFile(String inputFile, String outputFile, String logfile)
            throws Exception {
        // Initial setup and logging
        setup(inputFile, outputFile, null, null, logfile);
        writeInitialLogEntry(Thread.currentThread().getStackTrace()[1].getMethodName());
        logger.log("Reading from JSON file " + this.inputFilename, Level.INFO);
        logger.log("Writing to SQL file " + this.outputFilename, Level.INFO);
        // Read JSON file from disk and process it
        FileUtility fileUtil = new FileUtility();
        String jsonString = fileUtil.readFileIntoString(this.inputFilename);
        String sqlString = convertSingleJSONStringToSQLString(jsonString);
        // Write to file
        fileUtil.writeStringToFile(sqlString, this.outputFilename);
        // Perform validation and append results to log
        SQLValidator validator = new SQLValidator();
        String validationResult = validator.validateStandardSetWithDupeChecking(
                rootDBTable, nestedTablesComplexTypes, nestedTablesSimpleArrays);
        logger.log(validationResult, Level.INFO);
        // Finally, close log
        logger.closeLog();
    }

    /**
     * Converts a single Mongoose schema definition file to a single SQL script
     * that can then be reverse-engineered into Erwin. Results are written to
     * logfile. Also, QA is performed, and resulting cautionary notes are
     * written to the logfile.
     *
     * @param inputFile the input Mongoose schema file name (including path)
     * @param outputFile the output SQL file name (including path)
     * @param logfile the output log file name (including path)
     * @throws Exception if problem occurs
     */
    public void convertSingleMongooseFileToSQLFile(String inputFile, String outputFile, String logfile)
            throws Exception {
        // Initial setup and logging
        setup(inputFile, outputFile, null, null, logfile);
        writeInitialLogEntry(Thread.currentThread().getStackTrace()[1].getMethodName());
        logger.log("Reading from Mongoose file " + this.inputFilename, Level.INFO);
        logger.log("Writing to SQL file " + this.outputFilename, Level.INFO);
        // Read Mongoose file from disk and process it
        MongooseFileUtility fileUtil = new MongooseFileUtility();
        String jsonString = fileUtil.convertMongooseFileToJSONString(inputFilename);
        String sqlString = convertSingleJSONStringToSQLString(jsonString);
        fileUtil.writeStringToFile(sqlString, this.outputFilename);
        // Perform validation and append results to log
        SQLValidator validator = new SQLValidator();
        String validationResult = validator.validateStandardSetWithDupeChecking(
                rootDBTable, nestedTablesComplexTypes, nestedTablesSimpleArrays);
        logger.log(validationResult, Level.INFO);
        // Finally, close log
        logger.closeLog();
    }

    /**
     * Converts a single Mongoose schema definition file into one or more Java
     * JPA boilerplate files that contain variable definitions.
     *
     * @param inputFile the input Mongoose schema file name (including path)
     * @param outputDirectory the output directory in which to write the .java
     * files
     * @param logfile the output log file name (including path)
     * @throws Exception if problem occurs
     */
    public void convertSingleMongooseFileToJPAFiles(String inputFile, String outputDirectory, String logfile)
            throws Exception {
        // Initial setup and logging
        setup(inputFile, null, null, outputDirectory, logfile);
        writeInitialLogEntry(Thread.currentThread().getStackTrace()[1].getMethodName());
        logger.log("Reading from Mongoose file " + this.inputFilename, Level.INFO);
        logger.log("Writing JPA java files to directory " + this.outputDirectoryMultipleFiles, Level.INFO);
        // Read Mongoose file from disk, process into Data Objects and DBTables
        MongooseFileUtility fileUtil = new MongooseFileUtility();
        String jsonString = fileUtil.convertMongooseFileToJSONString(this.inputFilename);
        rootDataObject = parseJSONIntoDataObject(jsonString, rootDataObject);
        genRootAndNestedDBTables(rootDataObject);
        // Write out the Java JPA Files
        writeJPAFiles();
        // Finally, close log
        logger.closeLog();
    }

    /**
     * Converts multiple Mongoose schema definition files into a single SQL
     * script that can then be reverse-engineered into Erwin. Results are
     * written to logfile. Also, QA is performed, and resulting cautionary notes
     * are written to the logfile.
     *
     * @param inputDirectory the directory that contains the Mongoose files,
     * which MUST have a .js file extension to be processed.
     * @param outputFile the output SQL file name (including path)
     * @param logfile the output log file name (including path)
     * @throws Exception if problem occurs
     */
    public void convertMultiMongooseFilesToSQLFile(
            String inputDirectory, String outputFile, String logfile)
            throws Exception {
        // Initial setup and logging
        setup(null, outputFile, inputDirectory, null, logfile);
        writeInitialLogEntry(Thread.currentThread().getStackTrace()[1].getMethodName());
        logger.log("Reading Mongoose .js files from directory " + this.inputDirectoryMultipleFiles, Level.INFO);
        logger.log("Writing to SQL file " + this.outputFilename, Level.INFO);
        ArrayList<String> filenamesSuccessful = new ArrayList<String>();
        ArrayList<String> filenamesFailed = new ArrayList<String>();
        StringBuilder bigSQLBuilder = new StringBuilder();
        // Read Mongoose files from disk and process them
        MongooseFileUtility fileUtil = new MongooseFileUtility();
        ArrayList<String> filenameList = fileUtil.getFilesnamesFromDirectory(this.inputDirectoryMultipleFiles, ".js");

        if (filenameList.size() > 0) {
            HashMap<String, Integer> tableNamesMap = new HashMap<>();
            for (String filename : filenameList) {
                try {
                    resetSQLStuff();
                    logger.log("Processing file " + filename, Level.INFO);
                    // Run the conversion and add the result to the big SQL StringBuilder
                    String jsonString = fileUtil.convertMongooseFileToJSONString(filename);
                    String sqlString = convertSingleJSONStringToSQLString(jsonString);
                    bigSQLBuilder.append(sqlString);
                    // Validate it
                    SQLValidator validator = new SQLValidator();
                    String validationResult = validator.validateStandardSet(
                            rootDBTable, nestedTablesComplexTypes, nestedTablesSimpleArrays);
                    logger.log(validationResult, Level.INFO);
                    // Add table names to big overall list for final dupe table name check 
                    tableNamesMap.merge(
                            rootDBTable.getTableName().toUpperCase(), 1, Integer::sum);

                    for (DBTable x : nestedTablesComplexTypes) {
                        tableNamesMap.merge(
                                x.getTableName().toUpperCase(), 1, Integer::sum);
                    }
                    for (DBTable y : nestedTablesSimpleArrays) {
                        tableNamesMap.merge(
                                y.getTableName().toUpperCase(), 1, Integer::sum);
                    }
                    filenamesSuccessful.add(filename);
                } catch (Exception e) {
                    filenamesFailed.add(filename);
                    logger.log("ALERT: Unable to process file " + filename + "..." + e.getMessage(), Level.SEVERE);
                }
            }
            // Write the big SQL String out to the output file
            fileUtil.writeStringToFile(bigSQLBuilder.toString(), outputFilename);
            // Write summary to log 
            logger.log("Files successfully processed:", Level.INFO);
            for (String s : filenamesSuccessful) {
                logger.log(String.format("...%s", s), Level.INFO);
            }
            logger.log("Files that failed:", Level.INFO);
            for (String f : filenamesFailed) {
                logger.log(String.format("...%s", f), Level.INFO);
            }
            // Do final Validation check for dupe table names, write results to log 
            SQLValidator dupeCheckValidator = new SQLValidator();
            String dupeCheck = dupeCheckValidator.checkForDupeTableNames(tableNamesMap);
            logger.log(dupeCheck, Level.INFO);
        } else {
            logger.log(String.format(
                    "No files found in specified directory %s", this.inputDirectoryMultipleFiles), Level.WARNING);
        }
        // Finally, close log
        logger.closeLog();
    }

    /**
     * Connects to the specified MongoDB server, queries the specified
     * collection (in the specified database) for a single record, then builds
     * out a SQL script that creates database tables, which can then be
     * reverse-engineered into Erwin.
     *
     * @param connectionString
     * @param databaseName
     * @param collectionName
     * @param outputFilename
     * @param logfile
     * @param username
     * @param password
     * @throws Exception
     */
    public void convertSingleMongoDBCollectionToSQLFile(String connectionString, String databaseName,
            String collectionName, String outputFilename, String logfile,
            String username, String password)
            throws Exception {

        // Initial setup and logging
        setup(null, outputFilename, null, null, logfile);
        writeInitialLogEntry(Thread.currentThread().getStackTrace()[1].getMethodName());
        logger.log(String.format("Will connect to MongoDB server %s, database %s" + lfChar, connectionString, databaseName), Level.INFO);
        logger.log(String.format("Will read from MongoDB collection %s" + lfChar, collectionName), Level.INFO);
        logger.log(String.format("Writing SQL file %s" + lfChar, this.outputFilename), Level.INFO);

        FileUtility fileUtil = new FileUtility();
        MongoDBUtility mongoDBUtil = new MongoDBUtility();
        String jsonString
                = mongoDBUtil.getOneDocBuildJSONString(connectionString, databaseName, collectionName, username, password);
        String sqlString = convertSingleJSONStringToSQLString(jsonString);
        // Write to file
        fileUtil.writeStringToFile(sqlString, this.outputFilename);
        // Perform validation and append results to log
        SQLValidator validator = new SQLValidator();
        String validationResult = validator.validateStandardSetWithDupeChecking(
                rootDBTable, nestedTablesComplexTypes, nestedTablesSimpleArrays);
        logger.log(validationResult, Level.INFO);
        // Finally, close log
        logger.closeLog();
    }

    /**
     * Connects to the specified MongoDB server, queries the specified
     * collection (in the specified database) for a single record, then builds
     * out a schema description of the collection's record structure, in a JSON
     * format.
     *
     * @param connectionString
     * @param databaseName
     * @param collectionName
     * @param outputFilename
     * @param logfile
     * @throws Exception
     */
    public void convertSingleMongoDBCollectionToJSONFile(String connectionString, String databaseName,
            String collectionName, String outputFilename, String logfile, String username, String password)
            throws Exception {
        // Initial setup and logging
        setup(null, outputFilename, null, null, logfile);
        writeInitialLogEntry(Thread.currentThread().getStackTrace()[1].getMethodName());
        logger.log(String.format("Will connect to MongoDB server %s, database %s" + lfChar, connectionString, databaseName), Level.INFO);
        logger.log(String.format("Writing JSON file %s" + lfChar, this.outputFilename), Level.INFO);
        FileUtility fileUtil = new FileUtility();
        MongoDBUtility mongoDBUtil = new MongoDBUtility();
        String jsonString
                = mongoDBUtil.getOneDocBuildJSONString(connectionString, databaseName, collectionName, username, password);
        fileUtil.writeStringToFile(jsonString, this.outputFilename);
        // Finally, close log
        logger.closeLog();
    }

    /**
     * Connects to the specified MongoDB server, queries the specified
     * collection (in the specified database) for a single record, then builds
     * out a schema description of the collection's record structure, in the
     * form of one or more boilerplate Java Persistence API (JPA) Java classes.
     *
     * @param connectionString
     * @param databaseName
     * @param collectionName
     * @param outputDirectory
     * @param logfile
     * @param username
     * @param password
     * @throws Exception
     */
    public void convertSingleMongoDBCollectionToJPAFiles(String connectionString, String databaseName,
            String collectionName, String outputDirectory, String logfile, String username, String password)
            throws Exception {
        // Initial setup and logging
        setup(null, null, null, outputDirectory, logfile);
        writeInitialLogEntry(Thread.currentThread().getStackTrace()[1].getMethodName());
        logger.log(String.format("Will connect to MongoDB server %s, database %s" + lfChar, connectionString, databaseName), Level.INFO);
        logger.log(String.format("Writing JPA java files to directory %s" + lfChar, this.outputDirectoryMultipleFiles), Level.INFO);
        MongoDBUtility mongoDBUtil = new MongoDBUtility();
        String jpaString
                = mongoDBUtil.getOneDocBuildJSONStringWithJPADatatypes(connectionString, databaseName, collectionName,
                        username, password);
        rootDataObject = parseJSONIntoDataObject(jpaString, rootDataObject);
        genRootAndNestedDBTables(rootDataObject);
        // Write out the Java JPA Files
        writeJPAFiles();
        // Finally, close log
        logger.closeLog();
    }

    /**
     * Connects to the specified MongoDB server, queries the specified
     * collection (in the specified database) for a single record, then builds
     * out a schema description of the collection's record structure, in a
     * Mongoose schema definition format.
     *
     * @param connectionString
     * @param databaseName
     * @param collectionName
     * @param outputFilename
     * @param logfile
     * @param username
     * @param password
     * @throws Exception
     */
    public void convertSingleMongoDBCollectionToMongooseFile(String connectionString, String databaseName,
            String collectionName, String outputFilename, String logfile,
            String username, String password) throws Exception {
        // Initial setup and logging
        setup(null, outputFilename, null, null, logfile);
        writeInitialLogEntry(Thread.currentThread().getStackTrace()[1].getMethodName());
        logger.log(String.format("Will connect to MongoDB server %s, database %s" + lfChar, connectionString, databaseName), Level.INFO);
        logger.log(String.format("Writing Mongoose file %s" + lfChar, this.outputFilename), Level.INFO);
        FileUtility fileUtil = new FileUtility();
        MongoDBUtility mongoDBUtil = new MongoDBUtility();
        String mongooseString
                = mongoDBUtil.getOneDocBuildMongooseString(connectionString, databaseName, collectionName, username, password);
        fileUtil.writeStringToFile(mongooseString, this.outputFilename);
        // Finally, close log
        logger.closeLog();
    }

    /**
     * Connects to the specified MongoDB server, queries the specified
     * collection (in the specified database) for a single record, then builds
     * out a script containing MongoDB collMod statement to create MongoDB
     * Validation for that collection, based on the contents and format of the
     * record queried. That script can then be run from the Mongo shell to
     * create the Validator for that collection. (NOTE: it will initially delete
     * any existing Validator before creating the new one).
     *
     * @param connectionString
     * @param databaseName
     * @param collectionName
     * @param outputFilename
     * @param logfile
     * @param username
     * @param password
     * @throws Exception
     */
    public void convertSingleMongoDBCollectionToMongoDBValidator(String connectionString, String databaseName,
            String collectionName, String outputFilename, String logfile, String username, String password)
            throws Exception {
        // Initial setup and logging
        setup(null, outputFilename, null, null, logfile);
        writeInitialLogEntry(Thread.currentThread().getStackTrace()[1].getMethodName());
        logger.log(String.format("Will connect to MongoDB server %s, database %s" + lfChar, connectionString, databaseName), Level.INFO);
        logger.log(String.format("Writing Validator text file %s" + lfChar, this.outputFilename), Level.INFO);
        FileUtility fileUtil = new FileUtility();
        MongoDBUtility mongoDBUtil = new MongoDBUtility();
        String validatorString
                = mongoDBUtil.getOneDocBuildValidatorString(connectionString, databaseName, collectionName, username, password);
        fileUtil.writeStringToFile(validatorString, this.outputFilename);
        // Finally, close log
        logger.closeLog();
    }

    /**
     * Connects to the specified server and the specified database. Grabs a list
     * of all the collection (i.e. table) names for that database. Loops through
     * the collections and generates JSON schema-def files for each of the
     * collections. These scripts will contain MongoDB $ref items, if found in
     * the DB. In addition, log file will list out all the collections found to
     * have $ref items in them.
     *
     * @param connectionString
     * @param databaseName
     * @param outputDirectory
     * @param logfile
     * @param username
     * @param password
     * @throws Exception
     */
    public void convertMultiMongoDBCollectionsToJSONFiles(String connectionString, String databaseName,
            String outputDirectory, String logfile, String username, String password)
            throws Exception {
        // Initial setup and logging
        setup(null, null, null, outputDirectory, logfile);
        writeInitialLogEntry(Thread.currentThread().getStackTrace()[1].getMethodName());
        logger.log(String.format("Will connect to MongoDB server %s, database %s" + lfChar, connectionString, databaseName), Level.INFO);
        logger.log(String.format("Writing JSON files to directory %s" + lfChar, this.outputDirectoryMultipleFiles), Level.INFO);

        ArrayList<String> collectionsSuccessful = new ArrayList<String>();
        ArrayList<String> collectionsFailed = new ArrayList<String>();
        ArrayList<String> collectionswithMongoDBRef = new ArrayList<String>();

        FileUtility fileUtil = new FileUtility();
        MongoDBUtility mongoDBUtil = new MongoDBUtility();

        // Get list of MongoDB Collection Names
        List<String> collectionNames = mongoDBUtil.getCollectionNames(connectionString, databaseName, username, password);
        // Loop through the list of Collection Names and process
        if (collectionNames.size() > 0) {
            for (String collectionName : collectionNames) {
                if (!collectionName.equalsIgnoreCase("system.profile")) {
                    try {
                        String jsonString
                                = mongoDBUtil.getOneDocBuildJSONString(connectionString, databaseName, collectionName,
                                        username, password);
                        String outputFilename = this.outputDirectoryMultipleFiles + "/" + collectionName + ".json";
                        fileUtil.writeStringToFile(jsonString, outputFilename);
                        collectionsSuccessful.add(collectionName);
                        logger.log(String.format(
                                "Successfully generated JSON file %s for MongoDB collection %s", outputFilename, collectionName), Level.INFO);
                        if (jsonString.contains("$ref")) {
                            collectionswithMongoDBRef.add(collectionName);
                            logger.log(String.format("Collection %s contains at least one MongoDB $ref item", collectionName), Level.INFO);
                        }
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                        collectionsFailed.add(collectionName);
                        logger.log(String.format("ALERT: Unable to generate JSON file from MongoDB collection %s ... %s", collectionName, e.getMessage()), Level.SEVERE);
                    }
                } else {
                    logger.log(String.format("Ignoring %s collection", collectionName), Level.INFO);
                }
            }
            // Write summary info to log 
            logger.log("Collections successfully processed:", Level.INFO);
            for (String s : collectionsSuccessful) {
                logger.log(String.format("...%s", s), Level.INFO);
            }
            logger.log("Collections that failed:", Level.INFO);
            for (String f : collectionsFailed) {
                logger.log(String.format("...%s", f), Level.INFO);
            }
            if (collectionsFailed.size() == 0) {
                logger.log(String.format("...No collections failed...AWESOME!"), Level.INFO);
            }
            logger.log("Collections that contain at least one MongoDB $ref item", Level.INFO);
            for (String r : collectionswithMongoDBRef) {
                logger.log(String.format("...%s", r), Level.INFO);
            }
            if (collectionswithMongoDBRef.size() == 0) {
                logger.log(String.format("...No collections found to contain MongoDB $ref items."), Level.INFO);
            }
        } else { // No collections found for that database!
            logger.log(String.format("No MongoDB collections found on specified server %s, database %s", connectionString, databaseName), Level.SEVERE);
        }
        // Finally, close log
        logger.closeLog();
    }

    /**
     * Connects to the specified server and the specified database. Grabs a list
     * of all the collection (i.e. table) names for that database. Loops through
     * the collections and generates SINGLE JSON schema def file for all of the
     * collections. These scripts will contain MongoDB $ref items, if found in
     * the DB. In addition, log file will list out all the collections found to
     * have $ref items in them.
     *
     * @param connectionString
     * @param databaseName
     * @param outputFilename
     * @param logfile
     * @param username
     * @param password
     * @throws Exception
     */
    public void convertMultiMongoDBCollectionsToJSONFile(String connectionString, String databaseName,
            String outputFilename, String logfile, String username, String password) throws Exception {
        // Initial setup and logging
        setup(null, outputFilename, null, null, logfile);
        writeInitialLogEntry(Thread.currentThread().getStackTrace()[1].getMethodName());
        logger.log(String.format("Will connect to MongoDB server %s, database %s" + lfChar, connectionString, databaseName), Level.INFO);
        logger.log(String.format("Writing single JSON file %s" + lfChar, this.outputFilename), Level.INFO);

        ArrayList<String> collectionsSuccessful = new ArrayList<String>();
        ArrayList<String> collectionsFailed = new ArrayList<String>();
        ArrayList<String> collectionswithMongoDBRef = new ArrayList<String>();

        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("{ " + lfChar + quoteStr("name") + ": " + quoteStr(databaseName) + ","
                + lfChar + quoteStr("collections") + ": [" + lfChar);

        FileUtility fileUtil = new FileUtility();
        MongoDBUtility mongoDBUtil = new MongoDBUtility();

        // Get list of MongoDB Collection Names
        List<String> collectionNames = mongoDBUtil.getCollectionNames(connectionString, databaseName, username, password);

        // Loop through the list of Collection Names and process
        if (collectionNames.size() > 0) {
            for (String collectionName : collectionNames) {
                if (!collectionName.equalsIgnoreCase("system.profile")) {
                    try {
                        String jsonString
                                = mongoDBUtil.getOneDocBuildJSONString(connectionString, databaseName, collectionName,
                                        username, password);

                        stringBuilder.append(jsonString.substring(0, jsonString.length() - 2));

                        stringBuilder.append("," + lfChar);
                        collectionsSuccessful.add(collectionName);
                        logger.log(String.format(
                                "Successfully generated JSON file %s for MongoDB collection %s", outputFilename, collectionName), Level.INFO);
                        if (jsonString.contains("$ref")) {
                            collectionswithMongoDBRef.add(collectionName);
                            logger.log(String.format("Collection %s contains at least one MongoDB $ref item", collectionName), Level.INFO);
                        }
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                        collectionsFailed.add(collectionName);
                        logger.log(String.format("ALERT: Unable to generate JSON file from MongoDB collection %s ... %s", collectionName, e.getMessage()), Level.SEVERE);
                    }
                } else {
                    logger.log(String.format("Ignoring %s collection", collectionName), Level.INFO);
                }
            }
            // Finished looping through collections...now delete extra characters and append overall footer
            stringBuilder.delete(stringBuilder.length() - 3, stringBuilder.length() - 1);
            stringBuilder.append("]" + lfChar + "}" + lfChar);

            // Write summary info to log 
            logger.log("Collections successfully processed:", Level.INFO);
            for (String s : collectionsSuccessful) {
                logger.log(String.format("...%s", s), Level.INFO);
            }
            logger.log("Collections that failed:", Level.INFO);
            for (String f : collectionsFailed) {
                logger.log(String.format("...%s", f), Level.INFO);
            }
            if (collectionsFailed.size() == 0) {
                logger.log(String.format("...No collections failed...AWESOME!"), Level.INFO);
            }
            logger.log("Collections that contain at least one MongoDB $ref item", Level.INFO);
            for (String r : collectionswithMongoDBRef) {
                logger.log(String.format("...%s", r), Level.INFO);
            }
            if (collectionswithMongoDBRef.size() == 0) {
                logger.log(String.format("...No collections found to contain MongoDB $ref items."), Level.INFO);
            }
            // Write the big SQL String out to the output file
            String bigString = stringBuilder.toString();
            //bigJson = bigJson.replace(bigJson.substring(bigJson.length() - 1), "");
            //bigString = bigString.substring(0, bigString.length() - 4);
            fileUtil.writeStringToFile(bigString, outputFilename);
        } else { // No collections found for that database!
            logger.log(String.format("No MongoDB collections found on specified server %s, database %s", connectionString, databaseName), Level.SEVERE);
        }
        // Finally, close log
        logger.closeLog();
    }

    /**
     * Connects to the specified server and the specified database. Grabs a list
     * of all the collection (i.e. table) names for that database. Loops through
     * the collections and generates MongoDB Validator scripts for each of the
     * collections. Scripts will have naming convention of
     * collectionNameValidator.js. These scripts can then be run from the Mongo
     * shell to create the Validators for those collections. (NOTE: each script
     * will initially delete any existing Validator before creating the new one
     * for the collection). NOTE: system.profile collection will NOT be
     * processed.
     *
     * @param connectionString
     * @param databaseName
     * @param outputDirectory
     * @param logfile
     * @param username
     * @param password
     * @throws Exception
     */
    public void convertMultiMongoDBCollectionsToMongoDBValidatorFiles(String connectionString, String databaseName,
            String outputDirectory, String logfile, String username, String password)
            throws Exception {
        // Initial setup and logging
        setup(null, null, null, outputDirectory, logfile);
        writeInitialLogEntry(Thread.currentThread().getStackTrace()[1].getMethodName());
        logger.log(String.format("Will connect to MongoDB server %s, database %s" + lfChar, connectionString, databaseName), Level.INFO);
        logger.log(String.format("Writing Validator files to directory %s" + lfChar, this.outputDirectoryMultipleFiles), Level.INFO);
        ArrayList<String> collectionsSuccessful = new ArrayList<String>();
        ArrayList<String> collectionsFailed = new ArrayList<String>();
        FileUtility fileUtil = new FileUtility();
        MongoDBUtility mongoDBUtil = new MongoDBUtility();
        // Get list of MongoDB Collection Names
        List<String> collectionNames = mongoDBUtil.getCollectionNames(connectionString, databaseName, username, password);
        // Loop through the list of Collection Names and process
        if (collectionNames.size() > 0) {
            for (String collectionName : collectionNames) {
                if (!collectionName.equalsIgnoreCase("system.profile")) {
                    try {
                        String validatorString
                                = mongoDBUtil.getOneDocBuildValidatorString(connectionString, databaseName, collectionName,
                                        username, password);
                        String outputFilename = this.outputDirectoryMultipleFiles + "/" + collectionName + "Validator.js";
                        fileUtil.writeStringToFile(validatorString, outputFilename);
                        collectionsSuccessful.add(collectionName);
                        logger.log(String.format(
                                "Successfully generated Validator file %s for MongoDB collection %s", outputFilename, collectionName), Level.INFO);
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                        collectionsFailed.add(collectionName);
                        logger.log(String.format("ALERT: Unable to generate Validator script from MongoDB collection %s ... %s", collectionName, e.getMessage()), Level.SEVERE);
                    }
                } else {
                    logger.log(String.format("Ignoring %s collection", collectionName), Level.INFO);
                }
            }
            // Write summary info to log 
            logger.log("Collections successfully processed:", Level.INFO);
            for (String s : collectionsSuccessful) {
                logger.log(String.format("...%s", s), Level.INFO);
            }
            logger.log("Collections that failed:", Level.INFO);
            for (String f : collectionsFailed) {
                logger.log(String.format("...%s", f), Level.INFO);
            }
            if (collectionsFailed.size() == 0) {
                logger.log(String.format("...No collections failed...AWESOME!"), Level.INFO);
            }
        } else { // No collections found for that database!
            logger.log(String.format("No MongoDB collections found on specified server %s, database %s", connectionString, databaseName), Level.SEVERE);
        }
        // Finally, close log
        logger.closeLog();
    }

    /**
     * Connects to the specified server and the specified database. Grabs a list
     * of all the collection (i.e. table) names for that database. Loops through
     * the collections and generates a single, big MongoDB Validator script that
     * includes the Validator code for ALL of the collections. Scripts will have
     * naming convention of collectionNameValidator.js. These scripts can then
     * be run from the Mongo shell to create the Validators for those
     * collections. (NOTE: each script will initially delete any existing
     * Validator before creating the new one for the collection).
     *
     * NOTE: system.profile collection will NOT be processed.
     *
     * @param connectionString
     * @param databaseName
     * @param outputFilename
     * @param logfile
     * @param username
     * @param password
     * @throws Exception
     */
    public void convertMultiMongoDBCollectionsToMongoDBValidatorFile(String connectionString, String databaseName,
            String outputFilename, String logfile, String username, String password)
            throws Exception {
        // Initial setup and logging
        setup(null, outputFilename, null, null, logfile);
        writeInitialLogEntry(Thread.currentThread().getStackTrace()[1].getMethodName());
        logger.log(String.format("Will connect to MongoDB server %s, database %s" + lfChar, connectionString, databaseName), Level.INFO);
        logger.log(String.format("Writing single, big Validator file %s" + lfChar, this.outputFilename), Level.INFO);
        ArrayList<String> collectionsSuccessful = new ArrayList<String>();
        ArrayList<String> collectionsFailed = new ArrayList<String>();
        StringBuilder bigValidatorBuilder = new StringBuilder();
        FileUtility fileUtil = new FileUtility();
        MongoDBUtility mongoDBUtil = new MongoDBUtility();
        // Get list of MongoDB Collection Names
        List<String> collectionNames = mongoDBUtil.getCollectionNames(connectionString, databaseName, username, password);
        // Loop through the list of Collection Names and process
        if (collectionNames.size() > 0) {
            for (String collectionName : collectionNames) {
                if (!collectionName.equalsIgnoreCase("system.profile")) {
                    try {
                        String validatorString
                                = mongoDBUtil.getOneDocBuildValidatorString(connectionString, databaseName, collectionName,
                                        username, password);
                        bigValidatorBuilder.append(validatorString + lfChar + lfChar + lfChar);
                        collectionsSuccessful.add(collectionName);
                        logger.log(String.format(
                                "Successfully generated Validator code for MongoDB collection %s", collectionName), Level.INFO);
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                        collectionsFailed.add(collectionName);
                        logger.log(String.format("ALERT: Unable to generate Validator code from MongoDB collection %s ... %s", collectionName, e.getMessage()), Level.SEVERE);
                    }
                } else {
                    logger.log(String.format("Ignoring %s collection", collectionName), Level.INFO);
                }
            }
            // Write the big SQL String out to the output file
            fileUtil.writeStringToFile(bigValidatorBuilder.toString(), this.outputFilename);
            // Write summary info to log 
            logger.log("Collections successfully processed:", Level.INFO);
            for (String s : collectionsSuccessful) {
                logger.log(String.format("...%s", s), Level.INFO);
            }
            logger.log("Collections that failed:", Level.INFO);
            for (String f : collectionsFailed) {
                logger.log(String.format("...%s", f), Level.INFO);
            }
            if (collectionsFailed.size() == 0) {
                logger.log(String.format("...No collections failed...AWESOME!"), Level.INFO);
            }
        } else { // No collections found for that database!
            logger.log(String.format("No MongoDB collections found on specified server %s, database %s", connectionString, databaseName), Level.SEVERE);
        }
        // Finally, close log
        logger.closeLog();
    }

    /**
     * Connects to the specified server and the specified database. Grabs a
     * list of all the collection (i.e. table) names for that database. Loops
     * through the collections and generates SQL for each one. Writes SQL into a
     * big SQL script that can be reverse-engineered into Erwin. Performs QA on
     * the SQL and records results in the log.
     *
     * NOTE: system.profile collection will NOT be processed.
     *
     * @param connectionString
     * @param databaseName
     * @param outputFilename
     * @param logfile
     * @param username
     * @param password
     * @throws Exception
     */
    public void convertMultiMongoDBCollectionsToSQLFile(String connectionString, String databaseName,
            String outputFilename, String logfile, String username, String password) throws Exception {
        // Initial setup and logging
        setup(null, outputFilename, null, null, logfile);
        writeInitialLogEntry(Thread.currentThread().getStackTrace()[1].getMethodName());
        logger.log(String.format("Will connect to MongoDB server %s, database %s" + lfChar, connectionString, databaseName), Level.INFO);
        logger.log(String.format("Writing SQL file %s" + lfChar, this.outputFilename), Level.INFO);
        ArrayList<String> collectionsSuccessful = new ArrayList<String>();
        ArrayList<String> collectionsFailed = new ArrayList<String>();
        ArrayList<String> collectionswithMongoDBRef = new ArrayList<String>();

        StringBuilder bigSQLBuilder = new StringBuilder();
        FileUtility fileUtil = new FileUtility();
        MongoDBUtility mongoDBUtil = new MongoDBUtility();
        // Get list of MongoDB Collection Names
        List<String> collectionNames = mongoDBUtil.getCollectionNames(connectionString, databaseName,
                username, password);
        // Loop through the list of Collection Names and process
        if (collectionNames.size() > 0) {
            HashMap<String, Integer> tableNamesMap = new HashMap<>();
            for (String collectionName : collectionNames) {
                if (!collectionName.equalsIgnoreCase("system.profile")) {
                    try {
                        resetSQLStuff();
                        logger.log(String.format("Processing collection %s", collectionName), Level.SEVERE);
                        String jsonString
                                = mongoDBUtil.getOneDocBuildJSONString(connectionString, databaseName, collectionName,
                                        username, password);
                        String sqlString = convertSingleJSONStringToSQLString(jsonString);
                        if (sqlString.contains("$ref")) {
                            collectionswithMongoDBRef.add(collectionName);
                            logger.log(String.format("Collection %s, or nested/child collection, contains at least one MongoDB $ref item",
                                    collectionName), Level.INFO);
                        }
                        // Append the just-generated SQL to the big, overall SQL
                        bigSQLBuilder.append(sqlString);
                        // Validate the SQL just generated, append validation result to the log
                        SQLValidator validator = new SQLValidator();
                        String validationResult = validator.validateStandardSet(rootDBTable, nestedTablesComplexTypes, nestedTablesSimpleArrays);
                        logger.log(validationResult, Level.INFO);
                        // Add table names to big overall list for final dupe table name check
                        tableNamesMap.merge(rootDBTable.getTableName().toUpperCase(), 1, Integer::sum);
                        for (DBTable x : nestedTablesComplexTypes) {
                            tableNamesMap.merge(
                                    x.getTableName().toUpperCase(), 1, Integer::sum);
                        }
                        for (DBTable y : nestedTablesSimpleArrays) {
                            tableNamesMap.merge(
                                    y.getTableName().toUpperCase(), 1, Integer::sum);
                        }
                        // Add this collection name to list of those successfully processed
                        collectionsSuccessful.add(collectionName);
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                        collectionsFailed.add(collectionName);
                        logger.log(String.format("ALERT: Unable to generate SQL from MongoDB collection %s ... %s", collectionName, e.getMessage()), Level.SEVERE);
                    }
                } else {
                    logger.log(String.format("Ignoring %s collection", collectionName), Level.INFO);
                }
            }
            // Write the big SQL String out to the output file
            fileUtil.writeStringToFile(bigSQLBuilder.toString(), outputFilename);
            // Write summary info to log 
            logger.log("Collections successfully processed:", Level.INFO);
            for (String s : collectionsSuccessful) {
                logger.log(String.format("...%s", s), Level.INFO);
            }
            logger.log(lfChar + "Collections that failed:", Level.INFO);
            for (String f : collectionsFailed) {
                logger.log(String.format("...%s", f), Level.INFO);
            }
            if (collectionsFailed.size() == 0) {
                logger.log(String.format("...No collections failed...AWESOME!"), Level.INFO);
            }
            logger.log(lfChar + "Collections that contain at least one MongoDB $ref item", Level.INFO);
            for (String r : collectionswithMongoDBRef) {
                logger.log(String.format("...%s", r), Level.INFO);
            }
            if (collectionswithMongoDBRef.size() == 0) {
                logger.log(String.format("...No collections found to contain MongoDB $ref items."), Level.INFO);
            }
            // Do final Validation check for dupe table names, append results to log 
            SQLValidator dupeCheckValidator = new SQLValidator();
            String dupeCheck = dupeCheckValidator.checkForDupeTableNames(tableNamesMap);
            logger.log(dupeCheck, Level.INFO);
        } else { // No collections found for that database!
            logger.log(String.format("No MongoDB collections found on specified server %s, database %s", connectionString, databaseName), Level.SEVERE);
        }
        // Finally, close log
        logger.closeLog();
    }
}
