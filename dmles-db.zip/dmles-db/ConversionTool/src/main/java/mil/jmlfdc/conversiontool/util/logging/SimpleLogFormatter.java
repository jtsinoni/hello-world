package mil.jmlfdc.conversiontool.util.logging;

import java.util.logging.Formatter;
import java.util.logging.LogRecord;

/**
 * Class that provides very simple log formatting
 *
 */
class SimpleLogFormatter extends Formatter {

    private String lfChar;
    private static final String OPERATING_SYSTEM = System.getProperty("os.name");

    @Override
    public String format(LogRecord record) {
        if (OPERATING_SYSTEM.startsWith("Window") || OPERATING_SYSTEM.startsWith("WINDOW")) {
            lfChar = "\r\n";
        } else {
            lfChar = "\n";
        }
        StringBuilder sb = new StringBuilder();
        sb.append(record.getMessage());
        sb.append(lfChar);
        return sb.toString();
    }
}
