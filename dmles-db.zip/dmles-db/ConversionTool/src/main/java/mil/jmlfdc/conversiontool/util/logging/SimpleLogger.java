package mil.jmlfdc.conversiontool.util.logging;

import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Handler;
import java.util.logging.Logger;
import java.util.logging.Level;

/**
 * Class that provides very simple logging
 *
 */
public class SimpleLogger {

    private static final String OPERATING_SYSTEM = System.getProperty("os.name");
    private static final Logger LOGGER = Logger.getLogger(SimpleLogger.class.getName());
    private Handler fileHandler;
    private String defaultFilename = "C:\\Workspace\\FileWork\\mongoose_conversion_demo\\conversionWork.log";
    private String lfChar;

    /**
     * Constructor that takes in logfile name (including path)
     *
     * @param logfileName the logfile name (including path)
     */
    public SimpleLogger(String logfileName) {
        try {
            boolean append = false;
            String filename;

            if (logfileName == null || logfileName == "") {
                filename = defaultFilename;
            } else {
                filename = logfileName;
            }
            fileHandler = new FileHandler(logfileName, append);
            LOGGER.addHandler(fileHandler);
            fileHandler.setFormatter(new SimpleLogFormatter());
            fileHandler.setLevel(Level.ALL);

            if (OPERATING_SYSTEM.startsWith("Window") || OPERATING_SYSTEM.startsWith("WINDOW")) {
                lfChar = "\r\n";
            } else {
                lfChar = "\n";
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

    public void log(String logMessage, Level level) {
        LOGGER.log(level, logMessage + lfChar);
    }

    public void closeLog() {
        fileHandler.close();
    }
}
