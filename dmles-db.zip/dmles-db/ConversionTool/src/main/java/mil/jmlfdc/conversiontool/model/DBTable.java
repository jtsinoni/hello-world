package mil.jmlfdc.conversiontool.model;

import java.util.ArrayList;

/**
 * Class that models a database table, derived from a DataObject, and from which
 * SQL will be generated.
 *
 */
public class DBTable {

    private String tableName;
    private String parentTableName;
    private ArrayList<String> columnNames;
    private ArrayList<String> dataTypes;
    private ArrayList<String> JPADataTypes;
    private Boolean SQLBuilt;  // Indicator of whether SQL String has been built for this DBTable yet

    /**
     * No argument constructor
     */
    public void DBTable() {
        this.setSQLBuilt(Boolean.FALSE);
    }

    /**
     * Constructor that takes in table name
     *
     * @param tableName the table name
     */
    public void DBTable(String tableName) {
        this.setTableName(tableName);
        this.setSQLBuilt(Boolean.FALSE);
    }

    /**
     * @return the tableName
     */
    public String getTableName() {
        return tableName;
    }

    /**
     * @param tableName the tableName to set
     */
    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    /**
     * @return the columnNames
     */
    public ArrayList<String> getColumnNames() {
        return columnNames;
    }

    /**
     * @param columnNames the columnNames to set
     */
    public void setColumnNames(ArrayList<String> columnNames) {
        this.columnNames = columnNames;
    }

    /**
     * @return the dataTypes
     */
    public ArrayList<String> getDataTypes() {
        return dataTypes;
    }

    /**
     * @param dataTypes the dataTypes to set
     */
    public void setDataTypes(ArrayList<String> dataTypes) {
        this.dataTypes = dataTypes;
    }

    /**
     * @return the parentTableName
     */
    public String getParentTableName() {
        return parentTableName;
    }

    /**
     * @param parentTableName the parentTableName to set
     */
    public void setParentTableName(String parentTableName) {
        this.parentTableName = parentTableName;
    }

    /**
     * @return the getJPADataTypes
     */
    public ArrayList<String> getJPADataTypes() {
        return JPADataTypes;
    }

    /**
     * @param JPADataTypes the getJPADataTypes to set
     */
    public void setJPADataTypes(ArrayList<String> JPADataTypes) {
        this.JPADataTypes = JPADataTypes;
    }

    /**
     * @return true/false of whether the SQL String has been built for this
     * DBTable
     */
    public Boolean isSQLBuilt() {
        return SQLBuilt;
    }

    /**
     * @param isBuilt the SQLBuilt to set
     */
    public void setSQLBuilt(Boolean isBuilt) {
        this.SQLBuilt = isBuilt;
    }
}
