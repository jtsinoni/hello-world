package mil.jmlfdc.conversiontool.model;

import com.fasterxml.jackson.databind.JsonNode;
import java.util.ArrayList;

/**
 * Class that models a JSON Object, from which a more SQL-friendly "DBTable"
 * object can then be created. Contains an ArrayList of DataObject, which allows
 * the ability to capture the nested JSON stuff.
 *
 */
public class DataObject {

    private String dataKey;  // the "key" in the "key/value" pair
    private JsonNode node;   // the complete JSON node
    private ArrayList<DataObject> members; // Member DataObjects, the result of nested nodes within JSON

    /**
     * Constructor that takes in the key only
     *
     * @param dataKey the key
     */
    public DataObject(String dataKey) {
        this.setDataKey(dataKey);
        this.setMembers(new ArrayList<DataObject>());
    }

    /**
     * Constructor that takes in the key and the JSON node
     *
     * @param dataKey the key
     * @param node the JSON node
     */
    public DataObject(String dataKey, JsonNode node) {
        this.setDataKey(dataKey);
        this.setNode(node);
        this.setMembers(new ArrayList<DataObject>());
    }

    /**
     * @return the dataKey
     */
    public String getDataKey() {
        return dataKey;
    }

    /**
     * @param dataKey the dataKey to set
     */
    public void setDataKey(String dataKey) {
        this.dataKey = dataKey;
    }

    /**
     * @return the members
     */
    public ArrayList<DataObject> getMembers() {
        return members;
    }

    /**
     * @param members the members to set
     */
    public void setMembers(ArrayList<DataObject> members) {
        this.members = members;
    }

    /**
     * @return the JSON node
     */
    public JsonNode getNode() {
        return node;
    }

    /**
     * @param node the JSON node to set
     */
    public void setNode(JsonNode node) {
        this.node = node;
    }
}
