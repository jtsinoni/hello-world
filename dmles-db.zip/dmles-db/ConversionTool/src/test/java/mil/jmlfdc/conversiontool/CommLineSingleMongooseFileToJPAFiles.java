package mil.jmlfdc.conversiontool;

import mil.jmlfdc.conversiontool.processor.Converter;

/**
 * Class to test, via command line, the
 * Converter.converSingleMongooseFileToJPAFiles method
 *
 */
public class CommLineSingleMongooseFileToJPAFiles {

    static String INPUT_FILENAME = "C:\\Workspace\\GitProjects\\dmles-gui\\app_api\\models\\equipmentRecordDetailModel.js";
    static String OUTPUT_DIRECTORY = "U:\\temp";
    static String LOG_FILENAME = "U:\\temp\\mongoose_to_jpa.log";

    public void runConversion() {
        try {
            Converter converter = new Converter();
            converter.convertSingleMongooseFileToJPAFiles(INPUT_FILENAME, OUTPUT_DIRECTORY, LOG_FILENAME);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public static void main(String args[]) {
        CommLineSingleMongooseFileToJPAFiles convert = new CommLineSingleMongooseFileToJPAFiles();
        convert.runConversion();
    }
}
