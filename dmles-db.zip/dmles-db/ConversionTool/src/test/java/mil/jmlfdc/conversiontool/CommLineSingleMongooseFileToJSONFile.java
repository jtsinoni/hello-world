package mil.jmlfdc.conversiontool;

import mil.jmlfdc.conversiontool.processor.Converter;

/**
 * Class to test, via command line, the
 * Converter.convertSingleMongooseFileToJSONFile method
 *
 */
public class CommLineSingleMongooseFileToJSONFile {

    static String INPUT_FILENAME = "C:\\Workspace\\GitProjects\\dmles-gui\\app_api\\models\\regionModel.js";
    static String OUTPUT_FILENAME = "U:\\temp\\regionModel.json";
    static String LOG_FILENAME = "U:\\temp\\regionModel.log";

    public void runConversion() {
        try {
            Converter converter = new Converter();
            converter.convertSingleMongooseFileToJSONFile(INPUT_FILENAME, OUTPUT_FILENAME, LOG_FILENAME);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public static void main(String args[]) {
        CommLineSingleMongooseFileToJSONFile convert = new CommLineSingleMongooseFileToJSONFile();
        convert.runConversion();
    }
}
