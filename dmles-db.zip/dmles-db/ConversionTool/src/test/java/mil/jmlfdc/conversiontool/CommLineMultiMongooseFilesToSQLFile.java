package mil.jmlfdc.conversiontool;

import mil.jmlfdc.conversiontool.processor.Converter;

/**
 * Class to test, via command line, the
 * Converter.convertMultiMongooseFilesToSQLFile method
 *
 */
public class CommLineMultiMongooseFilesToSQLFile {

    private static final String INPUT_DIRECTORY = "C:\\Workspace\\GitProjects\\dmles-gui\\app_api\\models";
    private static final String OUTPUT_FILENAME = "U:\\temp\\mongoose_to_sql.sql";
    private static final String LOG_FILENAME = "U:\\temp\\mongoose_to_sql.log";

    public void runConversion() {
        try {
            Converter converter = new Converter();
            converter.convertMultiMongooseFilesToSQLFile(INPUT_DIRECTORY, OUTPUT_FILENAME, LOG_FILENAME);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public static void main(String args[]) {
        CommLineMultiMongooseFilesToSQLFile convert = new CommLineMultiMongooseFilesToSQLFile();
        convert.runConversion();
    }
}
