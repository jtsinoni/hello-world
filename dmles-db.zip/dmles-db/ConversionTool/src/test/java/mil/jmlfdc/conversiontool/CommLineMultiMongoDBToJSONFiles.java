/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mil.jmlfdc.conversiontool;

import mil.jmlfdc.conversiontool.processor.Converter;

/**
 * ^
 *
 * @author david.caglarcan
 */
public class CommLineMultiMongoDBToJSONFiles {

    static String MONGODB_CONNECTION_STRING = "replDMLES01/dmeddb3001:27017,dmeddb3002:27017,dmeddb3003:27017";
    static String DB_NAME = "dmles-equipment";
    static String OUTPUT_DIRECTORY = "C:\\Workspace\\temp2";
    static String LOG_FILENAME = "C:\\Workspace\\temp\\multiMongoDBToJSON.log";
    static String USERNAME = "username";  // Edit with the real info in order to run test
    static String PASSWORD = "password";  // Edit with the real info in order to run test

    public void runConversion() {
        try {
            Converter converter = new Converter();
            converter.convertMultiMongoDBCollectionsToJSONFiles(MONGODB_CONNECTION_STRING, DB_NAME, OUTPUT_DIRECTORY, LOG_FILENAME,
                    USERNAME, PASSWORD);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public static void main(String args[]) {
        CommLineMultiMongoDBToJSONFiles convert = new CommLineMultiMongoDBToJSONFiles();
        convert.runConversion();
    }
}
