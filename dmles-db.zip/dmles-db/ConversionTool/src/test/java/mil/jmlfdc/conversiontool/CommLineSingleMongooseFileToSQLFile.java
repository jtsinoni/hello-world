package mil.jmlfdc.conversiontool;

import mil.jmlfdc.conversiontool.processor.Converter;

/**
 * Class to test, via command line, the
 * Converter.converSingleMongooseFileToSQLFile method
 *
 */
public class CommLineSingleMongooseFileToSQLFile {

    static String INPUT_FILENAME = "C:\\Workspace\\GitProjects\\dmles-gui\\app_api\\models\\requestModel.js";
    static String OUTPUT_FILENAME = "U:\\temp\\requestModel.sql";
    static String LOG_FILENAME = "U:\\temp\\requestModel.log";

    public void runConversion() {
        try {
            Converter converter = new Converter();
            converter.convertSingleMongooseFileToSQLFile(INPUT_FILENAME, OUTPUT_FILENAME, LOG_FILENAME);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public static void main(String args[]) {
        CommLineSingleMongooseFileToSQLFile convert = new CommLineSingleMongooseFileToSQLFile();
        convert.runConversion();
    }
}
