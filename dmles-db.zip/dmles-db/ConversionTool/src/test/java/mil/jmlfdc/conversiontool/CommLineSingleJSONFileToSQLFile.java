package mil.jmlfdc.conversiontool;

import mil.jmlfdc.conversiontool.processor.Converter;

/**
 * Class to test, via command line, the Converter.convertSingleJSONFileToSQLFile
 * method
 *
 */
public class CommLineSingleJSONFileToSQLFile {

    static String INPUT_FILENAME = "U:\\temp\\EquipmentRequests.json";
    static String OUTPUT_FILENAME = "U:\\temp\\EquipmentRequests.sql";
    static String LOG_FILENAME = "U:\\temp\\EquipmentRequests.log";

    public void runConversion() {
        try {
            Converter converter = new Converter();
            converter.convertSingleJSONFileToSQLFile(INPUT_FILENAME, OUTPUT_FILENAME, LOG_FILENAME);

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public static void main(String args[]) {
        CommLineSingleJSONFileToSQLFile convert = new CommLineSingleJSONFileToSQLFile();
        convert.runConversion();
    }
}
