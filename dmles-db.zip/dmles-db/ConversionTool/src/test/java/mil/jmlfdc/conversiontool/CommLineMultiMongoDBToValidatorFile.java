package mil.jmlfdc.conversiontool;

import mil.jmlfdc.conversiontool.processor.Converter;
import mil.jmlfdc.conversiontool.util.MongoDBUtility;

/**
 *
 * @author david.caglarcan
 */
public class CommLineMultiMongoDBToValidatorFile {

    static String MONGODB_CONNECTION_STRING = "replDMLES01/dmetdb4001:27017,dmetdb4002:27017,dmetdb4003:27017";
    static String DB_NAME = "dmles-equipment";
    static String OUTPUT_FILE = "C:\\Workspace\\temp2\\dmles_dev_jw8_validator.js";
    static String LOG_FILENAME = "C:\\Workspace\\temp2\\dmles_dev_jw8_validator.log";
    static String USERNAME = MongoDBUtility.USER_CREDENTIALS_NOT_APPLICABLE;
    static String PASSWORD = MongoDBUtility.USER_CREDENTIALS_NOT_APPLICABLE;

    public void runConversion() {
        try {
            Converter converter = new Converter();
            converter.convertMultiMongoDBCollectionsToMongoDBValidatorFile(MONGODB_CONNECTION_STRING, DB_NAME, OUTPUT_FILE,
                    LOG_FILENAME, USERNAME, PASSWORD);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public static void main(String args[]) {
        CommLineMultiMongoDBToValidatorFile convert = new CommLineMultiMongoDBToValidatorFile();
        convert.runConversion();
    }
}
