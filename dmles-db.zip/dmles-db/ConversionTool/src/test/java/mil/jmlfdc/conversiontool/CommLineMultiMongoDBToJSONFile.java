/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mil.jmlfdc.conversiontool;

import mil.jmlfdc.conversiontool.processor.Converter;

/**
 *
 * @author david.caglarcan
 */
public class CommLineMultiMongoDBToJSONFile {

    static String MONGODB_CONNECTION_STRING = "replDMLES01/dmeddb3001:27017,dmeddb3002:27017,dmeddb3003:27017";
    static String DB_NAME = "dmles-user";
    static String OUTPUT_FILE = "C:\\Workspace\\temp2\\dmles_user.json";
    static String LOG_FILENAME = "C:\\Workspace\\temp2\\dmles_user.log";
    static String USERNAME = "username";  // Edit with the real info in order to run test
    static String PASSWORD = "password";  // Edit with the real info in order to run test

    public void runConversion() {
        try {
            Converter converter = new Converter();
            converter.convertMultiMongoDBCollectionsToJSONFile(MONGODB_CONNECTION_STRING, DB_NAME, OUTPUT_FILE, LOG_FILENAME, USERNAME, PASSWORD);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public static void main(String args[]) {
        CommLineMultiMongoDBToJSONFile convert = new CommLineMultiMongoDBToJSONFile();
        convert.runConversion();
    }
}
