use dmlesUser

// Seeding 13 new records into dmlesUser.Element

// Initial count

db.Element.count()


db.Element.insert({
    "_id" : ObjectId("58a4d5c77a7f30a5c71678d4"),
    "name" : "buyer-view"
})

db.Element.insert({
    "_id" : ObjectId("58a4d5dd7a7f30a5c71678e1"),
    "name" : "buyer-purchases-view"
})

db.Element.insert({
    "_id" : ObjectId("58a4d5e97a7f30a5c71678e6"),
    "name" : "buyer-requisition-view"
})

db.Element.insert({
    "_id" : ObjectId("58a4d5f47a7f30a5c71678ee"),
    "name" : "buyer-receipts-view"
})

db.Element.insert({
    "_id" : ObjectId("58a61810feb0cc1899977feb"),
    "name" : "inventory-record-view"
})

db.Element.insert({
    "_id" : ObjectId("58a61810feb0cc1899977fed"),
    "name" : "inventory-physical-view"
})

db.Element.insert({
    "_id" : ObjectId("58a61835feb0cc189997800a"),
    "name" : "inventory-storage-view"
})

db.Element.insert({
    "_id" : ObjectId("58a61835feb0cc189997800c"),
    "name" : "inventory-gain-loss-view"
})

db.Element.insert({
    "_id" : ObjectId("58a61835feb0cc189997800e"),
    "name" : "inventory-transfer-view"
})

db.Element.insert({
    "_id" : ObjectId("58a4d6007a7f30a5c71678f4"),
    "name" : "buyer-order-status-view"
})

db.Element.insert({
    "_id" : ObjectId("58a5f5a6feb0cc1899973f06"),
    "name" : "seller-view"
})

db.Element.insert({
    "_id" : ObjectId("58a5f5b7feb0cc1899973f13"),
    "name" : "seller-fulfillment-view"
})

db.Element.insert({
    "_id" : ObjectId("58a5f5c4feb0cc1899973f1d"),
    "name" : "seller-back-order-status-view"
})



// Post-insert count

db.Element.count()
