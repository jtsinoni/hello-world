use dmlesUser

// Inserting 24 new records into dmlesUser.State collection

// Initial count

db.State.count()


db.State.insert({
    "_id" : ObjectId("58a38afaa5f68771d18082d6"),
    "name" : "dmles.home.equipment"
})

db.State.insert({
    "_id" : ObjectId("58a38b2da5f68771d18082ff"),
    "name" : "dmles.home.equipment.record"
})

db.State.insert({
    "_id" : ObjectId("58a38b3ba5f68771d180830c"),
    "name" : "dmles.home.equipment.recordDataManagement"
})

db.State.insert({
    "_id" : ObjectId("58a38b46a5f68771d1808314"),
    "name" : "dmles.home.equipment.record.details"
})

db.State.insert({
    "_id" : ObjectId("58a38b52a5f68771d180831d"),
    "name" : "dmles.home.equipment.request"
})

db.State.insert({
    "_id" : ObjectId("58a38b5ea5f68771d1808329"),
    "name" : "dmles.home.equipment.request.myRequests"
})

db.State.insert({
    "_id" : ObjectId("58a38b6ca5f68771d1808339"),
    "name" : "dmles.home.equipment.request.myRequests.view"
})

db.State.insert({
    "_id" : ObjectId("58a38ba0a5f68771d1808365"),
    "name" : "dmles.home.equipment.request.myRequests.view.history"
})

db.State.insert({
    "_id" : ObjectId("58a4d51b7a7f30a5c716787b"),
    "name" : "dmles.home.buyer"
})

db.State.insert({
    "_id" : ObjectId("58a4d53f7a7f30a5c716788c"),
    "name" : "dmles.home.buyer.main"
})

db.State.insert({
    "_id" : ObjectId("58a4d54b7a7f30a5c7167892"),
    "name" : "dmles.home.buyer.purchases"
})

db.State.insert({
    "_id" : ObjectId("58a4d5557a7f30a5c7167899"),
    "name" : "dmles.home.buyer.requisition"
})

db.State.insert({
    "_id" : ObjectId("58a4d55f7a7f30a5c716789f"),
    "name" : "dmles.home.buyer.receipts"
})

db.State.insert({
    "_id" : ObjectId("58a4d5697a7f30a5c71678a5"),
    "name" : "dmles.home.buyer.orderStatus"
})

db.State.insert({
    "_id" : ObjectId("58a5f4ddfeb0cc1899973e85"),
    "name" : "dmles.home.seller"
})

db.State.insert({
    "_id" : ObjectId("58a5f501feb0cc1899973e9c"),
    "name" : "dmles.home.seller.main"
})

db.State.insert({
    "_id" : ObjectId("58a5f50efeb0cc1899973ea5"),
    "name" : "dmles.home.seller.fulfillment"
})

db.State.insert({
    "_id" : ObjectId("58a5f518feb0cc1899973eac"),
    "name" : "dmles.home.seller.backOrderStatus"
})

db.State.insert({
    "_id" : ObjectId("58a61778feb0cc1899977f77"),
    "name" : "dmles.home.inventory"
})

db.State.insert({
    "_id" : ObjectId("58a6178afeb0cc1899977f84"),
    "name" : "dmles.home.inventory.record"
})

db.State.insert({
    "_id" : ObjectId("58a6179dfeb0cc1899977f92"),
    "name" : "dmles.home.inventory.physical"
})

db.State.insert({
    "_id" : ObjectId("58a617abfeb0cc1899977f9c"),
    "name" : "dmles.home.inventory.storage"
})

db.State.insert({
    "_id" : ObjectId("58a617b7feb0cc1899977fa8"),
    "name" : "dmles.home.inventory.gainLoss"
})

db.State.insert({
    "_id" : ObjectId("58a617c4feb0cc1899977fb2"),
    "name" : "dmles.home.inventory.transfer"
})


// Post-insert count

db.State.count()
