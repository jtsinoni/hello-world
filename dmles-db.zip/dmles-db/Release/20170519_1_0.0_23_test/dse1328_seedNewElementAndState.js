print()
print()
print("================================================================================================================")
print("DSE-1328:  dmlesUser: Seed new Element and State" )
print("================================================================================================================")

use dmlesUser


print()
print("======================")
print("Pre-run queries")
print("======================")
print()

db.Element.find({name: "test-equipment"}).pretty()

db.State.find({name: "dmles.home.jmlfdcAdmin.equipmentTesting"}).pretty()





print()
print("======================")
print("Run inserts/updates")
print("======================")
print()

db.Element.insert( 
  {
    "_id" : ObjectId("591b62b9f7f173413c738210"),
    "name" : "test-equipment",
    "functionalArea" : "Other"
  }
)

db.State.insert(
  {
    "_id" : ObjectId("591b62caf7f173413c738211"),
    "name" : "dmles.home.jmlfdcAdmin.equipmentTesting",
    "functionalArea" : "Other"
  }
)


print()
print("======================")
print("Post-run QA queries")
print("======================")
print()

db.Element.find({name: "test-equipment"}).pretty()

db.State.find({name: "dmles.home.jmlfdcAdmin.equipmentTesting"}).pretty()



print()
print()
print()
