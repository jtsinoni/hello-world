print()
print()
print("================================================================================================================")
print("DSE-1333:  dmlesUser: Update User Profiles" )
print("================================================================================================================")

use dmlesUser


print()
print("======================")
print("Pre-run queries")
print("======================")
print()

print("Total recs in AppUserProfile")
db.getCollection('AppUserProfile').count({})

print("Recs where active = true")
db.getCollection('AppUserProfile').count({active: true})

print("Recs where _isDeleted = true")
db.getCollection('AppUserProfile').count({_isDeleted: true})

print("Recs where _isDeleted = false")
db.getCollection('AppUserProfile').count({_isDeleted: false})

print("Recs that have the new fields")
db.getCollection('AppUserProfile').count( { $and: [ {lockedDate: {$exists: true}}, {unlockedDate: {$exists: true}} ] } )


print("Recs that have at least 1 of the 2 obsolete fields")
db.getCollection('AppUserProfile').count( { $or: [ {active: {$exists: true}}, {retiredDate: {$exists: true}} ] } )



print()
print("======================")
print("Run inserts/updates")
print("======================")
print()

print()
print("Add new status fields to active users")
print()

db.AppUserProfile.update({}, 
                    {
                        $set: {
                            "lockedDate" : null,
                            "unlockedDate" : null,
                            "reason" : null,
                            "_isDeleted" : false,
                            "userProfileStatus" : "ACTIVE",
                            "deletedDate": null,
                            "profileSuspensionDate" : null  
                        }
                    },
                    {
                        multi: true
                    }                    
                );

print()
print("Update inactive profiles, set _isDeleted and userProfileStatus DELETED and update deletedDate")
print()

db.AppUserProfile.update(
  {active: false},
  {$set: {_isDeleted: true, "userProfileStatus" : "DELETED", deletedDate: ISODate("2017-05-18T01:01:01.001Z")}},
  {multi: true}
)


print()
print("Remove un-used fields")
print()

db.AppUserProfile.update( 
   {},
   {$unset: { active: 1, retiredDate: 1}},
   {multi: true}                
   );


print()
print("Further cleanup is needed..... in another ticket")
print()


print()
print("======================")
print("Post-run QA queries")
print("======================")
print()

print("Total recs in AppUserProfile")
db.getCollection('AppUserProfile').count({})

print("Recs where active = true")
db.getCollection('AppUserProfile').count({active: true})

print("Recs where _isDeleted = true")
db.getCollection('AppUserProfile').count({_isDeleted: true})

print("Recs where _isDeleted = false")
db.getCollection('AppUserProfile').count({_isDeleted: false})

print("Recs that have the new fields")
db.getCollection('AppUserProfile').count( { $and: [ {lockedDate: {$exists: true}}, {unlockedDate: {$exists: true}} ] } )


print("Recs that have at least 1 of the 2 obsolete fields")
db.getCollection('AppUserProfile').count( { $or: [ {active: {$exists: true}}, {retiredDate: {$exists: true}} ] } )


print()
print()
print()
