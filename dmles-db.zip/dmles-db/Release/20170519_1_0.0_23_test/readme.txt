===============================================================================
Roll to Test, 19-May-2017, LogiCole, Release 1.0.0_23
===============================================================================


---------------------------------------
Tickets w/Data Tier Changes rolling
---------------------------------------

* DSE-1316:  dmlesUser: Add New User Profile States

* DSE-1322:  dmlesUser: Add invitation and profile expiration data to existing active users

* DSE-1323:  dmlesOrganization: Add Role Refs To Service Providers

* DSE-1328:  dmlesUser: Seed new Element and State

* DSE-1333:  dmles1333: Update User Profiles"

* DSE-1342:  dmlesUser: Add new State

* DSE-1344:  dmlesUser: Update Profile Audit Fields (updatedDate and updatedBy)

* DSE-1350:  dmlesUser: Update RoleFuncationalAreaConfig (1 record)


ROLLED EARLY:

* DSE-1289:  dmlesUser changes required for Device Classification
                -- DB changes actually deployed on 12-May with Release 1.0.0_22, but
                   Matt's tracking spreadsheet has this ticket listed as part of this release.



---------------------------------------
RUN ORDER
---------------------------------------

-1   Run backup of DBs prior to deployment


0    Run pre-deploy QA queries

         cd qa_queries

         qaQueries.cmd <Environment> <username> <password>  > qaQueriesPreDeploy_<Environment>.log

         (Then navigate back up to deployment root dir)


1   Run dse1316_addNewUserProfileStates.cmd script

      -- 


2   Run dse1323_addRoleRefsToServiceProviders.cmd script

      -- 


3   Run dse1328_seedNewElementAndState.cmd script

      -- 


4   Run dse1333_updateUserProfiles.cmd script

      -- 


5   Run dse1342_addNewState.cmd script

      -- 


6   Run dse1344_updateProfileAuditFields.cmd script



7   Run dse1350_updateRoleFuncAreaConfig.cmd script




10   Run post-deploy QA queries

         cd qa_queries

         qaQueries.cmd <Environment> <username> <password>  > qaQueriesPostDeploy_<Environment>.log



11   Compare pre-deploy QA queries and post-deploy

         in Gitbash, go to qa_queries directory

         diff qaQueriesPreDeploy_<Environment>.log qaQueriesPostDeploy_<Environment>.log



12   Run "Validate Refs" Jenkins Job

      -- To verify that the data updates have not resulted in any broken Refs

      -- If any broken Refs found, remediate!   You may need to restore data from backup in order to "undo" the changes that were made.

          ---- The incidence of this can be minimized with proper testing ahead of time



13   Run "Validate Structure" Jenkins Job

      -- To verify that the Json Schema defs are up-to-date with the latest data structure changes

      -- If any inaccurracies found, fix the JSON schema ASAP (but that is NOT essential for the release deployment, just for nightly validation)
  


14   When Release is completely done, do the following:

      -- Run another backup of Dev and/or Test DBs


      -- Update the files for Developers' "static" update of their local MongoDB instances:

                X:\Software Engineering\DML-ES\MongoDB_Developer_Seed


      -- If new MongoDB database(s) have been added, or removed, then update the following scripts, in the dmles-bt project, accordingly:

                Scripts\mongoLocalSeed.cmd
                Scripts\mongodumpDevDbs.cmd
                Scripts\mongoexportAllDBsSample.cmd           


       -- If needed, run a new "export all data sample" for the data architects:

                Scripts\mongoexportAllDBsSample.cmd

                Zip results and save them to:  X:\Data Architecture Team\DML-ES DB Sample Data Import



---------------------------------------
HOW TO RUN the .cmd scripts
---------------------------------------

To run against your localhost DB:

    scriptName.cmd local n n


To run against the Dev DB:

    scriptName.cmd dev username password


To run against the Test DB:

    scriptName.cmd test username password


To output the results to a log file (recommended):

    Append this to your command:   > logfileName 2>&1 

    For example:

       scriptName.cmd local n n > logfile_local.log 2>&1

       scriptName.cmd dev  username password logfile_dev.log 2>&1

       scriptName.cmd test username password logfile_test.log 2>&1

