use dmlesCatalog

show collections



db.commodityClass.count()

db.itemCatalog.count()

db.productCatalog.count()

db.siteCatalog.count()

