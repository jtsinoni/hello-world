print()
print()
print("================================================================================================================")
print("DSE-1344:  dmlesUser:Update Profile Audit Fields (updatedDate and updatedBy)" )
print("================================================================================================================")

use dmlesUser


print()
print("======================")
print("Pre-run queries")
print("======================")
print()


print("count total")
db.AppUserProfile.count()

print()
print("count recs that have the audit fields populated")
db.AppUserProfile.count( {$and: [ {updatedDate: {$ne: null}}, {updatedBy: {$ne: null}} ] } )


print()
print("count recs that do NOT have the audit fields populated")
db.AppUserProfile.count( {$or: [ {updatedDate : null}, {updatedDate: {$exists: false}} ] } )


print()
print("count recs that do NOT have appProfileType")
db.AppUserProfile.count( {appProfileType: {$exists: false}} )





print()
print("======================")
print("Run inserts/updates")
print("======================")
print()


db.AppUserProfile.update( {appProfileType: {$exists: false}},
                          {$set: {appProfileType: "LOGISTICS"}},
                          {multi: true}
                        )

db.AppUserProfile.update( {$or: [ {updatedDate : null}, {updatedDate: {$exists: false}} ] },
                    {
                        $set: {
                            "updatedDate": ISODate("2017-05-18T01:01:01.001Z"),
                            "updatedBy": "System"
                        }
                    }, {
                        multi: true
                    });

print()
print("======================")
print("Post-run QA queries")
print("======================")
print()

print("count total")
db.AppUserProfile.count()

print()
print("count recs that have the audit fields populated")
db.AppUserProfile.count( {$and: [ {updatedDate: {$ne: null}}, {updatedBy: {$ne: null}} ] } )


print()
print("count recs that do NOT have the audit fields populated")
db.AppUserProfile.count( {$or: [ {updatedDate : null}, {updatedDate: {$exists: false}} ] } )

print()
print("count recs that do NOT have appProfileType")
db.AppUserProfile.count( {appProfileType: {$exists: false}} )


print()
print()
print()
