print()
print()
print("================================================================================================================")
print("DSE-1350:  dmlesUser: Fix RoleFunctionalAreaConfig record" )
print("================================================================================================================")

use dmlesUser


print()
print("======================")
print("Pre-run queries")
print("======================")
print()

db.RoleFunctionalAreaConfig.find( {_id: ObjectId("58d031372d0aef5f06168345")}).pretty()


print()
print("======================")
print("Run inserts/updates")
print("======================")
print()

db.RoleFunctionalAreaConfig.update( 
   {_id: ObjectId("58d031372d0aef5f06168345")},
   {$set: {option: "Equipment Request"}}
)


print()
print("======================")
print("Post-run QA queries")
print("======================")
print()

db.RoleFunctionalAreaConfig.find( {_id: ObjectId("58d031372d0aef5f06168345")}).pretty()


print()
print()
print()
