print()
print()
print("================================================================================================================")
print("DSE-NNNN:  dmlesNNNN: Quick Description" )
print("================================================================================================================")

use dmlesNNNN


print()
print("======================")
print("Pre-run queries")
print("======================")
print()






print()
print("======================")
print("Run inserts/updates")
print("======================")
print()






print()
print("======================")
print("Post-run QA queries")
print("======================")
print()







print()
print()
print()
