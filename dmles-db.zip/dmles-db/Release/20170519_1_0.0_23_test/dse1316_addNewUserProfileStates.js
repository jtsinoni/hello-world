print()
print()
print("================================================================================================================")
print("DSE-1316:  dmlesUser: Add New User Profile States" )
print("================================================================================================================")

use dmlesUser


print()
print("======================")
print("Pre-run queries")
print("======================")
print()

print("Check for the 2 new States and 1 modified State")
print()

db.State.count( {name: {$in: [ 
                               "dmles.home.admin.userProfileMng.createProfile",
                               "dmles.home.admin.userProfileMng.createProfile.assignRoles",
                               "dmles.home.admin.userProfileMng.createProfile.assignRoles.confirm"
                             ]
                       }
                }
              )

db.State.find( {name: {$in: [ 
                               "dmles.home.admin.userProfileMng.createProfile",
                               "dmles.home.admin.userProfileMng.createProfile.assignRoles",
                               "dmles.home.admin.userProfileMng.createProfile.assignRoles.confirm"
                             ]
                       }
                }, 
                {_id: 1, name: 1, functionalArea: 1}
              ).pretty()

print()
print("======================")
print("Run inserts/updates")
print("======================")
print()


db.State.update( 
  { _id: ObjectId("5911e836a9504efb91405165")},  
  {$set: { name: "dmles.home.admin.userProfileMng.createProfile"}}
)


db.State.insert(
  {
    "_id" : ObjectId("5911e836a9504efb91405166"),
    "name" : "dmles.home.admin.userProfileMng.createProfile.assignRoles"
  }
)

db.State.insert(
  {
    "_id" : ObjectId("5911e837a9504efb91405167"),
    "name" : "dmles.home.admin.userProfileMng.createProfile.assignRoles.confirm"
  }
)


// For Test environments, recs were already there (correct ID, wrong name) so doing updates 
// instead of the 2 inserts (which will have failed)

db.State.update(
  { 
    "_id" : ObjectId("5911e836a9504efb91405166") 
  },
  { $set: 
          {  
            "name" : "dmles.home.admin.userProfileMng.createProfile.assignRoles",
            "functionalArea" : "Administration"
          }
  }
)

db.State.update(
  { 
    "_id" : ObjectId("5911e837a9504efb91405167")
  },
  { $set: 
          {
            "name" : "dmles.home.admin.userProfileMng.createProfile.assignRoles.confirm",
            "functionalArea" : "Administration"
          }
  }
)


// Final update to make sure they all get functionalArea of "Administration"


db.State.updateMany( {name: {$in: [ 
                               "dmles.home.admin.userProfileMng.createProfile",
                               "dmles.home.admin.userProfileMng.createProfile.assignRoles",
                               "dmles.home.admin.userProfileMng.createProfile.assignRoles.confirm"
                             ]
                         }
                      },
                      {$set: {functionalArea: "Administration"}}
                   )

print()
print("======================")
print("Post-run QA queries")
print("======================")
print()

print("Check for the 3 new States")
print()

db.State.count( {name: {$in: [ 
                               "dmles.home.admin.userProfileMng.createProfile",
                               "dmles.home.admin.userProfileMng.createProfile.assignRoles",
                               "dmles.home.admin.userProfileMng.createProfile.assignRoles.confirm"
                             ]
                       }
                }
              )

db.State.find( {name: {$in: [ 
                               "dmles.home.admin.userProfileMng.createProfile",
                               "dmles.home.admin.userProfileMng.createProfile.assignRoles",
                               "dmles.home.admin.userProfileMng.createProfile.assignRoles.confirm"
                             ]
                       }
                }, 
                {_id: 1, name: 1, functionalArea: 1}
              ).pretty()

print()
print()
print()
