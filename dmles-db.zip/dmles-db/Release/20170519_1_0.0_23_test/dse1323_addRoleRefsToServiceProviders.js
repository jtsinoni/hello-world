print()
print()
print("================================================================================================================")
print("DSE-1323:  dmlesOrganization - ServiceProvider: Add More Equipment Request Roles" )
print("================================================================================================================")

use dmlesOrganization


print()
print("======================")
print("Pre-run queries")
print("======================")
print()



print()
print("======================")
print("Run inserts/updates")
print("======================")
print()


print()
print("Add more equipment request roles to the Equipment Request Service Provider Consumer")
print()

db.ServiceProvider.update({ "_id" : ObjectId("58f514c785ff091493fa6f72") }, 
                    {
                        $set: {
                            'consumer.roleRefs': [
                                {
                                    "id" : "57800f5d768bbb531eecd249",
                                    "name" : "Site Equipment Manager"
                                }, 
                                {
                                    "id" : "57800ed6768bbb531eecd248",
                                    "name" : "Site Equipment Custodian"
                                }, 
                                {
                                    "id" : "57800fba768bbb531eecd24b",
                                    "name" : "Site Equipment Maintenance"
                                }, 
                                {
                                    "id" : "57800f96768bbb531eecd24a",
                                    "name" : "Site Equipment Technology"
                                }, 
                                {
                                    "id" : "5810c056564b5f9f750ca8c0",
                                    "name" : "Site Equipment Classification"
                                }, 
                                {
                                    "id" : "57800fe5768bbb531eecd24d",
                                    "name" : "Site Equipment Safety"
                                }, 
                                {
                                    "id" : "57800fc5768bbb531eecd24c",
                                    "name" : "Site Equipment Facilities"
                                }                        
                            ]
                        }
                    }, {
                        multi: false
                    });

print()
print("Add more equipment request review roles to the Equipment Request Review Service Provider Consumer")
print()

db.ServiceProvider.update({ "_id" : ObjectId("58f514c785ff091493fa6f74") }, 
                    {
                        $set: {
                            'consumer.roleRefs': [
                                {
                                    "id" : "57800f5d768bbb531eecd249",
                                    "name" : "Site Equipment Manager"
                                }, 
                                {
                                    "id" : "57800fba768bbb531eecd24b",
                                    "name" : "Site Equipment Maintenance"
                                }, 
                                {
                                    "id" : "57800f96768bbb531eecd24a",
                                    "name" : "Site Equipment Technology"
                                }, 
                                {
                                    "id" : "5810c056564b5f9f750ca8c0",
                                    "name" : "Site Equipment Classification"
                                }, 
                                {
                                    "id" : "57800fe5768bbb531eecd24d",
                                    "name" : "Site Equipment Safety"
                                }, 
                                {
                                    "id" : "57800fc5768bbb531eecd24c",
                                    "name" : "Site Equipment Facilities"
                                },  
                                {
                                    "id" : "57bf493c03e0fba04e9bba1e",
                                    "name" : "Regional Equipment Manager"
                                }, 
                                {
                                    "id" : "57bf49da03e0fba04e9bba20",
                                    "name" : "Regional Equipment Maintenance"
                                }, 
                                {
                                    "id" : "57800f96768bbb531eecd24a",
                                    "name" : "Regional Equipment Technology"
                                }, 
                                {
                                    "id" : "5810c056564b5f9f750ca8c0",
                                    "name" : "Regional Equipment Classification"
                                }, 
                                {
                                    "id" : "57bf4a3403e0fba04e9bba22",
                                    "name" : "Regional Equipment Safety"
                                }, 
                                {
                                    "id" : "586d33ea0001aa092074256d",
                                    "name" : "Regional Subject Matter Expert"
                                },
                                {
                                    "id" : "588f53acc3a3041154d57fc8",
                                    "name" : "Service Subject Matter Expert"
                                },
                                {
                                    "id" : "57bf4a8403e0fba04e9bba25",
                                    "name" : "Service Equipment Maintenance"
                                },                                 
                                {
                                    "id" : "57bf4a5303e0fba04e9bba23",
                                    "name" : "Service Equipment Manager"
                                },
                                {
                                    "id" : "57bf4ab803e0fba04e9bba27",
                                    "name" : "Service Equipment Safety"
                                },
                                {
                                    "id" : "57bf4a9d03e0fba04e9bba26",
                                    "name" : "Service Equipment Facilities"
                                },
                                {
                                    "id" : "57bf4a6e03e0fba04e9bba24",
                                    "name" : "Service Equipment Technology"
                                },
                                {
                                    "id" : "57bf4af003e0fba04e9bba29",
                                    "name" : "DHA Equipment Technology"
                                },                                 
                                {
                                    "id" : "57bf4ad903e0fba04e9bba28",
                                    "name" : "DHA Equipment Manager"
                                },
                                {
                                    "id" : "57bf4b4c03e0fba04e9bba2c",
                                    "name" : "DHA Equipment Safety"
                                },
                                {
                                    "id" : "57bf4b0b03e0fba04e9bba2a",
                                    "name" : "DHA Equipment Maintenance"
                                },
                                {
                                    "id" : "588f53dbc3a3041154d57fcb",
                                    "name" : "DHA Subject Matter Expert"
                                },
                                {
                                    "id" : "57bf4b2203e0fba04e9bba2b",
                                    "name" : "DHA Equipment Facilities"
                                }                             
                            ]
                        }
                    }, {
                        multi: false
                    });

print()
print("======================")
print("Post-run QA queries")
print("======================")
print()







print()
print()
print()
