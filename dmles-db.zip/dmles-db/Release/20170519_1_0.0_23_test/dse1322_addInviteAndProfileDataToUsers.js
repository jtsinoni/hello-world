print()
print()
print("================================================================================================================")
print("DSE-1322:  dmlesUser: Add invitation and profile expiration data to existing active users" )
print("================================================================================================================")

use dmlesUser

print()
print("======================")
print("Pre-run queries")
print("======================")
print()

db.AppUserProfile.count({active: true})
db.AppUserProfile.count({active: true, invitation: {$exists: true}})


print()
print("======================")
print("Run inserts/updates")
print("======================")
print()

db.AppUserProfile.update({ active : true }, 
                    {
                        $set: {
                            "profileExpirationDate": ISODate("2020-01-01T01:01:00.000Z"),
                            "invitation": {
                                "id": "0570b764-9485-4acd-beac-32a325101c9c",
                                "acceptedDate": ISODate("2017-02-01T01:01:00.000Z"),
                                "expirationDate": ISODate("2017-05-01T01:01:00.000Z"),
                                "sentDate": ISODate("2017-01-01T01:01:00.000Z")
                            } 
                        }
                    }, {
                        multi: true
                    });

print()
print("======================")
print("Post-run QA queries")
print("======================")
print()

db.AppUserProfile.count({active: true})
db.AppUserProfile.count({active: true, invitation: {$exists: true}})


print()
print()
print()
