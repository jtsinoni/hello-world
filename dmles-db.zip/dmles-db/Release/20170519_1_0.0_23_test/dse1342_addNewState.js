print()
print()
print("================================================================================================================")
print("DSE-1342:  dmlesUser: Add new State" )
print("================================================================================================================")

use dmlesUser


print()
print("======================")
print("Pre-run queries")
print("======================")
print()

print("Check for the new State")
print()

db.State.find( {name: "dmles.home.admin.userProfileMng.editStatus"} )





print()
print("======================")
print("Run inserts/updates")
print("======================")
print()

db.State.insert( 
  {
    "_id" : ObjectId("591db8b6601e373f4898d876"),
    "name" : "dmles.home.admin.userProfileMng.editStatus",
    "functionalArea" : "Administration"
  }
)




print()
print("======================")
print("Post-run QA queries")
print("======================")
print()


print("Check for the new State")
print()

db.State.find( {name: "dmles.home.admin.userProfileMng.editStatus"} )


print()
print()
print()
