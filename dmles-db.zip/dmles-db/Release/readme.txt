=======================================================================================================================
dmles-db project, Release directory
=======================================================================================================================

Updated by Dave Caglarcan, 3/22/2017

----------------------------
Intro
----------------------------

Release directory was added to dmles-db project by Dave Caglarcan in January 2017 in order to capture the process for, a
nd artifacts from, the DB portion of DML-ES releases.

As of Feb 2017 the release process is still pretty basic, and releases are only being done in Dev and Test.  

The purpose of capturing these artifacts is so they can be used to develop more formalized, robust deployment procedures
in the future.


----------------------------
Typical Deployment Process
----------------------------

  * Software Engineer notifies developers and others at least a few hours ahead of time via email

  * Software Engineer (Matt Roberts) and DB Engineer (Dave Caglarcan) coordinate and communicate via the Swift chat app
    during the actual deployment.

      -- If Swift is not working well, use the Beta "JMLFDC Chat" app:  http://jwsrv116.ad.dmlss.detrick.army.mil:3000/chat/

  * Software Engineer brings down the application.

  * DB Engineer deployes DB changes (via scripts)

  * Software Engineer deploys code changes (typically via Jenkins deploy)

  * When changes are all deployed, Software Engineer brings the application back up, and both engineers do some basic
    front-end testing.

  * Software Engineer notifies developers and others that deployment is complete, and updates the "Release Reports" 
    page on Confluence

       -- https://jpsncm1012.jmlfdc.mil/confluence/pages/viewpage.action?spaceKey=DSE&title=Release+Reports


------------------------------------------
Creating deployment directory and scripts
------------------------------------------

  * Create a directory for the deployment, with format of:

         YYYYMMDD_<release_number>_environment

               e.g. 20161206_1.0.0_5_test
               e.g. 20161229_1.0.0_7_test

         Note: Software Engineer will have the release number

  * Copy the mongodbCommandScriptTemplate.txt and setConnectionProps.cmd files into the deployment directory

  * Open mongodbCommandScriptTemplate.txt and do "save as" to create .cmd file

      -- Note header comments in script to see the needed parameters

           --- Should be:   environment (local, dev, or test)
                            username 
                            password

      -- Edit script (see section down near bottom "PUT YOUR ACTUAL COMMAND(S) HERE")

      -- Script will call setConnectionProps.cmd to establish DB connection params, then run your step

  * Create a README file to list the order of steps being taken.  

      -- Use the readme_release_template.txt file as a template for this release-specific README file that you create.

 
----------------------------------------------------------------------------
"Partial Deployment" directories, leading to full Test deployment directory
----------------------------------------------------------------------------

* Throughout the week prior to deployment, as things are deployed to Dev (or pre-deployed to Test), create directories to store these scripts
  and capture this.

       e.g. 20170320_dse973_975_dev
       e.g. 20170321_dse975_test
       e.g. 20170321_dse989_dse999_dse_944_dev


* When you finally build the Test deployment directory, you can delete the "partial deployment" directories

       e.g.   Create  20170317_1_0.0_15_test
              Delete  20170315_dse950_dev and 20170316_dse957_dev

* Once something has been deployed to TEST, we don't need to keep artifacts of its having been deployed to Dev

* For tickets that are deployed in Dev, but do NOT deploy to Test that same week---->LEAVE the directories in place for those, UNTIL they go to Test


------------------------------------------
Other Advice and Notes
------------------------------------------

  * If seeding data that has a generated ObjectId for the _id field, you want to make sure you have that ObjectId value in the 
    data to be seeded!   (So you have consistency across environments)

      -- Good option:   * seed data initially into your localhost database (e.g. from CSV)
                        * export data out of databaes into .json file
                        * import THAT file for subsequent releases

  * Always do practice run against your localhost database first, before doing Dev, and finally Test when the time comes

  * Do backups of stuff before doing deploys, in case something goes wrong

  * Do NOT check in files that have passwords hard-coded.  (Should NOT be needed if you follow the steps described above)

  * Also, "sanitize" any data directories if needed.  Don't check in sensitive data of any kind.

  * Be flexible....we will evolve the procedures, etc. as we go!

  * In the future, we may consider switching from Windows command line scripts to Python scripts, which can be run either from
    Windows OR on the Linux servers themselves
