===============================================================================
20170209 Data seeding into TEST for couple tickets, Release 1.0.0_10
===============================================================================

-------------------
Step 0: Run backup
-------------------

* Run a mongodump of the dmlesBuyer database first (safety measure)



-------------------
Step 1: DSE-643
-------------------

* dse643_importAdvice.cmd

    -- Runs import of data (Advice.json) into new dmlesBuyer.Advice collection



-------------------
Step 2: DSE-645
-------------------

* dse645_seedSignal.cmd

    -- Runs insert of data ito new dmlesBuyer.Signal collection (via call to dse645_seedSignal.js)

