// Seed new Signal collection in dmlesBuyer database


use dmlesBuyer


db.Signal.deleteMany({})


db.Signal.insert(
  {
    "_id" : ObjectId("589895d7d6d892cd638d7057"),
    "code" : "A",
    "description" : "Ship to requisitioner; Bill to requisitioner"
  }
)

db.Signal.insert(
  {
    "_id" : ObjectId("589895d7d6d892cd638d7058"),
    "code" : "B",
    "description" : "Ship to requisitioner; Bill to supplementary address"
  }
)

db.Signal.insert(
  {
    "_id" : ObjectId("589895d7d6d892cd638d7059"),
    "code" : "C",
    "description" : "Ship to requisitioner; Bill to fund code"
  }
)

db.Signal.insert(
  {
    "_id" : ObjectId("589895d7d6d892cd638d705a"),
    "code" : "D",
    "description" : "Ship to requisitioner; Free issue"
  }
)

db.Signal.insert(
  {
    "_id" : ObjectId("589895d7d6d892cd638d705b"),
    "code" : "J",
    "description" : "Ship to supplementary address; Bill to requisitioner"
  }
)

db.Signal.insert(
  {
    "_id" : ObjectId("589895d7d6d892cd638d705c"),
    "code" : "K",
    "description" : "Ship to supplementary address; Bill to supplementary address"
  }
)


db.Signal.insert(
  {
    "_id" : ObjectId("589895d7d6d892cd638d705d"),
    "code" : "L",
    "description" : "Ship to supplementary address; Bill to fund code"
  }
)

db.Signal.insert(
  {
    "_id" : ObjectId("589895d7d6d892cd638d705e"),
    "code" : "M",
    "description" : "Ship to supplementary address; Free issue"
  }
)


// Count to verify the inserts went in (should be 8)

db.Signal.count()
