===============================================================================
Roll to Test, 14-Mar-2017, DML-ES/LogiCole, version 1.0.0_14
===============================================================================


---------------------------------------
Tickets w/DB Changes rolling
---------------------------------------

* DSE-799:   Load Facilities Installation and Site data (new dmlesRealEstate database)

* DSE-861:   Load file manager data (new dmlesFilemanager database)



---------------------------------------
RUN ORDER
---------------------------------------

1.  Run dse799_loadDmlesRealEstate.cmd script

      -- Runs mongorestore to load/seed new dmlesRealEstate database with Installation and Site data (11 collections)


2.  Run dse861_loadDmlesFilemanager.cmd script

      -- Runs mongorestore to load/seed new dmlesFilemanager database (3 collections)


3.  Run dse736_loadDmlesInventory.cmd script

      -- Runs mongorestore to load/seed new dmlesInventory DB (2 collections)



---------------------------------------
HOW TO RUN the .cmd scripts
---------------------------------------

To run against your localhost DB:

  scriptName.cmd local n n


To run against the Dev DB:

  scriptName.cmd dev username password


To run against the Test DB:

  scriptName.cmd test username password

