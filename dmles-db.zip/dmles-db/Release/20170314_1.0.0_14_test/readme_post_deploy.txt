===============================================================================
Additional Steps taken for DB portion of version 1.0.0_14
===============================================================================


---------------------------------------
Tickets w/DB Changes rolling
---------------------------------------

* DSE-799:   Load Facilities Installation and Site data (new dmlesRealEstate database)

* DSE-861:   Load file manager data (new dmlesFilemanager database)



---------------------------------------
Additional Steps
---------------------------------------

1.  Added JSON schemas dmlesInventory.json and dmlesFilemanager.json files to dmles-db\MongoDBValidateStructure\Schemas

    -- Created these by reverse-engineering them against my localhost copy of the respective DBs

    -- That means these schemas get added to our nightly validation 


2.  Added dmlesInventory and dmleSFilemanager to the list of databases that copied in the following scrips:

       dmles-bt\Scripts\mongodumpDevDBs.cmd
       dmles-bt\Scripts\mongoLocalSeed.cmd

    -- That means these schemas get added to the script that developers use to seed their local DBs


3.  Added dmlesInventory.json and dmlesFilemanager.json to the JSON_SCHEMA_FILES parameter in the Jenkins jobs Dmles_MongoDB_Validate_Struc_Test and Dmles_MongoDB_Validate_Struct_Dev

    -- That means these schemas get added to our nightly validation 



