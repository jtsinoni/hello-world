print()
print()
print("===============================================================================")
print("dse1175: Seed Role records for Asset Mgt")
print("===============================================================================")
print()


use dmlesUser


print()
print("========================================================")
print("Pre-run query: count Role records")
print("========================================================")
print()

db.Role.count()


print()
print("========================================================")
print("Now run the inserts")
print("========================================================")
print()

db.Role.insert(
  {
    "_id" : ObjectId("58d95f1ac006bb0b53904067"),
    "className" : "dmles.user.server.datamodel.RoleDO",
    "name" : "DHA Asset Manager",
    "assignedPermissions" : [ 
        {
            "name" : "Manage Medical Equipment Assets",
            "allowed" : true,
            "permission" : {
                "$ref" : "Permission",
                "$id" : ObjectId("58d40f69e677ab3e446bd293")
            }
        }, 
        {
            "name" : "Manage RealProperty Installed Equipment Assets",
            "allowed" : true,
            "permission" : {
                "$ref" : "Permission",
                "$id" : ObjectId("58d9594c7eb51d29c0c6d863")
            }
        }
    ],
    "isActive" : true,
    "functionalArea" : "Other",
    "description" : "DHA Asset Manager - Asset Management",
    "systemRole" : false
  }
)

db.Role.insert(
  {
    "_id" : ObjectId("58d96ea2c006bb0b53904068"),
    "className" : "dmles.user.server.datamodel.RoleDO",
    "name" : "Site Medical Asset Manager",
    "assignedPermissions" : [ 
        {
            "name" : "Manage Medical Equipment Assets",
            "allowed" : true,
            "permission" : {
                "$ref" : "Permission",
                "$id" : ObjectId("58d40f69e677ab3e446bd293")
            }
        }
    ],
    "isActive" : true,
    "functionalArea" : "Other",
    "description" : "Site Medical Asset Manager - Asset Management",
    "systemRole" : false
  }
)

db.Role.insert(
  {
    "_id" : ObjectId("58d96f39c006bb0b53904069"),
    "className" : "dmles.user.server.datamodel.RoleDO",
    "name" : "Site Real Property Asset Manager",
    "assignedPermissions" : [ 
        {
            "name" : "Manage RealProperty Installed Equipment Assets",
            "allowed" : true,
            "permission" : {
                "$ref" : "Permission",
                "$id" : ObjectId("58d9594c7eb51d29c0c6d863")
            }
        }
    ],
    "isActive" : true,
    "functionalArea" : "Other",
    "description" : "Site Real Property Asset Manager - Asset Management",
    "systemRole" : false
  }
)


print()
print("========================================================")
print("Post-run QA query: count Role records")
print("========================================================")
print()

db.Role.count()


print()
print()
print()
