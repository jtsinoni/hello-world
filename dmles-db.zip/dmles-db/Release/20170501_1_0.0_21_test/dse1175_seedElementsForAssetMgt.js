print()
print()
print("===============================================================================")
print("dse1175: Seed Element records for Asset Mgt")
print("===============================================================================")
print()


use dmlesUser


print()
print("========================================================")
print("Pre-run query: count Element records")
print("========================================================")
print()

db.Element.count()


print()
print("========================================================")
print("Now run the inserts")
print("========================================================")
print()


db.Element.insert(
  {
    "_id" : ObjectId("58b6f73fb7dbdfcba2c606f3"),
    "name" : "asset-management-view"
  }
)

db.Element.insert(
  {
    "_id" : ObjectId("58b6f76cb7dbdfcba2c60715"),
    "name" : "asset-management-medical-equipment-view"
  }
)

db.Element.insert(
  {
    "_id" : ObjectId("58b6f76cb7dbdfcba2c60713"),
    "name" : "asset-management-main-view"
  }
)

db.Element.insert(
  {
    "_id" : ObjectId("58b6f76cb7dbdfcba2c60717"),
    "name" : "asset-management-real-property-installed-view"
  }
)

db.Element.insert(
  {
    "_id" : ObjectId("58f118be6cffda845ce4e240"),
    "name" : "asset-management-upload-cobie-file"
  }
)


print()
print("========================================================")
print("Post-run QA query: count Element records")
print("========================================================")
print()

db.Element.count()


print()
print()
print()
