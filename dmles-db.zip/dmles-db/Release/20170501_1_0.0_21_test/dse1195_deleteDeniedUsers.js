print()
print()
print("===============================================================================")
print("dse1195: Delete Denied Users from AppUserProfileRegistration")
print("===============================================================================")
print()

use dmlesUser


print()
print()
print("========================================================")
print("Initial queries of AppUserProfileRegistration" );
print("========================================================")

print()
print("Count Total recs in AppUserProfileRegistration")

db.AppUserProfileRegistration.count()


print()
print("Count Total recs where accessDeniedDate exists and is not null")

db.AppUserProfileRegistration.count( {$and: [ {accessDeniedDate: {$exists: true}}, {accessDeniedDate: {$ne: null}} ] } )


print()
print("Now look at the records themselves...")

db.AppUserProfileRegistration.find( {$and: [ {accessDeniedDate: {$exists: true}}, {accessDeniedDate: {$ne: null}} ] }, { _id: 1, accessDeniedDate: 1} )


print()
print()
print("========================================================")
print("Now delete them!" );
print("========================================================")

db.AppUserProfileRegistration.remove( {$and: [ {accessDeniedDate: {$exists: true}}, {accessDeniedDate: {$ne: null}} ] } )


print()
print("========================================================")
print("Post-run QA queries of AppUserProfileRegistration" );
print("========================================================")

print()
print("Count Total recs in AppUserProfileRegistration")

db.AppUserProfileRegistration.count()


print()
print("Count Total recs where accessDeniedDate exists and is not null")

db.AppUserProfileRegistration.count( {$and: [ {accessDeniedDate: {$exists: true}}, {accessDeniedDate: {$ne: null}} ] } )


print()
print("Now look at the records themselves...")

db.AppUserProfileRegistration.find( {$and: [ {accessDeniedDate: {$exists: true}}, {accessDeniedDate: {$ne: null}} ] }, { _id: 1, accessDeniedDate: 1} )


print()
print()
print()
