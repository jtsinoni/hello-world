===============================================================================
Roll to Test, 1-May-2017, LogiCole, Release 1.0.0_21
===============================================================================


---------------------------------------
Tickets w/Data Tier Changes rolling
---------------------------------------

* DSE-10:    Data update related to Attachments functionality (causes data model changes in dmlesEquipment)

* DSE-1118:  Update storage location and owner org references in storage records (dmlesInventory)
                -- Child of DSE-735
                -- Essentially a re-load/re-seed of dmlesInventory database

* DSE-1136:  Drops old multi-col index, creates 5 new single-col indexes on abiCatalogStaging

* DSE-1195:  Delete Denied Users from the DB (one-time Delete)...specifically, delete from dmlesUser.AppUserProfileRegistration

* DSE-1175:  Seeds new records into dmlesUser.Element, State, Permission and Role in support of Asset Management functionality

* DSE-1236:  Seeds new dmlesOrganization.DmlssHost collection

XXXXX* DBT-15:    Remove empty "consumer" field from DmlesOrganization.ServiceProvider ---->CANCELLED!!!  DO NOT DEPLOY IN THIS RELEASE!




---------------------------------------
RUN ORDER
---------------------------------------

-1   Run backup of DBs prior to deployment


0    Run pre-deploy QA queries

         cd qa_queries

         qaQueries.cmd <Environment> <username> <password>  > qaQueriesPreDeploy_<Environment>.log

         (Then navigate back up to deployment root dir)


1   Run dse10_updatesToDmlesEquipment.cmd script

      -- Seeds 2 new States, then adds them to 3 permissions


2   Run dse1118_reloadDmlesInventory.cmd script

      -- Reloads the 2 collections for the dmlesInventory database


3   Run dse1136_createNewAbiIndexes.cmd script

      -- Drops the 1 old index, creates the new ones


4   Run dse1195_deleteDeniedUsers.cmd script

      -- Deletes the denied users


5   Run dse1175_seedDataForAssetMgt.cmd script

      -- Seeds Element, State, Permission and Role records

           ---- NOTE:  some of the Element and State inserts may get rejected due to being dupes---all good!


6   Run dse1236_seedDmlssHost.cmd script

      -- Seeds new dmlesOrganization.DmlssHost collection


10   Run post-deploy QA queries

         cd qa_queries

         qaQueries.cmd <Environment> <username> <password>  > qaQueriesPostDeploy_<Environment>.log



11   Compare pre-deploy QA queries and post-deploy

         in Gitbash, go to qa_queries directory

         diff qaQueriesPreDeploy_<Environment>.log qaQueriesPostDeploy_<Environment>.log



12   Run "Validate Refs" Jenkins Job

      -- To verify that the data updates have not resulted in any broken Refs

      -- If any broken Refs found, remediate!   You may need to restore data from backup in order to "undo" the changes that were made.

          ---- The incidence of this can be minimized with proper testing ahead of time



13   Run "Validate Structure" Jenkins Job

      -- To verify that the Json Schema defs are up-to-date with the latest data structure changes

      -- If any inaccurracies found, fix the JSON schema ASAP (but that is NOT essential for the release deployment, just for nightly validation)
  


14   When Release is completely done, do the following:

      -- Run another backup of Dev and/or Test DBs


      -- Update the files for Developers' "static" update of their local MongoDB instances:

                X:\Software Engineering\DML-ES\MongoDB_Developer_Seed


      -- If new MongoDB database(s) have been added, or removed, then update the following scripts, in the dmles-bt project, accordingly:

                Scripts\mongoLocalSeed.cmd
                Scripts\mongodumpDevDbs.cmd
                Scripts\mongoexportAllDBsSample.cmd           


       -- If needed, run a new "export all data sample" for the data architects:

                Scripts\mongoexportAllDBsSample.cmd

                Zip results and save them to:  X:\Data Architecture Team\DML-ES DB Sample Data Import

  

---------------------------------------
HOW TO RUN the .cmd scripts
---------------------------------------

To run against your localhost DB:

    scriptName.cmd local n n


To run against the Dev DB:

    scriptName.cmd dev username password


To run against the Test DB:

    scriptName.cmd test username password


To output the results to a log file (recommended):

    Append this to your command:   > logfileName 2>&1 

    For example:

       scriptName.cmd local n n > logfile_local.log 2>&1

       scriptName.cmd dev  username password logfile_dev.log 2>&1

       scriptName.cmd test username password logfile_test.log 2>&1

