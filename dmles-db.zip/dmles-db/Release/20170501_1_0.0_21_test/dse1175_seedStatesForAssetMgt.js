print()
print()
print("===============================================================================")
print("dse1175: Seed State records for Asset Mgt")
print("===============================================================================")
print()


use dmlesUser


print()
print("========================================================")
print("Pre-run query: count State records")
print("========================================================")
print()

db.State.count()


print()
print("========================================================")
print("Now run the inserts")
print("========================================================")
print()


db.State.insert(
  {
    "_id" : ObjectId("58b6f7b5b7dbdfcba2c6075d"),
    "name" : "dmles.home.assetManagement.main"
  }
)

db.State.insert(
  {
    "_id" : ObjectId("58b6f7b5b7dbdfcba2c60761"),
    "name" : "dmles.home.assetManagement.realPropertyInstalled"
  }
)

db.State.insert(
  {
    "_id" : ObjectId("58b6f7b5b7dbdfcba2c6075b"),
    "name" : "dmles.home.assetManagement"
  }
)

db.State.insert(
  {
    "_id" : ObjectId("58b6f7b5b7dbdfcba2c6075f"),
    "name" : "dmles.home.assetManagement.medicalEquipment"
  }
)

db.State.insert(
  {
    "_id" : ObjectId("58f0f2606cffda845ce4e23f"),
    "name" : "dmles.home.assetManagement.realPropertyInstalled.uploadCobieFile"
  }
)


print()
print("========================================================")
print("Post-run QA query: count State records")
print("========================================================")
print()

db.State.count()


print()
print()
print()
