print()
print()
print("===============================================================================")
print("dse1175: Seed Permission records for Asset Mgt")
print("===============================================================================")
print()


use dmlesUser


print()
print("========================================================")
print("Pre-run query: count Permission records")
print("========================================================")
print()

db.Permission.count()


print()
print("========================================================")
print("Now run the inserts")
print("========================================================")
print()


db.Permission.insert(
  {
    "_id" : ObjectId("58d40f69e677ab3e446bd293"),
    "className" : "dmles.user.server.datamodel.PermissionDO",
    "name" : "Manage Medical Equipment Assets",
    "states" : [ 
        {
            "$ref" : "State",
            "$id" : ObjectId("58b6f7b5b7dbdfcba2c6075f")
        }, 
        {
            "$ref" : "State",
            "$id" : ObjectId("58b6f7b5b7dbdfcba2c6075b")
        }, 
        {
            "$ref" : "State",
            "$id" : ObjectId("58b6f7b5b7dbdfcba2c6075d")
        }
    ],
    "elements" : [ 
        {
            "$ref" : "Element",
            "$id" : ObjectId("58b6f76cb7dbdfcba2c60715")
        }, 
        {
            "$ref" : "Element",
            "$id" : ObjectId("58b6f76cb7dbdfcba2c60713")
        }, 
        {
            "$ref" : "Element",
            "$id" : ObjectId("58b6f73fb7dbdfcba2c606f3")
        }
    ],
    "functionalArea" : "Other",
    "description" : "Manage Medical Equipment Assets",
    "active" : true
  }
)

db.Permission.insert(
  {
    "_id" : ObjectId("58d9594c7eb51d29c0c6d863"),
    "className" : "dmles.user.server.datamodel.PermissionDO",
    "name" : "Manage RealProperty Installed Equipment Assets",
    "states" : [ 
        {
            "$ref" : "State",
            "$id" : ObjectId("58b6f7b5b7dbdfcba2c6075d")
        }, 
        {
            "$ref" : "State",
            "$id" : ObjectId("58b6f7b5b7dbdfcba2c60761")
        }, 
        {
            "$ref" : "State",
            "$id" : ObjectId("58b6f7b5b7dbdfcba2c6075b")
        }, 
        {
            "$ref" : "State",
            "$id" : ObjectId("58f0f2606cffda845ce4e23f")
        }
    ],
    "elements" : [ 
        {
            "$ref" : "Element",
            "$id" : ObjectId("58b6f73fb7dbdfcba2c606f3")
        }, 
        {
            "$ref" : "Element",
            "$id" : ObjectId("58b6f76cb7dbdfcba2c60713")
        }, 
        {
            "$ref" : "Element",
            "$id" : ObjectId("58b6f76cb7dbdfcba2c60717")
        }, 
        {
            "$ref" : "Element",
            "$id" : ObjectId("58f118be6cffda845ce4e240")
        }
    ],
    "functionalArea" : "Other",
    "description" : "Manage RealProperty Installed Equipment Assets",
    "active" : true
  }
)



print()
print("========================================================")
print("Post-run QA query: count Permission records")
print("========================================================")
print()

db.Permission.count()


print()
print()
print()
