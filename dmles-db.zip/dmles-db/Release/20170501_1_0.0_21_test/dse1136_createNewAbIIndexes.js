print()
print()
print("===============================================================================")
print("dse1136: Create new ABi Indexes (and drop old one)")
print("===============================================================================")
print()

use enterpriseCatalog


print()
print("========================================================")
print("Pre-run query: List indexes on abiCatalogStaging")
print("========================================================")

db.abiCatalogStaging.getIndexes()

print()
print("========================================================")
print("Now, drop old index")
print("========================================================")

db.abiCatalogStaging.dropIndex( "abiCatalogStaging_mmcProdId_catSrc_mergedTo_idx" )


print()
print("========================================================")
print("Next, create new indexes")
print("========================================================")


db.abiCatalogStaging.createIndex( 
  { 
    "mmcProductIdentifier" : 1
  },
  { 
    name: "abiCatalogStaging_mmcProdId_idx"
  }
)

db.abiCatalogStaging.createIndex( 
  { 
    "inUseFlag" : 1
  },
  { name: "abiCatalogStaging_inUseFlag_idx"}
)

db.abiCatalogStaging.createIndex( 
  { 
    "mergedTo": 1
  },
  { name: "abiCatalogStaging_mergedTo_idx"}
)

db.abiCatalogStaging.createIndex( 
  { 
    "catalogSource": 1
  },
  { name: "abiCatalogStaging_catalogSource_idx"}
)

db.abiCatalogStaging.createIndex( 
  { 
    "ndc" : 1
  },
  { name: "abiCatalogStaging_ndc_idx"}
)


print()
print("========================================================")
print("Post-run QA query: List indexes on abiCatalogStaging")
print("========================================================")

db.abiCatalogStaging.getIndexes()

print()
print()
print()
