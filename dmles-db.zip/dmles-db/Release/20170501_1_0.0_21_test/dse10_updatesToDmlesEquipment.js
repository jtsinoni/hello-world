print()
print()
print("===============================================================================")
print("dse10: Updates to dmlesEquipment related to file attachments functionality")
print("===============================================================================")
print()

use dmlesUser

print()
print()
print("========================")
print("Seed new State records")
print("========================")
print()

db.State.insert(
  {
    "_id" : ObjectId("58ffb85fcd6b89199a7d9465"),
    "name" : "dmles.home.equipment.request.myRequests.view.attachments"
  }
)

db.State.insert(
  {
    "_id" : ObjectId("58ffb868cd6b89199a7d9466"),
    "name" : "dmles.home.equipment.request.myRequests.view.notes"
  }
)

print()
print()
print("===============================================================================================================")
print("Add the new States to 3 Permissions (first pull, then push, to avoid creating dupes by mistake if run twice)")
print("===============================================================================================================")
print()


print()
print()
print("First, pulls...")
print()

db.Permission.update( 
  { _id: ObjectId("57728d844c08ed9af7596da7"),
    "name" : "All Permissions"
  },
  { $pull: 
            {'states': 
                { "$ref": "State",
                  "$id": ObjectId("58ffb85fcd6b89199a7d9465")
                }
            }
  },
  {upsert: false}
)

db.Permission.update( 
  { _id: ObjectId("57728d844c08ed9af7596da7"),
    "name" : "All Permissions"
  },
  { $pull: 
            {'states': 
                { "$ref": "State",
                  "$id": ObjectId("58ffb868cd6b89199a7d9466")
                }
            }
  },
  {upsert: false}
)

db.Permission.update( 
  { _id: ObjectId("5780174e768bbb531eecd255"),
    name : "View Equipment Requests"
  },
  { $pull: 
            {'states': 
                { "$ref": "State",
                  "$id": ObjectId("58ffb85fcd6b89199a7d9465")
                }
            }
  },
  {upsert: false}
)

db.Permission.update( 
  { _id: ObjectId("5780174e768bbb531eecd255"),
    name : "View Equipment Requests"
  },
  { $pull: 
            {'states': 
                { "$ref": "State",
                  "$id": ObjectId("58ffb868cd6b89199a7d9466")
                }
            }
  },
  {upsert: false}
)

db.Permission.update( 
  { _id: ObjectId("57800e6f768bbb531eecd247"),
    name : "Submit Equipment Requests"
  },
  { $pull: 
            {'states': 
                { "$ref": "State",
                  "$id": ObjectId("58ffb85fcd6b89199a7d9465")
                }
            }
  },
  {upsert: false}
)

db.Permission.update( 
  { _id: ObjectId("57800e6f768bbb531eecd247"),
    name : "Submit Equipment Requests"
  },
  { $pull: 
            {'states': 
                { "$ref": "State",
                  "$id": ObjectId("58ffb868cd6b89199a7d9466")
                }
            }
  },
  {upsert: false}
)


print()
print()
print("Now pushes...")
print()

db.Permission.update( 
  { _id: ObjectId("57728d844c08ed9af7596da7"),
    "name" : "All Permissions"
  },
  { $push: 
            {'states': 
                { "$ref": "State",
                  "$id": ObjectId("58ffb85fcd6b89199a7d9465")
                }
            }
  },
  {upsert: false}
)

db.Permission.update( 
  { _id: ObjectId("57728d844c08ed9af7596da7"),
    "name" : "All Permissions"
  },
  { $push: 
            {'states': 
                { "$ref": "State",
                  "$id": ObjectId("58ffb868cd6b89199a7d9466")
                }
            }
  },
  {upsert: false}
)

db.Permission.update( 
  { _id: ObjectId("5780174e768bbb531eecd255"),
    name : "View Equipment Requests"
  },
  { $push: 
            {'states': 
                { "$ref": "State",
                  "$id": ObjectId("58ffb85fcd6b89199a7d9465")
                }
            }
  },
  {upsert: false}
)

db.Permission.update( 
  { _id: ObjectId("5780174e768bbb531eecd255"),
    name : "View Equipment Requests"
  },
  { $push: 
            {'states': 
                { "$ref": "State",
                  "$id": ObjectId("58ffb868cd6b89199a7d9466")
                }
            }
  },
  {upsert: false}
)

db.Permission.update( 
  { _id: ObjectId("57800e6f768bbb531eecd247"),
    name : "Submit Equipment Requests"
  },
  { $push: 
            {'states': 
                { "$ref": "State",
                  "$id": ObjectId("58ffb85fcd6b89199a7d9465")
                }
            }
  },
  {upsert: false}
)

db.Permission.update( 
  { _id: ObjectId("57800e6f768bbb531eecd247"),
    name : "Submit Equipment Requests"
  },
  { $push: 
            {'states': 
                { "$ref": "State",
                  "$id": ObjectId("58ffb868cd6b89199a7d9466")
                }
            }
  },
  {upsert: false}
)


print()
print()
print("==================================================")
print("QA Queries to verify Perms have the new States")
print("==================================================")
print()

print("Permission records that have State dmles.home.equipment.request.myRequests.view.attachments")
print()
db.Permission.find( {'states.$id': ObjectId("58ffb85fcd6b89199a7d9465")}, {name: 1, _id: 1} )

print()
print("Permission records that have State dmles.home.equipment.request.myRequests.view.notes")
print()
db.Permission.find( {'states.$id': ObjectId("58ffb868cd6b89199a7d9466")}, {name: 1, _id: 1} )

print()
print()
print()
