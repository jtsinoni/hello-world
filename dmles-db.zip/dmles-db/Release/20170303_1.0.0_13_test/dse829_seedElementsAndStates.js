use dmlesUser


// Pre-seed query before seeding new Element records

db.Element.count()



// Run inserts

db.Element.insert(
  {
    "_id" : ObjectId("58b6f73fb7dbdfcba2c606f3"),
    "name" : "asset-management-view"
  }
)

db.Element.insert(
  {
    "_id" : ObjectId("58b6f76cb7dbdfcba2c60713"),
    "name" : "asset-management-main-view"
  }
)

db.Element.insert(
  {
    "_id" : ObjectId("58b6f76cb7dbdfcba2c60715"),
    "name" : "asset-management-medical-equipment-view"
  }
)

db.Element.insert(
  {
    "_id" : ObjectId("58b6f76cb7dbdfcba2c60717"),
    "name" : "asset-management-real-property-installed-view'"
  }
)


// Post-seed query after seeding new Element records

db.Element.count()





// Pre-seed query before seeding new State records

db.State.count()


// Run inserts

db.State.insert(
  {
    "_id" : ObjectId("58b6f7b5b7dbdfcba2c6075b"),
    "name" : "dmles.home.assetManagement"
  }
)

db.State.insert(
  {
    "_id" : ObjectId("58b6f7b5b7dbdfcba2c6075d"),
    "name" : "dmles.home.assetManagement.main"
  }
)

db.State.insert(
  {
    "_id" : ObjectId("58b6f7b5b7dbdfcba2c6075f"),
    "name" : "dmles.home.assetManagement.medicalEquipment"
  }
)

db.State.insert(
  {
    "_id" : ObjectId("58b6f7b5b7dbdfcba2c60761"),
    "name" : "dmles.home.assetManagement.realPropertyInstalled"
  }
)


// Post-seed query before seeding new State records

db.State.count()
