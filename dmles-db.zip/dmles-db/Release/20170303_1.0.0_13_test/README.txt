===================================================================
Roll to Test, 3-Mar-2017, DML-ES/LogiCole, version 1.0.0_13
===================================================================


-------------------------------
Tickets w/DB Changes rolling
-------------------------------

* DSE-829  Add States and Elements to dmlesUser DB


-------------------------------
TO RUN:
-------------------------------

1.  Run dse829_seedElementsAndStates.cmd script

  -- Seeds new records in dmlesUser Element and State collections  (4 recs into Element, followed by 4 recs into State)

