use dmlesUser


// Pre-run QA Queries

db.getCollection('Permission').find({'_id':ObjectId("581b91f541634110bff3d178")}, {_id: 1, functionalArea: 1})
db.getCollection('Permission').find({'_id':ObjectId("582c9144416327163402cb4f")}, {_id: 1, functionalArea: 1})
db.getCollection('Permission').find({'_id':ObjectId("581cbb1d4163a8d20bd7b121")}, {_id: 1, functionalArea: 1})
db.getCollection('Permission').find({'_id':ObjectId("58bdbe88a05dfc1f90e2f8f3")}, {_id: 1, functionalArea: 1})


// Run updates  (one of them being inserted, because record does not exist in Test)

db.getCollection('Permission').update({'_id':ObjectId("581b91f541634110bff3d178")},{$set:{'functionalArea':'Real_Estate'}})
db.getCollection('Permission').update({'_id':ObjectId("582c9144416327163402cb4f")},{$set:{'functionalArea':'Real_Estate'}})
db.getCollection('Permission').update({'_id':ObjectId("581cbb1d4163a8d20bd7b121")},{$set:{'functionalArea':'Catalog'}})
db.getCollection('Permission').update({'_id':ObjectId("58bdbe88a05dfc1f90e2f8f3")},{$set:{'functionalArea':'Inventory'}})


db.Permission.insert(
{
    "_id" : ObjectId("58bdbe88a05dfc1f90e2f8f3"),
    "className" : "dmles.user.server.datamodel.PermissionDO",
    "name" : "View Inventory",
    "states" : [ 
        {
            "$ref" : "State",
            "$id" : ObjectId("58a61778feb0cc1899977f77")
        }, 
        {
            "$ref" : "State",
            "$id" : ObjectId("58a617b7feb0cc1899977fa8")
        }, 
        {
            "$ref" : "State",
            "$id" : ObjectId("58a6179dfeb0cc1899977f92")
        }, 
        {
            "$ref" : "State",
            "$id" : ObjectId("58a6178afeb0cc1899977f84")
        }, 
        {
            "$ref" : "State",
            "$id" : ObjectId("58a617abfeb0cc1899977f9c")
        }, 
        {
            "$ref" : "State",
            "$id" : ObjectId("58a617c4feb0cc1899977fb2")
        }
    ],
    "elements" : [ 
        {
            "$ref" : "Element",
            "$id" : ObjectId("58a61835feb0cc189997800c")
        }, 
        {
            "$ref" : "Element",
            "$id" : ObjectId("58a61810feb0cc1899977fed")
        }, 
        {
            "$ref" : "Element",
            "$id" : ObjectId("58a61810feb0cc1899977feb")
        }, 
        {
            "$ref" : "Element",
            "$id" : ObjectId("58a61835feb0cc189997800a")
        }, 
        {
            "$ref" : "Element",
            "$id" : ObjectId("58a61835feb0cc189997800e")
        }
    ],
    "functionalArea" : "Inventory",
    "description" : "View Inventory"
}
)

// Post-run QA Queries

db.getCollection('Permission').find({'_id':ObjectId("581b91f541634110bff3d178")}, {_id: 1, functionalArea: 1})
db.getCollection('Permission').find({'_id':ObjectId("582c9144416327163402cb4f")}, {_id: 1, functionalArea: 1})
db.getCollection('Permission').find({'_id':ObjectId("581cbb1d4163a8d20bd7b121")}, {_id: 1, functionalArea: 1})
db.getCollection('Permission').find({'_id':ObjectId("58bdbe88a05dfc1f90e2f8f3")}, {_id: 1, functionalArea: 1})
