use dmlesSeller



// Pre-run QA Queries

db.getCollection('Seller').count({isConus: {$type: "string"}})

db.getCollection('Seller').find({isConus: {$type: "string"}}, {_id: 1, isConus: 1})



// Run the update

function getIsConus( inDoc ) {
    return inDoc.isConus;   
}

db.Seller.find( {isConus: {$type: "string"}}).forEach( function (doc) {
    if (getIsConus(doc) == "N") {
      print (getIsConus(doc) + "...will update to false")
      db.Seller.updateOne( {_id: doc._id}, {$set: {isConus: false}} ) 
    } else {
        if (getIsConus(doc) == "Y") {
            print (getIsConus(doc) + "...will update to true")
            db.Seller.updateOne( {_id: doc._id}, {$set: {isConus: true}} ) 
        }
    }
});



// Post-run QA Query (should return 0)

db.getCollection('Seller').count({isConus: {$type: "string"}})



// Post-run QA Query (should return the 4 rows that got updated/fixed)

db.getCollection('Seller').find(
    {_id: {$in: [ 
                  ObjectId("58c9913758d9c366ef96d2cd"), 
                  ObjectId("58c9913758d9c366ef96d2cf"), 
                  ObjectId("58c9913758d9c366ef96d2d1"), 
                  ObjectId("58c9913758d9c366ef96d2d5")
                ]
           } 
     }, {_id: 1, isConus: 1}
 )
