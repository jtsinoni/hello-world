use dmlesSeller


// Find record that has className populated; get rid of className

// Pre-run QA Queries

db.Seller.count({className: {$exists: true}}, {_id: 1, className: 1})



// Run the update

db.Seller.update( {}, {$unset: {className: 1}}, {multi: true} )



// Post-run QA Queries

db.Seller.count({className: {$exists: true}}, {_id: 1, className: 1})
