use dmlesSeller



// Pre-run QA Queries

db.Seller.find( {'contract.isPrimary': {$exists: true}}, {_id: 1,  'contract.isPrimary': 1})



// Run the update

function getIsPrimary( inDoc ) {
    return inDoc.contract.isPrimary;   
}

db.Seller.find( {'contract.isPrimary': {$type: "string"}}).forEach( function (doc) {
    if (getIsPrimary(doc) == "N") {
      print (getIsPrimary(doc) + "...will update to false")
      db.Seller.updateOne( {_id: doc._id}, {$set: {'contract.isPrimary': false}} ) 
    } else {
        if (getIsPrimary(doc) == "Y") {
            print (getIsPrimary(doc) + "...will update to true")
            db.Seller.updateOne( {_id: doc._id}, {$set: {'contract.isPrimary': true}} ) 
        }
    }
});



// Post-run QA Queries

db.Seller.find( {'contract.isPrimary': {$exists: true}}, {_id: 1,  'contract.isPrimary': 1})

