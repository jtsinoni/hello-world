use dmlesOrganization


print("=====================================================================")
print("Adding index to Node collection")
print("=====================================================================")

//db.getCollection('Node').createIndex( { nodeChain: 1 } )



db.getCollection('Node').createIndex( { nodeChain: 1 }, { name: "Node_nodeChain_idx" } )