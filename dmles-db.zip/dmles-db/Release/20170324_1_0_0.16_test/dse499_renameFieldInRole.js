use dmlesUser


// Pre-run queries

db.Role.count( {active: {$exists: true}} )

db.Role.count( {isActive: {$exists: true}} )


// Run the update to rename the field

db.getCollection('Role').updateMany({}, {$rename: {'active':'isActive'}})  



// Run update to set isActive to TRUE for all records

db.getCollection('Role').updateMany({}, {$set: {"isActive": true}})



// Post-run queries

db.Role.count( {active: {$exists: true}} )

db.Role.count( {isActive: {$exists: true}} )

db.Role.count( {isActive: true} )

