use dmlesUser


print("=====================================================================")
print("Element, State, Permission update related to Node")
print("=====================================================================")

//db.getCollection('Node').createIndex( { nodeChain: 1 } )



db.Element.insert(
  {
    "_id" : ObjectId("58d4460b4b8a4686c2c15ed5"),
    "name" : "organization-management"
  }
)


db.State.insert(
  {
    "_id" : ObjectId("58d445374b8a4686c2c15e36"),
    "name" : "dmles.home.admin.orgMng"
  }
)


db.Permission.insert(
  {
    "_id" : ObjectId("58d448574b8a4686c2c18419"),
    "name" : "Organization Management",
    "states" : [ 
        {
            "$ref" : "State",
            "$id" : ObjectId("58d445374b8a4686c2c15e36")
        }
    ],
    "elements" : [ 
        {
            "$ref" : "Element",
            "$id" : ObjectId("58d4460b4b8a4686c2c15ed5")
        }
    ],
    "functionalArea" : "Other",
    "description" : "Manage Organization Data",
    "active" : true
  }
)

