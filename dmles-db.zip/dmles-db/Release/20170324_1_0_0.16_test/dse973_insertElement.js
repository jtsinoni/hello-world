use dmlesUser



// Pre-run QA Query

db.Element.count( {_id: ObjectId("58cc3c374013ca63e024595e")} )



//Insert into Element collection
db.Element.insert(
  {
    "_id" : ObjectId("58cc3c374013ca63e024595e"),
    "name" : "edit-user-assigned-permissions"
  }
)



// Post-run QA Query (should find the 1 rec that was inserted)

db.Element.count( {_id: ObjectId("58cc3c374013ca63e024595e")} )
