use dmlesUser


// Pre-run queries

db.Permission.count( {active: {$exists: true}} )

db.Role.count( {active: true} )



// Run update to set active to TRUE for all records

db.getCollection('Permission').updateMany({}, {$set: {"active": true}})



// Post-run queries

db.Permission.count( {active: {$exists: true}} )

db.Permission.count( {active: true} )
