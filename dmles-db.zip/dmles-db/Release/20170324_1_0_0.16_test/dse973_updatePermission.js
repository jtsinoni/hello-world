use dmlesUser


// Pre-run QA Query of Permission collection
db.Permission.find({_id: ObjectId("58a77720d62fb82c803fa817")}).pretty()


//Update/Replace 1 record in Permission collection

db.Permission.update(
   { 
     "_id" : ObjectId("58a77720d62fb82c803fa817") 
   },
   {
    "_id" : ObjectId("58a77720d62fb82c803fa817"),
    "className" : "dmles.user.server.datamodel.PermissionDO",
    "name" : "Manage JMLFDC Data",
    "states" : [ 
        {
            "$ref" : "State",
            "$id" : ObjectId("57718452d0142fa833276e4a")
        }, 
        {
            "$ref" : "State",
            "$id" : ObjectId("57ade465a8ac2ac9a4fdc8d6")
        }, 
        {
            "$ref" : "State",
            "$id" : ObjectId("57ade4d4a8ac2ac9a4fdc8d7")
        }, 
        {
            "$ref" : "State",
            "$id" : ObjectId("57ade509a8ac2ac9a4fdc8d8")
        }, 
        {
            "$ref" : "State",
            "$id" : ObjectId("57ade55ea8ac2ac9a4fdc8d9")
        }, 
        {
            "$ref" : "State",
            "$id" : ObjectId("57ade595a8ac2ac9a4fdc8da")
        }, 
        {
            "$ref" : "State",
            "$id" : ObjectId("57ade5cda8ac2ac9a4fdc8db")
        }, 
        {
            "$ref" : "State",
            "$id" : ObjectId("57ade603a8ac2ac9a4fdc8dc")
        }, 
        {
            "$ref" : "State",
            "$id" : ObjectId("57718452d0142fa833276e4b")
        }, 
        {
            "$ref" : "State",
            "$id" : ObjectId("57718452d0142fa833276e4c")
        }, 
        {
            "$ref" : "State",
            "$id" : ObjectId("57718452d0142fa833276e58")
        }, 
        {
            "$ref" : "State",
            "$id" : ObjectId("57718452d0142fa833276e59")
        }, 
        {
            "$ref" : "State",
            "$id" : ObjectId("57718452d0142fa833276e50")
        }, 
        {
            "$ref" : "State",
            "$id" : ObjectId("57718452d0142fa833276e4d")
        }, 
        {
            "$ref" : "State",
            "$id" : ObjectId("57718452d0142fa833276e5a")
        }, 
        {
            "$ref" : "State",
            "$id" : ObjectId("57718452d0142fa833276e5b")
        }, 
        {
            "$ref" : "State",
            "$id" : ObjectId("57718452d0142fa833276e5c")
        }, 
        {
            "$ref" : "State",
            "$id" : ObjectId("57718452d0142fa833276e4e")
        }, 
        {
            "$ref" : "State",
            "$id" : ObjectId("58a733f2cffd1e02ddbc00af")
        }, 
        {
            "$ref" : "State",
            "$id" : ObjectId("58a733f2cffd1e02ddbc00ad")
        }, 
        {
            "$ref" : "State",
            "$id" : ObjectId("58a733f2cffd1e02ddbc00ae")
        }
    ],
    "elements" : [ 
        {
            "$ref" : "Element",
            "$id" : ObjectId("57ade6d8a8ac2ac9a4fdc8de")
        }, 
        {
            "$ref" : "Element",
            "$id" : ObjectId("57718452d0142fa833276e64")
        }, 
        {
            "$ref" : "Element",
            "$id" : ObjectId("57718452d0142fa833276e63")
        }, 
        {
            "$ref" : "Element",
            "$id" : ObjectId("57ed3f35f1f06ee0601ae1c2")
        }, 
        {
            "$ref" : "Element",
            "$id" : ObjectId("58a72b22cffd1e02ddbc00ac")
        }, 
        {
            "$ref" : "Element",
            "$id" : ObjectId("58cc3c374013ca63e024595e")
        }
    ],
    "functionalArea" : "Other",
    "description" : "Management of JMLFDC Data"
   }
)

// Post-run QA Query of Permission collection
db.Permission.find({_id: ObjectId("58a77720d62fb82c803fa817")}).pretty()
