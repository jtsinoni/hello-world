use dmlesUser

print()
print("=======================================================================================")
print("Pre-run QA Queries---count AppUserProfileRegistration recs")
print("   plus ones that contain appProfileType")
print("   plus ones where it is set to LOGISTICS")
print("=======================================================================================")
print()

db.AppUserProfileRegistration.count()

db.AppUserProfileRegistration.count( {appProfileType: {$exists: true}} )

db.AppUserProfileRegistration.count( {appProfileType: "LOGISTICS"} )


print()
print("=======================================================================================")
print("Run the update, add new column appProfileType to AppUserProfileRegistration")
print("=======================================================================================")
print()

db.AppUserProfileRegistration.find({}).forEach( function (doc) {
    db.AppUserProfileRegistration.updateOne( {_id: doc._id}, {$set: {"appProfileType" : "LOGISTICS"} } )
});



print()
print("=======================================================================================")
print("Post-run QA Queries---count AppUserProfileRegistration recs that contain appProfileType")
print("=======================================================================================")
print()

db.AppUserProfileRegistration.count()

db.AppUserProfileRegistration.count( {appProfileType: {$exists: true}} )

db.AppUserProfileRegistration.count( {appProfileType: "LOGISTICS"} )

print()
print()
print("ALL DONE!")
print()
