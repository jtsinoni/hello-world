use dmlesUser


db.Role.remove( {_id: ObjectId("57728d8d4c0868770213abd1")} )


db.Role.insert(
  {
    "_id" : ObjectId("57728d8d4c0868770213abd1"),
    "className" : "dmles.user.server.datamodel.RoleDO",
    "name" : "All Role",
    "assignedPermissions" : [ 
        {
            "name" : "All Permissions",
            "allowed" : true,
            "permission" : {
                "$ref" : "Permission",
                "$id" : ObjectId("57728d844c08ed9af7596da7")
            }
        }, 
        {
            "name" : "Manage User Profiles",
            "allowed" : true,
            "permission" : {
                "$ref" : "Permission",
                "$id" : ObjectId("57800a1e768bbb531eecd243")
            }
        }, 
        {
            "name" : "Manage User Roles",
            "allowed" : true,
            "permission" : {
                "$ref" : "Permission",
                "$id" : ObjectId("57800c60768bbb531eecd245")
            }
        }
    ],
    "functionalArea" : "Other",
    "description" : "Role that contains all roles",
    "systemRole" : false,
    "isActive" : true
  }
)
