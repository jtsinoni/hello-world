===============================================================================
Roll to Test, 24-Mar-2017, DML-ES/LogiCole, 1.0.0_16
===============================================================================


---------------------------------------
Tickets w/DB Changes rolling on 3/24
---------------------------------------

* DSE-954 (child of DSE-1044): 

       -- Re-load dmlesOrganization.Node collection, add new index to it, and add a dmlesUser.Element, State and Permission


* DSE-499:   

       -- Modifying dmlesUser.Role, renaming "active" to "isActive", and setting value to true for all records

       -- Updating dmlesUser.Permission, setting "active" to true for all records


* DSE-881: update AppUserProfileRegistration for Facilities

       -- Since we are not updating EXISTING records---only changing new records not yet written, no actual DB updates
          need to be run for this one--->only JSON schema updates to dmlesUser.json.
             

* DSE-973 (child of DSE-917):

       -- Insert new dmlesUser.Element record

       -- Update a dmlesUser.Permission record



----------------------------------------------
Tickets already rolled ahead of time, 3/21
----------------------------------------------

* DSE-975: dmlesUser small cleanup

    -- Rolled 3/21

* DSE-989 (child of DSE-929): add new dmlesUser.RoleFunctionalAreaConfig collection

    -- Rolled 3/21



---------------------------------------
RUN ORDER for 3/24 actual deploy
---------------------------------------

-1   Run backup of DBs prior to deployment


0    Run pre-deploy QA queries

         cd qa_queries

         qaQueries.cmd <Environment> <username> <password>  > qaQueriesPreDeploy_<Environment>.log


1    Run dse954_Node.cmd script

       -- It runs mongorestore of dmlesOrganization.Node collection, then calls a couple .js scripts


2    Run dse499_updateRoleAndPermission.cmd script

        -- It calls 2 .js scripts to do updates from Mongo shell


3    Run dse973_insertElementUpdatePerm.cmd script

        -- It calls 2 .js scripts to do updates from Mongo shell



10   Run post-deploy QA queries

         cd qa_queries

         qaQueries.cmd <Environment> <username> <password>  > qaQueriesPostDeploy_<Environment>.log


11   Compare pre-deploy QA queries and post-deploy

         in Gitbash, go to qa_queries directory

         diff qaQueriesPreDeploy_<Environment>.log qaQueriesPostDeploy_<Environment>.log


12   Verify that nightly "validate structure" Jenkins jobs are up-to-date w/latest correct JSON schemas

      -- Update of dmlesUser.json


13   Run "validate structure" and "validate refs" Jenkins jobs

      -- Just as a verification that all is kosher



---------------------------------------
HOW TO RUN the .cmd scripts
---------------------------------------

To run against your localhost DB:

  scriptName.cmd local n n


To run against the Dev DB:

  scriptName.cmd dev username password


To run against the Test DB:

  scriptName.cmd test username password

