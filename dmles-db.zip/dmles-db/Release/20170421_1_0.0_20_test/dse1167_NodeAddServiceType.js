print()
print()
print("===============================================================================")
print("dse1167: Add Service Provider Refs to Node Data")
print("===============================================================================")
print()

use dmlesOrganization


print()
print()
print("========================================================")
print("UPDATE ROOT Record")
print("========================================================")

print()
print("==================================")
print("Check")
print("==================================")

db.Node.find({parent: "", 'nodeTypeRef.id': "58efd64244c0a5e103d6f38a"}, {_id: 1, guid: 1, name: 1, serviceProviderRefs: 1}).sort({name: 1}).pretty()

print()
print("==================================")
print("Add Service Providers to Root")
print("==================================")

db.Node.update({ parent: "", 'nodeTypeRef.id': "58efd64244c0a5e103d6f38a", serviceProviderRef: {$exists:false}},
   { $set: {
            serviceProviderRefs: [
            {
                id: "58f514c785ff091493fa6f6a",
                name: "User Management"
            },
            {
                id: "58f514c785ff091493fa6f6c",
                name: "Role Management"
            },            
            {
                id: "58f514c785ff091493fa6f6e",
                name: "Node Management"
            }
            ]
        }
    },
  {
    multi:false
  }
)

print()
print("==================================")
print("Check Again")
print("==================================")

db.Node.find({parent: "", 'nodeTypeRef.id': "58efd64244c0a5e103d6f38a"}, {_id: 1, guid: 1, name: 1, serviceProviderRefs: 1}).sort({name: 1}).pretty()

print()
print()
print("========================================================")
print("UPDATE AGENCIES")
print("========================================================")

print()
print("==================================")
print("Check")
print("==================================")

db.Node.find({ 'nodeTypeRef.id': "58efd61944c0a5e103d6f362" }).pretty()

print()
print("=================================")
print("Add Service Providers to Agencies")
print("=================================")

db.Node.update({ 'nodeTypeRef.id': "58efd61944c0a5e103d6f362", serviceProviderRef: {$exists:false}},
   { $set: {
            serviceProviderRefs: [
            {
                id: "58f514c785ff091493fa6f6a",
                name: "User Management"
            },           
            {
                id: "58f514c785ff091493fa6f6e",
                name: "Node Management"
            }
            ]
        }
    },
  {
    multi:true
  }
)

print()
print("==================================")
print("Check Again")
print("==================================")

db.Node.find({ 'nodeTypeRef.id': "58efd61944c0a5e103d6f362" }).pretty()

print()
print()
print("========================================================")
print("UPDATE SERVICES")
print("========================================================")

print()
print("==================================")
print("Check")
print("==================================")

db.Node.find({'nodeTypeRef.id': "58efd64d44c0a5e103d6f397"}, {_id: 1, guid: 1, name: 1, serviceProviderRefs: 1}).sort({name: 1}).pretty()

print()
print("==================================")
print("Add Service Providers to Services")
print("==================================")

db.Node.update({ 'nodeTypeRef.id': "58efd64d44c0a5e103d6f397", serviceProviderRef: {$exists:false}},
   { $set: {
            serviceProviderRefs: [
            {
                id: "58f514c785ff091493fa6f6a",
                name: "User Management"
            },           
            {
                id: "58f514c785ff091493fa6f6e",
                name: "Node Management"
            }
            ]
        }
    },
  {
    multi:true
  }
)

print()
print("==================================")
print("Check Again")
print("==================================")

db.Node.find({'nodeTypeRef.id': "58efd64d44c0a5e103d6f397"}, {_id: 1, guid: 1, name: 1, serviceProviderRefs: 1}).sort({name: 1}).pretty()

print()
print()
print("========================================================")
print("UPDATE REGIONS")
print("========================================================")

print()
print("==================================")
print("Check")
print("==================================")

db.Node.count({'nodeTypeRef.id': "58efd65744c0a5e103d6f3a4"})

db.Node.count({'nodeTypeRef.id': "58efd65744c0a5e103d6f3a4", serviceProviderRefs: {$exists: true}})


print()
print("==================================")
print("Add Service Providers to Regions")
print("==================================")

db.Node.update({ 'nodeTypeRef.id': "58efd65744c0a5e103d6f3a4", serviceProviderRef: {$exists:false}},
   { $set: {
            serviceProviderRefs: [
            {
                id: "58f514c785ff091493fa6f6a",
                name: "User Management"
            },           
            {
                id: "58f514c785ff091493fa6f6e",
                name: "Node Management"
            }
            ]
        }
    },
  {
    multi:true
  }
)

print()
print("==================================")
print("Check Again")
print("==================================")

db.Node.count({'nodeTypeRef.id': "58efd65744c0a5e103d6f3a4"})

db.Node.count({'nodeTypeRef.id': "58efd65744c0a5e103d6f3a4", serviceProviderRefs: {$exists: true}})

db.Node.find({'nodeTypeRef.id': "58efd65744c0a5e103d6f3a4", serviceProviderRefs: {$exists: true}}, {_id: 1, guid: 1, name: 1, serviceProviderRefs: 1}).limit(3).pretty()



print()
print()
print("========================================================")
print("UPDATE SITES")
print("========================================================")

print()
print("==================================")
print("Check")
print("==================================")

db.getCollection('Node').count({isPrimaryHost: true, 'nodeTypeRef.id': "58efd83044c0a5e103d6f53f"})

db.getCollection('Node').count({isPrimaryHost: true, 'nodeTypeRef.id': "58efd83044c0a5e103d6f53f", serviceProviderRefs: {$exists: true}})


print()
print("==================================")
print("Add Service Providers to Sites")
print("==================================")

db.Node.update({ isPrimaryHost: true, 'nodeTypeRef.id': "58efd83044c0a5e103d6f53f", serviceProviderRef: {$exists:false}},
   { $set: {
            serviceProviderRefs: [
            {
                id: "58f514c785ff091493fa6f6a",
                name: "User Management"
            },
            {
                id: "58f514c785ff091493fa6f70",
                name: "Equipment Record"
            },
            {
                id: "58f514c785ff091493fa6f72",
                name: "Equipment Request"
            },
            {
                id: "58f514c785ff091493fa6f74",
                name: "Equipment Request Review"
            }       
            ]
        }
    },
  {
    multi:true
  }
)

print()
print("==================================")
print("Check Again")
print("==================================")

db.getCollection('Node').count({isPrimaryHost: true, 'nodeTypeRef.id': "58efd83044c0a5e103d6f53f"})

db.getCollection('Node').count({isPrimaryHost: true, 'nodeTypeRef.id': "58efd83044c0a5e103d6f53f", serviceProviderRefs: {$exists: true}})

db.getCollection('Node').find( {isPrimaryHost: true, 'nodeTypeRef.id': "58efd83044c0a5e103d6f53f", serviceProviderRefs: {$exists: true}}, {_id: 1, guid: 1, name: 1, serviceProviderRefs: 1}).limit(3).pretty()


print()
print()
print()
