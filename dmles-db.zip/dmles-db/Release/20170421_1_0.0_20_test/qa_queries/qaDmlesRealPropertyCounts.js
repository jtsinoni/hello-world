use dmlesRealProperty

show collections



db.AddressLookup.count()

db.AddressStreetPostDirection.count()

db.AddressStreetType.count()

db.CommandClaimant.count()

db.EpaRegion.count()

db.GsaRegion.count()

db.Installation.count()

db.MetroStatisticalArea.count()

db.OperationalStatus.count()

db.ReportingComponent.count()

db.Site.count()

