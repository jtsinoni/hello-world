use dmlesOrganization

show collections



db.Node.count()

db.NodeType.count()

db.ServiceProvider.count()

