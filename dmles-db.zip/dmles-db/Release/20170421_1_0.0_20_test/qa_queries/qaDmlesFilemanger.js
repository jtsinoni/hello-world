use dmlesFilemanager

show collections



db.Configuration.count()

db.FileManager.count()


