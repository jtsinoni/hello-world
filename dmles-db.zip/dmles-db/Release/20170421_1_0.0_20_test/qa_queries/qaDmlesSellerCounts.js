use dmlesSeller

show collections



db.Contract.count()

db.SellerOwnerNode.count()

db.SellerUserAccount.count()

db.Supplier.count()
