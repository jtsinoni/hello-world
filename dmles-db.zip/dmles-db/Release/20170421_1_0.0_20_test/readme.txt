===============================================================================
Roll to Test, 21-Apr-2017, DML-ES/LogiCole, Release 1.0.0_20
===============================================================================


---------------------------------------
Tickets w/Data Tier Changes rolling
---------------------------------------

* DSE-1070:  Update Roles, Permissions for RealEstate (RealProperty)  

* DSE-1156:  Changes to dmlesSeller database (new SellerOwnerNode collection)

* DSE-1163:  Remove Duplicate Roles

* DSE-1167:  Add Service Provider Refs to Node Data  

* DSE-1172:  Delete obsolete Element and State records related to ABi

* DSE-1173:  DT: Add Audit Fields to Roles and Permissions (JSON Schema changes ONLY---no scripting)




---------------------------------------
RUN ORDER
---------------------------------------

-1   Run backup of DBs prior to deployment


0    Run pre-deploy QA queries

         cd qa_queries

         qaQueries.cmd <Environment> <username> <password>  > qaQueriesPreDeploy_<Environment>.log

         (Then navigate back up to deployment root dir)


2   Run dse1070_insertNewUserDataForFM.cmd script

      -- Performs CRUD ops into dmlesUser.State, Element, Permission, Role, and AppUserProfile collection

      -- Basically a cleanup of FM-related data


3   Run dse1156_seedSellerOwnerNode.cmd script

      -- Via mongorestore, loads new SellerOwnerNode collection into the dmlesSeller DB

      -- In addition to reviewing script results, have a look in Robomongo to see the new collection


4   Run dse1163_deleteDupeRoles.cmd script

      -- Deletes duplicate versions of "DHA Subject Matter Expert" & "Service Subject Matter Expert" roles from dmlesUser.Role

      -- Performs CRUD ops on AppUserProfile records that have these roles

            ---- So they all end up with just the non-dupe, correct role


5   Run dse1167_NodeAddServiceType.cmd script

      -- Updates records in dmlesOrganization.Node

            ---- Adds serviceProviderRefs nested array to the records

                  ------ Root, Agency, Service, Region, and Site level nodes all get updated


6   Run dse1172_deleteElementsStatesForAbi.cmd script

      -- Runs deletes of obsolete dmlesUser.Element and State records

      -- Updates Permission records, removing $refs to the now-deleted Element and State records


6.5  Run broken Refs report against the DB to verify there are still no broken Refs after the 1172 script!





10   Run post-deploy QA queries

         cd qa_queries

         qaQueries.cmd <Environment> <username> <password>  > qaQueriesPostDeploy_<Environment>.log


11   Compare pre-deploy QA queries and post-deploy

         in Gitbash, go to qa_queries directory

         diff qaQueriesPreDeploy_<Environment>.log qaQueriesPostDeploy_<Environment>.log


12   Verify that nightly "validate structure" Jenkins jobs are up-to-date w/latest correct JSON schemas

       -- "Broken Refs" job already run with Step 6.5




---------------------------------------
HOW TO RUN the .cmd scripts
---------------------------------------

To run against your localhost DB:

  scriptName.cmd local n n


To run against the Dev DB:

  scriptName.cmd dev username password


To run against the Test DB:

  scriptName.cmd test username password

