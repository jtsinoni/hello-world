print()
print("===============================================================================")
print("dse1163 part 1: Dupe Service roles")
print()
print("Role: Service Subject Matter Expert")
print()
print("...Good _id: 588f53acc3a3041154d57fc8")
print("...Dupe _id: 58908c616b27cd08ec3bf57d")
print()
print("===============================================================================")
print()

use dmlesUser


print()
print("===============================================================================")
print("Query to show the dupe pair")
print("===============================================================================")
print()

db.getCollection('Role').find({name: {$in: ["Service Subject Matter Expert"]}}, {_id: 1, name: 1}).sort({name: 1, _id: 1})

print()
print("===============================================================================")
print("More in-depth for the Service Roles")
print("===============================================================================")
print()

print("Count AppUserProfiles that have either of the Service roles...")
db.AppUserProfile.count( {'roles.$id': {$in: [ObjectId("588f53acc3a3041154d57fc8"), ObjectId("58908c616b27cd08ec3bf57d")]}} )

print()
print()
print("Count AppUserProfiles that has the good Service role...")
db.AppUserProfile.count( {'roles.$id': {$in: [ObjectId("588f53acc3a3041154d57fc8")]}} )

print()
print()
print("Count AppUserProfiles that has the bad Service role...")
db.AppUserProfile.count( {'roles.$id': {$in: [ObjectId("58908c616b27cd08ec3bf57d")]}} )

print()
print()
print()
print("===============================================================================")
print("Now run the updates")
print("===============================================================================")
print()

print("Now update users have EITHER of the Service roles...remove BOTH roles, then grant the GOOD ONE only")
print()

db.AppUserProfile.find( {'roles.$id': {$in: [ObjectId("588f53acc3a3041154d57fc8"), ObjectId("58908c616b27cd08ec3bf57d")]}} ).forEach( function (doc) {
  print("Updating " + doc._id)
  db.AppUserProfile.update( 
    {_id: doc._id}, 
    {$pull: 
            {
             'roles': { $id: ObjectId("588f53acc3a3041154d57fc8") } 
            }
    },
    {multi: true}
  );
  db.AppUserProfile.update( 
    {_id: doc._id}, 
    {$pull: 
            {
             'roles': { $id: ObjectId("58908c616b27cd08ec3bf57d") } 
            }
    },
    {multi: true}
  );
  db.AppUserProfile.update( 
    {_id: doc._id}, 
    {$push: 
            {'roles': 
               { 
                 "$ref": "Role", 
                 "$id":  ObjectId("588f53acc3a3041154d57fc8")
               }
            }
    },
    {upsert: false}
  );
});


print()
print("Now delete the bad (dupe) Role record")
print()

db.Role.remove( {_id: ObjectId("58908c616b27cd08ec3bf57d")} )


print()
print()
print()
print("===============================================================================")
print("Post-run QA queries---check for the dupe pair")
print("===============================================================================")
print()

db.getCollection('Role').find({name: {$in: ["Service Subject Matter Expert"]}}, {_id: 1, name: 1}).sort({name: 1, _id: 1})

print()
print("===============================================================================")
print("Post-run QA queries---More in-depth for the Service Roles")
print("===============================================================================")
print("Count AppUserProfiles that have either of the Service roles...")
db.AppUserProfile.count( {'roles.$id': {$in: [ObjectId("588f53acc3a3041154d57fc8"), ObjectId("58908c616b27cd08ec3bf57d")]}} )

print()
print()
print("Count AppUserProfiles that has the good Service role...")
db.AppUserProfile.count( {'roles.$id': {$in: [ObjectId("588f53acc3a3041154d57fc8")]}} )

print()
print()
print("Count AppUserProfiles that has the bad Service role...")
db.AppUserProfile.count( {'roles.$id': {$in: [ObjectId("58908c616b27cd08ec3bf57d")]}} )


print()
print()
print()
