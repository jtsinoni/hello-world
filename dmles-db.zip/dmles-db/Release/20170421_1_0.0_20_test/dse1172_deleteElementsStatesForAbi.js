use dmlesUser


print("=================================================")
print("Initial QA queries")
print("=================================================")
print()

db.Element.count()
db.State.count()



print("=================================================")
print("Delete 1 obsolete Element record")
print("=================================================")
print()

db.Element.remove(
{
    "_id" : ObjectId("581cb8fe564b5f9f750d233e"),
    "name" : "enterprise-catalog"
})

print("=================================================")
print("Update Permission records w/refs to the Element")
print("=================================================")
print()

print("Count Perms that have the Element..")
print()

db.Permission.count( {'elements.$id': ObjectId("581cb8fe564b5f9f750d233e")} )

print()
print("Run update..." )
print()

db.Permission.update( 
   {'elements.$id': ObjectId("581cb8fe564b5f9f750d233e")} , 
   {$pull: {'elements': {'$id': ObjectId("581cb8fe564b5f9f750d233e")}}}, 
   {multi: true} 
)

print()
print("QA: Re-count perms that have the Element (should be 0)...")
print()

db.Permission.count( {'elements.$id': ObjectId("581cb8fe564b5f9f750d233e")} )
print()



print("=================================================")
print("Delete 9 obsolete State records")
print("=================================================")
print()

db.State.remove(
{
    "_id" : ObjectId("581cb968564b5f9f750d233f"),
    "name" : "dmles.home.enterpriseCatalog"
})

db.State.remove(
{
    "_id" : ObjectId("581cba0e564b5f9f750d2342"),
    "name" : "dmles.home.enterpriseCatalog.favs"
})

db.State.remove(
{
    "_id" : ObjectId("581cb9ae564b5f9f750d2340"),
    "name" : "dmles.home.enterpriseCatalog.search"
})

db.State.remove(
{
    "_id" : ObjectId("58a4aad6f1031a31972b291e"),
    "name" : "dmles.home.enterpriseCatalog.search.help"
})

db.State.remove(
{
    "_id" : ObjectId("588a09bdb7d8095cfb33fdce"),
    "name" : "dmles.home.enterpriseCatalog.search.itemComparison"
})

db.State.remove(
{
    "_id" : ObjectId("581cb9e4564b5f9f750d2341"),
    "name" : "dmles.home.enterpriseCatalog.search.details"
})

db.State.remove(
{
    "_id" : ObjectId("58a4aad6f1031a31972b291c"),
    "name" : "dmles.home.enterpriseCatalog.search.siteCatalogItems"
})

db.State.remove(
{
    "_id" : ObjectId("58a4aad6f1031a31972b291d"),
    "name" : "dmles.home.enterpriseCatalog.search.preferredProduct"
})

db.State.remove(
{
    "_id" : ObjectId("58acb031c8ea61084dd29a2d"),
    "name" : "dmles.home.enterpriseCatalog.search.sameSpDrugCode"
})



print("=================================================")
print("Update Permission records w/refs to the State")
print("=================================================")
print()

print("Count Perms that have the States..")
print()

db.Permission.count( 
   {'states.$id': 
      {$in: [ 
               ObjectId("581cb968564b5f9f750d233f"),    
               ObjectId("581cba0e564b5f9f750d2342"),
               ObjectId("581cb9ae564b5f9f750d2340"),
               ObjectId("58a4aad6f1031a31972b291e"),
               ObjectId("588a09bdb7d8095cfb33fdce"),
               ObjectId("581cb9e4564b5f9f750d2341"),
               ObjectId("58a4aad6f1031a31972b291c"),
               ObjectId("58a4aad6f1031a31972b291d"),
               ObjectId("58acb031c8ea61084dd29a2d")
            ]
      } 
   }
)

print()
print("Run update..." )
print()

db.Permission.update( 
   {'states.$id': ObjectId("581cb968564b5f9f750d233f")} , 
   {$pull: {'states': {'$id': ObjectId("581cb968564b5f9f750d233f")}}}, 
   {multi: true} 
)

db.Permission.update( 
   {'states.$id': ObjectId("581cba0e564b5f9f750d2342")} , 
   {$pull: {'states': {'$id': ObjectId("581cba0e564b5f9f750d2342")}}}, 
   {multi: true} 
)

db.Permission.update( 
   {'states.$id': ObjectId("581cb9ae564b5f9f750d2340")} , 
   {$pull: {'states': {'$id': ObjectId("581cb9ae564b5f9f750d2340")}}}, 
   {multi: true} 
)

db.Permission.update( 
   {'states.$id': ObjectId("58a4aad6f1031a31972b291e")} , 
   {$pull: {'states': {'$id': ObjectId("58a4aad6f1031a31972b291e")}}}, 
   {multi: true} 
)

db.Permission.update( 
   {'states.$id': ObjectId("588a09bdb7d8095cfb33fdce")} , 
   {$pull: {'states': {'$id': ObjectId("588a09bdb7d8095cfb33fdce")}}}, 
   {multi: true} 
)

db.Permission.update( 
   {'states.$id': ObjectId("581cb9e4564b5f9f750d2341")} , 
   {$pull: {'states': {'$id': ObjectId("581cb9e4564b5f9f750d2341")}}}, 
   {multi: true} 
)

db.Permission.update( 
   {'states.$id': ObjectId("58a4aad6f1031a31972b291c")} , 
   {$pull: {'states': {'$id': ObjectId("58a4aad6f1031a31972b291c")}}}, 
   {multi: true} 
)

db.Permission.update( 
   {'states.$id': ObjectId("58a4aad6f1031a31972b291d")} , 
   {$pull: {'states': {'$id': ObjectId("58a4aad6f1031a31972b291d")}}}, 
   {multi: true} 
)

db.Permission.update( 
   {'states.$id': ObjectId("58acb031c8ea61084dd29a2d")} , 
   {$pull: {'states': {'$id': ObjectId("58acb031c8ea61084dd29a2d")}}}, 
   {multi: true} 
)

print()
print("QA: Re-count perms that have the States (should be 0)...")
print()

db.Permission.count( 
   {'states.$id': 
      {$in: [ 
               ObjectId("581cb968564b5f9f750d233f"),    
               ObjectId("581cba0e564b5f9f750d2342"),
               ObjectId("581cb9ae564b5f9f750d2340"),
               ObjectId("58a4aad6f1031a31972b291e"),
               ObjectId("588a09bdb7d8095cfb33fdce"),
               ObjectId("581cb9e4564b5f9f750d2341"),
               ObjectId("58a4aad6f1031a31972b291c"),
               ObjectId("58a4aad6f1031a31972b291d"),
               ObjectId("58acb031c8ea61084dd29a2d")
            ]
      } 
   }
)


print("=================================================")
print("Post-run QA queries")
print("=================================================")
print()


db.Element.count()
db.State.count()


print(".....Run the Broken Refs report, Bubba!")

print()
print()
print()
