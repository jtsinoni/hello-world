print()
print()
print("===============================================================================")
print("dse1070: Seeding new Role, Perm, State, and Element recs for dmlesRealProperty")
print("...........and cleaning up the old junk")
print("===============================================================================")
print()

use dmlesUser

print()
print()
print("========================")
print("Seed new State record")
print("========================")
print()

db.State.insert(
{
    "_id" : ObjectId("58efb01e5fd7d42aeb8fff3c"),
    "name" : "dmles.home.realEstate.facilityView"
})


print()
print()
print("========================")
print("Seed new Element records")
print("========================")
print()

db.Element.insert( 
{
    "_id" : ObjectId("58efb02a5fd7d42aeb8fff41"),
    "name" : "real-estate-facilty-create"
})

db.Element.insert( 
{
    "_id" : ObjectId("58efb02a5fd7d42aeb8fff42"),
    "name" : "real-estate-facility-view"
})


print()
print()
print("===========================")
print("Seed new Permission record")
print("===========================")
print()

db.Permission.insert( 
{
    "_id" : ObjectId("58efb2f15fd7d42aeb8fff43"),
    "name" : "Manage Real Property Records",
    "states" : [ 
        {
            "$ref" : "State",
            "$id" : ObjectId("58b6f7b5b7dbdfcba2c60761")
        }, 
        {
            "$ref" : "State",
            "$id" : ObjectId("588a3e990b2259c5d38cd247")
        }, 
        {
            "$ref" : "State",
            "$id" : ObjectId("58efb01e5fd7d42aeb8fff3c")
        }, 
        {
            "$ref" : "State",
            "$id" : ObjectId("588a3e990b2259c5d38cd248")
        },
        {
            "$ref" : "State",
            "$id" : ObjectId("588a3e990b2259c5d38cd249")
        }
    ],
    "elements" : [ 
        {
            "$ref" : "Element",
            "$id" : ObjectId("58efb02a5fd7d42aeb8fff42")
        }, 
        {
            "$ref" : "Element",
            "$id" : ObjectId("58efb02a5fd7d42aeb8fff41")
        }, 
        {
            "$ref" : "Element",
            "$id" : ObjectId("58cc389d494f04cc5c44f320")
        },
        {
            "$ref" : "Element",
            "$id" : ObjectId("588a3e990b2259c5d38cd245")
        },

        {
            "$ref" : "Element",
            "$id" : ObjectId("58cc38a0494f04cc5c44f321")
        }, 
        {
            "$ref" : "Element",
            "$id" : ObjectId("588a3e990b2259c5d38cd246")
        }
    ],
    "functionalArea" : "Real_Estate",
    "description" : "View Facility Records",
    "active" : true
})



print()
print()
print("=================================================")
print("Add new Elements to the All Permissions record")
print("=================================================")
print()

db.Permission.update( {_id: ObjectId("57728d844c08ed9af7596da7"), name: "All Permissions"}, 
                      {$push: 
                           {
                             'elements': 
                                         { "$ref": "Element", 
                                           "$id":  ObjectId("58efb02a5fd7d42aeb8fff41")
                                         }
                           }
                      },
                      {upsert: false}
                    )

db.Permission.update( {_id: ObjectId("57728d844c08ed9af7596da7"), name: "All Permissions"}, 
                      {$push: 
                           {
                             'elements': 
                                         { "$ref": "Element", 
                                           "$id":  ObjectId("58efb02a5fd7d42aeb8fff42")
                                         }
                           }
                      },
                      {upsert: false}
                    )

print()
print()
print("========================")
print("Seed new Role record")
print("========================")
print()

db.Role.insert( 
{
    "_id" : ObjectId("58efb48c5fd7d42aeb8fff44"),
    "name" : "Real Property Manager",
    "assignedPermissions" : [ 
        {
            "name" : "Manage Real Property Records",
            "allowed" : true,
            "permission" : {
                "$ref" : "Permission",
                "$id" : ObjectId("58efb2f15fd7d42aeb8fff43")
            }
        }
    ],
    "isActive" : true,
    "functionalArea" : "Real Estate",
    "description" : "Manage Real Property Records",
    "systemRole" : false
})


print()
print()
print("====================================")
print("Delete obsolete Role records")
print("====================================")
print()

db.Role.remove( {_id: ObjectId("581b928441634110bff3d17b"), name: "DHA Facility Manager"} )

db.Role.remove( {_id: ObjectId("58cc50f4117fc4237fa7e06e"), name: "Real Estate Manager"} )


print()
print()
print("===========================================================")
print("Revoke obsolete Role from users...grant new role instead")
print("===========================================================")
print()

print("Count AppUserProfile recs that have the obsolete Roles...")
print()

db.AppUserProfile.count( {'roles.$id': {$in: [ObjectId("581b928441634110bff3d17b"), ObjectId("58cc50f4117fc4237fa7e06e")]}} )

print()
print("Update 1: add the new role to the AppUserProfile recs" )
print()

db.AppUserProfile.find( {'roles.$id': {$in: [ObjectId("581b928441634110bff3d17b"), ObjectId("58cc50f4117fc4237fa7e06e")]}} ).forEach( function (doc) {
  db.AppUserProfile.update( {_id: doc._id}, 
                            {$push: 
                                    {'roles': 
                                        { "$ref": "Role", 
                                          "$id":  ObjectId("58efb48c5fd7d42aeb8fff44")
                                        }
                                    }
                            },
                            {upsert: false}
  )
});

print()
print("Update 2: remove the obsolete roles from the AppUserProfile recs---gotta do them 1 at a time" )
print()

db.AppUserProfile.update( 
  {'roles.$id': ObjectId("581b928441634110bff3d17b")}, 
  {$pull: 
          {
             'roles': { $id: ObjectId("581b928441634110bff3d17b") } 
          }
  },
  {multi: true}
)

db.AppUserProfile.update( 
  {'roles.$id': ObjectId("58cc50f4117fc4237fa7e06e")}, 
  {$pull: 
          {
             'roles': { $id: ObjectId("58cc50f4117fc4237fa7e06e") } 
          }
  },
  {multi: true}
)

print()
print("QA 1: Count AppUserProfiles that have the new Role...should equal how many used to have the obsolete roles")
print()

db.AppUserProfile.count( {'roles.$id': ObjectId("58efb48c5fd7d42aeb8fff44")} )

print()
print("QA 2: Count AppUserProfiles that have the obsolete roles (should be 0)...")
print()

db.AppUserProfile.count( {'roles.$id': {$in: [ObjectId("581b928441634110bff3d17b"), ObjectId("58cc50f4117fc4237fa7e06e")]}} )



print()
print()
print("====================================")
print("Delete obsolete Permission records")
print("====================================")
print()

db.Permission.remove( {_id: ObjectId("581b91f541634110bff3d178"), name: "View Facility Records"} )

db.Permission.remove( {_id: ObjectId("582c9144416327163402cb4f")} )


print()
print()
print("=====================================================================")
print("Remove obsolete Permissions from Role record(s)")
print("   (NOTE: should be 1 Role record, 5818ad74ba8a0a189d5d618b)")
print("=====================================================================")
print()
print()

print("Count Roles that have the Perms...")
print()

db.Role.count( {'assignedPermissions.permission.$id' : {$in: [ObjectId("581b91f541634110bff3d178"), ObjectId("582c9144416327163402cb4f")] } } )

print()
print("Run update..." )
print()

db.Role.update(
  {'assignedPermissions.permission.$id' : {$in: [ObjectId("581b91f541634110bff3d178"), ObjectId("582c9144416327163402cb4f")] } },
  {$pull: {'assignedPermissions': {'permission.$id': {$in: [ObjectId("581b91f541634110bff3d178"), ObjectId("582c9144416327163402cb4f")] }}}},
  {multi: true}
)

print()
print("QA: Re-count Roles that have the Perm (should be 0)...")
print()

db.Role.count( {'assignedPermissions.permission.$id' : {$in: [ObjectId("581b91f541634110bff3d178"), ObjectId("582c9144416327163402cb4f")] } } )


print()
print()
print("====================================")
print("Delete obsolete State record")
print("====================================")
print()

db.State.remove( {_id: ObjectId("581b90c8564b5f9f750d233b"), name: "dmles.home.facilityManagement"} )


print()
print()
print("=====================================================================")
print("Remove obsolete State from Permission record(s)")
print("   (NOTE: should be 1 Permission record, 57728d844c08ed9af7596da7)")
print("=====================================================================")
print()
print()

print("Count Perms that have the State...")
print()

db.Permission.count( {'states.$id': ObjectId("581b90c8564b5f9f750d233b")} )

print()
print("Run update..." )
print()

db.Permission.update( 
   {'states.$id': ObjectId("581b90c8564b5f9f750d233b")}, 
   {$pull: {'states': {'$id': ObjectId("581b90c8564b5f9f750d233b")}}}, 
   {multi: true} 
)

print()
print("QA: Re-count perms that have the State (should be 0)...")
print()

db.Permission.count( { 'states.$id': ObjectId("581b90c8564b5f9f750d233b")} )
print()


print()
print()
print("====================================")
print("Delete obsolete Element record")
print("====================================")
print()

db.Element.remove( {_id: ObjectId("5819e4f3564b5f9f750d2337"), name: "facility-management"} )


print()
print()
print("=====================================================================")
print("Remove obsolete Element from Permission record(s)")
print("   (NOTE: should be 1 Permission record)")
print("=====================================================================")

print()
print("Count Perms that have the Element...")
print()

db.Permission.count({'elements.$id': ObjectId("5819e4f3564b5f9f750d2337")} )

print()
print("Run update..." )
print()

db.Permission.update( 
  {'elements.$id': ObjectId("5819e4f3564b5f9f750d2337")},
  {$pull: {'elements': {'$id': ObjectId("5819e4f3564b5f9f750d2337")}}}, 
  {multi: true}
)

print()
print("QA: Re-count perms that have the Element (should be 0)...")
print()

db.Permission.count({'elements.$id': ObjectId("5819e4f3564b5f9f750d2337")} )


print()
print()
print("========================================")
print("Fix Element record that has single quote")
print("========================================")
print()

db.Element.update( {"_id" : ObjectId("58b6f76cb7dbdfcba2c60717")}, {$set: {name: "asset-management-real-property-installed-view"}} )

print()
print("Query the updated record")
print()

db.getCollection('Element').find({_id: ObjectId("58b6f76cb7dbdfcba2c60717")})


print()
print()
print()
