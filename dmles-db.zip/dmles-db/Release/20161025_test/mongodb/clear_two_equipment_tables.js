use dmles-equipment

db.EquipmentRequests.deleteMany({})
db.EquipmentRequestWorkflowProcess.deleteMany({})
