===============================================================================
Roll to <Environment>, DD-Mon-YYYY, DML-ES/LogiCole, Release <ReleaseNumber>
===============================================================================


---------------------------------------
Tickets w/Data Tier Changes rolling
---------------------------------------

* DSE-NNN:   description.....

* DSE-NNN:   description.....

* DSE-NNN:   description.....



---------------------------------------
RUN ORDER
---------------------------------------


-1   Run backup of DBs prior to deployment


0    Run pre-deploy QA queries

         cd qa_queries

         qaQueries.cmd <Environment> <username> <password>  > qaQueriesPreDeploy_<Environment>.log

         (Then navigate back up to deployment root dir)


1   Run dseNNN_yadaYada.cmd script

      -- 


2   Run dseNNN_yadaYada.cmd script

      -- 


3   Run dseNNN_yadaYada.cmd script

      -- 



10   Run post-deploy QA queries

         cd qa_queries

         qaQueries.cmd <Environment> <username> <password>  > qaQueriesPostDeploy_<Environment>.log


11   Compare pre-deploy QA queries and post-deploy

         in Gitbash, go to qa_queries directory

         diff qaQueriesPreDeploy_<Environment>.log qaQueriesPostDeploy_<Environment>.log


12   Verify that nightly "validate structure" Jenkins jobs are up-to-date w/latest correct JSON schemas

      -- Update of dmlesUser.json


13   Run "validate structure" and "validate refs" Jenkins jobs

      -- Just as a verification that all is kosher



---------------------------------------
HOW TO RUN the .cmd scripts
---------------------------------------

To run against your localhost DB:

  scriptName.cmd local n n


To run against the Dev DB:

  scriptName.cmd dev username password


To run against the Test DB:

  scriptName.cmd test username password

