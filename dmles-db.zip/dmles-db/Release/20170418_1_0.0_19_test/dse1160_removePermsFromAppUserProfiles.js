print()
print()
print("===============================================================================")
print("dse1160: Remove assignedPermissions from AppUserProfile records")
print("===============================================================================")
print()

use dmlesUser

print()
print()
print("========================")
print("Pre-update queries")
print("========================")
print()

db.AppUserProfile.count()
db.AppUserProfile.count( {assignedPermissions: {$exists: true}} )

print()
print()
print("========================")
print("Run the update")
print("========================")
print()

db.AppUserProfile.update( {assignedPermissions: {$exists: true}},
                          {$unset: {assignedPermissions: 1}},
                          {multi: true}
)

print()
print()
print("==================================================================")
print("Post-update queries (should get 0 recs having assignedPermissions)")
print("==================================================================")
print()

db.AppUserProfile.count()
db.AppUserProfile.count( {assignedPermissions: {$exists: true}} )


print()
print()
print()
