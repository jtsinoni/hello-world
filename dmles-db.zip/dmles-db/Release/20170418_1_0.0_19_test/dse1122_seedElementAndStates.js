use dmlesUser


print("==================================")
print("Initial QA queries")
print("==================================")
print()

db.Element.count()
db.State.count()



print("==================================")
print("Run inserts")
print("==================================")
print()


db.Element.insert(
{
    "_id" : ObjectId("58ee8c2688ae4ff4dde04940"),
    "name" : "abi"
}
)




db.State.insert(
{
    "_id" : ObjectId("58ee8d97eebb3f623af8f382"),
    "name" : "dmles.home.abi"
}
)

db.State.insert(
{
    "_id" : ObjectId("58ee8d97eebb3f623af8f383"),
    "name" : "dmles.home.abi.search"
}
)

db.State.insert(
{
    "_id" : ObjectId("58ee8d97eebb3f623af8f384"),
    "name" : "dmles.home.abi.search.help"
}
)

db.State.insert(
{
    "_id" : ObjectId("58ee8d97eebb3f623af8f385"),
    "name" : "dmles.home.abi.search.preferredProduct"
}
)

db.State.insert(
{
    "_id" : ObjectId("58ee8d97eebb3f623af8f386"),
    "name" : "dmles.home.abi.search.productComparison"
}
)

db.State.insert(
{
    "_id" : ObjectId("58ee8d97eebb3f623af8f387"),
    "name" : "dmles.home.abi.search.productDetails"
}
)

db.State.insert(
{
    "_id" : ObjectId("58ee8d97eebb3f623af8f388"),
    "name" : "dmles.home.abi.search.sameProductGroup"
}
)

db.State.insert(
{
    "_id" : ObjectId("58ee8d97eebb3f623af8f389"),
    "name" : "dmles.home.abi.search.siteCatalogItems"
}
)



print("==================================")
print("Post-run QA queries")
print("==================================")
print()

db.Element.count()
db.State.count()

