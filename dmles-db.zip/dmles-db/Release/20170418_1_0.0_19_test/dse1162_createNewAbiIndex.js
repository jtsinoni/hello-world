use enterpriseCatalog


print("===================================================")
print("Create index on enterpriseCatalog.abiCatalogStaging")
print("===================================================")


db.abiCatalogStaging.createIndex( 
  { "mmcProductIdentifier" : 1,
    "catalogSource": 1,
    "mergedTo": 1
  },
  { name: "abiCatalogStaging_mmcProdId_catSrc_mergedTo_idx"}
)


print()
print()
print()
