use dmlesOrganization

print()
print("=============================================================")
print("Running updates to Node collection")
print("=============================================================")
print()


db.Node.update({ isPrimaryHost: true, nodeTypeRef: {$exists:false}},
   { $set: {
        nodeTypeRef: {
            id: "58efd83044c0a5e103d6f53f",
            name: "Site"
        }    }},
  {
    multi:true
  }
);

db.Node.update({ parent: "", nodeTypeRef: {$exists:false}},
   { $set: {
        nodeTypeRef: {
            id: "58efd64244c0a5e103d6f38a",
            name: "Root"
        }    }},
  {
    multi:false
  }
);

db.Node.update({ providerCode: "SVC", nodeTypeRef: {$exists:false}},
   { $set: {
        nodeTypeRef: {
            id: "58efd84244c0a5e103d6f553",
            name: "Customer"
        }    }},
  {
    multi:true
  }
);

db.Node.update({ providerCode: "DEPT", nodeTypeRef: {$exists:false}},
   { $set: {
        nodeTypeRef: {
            id: "58efd83b44c0a5e103d6f54b",
            name: "Department"
        }    }},
  {
    multi:true
  }
);

db.Node.update({parent: "1598305238624407B1D50552C27F739C", nodeTypeRef: {$exists:false}},
   { $set: {
        nodeTypeRef: {
            id: "58efd61944c0a5e103d6f362",
            name: "Agency"
        }    }},
  {
    multi:true
  }
);

db.Node.update({ providerCode: "BRNC",
    parent: { $in: ["CFB05B90C67E4467B3E00EE08A28E18C", "B70EAD7B31B147FD9C2B0DFED691F8B4"]},
    nodeTypeRef: {$exists:false}},
   { $set: {
        nodeTypeRef: {
            id: "58efd64d44c0a5e103d6f397",
            name: "Service"
        }    }},
  {
    multi:true
  }
);

db.Node.update({ providerCode: { $in: ["ORG","GRP"]},
    nodeTypeRef: {$exists:false}},
   { $set: {
        nodeTypeRef: {
            id: "58efd84a44c0a5e103d6f55a",
            name: "Organization"
        }    }},
  {
    multi:true
  }
);

db.Node.update( {providerCode: "BRNC",
    nodeTypeRef: {$exists:false}},
   { $set: {
        nodeTypeRef: {
            id: "58efd65744c0a5e103d6f3a4",
            name: "Region"
        }    }},
  {
    multi:true
  }
);



print()
print()
print()
