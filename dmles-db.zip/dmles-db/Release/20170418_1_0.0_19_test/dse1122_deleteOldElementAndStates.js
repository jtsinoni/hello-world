use dmlesUser


print("=================================================")
print("Initial QA queries")
print("=================================================")
print()

db.Element.count()
db.State.count()



print("=================================================")
print("Run deletes (1 Element record, 9 State records)")
print("=================================================")
print()

db.Element.remove(
{
    "name" : "enterprise-catalog"
})

db.State.remove(
{
        "name" : "dmles.home.enterpriseCatalog"
})

db.State.remove(
{
        "name" : "dmles.home.enterpriseCatalog.favs"
})

db.State.remove(
{
        "name" : "dmles.home.enterpriseCatalog.search"
})

db.State.remove(
{
        "name" : "dmles.home.enterpriseCatalog.search.help"
})

db.State.remove(
{
        "name" : "dmles.home.enterpriseCatalog.search.itemComparison"
})

db.State.remove(
{
        "name" : "dmles.home.enterpriseCatalog.search.details"
})

db.State.remove(
{
        "name" : "dmles.home.enterpriseCatalog.search.siteCatalogItems"
})

db.State.remove(
{
        "name" : "dmles.home.enterpriseCatalog.search.preferredProduct"
})

db.State.remove(
{
        "name" : "dmles.home.enterpriseCatalog.search.sameSpDrugCode"
})



print("=================================================")
print("Post-run QA queries")
print("=================================================")
print()

db.Element.count()
db.State.count()

print()
print()
print()
