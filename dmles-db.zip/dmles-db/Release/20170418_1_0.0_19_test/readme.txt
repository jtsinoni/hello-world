===============================================================================
Roll to Test, 18-Apr-2017, DML-ES/LogiCole, Release 1.0.0_19
===============================================================================


NOTE:   

Ran into problem with DSE-1122 ticket...it caused broken $refs in Test.

So, I restored dmlesUser.Element and dmlesUser.State from backup.

Then, I ran the INSERT portion of DSE-1122 ONLY.

And created a new DSE-1172 ticket to PROPERLY delete the old recs.


---------------------------------------
Tickets w/Data Tier Changes rolling
---------------------------------------

* DSE-626:   ABi changes: Seed new packageUnit collection

* DSE-1122:  ABi changes: Seed new Element and States, delete old ones

* DSE-1162:  ABi changes: Create index on abiCatalogStaging collection........................ALREADY DEPLOYED earlier on 4/18

* DSE-1151:  FM  changes: Rename dmlesRealEstate database to dmlesRealProperty

* DSE-1146:  Org changes: Update Node records.................................................ALREADY DEPLOYED Fri 4/14

* DSE-1161:  Org changes: Add ServiceProvider collection to dmlesOrganization.................ALREADY DEPLOYED earlier on 4/18

* DSE-1144:  Org changes: Create and Populate the Node Type Collection in dmlesOrganization...ALREADY DEPLOYED earlier on 4/18

* DSE-1160:  Remove ALL assignedPermissions from AppUserProfile records





---------------------------------------
RUN ORDER
---------------------------------------

-1   Run backup of DBs prior to deployment


0    Run pre-deploy QA queries

         cd qa_queries

         qaQueries.cmd <Environment> <username> <password>  > qaQueriesPreDeploy_<Environment>.log

         (Then navigate back up to deployment root dir)


1   Run dse626_seedPackageUnit.cmd script

      -- This does a mongorestore to load the new packageUnit collection into the enterpriseCatalog DB


2   Run dse1122_abiStuff.cmd script

      -- This seeds new dmlesUser Element and State records related to ABi, and deletes old records from those 2 tables as well


3   Run dse1151_pt1.cmd  script

      -- This creates/loads the new dmlesRealProperty database by restoring a backup made of the dmlesRealEstate database

      -- Verify that it ran correctly and the new DB was created


3.5  Run dse1151_pt2.cmd script

      -- This drops the now-obsolete dmlesRealEstate database



4   Run dse1060_removePermsFromAppuserProfiles.cmd script
 
      -- This updates all the AppUserProfile records that have ANY assignedPermissions....eliminates that field



10   Run post-deploy QA queries

         cd qa_queries

         qaQueries.cmd <Environment> <username> <password>  > qaQueriesPostDeploy_<Environment>.log


11   Compare pre-deploy QA queries and post-deploy

         in Gitbash, go to qa_queries directory

         diff qaQueriesPreDeploy_<Environment>.log qaQueriesPostDeploy_<Environment>.log


12   Verify that nightly "validate structure" Jenkins jobs are up-to-date w/latest correct JSON schemas

      -- Update of dmlesUser.json


13   Run "validate structure" and "validate refs" Jenkins jobs

      -- Just as a verification that all is kosher


14   Run "broken refs" check Jenkins job


---------------------------------------
HOW TO RUN the .cmd scripts
---------------------------------------

To run against your localhost DB:

  scriptName.cmd local n n


To run against the Dev DB:

  scriptName.cmd dev username password


To run against the Test DB:

  scriptName.cmd test username password

