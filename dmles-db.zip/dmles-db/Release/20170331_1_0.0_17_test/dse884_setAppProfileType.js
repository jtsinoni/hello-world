use dmlesUser


print()
print()
print("============================================================================================================")
print("DSE-884: set dmlesUser.AppUserProfile.appProfileType to 'LOGISTICS' for all recs where it is not populated")
print("============================================================================================================")
print()
print()

print()
print("QA Queries, pre-run")
print()

db.getCollection('AppUserProfile').count({})

db.getCollection('AppUserProfile').count({appProfileType: {$exists: true}})

db.getCollection('AppUserProfile').count( {appProfileType: "LOGISTICS"} )


print()
print("Run update")
print()

db.AppUserProfile.find({appProfileType: {$exists: false}}).forEach( function (doc) {  
    db.AppUserProfile.update( {_id: doc._id}, {$set: {appProfileType: "LOGISTICS"}} )
});



print()
print("QA Queries, post-run")
print()

db.getCollection('AppUserProfile').count({})

db.getCollection('AppUserProfile').count({appProfileType: {$exists: true}})

db.getCollection('AppUserProfile').count( {appProfileType: "LOGISTICS"} )
