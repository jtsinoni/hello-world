use dmlesEquipment


print()
print("Deleting existing EquipmentRequest and EquipmentRequestWorkflowProcess records")
print()

db.EquipmentRequest.deleteMany({})
db.EquipmentRequestWorkflowProcess.deleteMany({})


print()
print("Counting recs in table to QA...should be 0 recs in both")
print()

db.EquipmentRequest.count()

db.EquipmentRequestWorkflowProcess.count()

