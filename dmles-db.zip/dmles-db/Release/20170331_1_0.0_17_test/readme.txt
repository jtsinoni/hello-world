===============================================================================
Roll to TEST, 31-Mar-2017, DML-ES/LogiCole, Release 1.0.0_17
===============================================================================


---------------------------------------
Tickets w/Data Tier changes 
---------------------------------------

* DSE-884:   dmlesUser: Set appProfileType to "LOGISTICS" for all the AppUserProfile records where it is null

* DSE-791:   dmlesEquipment:  ReviewResponse collection being created, and deleting existing recs from EquipmentRequest & EquipmentRequestWOrkflowProcess

* DSE-1078:  dmlesEquipment:  reload EquipmentRequestWorkflowDefinition collection



---------------------------------------
RUN ORDER
---------------------------------------

-1   Run backup of DBs prior to deployment


0    Run pre-deploy QA queries

         cd qa_queries

         qaQueries.cmd <Environment> <username> <password>  > qaQueriesPreDeploy_<Environment>.log

         (Then navigate back up to deployment root dir)


1    Run dse884_setAppProfileType.cmd script

      -- Calls .js script to do the updates


2    Run dse791_1078_EquipmentChanges.cmd script

      -- Runs mongorestore to load new ReviewResponse collection

      -- Runs mongorestonre to re-load EquipmentRequestWorkflowDefinition collection

      -- Calls .js script to delete existing recs from EquipmentRequest & EquipmentRequestWOrkflowProcess


10   Run post-deploy QA queries

         cd qa_queries

         qaQueries.cmd <Environment> <username> <password>  > qaQueriesPostDeploy_<Environment>.log


11   Compare pre-deploy QA queries and post-deploy

         in Gitbash, go to qa_queries directory

         diff qaQueriesPreDeploy_<Environment>.log qaQueriesPostDeploy_<Environment>.log


12   Verify that nightly "validate structure" Jenkins jobs are up-to-date w/latest correct JSON schemas

      -- Update of dmlesUser.json


13   Run "validate structure" and "validate refs" Jenkins jobs

      -- Just as a verification that all is kosher




---------------------------------------
HOW TO RUN the .cmd scripts
---------------------------------------

To run against your localhost DB:

  scriptName.cmd local n n


To run against the Dev DB:

  scriptName.cmd dev username password


To run against the Test DB:

  scriptName.cmd test username password

