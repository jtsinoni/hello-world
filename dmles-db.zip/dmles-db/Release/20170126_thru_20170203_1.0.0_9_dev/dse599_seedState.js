// From Pat Scarborough, email request 1/26/2017, for DSE-599

use dmlesUser

db.State.insert(
  {  
    "name" : "dmles.home.enterpriseCatalog.search.itemComparison"
  }
)
