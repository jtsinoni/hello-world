use dmlesUser


// Check the dupes in State
//
//   The "good" one is 581b67ee564b5f9f750d233a
//   The "bad"  one is 5866a9fb38136b69ef9abe3a

db.getCollection('State').find({ name : "dmles.home.finance.landing"})


// Count Permissions records that have $refs pointing to these states

db.getCollection('Permission').count({'states.$id': ObjectId("581b67ee564b5f9f750d233a")})
db.getCollection('Permission').count({'states.$id': ObjectId("5866a9fb38136b69ef9abe3a")})



// First, replace the Permission record that points to the bad State record

db.Permission.remove({'states.$id': ObjectId("5866a9fb38136b69ef9abe3a")})


// Note: for insert, we are also getting rid of extra (dupe) $ref pointing to 5866a9fb38136b69ef9abe3e

db.Permission.insert(
  {
    "_id" : ObjectId("5866acb838136b69ef9ac3b1"),
    "name" : "View Appropriations",
    "states" : [ 
        {
            "$ref" : "State",
            "$id" : ObjectId("581c8b32564b5f9f750d233d")
        }, 
        {
            "$ref" : "State",
            "$id" : ObjectId("57718452d0142fa833276e47")
        }, 
        {
            "$ref" : "State",
            "$id" : ObjectId("581b67ee564b5f9f750d233a")
        }, 
        {
            "$ref" : "State",
            "$id" : ObjectId("5866a9fb38136b69ef9abe3c")
        }, 
        {
            "$ref" : "State",
            "$id" : ObjectId("5866a9fb38136b69ef9abe3e")
        },
        {
            "$ref" : "State",
            "$id" : ObjectId("5866a9fb38136b69ef9abe40")
        }
    ],
    "elements" : [],
    "functionalArea" : "Finance_Appropriations",
    "description" : "View Finance Appropriations"
  }
)




// Next, get rid of the bad State record

db.State.remove( {_id: ObjectId("5866a9fb38136b69ef9abe3a")} )




// Now, run post-update queries

db.getCollection('State').find({ name : "dmles.home.finance.landing"})


// Count Permissions records that have $refs pointing to these states

db.getCollection('Permission').count({'states.$id': ObjectId("581b67ee564b5f9f750d233a")})
db.getCollection('Permission').count({'states.$id': ObjectId("5866a9fb38136b69ef9abe3a")})


// Show the updated Permission record

db.Permission.find({_id: ObjectId("5866acb838136b69ef9ac3b1")} ).pretty()










