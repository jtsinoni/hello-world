use dmlesUser


// Pre-update check

db.State.find( {_id: {$in: [ObjectId("5866a9fb38136b69ef9abe40"), ObjectId("5866a9fb38136b69ef9abe3e"), ObjectId("5866a9fb38136b69ef9abe3c")]}} )



// Run updates

db.State.update( {"_id": ObjectId("5866a9fb38136b69ef9abe40")},  {"$set": {"name": "dmles.home.finance.appropriation.myappropriations.detail"}} )

db.State.update( {"_id" : ObjectId("5866a9fb38136b69ef9abe3e")}, {"$set": {"name": "dmles.home.finance.appropriation.myappropriations"}} ) 

db.State.update( {"_id" : ObjectId("5866a9fb38136b69ef9abe3c")}, {"$set": {"name": "dmles.home.finance.appropriation"}} )  



// Post-update check

db.State.find( {_id: {$in: [ObjectId("5866a9fb38136b69ef9abe40"), ObjectId("5866a9fb38136b69ef9abe3e"), ObjectId("5866a9fb38136b69ef9abe3c")]}} )
