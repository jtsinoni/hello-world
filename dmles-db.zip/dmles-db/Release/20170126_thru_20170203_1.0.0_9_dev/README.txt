=======================================================================================
20170126 - 20170203 Data seeding into Dev for various tickets, at request of developers
=======================================================================================



DSE-517
---------
* Script:  dse517_importAppropriation.cmd

* Imports data into a new dmlesFinance database (Appropriate and MaintAccount collections)

* From Jenna Hoopengardner




DSE-597
--------
* Script:  dse597_seedElementAndState.cmd

* Seeds data into dmlesUser database, Element and State collections

* From Tom Krotz




DSE-599
--------
* Script: dse599_seedState.cmd

* Seeds one record into dmlesUser database, State collection

* From Pat Scarborough




DSE-629 
---------
* Script:   dse629_importAppropConfig.cmd

* Imports data into a new AppropriationConfig collection in dmlesFinance 

* Ticket assigned to me, created by Rob Hayes




DSE-630
--------
* Script:   dse630_updateStateRecords.cmd

* Updates 3 records in dmlesUser database, State collection

* Ticket assigned to me, created by Rob Hayes




DSE-633
--------
* Script:   dse633_deleteDuplicateState.cmd

* Deletes dupe State record (logical dupe)

* Updates (actually deletes/replaces) Permission record so it no longer has a $ref that points to the dupe State




DSE-614
--------
* Script:   dse614_multiple.cmd

* Seed a couple of new Roles

* Deletes/Replaces one of the EquipmentRequestWorkflowDefinition records


