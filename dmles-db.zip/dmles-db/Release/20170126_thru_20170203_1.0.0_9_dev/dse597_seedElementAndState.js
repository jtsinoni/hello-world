// From Tom Krotz, email request 1/26/2017, for DSE-597


use dmlesUser


db.Element.insert(
  {
    "name" : "real-estate-installation-view"
  }
)

db.Element.insert(
  {
    "name" : "real-estate-site-view"
  }
)



db.State.insert(
  {
    "name" : "dmles.home.realEstate"
  }
)

db.State.insert(
  {
    "name" : "dmles.home.realEstate.installationView"
  }
)

db.State.insert(
  {
    "name" : "dmles.home.realEstate.siteView"
  }
)
