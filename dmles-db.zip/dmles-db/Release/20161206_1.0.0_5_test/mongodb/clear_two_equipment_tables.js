use dmles-equipment

db.EquipmentRequests.deleteMany({})
db.EquipmentRequest.deleteMany({})
db.EquipmentRequestWorkflowProcess.deleteMany({})


