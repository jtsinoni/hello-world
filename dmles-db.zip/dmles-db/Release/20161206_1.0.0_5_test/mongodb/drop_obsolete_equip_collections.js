use dmles-equipment

db.DeviceClass.drop()

db.EquipCriticality.drop()

db.EquipmentRequests.drop()

db.attachments.drop()

db.SiteEquipManufacturers.drop()


