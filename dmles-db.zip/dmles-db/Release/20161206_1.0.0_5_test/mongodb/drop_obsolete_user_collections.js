use dmles-user


db.Elements.drop()

db.Endpoints.drop()

db.Permissions.drop()

db.Roles.drop()

db.Sites.drop()

db.States.drop()

