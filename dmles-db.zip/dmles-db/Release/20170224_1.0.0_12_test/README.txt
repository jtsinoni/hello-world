===================================================================
Roll to Test, 24-Feb-2017, DML-ES/LogiCole, version 1.0.0_12
===================================================================


-------------------------------
Tickets w/DB Changes rolling
-------------------------------

* DSE-613  Edit ABi Staging record User Interface improvements
* DSE-631: Create Main Account Codes for FM
* DSE-693: Create dmleSFinance and dmlesBuyer JSON Schemas (which includes data cleanup)
* DSE-716: Prepare for early March demo (ABi)
* DSE-761: dmlesUser data cleanup



-------------------------------
TO RUN:
-------------------------------

1.  Run re-import of dmlesFinance.MainAccount collection from JSON file to Test database:

        dse631_693_reImportMainAccount.cmd



2.  Run restore of dmlesFinance.Appropriation collection (backed up from Dev)

        dse693_restoreAppropriation.cmd

 

3.  Dump 4 collections from Dev dmlesUser database and import them into Test.  (NOTE: this also pushes the DSE-613 and 716 changes).

    Collections include:  Role, Permission, Element, and State

 
        dse716_761_backupCollectionsFromDev.cmd     (run against Dev DB)

        dse716_761_restoreCollectionsToTest.cmd     (run against Test DB)


4.  Clean up any AppUserProfile records affected by the import/replacement of Role/Permission/Element/State

        dse761_cleanupAffectedAppUserProfile.cmd


5.  Run Jenkins jobs to check for valid structure, and to verify there are no broken refs
