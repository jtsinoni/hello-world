use dmlesUser


// ===============================================================================================
// Remove Undesirable Permission records (and delete $ref items in AppUerProfile accordingly)
// ===============================================================================================


// ---------------------
// Initial queries
// ---------------------

db.Permission.find( { name: {$in: [ "Create Equipment Requests From Catalog", 
                                    "Add Radiology Reviews", 
                                    "Manage Equipment Data", 
                                    "View Equipment Records2asdf"
                                  ]
                            }
                    }, 
                    {_id: 1, name: 1}
                  )


db.AppUserProfile.count()

db.AppUserProfile.count( {'assignedPermissions.permission.$id' : 
                               {$nin: [ 
                                       ObjectId("57b21beeb6c6ace31a223cbe"), 
                                       ObjectId("5818d6a6ba8a0a189d5d6190"), 
                                       ObjectId("578017d5768bbb531eecd257"), 
                                       ObjectId("5841b9e364a15370d5505ae9") 
                                     ] 
                               } 
                        }
                      )

db.AppUserProfile.count( {'assignedPermissions.permission.$id' : 
                               {$in: [ 
                                       ObjectId("57b21beeb6c6ace31a223cbe"), 
                                       ObjectId("5818d6a6ba8a0a189d5d6190"), 
                                       ObjectId("578017d5768bbb531eecd257"), 
                                       ObjectId("5841b9e364a15370d5505ae9") 
                                     ] 
                               } 
                        }
                      )


db.Role.count()

db.Role.count( {'assignedPermissions.permission.$id' : 
                               {$nin: [ 
                                       ObjectId("57b21beeb6c6ace31a223cbe"), 
                                       ObjectId("5818d6a6ba8a0a189d5d6190"), 
                                       ObjectId("578017d5768bbb531eecd257"), 
                                       ObjectId("5841b9e364a15370d5505ae9") 
                                     ] 
                               } 
                        }
                      )

db.Role.count( {'assignedPermissions.permission.$id' : 
                               {$in: [ 
                                       ObjectId("57b21beeb6c6ace31a223cbe"), 
                                       ObjectId("5818d6a6ba8a0a189d5d6190"), 
                                       ObjectId("578017d5768bbb531eecd257"), 
                                       ObjectId("5841b9e364a15370d5505ae9") 
                                     ] 
                               } 
                        }
                      )



// ---------------------------------------------------------------------------------
// Now delete the applicable permission $refs from within AppUserProfile collection
// ---------------------------------------------------------------------------------

db.getCollection('AppUserProfile').updateMany(
      { 'assignedPermissions.permission.$id': 
                   { $in: [ 
                             ObjectId("57b21beeb6c6ace31a223cbe"), 
                             ObjectId("5818d6a6ba8a0a189d5d6190"), 
                             ObjectId("578017d5768bbb531eecd257"), 
                             ObjectId("5841b9e364a15370d5505ae9") 
                          ] 
                   }
      },
      { $pull: 
            { assignedPermissions : 
                { 'permission.$id':
                         { $in: [ 
                                  ObjectId("57b21beeb6c6ace31a223cbe"), 
                                  ObjectId("5818d6a6ba8a0a189d5d6190"), 
                                  ObjectId("578017d5768bbb531eecd257"), 
                                  ObjectId("5841b9e364a15370d5505ae9") 
                                ] 
                         }
                }
            }
      },
      { multi: true }
)


// ---------------------------------------------------------------------------------
// Now delete the applicable permission $refs from within Role collection
// ---------------------------------------------------------------------------------

db.getCollection('Role').updateMany(
      { 'assignedPermissions.permission.$id': 
                   { $in: [ 
                             ObjectId("57b21beeb6c6ace31a223cbe"), 
                             ObjectId("5818d6a6ba8a0a189d5d6190"), 
                             ObjectId("578017d5768bbb531eecd257"), 
                             ObjectId("5841b9e364a15370d5505ae9") 
                          ] 
                   }
      },
      { $pull: 
            { assignedPermissions : 
                { 'permission.$id':
                         { $in: [ 
                                  ObjectId("57b21beeb6c6ace31a223cbe"), 
                                  ObjectId("5818d6a6ba8a0a189d5d6190"), 
                                  ObjectId("578017d5768bbb531eecd257"), 
                                  ObjectId("5841b9e364a15370d5505ae9") 
                                ] 
                         }
                }
            }
      },
      { multi: true }
)




// ---------------------------------------------------------------------------------
// Now delete the Permission records
// ---------------------------------------------------------------------------------

db.Permission.remove( { name: {$in: [ "Create Equipment Requests From Catalog", 
                                    "Add Radiology Reviews", 
                                    "Manage Equipment Data", 
                                    "View Equipment Records2asdf"
                                  ]
                            }
                    }
                  )



// ---------------------
// QA queries
// ---------------------

db.Permission.count( { name: {$in: [ "Create Equipment Requests From Catalog", 
                                    "Add Radiology Reviews", 
                                    "Manage Equipment Data", 
                                    "View Equipment Records2asdf"
                                  ]
                            }
                    }
                  )


db.AppUserProfile.count()

db.AppUserProfile.count( {'assignedPermissions.permission.$id' : 
                               {$nin: [ 
                                       ObjectId("57b21beeb6c6ace31a223cbe"), 
                                       ObjectId("5818d6a6ba8a0a189d5d6190"), 
                                       ObjectId("578017d5768bbb531eecd257"), 
                                       ObjectId("5841b9e364a15370d5505ae9") 
                                     ] 
                               } 
                        }
                      )

db.AppUserProfile.count( {'assignedPermissions.permission.$id' : 
                               {$in: [ 
                                       ObjectId("57b21beeb6c6ace31a223cbe"), 
                                       ObjectId("5818d6a6ba8a0a189d5d6190"), 
                                       ObjectId("578017d5768bbb531eecd257"), 
                                       ObjectId("5841b9e364a15370d5505ae9") 
                                     ] 
                               } 
                        }
                      )

db.Role.count()

db.Role.count( {'assignedPermissions.permission.$id' : 
                               {$nin: [ 
                                       ObjectId("57b21beeb6c6ace31a223cbe"), 
                                       ObjectId("5818d6a6ba8a0a189d5d6190"), 
                                       ObjectId("578017d5768bbb531eecd257"), 
                                       ObjectId("5841b9e364a15370d5505ae9") 
                                     ] 
                               } 
                        }
                      )

db.Role.count( {'assignedPermissions.permission.$id' : 
                               {$in: [ 
                                       ObjectId("57b21beeb6c6ace31a223cbe"), 
                                       ObjectId("5818d6a6ba8a0a189d5d6190"), 
                                       ObjectId("578017d5768bbb531eecd257"), 
                                       ObjectId("5841b9e364a15370d5505ae9") 
                                     ] 
                               } 
                        }
                      )
