use dmlesUser

// ===============================================================================================
// Remove "JMAR" record from Role collection (and delete $ref items in AppUerProfile accordingly)
// ===============================================================================================

// ---------------------
// Initial queries
// ---------------------

db.Role.find( {name: "JMAR"}, {_id: 1, name: 1})

db.AppUserProfile.count()

db.AppUserProfile.count( { 'roles.$id': {$nin: [ObjectId("57801d01768bbb531eecd25a")]} } )

db.AppUserProfile.count( { 'roles.$id': ObjectId("57801d01768bbb531eecd25a") } )


// ---------------------------------------------------------------------
// Now delete the JMAR role $refs from within AppUserProfile collection
// ---------------------------------------------------------------------

db.getCollection('AppUserProfile').updateMany(
      { 'roles.$id': ObjectId("57801d01768bbb531eecd25a") },
      { $pull: 
            { roles : 
                { '$id': ObjectId("57801d01768bbb531eecd25a") } 
            }
      },
      { multi: true }
)

// ---------------------------------------------------------------------
// Now delete the JMAR role from Role collection
// ---------------------------------------------------------------------

db.Role.remove( {name: "JMAR"} )


// ---------------------
// QA queries
// ---------------------

db.Role.count( {name: "JMAR"} )

db.AppUserProfile.count( { 'roles.$id': {$nin: [ObjectId("57801d01768bbb531eecd25a")]} } )

db.AppUserProfile.count( { 'roles.$id': ObjectId("57801d01768bbb531eecd25a") } )

