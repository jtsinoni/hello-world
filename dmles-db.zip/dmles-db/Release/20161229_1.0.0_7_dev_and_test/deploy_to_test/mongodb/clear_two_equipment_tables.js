use dmlesEquipment

db.EquipmentRequests.deleteMany({})
db.EquipmentRequestWorkflowProcess.deleteMany({})
