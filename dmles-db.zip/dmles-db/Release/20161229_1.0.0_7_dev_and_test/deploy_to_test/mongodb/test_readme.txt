==========================================================================================
Deploy Plan for DB Portion of DML-ES Deploy to Test, 29-Dec-2016
==========================================================================================

* Created by Dave Caglarcan, 12/29/2016



===================================================
Step 0:  pre-deploy backup 
===================================================

  * Run this BEFORE the actual deploy

  * Using the Jenkins jobs, run full backup of Test.   Verify it ran fine.



===================================================
Step 0.5:  Verify Dev deploy went fine
===================================================

  * Don't deploy to test until Dev looks good!



===================================================
Step 1:  deploy_pt1_backup_users_test.bat
===================================================

  * MongoDumps AppUserProfile and AppUserProfileRegistration collections out of test DB, for re-load later



===================================================
Step 2:  deploy_pt2_backups_dbs_from_dev.bat
===================================================

  * Performs mongodump from Dev, all 3 newly-named databases (dmlesEquipment, dmlesSystem, & dmlesUser)

  * Verify this ran fine



===================================================
Step 3:  deploy_pt3_restore_dbs_to_test.bat
===================================================

  * Performs mongorestore to restore the just-backed-up Dev databases (dmlesEquipment, dmlesSystem, & dmlesUser) to Test

  * Verify this ran fine



===================================================
Step 4:  deploy_pt4_restore_users_test.bat
===================================================

  * Performs mongorestore to restore the AppUserProfile & AppUserProfileRegistration collections that had earlier 
    been exported from Test...to Test

  * Verify this ran fine




===================================================
Step 5:  deploy_pt5_clear_equip_collections.bat
===================================================
  * Connects to Mongo shell (Test database), runs JavaScript file clear_two_equipment_tables.js, which:

      -- Deletes all records from 2 tables in dmles-equipment database: EquipmentRequests & EquipmentRequestWorkflowProcess

  * Verify this ran fine


 

===================================================
Step 6:  deploy_pt6_drop_old_dbs.bat
===================================================

  * Connects to MongoDB and runs .js script to drop the obsolete DBs
 
  * ONLY run this AFTER the app is up and running and working correctly...coord w/software engineers!

  * Afterward, verify that these DBs were dropped correctly




===================================
Step 7:  Script sanitization
===================================
  * Edit  the shell scripts...remove the username and password info!



