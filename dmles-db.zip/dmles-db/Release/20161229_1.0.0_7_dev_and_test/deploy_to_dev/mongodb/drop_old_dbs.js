use dmles-equipment

db.dropDatabase()


use dmles-user

db.dropDatabase()



use dmles-system

db.dropDatabase()



use dmles-facility

db.dropDatabase()



use dmles-internal

db.dropDatabase()

