==========================================================================================
Deploy Plan for DB Portion of DML-ES Deploy to Dev (followed by Test), 29-Dec-2016
==========================================================================================

* Created by Dave Caglarcan, 12/29/2016



===================================================
Step 0:  pre-deploy backup 
===================================================

  * Run this BEFORE the actual deploy
  * Using the Jenkins jobs, run full backup of Dev.   Verify it ran fine.


===================================================
Step 1:  deploy_pt1_create_new_dbs.bat
===================================================

  * This script exports out the old, incorrectly-named databases, and re-imports them into properly named databases

      -- dmles-equipment, dmles-system, dmles-user, dmles-internal & dmles-facility 
   
     --->dmlesEquipment,  dmlesSystem,  dmlesUser,  dmlesInternal, & dmlesFacility 


  * After running, do a quick check in RoboMongo to ensure the data looks correct



===================================================
Step 2:  Wait for Matt to deploy new code and test
===================================================


****** STOPPED HERE 20161229 13:37


===================================================
Step 3:  deploy_pt3_drop_old_dbs.bat
===================================================

  * Connects to MongoDB and runs .js script to drop the obsolete DBs
 
  * ONLY run this AFTER the app is up and running and working correctly...coord w/software engineers!

  * Afterward, verify that these DBs were dropped correctly




===================================
Step 4:  Script sanitization
===================================

  * Edit both of the shell scripts...remove the username and password info!
