==========================================================================================
Deploy Plan for DB Portion of DML-ES Deploy to Test, 12/16/2016
==========================================================================================
* Created by Dave Caglarcan, 12/16/2016



===================================
Step 0:  
===================================
  * Using the Jenkins jobs, run backups of both DBs (Dev and Test) just prior to deployment.  Verify they ran fine.


===================================
Step 1:  deploy_pt1.bat script
===================================
  * Export AppUserProfile and AppUserProfileRegistration collections out of test DB, for re-import



===================================
Step 2:  deploy_pt2.bat script
===================================
  * Performs mongodump from Dev, all 3 databases (dmles-equipment, dmles-system, & dmles-user)

  * Verify this ran fine


===================================
Step 3:  deploy_pt3.bat script
===================================
  * Performs mongorestore to restore the just-backed-up Dev databases (dmles-equipment, dmles-system, & dmles-user) to Test

  * Verify this ran fine


===================================
Step 4:  deploy_pt4.bat script
===================================
  * Performs mongorestore to restore the AppUserProfile & AppUserProfileRegistration collections that had earlier 
    been exported from Test...to Test

      -- This preserves the user profile data that the testers have already created in the Test environment
      -- In this case, the data (.json) for AppUserProfile was edited to conform to the new naming convention)

  * Verify this ran fine


===================================
Step 5:  deploy_pt5.bat script
===================================
  * Connects to Mongo shell (Test database), runs JavaScript file clear_two_equipment_tables.js, which:

      -- Deletes all records from 2 tables in dmles-equipment database: EquipmentRequests & EquipmentRequestWorkflowProcess

  * Verify this ran fine



===================================
Step 6:  Drop obsolete collections
         from Test DB
===================================
  * Look at the collections in the Test database

  * If needed, run the following scripts to drop obsolete collections (or portions thereof):

        drop_obsolete_equip_collections.js

        drop_obsolete_user_collections.js

