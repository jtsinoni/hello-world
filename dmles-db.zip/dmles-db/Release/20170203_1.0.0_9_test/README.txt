===============================================================================
20170203 Data seeding into TEST for bunch of tickets, Release 1.0.0_9
===============================================================================

Took backup of most Test DBs first---thank goodness I did!


DSE-517, DSE-629
-------------------

* Run a mongodump of the dmlesFinance database out of Dev

* Run a mongorestore of that database into Test

    -- Command I ended up using:

           mongorestore --ssl --host replDMLES01/dmetdb4001:27017,dmetdb4002:27017,dmetdb4003:27017 --sslAllowInvalidCertificates --sslAllowInvalidHostnames --authenticationDatabase "admin" -u dave.caglarcan -p nnnnnnnnnnnnnnnnn --db dmlesFinance --drop C:\Workspace\GitProjects\dmles-db\Release\20170203_test\20170203_replDMLES01_dmeddb3001_dmlesFinance\Data\mongodb_backups\dev\20170203\dmlesFinance




DSE-597, DSE-599, DSE-630, DSE-633, part of DSE-614 (Roles portion):
----------------------------------------------------------------------

* Run a mongodump of the dmlesUser database out of Dev

* Run a mongorestore of that database into Test

* Then, take the previous backup of Test, and restore just the AppUserProfile and AppUserProfileRegistration collections back into Test.

    -- Commands I ended up using:

           mongorestore --ssl --host replDMLES01/dmetdb4001:27017,dmetdb4002:27017,dmetdb4003:27017 --sslAllowInvalidCertificates --sslAllowInvalidHostnames --authenticationDatabase "admin" -u dave.caglarcan -p nnnnnnnnnnnnnnnnn --db dmlesUser  --collection AppUserProfile  --drop  C:\Workspace\GitProjects\dmles-db\Release\20170203_test\20170203_replDMLES01_dmetdb4001_dmlesUser\Data\mongodb_backups\test\20170203\dmlesUser\AppUserProfile.bson

           mongorestore --ssl --host replDMLES01/dmetdb4001:27017,dmetdb4002:27017,dmetdb4003:27017 --sslAllowInvalidCertificates --sslAllowInvalidHostnames --authenticationDatabase "admin" -u dave.caglarcan -p nnnnnnnnnnnnnnnnn --db dmlesUser  --collection AppUserProfileRegistration  --drop  C:\Workspace\GitProjects\dmles-db\Release\20170203_test\20170203_replDMLES01_dmetdb4001_dmlesUser\Data\mongodb_backups\test\20170203\dmlesUser\AppUserProfileRegistration.bson


* Also manually edited one of the AppUserProfile records, took out a broken $ref pointing to Permission

       -- db.getCollection('AppUserProfile').find({ 'assignedPermissions.permission.$id' : ObjectId("5780183b768bbb531eecd258") })


DSE-614
--------
* Script:   dse614_multiple.cmd

* Seed a couple of new Roles

* Deletes/Replaces one of the EquipmentRequestWorkflowDefinition records
