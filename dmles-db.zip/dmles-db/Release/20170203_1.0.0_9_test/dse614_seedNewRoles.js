use dmlesUser


// Pre-seed check (should find 0 records)

db.Role.count(  {_id: {$in: [ ObjectId("588f53acc3a3041154d57fc8"), ObjectId("588f53dbc3a3041154d57fcb")]}})




// Run inserts

db.Role.insert(
{
    "_id" : ObjectId("588f53acc3a3041154d57fc8"),
    "className" : "dmles.user.server.datamodel.RoleDO",
    "name" : "Service Subject Matter Expert",
    "assignedPermissions" : [ 
        {
            "name" : "Complete Subject Matter Review",
            "allowed" : true,
            "permission" : {
                "$ref" : "Permission",
                "$id" : ObjectId("586d1ae99422991d673049af")
            }
        }, 
        {
            "name" : "View Equipment Catalog",
            "allowed" : true,
            "permission" : {
                "$ref" : "Permission",
                "$id" : ObjectId("5780177a768bbb531eecd256")
            }
        }, 
        {
            "name" : "View Equipment Requests",
            "allowed" : true,
            "permission" : {
                "$ref" : "Permission",
                "$id" : ObjectId("5780174e768bbb531eecd255")
            }
        }
    ],
    "active" : false,
    "functionalArea" : "Equipment_Request",
    "description" : "They are an expert of a particular discipline.",
    "systemRole" : false
}
)



db.Role.insert(
{
    "_id" : ObjectId("588f53dbc3a3041154d57fcb"),
    "className" : "dmles.user.server.datamodel.RoleDO",
    "name" : "DHA Subject Matter Expert",
    "assignedPermissions" : [ 
        {
            "name" : "Complete Subject Matter Review",
            "allowed" : true,
            "permission" : {
                "$ref" : "Permission",
                "$id" : ObjectId("586d1ae99422991d673049af")
            }
        }, 
        {
            "name" : "View Equipment Catalog",
            "allowed" : true,
            "permission" : {
                "$ref" : "Permission",
                "$id" : ObjectId("5780177a768bbb531eecd256")
            }
        }, 
        {
            "name" : "View Equipment Requests",
            "allowed" : true,
            "permission" : {
                "$ref" : "Permission",
                "$id" : ObjectId("5780174e768bbb531eecd255")
            }
        }
    ],
    "active" : false,
    "functionalArea" : "Equipment_Request",
    "description" : "An expert in a particular discipline",
    "systemRole" : false
}
)




// Post-update check

db.Role.count(  {_id: {$in: [ ObjectId("588f53acc3a3041154d57fc8"), ObjectId("588f53dbc3a3041154d57fcb")]}})
