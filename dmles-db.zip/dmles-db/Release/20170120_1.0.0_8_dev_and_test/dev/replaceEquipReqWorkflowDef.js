use dmlesEquipment


db.EquipmentRequestWorkflowDefinition.remove({
    _id: ObjectId("576aa0f3a70faa3f68683c55")
})
db.EquipmentRequestWorkflowDefinition.remove({
    _id: ObjectId("57b71d4603e0fba04e9bba17")
})
db.EquipmentRequestWorkflowDefinition.remove({
    _id: ObjectId("576aa20ca70faa3f68683c57")
})
db.EquipmentRequestWorkflowDefinition.remove({
    _id: ObjectId("576aa205a70faa3f68683c56")
})
db.EquipmentRequestWorkflowDefinition.remove({
    _id: ObjectId("57b71d9603e0fba04e9bba18")
})


db.EquipmentRequestWorkflowDefinition.insert({
    "_id": ObjectId("576aa0f3a70faa3f68683c55"),
    "className": "dmles.equipment.server.datamodels.request.workflow.definition.WorkflowDefinitionDO",
    "name": "Air Force Workflow Definition",
    "service": "AF",
    "reviewResponses": [
        "Recommend Approve",
        "Note Concern",
        "Not Applicable"
    ],
    "levelDefinitions": [
        {
            "levelId": 0,
            "name": "Site",
            "userType": "SITE",
            "ownerRoleId": "57800f5d768bbb531eecd249",
            "rules": {
                "allowReviewBypassOnApprove": false,
                "allowReviewSelection": true,
                "allowForceUp": true,
                "allowAutoApproveAfterReview": true,
                "allowModify": true,
                "allowReject": true,
                "allowHold": true,
                "allowRework": false,
                "allowRequestCancel": false,
                "allowCancel": true,
                "allowOwnerOverrideNegativeReviews": true,
                "allowRetract": true,
                "allowNoteConcern": false
            },
            "levelDefinitionReviews": [
                {
                    "elementName": "equip-request-technology",
                    "roleId": "57800f96768bbb531eecd24a",
                    "reviewDisplayName": "Site Equipment Technology"
                },
                {
                    "elementName": "equip-request-maintenance",
                    "roleId": "57800fba768bbb531eecd24b",
                    "reviewDisplayName": "Site Equipment Maintenance"
                },
                {
                    "elementName": "equip-request-facilities",
                    "roleId": "57800fc5768bbb531eecd24c",
                    "reviewDisplayName": "Site Equipment Facilities"
                },
                {
                    "elementName": "equip-request-safety",
                    "roleId": "57800fe5768bbb531eecd24d",
                    "reviewDisplayName": "Site Equipment Safety"
                }
            ]
        },
        {
            "levelId": 1,
            "name": "Regional",
            "userType": "SERVICEREGION",
            "ownerRoleId": "57bf493c03e0fba04e9bba1e",
            "rules": {
                "allowReviewBypassOnApprove": true,
                "allowReviewSelection": true,
                "allowForceUp": true,
                "allowAutoApproveAfterReview": false,
                "allowModify": false,
                "allowReject": true,
                "allowHold": true,
                "allowRework": true,
                "allowRequestCancel": false,
                "allowCancel": true,
                "allowOwnerOverrideNegativeReviews": true,
                "allowRetract": true,
                "allowNoteConcern": false
            },
            "levelDefinitionReviews": [
                {
                    "elementName": "equip-request-technology",
                    "roleId": "57800f96768bbb531eecd24a",
                    "reviewDisplayName": "Region Equipment Technology"
                },
                {
                    "elementName": "equip-request-maintenance",
                    "roleId": "57800fba768bbb531eecd24b",
                    "reviewDisplayName": "Region Equipment Maintenance"
                },
                {
                    "elementName": "equip-request-facilities",
                    "roleId": "57800fc5768bbb531eecd24c",
                    "reviewDisplayName": "Region Equipment Facilities"
                },
                {
                    "elementName": "equip-request-safety",
                    "roleId": "57800fe5768bbb531eecd24d",
                    "reviewDisplayName": "Region Equipment Safety"
                }
            ],
            "levelCriteria": {
                "totalCost": 10000,
                "catalogItems": [
                    {
                        "catalogID": "6665015214676",
                        "catalogName": "ANALYZER HAZARDOUS MATERIAL ID COMMAND"
                    }
                ],
                "devices": [
                    {
                        "deviceCode": "C0067",
                        "deviceName": "Medical Waste Equipment, Eto, Emissions Control System"
                    }
                ]
            }
        },
        {
            "levelId": 2,
            "name": "Service",
            "userType": "SERVICE",
            "ownerRoleId": "57bf4a5303e0fba04e9bba23",
            "rules": {
                "allowReviewBypassOnApprove": true,
                "allowReviewSelection": true,
                "allowForceUp": true,
                "allowAutoApproveAfterReview": false,
                "allowModify": false,
                "allowReject": true,
                "allowHold": true,
                "allowRework": true,
                "allowRequestCancel": false,
                "allowCancel": true,
                "allowOwnerOverrideNegativeReviews": true,
                "allowRetract": true,
                "allowNoteConcern": false
            },
            "levelDefinitionReviews": [
                {
                    "elementName": "equip-request-technology",
                    "roleId": "57800f96768bbb531eecd24a",
                    "reviewDisplayName": "Service Equipment Technology"
                },
                {
                    "elementName": "equip-request-maintenance",
                    "roleId": "57800fba768bbb531eecd24b",
                    "reviewDisplayName": "Service Equipment Maintenance"
                }
            ],
            "levelCriteria": {
                "totalCost": 20000
            }
        },
        {
            "levelId": 3,
            "name": "DHA",
            "userType": "GLOBAL",
            "ownerRoleId": "57bf4ad903e0fba04e9bba28",
            "rules": {
                "allowReviewBypassOnApprove": true,
                "allowReviewSelection": true,
                "allowForceUp": false,
                "allowAutoApproveAfterReview": false,
                "allowModify": false,
                "allowReject": true,
                "allowHold": true,
                "allowRework": true,
                "allowRequestCancel": false,
                "allowCancel": true,
                "allowOwnerOverrideNegativeReviews": true,
                "allowRetract": false,
                "allowNoteConcern": false
            },
            "levelDefinitionReviews": [
                {
                    "elementName": "equip-request-technology",
                    "roleId": "57800f96768bbb531eecd24a",
                    "reviewDisplayName": "DHA Equipment Technology"
                }
            ],
            "levelCriteria": {
                "totalCost": 30000
            }
        }
    ],
    "active": true,
    "version": "0.0.11",
    "dateCreated": ISODate("2016-07-14T22:00:36.706Z"),
    "dateUpdated": ISODate("2016-10-07T06:26:20.201Z"),
    "effectiveDate": ISODate("2016-10-07T06:26:20.201Z"),
    "updatedBy": "site.all.123"
})

db.EquipmentRequestWorkflowDefinition.insert({
    "_id": ObjectId("57b71d4603e0fba04e9bba17"),
    "className": "dmles.equipment.server.datamodels.request.workflow.definition.WorkflowDefinitionDO",
    "name": "Defense Health Agency Workflow Definition",
    "service": "DHA",
    "reviewResponses": [
        "Recommend Approve",
        "Note Concern",
        "Not Applicable"
    ],
    "levelDefinitions": [
        {
            "levelId": 0,
            "name": "Site",
            "userType": "SITE",
            "ownerRoleId": "57800f5d768bbb531eecd249",
            "rules": {
                "allowReviewBypassOnApprove": false,
                "allowReviewSelection": true,
                "allowForceUp": true,
                "allowAutoApproveAfterReview": false,
                "allowModify": true,
                "allowReject": true,
                "allowHold": true,
                "allowRework": false,
                "allowRequestCancel": false,
                "allowCancel": true,
                "allowOwnerOverrideNegativeReviews": true,
                "allowRetract": true,
                "allowNoteConcern": false
            },
            "levelDefinitionReviews": [
                {
                    "elementName": "equip-request-technology",
                    "roleId": "57800f96768bbb531eecd24a",
                    "reviewDisplayName": "Site Equipment Technology"
                },
                {
                    "elementName": "equip-request-maintenance",
                    "roleId": "57800fba768bbb531eecd24b",
                    "reviewDisplayName": "Site Equipment Maintenance"
                },
                {
                    "elementName": "equip-request-facilities",
                    "roleId": "57800fc5768bbb531eecd24c",
                    "reviewDisplayName": "Site Equipment Facilities"
                },
                {
                    "elementName": "equip-request-safety",
                    "roleId": "57800fe5768bbb531eecd24d",
                    "reviewDisplayName": "Site Equipment Safety"
                }
            ]
        },
        {
            "levelId": 1,
            "name": "Regional",
            "userType": "SERVICEREGION",
            "ownerRoleId": "57bf493c03e0fba04e9bba1e",
            "rules": {
                "allowReviewBypassOnApprove": true,
                "allowReviewSelection": true,
                "allowForceUp": true,
                "allowAutoApproveAfterReview": false,
                "allowModify": false,
                "allowReject": true,
                "allowHold": true,
                "allowRework": true,
                "allowRequestCancel": false,
                "allowCancel": true,
                "allowOwnerOverrideNegativeReviews": true,
                "allowRetract": true,
                "allowNoteConcern": false
            },
            "levelDefinitionReviews": [
                {
                    "elementName": "equip-request-technology",
                    "roleId": "57800f96768bbb531eecd24a",
                    "reviewDisplayName": "Region Equipment Technology"
                },
                {
                    "elementName": "equip-request-maintenance",
                    "roleId": "57800fba768bbb531eecd24b",
                    "reviewDisplayName": "Region Equipment Maintenance"
                },
                {
                    "elementName": "equip-request-facilities",
                    "roleId": "57800fc5768bbb531eecd24c",
                    "reviewDisplayName": "Region Equipment Facilities"
                },
                {
                    "elementName": "equip-request-safety",
                    "roleId": "57800fe5768bbb531eecd24d",
                    "reviewDisplayName": "Region Equipment Safety"
                }
            ],
            "levelCriteria": {
                "totalCost": 10000
            }
        },
        {
            "levelId": 2,
            "name": "Service",
            "userType": "SERVICE",
            "ownerRoleId": "57bf4a5303e0fba04e9bba23",
            "rules": {
                "allowReviewBypassOnApprove": true,
                "allowReviewSelection": true,
                "allowForceUp": true,
                "allowAutoApproveAfterReview": false,
                "allowModify": false,
                "allowReject": true,
                "allowHold": true,
                "allowRework": true,
                "allowRequestCancel": false,
                "allowCancel": true,
                "allowOwnerOverrideNegativeReviews": true,
                "allowRetract": true,
                "allowNoteConcern": false
            },
            "levelDefinitionReviews": [
                {
                    "elementName": "equip-request-technology",
                    "roleId": "57800f96768bbb531eecd24a",
                    "reviewDisplayName": "Service Equipment Technology"
                },
                {
                    "elementName": "equip-request-maintenance",
                    "roleId": "57800fba768bbb531eecd24b",
                    "reviewDisplayName": "Service Equipment Maintenance"
                }
            ],
            "levelCriteria": {
                "totalCost": 20000
            }
        },
        {
            "levelId": 3,
            "name": "DHA",
            "userType": "GLOBAL",
            "ownerRoleId": "57bf4ad903e0fba04e9bba28",
            "rules": {
                "allowReviewBypassOnApprove": true,
                "allowReviewSelection": true,
                "allowForceUp": false,
                "allowAutoApproveAfterReview": false,
                "allowModify": false,
                "allowReject": true,
                "allowHold": true,
                "allowRework": true,
                "allowRequestCancel": false,
                "allowCancel": true,
                "allowOwnerOverrideNegativeReviews": true,
                "allowRetract": false,
                "allowNoteConcern": false
            },
            "levelDefinitionReviews": [
                {
                    "elementName": "equip-request-technology",
                    "roleId": "57800f96768bbb531eecd24a",
                    "reviewDisplayName": "DHA Equipment Technology"
                }
            ],
            "levelCriteria": {
                "totalCost": 30000
            }
        }
    ],
    "active": true,
    "version": "0.0.10",
    "dateCreated": ISODate("2016-08-19T22:10:53.706Z"),
    "dateUpdated": ISODate("2016-10-07T06:26:20.201Z"),
    "effectiveDate": ISODate("2016-10-07T06:26:20.201Z"),
    "updatedBy": "site.all.123"
})

db.EquipmentRequestWorkflowDefinition.insert({
    "_id": ObjectId("576aa20ca70faa3f68683c57"),
    "className": "dmles.equipment.server.datamodels.request.workflow.definition.WorkflowDefinitionDO",
    "name": "Navy Workflow Definition",
    "service": "DN",
    "reviewResponses": [
        "Recommend Approve",
        "Note Concern",
        "Not Applicable"
    ],
    "levelDefinitions": [
        {
            "levelId": 0,
            "name": "Site",
            "userType": "SITE",
            "ownerRoleId": "57800f5d768bbb531eecd249",
            "rules": {
                "allowReviewBypassOnApprove": false,
                "allowReviewSelection": true,
                "allowForceUp": true,
                "allowAutoApproveAfterReview": false,
                "allowModify": true,
                "allowReject": true,
                "allowHold": true,
                "allowRework": false,
                "allowRequestCancel": false,
                "allowCancel": true,
                "allowOwnerOverrideNegativeReviews": true,
                "allowRetract": true,
                "allowNoteConcern": false
            },
            "levelDefinitionReviews": [
                {
                    "elementName": "equip-request-technology",
                    "roleId": "57800f96768bbb531eecd24a",
                    "reviewDisplayName": "Site Equipment Technology"
                },
                {
                    "elementName": "equip-request-maintenance",
                    "roleId": "57800fba768bbb531eecd24b",
                    "reviewDisplayName": "Site Equipment Maintenance"
                },
                {
                    "elementName": "equip-request-facilities",
                    "roleId": "57800fc5768bbb531eecd24c",
                    "reviewDisplayName": "Site Equipment Facilities"
                },
                {
                    "elementName": "equip-request-safety",
                    "roleId": "57800fe5768bbb531eecd24d",
                    "reviewDisplayName": "Site Equipment Safety"
                }
            ]
        },
        {
            "levelId": 1,
            "name": "Regional",
            "userType": "SERVICEREGION",
            "ownerRoleId": "57bf493c03e0fba04e9bba1e",
            "rules": {
                "allowReviewBypassOnApprove": true,
                "allowReviewSelection": true,
                "allowForceUp": true,
                "allowAutoApproveAfterReview": false,
                "allowModify": false,
                "allowReject": true,
                "allowHold": true,
                "allowRework": true,
                "allowRequestCancel": false,
                "allowCancel": true,
                "allowOwnerOverrideNegativeReviews": true,
                "allowRetract": true,
                "allowNoteConcern": false
            },
            "levelDefinitionReviews": [
                {
                    "elementName": "equip-request-technology",
                    "roleId": "57800f96768bbb531eecd24a",
                    "reviewDisplayName": "Region Equipment Technology"
                },
                {
                    "elementName": "equip-request-maintenance",
                    "roleId": "57800fba768bbb531eecd24b",
                    "reviewDisplayName": "Region Equipment Maintenance"
                },
                {
                    "elementName": "equip-request-facilities",
                    "roleId": "57800fc5768bbb531eecd24c",
                    "reviewDisplayName": "Region Equipment Facilities"
                },
                {
                    "elementName": "equip-request-safety",
                    "roleId": "57800fe5768bbb531eecd24d",
                    "reviewDisplayName": "Region Equipment Safety"
                }
            ],
            "levelCriteria": {
                "totalCost": 10000
            }
        },
        {
            "levelId": 2,
            "name": "Service",
            "userType": "SERVICE",
            "ownerRoleId": "57bf4a5303e0fba04e9bba23",
            "rules": {
                "allowReviewBypassOnApprove": true,
                "allowReviewSelection": true,
                "allowForceUp": true,
                "allowAutoApproveAfterReview": false,
                "allowModify": false,
                "allowReject": true,
                "allowHold": true,
                "allowRework": true,
                "allowRequestCancel": false,
                "allowCancel": true,
                "allowOwnerOverrideNegativeReviews": true,
                "allowRetract": true,
                "allowNoteConcern": false
            },
            "levelDefinitionReviews": [
                {
                    "elementName": "equip-request-technology",
                    "roleId": "57800f96768bbb531eecd24a",
                    "reviewDisplayName": "Service Equipment Technology"
                },
                {
                    "elementName": "equip-request-maintenance",
                    "roleId": "57800fba768bbb531eecd24b",
                    "reviewDisplayName": "Service Equipment Maintenance"
                }
            ],
            "levelCriteria": {
                "totalCost": 20000
            }
        },
        {
            "levelId": 3,
            "name": "DHA",
            "userType": "GLOBAL",
            "ownerRoleId": "57bf4ad903e0fba04e9bba28",
            "rules": {
                "allowReviewBypassOnApprove": true,
                "allowReviewSelection": true,
                "allowForceUp": false,
                "allowAutoApproveAfterReview": false,
                "allowModify": false,
                "allowReject": true,
                "allowHold": true,
                "allowRework": true,
                "allowRequestCancel": false,
                "allowCancel": true,
                "allowOwnerOverrideNegativeReviews": true,
                "allowRetract": false,
                "allowNoteConcern": false
            },
            "levelDefinitionReviews": [
                {
                    "elementName": "equip-request-technology",
                    "roleId": "57800f96768bbb531eecd24a",
                    "reviewDisplayName": "DHA Equipment Technology"
                }
            ],
            "levelCriteria": {
                "totalCost": 30000
            }
        }
    ],
    "active": true,
    "version": "0.0.17",
    "dateCreated": ISODate("2016-07-14T22:00:36.706Z"),
    "dateUpdated": ISODate("2016-10-07T06:26:20.201Z"),
    "effectiveDate": ISODate("2016-10-07T06:26:20.201Z"),
    "updatedBy": "site.all.123"
})

db.EquipmentRequestWorkflowDefinition.insert({
    "_id": ObjectId("576aa205a70faa3f68683c56"),
    "className": "dmles.equipment.server.datamodels.request.workflow.definition.WorkflowDefinitionDO",
    "name": "Army Workflow Definition",
    "service": "DA",
    "reviewResponses": [
        "Recommend Approve",
        "Note Concern",
        "Not Applicable"
    ],
    "levelDefinitions": [
        {
            "levelId": 0,
            "name": "Site",
            "userType": "SITE",
            "ownerRoleId": "57800f5d768bbb531eecd249",
            "rules": {
                "allowReviewBypassOnApprove": false,
                "allowReviewSelection": true,
                "allowForceUp": true,
                "allowAutoApproveAfterReview": true,
                "allowModify": true,
                "allowReject": true,
                "allowHold": true,
                "allowRework": false,
                "allowRequestCancel": false,
                "allowCancel": true,
                "allowOwnerOverrideNegativeReviews": false,
                "allowRetract": true,
                "allowNoteConcern": false
            },
            "levelDefinitionReviews": [
                {
                    "elementName": "equip-request-technology",
                    "roleId": "57800f96768bbb531eecd24a",
                    "reviewDisplayName": "Site Equipment Technology"
                },
                {
                    "elementName": "equip-request-maintenance",
                    "roleId": "57800fba768bbb531eecd24b",
                    "reviewDisplayName": "Site Equipment Maintenance"
                },
                {
                    "elementName": "equip-request-facilities",
                    "roleId": "57800fc5768bbb531eecd24c",
                    "reviewDisplayName": "Site Equipment Facilities"
                },
                {
                    "elementName": "equip-request-safety",
                    "roleId": "57800fe5768bbb531eecd24d",
                    "reviewDisplayName": "Site Equipment Safety"
                }
            ]
        },
        {
            "levelId": 1,
            "name": "Regional",
            "userType": "SERVICEREGION",
            "ownerRoleId": "57bf493c03e0fba04e9bba1e",
            "rules": {
                "allowReviewBypassOnApprove": true,
                "allowReviewSelection": true,
                "allowForceUp": true,
                "allowAutoApproveAfterReview": false,
                "allowModify": false,
                "allowReject": true,
                "allowHold": true,
                "allowRework": true,
                "allowRequestCancel": false,
                "allowCancel": true,
                "allowOwnerOverrideNegativeReviews": true,
                "allowRetract": true,
                "allowNoteConcern": false
            },
            "levelDefinitionReviews": [
                {
                    "elementName": "equip-request-sme",
                    "roleId": "586d33ea0001aa092074256d",
                    "reviewDisplayName": "Region Subject Matter Expert"
                },
                {
                    "elementName": "equip-request-radiology",
                    "roleId": "5841ba3c4163cd73567a511f",
                    "reviewDisplayName": "Region Equipment Radiology"
                }
            ],
            "levelCriteria": {
                "totalCost": 10000,
                "totalCostThreshold": 10000,
                "deviceCostThreshold": 20000,
                "catalogItems": [
                    {
                        "catalogID": "6665015214676",
                        "catalogName": "ANALYZER HAZARDOUS MATERIAL ID COMMAND"
                    }
                ],
                "devices": [
                    {
                        "deviceCode": "C0067",
                        "deviceName": "Medical Waste Equipment, Eto, Emissions Control System"
                    }
                ]
            }
        },
        {
            "levelId": 2,
            "name": "Service",
            "userType": "SERVICE",
            "ownerRoleId": "57bf4a5303e0fba04e9bba23",
            "rules": {
                "allowReviewBypassOnApprove": true,
                "allowReviewSelection": true,
                "allowForceUp": true,
                "allowAutoApproveAfterReview": false,
                "allowModify": false,
                "allowReject": true,
                "allowHold": true,
                "allowRework": true,
                "allowRequestCancel": false,
                "allowCancel": true,
                "allowOwnerOverrideNegativeReviews": true,
                "allowRetract": true,
                "allowNoteConcern": false
            },
            "levelDefinitionReviews": [
                {
                    "elementName": "equip-request-technology",
                    "roleId": "57800f96768bbb531eecd24a",
                    "reviewDisplayName": "Service Equipment Technology"
                },
                {
                    "elementName": "equip-request-maintenance",
                    "roleId": "57800fba768bbb531eecd24b",
                    "reviewDisplayName": "Service Equipment Maintenance"
                }
            ],
            "levelCriteria": {
                "totalCostThreshold": 20000
            }
        },
        {
            "levelId": 3,
            "name": "DHA",
            "userType": "GLOBAL",
            "ownerRoleId": "57bf4ad903e0fba04e9bba28",
            "rules": {
                "allowReviewBypassOnApprove": true,
                "allowReviewSelection": true,
                "allowForceUp": false,
                "allowAutoApproveAfterReview": false,
                "allowModify": false,
                "allowReject": true,
                "allowHold": true,
                "allowRework": true,
                "allowRequestCancel": false,
                "allowCancel": true,
                "allowOwnerOverrideNegativeReviews": true,
                "allowRetract": false,
                "allowNoteConcern": false
            },
            "levelDefinitionReviews": [
                {
                    "elementName": "equip-request-technology",
                    "roleId": "57800f96768bbb531eecd24a",
                    "reviewDisplayName": "DHA Equipment Technology"
                }
            ],
            "levelCriteria": {
                "totalCost": 30000,
                "totalCostThreshold": 30000,
                "deviceCostThreshold": 10000,
                "devices": [
                    {
                        "totalCost": 150,
                        "deviceCode": "11165",
                        "deviceName": "System Treatment Dental Self Contained"
                    }
                ]
            }
        }
    ],
    "version": "0.0.11",
    "dateCreated": ISODate("2016-07-14T22:00:36.706Z"),
    "dateUpdated": ISODate("2016-10-18T18:47:14.321Z"),
    "effectiveDate": ISODate("2016-10-07T06:26:20.201Z"),
    "updatedBy": "5790c87a4c08b0003d9782f0",
    "active": true
})

db.EquipmentRequestWorkflowDefinition.insert({
    "_id": ObjectId("57b71d9603e0fba04e9bba18"),
    "className": "dmles.equipment.server.datamodels.request.workflow.definition.WorkflowDefinitionDO",
    "name": "Veteran Affairs Workflow Definition",
    "service": "VA",
    "reviewResponses": [
        "Recommend Approve",
        "Note Concern",
        "Not Applicable"
    ],
    "levelDefinitions": [
        {
            "levelId": 0,
            "name": "Site",
            "userType": "SITE",
            "ownerRoleId": "57800f5d768bbb531eecd249",
            "rules": {
                "allowReviewBypassOnApprove": false,
                "allowReviewSelection": true,
                "allowForceUp": true,
                "allowAutoApproveAfterReview": false,
                "allowModify": true,
                "allowReject": true,
                "allowHold": true,
                "allowRework": false,
                "allowRequestCancel": false,
                "allowCancel": true,
                "allowOwnerOverrideNegativeReviews": true,
                "allowRetract": true,
                "allowNoteConcern": false
            },
            "levelDefinitionReviews": [
                {
                    "elementName": "equip-request-technology",
                    "roleId": "57800f96768bbb531eecd24a",
                    "reviewDisplayName": "Site Equipment Technology"
                },
                {
                    "elementName": "equip-request-maintenance",
                    "roleId": "57800fba768bbb531eecd24b",
                    "reviewDisplayName": "Site Equipment Maintenance"
                },
                {
                    "elementName": "equip-request-facilities",
                    "roleId": "57800fc5768bbb531eecd24c",
                    "reviewDisplayName": "Site Equipment Facilities"
                },
                {
                    "elementName": "equip-request-safety",
                    "roleId": "57800fe5768bbb531eecd24d",
                    "reviewDisplayName": "Site Equipment Safety"
                }
            ]
        },
        {
            "levelId": 1,
            "name": "Regional",
            "userType": "SERVICEREGION",
            "ownerRoleId": "57bf493c03e0fba04e9bba1e",
            "rules": {
                "allowReviewBypassOnApprove": true,
                "allowReviewSelection": true,
                "allowForceUp": true,
                "allowAutoApproveAfterReview": false,
                "allowModify": false,
                "allowReject": true,
                "allowHold": true,
                "allowRework": true,
                "allowRequestCancel": false,
                "allowCancel": true,
                "allowOwnerOverrideNegativeReviews": true,
                "allowRetract": true,
                "allowNoteConcern": false
            },
            "levelDefinitionReviews": [
                {
                    "elementName": "equip-request-technology",
                    "roleId": "57800f96768bbb531eecd24a",
                    "reviewDisplayName": "Region Equipment Technology"
                },
                {
                    "elementName": "equip-request-maintenance",
                    "roleId": "57800fba768bbb531eecd24b",
                    "reviewDisplayName": "Region Equipment Maintenance"
                },
                {
                    "elementName": "equip-request-facilities",
                    "roleId": "57800fc5768bbb531eecd24c",
                    "reviewDisplayName": "Region Equipment Facilities"
                },
                {
                    "elementName": "equip-request-safety",
                    "roleId": "57800fe5768bbb531eecd24d",
                    "reviewDisplayName": "Region Equipment Safety"
                }
            ],
            "levelCriteria": {
                "totalCost": 10000
            }
        },
        {
            "levelId": 2,
            "name": "Service",
            "userType": "SERVICE",
            "ownerRoleId": "57bf4a5303e0fba04e9bba23",
            "rules": {
                "allowReviewBypassOnApprove": true,
                "allowReviewSelection": true,
                "allowForceUp": true,
                "allowAutoApproveAfterReview": false,
                "allowModify": false,
                "allowReject": true,
                "allowHold": true,
                "allowRework": true,
                "allowRequestCancel": false,
                "allowCancel": true,
                "allowOwnerOverrideNegativeReviews": true,
                "allowRetract": true,
                "allowNoteConcern": false
            },
            "levelDefinitionReviews": [
                {
                    "elementName": "equip-request-technology",
                    "roleId": "57800f96768bbb531eecd24a",
                    "reviewDisplayName": "Service Equipment Technology"
                },
                {
                    "elementName": "equip-request-maintenance",
                    "roleId": "57800fba768bbb531eecd24b",
                    "reviewDisplayName": "Service Equipment Maintenance"
                }
            ],
            "levelCriteria": {
                "totalCost": 20000
            }
        },
        {
            "levelId": 3,
            "name": "DHA",
            "userType": "GLOBAL",
            "ownerRoleId": "57bf4ad903e0fba04e9bba28",
            "rules": {
                "allowReviewBypassOnApprove": true,
                "allowReviewSelection": true,
                "allowForceUp": false,
                "allowAutoApproveAfterReview": false,
                "allowModify": false,
                "allowReject": true,
                "allowHold": true,
                "allowRework": true,
                "allowRequestCancel": false,
                "allowCancel": true,
                "allowOwnerOverrideNegativeReviews": true,
                "allowRetract": false,
                "allowNoteConcern": false
            },
            "levelDefinitionReviews": [
                {
                    "elementName": "equip-request-technology",
                    "roleId": "57800f96768bbb531eecd24a",
                    "reviewDisplayName": "DHA Equipment Technology"
                }
            ],
            "levelCriteria": {
                "totalCost": 30000
            }
        }
    ],
    "active": true,
    "version": "0.0.27",
    "dateCreated": ISODate("2016-08-19T22:10:53.706Z"),
    "dateUpdated": ISODate("2016-10-07T06:26:20.201Z"),
    "effectiveDate": ISODate("2016-10-07T06:26:20.201Z"),
    "updatedBy": "site.all.123"
})
