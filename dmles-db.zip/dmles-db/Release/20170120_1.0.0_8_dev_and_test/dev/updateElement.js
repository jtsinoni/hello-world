// ============== Switch to correct DB ======================

use dmlesUser




// ============== Update Element collection ======================


// Pre-run queries of Element

db.getCollection('Element').find({"name": "equip-request-weighin"}, {"_id": 1, "name": 1})

db.getCollection('Element').find({"name": "equip-request-review"}, {"_id": 1, "name": 1})



// Run update of Element

db.Element.update( {"name": "equip-request-weighin"}, {"$set": {"name": "equip-request-review"}} )



// Post-run queries of Element

db.getCollection('Element').find({"name": "equip-request-weighin"}, {"_id": 1, "name": 1})

db.getCollection('Element').find({"name": "equip-request-review"}, {"_id": 1, "name": 1})
