// ============== Switch to correct DB ======================

use dmlesUser



// ============== Update Permission collection ======================


// Pre-run queries of Permission

db.Permission.count( {"name": {$regex: /Weigh*/i} }, {"_id": 1, "name": 1, "description": 1})
db.Permission.find( {"name": {$regex: /Weigh*/i} }, {"_id": 1, "name": 1, "description": 1})

db.Permission.count( {"name": {$regex: /Review*/i} } , {"_id": 1, "name": 1, "description": 1})
db.Permission.find( {"name": {$regex: /Review*/i} } , {"_id": 1, "name": 1, "description": 1})



// Run Update of Permission

db.Permission.find( {"name": {$regex: /Weigh-Ins*/i} } ).forEach(function(doc) {
    var nameUpdated = doc.name.replace('Weigh-Ins','Reviews');
    var descUpdated = doc.description.replace('Weigh-Ins','Reviews');
    db.Permission.update( 
           {"_id": doc._id},
           {"$set": {
                "name": nameUpdated,
                "description": descUpdated
              }
           }
    );
 });



// Post-run queries of Permission

db.Permission.count( {"name": {$regex: /Weigh*/i} }, {"_id": 1, "name": 1, "description": 1})
db.Permission.find( {"name": {$regex: /Weigh*/i} }, {"_id": 1, "name": 1, "description": 1})

db.Permission.count( {"name": {$regex: /Review*/i} } , {"_id": 1, "name": 1, "description": 1})
db.Permission.find( {"name": {$regex: /Review*/i} } , {"_id": 1, "name": 1, "description": 1})


