==============================
Deployment Steps
==============================


0.  Run a backup of the Dev dmlesEquipment and dmlesUser databases (just in case)


1.  Run  updateElementAndPermissionDev.cmd script

       -- Updates Element and Permission collections
       -- Calls updateElement.js and updatePermission.js  JavaScript scripts


2.  Run replaceEquipReqWorkflowDefDev.cmd script

       -- Updates/replaces EquipmentRequestWorkflowDefinition records



3.  Run replaceEquipReqWorkflowProcessDev.cmd script

       -- Updates/replaces EquipmentRequestWorkflowProcess records


4.  Browse data in RoboMongo to verify updates went well


5.  Before checking into git, remove passwords from .cmd scripts!


NOTE: consider piping script output to .log files for additional review

