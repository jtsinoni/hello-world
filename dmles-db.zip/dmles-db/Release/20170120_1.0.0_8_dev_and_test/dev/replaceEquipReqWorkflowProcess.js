use dmlesEquipment


db.EquipmentRequestWorkflowProcess.remove( {_id: ObjectId("586d3d740001aa092080d1d3")} )

db.EquipmentRequestWorkflowProcess.remove( {_id: ObjectId("586d5d550001aa092080d1d6")} )





db.EquipmentRequestWorkflowProcess.insert(
{
    "_id" : ObjectId("586d3d740001aa092080d1d3"),
    "className" : "dmles.equipment.server.datamodels.request.workflow.process.WorkflowProcessingDO",
    "requestId" : "586d3d740001aa092080d1d2",
    "currentLevelId" : 0,
    "currentStatus" : "Active",
    "currentOwnerRole" : "57800f5d768bbb531eecd249",
    "isCompleted" : false,
    "wfDefinition" : {
        "$ref" : "EquipmentRequestWorkflowDefinition",
        "$id" : ObjectId("576aa205a70faa3f68683c56")
    },
    "levels" : {
        "0" : {
            "levelId" : 0,
            "levelName" : "Site",
            "status" : "Active",
            "reviews" : [ 
                {
                    "reviewDisplayName" : "Site Equipment Technology",
                    "elementName" : "equip-request-technology",
                    "reviewStatus" : "New",
                    "roleId" : "57800f96768bbb531eecd24a"
                }, 
                {
                    "reviewDisplayName" : "Site Equipment Maintenance",
                    "elementName" : "equip-request-maintenance",
                    "reviewStatus" : "New",
                    "roleId" : "57800fba768bbb531eecd24b"
                }, 
                {
                    "reviewDisplayName" : "Site Equipment Facilities",
                    "elementName" : "equip-request-facilities",
                    "reviewStatus" : "New",
                    "roleId" : "57800fc5768bbb531eecd24c"
                }, 
                {
                    "reviewDisplayName" : "Site Equipment Safety",
                    "elementName" : "equip-request-safety",
                    "reviewStatus" : "New",
                    "roleId" : "57800fe5768bbb531eecd24d"
                }
            ]
        },
        "1" : {
            "levelId" : 1,
            "levelName" : "Regional",
            "reviews" : [ 
                {
                    "reviewDisplayName" : "Region Subject Matter Expert 1",
                    "elementName" : "equip-request-sme",
                    "reviewStatus" : "New",
                    "roleId" : "586d33ea0001aa092074256d"
                }, 
                {
                    "reviewDisplayName" : "Region Equipment Radiology",
                    "elementName" : "equip-request-radiology",
                    "reviewStatus" : "New",
                    "roleId" : "5841ba3c4163cd73567a511f"
                }, 
                {
                    "reviewDisplayName" : "Region Subject Matter Expert 2",
                    "elementName" : "equip-request-sme",
                    "reviewStatus" : "New",
                    "roleId" : "586d33ea0001aa092074256d"
                }, 
                {
                    "reviewDisplayName" : "Region Subject Matter Expert 3",
                    "elementName" : "equip-request-sme",
                    "reviewStatus" : "New",
                    "roleId" : "586d33ea0001aa092074256d"
                }
            ]
        },
        "2" : {
            "levelId" : 2,
            "levelName" : "Service",
            "reviews" : [ 
                {
                    "reviewDisplayName" : "Service Equipment Technology",
                    "elementName" : "equip-request-technology",
                    "reviewStatus" : "New",
                    "roleId" : "57800f96768bbb531eecd24a"
                }, 
                {
                    "reviewDisplayName" : "Service Equipment Maintenance",
                    "elementName" : "equip-request-maintenance",
                    "reviewStatus" : "New",
                    "roleId" : "57800fba768bbb531eecd24b"
                }
            ]
        },
        "3" : {
            "levelId" : 3,
            "levelName" : "DHA",
            "reviews" : [ 
                {
                    "reviewDisplayName" : "DHA Equipment Technology",
                    "elementName" : "equip-request-technology",
                    "reviewStatus" : "New",
                    "roleId" : "57800f96768bbb531eecd24a"
                }
            ]
        }
    },
    "history" : [ 
        {
            "id" : NumberLong(1483554164730),
            "level" : "Site",
            "user" : "All, Site",
            "action" : "Request submitted for processing",
            "section" : "Request",
            "when" : ISODate("2017-01-04T18:22:44.730Z")
        }
    ],
    "updatedBy" : "All, Site",
    "updatedDate" : ISODate("2017-01-04T18:22:44.743Z")
})


db.EquipmentRequestWorkflowProcess.insert(
{
    "_id" : ObjectId("586d5d550001aa092080d1d6"),
    "className" : "dmles.equipment.server.datamodels.request.workflow.process.WorkflowProcessingDO",
    "requestId" : "586d5d550001aa092080d1d5",
    "currentLevelId" : 0,
    "currentStatus" : "Active",
    "currentOwnerRole" : "57800f5d768bbb531eecd249",
    "isCompleted" : false,
    "wfDefinition" : {
        "$ref" : "EquipmentRequestWorkflowDefinition",
        "$id" : ObjectId("576aa205a70faa3f68683c56")
    },
    "levels" : {
        "0" : {
            "levelId" : 0,
            "levelName" : "Site",
            "status" : "Active",
            "reviews" : [ 
                {
                    "reviewDisplayName" : "Site Equipment Technology",
                    "elementName" : "equip-request-technology",
                    "reviewStatus" : "New",
                    "roleId" : "57800f96768bbb531eecd24a"
                }, 
                {
                    "reviewDisplayName" : "Site Equipment Maintenance",
                    "elementName" : "equip-request-maintenance",
                    "reviewStatus" : "New",
                    "roleId" : "57800fba768bbb531eecd24b"
                }, 
                {
                    "reviewDisplayName" : "Site Equipment Facilities",
                    "elementName" : "equip-request-facilities",
                    "reviewStatus" : "New",
                    "roleId" : "57800fc5768bbb531eecd24c"
                }, 
                {
                    "reviewDisplayName" : "Site Equipment Safety",
                    "elementName" : "equip-request-safety",
                    "reviewStatus" : "New",
                    "roleId" : "57800fe5768bbb531eecd24d"
                }
            ]
        },
        "1" : {
            "levelId" : 1,
            "levelName" : "Regional",
            "reviews" : [ 
                {
                    "reviewDisplayName" : "Region Subject Matter Expert",
                    "elementName" : "equip-request-sme",
                    "reviewStatus" : "New",
                    "roleId" : "586d33ea0001aa092074256d"
                }, 
                {
                    "reviewDisplayName" : "Region Equipment Radiology",
                    "elementName" : "equip-request-radiology",
                    "reviewStatus" : "New",
                    "roleId" : "5841ba3c4163cd73567a511f"
                }
            ]
        },
        "2" : {
            "levelId" : 2,
            "levelName" : "Service",
            "reviews" : [ 
                {
                    "reviewDisplayName" : "Service Equipment Technology",
                    "elementName" : "equip-request-technology",
                    "reviewStatus" : "New",
                    "roleId" : "57800f96768bbb531eecd24a"
                }, 
                {
                    "reviewDisplayName" : "Service Equipment Maintenance",
                    "elementName" : "equip-request-maintenance",
                    "reviewStatus" : "New",
                    "roleId" : "57800fba768bbb531eecd24b"
                }
            ]
        },
        "3" : {
            "levelId" : 3,
            "levelName" : "DHA",
            "reviews" : [ 
                {
                    "reviewDisplayName" : "DHA Equipment Technology",
                    "elementName" : "equip-request-technology",
                    "reviewStatus" : "New",
                    "roleId" : "57800f96768bbb531eecd24a"
                }
            ]
        }
    },
    "history" : [ 
        {
            "id" : NumberLong(1483562325321),
            "level" : "Site",
            "user" : "Putnam, Becky",
            "action" : "Request submitted for processing",
            "section" : "Request",
            "when" : ISODate("2017-01-04T20:38:45.321Z")
        }
    ],
    "updatedBy" : "Putnam, Becky",
    "updatedDate" : ISODate("2017-01-04T20:38:45.330Z")
})
