use dmlesEquipment

db.EquipmentRequest.deleteMany({})
db.EquipmentRequestWorkflowProcess.deleteMany({})
