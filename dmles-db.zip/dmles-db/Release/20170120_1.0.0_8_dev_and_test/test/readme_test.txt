==============================
Deployment Steps
==============================


0.  Run a backup of the Test dmlesEquipment and dmlesUser databases (just in case)


1.  Run  updateElementAndPermissionTest.cmd script

       -- Updates Element and Permission collections
       -- Calls updateElement.js and updatePermission.js  JavaScript scripts


2.  Run replaceEquipReqWorkflowDefTest.cmd script

       -- Updates/replaces EquipmentRequestWorkflowDefinition records



3.  Run replaceEquipReqWorkflowProcessTest.cmd script

       -- Updates/replaces EquipmentRequestWorkflowProcess records


4.  Run statesPermsRoles_datapush_20170105.cmd  script

       -- Updates Permissions and ROles info.....stuff for Rob Hayes' work (functionality not to be deployed until later).


5.  Run clearTwoEquipTables.cmd script

       -- Clears out EquipmentRequest and EquipmentRequestWorkflowProcess


5.  Browse data in RoboMongo to verify updates went well


6.  Before checking into git, remove passwords from .cmd scripts!



NOTE: consider piping script output to .log files for additional review
