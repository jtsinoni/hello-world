use dmlesUser


db.State.insert({
    "_id": ObjectId("5866a9fb38136b69ef9abe3a"),
    "name": "dmles.home.finance.landing"
})
db.State.insert({
    "_id": ObjectId("5866a9fb38136b69ef9abe3c"),
    "name": "dmles.home.finance.admin"
})
db.State.insert({
    "_id": ObjectId("5866a9fb38136b69ef9abe3e"),
    "name": "dmles.home.finance.admin.myappropriations"
})
db.State.insert({
    "_id": ObjectId("5866a9fb38136b69ef9abe40"),
    "name": "dmles.home.finance.admin.myappropriations.detail"
})


db.Permission.insert({
    "_id":  ObjectId("5866acb838136b69ef9ac3b1"),
    "name": "View Appropriations",
    "states": [
        {
            "$ref": "State",
            "$id": ObjectId("581c8b32564b5f9f750d233d")
        },
        {
            "$ref": "State",
            "$id": ObjectId("57718452d0142fa833276e47")
        },
        {
            "$ref": "State",
            "$id": ObjectId("5866a9fb38136b69ef9abe3a")
        },
        {
            "$ref": "State",
            "$id": ObjectId("5866a9fb38136b69ef9abe3c")
        },
        {
            "$ref": "State",
            "$id": ObjectId("5866a9fb38136b69ef9abe3e")
        },
        {
            "$ref": "State",
            "$id": ObjectId("5866a9fb38136b69ef9abe3e")
        }
    ],
    "elements": [
    ],
    "functionalArea": "Finance_Appropriations",
    "description": "View Finance Appropriations"
})



db.Role.insert({
    "_id": ObjectId("5866acd61fe33d04fc32a023"),
    "className": "dmles.user.server.datamodel.RoleDO",
    "name": "Appropriation Viewer",
    "assignedPermissions": [
        {
            "name": "All Permissions",
            "allowed": true,
            "permission": {
                "$ref": "Permission",
                "$id": ObjectId("57728d844c08ed9af7596da7")
            }
        },
        {
            "name": "View Appropriations",
            "allowed": true,
            "permission": {
                "$ref": "Permission",
                "$id": ObjectId("5866acb838136b69ef9ac3b1")
            }
        }
    ],
    "active": false,
    "functionalArea": "Other",
    "description": "Able to view Financial Appropriations",
    "systemRole": false
})
