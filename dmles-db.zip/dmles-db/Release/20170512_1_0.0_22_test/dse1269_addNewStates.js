print()
print()
print("================================================================================================================")
print("DSE-1269:  dmlesUser: Add new States" )
print("================================================================================================================")

use dmlesUser


print()
print("Pre-run QA queries")
print()

print("First check State recs")
print()

db.State.count()

db.State.count( { name: {$in: [ "dmles.home.admin.userProfileMng.createUserProfile", 
                                "dmles.home.admin.userProfileMng.userProfileAssignRoles", 
                                "dmles.home.admin.userProfileMng.userProfileCreateConfirm"
                              ] 
                        }
                }
              )

db.State.find( { name: {$in: [ "dmles.home.admin.userProfileMng.createUserProfile", 
                                "dmles.home.admin.userProfileMng.userProfileAssignRoles", 
                                "dmles.home.admin.userProfileMng.userProfileCreateConfirm"
                              ] 
                        }
                }, 
                {_id: 1, name: 1}
              ).pretty()

print()
print("Next check Permission recs")
print()

db.Permission.count( {name: "All Permissions", 'states.$id': ObjectId("5911e836a9504efb91405165")} )

db.Permission.count( {name: "All Permissions", 'states.$id': ObjectId("5911e836a9504efb91405166")} )

db.Permission.count( {name: "All Permissions", 'states.$id': ObjectId("5911e837a9504efb91405167")} )



print()
print("Run inserts/updates...")
print()


print()
print("First insert 3 new State records...")
print()

db.State.insert(
  {
        "_id" : ObjectId("5911e836a9504efb91405165"),
        "name" : "dmles.home.admin.userProfileMng.createUserProfile"
  }
)

db.State.insert(
  {
        "_id" : ObjectId("5911e836a9504efb91405166"),
        "name" : "dmles.home.admin.userProfileMng.userProfileAssignRoles"
  }
)

db.State.insert(
  {
        "_id" : ObjectId("5911e837a9504efb91405167"),
        "name" : "dmles.home.admin.userProfileMng.userProfileCreateConfirm"
  }
)


print()
print()
print()
print("Next, update the Permission record...")
print()


print()
print("First, pull (in case already there)...")
print()

db.Permission.update( 
  { _id: ObjectId("57728d844c08ed9af7596da7"),
    "name" : "All Permissions"
  },
  { $pull: 
            {'states': 
                { "$ref": "State",
                  "$id": ObjectId("5911e836a9504efb91405165")
                }
            }
  },
  {upsert: false}
)

db.Permission.update( 
  { _id: ObjectId("57728d844c08ed9af7596da7"),
    "name" : "All Permissions"
  },
  { $pull: 
            {'states': 
                { "$ref": "State",
                  "$id": ObjectId("5911e836a9504efb91405166")
                }
            }
  },
  {upsert: false}
)

db.Permission.update( 
  { _id: ObjectId("57728d844c08ed9af7596da7"),
    "name" : "All Permissions"
  },
  { $pull: 
            {'states': 
                { "$ref": "State",
                  "$id": ObjectId("5911e837a9504efb91405167")
                }
            }
  },
  {upsert: false}
)

print()
print("Next, push...")
print()

db.Permission.update( 
  { _id: ObjectId("57728d844c08ed9af7596da7"),
    "name" : "All Permissions"
  },
  { $push: 
            {'states': 
                { "$ref": "State",
                  "$id": ObjectId("5911e836a9504efb91405165")
                }
            }
  },
  {upsert: false}
)

db.Permission.update( 
  { _id: ObjectId("57728d844c08ed9af7596da7"),
    "name" : "All Permissions"
  },
  { $push: 
            {'states': 
                { "$ref": "State",
                  "$id": ObjectId("5911e836a9504efb91405166")
                }
            }
  },
  {upsert: false}
)

db.Permission.update( 
  { _id: ObjectId("57728d844c08ed9af7596da7"),
    "name" : "All Permissions"
  },
  { $push: 
            {'states': 
                { "$ref": "State",
                  "$id": ObjectId("5911e837a9504efb91405167")
                }
            }
  },
  {upsert: false}
)





print()
print("Post-run QA queries")
print()

print("First check State recs")
print()

db.State.count()

db.State.count( { name: {$in: [ "dmles.home.admin.userProfileMng.createUserProfile", 
                                "dmles.home.admin.userProfileMng.userProfileAssignRoles", 
                                "dmles.home.admin.userProfileMng.userProfileCreateConfirm"
                              ] 
                        }
                }
              )

db.State.find( { name: {$in: [ "dmles.home.admin.userProfileMng.createUserProfile", 
                                "dmles.home.admin.userProfileMng.userProfileAssignRoles", 
                                "dmles.home.admin.userProfileMng.userProfileCreateConfirm"
                              ] 
                        }
                }, 
                {_id: 1, name: 1}
              ).pretty()

print()
print("Next check Permission recs")
print()

db.Permission.count( {name: "All Permissions", 'states.$id': ObjectId("5911e836a9504efb91405165")} )

db.Permission.count( {name: "All Permissions", 'states.$id': ObjectId("5911e836a9504efb91405166")} )

db.Permission.count( {name: "All Permissions", 'states.$id': ObjectId("5911e837a9504efb91405167")} )


print()
print()
print()
