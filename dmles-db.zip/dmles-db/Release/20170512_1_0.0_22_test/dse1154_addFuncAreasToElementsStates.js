print()
print()
print("================================================================================================================")
print("DSE-1154:  dmlesUser: Add Functional Areas to Elements and States" )
print("================================================================================================================")

use dmlesUser


print()
print("Pre-run queries")
print()

print()
print("Element counts (total vs. 'has functionalArea')")
print()
db.Element.count()
db.Element.count( {functionalArea: {$exists: true}} )

print()
print("State counts (total vs. 'has functionalArea')")
print()
db.State.count()
db.State.count( {functionalArea: {$exists: true}} )

print()
print("Role counts (total vs. 'has functionalArea')")
print()
db.Role.count()
db.Role.count( {functionalArea: {$exists: true}} )


print()
print()
print("Run inserts/updates")
print()


print()
print("Updates to Element records...")
print()

db.getCollection('Element').updateMany(
{'name': /inventory/}, 
{$set: {'functionalArea' : 'Inventory'}})

db.getCollection('Element').updateMany(
{'name': /real/}, 
{$set: {'functionalArea' : 'Real Estate'}})

db.getCollection('Element').updateMany(
{'name': /buyer/}, 
{$set: {'functionalArea' : 'Buyer'}})

db.getCollection('Element').updateMany(
{'name': /finance/}, 
{$set: {'functionalArea' : 'Finance'}})

db.getCollection('Element').updateMany(
{'name': /seller/}, 
{$set: {'functionalArea' : 'Seller'}})

db.getCollection('Element').updateMany(
{ $or : [{'name': /abi/},{'name': /catalog/}]},
{$set: {'functionalArea' : 'Catalog'}})

db.getCollection('Element').updateMany(
{ $or : [{'name': /user/},{'name': /role/}, {'name': /organization/}]},
{$set: {'functionalArea' : 'Administration'}})

db.getCollection('Element').updateMany(
{'name': 'all'}, 
{$set: {'functionalArea' : 'Other'}})

db.getCollection('Element').updateMany(
{'name': /purchase/}, 
{$set: {'functionalArea' : 'Purchasing'}})

db.getCollection('Element').updateMany(
{ $or : [{'name': /asset/},{'name': /request/}, {'name': /device/}, {'name': /equip/}, {'name': /workflow/}]},
{$set: {'functionalArea' : 'Equipment Request'}})


print()
print("Updates to State records...")
print()


db.getCollection('State').updateMany(
{'name': /inventory/}, 
{$set: {'functionalArea' : 'Inventory'}})

db.getCollection('State').updateMany(
{'name': /real/}, 
{$set: {'functionalArea' : 'Real Estate'}})

db.getCollection('State').updateMany(
{'name': /buyer/}, 
{$set: {'functionalArea' : 'Buyer'}})

db.getCollection('State').updateMany(
{'name': /finance/}, 
{$set: {'functionalArea' : 'Finance'}})

db.getCollection('State').updateMany(
{'name': /seller/}, 
{$set: {'functionalArea' : 'Seller'}})

db.getCollection('State').updateMany(
{ $or : [{'name': /abi/},{'name': /Abi/},{'name': /catalog/}]},
{$set: {'functionalArea' : 'Catalog'}})

db.getCollection('State').updateMany(
{ $or : [{'name': /user/},{'name': /role/},{'name': /organization/},{'name': /permission/},{'name': /admin/},{'name': /Admin/},{'name': /security/}]},
{$set: {'functionalArea' : 'Administration'}})

db.getCollection('State').updateMany(
{ $or : [{'name': /all/},{'name': /login/},{'name': /home/},{'name': 'dmles'}]},
{$set: {'functionalArea' : 'Other'}})

db.getCollection('State').updateMany(
{'name': /purchase/}, 
{$set: {'functionalArea' : 'Purchasing'}})

db.getCollection('State').updateMany(
{ $or : [{'name': /asset/},{'name': /request/}, {'name': /device/}, {'name': /equip/}, {'name': /workflow/}]},
{$set: {'functionalArea' : 'Equipment Request'}})


print()
print("Updates to Role records...")
print()

db.getCollection('Role').updateMany(
{'functionalArea': {$eq : 'Equipment_Request'}}, 
{$set: {'functionalArea' : 'Equipment Request'}})


print()
print("Post-run QA queries")
print()

print()
print("Element counts (total vs. 'has functionalArea')")
print()
db.Element.count()
db.Element.count( {functionalArea: {$exists: true}} )

print()
print("State counts (total vs. 'has functionalArea')")
print()
db.State.count()
db.State.count( {functionalArea: {$exists: true}} )

print()
print("Role counts (total vs. 'has functionalArea')")
print()
db.Role.count()
db.Role.count( {functionalArea: {$exists: true}} )


print()
print()
print()
