print()
print()
print("===============================================================================")
print("DSE-1289: dmlesUser changes required for Device Classification")
print("===============================================================================")
print()

use dmlesUser

print()
print()
print("============================")
print("Pre-run queries")
print("============================")

print()
print("Element records")
print()
db.Element.find({name: {$in: ["device-search", "device", "classification-device-view", "classification-device-create"]}}).pretty()


print()
print("State records")
print()
db.State.find({name: {$in: [
                             "dmles.home.classification.device.details",           "dmles.home.classification",           "dmles.home.classification.device",
                             "dmles.home.equipment.classification.device.details", "dmles.home.equipment.classification", "dmles.home.equipment.classification.device"
                           ]
                     }
              }
             ).pretty()

print()
print("Permission records")
print()
db.Permission.find( {name: {$in: ["View Device Records", "Manage Classification Device", "View Classification Device"]}},
                    {_id: 1, name: 1, elements: 1, description: 1}
                  ).pretty()


print()
print("Role record")
print()
db.Role.find({name: "Site Equipment Classification"}, {_id: 1, name: 1, assignedPermissions: 1}).pretty()

print()
print()
print()
print("============================")
print("Run Updates")
print("============================")
print()

print()
print("Update Element records")
print()

db.Element.update( {_id: ObjectId("580f6b27564b5f9f750ca8be"), name: "device-search"},
                   {$set: {name: "classification-device-view"}}
                 )

db.Element.update( {_id: ObjectId("580f6b15564b5f9f750ca8bd"), name: "device"},
                   {$set: {name: "classification-device-create"}}
                 )

print()
print("Update State records")
print()

db.State.update( {_id: ObjectId("580f88a7564b5f9f750ca8bf"), name: "dmles.home.classification.device.details"},
                 {$set: {name: "dmles.home.equipment.classification.device.details"}}
               ) 

db.State.update( {_id: ObjectId("580f69cc564b5f9f750ca8bb"), name: "dmles.home.classification"},
                 {$set: {name: "dmles.home.equipment.classification"}}
               )

db.State.update( {_id: ObjectId("580f6a06564b5f9f750ca8bc"), name: "dmles.home.classification.device"}, 
                 {$set: {name: "dmles.home.equipment.classification.device"}}
               )


print()
print("Insert new 'Manage Classification Device' Permission")
print()

db.Permission.insert(
  {
    "_id" : ObjectId("59138cbcda9c0c6bc7d698bb"),
    "name" : "Manage Classification Device",
    "states" : [ 
        {
            "$ref" : "State",
            "$id" : ObjectId("580f69cc564b5f9f750ca8bb")
        }, 
        {
            "$ref" : "State",
            "$id" : ObjectId("580f6a06564b5f9f750ca8bc")
        }, 
        {
            "$ref" : "State",
            "$id" : ObjectId("580f88a7564b5f9f750ca8bf")
        }
    ],
    "elements" : [ 
        {
            "$ref" : "Element",
            "$id" : ObjectId("580f6b15564b5f9f750ca8bd")
        }, 
        {
            "$ref" : "Element",
            "$id" : ObjectId("580f6b27564b5f9f750ca8be")
        }
    ],
    "functionalArea" : "Equipment_Request",
    "description" : "Manage Device Records",
    "active" : true
  }
)


print()
print("Update the 'View Device Records' Permission (2 updates to same record)")
print()

db.Permission.update( {_id: ObjectId("580f6bda4163dbdafb430511"), name: "View Device Records"},
                      {$set: {name: "View Classification Device"}}
                    )

db.Permission.update( 
  {_id: ObjectId("580f6bda4163dbdafb430511")},
  {$pull: 
      {'elements':
            { "$ref": "Element",
              "$id": ObjectId("580f6b15564b5f9f750ca8bd")
            }
      }
  },
  {upsert: false}
)
 

print()
print("Update Role record")
print()

db.Role.update( {_id: ObjectId("5810c056564b5f9f750ca8c0"), name: "Site Equipment Classification"},
                {$set:
                       { assignedPermissions: [ 
                               {
                                 "name" : "View Classification Device",
                                 "allowed" : true,
                                 "permission" : {
                                       "$ref" : "Permission",
                                       "$id" : ObjectId("580f6bda4163dbdafb430511")
                                  }
                               }
                            ]
                       }
                }
              )

print()
print()
print("============================")
print("Post-run QA queries")
print("============================")

print()
print("Element records")
print()
db.Element.find({name: {$in: ["device-search", "device", "classification-device-view", "classification-device-create"]}}).pretty()


print()
print("State records")
print()
db.State.find({name: {$in: [
                             "dmles.home.classification.device.details",           "dmles.home.classification",           "dmles.home.classification.device",
                             "dmles.home.equipment.classification.device.details", "dmles.home.equipment.classification", "dmles.home.equipment.classification.device"
                           ]
                     }
              }
             ).pretty()

print()
print("Permission records")
print()
db.Permission.find( {name: {$in: ["View Device Records", "Manage Classification Device", "View Classification Device"]}},
                    {_id: 1, name: 1, elements: 1, description: 1}
                  ).pretty()


print()
print("Role record")
print()
db.Role.find({name: "Site Equipment Classification"}, {_id: 1, name: 1, assignedPermissions: 1}).pretty()


print()
print()
print()
