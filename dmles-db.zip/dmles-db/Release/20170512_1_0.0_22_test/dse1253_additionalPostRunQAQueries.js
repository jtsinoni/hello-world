print("Added these queries after the fact, and ran them manually in Dev and Test---to verify success in the 1253 ticket")
print()

use dmlesOrganization

print()
print("expecting 8817")
print()
db.getCollection('Node').find({ isPrimaryHost: false, 'nodeTypeRef.id': "58efd83b44c0a5e103d6f54b", serviceProviderRefs: {$exists:true}}).count()

print()
print("expecting 51604")
print()
db.Node.find( {'nodeTypeRef.id': "58efd84244c0a5e103d6f553", serviceProviderRefs: {$exists:true}}).count()


print()
print("expecting 1302")
print()
db.getCollection('Node').find({ isPrimaryHost: false, 'nodeTypeRef.id': "58efd84a44c0a5e103d6f55a" , serviceProviderRefs: {$exists:true}}).count()