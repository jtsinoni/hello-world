print()
print()
print("================================================================================================================")
print("DSE-1267:  Add NodeTypeRef data to dmlesUser.Role")
print("================================================================================================================")

use dmlesUser


print()
print("Pre-run QA queries")
print()

db.Role.count()

db.Role.count( {nodeTypeRefs: {$exists: true}} )



print()
print("Run updates...")
print()

print()
print("Roles with all node types")
print()

db.Role.update( { $or: [ { name: "All Role" }, 
                        { name: "Test Role" }, 
                        { name: "Customer Manager" }, 
                        { name: "Manage Users" }, 
                        { name: "Role Management" }, 
                        { name: "JMLFDC Only" },
                        { name: "Authorized" },
                        { name: "Data Admin" },
                        { name: "Appropriation Viewer" },
                        { name: "Purchasing" },
                        { name: "Real Property Manager" }], 
                 nodeTypeRef: {$exists:false}},
   { $set: {
    "nodeTypeRefs" : [ 
        {
            "id" : "58efd64244c0a5e103d6f38a",
            "name" : "Root"
        }, 
        {
            "id" : "58efd61944c0a5e103d6f362",
            "name" : "Agency"
        }, 
        {
            "id" : "58efd64d44c0a5e103d6f397",
            "name" : "Service"
        }, 
        {
            "id" : "58efd65744c0a5e103d6f3a4",
            "name" : "Region"
        }, 
        {
            "id" : "58efd83044c0a5e103d6f53f",
            "name" : "Site"
        }, 
        {
            "id" : "58efd83b44c0a5e103d6f54b",
            "name" : "Department"
        }, 
        {
            "id" : "58efd84244c0a5e103d6f553",
            "name" : "Customer"
        }, 
        {
            "id" : "58efd84a44c0a5e103d6f55a",
            "name" : "Organization"
        }
    ],
        
        }},
  {
    multi:true
  }
)

print()
print("Roles with Site Level Node Types")
print()
db.Role.update( { $or: [{ name: "Site Equipment Maintenance" }, 
                        { name: "Site Equipment Manager" }, 
                        { name: "Customer Manager" }, 
                        { name: "Site Equipment Classification" }, 
                        { name: "Site Equipment Technology" }, 
                        { name: "Site Equipment Custodian" },
                        { name: "Site Equipment Safety" },
                        { name: "Site Equipment Facilities" },
                        { name: "Site Medical Asset Manager" },
                        { name: "Site Real Property Asset Manager" }], 
                 nodeTypeRef: {$exists:false}},
   { $set: {
    "nodeTypeRefs" : [ 
        {
            "id" : "58efd83044c0a5e103d6f53f",
            "name" : "Site"
        }
    ],
        
        }},
  {
    multi:true
  }
)


print()
print("Roles with Region Level Node Types")
print()
db.Role.update( { $or: [{ name: "Region Equipment Radiology" }, 
                        { name: "Regional Equipment Technology" }, 
                        { name: "Regional Equipment Maintenance" }, 
                        { name: "Regional Equipment Safety" }, 
                        { name: "Regional Equipment Facilities" }, 
                        { name: "Regional Equipment Manager" },
                        { name: "Region Subject Matter Expert" }], 
                 nodeTypeRef: {$exists:false}},
   { $set: {
    "nodeTypeRefs" : [ 
        {
            "id" : "58efd65744c0a5e103d6f3a4",
            "name" : "Region"
        }
    ],
        }},
  {
    multi:true
  }
)


print()
print("Roles with Service Level Node Types")
print()
db.Role.update( { $or: [{ name: "Service Subject Matter Expert" }, 
                        { name: "Service Equipment Maintenance" }, 
                        { name: "Service Equipment Manager" }, 
                        { name: "Service Equipment Safety" }, 
                        { name: "Service Equipment Facilities" }, 
                        { name: "Service Equipment Technology" }], 
                 nodeTypeRef: {$exists:false}},
   { $set: {
    "nodeTypeRefs" : [ 
        {
            "id" : "58efd64d44c0a5e103d6f397",
            "name" : "Service"
        }
    ],
        }},
  {
    multi:true
  }
)


print()
print("Roles with Agency Level Node Types")
print()
db.Role.update( { $or: [{ name: "DHA Equipment Technology" }, 
                        { name: "DHA Equipment Manager" }, 
                        { name: "DHA Equipment Safety" }, 
                        { name: "DHA Equipment Maintenance" }, 
                        { name: "DHA Subject Matter Expert" }, 
                        { name: "DHA Equipment Facilities" }, 
                        { name: "DHA Asset Manager" }], 
                 nodeTypeRef: {$exists:false}},
   { $set: {
    "nodeTypeRefs" : [ 
        {
            "id" : "58efd61944c0a5e103d6f362",
            "name" : "Agency"
        }
    ],
        }},
  {
    multi:true
  }
)


print()
print("Post-run QA queries")
print()

db.Role.count()

db.Role.count( {nodeTypeRefs: {$exists: true}} )


print()
print()
print()
