print()
print()
print("================================================================================================================")
print("DSE-1268:  dmlesOrganization - ServiceProvider: Move Provider data to Consumer" )
print("================================================================================================================")

use dmlesOrganization


print()
print("Pre-run QA queries")
print()

db.ServiceProvider.find( {}, {_id: 1, name: 1, consumer: 1, provider: 1} ).pretty()



print()
print("Run updates...")
print()


db.ServiceProvider.update( { name: "User Management" },
   { $set: {
    "consumer" : {
        "roleRefs" : [ 
            {
                "id" : "57800b36768bbb531eecd244",
                "name" : "Manage Users"
            }
        ]
    },
    "provider" : {},       
        
        }},
  {
    multi:false
  }
)

db.ServiceProvider.update( { name: "Role Management" },
   { $set: {
    "consumer" : {
        "roleRefs" : [ 
            {
                "id" : "5818d7fcba8a0a189d5d6196",
                "name" : "Role Management"
            }
        ]        
    },
    "provider" : {},       
        
        }},
  {
    multi:false
  }
)


db.ServiceProvider.update( { name: "Node Management" },
   { $set: {
    "consumer" : {},
    "provider" : {},       
        
        }},
  {
    multi:false
  }
)


db.ServiceProvider.update( { name: "Equipment Request Review" },
   { $set: {
    "consumer" : {
        "roleRefs" : [ 
            {
                "id" : "57800f5d768bbb531eecd249",
                "name" : "Site Equipment Manager"
            }, 
            {
                "id" : "57bf493c03e0fba04e9bba1e",
                "name" : "Regional Equipment Manager"
            }, 
            {
                "id" : "57bf4a5303e0fba04e9bba23",
                "name" : "Service Equipment Manager"
            }, 
            {
                "id" : "57bf4ad903e0fba04e9bba28",
                "name" : "DHA Equipment Manager"
            }
        ]        
    },
    "provider" : {},       
        
        }},
  {
    multi:false
  }
)


db.ServiceProvider.update( { name: "Equipment Request" },
   { $set: {
    "consumer" : {
        "roleRefs" : [ 
            {
                "id" : "57800f5d768bbb531eecd249",
                "name" : "Site Equipment Manager"
            }, 
            {
                "id" : "57800ed6768bbb531eecd248",
                "name" : "Site Equipment Custodian"
            }
        ]       
    },
    "provider" : {},       
        
        }},
  {
    multi:false
  }
)


db.ServiceProvider.update( { name: "Equipment Record" },
   { $set: {
    "consumer" : {
        "roleRefs" : [ 
            {
                "id" : "57800ed6768bbb531eecd248",
                "name" : "Site Equipment Custodian"
            }, 
            {
                "id" : "57800f5d768bbb531eecd249",
                "name" : "Site Equipment Manager"
            }, 
            {
                "id" : "57bf493c03e0fba04e9bba1e",
                "name" : "Regional Equipment Manager"
            }, 
            {
                "id" : "57bf4a5303e0fba04e9bba23",
                "name" : "Service Equipment Manager"
            }, 
            {
                "id" : "57bf4ad903e0fba04e9bba28",
                "name" : "DHA Equipment Manager"
            }
        ]    
    },
    "provider" : {},       
        
        }},
  {
    multi:false
  }
)






print()
print("Post-run QA queries")
print()


db.ServiceProvider.find( {}, {_id: 1, name: 1, consumer: 1, provider: 1} ).pretty()


print()
print()
print()
