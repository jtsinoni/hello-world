print()
print()
print("===============================================================================")
print("DSE-1253")
print("===============================================================================")
print()

use dmlesOrganization


print()
print()
print("============================")
print("New Departments")
print("============================")

print()
print("Check (expecting count of 8817)")
print()
db.getCollection('Node').find({ isPrimaryHost: false, 'nodeTypeRef.id': "58efd83b44c0a5e103d6f54b" }).count()

print()
print("Check (sample...)")
print()
db.getCollection('Node').find({isPrimaryHost: false, 'nodeTypeRef.id': "58efd83b44c0a5e103d6f54b"}, {_id: 1, name: 1, serviceProviderRefs: 1}).limit(5).pretty()

print()
print("Add Service Providers to Departments")
print()

db.Node.update({ 'nodeTypeRef.id': "58efd83b44c0a5e103d6f54b", serviceProviderRef: {$exists:false}},
   { $set: {
            serviceProviderRefs: [
            {
                id: "58f514c785ff091493fa6f70",
                name: "Equipment Record"
            },
            {
                id: "58f514c785ff091493fa6f72",
                name: "Equipment Request"
            },
            {
                id: "58f514c785ff091493fa6f74",
                name: "Equipment Request Review"
            }       
            ]
        }
    },
  {
    multi:true
  }
)


print()
print("Check Again")
print()
db.getCollection('Node').find({ isPrimaryHost: false, 'nodeTypeRef.id': "58efd83b44c0a5e103d6f54b" }).count()

print()
print("Check (sample...)")
print()
db.getCollection('Node').find({isPrimaryHost: false, 'nodeTypeRef.id': "58efd83b44c0a5e103d6f54b"}, {_id: 1, name: 1, serviceProviderRefs: 1}).limit(5).pretty()


print()
print()
print("============================")
print("New Customers")
print("============================")
print()

print("Check (expecting count of 51604)")
print()
db.getCollection('Node').find({ isPrimaryHost: false, 'nodeTypeRef.id': "58efd84244c0a5e103d6f553" }).count()
print()

print("Check (sample...)")
print()
db.getCollection('Node').find({ isPrimaryHost: false, 'nodeTypeRef.id': "58efd84244c0a5e103d6f553" }, {_id: 1, name: 1, serviceProviderRefs: 1}).limit(5).pretty()

print()
print("Add Service Providers to Customers")
print()

db.Node.update({ 'nodeTypeRef.id': "58efd84244c0a5e103d6f553", serviceProviderRef: {$exists:false}},
   { $set: {
            serviceProviderRefs: [
            {
                id: "58f514c785ff091493fa6f70",
                name: "Equipment Record"
            },
            {
                id: "58f514c785ff091493fa6f72",
                name: "Equipment Request"
            }       
            ]
        }
    },
  {
    multi:true
  }
)


print()
print("Check Again")
print()
db.getCollection('Node').find({ isPrimaryHost: false, 'nodeTypeRef.id': "58efd84244c0a5e103d6f553" }).count()

print()
print("Check (sample...)")
print()
db.getCollection('Node').find({ isPrimaryHost: false, 'nodeTypeRef.id': "58efd84244c0a5e103d6f553" }, {_id: 1, name: 1, serviceProviderRefs: 1}).limit(5).pretty()



print()
print()
print("============================")
print("New Organization")
print("============================")
print()

print("Check (expecting count of 1302)")
print()
db.getCollection('Node').find({ isPrimaryHost: false, 'nodeTypeRef.id': "58efd84a44c0a5e103d6f55a" }).count()


print()
print("Check (sample...)")
print()
db.getCollection('Node').find({ isPrimaryHost: false, 'nodeTypeRef.id': "58efd84a44c0a5e103d6f55a" }, {_id: 1, name: 1, serviceProviderRefs: 1}).limit(5).pretty()

print()
print("Add Service Providers to Organization")
print()

db.Node.update({ 'nodeTypeRef.id': "58efd84a44c0a5e103d6f55a", serviceProviderRef: {$exists:false}},
   { $set: {
            serviceProviderRefs: null
        }
    },
  {
    multi:true
  }
)


print()
print("Check Again")
print()
db.getCollection('Node').find({ isPrimaryHost: false, 'nodeTypeRef.id': "58efd84a44c0a5e103d6f55a" }).count()


print()
print("Check (sample...)")
print()
db.getCollection('Node').find({ isPrimaryHost: false, 'nodeTypeRef.id': "58efd84a44c0a5e103d6f55a" }, {_id: 1, name: 1, serviceProviderRefs: 1}).limit(5).pretty()


print()
print()
print()
