print()
print()
print("===============================================================================")
print("dse1243: Add File Management Configs to DB")
print("===============================================================================")
print()


use dmlesFilemanager


print()
print("========================================================")
print("Pre-run query: count Configuration records")
print("========================================================")
print()

db.Configuration.count()


print()
print("========================================================")
print("Now run the inserts")
print("========================================================")
print()


db.Configuration.insert(
  { "_id" : ObjectId("58f7bf56c29aa3a1a192ad50"), "name" : "maximumPostSize", "value" : "100000000" }
)

db.Configuration.insert(
  { "_id" : ObjectId("58f7bf65c29aa3a1a192ad7a"), "name" : "permittedFileExtensions", "value" : ".exe" }
)


print()
print("========================================================")
print("Post-run QA query: count Configuration records")
print("========================================================")
print()

db.Configuration.count()


print()
print()
print()
