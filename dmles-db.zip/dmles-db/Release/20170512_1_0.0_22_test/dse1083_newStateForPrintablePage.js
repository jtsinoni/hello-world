print()
print()
print("===============================================================================")
print("DSE-1083")
print("===============================================================================")
print()

use dmlesUser


print()
print()
print("============================")
print("Pre-run queries")
print("============================")

print()
print("Count total recs in State")
print()

db.State.count()

print()
print("Look for the particular, new State rec...")
print()

db.State.find( { _id : ObjectId("590b61d83f3e80946924d7c5")} ).pretty()


print()
print("Look for recs in Permission that have the particular State...")
print()

db.Permission.find( {'states.$id': ObjectId("590b61d83f3e80946924d7c5")}, {_id: 1, name: 1} )

print()
print("============================")
print("Run insert and updates")
print("============================")
print()

print()
print("First, insert the State...")
print()

db.State.insert(
  {
        "_id" : ObjectId("590b61d83f3e80946924d7c5"),
        "name" : "dmles.home.equipment.request.myRequests.view.print"
  }
)


print()
print("Next, update the 2 Permissions...")
print()

print()
print("First, pull (in case already there)...")
print()

db.Permission.update( 
  { _id: ObjectId("57728d844c08ed9af7596da7"),
    "name" : "All Permissions"
  },
  { $pull: 
            {'states': 
                { "$ref": "State",
                  "$id": ObjectId("590b61d83f3e80946924d7c5")
                }
            }
  },
  {upsert: false}
)

db.Permission.update( 
  { _id: ObjectId("5780174e768bbb531eecd255"),
    name : "View Equipment Requests"
  },
  { $pull: 
            {'states': 
                { "$ref": "State",
                  "$id": ObjectId("590b61d83f3e80946924d7c5")
                }
            }
  },
  {upsert: false}
)


print()
print("Next, push...")
print()

db.Permission.update( 
  { _id: ObjectId("57728d844c08ed9af7596da7"),
    "name" : "All Permissions"
  },
  { $push: 
            {'states': 
                { "$ref": "State",
                  "$id": ObjectId("590b61d83f3e80946924d7c5")
                }
            }
  },
  {upsert: false}
)

db.Permission.update( 
  { _id: ObjectId("5780174e768bbb531eecd255"),
    name : "View Equipment Requests"
  },
  { $push: 
            {'states': 
                { "$ref": "State",
                  "$id": ObjectId("590b61d83f3e80946924d7c5")
                }
            }
  },
  {upsert: false}
)

print()
print("Post-Run QA Queries")
print()

print()
print("Count total recs in State")
print()

db.State.count()

print()
print("Look for the particular, new State rec...")
print()

db.State.find( { _id : ObjectId("590b61d83f3e80946924d7c5")} ).pretty()

print()
print("Look for recs in Permission that have the particular State...")
print()

db.Permission.find( {'states.$id': ObjectId("590b61d83f3e80946924d7c5")}, {_id: 1, name: 1} )


print()
print()
print()
