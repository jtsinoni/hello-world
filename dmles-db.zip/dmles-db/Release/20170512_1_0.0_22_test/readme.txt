===============================================================================
Roll to Test, 12-May-2017, LogiCole, Release 1.0.0_22
===============================================================================


---------------------------------------
Tickets w/Data Tier Changes rolling
---------------------------------------

TICKETS DEPLOYED EARLY

* DSE-1195:  Remove denied users  (deployed early, 5/1/2017)

* DSE-1236:  Create DmlssHost collection in dmlesOrganization DB  (deployed early, 5/1/2017)

* DSE-1243:  Add File Management Configs to DB  (deployed early, 5/2/2017

* DSE-1253:  Load remaining Service Provider Refs  (deployed early 5/4/2017)



TICKETS DEPLOYING TODAY

* DSE-1083:  Create a printable page

               -- Add new dmlesUser.State, and grant to 2 permissions

* DSE-1154:  dmlesUser: Add Functional Areas to Elements and States

* DSE-1267:  dmlesUser - Roles: Add NodeTypeRef Data

               -- Child of DSE-1168

* DSE-1268:  dmlesOrganization -  move provider data to consumer

* DSE-1269:  dmlesUser - add new States

* DSE-1270:  Update to AppUserProfile schema definition ONLY

* DSE-1287:  UPdate to AppUserProfile schema definition ONLY---fix "invitation" stuff

* DSE-1289:  dmlesUser changes for Device Class

               -- Related to DSE-739, but can roll independently (no harm). Kevin Martin wants it deployed now.



---------------------------------------
RUN ORDER
---------------------------------------

-1   Run backup of DBs prior to deployment


0    Run pre-deploy QA queries

         cd qa_queries

         qaQueries.cmd <Environment> <username> <password>  > qaQueriesPreDeploy_<Environment>.log

         (Then navigate back up to deployment root dir)


1   Run dse1083_newStateForPrintablePage.cmd script


2   Run dse1154_addFuncAreasToElementsStates.cmd script


3   Run dse1267_addNodeTypeRefData.cmd script


4   Run dse1268_moveProviderDataToCustomer.cmd script


5   Run dse1269_addNewStates.cmd script


6   Run dse1289_dmlesUserChangesForDeviceClass.cmd script



10   Run post-deploy QA queries

         cd qa_queries

         qaQueries.cmd <Environment> <username> <password>  > qaQueriesPostDeploy_<Environment>.log



11   Compare pre-deploy QA queries and post-deploy

         in Gitbash, go to qa_queries directory

         diff qaQueriesPreDeploy_<Environment>.log qaQueriesPostDeploy_<Environment>.log



12   Run "Validate Refs" Jenkins Job

      -- To verify that the data updates have not resulted in any broken Refs

      -- If any broken Refs found, remediate!   You may need to restore data from backup in order to "undo" the changes that were made.

          ---- The incidence of this can be minimized with proper testing ahead of time



13   Run "Validate Structure" Jenkins Job

      -- To verify that the Json Schema defs are up-to-date with the latest data structure changes

      -- If any inaccurracies found, fix the JSON schema ASAP (but that is NOT essential for the release deployment, just for nightly validation)
  


14   When Release is completely done, do the following:

      -- Run another backup of Dev and/or Test DBs


      -- Update the files for Developers' "static" update of their local MongoDB instances:

                X:\Software Engineering\DML-ES\MongoDB_Developer_Seed


      -- If new MongoDB database(s) have been added, or removed, then update the following scripts, in the dmles-bt project, accordingly:

                Scripts\mongoLocalSeed.cmd
                Scripts\mongodumpDevDbs.cmd
                Scripts\mongoexportAllDBsSample.cmd           


       -- If needed, run a new "export all data sample" for the data architects:

                Scripts\mongoexportAllDBsSample.cmd

                Zip results and save them to:  X:\Data Architecture Team\DML-ES DB Sample Data Import



---------------------------------------
HOW TO RUN the .cmd scripts
---------------------------------------

To run against your localhost DB:

    scriptName.cmd local n n


To run against the Dev DB:

    scriptName.cmd dev username password


To run against the Test DB:

    scriptName.cmd test username password


To output the results to a log file (recommended):

    Append this to your command:   > logfileName 2>&1 

    For example:

       scriptName.cmd local n n > logfile_local.log 2>&1

       scriptName.cmd dev  username password logfile_dev.log 2>&1

       scriptName.cmd test username password logfile_test.log 2>&1

