===============================================================================
Roll to Test, 07-Apr-2017, DML-ES/LogiCole, Release 1.0.0_18
===============================================================================


---------------------------------------
Tickets w/Data Tier Changes rolling
---------------------------------------


* DSE-1099: Configure the workflow to not auto approve 

    -- EquipmentRequestWorkflowDefinition "auto approve" setting needs to be modified (in DB)

    -- Pull updated version of dmlesEquipment.EquipmentRequestWorkflowDefinition from Becky Putnam's DB and deploy to Dev



* DSE-506: Updates to dmlesSeller database

    -- Adds new Contract collection, drops SourceType collection, modifies Seller collection


* DSE-1058:  Data changes for ABi

    -- Seeds new dmlesUser.State records


* DSE-1124:  Create dir, files and nav

    -- Child to DSE-980

    -- Simple one, just seeds a new Element and State



---------------------------------------
RUN ORDER
---------------------------------------


-1   Run backup of DBs prior to deployment


0    Run pre-deploy QA queries

         cd qa_queries

         qaQueries.cmd <Environment> <username> <password>  > qaQueriesPreDeploy_<Environment>.log

         (Then navigate back up to deployment root dir)


1   Run dbDeploy_1_0_0_18.cmd script

      -- It runs everything

      -- Comments within script indicate which ticket each step is supporting



10   Run post-deploy QA queries

         cd qa_queries

         qaQueries.cmd <Environment> <username> <password>  > qaQueriesPostDeploy_<Environment>.log


11   Compare pre-deploy QA queries and post-deploy

         in Gitbash, go to qa_queries directory

         diff qaQueriesPreDeploy_<Environment>.log qaQueriesPostDeploy_<Environment>.log


12   Verify that nightly "validate structure" Jenkins jobs are up-to-date w/latest correct JSON schemas

      -- Update of dmlesUser.json


13   Run "validate structure" and "validate refs" Jenkins jobs

      -- Just as a verification that all is kosher



---------------------------------------
HOW TO RUN the .cmd scripts
---------------------------------------

To run against your localhost DB:

  scriptName.cmd local n n


To run against the Dev DB:

  scriptName.cmd dev username password


To run against the Test DB:

  scriptName.cmd test username password

