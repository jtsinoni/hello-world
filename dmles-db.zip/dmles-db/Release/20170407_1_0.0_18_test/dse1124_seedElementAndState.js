use dmlesUser


db.Element.insert(
  {
    "_id" : ObjectId("58e7e0a60da2ab2cac53400f"),
    "name" : "customer-catalog-view"
  }
)

db.State.insert(
  {
    "_id" : ObjectId("58e7e01b0da2ab2cac533f18"),
    "name" : "dmles.home.catalog.customerCatalog"
  }
)
