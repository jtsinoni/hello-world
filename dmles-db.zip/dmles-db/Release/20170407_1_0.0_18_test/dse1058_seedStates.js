use dmlesUser



print()
print("Initial QA queries")
print()

db.getCollection('State').count({name: /abi/})
db.getCollection('State').find({name: /abi/})

print()
print("Seeding new State records related to abi...")
print()


db.State.insert( 
  {
    "_id" : ObjectId("58e2667f6fe384cbab683d26"),
    "name" : "dmles.home.jmlfdcAdmin.abiStaging"
  }
)

db.State.insert( 
  {
    "_id" : ObjectId("58e2667f6fe384cbab683d27"),
    "name" : "dmles.home.jmlfdcAdmin.abiStaging.viewAbiStaging"
  }
)

db.State.insert( 
  {
    "_id" : ObjectId("58e2667f6fe384cbab683d28"),
    "name" : "dmles.home.jmlfdcAdmin.abiStaging.viewAbiStaging.editAbiStaging"
  }
)

db.State.insert( 
  {
    "_id" : ObjectId("58e2667f6fe384cbab683d29"),
    "name" : "dmles.home.jmlfdcAdmin.abiStaging.viewAbiStaging.setUnspsc"
  }
)

db.State.insert( 
  {
    "_id" : ObjectId("58e2667f6fe384cbab683d2a"),
    "name" : "dmles.home.jmlfdcAdmin.abiStaging.viewAbiStaging.setAttributes"
  }
)

db.State.insert( 
  {
    "_id" : ObjectId("58e2667f6fe384cbab683d2b"),
    "name" : "dmles.home.jmlfdcAdmin.abiStaging.mergeByMmc"
  }
)

db.State.insert( 
  {
    "_id" : ObjectId("58e2667f6fe384cbab683d2c"),
    "name" : "dmles.home.jmlfdcAdmin.abiStaging.mergeRecords"
  }
)

db.State.insert( 
  {
    "_id" : ObjectId("58e2667f6fe384cbab683d2d"),
    "name" : "dmles.home.jmlfdcAdmin.abiStaging.manageMergedRecords"
  }
)


print()
print("Post-run QA queries")
print()

db.getCollection('State').count({name: /abi/})
db.getCollection('State').find({name: /abi/})

