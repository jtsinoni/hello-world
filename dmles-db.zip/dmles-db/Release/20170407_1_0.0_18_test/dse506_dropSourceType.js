use dmlesSeller



print()
print("Initial QA queries")
print()

db.SourceType.count()

print()
print("Drop SourceType collection")
print()


db.SourceType.drop()


print()
print("Post-run QA query---make sure SourceType is gone")
print()

db.SourceType.count()
