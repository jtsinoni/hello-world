use dmlesInventory


// Pre-run queries

db.InventoryRecord.count( {catalogId: {$exists: true} } )

db.InventoryRecord.count( {catalogItemId: {$exists: true} } )



// Run update

db.getCollection('InventoryRecord').updateMany({}, {$rename: {'catalogId':'catalogItemId'}})





// Post-run queries

db.InventoryRecord.count( {catalogId: {$exists: true} } )

db.InventoryRecord.count( {catalogItemId: {$exists: true} } )
