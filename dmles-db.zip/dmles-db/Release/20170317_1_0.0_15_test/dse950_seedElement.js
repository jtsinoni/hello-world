use dmlesUser


// Pre-run query (should return 0 rows)

db.Element.find({"name": {$in: ["real-estate-installation-create","real-estate-site-create"]} })


// Run the inserts

db.Element.insert(
  {
    "_id" : ObjectId("58cc389d494f04cc5c44f320"),
    "name" : "real-estate-installation-create"
  }
)

db.Element.insert(
  {
    "_id" : ObjectId("58cc38a0494f04cc5c44f321"),
    "name" : "real-estate-site-create"
  }
)


// Post-run queries (should return 2 rows)

db.Element.find({"name": {$in: ["real-estate-installation-create","real-estate-site-create"]} })
