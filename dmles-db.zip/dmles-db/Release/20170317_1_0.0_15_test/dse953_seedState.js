use dmlesUser


// Pre-run query (should return 0 rows)

db.State.count( { name: {$in: ["dmles.home.seller.main.detail", "dmles.home.seller.main.add"]} } )



// Run the inserts


db.State.insert(
  {
    "_id" : ObjectId("58b9cd11e1b5f3f33c2467eb"),
    "name" : "dmles.home.seller.main.detail"
  }
)


db.State.insert(
  {
    "_id" : ObjectId("58c07c785f03c67b0d63e95c"),
    "name" : "dmles.home.seller.main.add"
  }
)



// Post-run queries (should return 2 rows)

db.State.count( { name: {$in: ["dmles.home.seller.main.detail", "dmles.home.seller.main.add"]} } )
