use dmlesBuyer

show collections


db.Advice.count()

db.MediaStatus.count()

db.PurchasePriority.count()

db.Signal.count()
