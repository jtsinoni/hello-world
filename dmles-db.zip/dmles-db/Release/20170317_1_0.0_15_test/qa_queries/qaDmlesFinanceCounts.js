use dmlesFinance

show collections



db.Appropriation.count()

db.AppropriationConfig.count()

db.MainAccount.count()


