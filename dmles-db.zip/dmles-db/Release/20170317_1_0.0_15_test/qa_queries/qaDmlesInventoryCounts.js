use dmlesInventory

show collections



db.InventoryRecord.count()

db.StorageLocation.count()

