use dmlesUser

show collections


db.AppUserProfile.count()

db.AppUserProfileRegistration.count()

db.Element.count()

db.Endpoint.count()

db.Permission.count()

db.Regions.count()

db.Role.count()

db.Services.count()

db.Site.count()

db.State.count()

