use dmlesEquipment

show collections


