use dmlesUser

db.AppUserProfile.count( {}, {'roles.$id' : ObjectId("5807d6aaba8a76977f96f4b2") } )
