use enterpriseCatalog

show collections



db.abiCatalog.count()

db.abiCatalogStaging.count()

db.commodityClass.count()

db.scriptPro_20170201.count()

db.siteCatalog.count()

db.system.profile.count()

db.unspsc.count()
