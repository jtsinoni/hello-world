use dmlesUser

DBQuery.shellBatchSize = 500 

db.AppUserProfile.aggregate([
     {$project: {_id: 0, roles: 1}},
     {$unwind: "$roles"},
     {$group: {_id: "$roles", total: {$sum: 1} } },
     {$sort: { _id: 1 } }
     ])
