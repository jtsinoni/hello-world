===============================================================================
Roll to Test, 17-Mar-2017, DML-ES/LogiCole, version 1.0.0_15
===============================================================================


---------------------------------------
Tickets w/DB Changes rolling
---------------------------------------

* DSE-957:   InventoryRecord schema change (renaming a column in dmlesInventory.InventoryRecord collection)

* DSE-953:   Seed new dmlesSeller database, and inserts 2 new records into dmlesUser.State collection

* DSE-950:   Seeds/Re-loads dmlesRealEstate database, which has some data corrections made. Also seeds 2 new dmlesUser.Element records.



---------------------------------------
RUN ORDER
---------------------------------------

-1   Run backup of DBs prior to deployment


0    Run pre-deploy QA queries

         cd qa_queries

         qaQueries.cmd <Environment> <username> <password>  > qaQueriesPreDeploy_<Environment>.log


1    Run dse957_inventoryRecordSchemaChg.cmd script

      -- Calls dse957_inventoryRecordSchemaChg.js to make the update (renaming a column). 


2    Run dse953_seedDmlesSeller.cmd script

      -- Does a mongorestore of the dmlesSeller data, putting into the DB for the first time


2.5  Run dse953_seedState.cmd script

      -- Calls dse953_seedState.js to seed 2 new records into the dmlesUser.State collection


3    Run dse950_seedDmlesRealEstate.cmd script

      -- Does a mongorestore of the dmlesRealEstate database, replacing the one that's there with corrected data


3.5  Run dse950_seedElement.cmd script

      -- Calls dse950_seedElement.js to seed 2 new records into the dmlesUser.Element collection


10  Run post-deploy QA queries

         cd qa_queries

         qaQueries.cmd <Environment> <username> <password>  > qaQueriesPostDeploy_<Environment>.log


11   Compare pre-deploy QA queries and post-deploy

         in Gitbash, go to qa_queries directory

         diff qaQueriesPreDeploy_<Environment>.log qaQueriesPostDeploy_<Environment>.log


12   Made manual correction of 1 record in dmlesRealEstate.Site collection for PL --- updated the _id for one record so it
     would correspond with a hardcoded value (for Maxwell AFB) that he has in his code right now.


13   Create dmlesSeller.json schema def file using Conversion Tool, then add this file to dmles-db/MongoDBValidation/Schemas


14   Add dmlesSeller database to dmles-bt/Scripts/mongodumpDevDBs.cmd and mongoLocalSeed.cmd


15   Add dmlesSeller.json schema def file to the list of files evaluated by the following Jenkins jobs on jwsrv116:

       -- Dmles_MongoDB_Validate_Struct_Dev
       -- Dmles_MongoDB_Validate_Struct_Test

       DO this by:

          Adding MongoDBValidateStructure/Schemas/dmlesSeller.json to JSON_SCHEMA_FILES parameter
          Adding dmlesSeller.json to "Index page(s)" under "Publish HTML Reports"-->"MongoDBValidateStructureResults"

       Verify successful by:

          Running the jobs in both Dev and Test
            --- Verifying that within the results, the validation results for dmlesSeller were included, as well as
                the schema itself in the "DMLES JSON Schemas" section


---------------------------------------
HOW TO RUN the .cmd scripts
---------------------------------------

To run against your localhost DB:

  scriptName.cmd local n n


To run against the Dev DB:

  scriptName.cmd dev username password


To run against the Test DB:

  scriptName.cmd test username password

