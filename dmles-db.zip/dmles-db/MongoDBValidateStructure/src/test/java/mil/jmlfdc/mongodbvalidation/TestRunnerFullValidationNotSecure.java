/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mil.jmlfdc.mongodbvalidation;

import mil.jmlfdc.mongodbvalidation.model.DBResult;
import mil.jmlfdc.mongodbvalidation.util.MongoDBUtility;

/**
 *
 * @author david.caglarcan
 */
public class TestRunnerFullValidationNotSecure {

    public void runTest() {
        String params[] = {
            "Schemas\\dmlesEquipment.json,Schemas\\dmlesSystem.json,Schemas\\dmlesUser.json",
            "localhost:27017",
            "C:\\Workspace\\Temp2\\multi_database_full_validation.txt",
            DBResult.VALIDATION_TYPE_COMPLETE,
            "500",
            "50",
            "30",
            MongoDBUtility.USER_CREDENTIALS_NOT_APPLICABLE, // could also pass null
            MongoDBUtility.USER_CREDENTIALS_NOT_APPLICABLE // could also pass null
        };
        App.main(params);
    }

    public static void main(String args[]) {

        TestRunnerFullValidationNotSecure runner = new TestRunnerFullValidationNotSecure();
        runner.runTest();
    }

}
