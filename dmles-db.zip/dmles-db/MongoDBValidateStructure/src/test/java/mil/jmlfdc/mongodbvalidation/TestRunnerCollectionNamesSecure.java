/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mil.jmlfdc.mongodbvalidation;

import mil.jmlfdc.mongodbvalidation.model.DBResult;

/**
 *
 * @author david.caglarcan
 */
public class TestRunnerCollectionNamesSecure {

    public void runTest() {
        String params[] = {
            "Schemas\\dmlesEquipment.json,Schemas\\dmlesSystem.json,Schemas\\dmlesUser.json",
            "replDMLES01/dmeddb3001:27017,dmeddb3002:27017,dmeddb3003:27017",
            "Results\\multi_database_coll_names_validation.txt",
            DBResult.VALIDATION_TYPE_COLLECTION_NAMES_ONLY,
            "0",
            "0",
            "30",
            "username", //modify...enter actual username here for testing
            "password" //modify...enter actual password here for testing
        };
        App.main(params);
    }

    public static void main(String args[]) {

        TestRunnerCollectionNamesSecure runner = new TestRunnerCollectionNamesSecure();
        runner.runTest();
    }
}
