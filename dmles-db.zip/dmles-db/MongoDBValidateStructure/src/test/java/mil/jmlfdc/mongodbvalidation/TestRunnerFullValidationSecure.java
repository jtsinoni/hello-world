/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mil.jmlfdc.mongodbvalidation;

import mil.jmlfdc.mongodbvalidation.model.DBResult;

/**
 *
 * @author david.caglarcan
 */
public class TestRunnerFullValidationSecure {

    public void runTest() {
        String params[] = {
            "Schemas\\dmlesEquipment.json,Schemas\\dmlesSystem.json,Schemas\\dmlesUser.json",
            "replDMLES01/dmeddb3001:27017,dmeddb3002:27017,dmeddb3003:27017",
            "Results\\multi_database_full_validation.txt",
            DBResult.VALIDATION_TYPE_COMPLETE,
            "500",
            "50",
            "4",
            "username", //modify...enter actual username here for testing
            "password" //modify...enter actual password here for testing
        };
        App.main(params);
    }

    public static void main(String args[]) {

        TestRunnerFullValidationSecure runner = new TestRunnerFullValidationSecure();
        runner.runTest();
    }
}
