package mil.jmlfdc.mongodbvalidation.processing;

import mil.jmlfdc.mongodbvalidation.util.*;
import mil.jmlfdc.mongodbvalidation.model.*;

import com.mongodb.MongoClient;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;
import org.bson.types.ObjectId;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;
import java.io.IOException;

/**
 * This class provides capability to run a validation of a MongoDB database
 * (either collection names only, or a full validation including collection
 * structures). It returns a DBResult object.
 */
public class SingleDBValidator {

    protected static final String OPERATING_SYSTEM = System.getProperty("os.name");

    private String connectionString;
    private String username;
    private String password;
    private MongoCredential credential;
    private List<ServerAddress> serverAddresses;
    private String jsonSchemaFilename;
    //private String mongoDBHostName;
    //private String mongoDBPort;
    private String resultOutputFilename;
    private String validationType;
    private Integer maxFetchSize;
    private Integer maxDiscrepanciesReportSize;

    private MongoClient mongoClient;
    private FileUtility fileUtil;
    private MongoDBUtility mongoDBUtil;

    private String jsonSchemaString;
    private JsonNode jsonSchemaRootNode;
    private String jsonSchemaDatabaseName;
    private ArrayList<DataNode> jsonSchemaCollectionNodes;
    private Map<String, Integer> jsonSchemaCollectionNamesMap;
    private Map<String, Integer> mongoDBCollectionNamesMap;

    private DBResult dbResult;
    protected String lfChar;

    public SingleDBValidator(String schemaFilename, String connectionString,
            String outputFilename, String validationType, Integer maxFetchSize,
            Integer maxDiscrepanciesReportSize, String username, String password) {

        this.jsonSchemaFilename = schemaFilename;
        this.connectionString = connectionString;
        this.username = username;
        this.password = password;
        this.resultOutputFilename = outputFilename;
        this.validationType = validationType;
        this.maxFetchSize = maxFetchSize;
        this.maxDiscrepanciesReportSize = maxDiscrepanciesReportSize;

        mongoDBCollectionNamesMap = new HashMap<String, Integer>();
        jsonSchemaCollectionNamesMap = new HashMap<String, Integer>();
        fileUtil = new FileUtility();

        if (OPERATING_SYSTEM.startsWith("Window") || OPERATING_SYSTEM.startsWith("WINDOW")) {
            lfChar = "\r\n";
        } else {
            lfChar = "\n";
        }
    }

    /**
     * The bread-and-butter method that performs the database validation.
     *
     * @return DBResult DBResult object containing results of the validation
     * @throws Exception
     */
    public DBResult validateDatabase() throws Exception {

        if (!DBResult.VALIDATION_TYPE_COMPLETE.equals(validationType) && !DBResult.VALIDATION_TYPE_COLLECTION_NAMES_ONLY.equals(validationType)) {
            throw new Exception(String.format("Bad validationType provided (must be %s or %s)",
                    DBResult.VALIDATION_TYPE_COMPLETE, DBResult.VALIDATION_TYPE_COLLECTION_NAMES_ONLY));
        }

        parseJsonSchemaFromFile();

        dbResult = new DBResult(jsonSchemaFilename, connectionString,
                jsonSchemaDatabaseName, validationType, maxFetchSize, maxDiscrepanciesReportSize);
        mongoDBUtil = new MongoDBUtility(connectionString, jsonSchemaDatabaseName, username, password);
        mongoDBCollectionNamesMap = mongoDBUtil.getCollectionNames();

        dbResult.setNumCollectionsInJsonSchema(jsonSchemaCollectionNodes.size());
        List<String> jsonSchemaCollectionNames = new ArrayList<String>();
        for (DataNode d : jsonSchemaCollectionNodes) {
            jsonSchemaCollectionNames.add(d.getKey());
        }
        dbResult.setJsonSchemaCollectionNames(jsonSchemaCollectionNames);

        dbResult.setNumCollectionsInMongoDB(mongoDBCollectionNamesMap.size());

        checkDbForMissingCollections();
        checkDbForExtraCollections();

        if (DBResult.VALIDATION_TYPE_COMPLETE.equals(validationType)) {
            checkDbCollectionDocumentStructures();
        }
        return dbResult;
    }

    /**
     * Read JSON schema definition file, parse into jsonSchemaRootNode (i.e.
     * database) and jsonSchemaMemberNodes (i.e. collections)
     */
    private void parseJsonSchemaFromFile() throws IOException {

        jsonSchemaString = fileUtil.readFileIntoString(jsonSchemaFilename);
        JsonFactory factory = new JsonFactory();
        ObjectMapper mapper = new ObjectMapper(factory);
        jsonSchemaRootNode = mapper.readTree(jsonSchemaString);
        jsonSchemaDatabaseName = jsonSchemaRootNode.findValue("name").asText();
        jsonSchemaCollectionNodes = new ArrayList<DataNode>();
        JsonNode collNode = jsonSchemaRootNode.findValue("collections");

        Iterator<JsonNode> collectionsIterator = collNode.elements();
        int increment = 0;
        while (collectionsIterator.hasNext()) {
            JsonNode node = collectionsIterator.next();
            String collectionString = node.toString();
            DataNode dataNode = parseJsonIntoDataNode(collectionString);
            jsonSchemaCollectionNodes.add(dataNode);
        }

        for (DataNode node : jsonSchemaCollectionNodes) {
            jsonSchemaCollectionNamesMap.put(node.getKey(), 1);
        }
    }

    /**
     * Loops through the collections listed in the JSON schema, checks for any
     * that are not in the MongoDB database, adds to the dbResult
     */
    private void checkDbForMissingCollections() {

        for (DataNode collectionNode : jsonSchemaCollectionNodes) {
            String collectionName = collectionNode.getKey();
            if (!mongoDBCollectionNamesMap.containsKey(collectionName)) {
                dbResult.noteCollectionMissingFromMongo(collectionName);
            }
        }
    }

    /**
     * Iterates through the HashMap of MongoDB collection names, looks for any
     * that are NOT found in the JSON schema file, adds to the dbResult
     */
    private void checkDbForExtraCollections() {

        Iterator it = mongoDBCollectionNamesMap.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pair = (Map.Entry) it.next();
            String mongoDBCollectionName = (String) pair.getKey();

            if (jsonSchemaCollectionNamesMap.containsKey(mongoDBCollectionName)) {
                dbResult.noteMatchingCollectionName(mongoDBCollectionName);
            } else {
                dbResult.noteExtraCollectionInMongo(mongoDBCollectionName);
            }
        }
    }

    /**
     * Validate the the JSON schema (parsed from the fie) against the specified
     * MongoDB database---detailed comparison including document (record)
     * structure
     */
    private void checkDbCollectionDocumentStructures() throws Exception {

        for (DataNode jsonSchemaCollectionNode : jsonSchemaCollectionNodes) {

            String collectionName = jsonSchemaCollectionNode.getKey();
            DBCollectionInfo collectionInfo = new DBCollectionInfo(collectionName);
            dbResult.addDBCollectionInfo(collectionInfo);

            if (mongoDBCollectionNamesMap.containsKey(collectionName)) {

                // dbResult.incrementNumCollectionsComparedInDetail();
                //List<String> dbDocStrings = mongoDBUtil.getMultipleDocsAsJSONSchemaDefStrings(collectionName, maxFetchSize);
                Map<ObjectId, String> dbDocs = mongoDBUtil.getMultipleDocsAsJSONSchemaDefs(collectionName, maxFetchSize);

                if (dbDocs != null && dbDocs.size() > 0) {

                    Iterator it = dbDocs.entrySet().iterator();
                    while (it.hasNext()) {
                        Map.Entry e = (Map.Entry) it.next();
                        ObjectId objectId = (ObjectId) e.getKey();
                        DataNode dbDataNode = parseJsonIntoDataNode((String) e.getValue());

                        if (!jsonSchemaCollectionNode.getJsonNode().equals(dbDataNode.getJsonNode())) {

                            for (DataNode dbDataNodeMember : dbDataNode.getMembersList()) {

                                if (!jsonSchemaCollectionNode.containsKey(dbDataNodeMember.getKey())) {

                                    Discrepancy disc = new Discrepancy(
                                            jsonSchemaCollectionNode.getKey(),
                                            dbDataNodeMember.getKey(),
                                            objectId,
                                            String.format("DB field %s.%s NOT found in JSON schema", jsonSchemaCollectionNode.getKey(), dbDataNodeMember.getKey()));
                                    // "DB field " + dbDataNodeMember.getKey() + " NOT found in JSON schema");

                                    dbResult.noteDiscrepancy(disc, false);
                                } else {
                                    compareNodes(dbDataNodeMember, jsonSchemaCollectionNode.getMemberByKey(dbDataNodeMember.getKey()),
                                            jsonSchemaCollectionNode.getKey(), objectId, "");
                                }
                            }
                        }
                    }
                } else {
                    dbResult.incrementNumCollectionsWithZeroDBRecs();
                }
            }
        }
        dbResult.tallyUpDetailedComparisonTotals();
    }

    /**
     * Parses Json string into data node then calls setNodes to populate the
     * Members of the DataNode.
     *
     * @param json
     * @return DataNode object
     * @throws IOException
     */
    private DataNode parseJsonIntoDataNode(String json) throws IOException {
        DataNode dataNode = new DataNode();
        JsonFactory factory = new JsonFactory();
        ObjectMapper mapper = new ObjectMapper(factory);
        JsonNode rootNode = mapper.readTree(json);
        Iterator<Map.Entry<String, JsonNode>> fieldsIterator = rootNode.fields();
        int increment = 0;

        while (fieldsIterator.hasNext()) {
            Map.Entry<String, JsonNode> field = fieldsIterator.next();
            increment++;
            if (increment == 1) {
                dataNode.setKey(field.getKey().trim());
                dataNode.setJsonNode(field.getValue());
                dataNode.setMembersList(new ArrayList<DataNode>());
                dataNode.setMembersMap(new HashMap<String, DataNode>());
            }
        }
        setNodes(dataNode.getJsonNode(), dataNode);
        return dataNode;
    }

    /**
     *
     * @param nodeFromDatabase
     * @param nodeFromJsonSchema
     * @param baseCollectionName
     * @param nodeChain
     */
    private void compareNodes(DataNode nodeFromDatabase, DataNode nodeFromJsonSchema,
            String baseCollectionName, ObjectId baseDocumentObjectId, String nodeChain) {

        if (nodeChain == null) {
            nodeChain = "";
        }
        if (nodeFromDatabase.getKey().equals(nodeFromJsonSchema.getKey()) && nodeFromDatabase.getJsonNode().equals(nodeFromJsonSchema.getJsonNode())) {
            nodeChain = "";
        } else {
            nodeChain = nodeChain + "." + nodeFromDatabase.getKey();

            if (!nodeFromDatabase.getKey().equals(nodeFromJsonSchema.getKey())) {

                Discrepancy disc = new Discrepancy(
                        baseCollectionName,
                        nodeFromDatabase.getKey(),
                        baseDocumentObjectId,
                        String.format("Field %s has diffs...field name is different (%s vs %s)",
                                (baseCollectionName + nodeChain), (nodeFromDatabase.getKey()), (nodeFromJsonSchema.getKey()))
                );
                dbResult.noteDiscrepancy(disc, false);

            } else if (nodeFromDatabase.getMembersList().size() == 0 && nodeFromJsonSchema.getMembersList().size() == 0) {

                String nodeFromDbDataType = nodeFromDatabase.getJsonNode().findValue("type").asText();
                String nodeFromJsonDataType = nodeFromJsonSchema.getJsonNode().findValue("type").asText();

                if (!nodeFromDbDataType.equals("null") && !nodeFromDbDataType.equals(nodeFromJsonDataType)) {

                    Discrepancy disc = new Discrepancy(
                            baseCollectionName,
                            nodeFromDatabase.getKey(),
                            baseDocumentObjectId,
                            String.format("Field %s has diff datatypes (database has %s, JSON schema has %s)",
                                    (baseCollectionName + nodeChain), nodeFromDbDataType, nodeFromJsonDataType
                            ));
                    dbResult.noteDiscrepancy(disc, false);
                }

            } else if (nodeFromDatabase.getMembersList() != null && nodeFromDatabase.getMembersList().size() > 0
                    && nodeFromJsonSchema.getMembersList() != null && nodeFromJsonSchema.getMembersList().size() > 0) {

                for (int i = 0; i < nodeFromDatabase.getMembersList().size(); i++) {

                    DataNode dbNode = nodeFromDatabase.getMembersList().get(i);

                    DataNode jsonSchemaNode = nodeFromJsonSchema.getMembersMap().get(dbNode.getKey());
                    if (jsonSchemaNode != null) {
                        compareNodes(nodeFromDatabase.getMembersList().get(i),
                                jsonSchemaNode, baseCollectionName, baseDocumentObjectId, nodeChain);
                    } else {
                        Discrepancy disc = new Discrepancy(
                                baseCollectionName,
                                nodeFromDatabase.getKey(),
                                baseDocumentObjectId,
                                String.format("Field %s not found in JSON schema",
                                        (baseCollectionName + nodeChain + "." + dbNode.getKey())
                                ));
                        dbResult.noteDiscrepancy(disc, false);
                    }
                }

            } else if ((nodeFromDatabase.getMembersList() != null && nodeFromJsonSchema.getMembersList() == null)
                    || (nodeFromDatabase.getMembersList() == null && nodeFromJsonSchema.getMembersList() != null)) {

                Discrepancy disc = new Discrepancy(
                        baseCollectionName,
                        nodeFromDatabase.getKey(),
                        baseDocumentObjectId,
                        String.format("Field %s has diffs...children members are different",
                                (baseCollectionName + nodeChain)));
                dbResult.noteDiscrepancy(disc, false);

            } else if ((nodeFromDatabase.getMembersList() == null || nodeFromDatabase.getMembersList().size() == 0)
                    && (nodeFromJsonSchema.getMembersList() != null && nodeFromJsonSchema.getMembersList().size() > 0)) {
                // Database array field is empty, while JSON schema field is populated...because we do not have mandatory 
                // fields at this point, do not treat this as a difference

            } else {
                Discrepancy disc = new Discrepancy(
                        baseCollectionName,
                        nodeFromDatabase.getKey(),
                        baseDocumentObjectId,
                        String.format("Field %s has other diff",
                                (baseCollectionName + nodeChain)));
                dbResult.noteDiscrepancy(disc, false);
            }
        }
    }

    /**
     * Populates the Members of the DataNode, based on the JSON passed in. Makes
     * recursive calls in order to populate all the nested stuff.
     *
     * @param jsonNode the JsonNode to be converted into a new DataNode
     * @param parentDataNode the parent DataNode into which the new DataNode
     * will be added as a Member.
     */
    private void setNodes(JsonNode jsonNode, DataNode parentDataNode) {

        if (!parentDataNode.getJsonNode().isArray()) {

            Iterator<Map.Entry<String, JsonNode>> fieldsInterator = jsonNode.fields();

            while (fieldsInterator.hasNext()) {
                Map.Entry<String, JsonNode> nestedField = fieldsInterator.next();

                if (nestedField.getValue().isObject()) {
                    DataNode nestedDataNode = new DataNode("TBD");
                    nestedDataNode.setKey(nestedField.getKey().trim());
                    nestedDataNode.setJsonNode(nestedField.getValue());
                    parentDataNode.getMembersList().add(nestedDataNode);
                    parentDataNode.getMembersMap().put(nestedField.getKey().trim(), nestedDataNode);
                    setNodes(nestedField.getValue(), nestedDataNode);

                } else if (nestedField.getValue().isArray()) {
                    DataNode nestedDataNode = new DataNode("TBD");
                    nestedDataNode.setKey(nestedField.getKey().trim());
                    JsonNode nestedNode = nestedField.getValue();
                    nestedDataNode.setJsonNode(nestedNode);

                    if (nestedNode.isArray()) {
                        for (JsonNode nestedNestedNode : nestedNode) {

                            Iterator<Map.Entry<String, JsonNode>> fieldsIterator3 = nestedNestedNode.fields();

                            while (fieldsIterator3.hasNext()) {
                                Map.Entry<String, JsonNode> nestedNestedField = fieldsIterator3.next();

                                if (nestedNestedField.getValue().isObject() || nestedNestedField.getValue().isArray()) {

                                    DataNode nestedNestedDataNode = new DataNode("TBD");
                                    nestedNestedDataNode.setKey(nestedNestedField.getKey().trim());
                                    nestedNestedDataNode.setJsonNode(nestedNestedField.getValue());

                                    setNodes(nestedNestedField.getValue(), nestedNestedDataNode);
                                    nestedDataNode.getMembersList().add(nestedNestedDataNode);
                                    nestedDataNode.getMembersMap().put(nestedNestedField.getKey().trim(), nestedNestedDataNode);
                                }
                            }
                        }
                    }
                    parentDataNode.getMembersList().add(nestedDataNode);
                    parentDataNode.getMembersMap().put(nestedDataNode.getKey().trim(), nestedDataNode);
                    setNodes(nestedField.getValue(), nestedDataNode);
                }
            }
        }
    }

    /**
     * Helper method to enclose the String in double quotes.
     *
     * @param input the input String
     * @return the String with quotes around it.
     */
    private String quoteStr(String input) {
        String retval = "\"" + input + "\"";
        return retval;
    }
}
