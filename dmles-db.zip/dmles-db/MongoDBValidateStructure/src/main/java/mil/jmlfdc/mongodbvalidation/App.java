package mil.jmlfdc.mongodbvalidation;

import java.util.Arrays;
import java.util.List;
import mil.jmlfdc.mongodbvalidation.processing.MongoDBValidateStructure;
import mil.jmlfdc.mongodbvalidation.util.MongoDBUtility;

public class App {

    /**
     * Main method
     *
     * @param args includes comma-delimited list of JSON filenames (including
     * path), the MongoDB hostname, the MongoDB port, the output File (including
     * path), the type of validation (reference constants in DBResult class for
     * appropriate values), the max fetch size (i.e. max # of recs to query from
     * each DB collection), and the max # of discrepancies to report.
     */
    public static void main(String[] args) {
        String commaDelimitListJsonFilenamesParam;
        String connectionStringParam;
        //String mongoDBHostParam;
        //String mongoDBPortParam;
        String outputFileParam;
        String validationTypeParam;
        Integer maxFetchSizeParam;
        Integer maxDiscrepanciesReportSizeParam;
        Integer validationRecordRetentionDaysParam;
        String usernameParam;
        String passwordParam;

        try {
            if (args.length >= 6) {
                commaDelimitListJsonFilenamesParam = args[0];
                connectionStringParam = args[1];
                outputFileParam = args[2];
                validationTypeParam = args[3];

                if (args[4] != null) {
                    maxFetchSizeParam = Integer.parseInt(args[4]);
                } else {
                    maxFetchSizeParam = MongoDBValidateStructure.DEFAULT_MAX_FETCH_SIZE;
                }
                if (args[5] != null) {
                    maxDiscrepanciesReportSizeParam = Integer.parseInt(args[5]);
                } else {
                    maxDiscrepanciesReportSizeParam = MongoDBValidateStructure.DEFAULT_MAX_DISCREPANCIES_REPORT_SIZE;
                }
                if (args[6] != null) {
                    validationRecordRetentionDaysParam = Integer.parseInt(args[6]);
                } else {
                    validationRecordRetentionDaysParam = MongoDBValidateStructure.DEFAULT_VALIDATION_RECORD_RETENTION_DAYS;
                }
                if (args[7] != null) {
                    usernameParam = args[7];
                } else {
                    usernameParam = MongoDBUtility.USER_CREDENTIALS_NOT_APPLICABLE;
                }
                if (args[8] != null) {
                    passwordParam = args[8];
                } else {
                    passwordParam = MongoDBUtility.USER_CREDENTIALS_NOT_APPLICABLE;
                }

                List<String> jsonSchemaFilenames = Arrays.asList(commaDelimitListJsonFilenamesParam.split(","));

                MongoDBValidateStructure runner = new MongoDBValidateStructure(jsonSchemaFilenames, connectionStringParam,
                        outputFileParam, validationTypeParam, maxFetchSizeParam, maxDiscrepanciesReportSizeParam,
                validationRecordRetentionDaysParam, usernameParam, passwordParam);
                runner.runValidation();

            } else {
                throw new Exception("Insufficient parameters passed to main method");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
