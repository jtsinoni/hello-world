package mil.jmlfdc.mongodbvalidation.processing;

import mil.jmlfdc.mongodbvalidation.model.*;
import mil.jmlfdc.mongodbvalidation.util.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.TimeZone;

/**
 * Application for running database validation of one or more MongoDB databases.
 * Contains the main method for command line (or Jenkins execution). Calls
 * SingleDBValidator once for each database being validated. Writes record in
 * MongoDB dmlesInternal database, DatabaseValidation collection, for each
 * validation performed. Writes overall summary out to text file.
 */
public class MongoDBValidateStructure {

    private static final String RESULTS_DB_NAME = "dmlesInternal";
    private static final String RESULTS_COLLECTION_NAME = "DatabaseValidation";
    private static final String OPERATING_SYSTEM = System.getProperty("os.name");
    public static final Integer DEFAULT_MAX_FETCH_SIZE = 5;
    public static final Integer DEFAULT_MAX_DISCREPANCIES_REPORT_SIZE = 5;
    public static final Integer DEFAULT_VALIDATION_RECORD_RETENTION_DAYS = 1000;
    private FileUtility fileUtil;
    private List<String> jsonSchemaFilenames;
    private String connectionString;
    private String username;
    private String password;
    private String outputFilename;
    private List<DBResult> dbResults;
    private String validationType;
    private Integer maxFetchSize;
    private Integer maxDiscrepanciesReportSize;
    private Integer validationRecordRetentionDays;
    private DateFormat dateFormatUtc;
    private DateFormat dateFormatLocal;
    private String lfChar;

    /**
     * Constructor method
     *
     * @param jsonSchemaFilenames list of JSON schema filenames (including path)
     * @param mongoDBHostName MongoDB host name
     * @param mongoDBPort MongoDB Port (e.g. 27017)
     * @param outputFilename Output filename for result display
     * @param validationType the type of validation to run
     * @param maxFetchSize max # of records to query from each collection
     * @param maxDiscrepanciesReportSize max # of discrepancies to report for
     * the entire database (after that, none more will be reported)
     * @param validationRecordRetentionDays number of days to retain validation
     * result records in the DB (old ones will be purged). Max 1000.
     */
    public MongoDBValidateStructure(List<String> jsonSchemaFilenames, String connectionString,
            String outputFilename, String validationType, Integer maxFetchSize, Integer maxDiscrepanciesReportSize,
            Integer validationRecordRetentionDays, String username, String password) {

        this.fileUtil = new FileUtility();
        this.jsonSchemaFilenames = jsonSchemaFilenames;
        this.connectionString = connectionString;
        //this.mongoDBHostName = mongoDBHostName;
        //this.mongoDBPort = mongoDBPort;
        this.outputFilename = outputFilename;
        this.dbResults = new ArrayList<DBResult>();
        this.validationType = validationType;
        this.maxFetchSize = maxFetchSize;
        this.maxDiscrepanciesReportSize = maxDiscrepanciesReportSize;
        this.username = username;
        this.password = password;

        if (validationRecordRetentionDays <= DEFAULT_VALIDATION_RECORD_RETENTION_DAYS) {
            this.validationRecordRetentionDays = validationRecordRetentionDays;
        } else {
            this.validationRecordRetentionDays = DEFAULT_VALIDATION_RECORD_RETENTION_DAYS;
        }

        if (OPERATING_SYSTEM.startsWith("Window") || OPERATING_SYSTEM.startsWith("WINDOW")) {
            this.lfChar = "\r\n";
        } else {
            this.lfChar = "\n";
        }

        dateFormatUtc = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        dateFormatUtc.setTimeZone(TimeZone.getTimeZone("UTC"));
        dateFormatLocal = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        dateFormatLocal.setTimeZone(TimeZone.getTimeZone("America/New_York"));
    }

    /**
     * Bread-and-butter "runValidation" method that does the actual work, by
     * creating the SingleDBValidator objects, running the validations, storing
     * the results to the DB, and displaying them to the output file.
     *
     * @throws Exception
     */
    public void runValidation() throws Exception {

        for (String jsonSchemaFilename : jsonSchemaFilenames) {
            SingleDBValidator singleDBValidator = new SingleDBValidator(jsonSchemaFilename, connectionString,
                    outputFilename, validationType, maxFetchSize, maxDiscrepanciesReportSize, username, password);

            DBResult singleDBResult = singleDBValidator.validateDatabase();
            saveResultToDatabase(singleDBResult);
            dbResults.add(singleDBResult);
        }

        MongoDBUtility mongoDBUtil = mongoDBUtil = new MongoDBUtility(
                connectionString, RESULTS_DB_NAME, username, password);
        mongoDBUtil.purgeOldValidationRecs(validationRecordRetentionDays);

        displayHeader();
        displayResults();
        displayFooter();
    }

    /**
     * Helper method that saves the result details for a given database (in a
     * JSON format) into the MongoDB database
     *
     * @param dbResult the dbResult for a given single database
     * @throws Exception
     */
    private void saveResultToDatabase(DBResult dbResult) throws Exception {

        MongoDBUtility mongoDBUtil = mongoDBUtil = new MongoDBUtility(
                connectionString, RESULTS_DB_NAME, username, password);

        ObjectMapper mapper = new ObjectMapper();
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        String dbResultJsonString = ow.writeValueAsString(dbResult);

        // Replace the cheesily-formatted validationDate in the dbResult with a dateTime that shows up as a nice ISODate in MongoDB
        JsonNode dbResultJsonNode = mapper.readTree(dbResultJsonString);
        Long currentTimeInMillis = new Date().getTime();
        String newValidationDateString = "{ " + quoteStr("validationDate") + " : { " + quoteStr("$date") + " : " + currentTimeInMillis + "} }";
        JsonNode newValidationDateNode = mapper.readTree(newValidationDateString);
        ((ObjectNode) dbResultJsonNode).replace("validationDate", newValidationDateNode.findValue("validationDate"));

        // With validationDate fixed, now save things to the DB
        String dbResultJsonStringFixed = ((ObjectNode) dbResultJsonNode).toString();
        mongoDBUtil.insertNewRecordJson(RESULTS_COLLECTION_NAME, dbResultJsonStringFixed);
    }

    /**
     * Helper method to write actual results details to the output file. Loops
     * through all the dbResult objects within the dbResults ArrayList, and
     * writes out to the file
     */
    private void displayResults() {
        for (DBResult dbResult : dbResults) {
            StringBuilder builder = new StringBuilder();
            builder.append(littleHeader() + lfChar);
            builder.append(String.format("Database:  %s" + lfChar + lfChar, dbResult.getJsonSchemaDatabaseName()));
            builder.append(String.format("JSON Schema definition file:  %s" + lfChar + lfChar, dbResult.getJsonSchemaFilename()));

            builder.append("Expected Collections:" + lfChar + lfChar);
            // for (DBCollectionInfo info : dbResult.getCollectionsComparedInDetail().values()) {
            //  builder.append(spaces(10) + info.getCollectionName());
            //TODO Add versioned data capability!
            //if (info.containsVersionedData()) {
            //    builder.append(" (v)");
            //}
            //  builder.append(lfChar);
            //}
            for (String collectionName : dbResult.getJsonSchemaCollectionNames()) {
                builder.append(spaces(10) + collectionName);
                //TODO Add versioned data capability!
                //if (info.containsVersionedData()) {
                //    builder.append(" (v)");
                //}
                builder.append(lfChar);
            }

            //builder.append(lfChar + "(v) = collection includes versioned data" + lfChar);
            builder.append(lfChar + littleHeader() + lfChar);

            builder.append(String.format("Total collections evaluated (based on JSON schema file)....................... %d" + lfChar,
                    dbResult.getNumCollectionsInJsonSchema()));
            builder.append(String.format("Total collections found in MongoDB database................................... %d" + lfChar,
                    dbResult.getNumCollectionsInMongoDB()));

            Integer numCollectionsMissingInMongo = dbResult.getMissingCollectionNamesInMongo().size();
            builder.append(String.format("Total expected collections NOT FOUND in the MongoDB database.................. %d" + lfChar,
                    numCollectionsMissingInMongo));

            Integer numExtraCollectionsInMongo = dbResult.getExtraCollectionNamesInMongo().size();
            builder.append(String.format("Total EXTRA collections found in the MongoDB database......................... %d" + lfChar,
                    numExtraCollectionsInMongo));

            if (numCollectionsMissingInMongo > 0) {
                builder.append(lfChar + "Expected collections missing from MongoDB:" + lfChar);
                for (String collName : dbResult.getMissingCollectionNamesInMongo()) {
                    builder.append(spaces(42) + collName + lfChar);
                }
                builder.append(lfChar);
            }

            if (numExtraCollectionsInMongo > 0) {
                builder.append("Extra collections found in MongoDB:" + lfChar);
                if (dbResult.getExtraCollectionNamesInMongo().size() > 0) {
                    for (String collName : dbResult.getExtraCollectionNamesInMongo()) {
                        builder.append(spaces(42) + collName + lfChar);
                    }
                    builder.append(lfChar);
                }
            }

            if (DBResult.VALIDATION_TYPE_COMPLETE.equals(validationType)) {
                builder.append(resultDetailsForCompleteCompare(dbResult));
            }

            builder.append(lfChar + lfChar + lfChar + lfChar);
            fileUtil.appendStringToFile(builder.toString(), outputFilename);
        }
    }

    /**
     * Helper method to show results for the detailed structural comparison (not
     * needed when comparing table names only
     *
     * @param dbResult
     * @return the result String
     */
    private String resultDetailsForCompleteCompare(DBResult dbResult) {
        String retval;
        StringBuilder builder = new StringBuilder();
        builder.append(String.format("Total collections where structure compared against DB recs.................... %d" + lfChar,
                dbResult.getNumCollectionsComparedInDetail()));
        builder.append(String.format("Total collections where all sampled DB documents agree w/JSON schema.......... %d" + lfChar,
                dbResult.getCollectionsWhereAllRecsIdentical().size()));
        builder.append(String.format("Total collections that had differences between DB documents and JSON schema... %d" + lfChar,
                dbResult.getCollectionsWhereDiscrepanciesFound().size()));
        builder.append(String.format("Total cases where ZERO documents found in DB collection to compare against.... %d" + lfChar,
                dbResult.getNumCollectionsMongoWithZeroDbRecs()));
        builder.append(String.format("Max number of records to fetch from each collection........................... %d" + lfChar,
                dbResult.getMaxFetchSize()));
        builder.append(String.format("Max number of discrepancies to report......................................... %d" + lfChar,
                dbResult.getMaxDiscrepanciesReportSize()));
        builder.append(String.format("Total discrepancies reported.................................................. %d" + lfChar,
                dbResult.getNumDiscrepanciesReported()
        ));

        if (dbResult.getDiscrepancies().size() > 0) {
            builder.append(lfChar + "Collections with discrepancies (JSON disagrees with rec(s) in collection):" + lfChar + lfChar);
            for (String collName : dbResult.getCollectionsWhereDiscrepanciesFound().keySet()) {
                builder.append(spaces(20) + collName + lfChar);
            }
            builder.append(lfChar + "Discrepancies in Detail:" + lfChar);
            String previousCollectionName = "oatmeal";
            for (Discrepancy disc : dbResult.getDiscrepancies()) {
                if (!disc.getCollectionName().equals(previousCollectionName)) {
                    previousCollectionName = disc.getCollectionName();
                    builder.append(String.format(lfChar + spaces(4) + "Collection: %s" + lfChar + lfChar, previousCollectionName));
                }
                builder.append(String.format(spaces(14) + "_id ObjectId(%s)" + lfChar, quoteStr(disc.getObjectIdString())));
                builder.append(spaces(20) + disc.getDescription() + lfChar + lfChar);
            }
        }
        retval = builder.toString();
        return retval;
    }

    /**
     * Helper method to write header info at the top of the output file
     */
    private void displayHeader() {
        StringBuilder builder = new StringBuilder();
        builder.append(bigHeader() + lfChar);
        builder.append("Running MultiDBValidationRunner" + lfChar + lfChar);
        Date date = new Date();
        builder.append("Current time (UTC)............. " + dateFormatUtc.format(date) + lfChar);
        builder.append("Current time (local)........... " + dateFormatLocal.format(date) + lfChar + lfChar);
        builder.append("MongoDB Connection String ..... " + connectionString + lfChar + lfChar);
        builder.append(String.format("Type of validation being run... %s" + lfChar + lfChar, validationType));
        builder.append("JSON Schema Files describing the Databases, which will be validated against:" + lfChar + lfChar);
        for (String filename : jsonSchemaFilenames) {
            builder.append(spaces(32) + filename + lfChar);
        }
        builder.append(bigHeader() + lfChar + lfChar);
        fileUtil.writeStringToFile(builder.toString(), outputFilename);
    }

    /**
     * Helper method to append footer/result info to the output file
     */
    private void displayFooter() {
        StringBuilder builder = new StringBuilder();
        builder.append(lfChar + lfChar);
        builder.append(bigHeader() + lfChar);
        builder.append("Finishing MultiDBValidationRunner" + lfChar + lfChar);
        Date date = new Date();
        builder.append("Current time (UTC)............. " + dateFormatUtc.format(date) + lfChar);
        builder.append("Current time (local)........... " + dateFormatLocal.format(date) + lfChar + lfChar);
        builder.append("Output file.................... " + this.outputFilename + lfChar);
        builder.append(lfChar + lfChar);
        builder.append("Have a nice day!" + lfChar);
        this.fileUtil.appendStringToFile(builder.toString(), this.outputFilename);
    }

    /**
     * Helper method to properly escape quote characters around an input string
     *
     * @param input the input string around which you want the quotation marks
     * @return the string with quotation marks properly escaped around it
     */
    private String quoteStr(String input) {
        String retval = "\"" + input + "\"";
        return retval;
    }

    /**
     * Helper method to get a bunch of blank spaces (e.g. to use at beginning of
     * an indented line).
     *
     * @param numberOfSpaces
     * @return String of blank spaces
     */
    private String spaces(int numberOfSpaces) {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < numberOfSpaces; i++) {
            builder.append(" ");
        }
        return builder.toString();
    }

    private String bigHeader() {
        return "=============================================================================================================";
    }

    private String littleHeader() {
        return "-------------------------------------------------------------------------------------------------------------";
    }

}
