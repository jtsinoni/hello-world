package mil.jmlfdc.mongodbvalidation.model;

import org.bson.types.ObjectId;

public class Discrepancy {

    private String collectionName;
    private String nodeName;
    private String objectIdString;
    private String description;

    public Discrepancy(String collectionName, String nodeName, ObjectId objectId, String description) {
        this.setCollectionName(collectionName);
        this.setNodeName(nodeName);
        this.setObjectIdString(objectId.toString());
        this.setDescription(description);
    }

    /**
     * @return the collectionName
     */
    public String getCollectionName() {
        return collectionName;
    }

    /**
     * @param collectionName the collectionName to set
     */
    public void setCollectionName(String collectionName) {
        this.collectionName = collectionName;
    }

    /**
     * @return the nodeName
     */
    public String getNodeName() {
        return nodeName;
    }

    /**
     * @param nodeName the nodeName to set
     */
    public void setNodeName(String nodeName) {
        this.nodeName = nodeName;
    }

    public String getObjectIdString() {
        return objectIdString;
    }

    /**
     * @param objectIdString the objectIdAsString to set
     */
    public void setObjectIdString(String objectIdString) {
        this.objectIdString = objectIdString;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

}
