package mil.jmlfdc.mongodbvalidation.model;

import com.fasterxml.jackson.databind.JsonNode;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

/**
 * Class that models a JsonNode, separating out the "key" (i.e. collection or
 item name) from the jsonNode itself. Contains an ArrayList of DataNode, which
 allows the ability to capture the nested JSON stuff.
 *
 */
public class DataNode {

    private String key;  // the "key" in the "key/value" pair
    private JsonNode jsonNode;   // the "value" in the "key/value" pair, a JSON jsonNode
    private ArrayList<DataNode> membersList; // Member DataNodes, the result of nested nodes within JSON
    private Map<String, DataNode> membersMap;

    public DataNode() {
    }

    /**
     * Constructor that takes in the key only
     *
     * @param dataKey the key
     */
    public DataNode(String key) {
        this.setKey(key);
        this.setMembersList(new ArrayList<DataNode>());
        this.setMembersMap(new HashMap<String, DataNode>());
    }

    /**
     * Constructor that takes in the key and the JSON jsonNode
     *
     * @param key the key
     * @param node the JSON jsonNode
     */
    public DataNode(String key, JsonNode node) {
        this.setKey(key);
        this.setJsonNode(node);
        this.setMembersList(new ArrayList<DataNode>());
        this.setMembersMap(new HashMap<String, DataNode>());
    }

    public boolean containsKey(String key) {
        boolean retval = false;
        if (this.getMembersMap() != null && this.getMembersMap().containsKey(key)) {
            retval = true;
        }
        return retval;
    }

    public DataNode getMemberByKey(String keyVal) {
        DataNode retval = new DataNode();
        if (this.getMembersMap().containsKey(keyVal)) {
            retval = this.getMembersMap().get(keyVal);
        }
        return retval;
    }

    /**
     * @return the key
     */
    public String getKey() {
        return key;
    }

    /**
     * @param key the key to set
     */
    public void setKey(String key) {
        this.key = key;
    }

    /**
     * @return the membersList
     */
    public ArrayList<DataNode> getMembersList() {
        return membersList;
    }

    /**
     * @param members the membersList to set
     */
    public void setMembersList(ArrayList<DataNode> members) {
        this.membersList = members;
    }

    /**
     * @return the JSON jsonNode
     */
    public JsonNode getJsonNode() {
        return jsonNode;
    }

    /**
     * @param node the JSON jsonNode to set
     */
    public void setJsonNode(JsonNode node) {
        this.jsonNode = node;
    }

    /**
     * @return the membersMap
     */
    public Map<String, DataNode> getMembersMap() {
        return membersMap;
    }

    /**
     * @param membersMap the membersMap to set
     */
    public void setMembersMap(Map<String, DataNode> membersMap) {
        this.membersMap = membersMap;
    }

}
