package mil.jmlfdc.mongodbvalidation.model;

import java.util.List;
import java.util.ArrayList;

public class DBCollectionInfo {
    
    private String collectionName;
    private Boolean containsVersionedData;
    private List<VersionedDataNode> versionedDataNodes;
    
    public DBCollectionInfo(String collectionName) {
        this.setCollectionName(collectionName);
        this.setContainsVersionedData(false);
        this.setVersionedDataNodes(new ArrayList<VersionedDataNode>());
    }

    /**
     * @return the collectionName
     */
    public String getCollectionName() {
        return collectionName;
    }

    /**
     * @param collectionName the collectionName to set
     */
    public void setCollectionName(String collectionName) {
        this.collectionName = collectionName;
    }

    /**
     * @return the containsVersionedData
     */
    public Boolean containsVersionedData() {
        return getContainsVersionedData();
    }

    /**
     * @param containsVersionedData the containsVersionedData to set
     */
    public void setContainsVersionedData(boolean containsVersionedData) {
        this.setContainsVersionedData((Boolean) containsVersionedData);
    }

    /**
     * @return the versionedDataNodes
     */
    public List<VersionedDataNode> getVersionedDataNodes() {
        return versionedDataNodes;
    }

    /**
     * @param versionedDataNodes the versionedDataNodes to set
     */
    public void setVersionedDataNodes(List<VersionedDataNode> versionedDataNodes) {
        this.versionedDataNodes = versionedDataNodes;
    }

    /**
     * @return the containsVersionedData
     */
    public Boolean getContainsVersionedData() {
        return containsVersionedData;
    }

    /**
     * @param containsVersionedData the containsVersionedData to set
     */
    public void setContainsVersionedData(Boolean containsVersionedData) {
        this.containsVersionedData = containsVersionedData;
    }

    
    private class VersionedDataNode {
        
        private String nodeName;
        private Integer currentVersion;
        
        public String getNodeName() {
            return nodeName;
        }
        
        public void setNodeName(String nodeName) {
            this.nodeName = nodeName;
        }
        
        public Integer getCurrentVersion() {
            return currentVersion;
        }
     
        public void setCurrentVersion(Integer currentVersion) {
            this.currentVersion = currentVersion;
        }
    }
    
}
