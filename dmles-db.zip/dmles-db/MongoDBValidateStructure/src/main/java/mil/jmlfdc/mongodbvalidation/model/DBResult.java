package mil.jmlfdc.mongodbvalidation.model;

import com.mongodb.BasicDBObject;
import java.util.ArrayList;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.time.LocalDateTime;

public class DBResult {

    public static final String VALIDATION_TYPE_COMPLETE = "COMPLETE_VALIDATION_INCLUDING_STRUCTURE";
    public static final String VALIDATION_TYPE_COLLECTION_NAMES_ONLY = "COLLECTION_NAMES_ONLY";
    private String jsonSchemaFilename;
    //private String mongoDBHostName;
    //private String mongoDBPort;

    private String connectionString;
    private String jsonSchemaDatabaseName;
    private String validationType;
    private Date validationDate;
    private Long validationMillis;

    // Numeric Variables based on comparing collection names (JSON vs DB)
    private Integer numCollectionsInJsonSchema;
    private Integer numCollectionsInMongoDB;
    private Integer numCollectionsMongoWithZeroDbRecs;

    // Lists based on comparing collection names (JSON vs DB)
    private List<String> jsonSchemaCollectionNames;
    private List<String> matchingCollectionNames;
    private List<String> missingCollectionNamesInMongo;
    private List<String> extraCollectionNamesInMongo;

    // Numeric Variables related to comparing the collection structures in detail
    private Integer numCollectionsComparedInDetail;
    private Integer numCollectionsWhereAllRecsIdentical;
    private Integer numCollectionsWhereDiscrepanciesFound;
    private Integer maxFetchSize;
    private Integer maxDiscrepanciesReportSize;
    private Integer numDiscrepanciesReported;

    // Maps based on comparing collection structures in detail
    private Map<String, DBCollectionInfo> collectionsComparedInDetail;
    private Map<String, Integer> collectionsWhereAllRecsIdentical;
    private Map<String, Integer> collectionsWhereDiscrepanciesFound;
    private List<Discrepancy> discrepancies;

    public DBResult(String jsonSchemaFilename, String connectionString,
            String jsonSchemaDatabaseName,
            String validationType, Integer maxFetchSize,
            Integer maxDiscrepanciesReportSize) throws Exception {

        this.jsonSchemaFilename = jsonSchemaFilename;
        this.connectionString = connectionString;
        //this.mongoDBHostName = mongoDBHostName;
        //this.mongoDBPort = mongoDBPort;
        this.jsonSchemaDatabaseName = jsonSchemaDatabaseName;
        this.validationType = validationType;
        this.maxFetchSize = maxFetchSize;
        this.maxDiscrepanciesReportSize = maxDiscrepanciesReportSize;

        validationDate = new Date();
        validationMillis = System.currentTimeMillis();

        numCollectionsInJsonSchema = 0;
        numCollectionsInMongoDB = 0;
        numCollectionsMongoWithZeroDbRecs = 0;

        matchingCollectionNames = new ArrayList<String>();
        missingCollectionNamesInMongo = new ArrayList<String>();
        extraCollectionNamesInMongo = new ArrayList<String>();

        numCollectionsComparedInDetail = 0;
        numCollectionsWhereAllRecsIdentical = 0;
        numCollectionsWhereDiscrepanciesFound = 0;
        collectionsComparedInDetail = new HashMap<String, DBCollectionInfo>();
        collectionsWhereAllRecsIdentical = new HashMap<String, Integer>();
        collectionsWhereDiscrepanciesFound = new HashMap<String, Integer>();
        discrepancies = new ArrayList<Discrepancy>();
    }

    public void noteMatchingCollectionName(String collName) {
        matchingCollectionNames.add(collName);
    }

    public void noteCollectionMissingFromMongo(String collName) {
        missingCollectionNamesInMongo.add(collName);
    }

    public void noteExtraCollectionInMongo(String collName) {
        extraCollectionNamesInMongo.add(collName);
    }

    public void incrementNumCollectionsWithZeroDBRecs() {
        setNumCollectionsMongoWithZeroDbRecs(getNumCollectionsMongoWithZeroDbRecs() + 1);
    }

    public void addDBCollectionInfo(DBCollectionInfo dbCollectionInfo) {
        getCollectionsComparedInDetail().put(dbCollectionInfo.getCollectionName(), dbCollectionInfo);
    }

    public void noteDiscrepancy(Discrepancy discrepancy, boolean overrideMaxReportSize) {
        if (discrepancies.size() < getMaxDiscrepanciesReportSize() || overrideMaxReportSize) {
            discrepancies.add(discrepancy);
        }
    }

    public void tallyUpDetailedComparisonTotals() {
        collectionsWhereAllRecsIdentical = new HashMap<String, Integer>();
        collectionsWhereDiscrepanciesFound = new HashMap<String, Integer>();
        if (discrepancies != null) {
            for (Discrepancy d : discrepancies) {
                collectionsWhereDiscrepanciesFound.put(d.getCollectionName(), 1);
            }
        }
        collectionsComparedInDetail.forEach((k, v) -> {
            if (!collectionsWhereDiscrepanciesFound.containsKey(k)) {
                collectionsWhereAllRecsIdentical.put(k, 1);
            }
        });
        numCollectionsComparedInDetail = collectionsComparedInDetail.size();
        numCollectionsWhereAllRecsIdentical = collectionsWhereAllRecsIdentical.size();
        numCollectionsWhereDiscrepanciesFound = collectionsWhereDiscrepanciesFound.size();
        numDiscrepanciesReported = discrepancies.size();
    }

    /**
     * @return the jsonSchemaFilename
     */
    public String getJsonSchemaFilename() {
        return jsonSchemaFilename;
    }

    /**
     * @return the mongoDBHostName
     */
    public String getConnectionString() {
        return connectionString;
    }

    /**
     * @return the jsonSchemaDatabaseName
     */
    public String getJsonSchemaDatabaseName() {
        return jsonSchemaDatabaseName;
    }

    /**
     * @return the numCollectionsInJsonSchema
     */
    public Integer getNumCollectionsInJsonSchema() {
        return numCollectionsInJsonSchema;
    }

    /**
     * @param numCollectionsInJsonSchema the numCollectionsInJsonSchema to set
     */
    public void setNumCollectionsInJsonSchema(Integer numCollectionsInJsonSchema) {
        this.numCollectionsInJsonSchema = numCollectionsInJsonSchema;
    }

    /**
     * @return the numCollectionsInMongoDB
     */
    public Integer getNumCollectionsInMongoDB() {
        return numCollectionsInMongoDB;
    }

    /**
     * @param numCollectionsInMongoDB the numCollectionsInMongoDB to set
     */
    public void setNumCollectionsInMongoDB(Integer numCollectionsInMongoDB) {
        this.numCollectionsInMongoDB = numCollectionsInMongoDB;
    }

    /**
     * @return the numCollectionsMongoWithZeroDbRecs
     */
    public Integer getNumCollectionsMongoWithZeroDbRecs() {
        return numCollectionsMongoWithZeroDbRecs;
    }

    /**
     * @return the matchingCollectionNames
     */
    public List<String> getMatchingCollectionNames() {
        return matchingCollectionNames;
    }

    /**
     * @return the missingCollectionNamesInMongo
     */
    public List<String> getMissingCollectionNamesInMongo() {
        return missingCollectionNamesInMongo;
    }

    /**
     * @return the extraCollectionNamesInMongo
     */
    public List<String> getExtraCollectionNamesInMongo() {
        return extraCollectionNamesInMongo;
    }

    /**
     * @return the numCollectionsComparedInDetail
     */
    public Integer getNumCollectionsComparedInDetail() {
        return numCollectionsComparedInDetail;
    }

    /**
     * @return the collectionsExaminedInDetail
     */
    public Map<String, DBCollectionInfo> getCollectionsComparedInDetail() {
        return collectionsComparedInDetail;
    }

    /**
     * @return the collectionsWhereAllRecsIdentical
     */
    public Map<String, Integer> getCollectionsWhereAllRecsIdentical() {
        return collectionsWhereAllRecsIdentical;
    }

    /**
     * @return the collectionsWhereDiscrepanciesFound
     */
    public Map<String, Integer> getCollectionsWhereDiscrepanciesFound() {
        return collectionsWhereDiscrepanciesFound;
    }

    /**
     * @return the discrepancies
     */
    public List<Discrepancy> getDiscrepancies() {
        return discrepancies;
    }

    /**
     * @param jsonSchemaDatabaseName the jsonSchemaDatabaseName to set
     */
    public void setJsonSchemaDatabaseName(String jsonSchemaDatabaseName) {
        this.jsonSchemaDatabaseName = jsonSchemaDatabaseName;
    }

    /**
     * @param numCollectionsMongoWithZeroDbRecs the
     * numCollectionsMongoWithZeroDbRecs to set
     */
    public void setNumCollectionsMongoWithZeroDbRecs(Integer numCollectionsMongoWithZeroDbRecs) {
        this.numCollectionsMongoWithZeroDbRecs = numCollectionsMongoWithZeroDbRecs;
    }

    /**
     * @param numCollectionsComparedInDetail the numCollectionsComparedInDetail
     * to set
     */
    public void setNumCollectionsComparedInDetail(Integer numCollectionsComparedInDetail) {
        this.numCollectionsComparedInDetail = numCollectionsComparedInDetail;
    }

    /**
     * @return the validationType
     */
    public String getValidationType() {
        return validationType;
    }

    /**
     * @param validationType the validationType to set
     */
    public void setValidationType(String validationType) {
        this.validationType = validationType;
    }

    /**
     * @return the validationDate
     */
    public Date getValidationDate() {
        return validationDate;
    }

    /**
     * @param validationDate the validationDate to set
     */
    public void setValidationDate(Date validationDate) {
        this.validationDate = validationDate;
    }

    /**
     * @return the maxFetchSize
     */
    public Integer getMaxFetchSize() {
        return maxFetchSize;
    }

    /**
     * @return the numCollectionsWhereAllRecsIdentical
     */
    public Integer getNumCollectionsWhereAllRecsIdentical() {
        return numCollectionsWhereAllRecsIdentical;
    }

    /**
     * @return the numCollectionsWhereDiscrepanciesFound
     */
    public Integer getNumCollectionsWhereDiscrepanciesFound() {
        return numCollectionsWhereDiscrepanciesFound;
    }

    /**
     * @return the maxDiscrepanciesReportSize
     */
    public Integer getMaxDiscrepanciesReportSize() {
        return maxDiscrepanciesReportSize;
    }

    /**
     * @return the numDiscrepanciesReported
     */
    public Integer getNumDiscrepanciesReported() {
        return numDiscrepanciesReported;
    }

    /**
     * @return the jsonSchemaCollectionNames
     */
    public List<String> getJsonSchemaCollectionNames() {
        return jsonSchemaCollectionNames;
    }

    /**
     * @param jsonSchemaCollectionNames the jsonSchemaCollectionNames to set
     */
    public void setJsonSchemaCollectionNames(List<String> jsonSchemaCollectionNames) {
        this.jsonSchemaCollectionNames = jsonSchemaCollectionNames;
    }

    /**
     * @return the validationMillis
     */
    public Long getValidationMillis() {
        return validationMillis;
    }

    /**
     * @param maxDiscrepanciesReportSize the maxDiscrepanciesReportSize to set
     */
    public void setMaxDiscrepanciesReportSize(Integer maxDiscrepanciesReportSize) {
        this.maxDiscrepanciesReportSize = maxDiscrepanciesReportSize;
    }

}
