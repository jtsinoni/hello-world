package mil.jmlfdc.mongodbvalidation.util;

import com.mongodb.DBCursor;
import com.mongodb.Block;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.MongoIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.DBRef;
import com.mongodb.DBObject;
import com.mongodb.DBCollection;
import com.mongodb.BasicDBObject;
import com.mongodb.ServerAddress;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCursor;
import com.mongodb.util.JSON;
import org.bson.BsonDocument;
import org.bson.types.ObjectId;
import org.bson.Document;
import org.bson.BsonDocument;

import java.util.Date;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Set;
import java.util.Collection;
import java.util.UUID;
import java.util.Map;
import java.util.HashMap;

/**
 * This class provides utilities for connecting to a MongoDB Database and
 * getting information that is required to perform conversion operations. (For
 * example, to convert from a MongoDB collection to a SQL script that creates a
 * similar structure, and which can then be reverse-engineered into Erwin, as
 * well as JPA formats and others).
 *
 * @author david.caglarcan
 */
public class MongoDBUtility {

    public static final Integer DEFAULT_MAX_FETCH_SIZE = 500;
    private static final String OPERATING_SYSTEM = System.getProperty("os.name");
    private static final String PARSE_TYPE_JSON = "parseTypeJSON";
    private static final String PARSE_TYPE_MONGOOSE = "parseTypeMongoose";
    private static final String DEFAULT_VALIDATOR_DATA_TYPE = "null";
    private static final String RESULTS_COLLECTION_NAME = "DatabaseValidation";
    public static final String USER_CREDENTIALS_NOT_APPLICABLE = "NOT_APPLICABLE";
    private DataTypeConversion dataTypeConversionToValidator;
    private String connectionString;
    private String username;
    private String password;
    private MongoCredential credential;
    private List<ServerAddress> serverAddresses;
    private String dbName;
    private MongoClient mongoClient;
    private MongoDatabase db;
    private HashMap<String, Integer> collectionNames;
    private String lfChar;

    /**
     * Constructor method, sets up database connection, etc.
     *
     * @param hostName the MongoDB host name
     * @param port the MongoDB port (e.g. 27017)
     * @param dbName the MongoDB database name
     */
    public MongoDBUtility(String connectionString, String dbName, String username, String password) throws Exception {

        if (OPERATING_SYSTEM.startsWith("Window") || OPERATING_SYSTEM.startsWith("WINDOW")) {
            this.lfChar = "\r\n";
        } else {
            this.lfChar = "\n";
        }
        
        this.connectionString = connectionString;
        this.username = username;
        this.password = password;

        setListOfServerAddresses();
        setMongoClient();

        this.dbName = dbName;
        this.db = mongoClient.getDatabase(this.dbName);
        this.dataTypeConversionToValidator = new DataTypeConversion(DataTypeConversion.CONVERSION_TYPE_BSON_TO_SCHEMA_VALIDATOR);

        setCollectionNames();
    }

    private void setListOfServerAddresses() {

        this.serverAddresses = new ArrayList<ServerAddress>();
        if (this.connectionString.contains("/")) {  // this is a replica set
            List<String> connectionStringPieces = Arrays.asList(this.connectionString.split("/"));
            String replicaSetName = connectionStringPieces.get(0).trim();
            String serverStringsConcat = connectionStringPieces.get(1).trim();
            List<String> serverStrings = Arrays.asList(serverStringsConcat.split(","));
            for (String serverString : serverStrings) {
                serverString = serverString.trim();
                String hostName = Arrays.asList(serverString.split(":")).get(0).trim();
                Integer port = Integer.parseInt(Arrays.asList(serverString.split(":")).get(1).trim());
                this.serverAddresses.add(new ServerAddress(hostName, port));
            }
        } else {  //single host---NOT a replica set
            String hostName = Arrays.asList(connectionString.split(":")).get(0).trim();
            Integer port = Integer.parseInt(Arrays.asList(connectionString.split(":")).get(1).trim());
            this.serverAddresses.add(new ServerAddress(hostName, port));
        }
    }

    private void setMongoClient() {

        if (this.username != null && !this.username.equals("") && !this.username.equalsIgnoreCase(this.USER_CREDENTIALS_NOT_APPLICABLE)
                && this.password != null && !this.password.equals("") && !this.password.equalsIgnoreCase(this.USER_CREDENTIALS_NOT_APPLICABLE)) {
            this.credential = MongoCredential.createCredential(this.username, "admin",
                    this.password.toCharArray());
            this.mongoClient = new MongoClient(this.serverAddresses, Arrays.asList(this.credential));
        } else {
            this.credential = null;
            this.mongoClient = new MongoClient(this.serverAddresses);
        }
    }

    /**
     * Takes in a JSON string, converts to a Bson Doc and inserts into MongoDB
     * collection
     *
     * @param collectionName the collection into which the document should be
     * inserted
     * @param jsonString the JSON string representing the document to be
     * inserted
     * @throws Exception
     */
    public void insertNewRecordJson(String collectionName, String jsonString)
            throws Exception {

        MongoCollection collection = db.getCollection(collectionName);
        Document doc = Document.parse(jsonString);
        collection.insertOne(doc);
    }

    /**
     * Deletes old database validation results from the MongoDB database
     *
     * @param retentionDays number of days to keep recs (delete the ones older
     * than this)
     */
    public void purgeOldValidationRecs(Integer retentionDays) {

        Long retentionDaysLong = retentionDays.longValue();
        Long nowMillis = new Date().getTime();
        Long retentionMillis = (retentionDaysLong * 24 * 60 * 60 * 1000);
        Long thresholdMillis = nowMillis - retentionMillis;

        MongoCollection collection = db.getCollection(RESULTS_COLLECTION_NAME);
        BasicDBObject query = new BasicDBObject();
        query.put("validationMillis", new BasicDBObject("$lt", thresholdMillis));
        collection.deleteMany(query);
    }

    /**
     * Populates the HashMap of collection names that exist in this MongoDB
     * database
     */
    private void setCollectionNames() {

        collectionNames = new HashMap<String, Integer>();
        MongoIterable<String> mongoDBCollectionNames = db.listCollectionNames();
        MongoCursor<String> iterator = mongoDBCollectionNames.iterator();
        while (iterator.hasNext()) {
            String collectionName = iterator.next();
            if (collectionName != null && !collectionName.equals("system.profile")) {
                collectionNames.put(collectionName, 1);
            }
        }
    }

    /**
     * Returns a HashMap of the collection names that exist in this MongoDB
     * database. Will return empty HashMap if there are no collections in this
     * database.
     *
     * @return the collection names HashMap (key = collection name, value = 1)
     */
    public Map<String, Integer> getCollectionNames() {
        return collectionNames;
    }

    /**
     * Gets a single BSON Document (equivalent to running a findOne() query in
     * Mongo DB), and returns it in a "raw" JSON-type format that is provided in
     * the Document API. Returns empty String if no doc returned from query.
     *
     * @param hostNameAndPort hostname:port of the DB server
     * @param dbName DB name to query
     * @param collectionName collection name to query
     * @return the single raw JSON String
     * @throws Exception
     */
    public String getOneDocAsRawJSONString(String collectionName)
            throws Exception {

        String retval = "";
        Document doc;
        FindIterable<Document> iterable = db.getCollection(collectionName).find();
        doc = iterable.first();

        if (doc != null) {
            retval = doc.toJson();
        }
        return retval;
    }

    /**
     * Gets a single BSON Document (equivalent to running a findOne() query in
     * Mongo DB), converts it to a JSON definition in the form of a String.
     * Returns empty String if no doc returned from query.
     *
     * @param collectionName collection name to query
     * @return the JSON String
     * @throws Exception
     */
    public String getOneDocAsJSONSchemaDefString(String collectionName)
            throws Exception {

        String retval = "";
        Document doc = getOneBSONDoc(collectionName);
        if (doc != null) {
            retval = convertBSONDocToJSONSchemaDef(doc, collectionName);
        }
        return retval;
    }

    /**
     * Gets multiple BSON Documents (equivalent to running a find() query in
     * Mongo DB), converts it to a JSON definition in the form of a String.
     * Returns empty String if no doc returned from query. Number of records
     * limited by maxFetchSize param.
     *
     * @param collectionName collection name to query
     * @return ArrayList of JSON Schema defs (1 for each document returned by
     * query), or empty ArrayList<String> if no recs found
     * @throws Exception
     */
    public List<String> getMultipleDocsAsJSONSchemaDefStrings(
            String collectionName, Integer maxFetchSize) throws Exception {

        List<String> retval = new ArrayList<String>();
        List<Document> docs = this.getMultipleBSONDocs(
                collectionName, maxFetchSize);

        for (Document doc : docs) {
            retval.add(convertBSONDocToJSONSchemaDef(doc, collectionName));
        }
        return retval;
    }

    public Map<ObjectId, String> getMultipleDocsAsJSONSchemaDefs(String collectionName,
            Integer maxFetchSize) throws Exception {

        Map<ObjectId, String> retval = new HashMap<ObjectId, String>();
        List<Document> docs = this.getMultipleBSONDocs(
                collectionName, maxFetchSize);

        for (Document doc : docs) {
            ObjectId id = (ObjectId) doc.get("_id");
            retval.put(id, convertBSONDocToJSONSchemaDef(doc, collectionName));
        }
        return retval;
    }

    /**
     * Gets a single BSON Document (equivalent to running a findOne() query in
     * MongoDB).
     *
     * @param collectionName collection name to query
     * @return the single BSON Document, or an empty BSON document of none
     * returned by query
     * @throws Exception
     */
    public Document getOneBSONDoc(String collectionName)
            throws Exception {

        Document retval;
        FindIterable<Document> iterable = db.getCollection(collectionName).find();
        retval = iterable.first();

        if (retval == null) {
            retval = new Document();
        }
        return retval;
    }

    /**
     * Gets multiple BSON documents (equivalent to running a find() query in
     * MongoDB, but will limit the size of the result set based on the
     * maxFetchSize param.
     *
     * @param collectionName collection name to query
     * @param maxFetchSize the max amount of records to return
     * @return a List of Documents. Will return empty list of no recs found.
     * @throws Exception
     */
    public List<Document> getMultipleBSONDocs(String collectionName, Integer maxFetchSize)
            throws Exception {

        List<Document> retval = new ArrayList<Document>();

        if (maxFetchSize == null || maxFetchSize == 0) {
            maxFetchSize = DEFAULT_MAX_FETCH_SIZE;
        }

        MongoCollection collection = db.getCollection(collectionName);
        FindIterable<Document> iterable = collection.find().limit(maxFetchSize);
        iterable.forEach(new Block<Document>() {
            public void apply(final Document doc) {
                retval.add(doc);
            }
        });
        return retval;
    }

    /**
     * Converts a BSON Document to a JSON schema definition String.
     *
     * @param bsonDoc the BSON Document
     * @param collectionName the name of the collection (for proper labeling
     * within the output)
     * @return the JSON String
     * @throws Exception
     */
    private String convertBSONDocToJSONSchemaDef(Document bsonDoc, String collectionName)
            throws Exception {
        String retval = "";
        StringBuilder builder = new StringBuilder();
        parseBSONDocForJSONOrMongoose(bsonDoc, collectionName, builder, dataTypeConversionToValidator, PARSE_TYPE_JSON);
        retval = builder.toString();
        retval = cleanupJSON(retval);
        return retval;
    }

    /**
     * Parses through the BSON document, builds a JSON string into the
     * StringBuilder that is passed in as a parameter. Depending on the
     * parseType, will include a JSON-style header, or a Mongoose schema
     * creation style header. Makes recursive calls back to itself as it works
     * its way through the nested BSON structures.
     *
     * @param doc the BSON document
     * @param collectionName the name of the collection in the DB
     * @param builder the StringBuilder object into which the JSON string should
     * be written.
     * @param dataTypeConversion the data type conversion (e.g.
     * DataTypeConversoin.CONVERSION_TYPE_BSON_TO_JPA, or
     * CONVERSION_TYPE_BSON_TO_MONGOOSE).
     * @param parseType the type of parsing (e.g. PARSE_TYPE_JSON or
     * PARSE_TYPE_MONGOOSE)
     * @throws Exception
     */
    private void parseBSONDocForJSONOrMongoose(Document doc, String collectionName,
            StringBuilder builder, DataTypeConversion dataTypeConversion, String parseType)
            throws Exception {
        // At very top, first time through, append header-type text
        if (collectionName != null && !collectionName.equals("")) {
            if (PARSE_TYPE_JSON.equals(parseType)) {
                builder.append("{" + lfChar + quoteStr(collectionName) + ": {" + lfChar);
            } else if (PARSE_TYPE_MONGOOSE.equals(parseType)) {
                builder.append("var " + collectionName + "Schema = new mongoose.Schema({" + lfChar);
            } else {
                throw new Exception("Invalid parseType parameter passed in!");
            }
        }
        // Now press ahead with logic
        Set<String> keys = doc.keySet();
        List<String> keysList = new ArrayList<String>();
        keysList.addAll(keys);
        Collection<Object> vals = doc.values();
        List<Object> valsList = new ArrayList<Object>();
        valsList.addAll(vals);

        for (int i = 0; i < keysList.size(); i++) {
            String key = keysList.get(i);
            Object valObject = valsList.get(i);

            if (valObject != null) {

                if (valObject instanceof ArrayList) {
                    builder.append(quoteStr(key) + ": [{" + lfChar);

                    if (((ArrayList) valObject).size() > 0) {
                        Object firstItem = ((ArrayList) valObject).get(0);
                        if (firstItem instanceof Document) {
                            parseBSONDocForJSONOrMongoose((Document) firstItem, null, builder, dataTypeConversion, parseType);
                        } else if (firstItem instanceof DBRef) {
                            builder.append(quoteStr("$ref") + ": {" + lfChar
                                    + quoteStr("type") + ": " + quoteStr(((DBRef) firstItem).getCollectionName()) + lfChar + "}," + lfChar
                                    + quoteStr("$id") + ": {" + lfChar
                                    + quoteStr("type") + ": " + quoteStr("ObjectId") + lfChar + "}," + lfChar);
                        }
                    }
                    builder.append("}]," + lfChar);
                } else if (valObject instanceof Document) {

                    builder.append(quoteStr(key) + ": {" + lfChar);
                    parseBSONDocForJSONOrMongoose((Document) valObject, null, builder, dataTypeConversion, parseType);
                    builder.append("}," + lfChar);

                } else if (valObject instanceof DBRef) {
                    builder.append(quoteStr(key) + ": {" + lfChar
                            + quoteStr("$ref") + ": {" + lfChar
                            + quoteStr("type") + ": " + quoteStr(((DBRef) valObject).getCollectionName()) + lfChar + "}," + lfChar
                            + quoteStr("$id") + ": {" + lfChar
                            + quoteStr("type") + ": " + quoteStr("ObjectId") + lfChar + "}," + lfChar
                            + "}," + lfChar);
                } else {
                    String dataType = dataTypeConversion.convert(valObject.getClass().toString());
                    builder.append(quoteStr(key) + ": {" + lfChar
                            + quoteStr("type") + ": " + quoteStr(dataType) + lfChar + "}," + lfChar);
                }
            } else { // value is null, cannot determine datatype, therefore use default
                builder.append(quoteStr(key) + ": {" + lfChar
                        + quoteStr("type") + ": " + quoteStr(this.DEFAULT_VALIDATOR_DATA_TYPE) + lfChar + "}," + lfChar);
            }
        }
        // At very bottom, at the end of the last time through, add footer text
        if (collectionName != null && !collectionName.equals("")) {
            if (PARSE_TYPE_JSON.equals(parseType)) {
                builder.append("}" + lfChar + "}" + lfChar);
            } else if (PARSE_TYPE_MONGOOSE.equals(parseType)) {
                builder.append("}" + lfChar + ");" + lfChar);
            }
        }
    }

    /**
     * Helper method, cleans up extra symbols and junk left from the initial
     * parse of the BSON into JSON, so that the end result can be parsed by
     * Jackson later.
     *
     * @param roughJSON the non-cleaned-up JSON
     * @return the cleaned-up JSON
     */
    private String cleanupJSON(String roughJSON) {
        String retval = roughJSON;
        retval = retval.replace(
                ("[{" + lfChar + "}]"), "{" + lfChar + quoteStr("type") + ": " + quoteStr("Array") + lfChar + "}");

        while (retval.contains(("}," + lfChar + "}"))) {
            retval = retval.replace(("}," + lfChar + "}"), ("}" + lfChar + "}"));
        }
        retval = retval.replace(("}]," + lfChar), ("}]" + lfChar));
        retval = retval.replace(("}]" + lfChar + "\""), ("}]," + lfChar + "\""));
        return retval;
    }

    /**
     * Helper method, encloses the String in double quotes.
     *
     * @param input the input String
     * @return the String with quotes around it.
     */
    private String quoteStr(String input) {
        String retval = "\"" + input + "\"";
        return retval;
    }

    /**
     * Helper method, removes quotes from a String. Useful when you need to
     * transform straight JSON into Mongoose schema definition.
     *
     * @param input the input String
     * @return the String with quotes removed.
     */
    private String removeQuotes(String input) {
        String retval = input;
        retval = retval.replace("\"", "");
        return retval;
    }
}
