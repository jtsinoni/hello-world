package mil.jmlfdc.mongodbvalidation.util;

/**
 * Class that provides appropriate conversion of a 'data type String' from one
 * format (e.g. a Mongoose format) to another format ((e.g. a SQL format). For
 * example, this Class can be used when you need to convert your Mongoose
 * "String" datatypes into Oracle "VARCHAR2(NN)" etc.).
 *
 */
public class DataTypeConversion {

    public static final String CONVERSION_TYPE_NO_CHOICE = "No Choice Selected (or N/A)";
    public static final String CONVERSION_TYPE_MONGOOSE_TO_SQL = "Convert Mongoose data type to SQL data type";
    public static final String CONVERSION_TYPE_MONGOOSE_TO_JPA = "Convert Mongoose data type to Java Persistence API (JPA) data type";
    public static final String CONVERSION_TYPE_BSON_TO_MONGOOSE = "Convert BSON data type (as read into Java by the Mongo driver) to Mongoose data type";
    public static final String CONVERSION_TYPE_BSON_TO_JPA = "Convert BSON data type (as read into Java by the Mongo driver) to Java Persistence API (JPA) data type";
    public static final String CONVERSION_TYPE_BSON_TO_MONGODB_VALIDATOR = "Convert BSON data type (as read into Java by the Mongo driver) to MongoDB data type as listed in a MongoDB collection Validator";
    public static final String CONVERSION_TYPE_BSON_TO_SCHEMA_VALIDATOR = "Minimal conversion, for validating against JSON schema file representing expected DB structure.";
    
    private String conversionType;

    /**
     * Constructor requires caller to indicate which type of conversion is being
     * done. Must be one of the Constants defined in this class.
     *
     * @param conversionType the type of datatype conversion being done.
     * @throws Exception
     */
    public DataTypeConversion(String conversionType) throws Exception {
        this.setConversionType(conversionType);
    }

    /**
     * Perform the convert operation, based on the type of conversion we are
     * doing.
     *
     * @param initDataTypeString the intiial datatype string (e.g. "String")
     * @return the converted datatype string (e.g. "VARCHAR2(NN)")
     * @throws Exception
     */
    public String convert(String initDataTypeString) {
        String retval = "";
        switch (getConversionType()) {
            case CONVERSION_TYPE_MONGOOSE_TO_SQL:
                retval = mongooseToSQLDataType(initDataTypeString);
                break;
            case CONVERSION_TYPE_MONGOOSE_TO_JPA:
                retval = mongooseToJPADataType(initDataTypeString);
                break;
            case CONVERSION_TYPE_BSON_TO_MONGOOSE:
                retval = bsonDocToMongooseDataType(initDataTypeString);
                break;
            case CONVERSION_TYPE_BSON_TO_JPA:
                retval = bsonDocToJPADataType(initDataTypeString);
                break;
            case CONVERSION_TYPE_BSON_TO_MONGODB_VALIDATOR:
                retval = bsonDocToMongoDBValidatorDataType(initDataTypeString);
                break;
            case CONVERSION_TYPE_BSON_TO_SCHEMA_VALIDATOR:
                retval = bsonDocToSchemaValidationType(initDataTypeString);
                break;
            case CONVERSION_TYPE_NO_CHOICE:
                retval = "";
                break;
            default:
                retval = "";
                break;
        }
        return retval;
    }

    /**
     * Converts a String that includes Mongoose/JSON datatype info (e.g. String,
     * Integer) to a SQL datatype (e.g. VARCHAR2(200), NUMBER)
     *
     * @param initDataTypeString the initial String representing a Mongoose/JSON
     * datatype
     * @return the String representing a SQL datatype
     */
    private String mongooseToSQLDataType(String initDataTypeString) {
        String retval = "";
        if (initDataTypeString.startsWith("[{") && initDataTypeString.endsWith("}]")) {
            retval = "Array";
        } else if (initDataTypeString.contains("Array")) {
            retval = "Array";
        } else if (initDataTypeString.contains("String")) {
            retval = "VARCHAR2(200)";
        } else if (initDataTypeString.contains("Number")) {
            retval = "NUMBER";
        } else if (initDataTypeString.contains("Integer") || initDataTypeString.contains("Float") || initDataTypeString.contains("Double") || initDataTypeString.contains("Long")) {
            retval = "NUMBER";
        } else if (initDataTypeString.contains("Date")) {
            retval = "DATE";
        } else if (initDataTypeString.contains("Boolean")) {
            retval = "VARCHAR2(1)";
        } else if (initDataTypeString.contains("mongoose.Schema.Types.ObjectId")) {
            retval = "RAW(16)";
        } else if (initDataTypeString.contains("Object")) {
            retval = "RAW(16)";
        }
        return retval;
    }

    /**
     * Converts a String that includes Mongoose/JSON datatype info (e.g. String,
     * Integer) to a legit Java datatype that could be included for a variable
     * in a Java JPA class.
     *
     * @param initDataTypeString the initial String representing a Mongoose/JSON
     * datatype
     * @return the String representing the Java/JPA datatype
     */
    private String mongooseToJPADataType(String initDataTypeString) {
        String retval = "";
        if (initDataTypeString.startsWith("[{") && initDataTypeString.endsWith("}]")) {
            retval = "Array";
        } else if (initDataTypeString.contains("Array")) {
            retval = "Array";
        } else if (initDataTypeString.contains("String")) {
            retval = "String";
        } else if (initDataTypeString.contains("Number")) {
            retval = "Integer";
        } else if (initDataTypeString.contains("Integer")) {
            retval = "Integer";
        } else if (initDataTypeString.contains("Double")) {
            retval = "Double";
        } else if (initDataTypeString.contains("Float")) {
            retval = "Float";
        } else if (initDataTypeString.contains("Long")) {
            retval = "Long";
        } else if (initDataTypeString.contains("Date")) {
            retval = "LocalDateTime";
        } else if (initDataTypeString.contains("Boolean")) {
            retval = "Boolean";
        } else if (initDataTypeString.contains("mongoose.Schema.Types.ObjectId")) {
            retval = "String";
        } else if (initDataTypeString.contains("Object")) {
            retval = "String";
        }
        return retval;
    }

    /**
     * Converts BSON Document data type to a Mongoose data type
     *
     * @param initDataTypeString the BSON Document data type
     * @return the Mongoose data type
     */
    private String bsonDocToMongooseDataType(String initDataTypeString) {
        String retval = "";
        //TODO Add additional types in here
        if (initDataTypeString.contains("String")) {
            retval = "String";
        } else if (initDataTypeString.contains("Integer")) {
            retval = "Number";
        } else if (initDataTypeString.contains("Double")) {
            retval = "Number";
        } else if (initDataTypeString.contains("Float")) {
            retval = "Number";
        } else if (initDataTypeString.contains("Long")) {
            retval = "Long";
        } else if (initDataTypeString.contains("Boolean")) {
            retval = "Boolean";
        } else if (initDataTypeString.contains("Date")) {
            retval = "Date";
        } else if (initDataTypeString.contains("mongoose.Schema.Types.ObjectId")) {
            retval = "String";
        } else if (initDataTypeString.contains("Object")) {
            retval = "String";
        }
        return retval;
    }

    /**
     * Converts BSON Document data type to a Java JPA data type
     *
     * @param initDataTypeString the BSON Document data type
     * @return the Java JPA data type
     */
    private String bsonDocToJPADataType(String initDataTypeString) {
        String retval = "";
        if (initDataTypeString.contains("String")) {
            retval = "String";
        } else if (initDataTypeString.contains("Integer")) {
            retval = "Integer";
        } else if (initDataTypeString.contains("Double")) {
            retval = "Double";
        } else if (initDataTypeString.contains("Float")) {
            retval = "Float";
        } else if (initDataTypeString.contains("Long")) {
            retval = "Long";
        } else if (initDataTypeString.contains("Boolean")) {
            retval = "Boolean";
        } else if (initDataTypeString.contains("Date")) {
            retval = "LocalDateTime";
        } else if (initDataTypeString.contains(
                "org.bson.types.ObjectId")) {
            retval = "mongoose.Schema.Types.ObjectId";
        } else if (initDataTypeString.contains("UUID")) {
            retval = "UUID";
        }
        return retval;
    }

    /**
     * Converts BSON Document data type to a data type "alias" as it would
     * appear in code creating a MongoDB Validator for a particular collection.
     *
     * @param initDataTypeString the BSON document data type
     * @return the data type "alias" as it appears in MongoDB Validator code
     * @see
     * <a href="https://docs.mongodb.org/manual/reference/operator/query/type/">https://docs.mongodb.org/manual/reference/operator/query/type/</a>
     */
    private String bsonDocToMongoDBValidatorDataType(String initDataTypeString) {
        String retval = "";
        if (initDataTypeString.contains("String")) {
            retval = "string";
        } else if (initDataTypeString.contains("Integer")) {
            retval = "number";  // will work for both 32-bit and 64-bit integer...
        } else if (initDataTypeString.contains("Double")) {
            retval = "number";  // using number for now, due to funky way MongoDB sometimes seems to convert integers into double
        } else if (initDataTypeString.contains("Float")) { // should never occur...
            retval = "number";
        } else if (initDataTypeString.contains("Long")) {
            retval = "long";
        } else if (initDataTypeString.contains("Boolean")) {
            retval = "bool";
        } else if (initDataTypeString.contains("Date")) {
            retval = "date";
        } else if (initDataTypeString.contains("Timestamp")) {
            retval = "timestamp";
        } else if (initDataTypeString.contains(
                "org.bson.types.ObjectId")) {
            retval = "objectId";
        }
        return retval;
    }
    
    
    private String bsonDocToSchemaValidationType(String initDataTypeString) {
        String retval = "";
        if (initDataTypeString.contains("String")) {
            retval = "String";
        } else if (initDataTypeString.contains("Integer")) {
            retval = "Number";  // will work for both 32-bit and 64-bit integer...
        } else if (initDataTypeString.contains("Double")) {
            retval = "Number";  // using number for now, due to funky way MongoDB sometimes seems to convert integers into double
        } else if (initDataTypeString.contains("Float")) { // should never occur...
            retval = "Number";
        } else if (initDataTypeString.contains("Long")) {
            retval = "Long";
        } else if (initDataTypeString.contains("Boolean")) {
            retval = "Boolean";
        } else if (initDataTypeString.contains("Date")) {
            retval = "Date";
        } else if (initDataTypeString.contains("Timestamp")) {
            retval = "Timestamp";
        } else if (initDataTypeString.contains(
                "org.bson.types.ObjectId")) {
            retval = "ObjectId";
        } else {
            System.out.println("Neato!");
        }
        return retval;
    }

    /**
     * Determines if the conversion type that has bee indicated is a valid one.
     *
     * @param conversionType the conversionType. Must be one of the Conversion
     * Type constants defined in this class.
     * @return true or false
     */
    private boolean isValidConversionType(String conversionType) {
        boolean retval = false;
        if (CONVERSION_TYPE_MONGOOSE_TO_SQL.equals(conversionType)
                || CONVERSION_TYPE_MONGOOSE_TO_JPA.equals(conversionType)
                || CONVERSION_TYPE_BSON_TO_MONGOOSE.equals(conversionType)
                || CONVERSION_TYPE_BSON_TO_JPA.equals(conversionType)
                || CONVERSION_TYPE_NO_CHOICE.equals(conversionType)
                || CONVERSION_TYPE_BSON_TO_MONGODB_VALIDATOR.equals(conversionType)
                || CONVERSION_TYPE_BSON_TO_SCHEMA_VALIDATOR.equals(conversionType)) {
            retval = true;
        }
        return retval;
    }

    /**
     * Only sets the conversionType after validating the input value.
     *
     * @param conversionType the conversionType to set
     */
    public void setConversionType(String conversionType) throws Exception {
        if (isValidConversionType(conversionType)) {
            this.conversionType = conversionType;
        } else {
            throw new Exception("Invalid Conversion Type!");
        }
    }

    /**
     * @return the conversionType
     */
    public String getConversionType() {
        return conversionType;
    }
}
