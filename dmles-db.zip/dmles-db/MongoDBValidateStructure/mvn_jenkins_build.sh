#!/bin/sh

cd $1

mvn clean package
