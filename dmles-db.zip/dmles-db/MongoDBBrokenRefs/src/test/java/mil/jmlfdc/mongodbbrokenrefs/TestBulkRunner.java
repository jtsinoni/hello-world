package mil.jmlfdc.mongodbbrokenrefs;

import mil.jmlfdc.mongodbbrokenrefs.processing.BulkRunner;

/**
 *
 * Basic class for unit testing of the MongoDBFindBrokenRefs project
 */
public class TestBulkRunner {

    private void runTestWithPropsFileParamSecure() {

        String[] params = {"replDMLES01/dmeddb3001:27017,dmeddb3002:27017,dmeddb3003:27017",
            "C:\\Workspace\\temp4\\broken_refs1.txt",
            "findBrokenRefs.properties",
            "username", "password" // replace with correct values to run test
    };
        App.main(params);
    }

    private void runTestWithoutPropsFileParamSecure() {

        String[] params = {"replDMLES01/dmeddb3001:27017,dmeddb3002:27017,dmeddb3003:27017",
            "C:\\Workspace\\temp4\\broken_refs99.txt", null,
            "dave.caglarcan", "nnnnnnnnnn" // replace with correct values to run test
    };
        App.main(params);
    }

    private void runTestWithPropsFileParamNotSecure() {
        String[] params = {"replDMLES01/dmetdb4001:27017,dmetdb4002:27017,dmetdb4003:27017",
            "C:\\Workspace\\temp4\\broken_refs3.txt",
            "findBrokenRefs.properties"
        };
        App.main(params);
    }

    private void runTestWithoutPropsFileParamNotSecure() {
        String[] params = {"localhost:27017",
            "C:\\Workspace\\temp4\\broken_refs999.txt"
        };
        App.main(params);
    }

    public static void main(String args[]) {
        TestBulkRunner testBulkRunner = new TestBulkRunner();
        //testBulkRunner.runTestWithPropsFileParamSecure();
        //testBulkRunner.runTestWithoutPropsFileParamSecure();
        //testBulkRunner.runTestWithoutPropsFileParamSecure();
        testBulkRunner.runTestWithoutPropsFileParamNotSecure();
    }
}
