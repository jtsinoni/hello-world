package mil.jmlfdc.mongodbbrokenrefs.util;

import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.MongoIterable;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.FindIterable;
import com.mongodb.Block;
import com.mongodb.MongoClient;
import org.bson.types.ObjectId;
import org.bson.Document;
import java.util.List;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Set;

public class MapOfIDs {

    private MongoDatabase db;
    private String collectionName;
    private Map<ObjectId, Integer> objectIdsMap;
    private Map<String, Integer> objectIdStringsMap;
    private Integer numberOfIds;

    /**
     * Constructor
     *
     * @param db the MongoDatabase object
     * @param collectionName the name of the collection
     */
    public MapOfIDs(MongoDatabase db, String collectionName) {
        this.db = db;
        this.collectionName = collectionName;
        this.objectIdsMap = new HashMap<ObjectId, Integer>();
        this.objectIdStringsMap = new HashMap<String, Integer>();
        this.populateMap();
        this.populateMapOfStrings();
    }

    private void populateMap() {
        this.objectIdsMap.clear();
        this.numberOfIds = 0;
        List<String> keysList = new ArrayList<String>();
        List<Object> valsList = new ArrayList<Object>();
        FindIterable<Document> iterable = getDb().getCollection(getCollectionName()).find();
        iterable.forEach(new Block<Document>() {
            public void apply(final Document doc) {
                Set<String> keys = doc.keySet();
                keysList.addAll(keys);
                Collection<Object> vals = doc.values();
                valsList.addAll(vals);
            }
        });
        for (int i = 0; i < keysList.size(); i++) {
            if (keysList.get(i).equals("_id") && valsList.get(i) instanceof ObjectId) {
                this.objectIdsMap.put((ObjectId) valsList.get(i), 1);
                this.numberOfIds++;
            }
        }
    }

    private void populateMapOfStrings() {
        this.objectIdStringsMap.clear();
        Iterator it = this.objectIdsMap.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pair = (Map.Entry) it.next();
            this.objectIdStringsMap.put(pair.getKey().toString(), (Integer) pair.getValue());
        }
    }

    public boolean containsObjectId(ObjectId objectId) {
        boolean retval = false;
        if (this.objectIdsMap.containsKey(objectId)) {
            retval = true;
        }
        return retval;
    }

    public boolean containsObjectIdString(String objectIdString) {
        boolean retval = false;
        if (this.objectIdStringsMap.containsKey(objectIdString)) {
            retval = true;
        }
        return retval;
    }

    /**
     * @return the collectionName
     */
    public String getCollectionName() {
        return collectionName;
    }

    /**
     * @return the db
     */
    public MongoDatabase getDb() {
        return db;
    }

    /**
     * @return the numberOfIds
     */
    public Integer getNumberOfIds() {
        return numberOfIds;
    }
}
