package mil.jmlfdc.mongodbbrokenrefs.processing;

import mil.jmlfdc.mongodbbrokenrefs.util.MapOfIDs;
import com.mongodb.DBRef;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.FindIterable;
import com.mongodb.Block;
import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;
import org.bson.types.ObjectId;
import org.bson.Document;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Set;

/**
 *
 * Class who's purpose is to find broken $ref (i.e. DBRef) items within a given
 * MongoDB collection in a given MongoDB database. Primary method
 * findBrokenRefs() returns a big String with a result narrative indicating the
 * number of bad $refs found, number of good $refs found, and also points out
 * the bad ones individually.
 */
public class MongoDBBrokenRefsFinder {

    private static final String OPERATING_SYSTEM = System.getProperty("os.name");
    public static final String USER_CREDENTIALS_NOT_APPLICABLE = "NOT_APPLICABLE";
    private String connectionString;
    private String username;
    private String password;
    private MongoCredential credential;
    private List<ServerAddress> serverAddresses;

    private String dbName;
    private String collectionName;

    private MongoClient mongoClient;
    private MongoDatabase db;

    private String lfChar;

    private ArrayList<String> itemsWithRef;
    private ArrayList<String> parentDatabaseNames;
    private ArrayList<String> parentCollections;
    private Integer numGoodRefsFound;
    private Integer numBrokenRefsFound;
    private StringBuilder resultBuilder;
    private String result;

    /**
     * Constructor method
     *
     * @param connectionString
     * @param dbName
     * @param collectionName
     * @param username
     * @param password
     */
    public MongoDBBrokenRefsFinder(String connectionString,
            String dbName, String collectionName,
            String username, String password) {

        if (OPERATING_SYSTEM.startsWith("Window") || OPERATING_SYSTEM.startsWith("WINDOW")) {
            this.lfChar = "\r\n";
        } else {
            this.lfChar = "\n";
        }

        this.connectionString = connectionString;
        this.username = username;
        this.password = password;

        setListOfServerAddresses();
        setMongoClient();

        this.dbName = dbName;
        this.collectionName = collectionName;
        this.db = mongoClient.getDatabase(this.dbName);
        this.itemsWithRef = new ArrayList<String>();
        this.parentDatabaseNames = new ArrayList<String>();
        this.parentCollections = new ArrayList<String>();
        this.resultBuilder = new StringBuilder();
        this.result = "";
        this.numGoodRefsFound = 0;
        this.numBrokenRefsFound = 0;
    }

    private void setListOfServerAddresses() {

        this.serverAddresses = new ArrayList<ServerAddress>();
        if (this.connectionString.contains("/")) {  // this is a replica set
            List<String> connectionStringPieces = Arrays.asList(this.connectionString.split("/"));
            String replicaSetName = connectionStringPieces.get(0).trim();
            String serverStringsConcat = connectionStringPieces.get(1).trim();
            List<String> serverStrings = Arrays.asList(serverStringsConcat.split(","));
            for (String serverString : serverStrings) {
                serverString = serverString.trim();
                String hostName = Arrays.asList(serverString.split(":")).get(0).trim();
                Integer port = Integer.parseInt(Arrays.asList(serverString.split(":")).get(1).trim());
                this.serverAddresses.add(new ServerAddress(hostName, port));
            }
        } else {  //single host---NOT a replica set
            String hostName = Arrays.asList(connectionString.split(":")).get(0).trim();
            Integer port = Integer.parseInt(Arrays.asList(connectionString.split(":")).get(1).trim());
            this.serverAddresses.add(new ServerAddress(hostName, port));
        }
    }

    private void setMongoClient() {

        if (this.username != null && !this.username.equals("") && !this.username.equalsIgnoreCase(this.USER_CREDENTIALS_NOT_APPLICABLE)
                && this.password != null && !this.password.equals("") && !this.password.equalsIgnoreCase(this.USER_CREDENTIALS_NOT_APPLICABLE)) {
            this.credential = MongoCredential.createCredential(this.username, "admin",
                    this.password.toCharArray());
            this.mongoClient = new MongoClient(this.serverAddresses, Arrays.asList(this.credential));
        } else {
            this.credential = null;
            this.mongoClient = new MongoClient(this.serverAddresses);
        }
    }

    /**
     * This is the primary, bread-and-butter method of the class. It will do the
     * analysis and then return a big String containing the result narrative.
     * This method calls the correct, specific method based on the DB and
     * collection name entered. For certain collections (those having a single,
     * mainline $ref item or Array), generic methods are called. For others
     * (those with multiple $ref items and/or more complex structure), custom
     * methods are called.
     */
    public String findBrokenRefs() {
        try {
            if (this.dbName.equals("dmlesUser") || this.dbName.equals("dave")) {
                switch (this.collectionName) {
                    case "AppUserProfile":
                        fbr_genericArrayRef(this.collectionName, "roles", "Role", this.dbName);
                        fbr_dmles_user_genericAssignedPermissions(this.collectionName);
                        break;

                    case "Permission":
                        fbr_genericArrayRef(this.collectionName, "endpoints", "Endpoint", this.dbName);
                        fbr_genericArrayRef(this.collectionName, "states", "State", this.dbName);
                        fbr_genericArrayRef(this.collectionName, "elements", "Element", this.dbName);
                        break;
                    case "Role":
                        //fbr_dmles_user_Roles();
                        fbr_dmles_user_genericAssignedPermissions(this.collectionName);
                        fbr_genericArrayRef(this.collectionName, "roles", this.collectionName, this.dbName);
                        break;
                    case "Site":
                        fbr_genericSingleRef(
                                this.collectionName, "service", "Services", this.dbName);
                        break;
                    default:
                        rejectInvalidParams();
                        break;
                }
            } else if (this.dbName.equals("dmlesEquipment") || this.dbName.equals("dave-e")) {
                switch (this.collectionName) {
                    case "EquipmentRequest":
                        fbr_genericSingleRef(
                                this.collectionName, "wfProcessing", "EquipmentRequestWorkflowProcess", this.dbName);
                        break;
                    case "EquipmentRequestWorkflowProcess":
                        fbr_genericSingleRef(
                                this.collectionName, "wfDefinition", "EquipmentRequestWorkflowDefinition", this.dbName);
                        fbr_genericSingleSoftRef(
                                this.collectionName, "requestId", "EquipmentRequest", this.dbName);
                        break;
                    case "EquipmentRequestWorkflowDefinition":
                        this.fbr_genericSingleSoftRefWithinArray(this.collectionName, "levelDefinitions", "ownerRoleId", "Role", "dmlesUser");
                    default:
                        rejectInvalidParams();
                        break;
                }
            } else {
                rejectInvalidParams();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        this.result = this.resultBuilder.toString();
        return this.result;
    }

    /**
     * Use this method to look for broken $ref items where the $ref is a
     * "mainline" item (i.e. NOT nested, not an Array) within the collection
     *
     * @param collectionName the name of the collection that contains the $ref
     * item
     * @param refItemName the name of the $ref item
     * @param parentCollectionName the name of the parent collection to which
     * @param parentCollectionDatabaseName the database where the parent
     * collection lives the $ref item refers
     * @throws Exception
     */
    private void fbr_genericSingleRef(String collectionName, String refItemName, String parentCollectionName,
            String parentCollectionDatabaseName)
            throws Exception {
        // Set display info and append Header to result
        this.resetTotalsAndLists();
        this.itemsWithRef.add(refItemName);
        this.parentDatabaseNames.add(parentCollectionDatabaseName);
        this.parentCollections.add(parentCollectionName);
        appendHeader(true);

        // Populate HashMap of parent keys to check against
        MongoDatabase parentDb = mongoClient.getDatabase(parentCollectionDatabaseName);
        MapOfIDs parentIds = new MapOfIDs(parentDb, parentCollectionName);
        this.appendMapNarrative(parentIds);

        // Iterate through all the records in the collection and look for broken $refs 
        FindIterable<Document> iterable = this.db.getCollection(collectionName).find();
        iterable.forEach(new Block<Document>() {
            public void apply(final Document doc) {
                ObjectId recordKey = new ObjectId();
                List<String> keysList = new ArrayList<String>();
                List<Object> valsList = new ArrayList<Object>();
                Set<String> keys = doc.keySet();
                keysList.addAll(keys);
                Collection<Object> vals = doc.values();
                valsList.addAll(vals);

                for (int i = 0; i < keysList.size(); i++) {
                    if (keysList.get(i).equals("_id") && valsList.get(i) instanceof ObjectId) {
                        recordKey = (ObjectId) valsList.get(i);
                    } else if (keysList.get(i).equals(refItemName)
                            && valsList.get(i) instanceof DBRef) {
                        DBRef dbRef = (DBRef) valsList.get(i);
                        ObjectId dbRefId = (ObjectId) dbRef.getId();

                        if (!parentIds.containsObjectId(dbRefId)) {
                            appendBrokenRefNarrative(refItemName, recordKey.toString(), dbRefId.toString());
                            incrementBrokenTotal();
                        } else {
                            incrementGoodTotal();
                        }
                    }
                }
            }
        });
        // Append totals to result narrative
        appendTotals(true);
    }

    /**
     * Use this method to look for broken $ref items where the item is a
     * "mainline" array (i.e. NOT nested, and it is an Array of $refs)
     *
     * @param collectionName the name of the collection that contains the $ref
     * item
     * @param refItemName the name of the $ref item
     * @param parentCollectionName the name of the parent collection to which
     * the $ref item refers
     * @throws Exception
     */
    private void fbr_genericArrayRef(String collectionName, String refItemName, String parentCollectionName,
            String parentCollectionDatabaseName)
            throws Exception {

        // Set display info and append Header to result
        this.resetTotalsAndLists();
        this.itemsWithRef.add(refItemName);
        this.parentDatabaseNames.add(parentCollectionDatabaseName);
        this.parentCollections.add(parentCollectionName);
        appendHeader(true);

        // Populate HashMap of parent keys to check against
        MongoDatabase parentDb = mongoClient.getDatabase(parentCollectionDatabaseName);
        MapOfIDs parentIds = new MapOfIDs(parentDb, parentCollectionName);
        this.appendMapNarrative(parentIds);

        // Iterate through all the records in the collection and look for broken $refs 
        FindIterable<Document> iterable = this.db.getCollection(collectionName).find();
        iterable.forEach(new Block<Document>() {
            public void apply(final Document doc) {
                ObjectId recordKey = new ObjectId();
                List<String> keysList = new ArrayList<String>();
                List<Object> valsList = new ArrayList<Object>();
                Set<String> keys = doc.keySet();
                keysList.addAll(keys);
                Collection<Object> vals = doc.values();
                valsList.addAll(vals);

                for (int i = 0; i < keysList.size(); i++) {
                    if (keysList.get(i).equals("_id") && valsList.get(i) instanceof ObjectId) {
                        recordKey = (ObjectId) valsList.get(i);
                    } else if (keysList.get(i).equals(refItemName)) {
                        if (valsList.get(i) instanceof ArrayList) {
                            ArrayList<Object> refsArray = (ArrayList) valsList.get(i);
                            for (Object ro : refsArray) {

                                if (ro instanceof DBRef) {
                                    DBRef dbRef = (DBRef) ro;
                                    ObjectId dbRefId = (ObjectId) dbRef.getId();

                                    if (!parentIds.containsObjectId(dbRefId)) {
                                        appendBrokenRefNarrative(refItemName, recordKey.toString(), dbRefId.toString());
                                        incrementBrokenTotal();
                                    } else {
                                        incrementGoodTotal();
                                    }
                                }
                            }
                        }
                    }
                }
            }
        });
        // Append totals to result narrative
        appendTotals(true);
    }

    /**
     * Use this method for cases where the collection has a single soft ref item
     * (i.e. the item is not truly a $ref datatype, but instead is merely an
     * ObjectId, or String representation of an ObjectId), and it is not an
     * array.
     *
     * @param collectionName the collection name
     * @param softRefItemName the soft ref item name
     * @param parentCollectionName the soft parent collection Name
     * @throws Exception
     */
    private void fbr_genericSingleSoftRef(String collectionName, String softRefItemName, String parentCollectionName,
            String parentCollectionDatabaseName)
            throws Exception {

        // Set display info and append Header to result
        this.resetTotalsAndLists();
        this.itemsWithRef.add(softRefItemName);
        this.parentDatabaseNames.add(parentCollectionDatabaseName);
        this.parentCollections.add(parentCollectionName);
        appendHeader(false);

        // Populate HashMap of parent keys to check against
        MongoDatabase parentDb = mongoClient.getDatabase(parentCollectionDatabaseName);
        MapOfIDs parentIds = new MapOfIDs(parentDb, parentCollectionName);
        this.appendMapNarrative(parentIds);

        // Iterate through all the records in the collection and look for broken soft ref 
        FindIterable<Document> iterable = this.db.getCollection(collectionName).find();
        iterable.forEach(new Block<Document>() {
            public void apply(final Document doc) {
                ObjectId recordKey = new ObjectId();
                List<String> keysList = new ArrayList<String>();
                List<Object> valsList = new ArrayList<Object>();
                Set<String> keys = doc.keySet();
                keysList.addAll(keys);
                Collection<Object> vals = doc.values();
                valsList.addAll(vals);

                for (int i = 0; i < keysList.size(); i++) {
                    if (keysList.get(i).equals("_id") && valsList.get(i) instanceof ObjectId) {
                        recordKey = (ObjectId) valsList.get(i);
                    } else if (keysList.get(i).equals(softRefItemName)
                            && (valsList.get(i) instanceof ObjectId || valsList.get(i) instanceof String)) {

                        if (valsList.get(i) instanceof ObjectId) {

                            ObjectId objectId = (ObjectId) valsList.get(i);

                            if (!parentIds.containsObjectId(objectId)) {
                                appendBrokenRefNarrative(softRefItemName, recordKey.toString(), objectId.toString());
                                incrementBrokenTotal();
                            } else {
                                incrementGoodTotal();
                            }

                        } else if (valsList.get(i) instanceof String) {

                            String objectIdString = (String) valsList.get(i);

                            if (!parentIds.containsObjectIdString(objectIdString)) {
                                appendBrokenRefNarrative(softRefItemName, recordKey.toString(), objectIdString);
                                incrementBrokenTotal();
                            } else {
                                incrementGoodTotal();
                            }
                        }
                    }
                }
            }
        });
        // Append totals to result narrative
        appendTotals(false);
    }

    private void fbr_genericSingleSoftRefWithinArray(String collectionName, String containingArrayName,
            String softRefItemName, String parentCollectionName, String parentCollectionDatabaseName) {

        // Set display info and append Header to result
        this.resetTotalsAndLists();
        this.itemsWithRef.add(containingArrayName + "." + softRefItemName);
        this.parentDatabaseNames.add(parentCollectionDatabaseName);
        this.parentCollections.add(parentCollectionName);
        appendHeader(false);

        // Populate HashMap of parent keys to check against
        MongoDatabase parentDb = mongoClient.getDatabase(parentCollectionDatabaseName);
        MapOfIDs parentIds = new MapOfIDs(parentDb, parentCollectionName);
        this.appendMapNarrative(parentIds);

        // Iterate through all the records in the collection and look for broken $refs 
        FindIterable<Document> iterable = this.db.getCollection(collectionName).find();
        iterable.forEach(new Block<Document>() {
            public void apply(final Document doc) {
                ObjectId recordKey = new ObjectId();
                List<String> keysList = new ArrayList<String>();
                List<Object> valsList = new ArrayList<Object>();
                Set<String> keys = doc.keySet();
                keysList.addAll(keys);
                Collection<Object> vals = doc.values();
                valsList.addAll(vals);

                for (int i = 0; i < keysList.size(); i++) {
                    if (keysList.get(i).equals("_id") && valsList.get(i) instanceof ObjectId) {
                        recordKey = (ObjectId) valsList.get(i);
                    } else if (keysList.get(i).equals(containingArrayName)) {
                        if (valsList.get(i) instanceof ArrayList) {

                            List<Object> containingArrayItems = (ArrayList) valsList.get(i);

                            for (int x = 0; x < containingArrayItems.size(); x++) {

                                if (containingArrayItems.get(x) instanceof Document) {
                                    Document pDoc = (Document) containingArrayItems.get(x);

                                    Set<String> pKeys = pDoc.keySet();
                                    List<String> pKeysList = new ArrayList<String>();
                                    pKeysList.addAll(pKeys);

                                    Collection<Object> pVals = pDoc.values();
                                    List<Object> pValsList = new ArrayList<Object>();
                                    pValsList.addAll(pVals);

                                    for (int k = 0; k < pKeysList.size(); k++) {
                                        if (pKeysList.get(k).equals(softRefItemName) && pValsList.get(k) instanceof String) {
                                            String softLinkString = (String) pValsList.get(k);

                                            if (!parentIds.containsObjectIdString(softLinkString)) {
                                                appendBrokenRefNarrative(softRefItemName, recordKey.toString(), softLinkString);
                                                incrementBrokenTotal();
                                            } else {
                                                incrementGoodTotal();
                                            }
                                        }
                                    }

                                }
                            }
                        }
                    }
                }
            }
        });
        // Append totals to result narrative
        appendTotals(false);
    }

    /**
     *
     * For cases where a collection within dmlesUser database includes the
     * structure shown in comments immediately within the method code (see
     * below)
     *
     * @param collectionName
     * @throws Exception
     */
    private void fbr_dmles_user_genericAssignedPermissions(String collectionName)
            throws Exception {
        /* For cases where a collection within dmlesUser database includes an array field
        with a structure like this:
        
                "assignedPermissions": [{
                    "permission": {
                        "$ref": {
                            "type": "Permission"
                       },
                       "$id": {
                           "type": "ObjectId"
                       }
                   }
                }]
         */
        this.resetTotalsAndLists();
        this.itemsWithRef.add("assignedPermissions.permission");
        this.parentDatabaseNames.add("dmlesUser");
        this.parentCollections.add("Permission");
        appendHeader(true);

        MapOfIDs parentPermissionsIds = new MapOfIDs(db, "Permission");
        this.appendMapNarrative(parentPermissionsIds);

        FindIterable<Document> iterable = this.db.getCollection(collectionName).find();
        iterable.forEach(new Block<Document>() {
            public void apply(final Document doc) {
                ObjectId recordKey = new ObjectId();
                List<String> keysList = new ArrayList<String>();
                List<Object> valsList = new ArrayList<Object>();
                Set<String> keys = doc.keySet();
                keysList.addAll(keys);
                Collection<Object> vals = doc.values();
                valsList.addAll(vals);

                for (int i = 0; i < keysList.size(); i++) {
                    if (keysList.get(i).equals("_id") && valsList.get(i) instanceof ObjectId) {
                        recordKey = (ObjectId) valsList.get(i);

                    } else if (keysList.get(i).equals("assignedPermissions")
                            && valsList.get(i) instanceof ArrayList) {
                        ArrayList assignedPermissions = (ArrayList) valsList.get(i);
                        for (int j = 0; j < assignedPermissions.size(); j++) {

                            if (assignedPermissions.get(j) instanceof Document) {
                                Document pDoc = (Document) assignedPermissions.get(j);
                                Set<String> pKeys = pDoc.keySet();
                                List<String> pKeysList = new ArrayList<String>();
                                pKeysList.addAll(pKeys);
                                Collection<Object> pVals = pDoc.values();
                                List<Object> pValsList = new ArrayList<Object>();
                                pValsList.addAll(pVals);

                                for (int k = 0; k < pKeysList.size(); k++) {
                                    if (pKeysList.get(k).equals("permission") && pValsList.get(k) instanceof DBRef) {
                                        DBRef dbRef = (DBRef) pValsList.get(k);
                                        ObjectId dbRefId = (ObjectId) dbRef.getId();

                                        if (!parentPermissionsIds.containsObjectId(dbRefId)) {
                                            appendBrokenRefNarrative("assignedPermissions.permission", recordKey.toString(), dbRefId.toString());
                                            incrementBrokenTotal();
                                        } else {
                                            incrementGoodTotal();
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        });
        appendTotals(true);
    }

    private void rejectInvalidParams() throws Exception {
        throw new Exception("Must enter valid parameters, pudknocker!");
    }

    private void incrementGoodTotal() {
        this.numGoodRefsFound++;
    }

    private void incrementBrokenTotal() {
        this.numBrokenRefsFound++;
    }

    private void resetTotalsAndLists() {
        this.itemsWithRef.clear();
        this.parentDatabaseNames.clear();
        this.parentCollections.clear();
        this.numGoodRefsFound = 0;
        this.numBrokenRefsFound = 0;
    }

    /**
     * Right-pads out a string with ".", and then ending with one blank space.
     * Used for final output stats, etc.
     *
     * If String is already >= the initial length, it will just pad it with one
     * blank space.
     *
     * @param initString String to be padded
     * @param desiredLength Desired length of padded String
     * @return the padded String
     */
    private String rpadWithPeriods(String initString, int desiredLength) {
        String retval = initString;
        if (retval.length() < (desiredLength - 1)) {
            while (retval.length() < desiredLength) {
                retval += ".";
            }
        }
        retval += " ";
        return retval;
    }

    private String rpadWithSpaces(String initString, int desiredLength) {
        String retval = initString;
        if (retval.length() < desiredLength) {
            while (retval.length() < desiredLength) {
                retval += " ";
            }
        }
        return retval;
    }

    /**
     * Appends header info to the result narrative
     */
    private void appendHeader(Boolean trueRef) {
        String refString;
        if (trueRef) {
            refString = "$ref";
        } else {
            refString = "soft-ref";
        }
        this.resultBuilder.append(lfChar);
        this.resultBuilder.append("--------------------------------------------------------------------------------------------------------" + lfChar);
        this.resultBuilder.append(rpadWithPeriods("Connection String", 36) + this.connectionString + lfChar);
        this.resultBuilder.append(rpadWithPeriods("Database", 36) + this.dbName + lfChar);
        this.resultBuilder.append(rpadWithPeriods("Collection", 36) + this.collectionName + lfChar);

        for (int i = 0; i < this.itemsWithRef.size(); i++) {
            this.resultBuilder.append(rpadWithPeriods("Item that contains a " + refString, 36) + this.itemsWithRef.get(i) + " (parent Collection: "
                    + this.parentDatabaseNames.get(i) + "." + this.parentCollections.get(i) + ")" + lfChar);
        }
        this.resultBuilder.append("--------------------------------------------------------------------------------------------------------" + lfChar);
    }

    /**
     * Appends info about the parent ObjectId mapping to the result narrative
     *
     * @param map the applicable MapOfIDs
     */
    private void appendMapNarrative(MapOfIDs map) {
        this.resultBuilder.append(String.format("Populated map of %s with %d keys to compare against" + lfChar,
                map.getCollectionName(), map.getNumberOfIds()));
        this.resultBuilder.append("--------------------------------------------------------------------------------------------------------" + lfChar);
    }

    /**
     * Appends info about a broken $ref to the result narrative
     *
     * @param elementName name of the $ref item in the collection
     * @param recordKey _id value (primary key) of the record with the bad $ref
     * @param refId the bad $ref $id value itself
     */
    private void appendBrokenRefNarrative(String elementName, String recordKey, String refId) {
        String info = String.format("Bad ref (%s)", elementName);
        info = rpadWithPeriods(info, 36);
        info = info + String.format("doc _id %s  ref $id %s" + lfChar,
                recordKey, refId);
        this.resultBuilder.append(info);
    }

    /**
     * Appends final totals to the result narrative
     */
    private void appendTotals(Boolean trueRef) {
        String refString;
        if (trueRef) {
            refString = "$ref";
        } else {
            refString = "soft-ref";
        }

        String itemsWithRefString = "";
        for (String s : this.itemsWithRef) {
            itemsWithRefString += (s + ", ");
        }
        itemsWithRefString = itemsWithRefString.substring(0, itemsWithRefString.length() - 2);

        this.resultBuilder.append("--------------------------------------------------------------------------------------------------------" + lfChar);
        this.resultBuilder.append(rpadWithPeriods("Completed work for collection", 36) + this.collectionName + lfChar);
        this.resultBuilder.append(rpadWithSpaces(" ", 44) + "(" + itemsWithRefString + ")" + lfChar);
        this.resultBuilder.append(rpadWithPeriods(String.format("Broken %s items found", refString), 36) + this.numBrokenRefsFound + lfChar);
        this.resultBuilder.append(rpadWithPeriods(String.format("Good %s items found", refString), 36) + this.numGoodRefsFound + lfChar);
        this.resultBuilder.append(lfChar + lfChar);
    }

}
