package mil.jmlfdc.mongodbbrokenrefs.processing;

import java.util.List;
import java.util.ArrayList;

/**
 * Class that runs the "find broken MongoDB $refs" for the given database and
 * given list of collection names (passed in via parameter)
 */
public class Runner {

    private static final String OPERATING_SYSTEM = System.getProperty("os.name");
    private String lfChar;
    private String connectionString;
    private String username;
    private String password;
    private String dbName;
    private List<String> collectionNames;
    private String runResultNarrative;

    /**
     * Constructor method
     *
     * @param connectionString
     * @param dbName
     * @param collectionNames
     * @param username
     * @param password
     */
    public Runner(String connectionString, String dbName, List<String> collectionNames,
            String username, String password) {

        if (OPERATING_SYSTEM.startsWith("Window") || OPERATING_SYSTEM.startsWith("WINDOW")) {
            this.lfChar = "\r\n";
        } else {
            this.lfChar = "\n";
        }

        this.connectionString = connectionString;
        this.dbName = dbName;
        this.collectionNames = collectionNames;
        this.username = username;
        this.password = password;

        this.runResultNarrative = "";
    }

    /**
     * Actual bread-and-butter method that does the work by instantiating
     * MongoDBBrokenRefsFinder objects and running their stuff
     *
     * @return String containing result narrative
     */
    public String runFindBrokenRefs() {

        StringBuilder builder = new StringBuilder();
        for (String collectionName : collectionNames) {
            MongoDBBrokenRefsFinder finder = new MongoDBBrokenRefsFinder(
                    this.connectionString, this.dbName, collectionName,
                    this.username, this.password);
            String result = finder.findBrokenRefs();
            builder.append(result);
        }
        this.runResultNarrative = builder.toString();
        return this.runResultNarrative;
    }
}
