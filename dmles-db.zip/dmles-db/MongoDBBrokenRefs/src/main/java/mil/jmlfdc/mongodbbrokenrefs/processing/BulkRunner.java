package mil.jmlfdc.mongodbbrokenrefs.processing;

import util.FileUtility;
import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Set;
import java.util.Date;
import java.util.Properties;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.TimeZone;

/**
 * Class that provides the executable main() method for running a big process to
 * find the broken MongoDB $ref items within a set of MongoDB databases
 */
public class BulkRunner {

    private static final String OPERATING_SYSTEM = System.getProperty("os.name");
    private FileUtility fileUtil;
    private String lfChar;
    private String connectionString;
    private String username;
    private String password;
    private Map<String, List> collectionsMap;
    private String propertiesFilename;
    private String outputFilename;
    private DateFormat dateFormatUtc;
    private DateFormat dateFormatLocal;

    /**
     * Constructor method for internal use by main
     *
     * @param hostname MongoDB hostname
     * @param port MongoDB port (e.g. "27017")
     * @param outputFilename output filename (include path as needed)
     */
    public BulkRunner(String connectionString, String outputFilename, String propertiesFilename,
            String username, String password) {

        this.connectionString = connectionString;
        this.username = username;
        this.password = password;
        this.outputFilename = outputFilename;
        this.propertiesFilename = propertiesFilename;
        this.fileUtil = new FileUtility();

        dateFormatUtc = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        dateFormatUtc.setTimeZone(TimeZone.getTimeZone("UTC"));
        dateFormatLocal = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        dateFormatLocal.setTimeZone(TimeZone.getTimeZone("America/New_York"));

        if (OPERATING_SYSTEM.startsWith("Window") || OPERATING_SYSTEM.startsWith("WINDOW")) {
            this.lfChar = "\r\n";
        } else {
            this.lfChar = "\n";
        }
        this.setDBCollectionsFromProperties();
    }

    /**
     * Primary, bread-and-butter method that does the actual work
     */
    public void run() {
        writeHeader();
        Set<String> dbKeys = this.collectionsMap.keySet();
        List<String> dbKeysList = new ArrayList<String>();
        dbKeysList.addAll(dbKeys);
        for (String dbKey : dbKeys) {
            List<String> collections = this.collectionsMap.get(dbKey);
            Runner runner = new Runner(this.connectionString, dbKey, collections, this.username, this.password);
            String runResult = runner.runFindBrokenRefs();
            this.fileUtil.appendStringToFile(runResult, this.outputFilename);
        }
        writeFooter();
    }

    /**
     * Sets the DBs to be processed, and the collections for each DB, based on
     * properties file
     */
    private void setDBCollectionsFromProperties() {

        Properties prop = new Properties();
        prop = this.fileUtil.readPropertiesFromFile(this.propertiesFilename);
        this.collectionsMap = new HashMap<String, List>();

        if (prop.getProperty("db1") != null && !prop.getProperty("db1").equals("")
                && prop.getProperty("db1Collections") != null && !prop.getProperty("db1Collections").equals("")) {
            String db1 = prop.getProperty("db1");
            String[] db1Collections = prop.getProperty("db1Collections").split(",");
            List<String> db1CollectionsList = Arrays.asList(db1Collections);
            this.collectionsMap.put(db1, db1CollectionsList);
        }
        if (prop.getProperty("db2") != null && !prop.getProperty("db2").equals("")
                && prop.getProperty("db2Collections") != null && !prop.getProperty("db2Collections").equals("")) {
            String db2 = prop.getProperty("db2");
            String[] db2Collections = prop.getProperty("db2Collections").split(",");
            List<String> db2CollectionsList = Arrays.asList(db2Collections);
            this.collectionsMap.put(db2, db2CollectionsList);
        }
        if (prop.getProperty("db3") != null && !prop.getProperty("db3").equals("")
                && prop.getProperty("db3Collections") != null && !prop.getProperty("db3Collections").equals("")) {
            String db3 = prop.getProperty("db3");
            String[] db3Collections = prop.getProperty("db3Collections").split(",");
            List<String> db3CollectionsList = Arrays.asList(db3Collections);
            this.collectionsMap.put(db3, db3CollectionsList);
        }
        if (prop.getProperty("db4") != null && !prop.getProperty("db4").equals("")
                && prop.getProperty("db4Collections") != null && !prop.getProperty("db4Collections").equals("")) {
            String db4 = prop.getProperty("db4");
            String[] db4Collections = prop.getProperty("db4Collections").split(",");
            List<String> db4CollectionsList = Arrays.asList(db4Collections);
            this.collectionsMap.put(db4, db4CollectionsList);
        }
        if (prop.getProperty("db5") != null && !prop.getProperty("db5").equals("")
                && prop.getProperty("db5Collections") != null && !prop.getProperty("db5Collections").equals("")) {
            String db5 = prop.getProperty("db5");
            String[] db5Collections = prop.getProperty("db5Collections").split(",");
            List<String> db5CollectionsList = Arrays.asList(db5Collections);
            this.collectionsMap.put(db5, db5CollectionsList);
        }
        if (prop.getProperty("db6") != null && !prop.getProperty("db6").equals("")
                && prop.getProperty("db6Collections") != null && !prop.getProperty("db6Collections").equals("")) {
            String db6 = prop.getProperty("db6");
            String[] db6Collections = prop.getProperty("db6Collections").split(",");
            List<String> db6CollectionsList = Arrays.asList(db6Collections);
            this.collectionsMap.put(db6, db6CollectionsList);
        }
        if (prop.getProperty("db7") != null && !prop.getProperty("db7").equals("")
                && prop.getProperty("db7Collections") != null && !prop.getProperty("db7Collections").equals("")) {
            String db7 = prop.getProperty("db7");
            String[] db7Collections = prop.getProperty("db7Collections").split(",");
            List<String> db7CollectionsList = Arrays.asList(db7Collections);
            this.collectionsMap.put(db7, db7CollectionsList);
        }
        if (prop.getProperty("db8") != null && !prop.getProperty("db8").equals("")
                && prop.getProperty("db8Collections") != null && !prop.getProperty("db8Collections").equals("")) {
            String db8 = prop.getProperty("db8");
            String[] db8Collections = prop.getProperty("db8Collections").split(",");
            List<String> db8CollectionsList = Arrays.asList(db8Collections);
            this.collectionsMap.put(db8, db8CollectionsList);
        }
        if (prop.getProperty("db9") != null && !prop.getProperty("db9").equals("")
                && prop.getProperty("db9Collections") != null && !prop.getProperty("db9Collections").equals("")) {
            String db9 = prop.getProperty("db9");
            String[] db9Collections = prop.getProperty("db9Collections").split(",");
            List<String> db9CollectionsList = Arrays.asList(db9Collections);
            this.collectionsMap.put(db9, db9CollectionsList);
        }
        if (prop.getProperty("db10") != null && !prop.getProperty("db10").equals("")
                && prop.getProperty("db10Collections") != null && !prop.getProperty("db10Collections").equals("")) {
            String db10 = prop.getProperty("db10");
            String[] db10Collections = prop.getProperty("db10Collections").split(",");
            List<String> db10CollectionsList = Arrays.asList(db10Collections);
            this.collectionsMap.put(db10, db10CollectionsList);
        }
    }

    /**
     * Appends header info to the output file
     */
    private void writeHeader() {
        StringBuilder builder = new StringBuilder();
        builder.append("========================================================================================================" + lfChar);
        builder.append("Running MongoDBFindBrokenRefs BulkRunner" + lfChar + lfChar);
        builder.append("Output file............ " + this.outputFilename + lfChar);
        builder.append("Connection String...... " + this.connectionString + lfChar + lfChar);

        Date date = new Date();
        builder.append("Current time (UTC)..... " + dateFormatUtc.format(date) + lfChar);
        builder.append("Current time (local)... " + dateFormatLocal.format(date) + lfChar + lfChar);
        
        builder.append("Databases:" + lfChar);
        Set<String> dbKeys = this.collectionsMap.keySet();
        List<String> dbKeysList = new ArrayList<String>();
        dbKeysList.addAll(dbKeys);
        for (String dbKey : dbKeys) {
            builder.append(lfChar);
            builder.append("      " + dbKey + lfChar);
            builder.append("                Collections:" + lfChar);
            List<String> collections = this.collectionsMap.get(dbKey);
            for (String collection : collections) {
                builder.append("                        " + collection + lfChar);
            }
        }
        builder.append("========================================================================================================" + lfChar + lfChar);
        this.fileUtil.writeStringToFile(builder.toString(), this.outputFilename);
    }

    /**
     * Appends footer/result info to the output file
     */
    private void writeFooter() {
        StringBuilder builder = new StringBuilder();
        builder.append(lfChar + lfChar);
        builder.append("========================================================================================================" + lfChar);
        builder.append("Finishing MongoDBFindBrokenRefs BulkRunner" + lfChar + lfChar);
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date date = new Date();
        builder.append("Current time (UTC)..... " + dateFormatUtc.format(date) + lfChar);
        builder.append("Current time (local)... " + dateFormatLocal.format(date) + lfChar + lfChar);
        builder.append(lfChar + lfChar);
        builder.append("Have a nice day!" + lfChar);
        this.fileUtil.appendStringToFile(builder.toString(), this.outputFilename);
    }

}
