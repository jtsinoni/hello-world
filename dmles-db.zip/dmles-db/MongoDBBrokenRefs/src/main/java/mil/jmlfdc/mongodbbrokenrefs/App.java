package mil.jmlfdc.mongodbbrokenrefs;

import mil.jmlfdc.mongodbbrokenrefs.processing.BulkRunner;
import mil.jmlfdc.mongodbbrokenrefs.processing.MongoDBBrokenRefsFinder;

public class App {

    /**
     * Main method for actual program execution
     *
     * @param args the host, port, and outputfile (including path as needed)
     * NOTE: args[2] = properties file that is desired to be used. If left
     * empty, then default "findBrokenRefs.properties" file is used
     */
    public static void main(String args[]) {
        String connectionStringParam;
        String outputFileParam;
        String propertiesFileParam;
        String usernameParam;
        String passwordParam;

        try {
            if (args.length >= 2) {
                connectionStringParam = args[0];
                outputFileParam = args[1];

                if (args.length >= 3 && args[2] != null && !args[2].equals("")) {
                    propertiesFileParam = args[2];
                } else {
                    propertiesFileParam = "findBrokenRefs.properties";
                }

                if (args.length >= 5) {
                    usernameParam = args[3];
                    passwordParam = args[4];
                } else {
                    usernameParam = MongoDBBrokenRefsFinder.USER_CREDENTIALS_NOT_APPLICABLE;
                    passwordParam = MongoDBBrokenRefsFinder.USER_CREDENTIALS_NOT_APPLICABLE;
                }

                BulkRunner bulkRunner = new BulkRunner(connectionStringParam, outputFileParam,
                        propertiesFileParam, usernameParam, passwordParam);
                bulkRunner.run();
            } else {
                throw new Exception("Insufficient parameters passed to main method");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
