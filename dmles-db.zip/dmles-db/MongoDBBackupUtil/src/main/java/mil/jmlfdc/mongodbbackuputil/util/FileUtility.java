package mil.jmlfdc.mongodbbackuputil.util;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author david.caglarcan
 */
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.File;
import java.io.FileWriter;
import java.nio.file.Files;
import java.nio.file.DirectoryStream;
import java.nio.file.Path;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;

/**
 * This class contains utilities for reading JSON data from files, and writing
 * JSON data to files.
 *
 */
public class FileUtility {

    protected static final String OPERATING_SYSTEM = System.getProperty("os.name");
    protected String lfChar;

    /**
     * No-argument constructor. Set linefeed character according to OS.
     */
    public FileUtility() {
        if (OPERATING_SYSTEM.startsWith("Window") || OPERATING_SYSTEM.startsWith("WINDOW")) {
            lfChar = "\r\n";
        } else {
            lfChar = "\n";
        }
    }

    /**
     * readFileIntoString
     *
     * Reads file into a String for processing.
     *
     * @param fileName the fileName including full path
     * @return the String
     * @throws IOException
     */
    public String readFileIntoString(String fileName) {

        try {
            BufferedReader br = new BufferedReader(new FileReader(fileName));
            StringBuilder sb = new StringBuilder();
            String line = br.readLine();

            while (line != null) {
                sb.append(line);
                sb.append(lfChar);
                line = br.readLine();
            }
            return sb.toString();
        } catch (IOException ie) {
            return ie.getMessage();
        } catch (Exception e) {
            return e.getMessage();
        }
    }

    /**
     * writeStringToFile
     *
     * Takes in input string, writes out to a file
     *
     * @param textToWrite the String to write
     * @param filename the output filename including full path
     */
    public void writeStringToFile(String textToWrite, String filename) {

        FileWriter fileWriter = null;
        try {
            File newTextFile = new File(filename);
            fileWriter = new FileWriter(newTextFile);
            fileWriter.write(textToWrite);
            fileWriter.close();
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        } finally {
            try {
                fileWriter.close();
            } catch (IOException ex) {
                System.out.println(ex.getMessage());
            }
        }
    }

    /**
     * Looks in the given directory for filenames of the given file extension,
     * then returns an ArrayList of the filenames (including path) found. (Or an
     * empty ArrayList if none are found).
     *
     * @param directoryName the directory in which to look for files
     * @param extensionFilter the file extension to look for
     * @return the ArrayList of filenames found (including path)
     */
    public ArrayList<String> getFilesnamesFromDirectory(String directoryName, String extensionFilter) {
        ArrayList<String> retval = new ArrayList<String>();

        try (DirectoryStream<Path> directoryStream = Files.newDirectoryStream(Paths.get(directoryName))) {
            for (Path path : directoryStream) {

                String filename = path.toString();

                if (extensionFilter == "" || (extensionFilter != "" && filename.endsWith(extensionFilter))) {
                    retval.add(path.toString());
                }
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
        return retval;
    }
}
