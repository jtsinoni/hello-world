package mil.jmlfdc.mongodbbackuputil.processing;

import java.util.Map;
import java.util.HashMap;
import java.util.Arrays;
import com.mongodb.client.MongoIterable;
import com.mongodb.client.MongoCursor;
import com.mongodb.ServerAddress;
import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import java.util.List;
import java.util.ArrayList;
import mil.jmlfdc.mongodbbackuputil.util.FileUtility;

/**
 * This is a simple Java class designed to write a batch script that can be
 * called to run mongodump backups of a bunch of databases within a MongoD.
 *
 * While mongodump (as of v3.2) provides ability to back up ALL DBs, or a single
 * DB, it does NOT provide ability to back up all DBs EXCEPT FOR certain ones to
 * be excluded.
 *
 * We needed the ability to exclude certain databases from frequent backup jobs,
 * in order to save space. That is why this class was written.
 *
 * This class is the "Main Class" for the MongoDBBackupTool project.
 *
 * See description of main method for more information on invoking the program,
 * and the parameters passed in.
 */
public class GenerateBatchScript {

    private String connectionString;
    private String envType;
    private String delimitedListOfDBsToExclude;
    private String dynamicallyGeneratedBatchScriptName;
    private String singleDbBatchScriptName;
    private String username;
    private String password;
    private MongoCredential credential;

    private FileUtility fileUtil;
    private List<ServerAddress> serverAddresses;
    private List<String> dbsToBackUp;
    private MongoClient mongoClient;
    protected String lfChar;
    protected static final String OPERATING_SYSTEM = System.getProperty("os.name");
    protected static final String USER_CREDENTIALS_NOT_APPLICABLE = "NOT_APPLICABLE";

    /**
     * Setup method that establishes the class variables, based on user params
     * passed in to the main method.
     *
     * @param connectionString the connection string (e.g. for single host,
     * "srv:27017", or for replica set,
     * "replSetName/srv1:27017,srv2:27017,srv3:27017")
     * @param environmentType "dev" or "test"
     * @param delimitedListOfDBsToExclude DBs to exclude from the backup (e.g.
     * "dmlesOatmeal,dmlesWheat,dmlesBarley")
     * @param dynamicallyGeneratedScriptName Name of script name to generate
     * @param singleDbBatchScriptName Name of batch script
     * @param username Username to log into DB (if DB has no authentication,
     * pass in null)
     * @param password Password to log into DB (if DB has no authentication,
     * pass in null)
     * @throws Exception
     */
    private void setup(String connectionString, String environmentType,
            String delimitedListOfDBsToExclude, String dynamicallyGeneratedScriptName,
            String singleDbBatchScriptName, String username, String password) throws Exception {

        this.envType = environmentType;
        if (!this.envType.equals("dev") && !this.envType.equals("test")) {
            throw new Exception("Invalid environmentType (must be dev or test");
        }
        if (OPERATING_SYSTEM.startsWith("Window") || OPERATING_SYSTEM.startsWith("WINDOW")) {
            lfChar = "\r\n";
        } else {
            lfChar = "\n";
        }
        this.fileUtil = new FileUtility();
        this.connectionString = connectionString;
        this.delimitedListOfDBsToExclude = delimitedListOfDBsToExclude;
        this.dynamicallyGeneratedBatchScriptName = dynamicallyGeneratedScriptName;
        this.singleDbBatchScriptName = singleDbBatchScriptName;
        this.username = username;
        this.password = password;

        setListOfServerAddresses();
        setMongoClient();
        setListOfDBsToBackUp();
    }

    /**
     * Helper method to enclose the String in double quotes.
     *
     * @param input the input String
     * @return the String with quotes around it.
     */
    private String quoteStr(String input) {
        String retval = "\"" + input + "\"";
        return retval;
    }

    private void setListOfServerAddresses() {

        this.serverAddresses = new ArrayList<ServerAddress>();

        if (this.connectionString.contains("/")) {  // this is a replica set
            List<String> connectionStringPieces = Arrays.asList(this.connectionString.split("/"));
            String replicaSetName = connectionStringPieces.get(0).trim();
            String serverStringsConcat = connectionStringPieces.get(1).trim();
            List<String> serverStrings = Arrays.asList(serverStringsConcat.split(","));
            for (String serverString : serverStrings) {
                serverString = serverString.trim();
                String hostName = Arrays.asList(serverString.split(":")).get(0).trim();
                Integer port = Integer.parseInt(Arrays.asList(serverString.split(":")).get(1).trim());
                this.serverAddresses.add(new ServerAddress(hostName, port));
            }
        } else {  //single host---NOT a replica set
            String hostName = Arrays.asList(connectionString.split(":")).get(0).trim();
            Integer port = Integer.parseInt(Arrays.asList(connectionString.split(":")).get(1).trim());
            this.serverAddresses.add(new ServerAddress(hostName, port));
        }
    }

    private void setMongoClient() {

        if (this.username != null && !this.username.equals("") && !this.username.equalsIgnoreCase(this.USER_CREDENTIALS_NOT_APPLICABLE)
                && this.password != null && !this.password.equals("") && !this.password.equalsIgnoreCase(this.USER_CREDENTIALS_NOT_APPLICABLE)) {
            this.credential = MongoCredential.createCredential(this.username, "admin",
                    this.password.toCharArray());
            this.mongoClient = new MongoClient(this.serverAddresses, Arrays.asList(this.credential));
        } else {
            this.credential = null;
            this.mongoClient = new MongoClient(this.serverAddresses);
        }
    }

    private void setListOfDBsToBackUp() {

        this.dbsToBackUp = new ArrayList<String>();
        List<String> items = Arrays.asList(this.delimitedListOfDBsToExclude.split(","));
        Map<String, String> dbsToExcludeMap = new HashMap<String, String>();
        for (String item : items) {
            item = item.trim();
            dbsToExcludeMap.put(item, "X");
        }
        MongoIterable<String> dbNames = this.mongoClient.listDatabaseNames();
        MongoCursor<String> iterator = dbNames.iterator();
        while (iterator.hasNext()) {
            String dbName = iterator.next();
            if (!dbsToExcludeMap.containsKey(dbName) && !dbName.equals("local")) {
                this.dbsToBackUp.add(dbName);
            }
        }
    }

    /**
     * Builds the big String that will go to the output file
     *
     * @return the String
     */
    private String getBatchBackupCommandsString() {

        String retval;
        StringBuilder buildString = new StringBuilder();
        buildString.append("@echo off" + lfChar + lfChar + lfChar);
        buildString.append("echo ===============================================================" + lfChar);
        buildString.append("echo Starting backups of MongoDB databases" + lfChar + lfChar);
        buildString.append("echo Excluding the following databases:" + lfChar);
        buildString.append("echo " + this.delimitedListOfDBsToExclude + lfChar + lfChar);
        buildString.append("echo Will run backups of the following databases: " + lfChar);
        for (String db : this.dbsToBackUp) {
            buildString.append("echo " + db + lfChar);
        }
        buildString.append("echo ===============================================================" + lfChar + lfChar);

        for (String db : this.dbsToBackUp) {
            String scriptCall = String.format("%s %s %s %s", this.singleDbBatchScriptName,
                    quoteStr(this.connectionString), this.envType, db);
            if (this.username != null && !this.username.equals("") && !this.username.equalsIgnoreCase(this.USER_CREDENTIALS_NOT_APPLICABLE)
                    && this.password != null && !this.password.equals("") && !this.password.equalsIgnoreCase(this.USER_CREDENTIALS_NOT_APPLICABLE)) {
                scriptCall += String.format(" %s %s", this.username, this.password);
            }
            buildString.append("echo Running " + scriptCall + lfChar);
            buildString.append("echo." + lfChar);
            buildString.append("call " + scriptCall + lfChar + lfChar);
        }
        buildString.append("echo." + lfChar);
        buildString.append("echo." + lfChar);
        buildString.append("echo Finished job to back up MongoDB databases.  Exiting..." + lfChar);

        retval = buildString.toString();
        return retval;
    }

    /**
     * Method that generates the actual batch script. Takes in params that
     * should've been provided when the main method was called.
     *
     * @param connectionString
     * @param environmentType
     * @param delimitedListOfDbsToExclude
     * @param dynamicallyGeneratedScriptName
     * @param batchScriptName
     * @param replicaSetName
     * @param username
     * @param password
     */
    public void generateBatchScript(
            String connectionString,
            String environmentType,
            String delimitedListOfDbsToExclude,
            String dynamicallyGeneratedScriptName,
            String batchScriptName,
            String username,
            String password) {

        try {
            setup(connectionString, environmentType, delimitedListOfDbsToExclude,
                    dynamicallyGeneratedScriptName, batchScriptName, username, password);
            String batchBackupCommandsString = this.getBatchBackupCommandsString();
            fileUtil.writeStringToFile(batchBackupCommandsString, dynamicallyGeneratedScriptName);
        } catch (Exception e) {
            System.out.println("Failure: " + e.getMessage());
        }
    }

}
