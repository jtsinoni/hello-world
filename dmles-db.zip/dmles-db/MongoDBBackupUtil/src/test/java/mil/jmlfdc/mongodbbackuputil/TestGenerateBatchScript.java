package mil.jmlfdc.mongodbbackuputil;

import mil.jmlfdc.mongodbbackuputil.processing.GenerateBatchScript;

public class TestGenerateBatchScript {
    
    public static void main(String args[]) {
        String[] argsForNonSecureDB = {"replDMLES01/dmetdb4001:27017,dmetdb4002:27017,dmetdb4003:27017", "test",
            "dmles-user,dmles-equipment", "C:\\Workspace\\temp2\\test_nonsecure.bat.txt",
            "C:\\Workspace\\temp2\\mongodump_and_zip_db.bat", "NOT_APPLICABLE","NOT_APPLICABLE"
        };
        App.main(argsForNonSecureDB);
        
        
        /* Modify the below, replace "username" and "password" with actual credentials...then uncomment out for testing */
        
        /*String[] argsForSecureDB = {"replDMLES01/dmeddb3001:27017,dmeddb3002:27017,dmeddb3003:27017", "dev",
            "dmles-user", "C:\\Workspace\\temp2\\test_secure.bat.txt",
            "C:\\Workspace\\temp2\\mongodump_and_zip_db.bat", "username", "password"   
        };
        App.main(argsForSecureDB);  */
    }
}
