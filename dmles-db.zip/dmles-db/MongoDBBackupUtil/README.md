## MongoDBBackupUtil

MongoDB Backup Utility


------------
History:
------------
* 20160721  Created by David Caglarcan
* 20161027  Updated to reflect Mavenizing of the project


------------
Overview:
------------
* As of Oct 2016, backups are being run as jobs on a Jenkins dev server



-----------------------------------------------
Scripts/Files/Directories and their Functions:
-----------------------------------------------
* mongodump_and_zip_all_dbs.bat    
         -- Batch script for running standard mongodump (all DBs in a MongoD)
         -- For params and calling example, see comments within script
                                  

* mongodump_and_zip_db.bat         
         -- Batch script for running mongodump of a single database 
         -- For params and calling example, see comments within script


* del_old_mongodb_backups.bat
         -- Batch script that deletes old MongoDB backups older than a certain threshold of days
         -- For params and calling example, see comments within script


* MongoDBBackupTool.jar
         -- Executable Java Program, built by the Java code, that generates a batch script that can be called to run 
            backups of all databases within a MongoD EXCEPT FOR those specifically excluded by
            parameter

         -- Background:

              ---- While mongodump (as of v3.2) provides ability to back up ALL DBs, or a single DB, it does NOT provide 
                   ability to back up all DBs EXCEPT FOR certain ones to be excluded.

              ---- We needed the ability to exclude certain databases from frequent backup jobs,
                   in order to save space. (Specifically, the huge "catalog" and "fda" databases in dev and test)

              ---- This JAR file can be called to generate a batch script THAT WILL CALL the
                   mongodump_and_zip_db.bat multiple times---one time for each database to be backed up

         -- Params:
              ---- host name of the MongoDB server (e.g. jwcui01)
              ---- port # of the MongoDB server (e.g. 27017 or 27018)
              ---- type of environment (dev or test)
              ---- comma-delimited list of DBs to exclude from backup (e.g. fda,catalog)
              ---- name and relative path of batch script to generate 
                           (e.g. dynamically_generated_backup_script.bat
                              or backup_scripts/dynamically_generated_backup_script.bat)
              ---- name and relative path of the batch script that will be called repeatedly
                           (Should be mongodump_and_zip_db.bat  or <path>/mongodump_and_zip_db.bat)

         -- Calling example:

              java -jar MongoDBBackupTool.jar jw8cui01 27018 dev fda,catalog dynamically_generated_backup_script.bat mongodump_and_zip_db.bat

              ---- NOTE: The Jenkins server makes this type of call to generate the batch script it needs to run, and then runs that batch script

