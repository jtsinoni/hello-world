
export class ServiceShortName {

    static AIR_FORCE_SHORT_NAME: string = 'DF';
    static ARMY_SHORT_NAME: string = 'DA';
    static NAVY_SHORT_NAME: string = 'NV';
    constructor() {}
}
