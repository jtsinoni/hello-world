export class NavigationConstants {

  public static CATALOG_NAV_ID: string = 'catalog';
  public static ORDERING_NAV_ID: string = 'ordering';
  public static FULFILLMENT_NAV_ID: string = 'fulfillment';
  public static INVENTORY_NAV_ID: string = 'inventory';
  public static COMMUNICATIONS_NAV_ID: string = 'communications';
  public static EQUIPMENT_NAV_ID: string = 'equipment';
  public static ORGANIZATION_NAV_ID: string = 'organization';
  public static ACCESS_NAV_ID: string = 'access';
  public static FINANCE_NAV_ID: string = 'finance';
  public static ADMIN_NAV_ID: string = 'jmlfdcAdmin';

}
