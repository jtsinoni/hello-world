export class ProfileStatusConstants {

  static STATUS_ACTIVE: string = 'ACTIVE';
  static STATUS_INACTIVE: string = 'INACTIVE';
  static STATUS_DELETED: string = 'DELETED';
  static STATUS_EXPIRED: string = 'EXPIRED';
  static STATUS_LOCKED: string = 'LOCKED';
  static STATUS_RELOCKED: string = 'RELOCKED';
  static STATUS_PENDING: string = 'PENDING';
  static STATUS_SUSPENDED: string = 'SUSPENDED';

  constructor() {
  }
}
