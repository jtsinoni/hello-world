import {NavigationConstants} from './navigation.constants';
import {ResourceConstants} from './resource.constants';

export interface RouteInfo {
  url: string;
  name: string; // dotted state
  perm?: string; // permission string
  breadcrumb?: string; // should have this unless in login area
  navigationId?: string; // dropdown parent area (NavigationConstant Order, Inventory, etc)
  shown?: boolean; // show or hide dropdown
  selectionText?: string; // dropdown text TODO use breadcrumb text ?
  dividerFollows?: boolean; // dropdown divider
  parent?: RouteInfo; // previous page: all except HOME_ROOT should have one
}

// TODO update / correct permissions, add permissions to all / most routes...?

export class RouteConstants {
  static LOGIN_ROOT: RouteInfo = {url: '/login', name: 'login'};
  static LOGIN: RouteInfo = {
    url: '/loginForm',
    name: 'login.loginForm',
    breadcrumb: 'Login',
    parent: RouteConstants.LOGIN_ROOT
  };
  static CHOOSE_PROFILE: RouteInfo = {
    url: '/chooseProfile', name: 'login.chooseProfile', breadcrumb: 'Choose Profile',
    parent: RouteConstants.LOGIN_ROOT
  };
  static REQUEST_PKI_DN_UPDATE: RouteInfo = {
    url: '/requestPkiDnUpdate', name: 'login.updateCAC', breadcrumb: 'Update CAC',
    parent: RouteConstants.LOGIN_ROOT
  };
  static ACCESSIBILITY: RouteInfo = {
    url: '/accessibility', name: 'login.accessibility', breadcrumb: 'Accessibility',
    parent: RouteConstants.LOGIN_ROOT
  };

  static HOME_ROOT: RouteInfo = {url: '/home', name: 'home', breadcrumb: 'Home'};
  static MY_DASHBOARD: RouteInfo = {
    url: '/dashboard', name: 'home.myDashboard', breadcrumb: 'My Dashboard',
    parent: RouteConstants.HOME_ROOT
  };
  static ABOUT: RouteInfo = {url: '/about', name: 'home.about', breadcrumb: 'About', parent: RouteConstants.HOME_ROOT};
  static HELP: RouteInfo = {url: '/help', name: 'home.help', breadcrumb: 'Help', parent: RouteConstants.HOME_ROOT};

  static MY_PROFILE: RouteInfo = {
    url: '/myProfile',
    name: 'home.myProfile',
    breadcrumb: 'My Profile',
    parent: RouteConstants.HOME_ROOT
  };

  static EDIT_MY_PROFILE: RouteInfo = {
    url: '/editMyProfile',
    name: 'home.myProfile.editProfile',
    breadcrumb: 'Edit My Profile',
    parent: RouteConstants.MY_PROFILE
  };

  static LOADING: RouteInfo = {url: '/loading', name: 'home.loading', parent: RouteConstants.HOME_ROOT};

  static ACCESS: RouteInfo = {
    url: '/access',
    name: 'home.access',
    breadcrumb: 'Access',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.ACCESS_NAV_ID
  };
  static ACCESS_USER_PROFILE_MANAGEMENT: RouteInfo = {
    url: '/userProfileManagement',
    name: 'home.access.userProfileManagement',
    // parent should be ACCESS, however, ACCESS does not have HTML to show
    parent: RouteConstants.HOME_ROOT,
    breadcrumb: 'Profile Management', navigationId: NavigationConstants.ACCESS_NAV_ID, shown: true,
    perm: ResourceConstants.USER_PROFILE_MANAGEMENT,
    selectionText: 'Profile Management',
  };
  static ACCESS_PERMISSION_MANAGEMENT: RouteInfo = {
    url: '/permissionManagement',
    name: 'home.access.permissionManagement',
    parent: RouteConstants.HOME_ROOT,
    breadcrumb: 'Permission Management', navigationId: NavigationConstants.ACCESS_NAV_ID, shown: true,
    perm: ResourceConstants.PERMISSION_MANAGEMENT,
    selectionText: 'Permission Management',
  };
  static ACCESS_PERMISSION_MANAGEMENT_DETAILS: RouteInfo = {
    url: '/permissionDetails',
    name: 'home.access.permissionManagement.permissionDetails',
    breadcrumb: 'Permission Details',
    parent: RouteConstants.ACCESS_PERMISSION_MANAGEMENT, navigationId: NavigationConstants.ACCESS_NAV_ID
  };
  static ACCESS_PERMISSION_MANAGEMENT_EDIT_GEN_INFO: RouteInfo = {
    url: '/permissionEditGenInfo',
    name: 'home.access.permissionManagement.permissionEditGenInfo',
    breadcrumb: 'Edit Permission General Information',
    parent: RouteConstants.ACCESS_PERMISSION_MANAGEMENT_DETAILS, navigationId: NavigationConstants.ACCESS_NAV_ID
  };
  static ACCESS_PERMISSION_MANAGEMENT_EDIT_ELEMENTS: RouteInfo = {
    url: '/permissionEditElements',
    name: 'home.access.permissionManagement.permissionEditElements',
    breadcrumb: 'Edit Permission Elements',
    parent: RouteConstants.ACCESS_PERMISSION_MANAGEMENT_DETAILS, navigationId: NavigationConstants.ACCESS_NAV_ID
  };
  static ACCESS_PERMISSION_MANAGEMENT_EDIT_STATES: RouteInfo = {
    url: '/permissionEditStates',
    name: 'home.access.permissionManagement.permissionEditStates',
    breadcrumb: 'Edit Permission States',
    parent: RouteConstants.ACCESS_PERMISSION_MANAGEMENT_DETAILS, navigationId: NavigationConstants.ACCESS_NAV_ID
  };
  static ACCESS_PERMISSION_MANAGEMENT_EDIT_ENDPOINTS: RouteInfo = {
    url: '/permissionEditEndpoints',
    name: 'home.access.permissionManagement.permissionEditEndpoints',
    breadcrumb: 'Edit Permission Endpoints',
    parent: RouteConstants.ACCESS_PERMISSION_MANAGEMENT_DETAILS, navigationId: NavigationConstants.ACCESS_NAV_ID
  };

  static ACCESS_ROLE_MANAGEMENT: RouteInfo = {
    url: '/roleManagement',
    name: 'home.access.roleManagement',
    parent: RouteConstants.HOME_ROOT,
    breadcrumb: 'Role Management', navigationId: NavigationConstants.ACCESS_NAV_ID, shown: true,
    perm: ResourceConstants.ROLE_MANAGEMENT,
    selectionText: 'Role Management',
  };

  static FINANCE_ROOT: RouteInfo = {
    url: '/finance',
    name: 'home.finance',
    breadcrumb: 'Funding Dashboard',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.FINANCE_NAV_ID,
    shown: true,
    dividerFollows: false,
    perm: ResourceConstants.FINANCE_MANAGEMENT,
    selectionText: 'Funding Dashboard'
  };
  static FINANCE_SEARCH: RouteInfo = {
    url: '/search',
    name: 'home.finance.search',
    breadcrumb: 'Funding Search',
    parent: RouteConstants.FINANCE_ROOT,
    navigationId: NavigationConstants.FINANCE_NAV_ID, shown: true,
    perm: ResourceConstants.FINANCE_MANAGEMENT,
    selectionText: 'Funding Search',
  };
  static FINANCE_MY_FUNDING_SOURCES: RouteInfo = {
    url: '/myAppropriations',
    name: 'home.finance.myAppropriations',
    breadcrumb: 'My Appropriations',
    parent: RouteConstants.FINANCE_ROOT,
    navigationId: NavigationConstants.FINANCE_NAV_ID, shown: true,
    perm: ResourceConstants.FINANCE_MANAGEMENT,
    selectionText: 'My Appropriations',
  };
  static FINANCE_DETAIL: RouteInfo = {
    url: '/detail',
    name: 'home.finance.search.detail',
    breadcrumb: 'Detail',
    parent: RouteConstants.FINANCE_SEARCH,
    navigationId: NavigationConstants.FINANCE_NAV_ID
  };
  static FINANCE_FUNDING_SOURCE_ADD: RouteInfo = {
    url: '/appropriationEdit',
    name: 'home.finance.search.detail.appropriationEdit',
    breadcrumb: 'Appropriation',
    parent: RouteConstants.FINANCE_DETAIL,
    navigationId: NavigationConstants.FINANCE_NAV_ID
  };
  static FINANCE_EXP_CTR_ADD: RouteInfo = {
    url: '/expenseCenterAdd',
    name: 'home.finance.search.detail.expenseCenterAdd',
    breadcrumb: 'Expense Center',
    parent: RouteConstants.FINANCE_DETAIL,
    navigationId: NavigationConstants.FINANCE_NAV_ID
  };
  static FINANCE_PROJ_CTR_ADD: RouteInfo = {
    url: '/projectCenterAdd',
    name: 'home.finance.search.detail.projectCenterAdd',
    breadcrumb: 'Project Center',
    parent: RouteConstants.FINANCE_DETAIL,
    navigationId: NavigationConstants.FINANCE_NAV_ID
  };
  static FINANCE_REF_DATA_SEARCH: RouteInfo = {
    url: '/financeRefDataSearch',
    name: 'home.finance.financeRefDataSearch',
    breadcrumb: 'Reference Data Search',
    parent: RouteConstants.FINANCE_ROOT,
    navigationId: NavigationConstants.FINANCE_NAV_ID, shown: true,
    perm: ResourceConstants.FINANCE_MANAGEMENT,
    selectionText: 'Reference Data Search',
  };
  static FINANCE_REF_DATA_DETAIL: RouteInfo = {
    url: '/financeRefDataDetail',
    name: 'home.finance.financeRefDataDetail',
    breadcrumb: 'Reference Data Detail',
    parent: RouteConstants.FINANCE_REF_DATA_SEARCH,
    navigationId: NavigationConstants.FINANCE_NAV_ID
  };
  static FINANCE_CREATE_EXP_FOR_CUST: RouteInfo = {
    url: '/createExpenseCenter',
    name: 'home.finance.search.detail.projectCenterAdd.createExpenseCenter',
    breadcrumb: 'Create Expense Center',
    parent: RouteConstants.FINANCE_PROJ_CTR_ADD,
    navigationId: NavigationConstants.FINANCE_NAV_ID, shown: true,
    perm: ResourceConstants.FINANCE_MANAGEMENT,
    selectionText: 'Create Expense Center',
  };
  static FINANCE_FUNDING_SOURCE_DETAIL: RouteInfo = {
    url: '/detail',
    name: 'home.finance.myAppropriations.detail',
    breadcrumb: 'Detail',
    parent: RouteConstants.FINANCE_MY_FUNDING_SOURCES,
    navigationId: NavigationConstants.FINANCE_NAV_ID
  };
  static FINANCE_FUNDING_SOURCE: RouteInfo = {
    url: '/appropriation',
    name: 'home.finance.myAppropriations.appropriation',
    breadcrumb: 'Appropriation',
    parent: RouteConstants.FINANCE_MY_FUNDING_SOURCES,
    navigationId: NavigationConstants.FINANCE_NAV_ID
  };
  static FINANCE_FUNDING_SOURCE_EDIT: RouteInfo = {
    url: '/appropriationEdit',
    name: 'home.finance.myAppropriations.detail.appropriationEdit',
    breadcrumb: 'Appropriation',
    parent: RouteConstants.FINANCE_FUNDING_SOURCE_DETAIL,
    navigationId: NavigationConstants.FINANCE_NAV_ID
  };
  static FINANCE_FUNDING_SOURCE_EXP_CTR: RouteInfo = {
    url: '/expenseCenter',
    name: 'home.finance.myAppropriations.detail.expenseCenter',
    breadcrumb: 'Expense Center',
    parent: RouteConstants.FINANCE_FUNDING_SOURCE_DETAIL,
    navigationId: NavigationConstants.FINANCE_NAV_ID
  };
  static FINANCE_FUNDING_SOURCE_PROJ_CTR: RouteInfo = {
    url: '/projectCenter',
    name: 'home.finance.myAppropriations.detail.projectCenter',
    breadcrumb: 'Project Center',
    parent: RouteConstants.FINANCE_FUNDING_SOURCE_DETAIL,
    navigationId: NavigationConstants.FINANCE_NAV_ID
  };
  static FINANCE_FUNDING_SOURCE_CREATE_EXP: RouteInfo = {
    url: '/createExpenseCenter',
    name: 'home.finance.myAppropriations.detail.projectCenter.createExpenseCenter',
    breadcrumb: 'Create Expense Center',
    parent: RouteConstants.FINANCE_FUNDING_SOURCE_PROJ_CTR,
    navigationId: NavigationConstants.FINANCE_NAV_ID, shown: true,
    perm: ResourceConstants.FINANCE_MANAGEMENT,
    selectionText: 'Create Expense Center',
  };

  static INVENTORY_OWNERS: RouteInfo = {
    url: '/invOwners',
    name: 'home.invOwners',
    breadcrumb: 'Inventory Owners',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.INVENTORY_NAV_ID,
    shown: true,
    perm: ResourceConstants.INVENTORY_MANAGEMENT,
    selectionText: 'Inventory Owners'
  };
  static INVENTORY_OWNER_DETAILS: RouteInfo = {
    url: '/invOwnerDetails',
    name: 'home.invOwners.invOwnerDetails',
    breadcrumb: 'Owner Details',
    parent: RouteConstants.INVENTORY_OWNERS,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  static INVENTORY_STORAGE_AREAS: RouteInfo = {
    url: '/invStorageAreas',
    name: 'home.invStorageAreas',
    breadcrumb: 'Storage Areas',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.INVENTORY_NAV_ID,
    shown: true,
    perm: ResourceConstants.INVENTORY_MANAGEMENT,
    selectionText: 'Storage Areas'
  };
  static INVENTORY_STORAGE_AREA_CREATE: RouteInfo = {
    url: '/invStorageAreaCreate',
    name: 'home.invStorageAreas.invStorageAreaCreate',
    breadcrumb: 'Create a new Storage Area',
    parent: RouteConstants.INVENTORY_STORAGE_AREAS,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  static INVENTORY_STORAGE_AREA_DETAILS: RouteInfo = {
    url: '/invStorageAreaDetails',
    name: 'home.invStorageAreas.invStorageAreaDetails',
    breadcrumb: 'Storage Area Details',
    parent: RouteConstants.INVENTORY_STORAGE_AREAS,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  static INVENTORY_LOCATION_DETAILS_FROM_STORAGE_AREA_DETAILS: RouteInfo = {
    url: '/invLocationDetailsFromSaDetails',
    name: 'home.invStorageAreas.invStorageAreaDetails.invLocationDetailsFromSaDetails',
    breadcrumb: 'Location Details',
    parent: RouteConstants.INVENTORY_STORAGE_AREA_DETAILS,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  static INVENTORY_REC_DETAILS_FROM_STORAGE_AREA_DETAILS: RouteInfo = {
    url: '/invItemDetailsFromSaDetails',
    name: 'home.invStorageAreas.invStorageAreaDetails.invLocationDetailsFromSaDetails.invItemDetailsFromSaDetails',
    breadcrumb: 'Item Details',
    parent: RouteConstants.INVENTORY_LOCATION_DETAILS_FROM_STORAGE_AREA_DETAILS,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  static INVENTORY_REC_LOC_DETAILS_FROM_STORAGE_AREA_DETAILS: RouteInfo = {
    url: '/invItemLocDetailsFromSaDetails',
    name: 'home.invStorageAreas.invStorageAreaDetails.invLocationDetailsFromSaDetails.invItemDetailsFromSaDetails.invItemLocDetailsFromSaDetails',
    breadcrumb: 'Item Location Details',
    parent: RouteConstants.INVENTORY_REC_DETAILS_FROM_STORAGE_AREA_DETAILS,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  static INVENTORY_LOCATIONS: RouteInfo = {
    url: '/invLocations',
    name: 'home.invLocations',
    breadcrumb: 'Locations Management',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.INVENTORY_NAV_ID,
    shown: true,
    perm: ResourceConstants.INVENTORY_MANAGEMENT,
    selectionText: 'Location Management',
  };
  static INVENTORY_LOCATION_CREATE: RouteInfo = {
    url: '/invLocationCreate',
    name: 'home.invLocations.invLocationCreate',
    breadcrumb: 'Create a new Location',
    parent: RouteConstants.INVENTORY_LOCATIONS,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  static INVENTORY_LOCATION_DETAILS: RouteInfo = {
    url: '/invLocationDetails',
    name: 'home.invLocations.invLocationDetails',
    breadcrumb: 'Location Details',
    parent: RouteConstants.INVENTORY_LOCATIONS,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  static INVENTORY_REC_DETAILS_FROM_LOCATION_DETAILS: RouteInfo = {
    url: '/invItemDetailsFromLocDetails',
    name: 'home.invLocations.invLocationDetails.invItemDetailsFromLocDetails',
    breadcrumb: 'Item Details',
    parent: RouteConstants.INVENTORY_LOCATION_DETAILS,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  static INVENTORY_REC_LOC_DETAILS_FROM_LOCATION_DETAILS: RouteInfo = {
    url: '/invItemLocDetailsFromLocDetails',
    name: 'home.invLocations.invLocationDetails.invItemDetailsFromLocDetails.invItemLocDetailsFromLocDetails',
    breadcrumb: 'Item Location Details',
    parent: RouteConstants.INVENTORY_REC_DETAILS_FROM_LOCATION_DETAILS,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  static INVENTORY_REC_SEARCH: RouteInfo = {
    url: '/invItemSearch',
    name: 'home.invItemSearch',
    breadcrumb: 'Inventory Search',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.INVENTORY_NAV_ID,
    shown: true,
    perm: ResourceConstants.INVENTORY_MANAGEMENT,
    selectionText: 'Inventory Search',
    dividerFollows: true
  };
  static INVENTORY_REC_ADD: RouteInfo = {
    url: '/invItemAdd',
    name: 'home.invItemSearch.invItemAdd',
    breadcrumb: 'Add an Inventory Item',
    parent: RouteConstants.INVENTORY_REC_SEARCH,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  static INVENTORY_REC_DETAILS: RouteInfo = {
    url: '/invItemDetails',
    name: 'home.invItemSearch.invItemDetails',
    breadcrumb: 'Item Details',
    parent: RouteConstants.INVENTORY_REC_SEARCH,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  static INVENTORY_REC_LOC_DETAILS: RouteInfo = {
    url: '/invItemLocDetails',
    name: 'home.invItemSearch.invItemDetails.invItemLocDetails',
    breadcrumb: 'Item Location Details',
    parent: RouteConstants.INVENTORY_REC_DETAILS,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  static INVENTORY_REPORT_EXCESS: RouteInfo = {
    url: '/invReportExcess',
    name: 'home.invReportExcess',
    breadcrumb: 'Excess',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.INVENTORY_NAV_ID,
    shown: true,
    perm: ResourceConstants.INVENTORY_MANAGEMENT,
    selectionText: 'Excess',
  };
  static INVENTORY_REPORT_EXCESS_DETAILS: RouteInfo = {
    url: '/invReportExcessDetails',
    name: 'home.invReportExcess.invReportExcessDetails',
    breadcrumb: 'Excess Details',
    parent: RouteConstants.INVENTORY_REPORT_EXCESS,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  static INVENTORY_REQUEST_EXCESS: RouteInfo = {
    url: '/invRequestExcess',
    name: 'home.invRequestExcess',
    breadcrumb: 'Excess Request',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.INVENTORY_NAV_ID,
    shown: true,
    perm: ResourceConstants.INVENTORY_MANAGEMENT,
    selectionText: 'Excess Request',
  };
  static INVENTORY_REQUEST_EXCESS_DETAILS: RouteInfo = {
    url: '/invRequestExcessDetails',
    name: 'home.invRequestExcess.invRequestExcessDetails',
    breadcrumb: 'Excess Request Details',
    parent: RouteConstants.INVENTORY_REQUEST_EXCESS,
    navigationId: NavigationConstants.INVENTORY_NAV_ID,
  };
  static INVENTORY_REQUEST_EXCESS_STATUS: RouteInfo = {
    url: '/invRequestExcessStatus',
    name: 'home.invRequestExcess.invRequestExcessStatus',
    breadcrumb: 'Excess Request Status',
    parent: RouteConstants.INVENTORY_REQUEST_EXCESS,
    navigationId: NavigationConstants.INVENTORY_NAV_ID,
  };
  static INVENTORY_LOGBAY_SEARCH: RouteInfo = {
    url: '/invLogbaySearch',
    name: 'home.invLogbaySearch',
    breadcrumb: 'LogBay Search',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.INVENTORY_NAV_ID,
    shown: true,
    perm: ResourceConstants.INVENTORY_MANAGEMENT,
    selectionText: 'LogBay Search',
  };
  static INVENTORY_LOGBAY_AVAILABLE_ITEM_DETAILS_FROM_SEARCH: RouteInfo = {
    url: '/invLogbayAvailItemDetailsFromSearch',
    name: 'home.invLogbaySearch.invLogbayAvailItemDetailsFromSearch',
    breadcrumb: 'Available Item Details',
    parent: RouteConstants.INVENTORY_LOGBAY_SEARCH,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  static INVENTORY_LOGBAY_MANAGER: RouteInfo = {
    url: '/invLogbayManager',
    name: 'home.invLogbayManager',
    breadcrumb: 'LogBay Management',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.INVENTORY_NAV_ID,
    shown: true,
    perm: ResourceConstants.INVENTORY_MANAGEMENT,
    selectionText: 'LogBay Management',
    dividerFollows: true
  };
  static INVENTORY_LOGBAY_AVAILABLE_ITEM_DETAILS_FROM_MANAGER: RouteInfo = {
    url: '/invLogbayAvailItemDetailsFromMgr',
    name: 'home.invLogbayManager.invLogbayAvailItemDetailsFromMgr',
    breadcrumb: 'Available Item Details',
    parent: RouteConstants.INVENTORY_LOGBAY_MANAGER,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  static INVENTORY_AUDIT: RouteInfo = {
    url: '/invAudit',
    name: 'home.invAudit',
    breadcrumb: 'Physical Inventory Audit',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.INVENTORY_NAV_ID,
    shown: true,
    perm: ResourceConstants.INVENTORY_MANAGEMENT,
    selectionText: 'Physical Inventory Audit',
  };
  static INVENTORY_AUDIT_SCHEDULED_CREATE: RouteInfo = {
    url: '/invAuditScheduleCreate',
    name: 'home.invAudit.invAuditScheduledCreate',
    breadcrumb: 'Create a Scheduled Physical Inventory',
    parent: RouteConstants.INVENTORY_AUDIT,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  static INVENTORY_AUDIT_SCHEDULED_DETAILS: RouteInfo = {
    url: '/invAuditScheduledDetails',
    name: 'home.invAudit.invAuditScheduledDetails',
    breadcrumb: 'Scheduled Physical Inventory Details',
    parent: RouteConstants.INVENTORY_AUDIT,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  static INVENTORY_AUDIT_INPROGRESS_DETAILS: RouteInfo = {
    url: '/invAuditInProgressDetails',
    name: 'home.invAudit.invAuditProgressDetails',
    breadcrumb: 'In Progress Physical Inventory Details',
    parent: RouteConstants.INVENTORY_AUDIT,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  static INVENTORY_AUDIT_COMPLETED_DETAILS: RouteInfo = {
    url: '/invAuditCompletedDetails',
    name: 'home.invAudit.invAuditCompletedDetails',
    breadcrumb: 'Completed Physical Inventory Details',
    parent: RouteConstants.INVENTORY_AUDIT,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  static INVENTORY_PLANNING: RouteInfo = {
    url: '/invPlanning',
    name: 'home.invPlanning',
    breadcrumb: 'Inventory Planning',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.INVENTORY_NAV_ID,
    shown: true,
    perm: ResourceConstants.INVENTORY_MANAGEMENT,
    selectionText: 'Inventory Planning',
  };
  static INVENTORY_PLANNING_DETAILS: RouteInfo = {
    url: '/invPlanningDetails',
    name: 'home.invPlanning.invPlanningDetails',
    breadcrumb: 'Recommended Level Change',
    parent: RouteConstants.INVENTORY_PLANNING,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  static INVENTORY_SHIPPING: RouteInfo = {
    url: '/invShipping',
    name: 'home.invShipping',
    breadcrumb: 'Transportation',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.INVENTORY_NAV_ID,
    shown: true,
    perm: ResourceConstants.INVENTORY_MANAGEMENT,
    selectionText: 'Transportation',
  };
  static INVENTORY_SHIPMENT_DETAILS: RouteInfo = {
    url: '/invShipmentDetails',
    name: 'home.invShipping.invShipmentDetails',
    breadcrumb: 'Shipment Details',
    parent: RouteConstants.INVENTORY_SHIPPING,
    navigationId: NavigationConstants.INVENTORY_NAV_ID,
  };
  static INVENTORY_SHIPPERS: RouteInfo = {
    url: '/invShippers',
    name: 'home.invShipping.invShippers',
    breadcrumb: 'Manage Shippers',
    parent: RouteConstants.INVENTORY_SHIPPING,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  static INVENTORY_SHIPPER_ADD: RouteInfo = {
    url: '/invShipperAdd',
    name: 'home.invShipping.invShippers.invShipperAdd',
    breadcrumb: 'Add a new Shipper',
    parent: RouteConstants.INVENTORY_SHIPPERS,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  static INVENTORY_SHIPPER_DETAILS: RouteInfo = {
    url: '/invShipperDetails',
    name: 'home.invShipping.invShippers.invShipperDetails',
    breadcrumb: 'Shipper Details',
    parent: RouteConstants.INVENTORY_SHIPPERS,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  static INVENTORY_RETURNS: RouteInfo = {
    url: '/invReturns',
    name: 'home.invReturns',
    breadcrumb: 'Return Management',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.INVENTORY_NAV_ID,
    shown: true,
    perm: ResourceConstants.INVENTORY_MANAGEMENT,
    selectionText: 'Return Management'
  };
  static INVENTORY_RETURN_PICKUP_DETAILS: RouteInfo = {
    url: '/invReturnPickupDetails',
    name: 'home.invReturns.invReturnPickupDetails',
    breadcrumb: 'Pickup Details',
    parent: RouteConstants.INVENTORY_RETURNS,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  static INVENTORY_RETURN_ACTION_TYPE_DETAILS: RouteInfo = {
    url: '/invReturnActionTypeDetails',
    name: 'home.invReturns.invReturnActionTypeDetails',
    breadcrumb: 'Provide Disposition Details',
    parent: RouteConstants.INVENTORY_RETURNS,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  static INVENTORY_RETURN_FINAL_REVIEW: RouteInfo = {
    url: '/invReturnFinalReview',
    name: 'home.invReturns.invReturnFinalReview',
    breadcrumb: 'Final Review',
    parent: RouteConstants.INVENTORY_RETURNS,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  static INVENTORY_RETURN_COMPLETE: RouteInfo = {
    url: '/invReturnComplete',
    name: 'home.invReturns.invReturnComplete',
    breadcrumb: 'Complete - Review Only',
    parent: RouteConstants.INVENTORY_RETURNS,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };

  static JMLFDC_ADMIN: RouteInfo = {
    url: '/admin', name: 'home.admin', breadcrumb: 'Admin',
    parent: RouteConstants.HOME_ROOT, navigationId: NavigationConstants.ADMIN_NAV_ID
  };
  static NOTIFICATIONS_VIEW: RouteInfo = {
    url: '/viewNotifications',
    name: 'home.admin.notifications',
    breadcrumb: 'System Notifications',
    parent: RouteConstants.JMLFDC_ADMIN, navigationId: NavigationConstants.ADMIN_NAV_ID, shown: true,
    perm: ResourceConstants.VIEW_SYSTEM_NOTIFICATIONS,
    selectionText: 'System Notifications',
  };
  static NOTIFICATIONS_ADD: RouteInfo = {
    url: '/createNotification',
    name: 'home.admin.notifications.createNotification',
    breadcrumb: 'Add',
    parent: RouteConstants.NOTIFICATIONS_VIEW, navigationId: NavigationConstants.ADMIN_NAV_ID
  };
  static NOTIFICATIONS_EDIT: RouteInfo = {
    url: '/editNotification',
    name: 'home.admin.notifications.editNotification',
    breadcrumb: 'Edit',
    parent: RouteConstants.NOTIFICATIONS_VIEW, navigationId: NavigationConstants.ADMIN_NAV_ID

  };

  static ORDER_EQUIPMENT_REQUEST: RouteInfo = { // TODO Define this route
    url: '', name: '',
    navigationId: NavigationConstants.ORDERING_NAV_ID,
    breadcrumb: 'Equipment Request',
    parent: RouteConstants.HOME_ROOT, shown: false,
    perm: '',
    selectionText: 'Equipment Request',
    dividerFollows: true,
  };

  static ORDER_BUYER: RouteInfo = {
    url: '/customer', name: 'home.customer', breadcrumb: 'Customer',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.ORDERING_NAV_ID, shown: true,
    selectionText: 'Customer',
    perm: ResourceConstants.ORDERS_VIEW
  };

  static ORDER_BUYER_DETAILS: RouteInfo = {
    url: '/details',
    name: 'home.customer.customerDetails',
    breadcrumb: 'Customer Details',
    parent: RouteConstants.ORDER_BUYER, navigationId: NavigationConstants.ORDERING_NAV_ID
  };
  static ORDER_CART: RouteInfo = {
    url: '/cart', name: 'home.cart', breadcrumb: 'Cart',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.ORDERING_NAV_ID, shown: true,
    perm: ResourceConstants.ORDERS_VIEW,
    selectionText: 'View Cart'
  };
  static ORDER_CART_CHECKOUT: RouteInfo = {
    url: '/checkout', name: 'home.cart.checkout', breadcrumb: 'Checkout',
    parent: RouteConstants.ORDER_CART, navigationId: NavigationConstants.ORDERING_NAV_ID
  };
  static ORDER_CART_SUMMARY: RouteInfo = {
    url: '/summary', name: 'home.cart.orderSummary', breadcrumb: 'OrderSummary',
    parent: RouteConstants.ORDER_CART, navigationId: NavigationConstants.ORDERING_NAV_ID
  };
  static ORDER_LISTS: RouteInfo = {
    url: '/lists', name: 'home.lists', breadcrumb: 'Item Lists',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.ORDERING_NAV_ID, shown: true,
    perm: ResourceConstants.ORDERS_VIEW,
    selectionText: 'Your Lists'
  };
  static ORDER_VIEW: RouteInfo = {
    url: '/orders', name: 'home.viewOrder', breadcrumb: 'Orders',
    parent: RouteConstants.HOME_ROOT, navigationId: NavigationConstants.ORDERING_NAV_ID, shown: true,
    selectionText: 'Orders',
    perm: ResourceConstants.ORDERS_VIEW,
    dividerFollows: true
  };
  static ORDER_VIEW_DETAIL: RouteInfo = {
    url: '/orderDetail', name: 'home.viewOrder.orderDetail',
    breadcrumb: 'Order Detail',
    parent: RouteConstants.ORDER_VIEW, navigationId: NavigationConstants.ORDERING_NAV_ID
  };
  static ORDER_RECEIPT: RouteInfo = {
    url: '/receipts', name: 'home.receipts', breadcrumb: 'Receipts',
    parent: RouteConstants.HOME_ROOT, navigationId: NavigationConstants.ORDERING_NAV_ID, shown: true,
    selectionText: 'Receipts',
    perm: ResourceConstants.ORDERS_VIEW,
    dividerFollows: true
  };
  static ORDER_RECEIPT_DETAIL: RouteInfo = {
    url: '/receiptDetail', name: 'home.receipts.receiptDetail',
    breadcrumb: 'Receipt Detail',
    parent: RouteConstants.ORDER_RECEIPT, navigationId: NavigationConstants.ORDERING_NAV_ID
  };

  static FULFILLMENT_ORDER_FULFILLMENT: RouteInfo = {
    url: '/incomingOrders',
    name: 'home.incomingOrders',
    breadcrumb: 'Order Fulfillment',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.FULFILLMENT_NAV_ID,
    shown: true, perm: ResourceConstants.ORDERS_VIEW,
    selectionText: 'Order Fulfillment',
  };
  static FULFILLMENT_PICKLIST_MANAGEMENT: RouteInfo = {
    url: '/picklistManagement',
    name: 'home.confirmPicklist',
    breadcrumb: 'Picklist Management',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.FULFILLMENT_NAV_ID,
    shown: true, perm: ResourceConstants.ORDERS_VIEW,
    selectionText: 'Picklist Management',
  };
  static FULFILLMENT_STAGED_ITEMS: RouteInfo = {
    url: '/stagedItems',
    name: 'home.generatePicklist',
    breadcrumb: 'Staged Items',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.FULFILLMENT_NAV_ID,
    shown: true, perm: ResourceConstants.ORDERS_VIEW,
    selectionText: 'Staged Items',
  };
  static ORDER_CATALOG: RouteInfo = {
    url: '/catalog',
    name: 'home.catalog',
    breadcrumb: 'Search Catalog',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.ORDERING_NAV_ID,
    shown: true, selectionText: 'Search Catalog',
    perm: ResourceConstants.EQUIP_REQUESTS_MY_REQUESTS,
    dividerFollows: true
  };
  static ORDER_CATALOG_ITEM_DETAILS: RouteInfo = {
    url: '/catalogItemDetails',
    name: 'home.catalog.catalogItemDetails',
    breadcrumb: 'Catalog Item Details',
    parent: RouteConstants.ORDER_CATALOG,
    navigationId: NavigationConstants.ORDERING_NAV_ID
  };

  // static ORDER_INCOMING_ORDERS: RouteInfo = {
  //   url: '/editFulfillment',
  //   name: 'home.processFulfillment.editFulfillment',
  //   breadcrumb: 'Edit Fulfillment',
  //   parent: RouteConstants.ORDER_FULFILLMENT
  // };
  static ORDER_DELIVERY_LIST: RouteInfo = {
    url: '/processDeliverList',
    name: 'home.processDeliveryList',
    breadcrumb: 'Delivery List',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.FULFILLMENT_NAV_ID
  };

  static ORDER_SELLER: RouteInfo = {
    url: '/supplier',
    name: 'home.seller',
    breadcrumb: 'Supplier',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.FULFILLMENT_NAV_ID,
    shown: true,
    selectionText: 'Supplier',
    dividerFollows: true
  };
  static ORDER_SELLER_DETAILS: RouteInfo = {
    url: '/details',
    name: 'home.seller.sellerDetails',
    breadcrumb: 'Details',
    parent: RouteConstants.ORDER_SELLER,
    navigationId: NavigationConstants.FULFILLMENT_NAV_ID
  };
  static ORDER_REQUISITION: RouteInfo = { // TODO confirm order requisition route
    url: '/requisition',
    name: 'home.requisition',
    breadcrumb: 'Requisition',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.ORDERING_NAV_ID,
    shown: true, selectionText: 'Requisition',
    perm: '',
  };

  static ORGANIZATION_VIEW: RouteInfo = {
    url: '/organizationView',
    name: 'home.organizationView',
    breadcrumb: 'Organization View',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.ORGANIZATION_NAV_ID,
    shown: true,
    perm: ResourceConstants.ORGANIZATION_TREE_MANAGEMENT,
    selectionText: 'View Organization',
  };

  static ORGANIZATION_MANAGEMENT: RouteInfo = {
    url: '/organizationManagement',
    name: 'home.organizationManagement',
    breadcrumb: 'Organization Management',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.ORGANIZATION_NAV_ID,
    shown: true,
    perm: ResourceConstants.ORGANIZATION_TREE_MANAGEMENT,
    selectionText: 'Manage Organization',
  };

  static COMMUNICATIONS: RouteInfo = {
    url: '/communications',
    name: 'home.communications',
    breadcrumb: 'Communications',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.COMMUNICATIONS_NAV_ID
  };
  static COMMUNICATIONS_SEARCH: RouteInfo = {
    url: '/search',
    name: 'home.communicationsSearch',
    breadcrumb: 'Communications Search',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.COMMUNICATIONS_NAV_ID,
    shown: true,
    perm: ResourceConstants.COMMUNICATIONS_MANAGEMENT,
    selectionText: 'Communications Search'
  };
  static COMMUNICATIONS_SEARCH_RECORD_DETAIL: RouteInfo = {
    url: '/searchRecordDetail',
    name: 'home.communicationsSearch.searchRecordDetail',
    breadcrumb: 'Search Record Detail',
    parent: RouteConstants.COMMUNICATIONS_SEARCH,
    navigationId: NavigationConstants.COMMUNICATIONS_NAV_ID
  };
  static COMMUNICATIONS_RESUBMIT: RouteInfo = {
    url: '/resubmit',
    name: 'home.communicationsResubmit',
    breadcrumb: 'Communications Resubmit',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.COMMUNICATIONS_NAV_ID,
    shown: true,
    perm: ResourceConstants.COMMUNICATIONS_RESUBMIT_VIEW,
    selectionText: 'Communications Resubmit'
  };
  static COMMUNICATIONS_FINANCIAL_RESUBMIT: RouteInfo = {
    url: '/financialResubmit',
    name: 'home.communicationsFinancialResubmit',
    breadcrumb: 'Communications Financial Resubmit',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.COMMUNICATIONS_NAV_ID,
    shown: true,
    perm: ResourceConstants.COMMUNICATIONS_FINANCIAL_RESUBMIT_VIEW,
    selectionText: 'Communications Financial Resubmit'
  };
  static COMMUNICATIONS_ERROR_DISMISSAL: RouteInfo = {
    url: '/viewCommunicationsErrors',
    name: 'home.manageCommunicationsErrors',
    breadcrumb: 'Error Dismissal',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.COMMUNICATIONS_NAV_ID,
    shown: true,
    perm: ResourceConstants.COMMUNICATIONS_ERROR_DISMISSAL_VIEW,
    selectionText: 'Error Dismissal',
    dividerFollows: true,
  };
  static COMMUNICATIONS_ERROR_DISMISSAL_DETAIL: RouteInfo = {
    url: '/errorDismissalDetail',
    name: 'home.manageCommunicationsErrors.errorDismissalDetail',
    breadcrumb: 'Error Dismissal Detail',
    parent: RouteConstants.COMMUNICATIONS_ERROR_DISMISSAL,
    navigationId: NavigationConstants.COMMUNICATIONS_NAV_ID
  };
  static COMMUNICATIONS_GATEWAY_ERRORS: RouteInfo = {
    url: '/viewGatewayErrors',
    name: 'home.manageGatewayErrors',
    breadcrumb: 'Inbound Gateway Errors',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.COMMUNICATIONS_NAV_ID,
    shown: true,
    perm: ResourceConstants.COMMUNICATIONS_GATEWAY_ERRORS_VIEW,
    selectionText: 'Inbound Gateway Errors',
    dividerFollows: true
  };
  static COMMUNICATIONS_GATEWAY_ERROR_DETAIL: RouteInfo = {
    url: '/gatewayErrorDetail',
    name: 'home.manageGatewayErrors.gatewayErrorDetail',
    breadcrumb: 'Inbound Gateway Error Detail',
    parent: RouteConstants.COMMUNICATIONS_GATEWAY_ERRORS,
    navigationId: NavigationConstants.COMMUNICATIONS_NAV_ID
  };
  static COMMUNICATIONS_EHR: RouteInfo = {
    url: '/viewCommunicationsEhr',
    name: 'home.manageCommunicationsEhr',
    breadcrumb: 'Manage Electronic Health Records',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.COMMUNICATIONS_NAV_ID,
    shown: true,
    perm: ResourceConstants.COMMUNICATIONS_EHR_VIEW,
    selectionText: 'Manage Electronic Health Records'
  };
  static COMMUNICATIONS_EHR_ADD_SYSTEM: RouteInfo = {
    url: '/addEhrSystem',
    name: 'home.manageCommunicationsEhr.addEhrSystem',
    breadcrumb: 'Add Electronic Health Records System',
    parent: RouteConstants.COMMUNICATIONS_EHR,
    navigationId: NavigationConstants.COMMUNICATIONS_NAV_ID
  };
  static COMMUNICATIONS_EHR_EDIT_SYSTEM: RouteInfo = {
    url: '/editEhrSystem',
    name: 'home.manageCommunicationsEhr.editEhrSystem',
    breadcrumb: 'Edit Electronic Health Records System',
    parent: RouteConstants.COMMUNICATIONS_EHR,
    navigationId: NavigationConstants.COMMUNICATIONS_NAV_ID
  };
  static COMMUNICATIONS_EHR_MANAGE_CUSTOMERS: RouteInfo = {
    url: '/manageEhrCustomers',
    name: 'home.manageCommunicationsEhr.manageCustomers',
    breadcrumb: 'Manage Customers',
    parent: RouteConstants.COMMUNICATIONS_EHR,
    navigationId: NavigationConstants.COMMUNICATIONS_NAV_ID
  };
  static COMMUNICATIONS_EHR_MANAGE_MESSAGES: RouteInfo = {
    url: '/manageEhrMessages',
    name: 'home.manageCommunicationsEhr.manageMessages',
    breadcrumb: 'Manage Messages',
    parent: RouteConstants.COMMUNICATIONS_EHR,
    navigationId: NavigationConstants.COMMUNICATIONS_NAV_ID
  };
  static COMMUNICATIONS_EHR_VIEW_MESSAGE_ORDER_LINES: RouteInfo = {
    url: '/viewEhrMessageOrderLines',
    name: 'home.manageCommunicationsEhr.manageMessages.viewMessageOrderLines',
    breadcrumb: 'View Order Lines',
    parent: RouteConstants.COMMUNICATIONS_EHR_MANAGE_MESSAGES,
    navigationId: NavigationConstants.COMMUNICATIONS_NAV_ID
  };
  static COMMUNICATIONS_ECMS: RouteInfo = {
    url: '/viewCommunicationsEcms',
    name: 'home.manageCommunicationsEcms',
    breadcrumb: 'Manage eCMS',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.COMMUNICATIONS_NAV_ID,
    shown: true,
    perm: ResourceConstants.COMMUNICATIONS_ECMS_VIEW,
    selectionText: 'Manage eCMS'
  };
  static COMMUNICATIONS_POINT_OF_CARE: RouteInfo = {
    url: '/viewCommunicationsPointOfCare',
    name: 'home.manageCommunicationsPointOfCare',
    breadcrumb: 'Manage Point of Care',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.COMMUNICATIONS_NAV_ID,
    shown: true,
    perm: ResourceConstants.COMMUNICATIONS_POINT_OF_CARE_VIEW,
    dividerFollows: true,
    selectionText: 'Manage Point of Care'
  };
  static COMMUNICATIONS_POINT_OF_CARE_ADD_SYSTEM: RouteInfo = {
    url: '/addPocSystem',
    name: 'home.manageCommunicationsPointOfCare.addPocSystem',
    breadcrumb: 'Add Point of Care System',
    parent: RouteConstants.COMMUNICATIONS_POINT_OF_CARE,
    navigationId: NavigationConstants.COMMUNICATIONS_NAV_ID,
  };
  static COMMUNICATIONS_POINT_OF_CARE_EDIT_SYSTEM: RouteInfo = {
    url: '/editPocSystem',
    name: 'home.manageCommunicationsPointOfCare.editPocSystem',
    breadcrumb: 'Edit Point of Care System',
    parent: RouteConstants.COMMUNICATIONS_POINT_OF_CARE,
    navigationId: NavigationConstants.COMMUNICATIONS_NAV_ID,
  };
  static COMMUNICATIONS_OUTBOUND_CONFIG: RouteInfo = {
    url: '/viewCommunicationsOutboundConfig',
    name: 'home.manageCommunicationsOutboundConfig',
    breadcrumb: 'Manage Outbound Transmission Configurations',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.COMMUNICATIONS_NAV_ID,
    shown: true,
    perm: ResourceConstants.COMMUNICATIONS_OUTBOUND_TRANSMISSION_CONFIG_VIEW,
    selectionText: 'Manage Outbound Transmission Configurations'
  };
  static COMMUNICATIONS_CONFIGURATIONS: RouteInfo = {
    url: '/viewCommunicationsConfigurations',
    name: 'home.manageCommunicationsConfigurations',
    breadcrumb: 'Communications Configurations',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.COMMUNICATIONS_NAV_ID,
    shown: true,
    perm: ResourceConstants.COMMUNICATIONS_CONFIGURATIONS_VIEW,
    selectionText: 'Communications Configurations'
  };
  static EQUIPMENT_RECORDS: RouteInfo = {
    url: '/equipment',
    name: 'home.equipmentRecords',
    breadcrumb: 'Equipment Records',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.EQUIPMENT_NAV_ID,
    // perm: ResourceConstants.EQUIP_RECORDS_VIEW,
    selectionText: 'Equipment Records',
    shown: true
  };
  static EQUIPMENT_RECORD_DETAILS: RouteInfo = {
    url: '/:dodaac/:meId',
    name: 'home.equipmentRecords.details',
    breadcrumb: 'Equipment Record Details',
    parent: RouteConstants.EQUIPMENT_RECORDS,
    navigationId: NavigationConstants.EQUIPMENT_NAV_ID
  };

  static UNDEFINED: RouteInfo = {
    url: '#', name: 'undefined', breadcrumb: 'X',
    parent: RouteConstants.HOME_ROOT
  };
}
