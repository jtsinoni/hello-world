
export class CookieConstants {
    static get Default(): any {
        return {
            KEY_CURRENT_STATE: 'currentState'
        };
    }
}
