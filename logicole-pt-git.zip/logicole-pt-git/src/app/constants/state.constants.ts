export class StateConstants {

  /* Comment out for merge w/ DSE-2349
   // static LOGIN: string                 = 'dmles.login';
   static LOGIN: string                 = 'login';
   static ACCESSIBILITY: string         = 'dmles.login.accessibility';
   static CHOOSE_PROFILE: string        = 'dmles.login.chooseProfile';
   static INVITATION: string            = 'dmles.login.invitation';
   static GROUPINVITATION: string       = 'dmles.login.groupInvitation';
   static REQUEST_PKI_DN_UPDATE: string = 'dmles.login.requestPkiDnUpdate';
   static UPDATE_PKI_DN: string         = 'dmles.login.updatePkiDN';

   static HOME_ROOT: string = 'dmles.home';
   static ABOUT: string = 'about';
   static HELP: string = 'help';
   static LOADING: string = 'loading';
   static MY_DASHBOARD: string = 'dashboard';
   static USER_PROFILE: string = 'userProfile';
   static USER_PROFILE_EDIT_GEN_INFO: string = 'editGenInfoUserProfile';


   static ABI_SHELL: string = 'dmles.home.abi';
   static ABI_SEARCH: string = 'dmles.home.abi.search';
   static ABI_SEARCH_HELP: string = 'dmles.home.abi.search.help';
   static ABI_PREFERRED_PRODUCT: string = 'dmles.home.abi.search.preferredProduct';
   static ABI_PRODUCT_COMPARISON: string = 'dmles.home.abi.search.productComparison';
   static ABI_PRODUCT_DETAILS: string = 'dmles.home.abi.search.productDetails';
   static ABI_PRODUCTS_IN_SAME_PRODUCT_GROUP: string = 'dmles.home.abi.search.sameProductGroup';
   static ABI_PRODUCTS_IN_SUBSTITUTE_PRODUCT_GROUP: string = 'dmles.home.abi.search.substituteProductGroup';
   static ABI_PRODUCTS_SITE_CATALOG_ITEMS: string = 'dmles.home.abi.search.siteCatalogItems';
   static ABI_PRODUCTS_SITE_EQUIPMENT_RECORDS: string = 'dmles.home.abi.search.siteEquipmentRecords';

   static ADMIN_SHELL: string = 'admin';
   static ADMIN_PERMISSION_MNG: string = 'dmles.home.admin.permissionMng';
   static ADMIN_PERMISSION_CREATE: string = 'dmles.home.admin.permissionMng.createPermission';
   static ADMIN_PERMISSION_EDIT_ELEMENTS: string = 'dmles.home.admin.permissionMng.editElementsPermission';
   static ADMIN_PERMISSION_EDIT_ENDPOINTS: string = 'dmles.home.admin.permissionMng.editEndpointsPermission';
   static ADMIN_PERMISSION_EDIT_GEN_INFO: string = 'dmles.home.admin.permissionMng.editGenInfoPermission';
   static ADMIN_PERMISSION_EDIT_STATES: string = 'dmles.home.admin.permissionMng.editStatesPermission';
   static ADMIN_PERMISSION_VIEW: string = 'dmles.home.admin.permissionMng.viewPermission';
   static ADMIN_ELEMENT_MNG: string = 'dmles.home.admin.permissionMng.elementMng';
   static ADMIN_ENDPOINT_MNG: string = 'dmles.home.admin.permissionMng.endpointMng';
   static ADMIN_STATE_MNG: string = 'dmles.home.admin.permissionMng.stateMng';
   static ADMIN_ROLE_MNG: string = 'dmles.home.admin.roleMng';
   static ADMIN_ROLE_CREATE: string = 'dmles.home.admin.roleMng.createRole';
   static ADMIN_ROLE_EDIT_GEN_INFO: string = 'dmles.home.admin.roleMng.editGenInfoRole';
   static ADMIN_ROLE_EDIT_PERMS: string = 'dmles.home.admin.roleMng.editPermsRole';
   static ADMIN_ROLE_VIEW: string = 'dmles.home.admin.roleMng.viewRole';
   static ADMIN_ORG_MNG: string = 'dmles.home.orgMng';

   static ADMIN_USER_PROFILE_MNG: string = 'dmles.home.admin.userProfileMng';
   static ADMIN_USER_PROFILE_EDIT_GEN_INFO: string = 'dmles.home.admin.userProfileMng.viewUserProfile.editGenInfoUserProfile';
   static ADMIN_USER_PROFILE_EDIT_PERMS: string = 'dmles.home.admin.userProfileMng.viewUserProfile.editPermsUserProfile';
   static ADMIN_USER_PROFILE_EDIT_ROLES: string = 'dmles.home.admin.userProfileMng.viewUserProfile.editRolesUserProfile';
   static ADMIN_USER_PROFILE_EDIT_STATUS: string = 'dmles.home.admin.userProfileMng.viewUserProfile.editStatus';
   static ADMIN_USER_PROFILE_VIEW: string = 'dmles.home.admin.userProfileMng.viewUserProfile';
   static ADMIN_USER_PROFILE_EDIT_ACCESS: string = 'dmles.home.admin.userProfileMng.viewUserProfile.editAccess';
   static ADMIN_USER_PROFILE_EDIT_INV_INFO: string = 'dmles.home.admin.userProfileMng.viewUserProfile.editInvitationInfo';

   static ADMIN_USER_PROFILE_CREATE: string = 'dmles.home.admin.userProfileMng.createProfile';
   static ADMIN_USER_PROFILE_ACCESS: string = 'dmles.home.admin.userProfileMng.createProfile.access';
   static ADMIN_USER_PROFILE_ASSIGN_ROLES: string = 'dmles.home.admin.userProfileMng.createProfile.access.roles';
   static ADMIN_USER_PROFILE_CREATE_CONFIRM: string = 'dmles.home.admin.userProfileMng.createProfile.access.roles.confirm';

   static ADMIN_GROUP_INVITATION_CREATE: string = 'dmles.home.admin.userProfileMng.createInvitation';
   static ADMIN_GROUP_INVITATION_ACCESS: string = 'dmles.home.admin.userProfileMng.createInvitation.access';
   static ADMIN_GROUP_INVITATION_ASSIGN_ROLES: string = 'dmles.home.admin.userProfileMng.createInvitation.access.roles';
   static ADMIN_GROUP_INVITATION_CREATE_CONFIRM: string = 'dmles.home.admin.userProfileMng.createInvitation.access.roles.confirm';
   static ADMIN_GROUP_INVITATION_VIEW_URL: string = 'dmles.home.admin.userProfileMng.viewGroupInvitationUrl';
   static ADMIN_GROUP_INVITATION_VIEW: string = 'dmles.home.admin.userProfileMng.viewGroupInvitation';

   static ADMIN_GROUP_INVITATION_EDIT_INFO: string = 'dmles.home.admin.userProfileMng.viewGroupInvitation.editGroupInvitationInfo';
   // tslint:disable-next-line:max-line-length
   static ADMIN_GROUP_INVITATION_EDIT_ACCESS: string = 'dmles.home.admin.userProfileMng.viewGroupInvitation.editGroupInvitationAccess';
   static ADMIN_GROUP_INVITATION_EDIT_ROLES: string = 'dmles.home.admin.userProfileMng.viewGroupInvitation.editGroupInvitationRoles';

   static EQUIP_SHELL: string = 'dmles.home.equipment';
   static EQUIP_RECORD_SEARCH: string = 'dmles.home.equipment.record';
   static EQUIP_RECORD_DATA_MANAGEMENT: string = 'dmles.home.equipment.recordDataManagement';
   static EQUIP_RECORD_DETAILS: string = 'dmles.home.equipment.record.details';

   static EQUIP_REQUEST_SHELL: string = 'dmles.home.equipment.request';
   static EQUIP_REQUEST_MY_REQUESTS: string = 'dmles.home.equipment.request.myRequests';
   static EQUIP_REQUEST_VIEW: string = 'dmles.home.equipment.request.myRequests.view';
   static EQUIP_REQUEST_HISTORY: string = 'dmles.home.equipment.request.myRequests.view.history';
   static EQUIP_REQUEST_ATTACHMENTS: string = 'dmles.home.equipment.request.myRequests.view.attachments';
   static EQUIP_REQUEST_NOTES: string = 'dmles.home.equipment.request.myRequests.view.notes';
   static EQUIP_REQUEST_PRINT: string = 'dmles.home.equipment.request.myRequests.view.print';

   // static ORG_MNG: string   = 'dmles.home.organization.management';
   static ORG_MNG: string   = 'organizationManage';
   static ORG_SHELL: string = 'dmles.home.organization';
   // static ORG_VIEW: string  = 'dmles.home.organization.view';
   static ORG_VIEW: string  = 'organizationView';


   static JMLFDC_ADMIN_SHELL: string = 'jmlfdcAdmin';
   static MANAGE_SERVICE_PROVIDERS: string = 'dmles.home.jmlfdcAdmin.viewServiceProviders';


   static ABI_STAGING_VIEW: string = 'dmles.home.jmlfdcAdmin.abiStaging.viewAbiStaging';
   static ABI_STAGING_EDIT: string = 'dmles.home.jmlfdcAdmin.abiStaging.viewAbiStaging.editAbiStaging';
   static ABI_STAGING_SHELL: string = 'dmles.home.jmlfdcAdmin.abiStaging';
   static ABI_STAGING_MERGE_BY_MMC: string = 'dmles.home.jmlfdcAdmin.abiStaging.mergeByMmc';
   static ABI_STAGING_MERGE_RECORDS: string = 'dmles.home.jmlfdcAdmin.abiStaging.mergeRecords';
   static ABI_STAGING_SET_UNSPSC: string = 'dmles.home.jmlfdcAdmin.abiStaging.viewAbiStaging.setUnspsc';
   static ABI_STAGING_SET_ATTRS: string = 'dmles.home.jmlfdcAdmin.abiStaging.viewAbiStaging.setAttributes';
   static ABI_STAGING_MANAGE_MERGED_RECS: string = 'dmles.home.jmlfdcAdmin.abiStaging.manageMergedRecords';
   static ABI_STAGING_MOVE_TO_PRODUCTION: string = 'dmles.home.jmlfdcAdmin.abiStaging.abiMoveToProduction';
   static ABI_STAGING_DELTA_VIEW: string = 'dmles.home.jmlfdcAdmin.abiStaging.viewAbiDelta';

   static EQUIPMENT_TESTING: string = 'dmles.home.jmlfdcAdmin.equipmentTesting';
   static APP_HISTORY_VIEW: string = 'dmles.home.jmlfdcAdmin.viewAppHistory';

   static GENERATE_PICKLIST: string                         = 'generatePicklist';
   static CONFIRM_PICKLIST: string                         = 'confirmPicklist';

   static NOTIFICATIONS_VIEW: string = 'viewNotifications'; // dmles.home.jmlfdcAdmin.
   static NOTIFICATIONS_ADD: string = 'createNotification'; // dmles.home.jmlfdcAdmin.
   static NOTIFICATIONS_EDIT: string = 'editNotification'; // dmles.home.jmlfdcAdmin.

   static ORDER: string                                     = 'dmles.home.order';
   static ORDER_BUYER: string                               = 'dmles.home.order.buyer';
   static ORDER_CART: string                                = 'dmles.home.order.cart';
   static ORDER_CART_CHECKOUT: string                       = 'dmles.home.order.cart.checkout';
   static ORDER_CART_SUMMARY: string                        = 'dmles.home.order.cart.summary';
   static ORDER_VIEW: string                                = 'dmles.home.order.view';
   static ORDER_RECEIPT: string                             = 'dmles.home.order.receipts';
   static ORDER_SELLER: string                              = 'dmles.home.order.seller';
   static ORDER_FULFILLMENT: string                         = 'dmles.home.order.fulfillment';

   static ORDERING_BUYER_MNG: string   = 'order/buyer';
   static COFFEE: string = 'dmles.home.coffee';

   static FIN_SHELL                        = 'dmles.home.finance';
   static FIN_LANDING                      = 'dmles.home.finance.landing';
   static FIN_APPROPRIATIONS_SHELL         = 'dmles.home.finance.fundingSource';
   static FIN_MY_FUNDING_SOURCES            = 'dmles.home.finance.fundingSource-search.fundingSource-search';
   static FIN_MY_FUNDING_SOURCE_DETAIL     = 'dmles.home.finance.detail.detail';
   static FIN_PROJECT_CENTER               = 'dmles.home.finance.projectcenter';
   static FIN_PROJECT_CENTER_VIEW          = 'dmles.home.finance.projectcenter.view';
   static FIN_PROJECT_CENTER_EDIT          = 'dmles.home.finance.projectcenter.edit';
   static FIN_SEARCH: string               = 'dmles.home.finance.search.search';

   // static INVENTORY: string = 'inventory';
   // static INVENTORY_SEARCH: string = 'search';
   // static INVENTORY_ITEM_ADD: string = 'add';
   // static INVENTORY_DETAILS: string = 'details';
   // static INVENTORY_ITEM_EDIT: string = 'edit';

   static LOGBAY_AVAILABLE_ITEMS_VIEW : string = 'dmles.home.inventory.logbay';
   static LOGBAY_MGMT_VIEW : string = 'dmles.home.inventory.logbaymgmt';
   static LOGBAY_MGMT_ITEM_VIEW : string = 'dmles.home.inventory.logbaymgmt.itemdetail';


   constructor() {
   }

   public static createLink(constant: string, extras?: NavigationExtras): any {
   const link = extras ? ['/' + constant, extras] : ['/' + constant];
   return link;
   }

   =======*/
  // TODO keep for reference then discard

  // static LOGIN: string                 = 'login';
  // static ACCESSIBILITY: string         = 'login.accessibility';
  // static CHOOSE_PROFILE: string        = 'login.chooseProfile';
  // static INVITATION: string            = 'login.invitation';
  // static GROUP_INVITATION: string      = 'login.groupInvitation';
  // static REQUEST_PKI_DN_UPDATE: string = "login.requestPkiDnUpdate";
  // static UPDATE_PKI_DN: string         = 'login.updatePkiDN';

  // static HOME_ROOT: string                  = 'home';
  // static ABOUT: string                      = 'home.about';
  // static HELP: string                       = 'home.help';
  // static LOADING: string                    = 'home.loading';
  // static MY_DASHBOARD: string               = 'home.dashboard';
  // static USER_PROFILE: string               = 'home.userProfile';
  // static USER_PROFILE_EDIT_GEN_INFO: string = 'home.userProfile.editGenInfoUserProfile';

  // static ABI_SHELL: string                                 = 'home.abi';
  // static ABI_SEARCH: string                                = 'home.abi.search';
  // static ABI_SEARCH_HELP: string                           = 'home.abi.search.help';
  // static ABI_PREFERRED_PRODUCT: string                     = 'home.abi.search.preferredProduct';
  // static ABI_PRODUCT_COMPARISON: string                    = 'home.abi.search.productComparison';
  // static ABI_PRODUCT_DETAILS: string                       = 'home.abi.search.productDetails';
  // static ABI_PRODUCTS_IN_SAME_PRODUCT_GROUP: string        = 'home.abi.search.sameProductGroup';
  // static ABI_PRODUCTS_IN_SUBSTITUTE_PRODUCT_GROUP: string  = 'home.abi.search.substituteProductGroup';
  // static ABI_PRODUCTS_SITE_CATALOG_ITEMS: string           = 'home.abi.search.siteCatalogItems';
  // static ABI_PRODUCTS_SITE_EQUIPMENT_RECORDS: string       = 'home.abi.search.siteEquipmentRecords';

  // static ADMIN_SHELL: string                     = 'home.admin';
  // static ADMIN_PERMISSION_MNG: string            = 'home.admin.permissionMng';
  // static ADMIN_PERMISSION_CREATE: string         = 'home.admin.permissionMng.createPermission';
  // static ADMIN_PERMISSION_EDIT_ELEMENTS: string  = 'home.admin.permissionMng.editElementsPermission';
  // static ADMIN_PERMISSION_EDIT_ENDPOINTS: string = 'home.admin.permissionMng.editEndpointsPermission';
  // static ADMIN_PERMISSION_EDIT_GEN_INFO: string  = 'home.admin.permissionMng.editGenInfoPermission';
  // static ADMIN_PERMISSION_EDIT_STATES: string    = 'home.admin.permissionMng.editStatesPermission';
  // static ADMIN_PERMISSION_VIEW: string           = 'home.admin.permissionMng.viewPermission';
  // static ADMIN_ELEMENT_MNG: string               = 'home.admin.permissionMng.elementMng';
  // static ADMIN_ENDPOINT_MNG: string              = 'home.admin.permissionMng.endpointMng';
  // static ADMIN_STATE_MNG: string                 = 'home.admin.permissionMng.stateMng';
  // static ADMIN_ROLE_MNG: string                  = 'home.admin.roleMng';
  // static ADMIN_ROLE_CREATE: string               = 'home.admin.roleMng.createRole';
  // static ADMIN_ROLE_EDIT_GEN_INFO: string        = 'home.admin.roleMng.editGenInfoRole';
  // static ADMIN_ROLE_EDIT_PERMS: string           = 'home.admin.roleMng.editPermsRole';
  // static ADMIN_ROLE_VIEW: string                 = 'home.admin.roleMng.viewRole';
  // static ADMIN_ORG_MNG: string                   = 'home.orgMng';

  // static ADMIN_USER_PROFILE_MNG: string             = 'home.admin.userProfileMng';
  // static ADMIN_USER_PROFILE_EDIT_GEN_INFO: string   = 'home.admin.userProfileMng.viewUserProfile.editGenInfoUserProfile';
  // static ADMIN_USER_PROFILE_EDIT_PERMS: string      = 'home.admin.userProfileMng.viewUserProfile.editPermsUserProfile';
  // static ADMIN_USER_PROFILE_EDIT_ROLES: string      = 'home.admin.userProfileMng.viewUserProfile.editRolesUserProfile';
  // static ADMIN_USER_PROFILE_EDIT_STATUS: string      = 'home.admin.userProfileMng.viewUserProfile.editStatus';
  // static ADMIN_USER_PROFILE_VIEW: string            = 'home.admin.userProfileMng.viewUserProfile';
  // static ADMIN_USER_PROFILE_EDIT_ACCESS: string     = 'home.admin.userProfileMng.viewUserProfile.editAccess';
  // static ADMIN_USER_PROFILE_EDIT_INV_INFO: string    = 'home.admin.userProfileMng.viewUserProfile.editInvitationInfo';

  // static ADMIN_USER_PROFILE_CREATE: string          = 'home.admin.userProfileMng.createProfile';
  // static ADMIN_USER_PROFILE_ACCESS: string           = 'home.admin.userProfileMng.createProfile.access';
  // static ADMIN_USER_PROFILE_ASSIGN_ROLES: string    = 'home.admin.userProfileMng.createProfile.access.roles';
  // static ADMIN_USER_PROFILE_CREATE_CONFIRM: string  = 'home.admin.userProfileMng.createProfile.access.roles.confirm';

  // static ADMIN_GROUP_INVITATION_CREATE: string          = 'home.admin.userProfileMng.createInvitation';
  // static ADMIN_GROUP_INVITATION_ACCESS: string           = 'home.admin.userProfileMng.createInvitation.access';
  // static ADMIN_GROUP_INVITATION_ASSIGN_ROLES: string    = 'home.admin.userProfileMng.createInvitation.access.roles';
  // static ADMIN_GROUP_INVITATION_CREATE_CONFIRM: string  = 'home.admin.userProfileMng.createInvitation.access.roles.confirm';
  // static ADMIN_GROUP_INVITATION_VIEW_URL: string        = 'home.admin.userProfileMng.viewGroupInvitationUrl';
  // static ADMIN_GROUP_INVITATION_VIEW : string           = 'home.admin.userProfileMng.viewGroupInvitation';

  // static ADMIN_GROUP_INVITATION_EDIT_INFO: string       = 'home.admin.userProfileMng.viewGroupInvitation.editGroupInvitationInfo';
  // static ADMIN_GROUP_INVITATION_EDIT_ACCESS: string      = 'home.admin.userProfileMng.viewGroupInvitation.editGroupInvitationAccess';
  // static ADMIN_GROUP_INVITATION_EDIT_ROLES: string      = 'home.admin.userProfileMng.viewGroupInvitation.editGroupInvitationRoles';
  // static ADMIN_GROUP_INVITATION_VIEW_PROFILE: string    = 'home.admin.userProfileMng.viewGroupInvitation.viewProfile';

  // static EQUIP_SHELL: string                  = 'home.equipment';
  // static EQUIP_RECORD_SEARCH: string          = 'home.equipment.record';
  // static EQUIP_RECORD_DATA_MANAGEMENT: string = 'home.equipment.recordDataManagement';
  // static EQUIP_RECORD_DETAILS: string         = 'home.equipment.record.details';

  // static EQUIP_REQUEST_SHELL: string       = 'home.equipment.request';
  // static EQUIP_REQUEST_MY_REQUESTS: string = 'home.equipment.request.myRequests';
  // static EQUIP_REQUEST_VIEW: string        = 'home.equipment.request.myRequests.view';
  // static EQUIP_REQUEST_HISTORY: string     = 'home.equipment.request.myRequests.view.history';
  // static EQUIP_REQUEST_ATTACHMENTS: string = 'home.equipment.request.myRequests.view.attachments';
  // static EQUIP_REQUEST_NOTES: string       = 'home.equipment.request.myRequests.view.notes';
  // static EQUIP_REQUEST_PRINT: string       = 'home.equipment.request.myRequests.view.print';

  // static JMLFDC_ADMIN_SHELL: string = 'home.jmlfdcAdmin';
  // static MANAGE_SERVICE_PROVIDERS: string = 'home.jmlfdcAdmin.viewServiceProviders';

  // static ORG_MNG: string   = 'home.organization.management';
  // static ORG_SHELL: string = 'home.organization';
  // static ORG_VIEW: string  = 'home.organization.view';

  // static ABI_STAGING_VIEW: string = 'home.jmlfdcAdmin.abiStaging.viewAbiStaging';
  // static ABI_STAGING_EDIT: string = "home.jmlfdcAdmin.abiStaging.viewAbiStaging.editAbiStaging";
  // static ABI_STAGING_SHELL: string = 'home.jmlfdcAdmin.abiStaging';
  // static ABI_STAGING_MERGE_BY_MMC: string = "home.jmlfdcAdmin.abiStaging.mergeByMmc";
  // static ABI_STAGING_MERGE_RECORDS: string = "home.jmlfdcAdmin.abiStaging.mergeRecords";
  // static ABI_STAGING_SET_UNSPSC: string = "home.jmlfdcAdmin.abiStaging.viewAbiStaging.setUnspsc";
  // static ABI_STAGING_SET_ATTRS: string = "home.jmlfdcAdmin.abiStaging.viewAbiStaging.setAttributes";
  // static ABI_STAGING_MANAGE_MERGED_RECS: string = "home.jmlfdcAdmin.abiStaging.manageMergedRecords";
  // static ABI_STAGING_MOVE_TO_PRODUCTION: string = 'home.jmlfdcAdmin.abiStaging.abiMoveToProduction';
  // static ABI_STAGING_DELTA_VIEW: string = 'home.jmlfdcAdmin.abiStaging.viewAbiDelta';

  // static EQUIPMENT_TESTING: string = 'home.jmlfdcAdmin.equipmentTesting';
  // static APP_HISTORY_VIEW: string = 'home.jmlfdcAdmin.viewAppHistory';

  // static NOTIFICATIONS_VIEW: string = 'home.jmlfdcAdmin.viewNotifications';
  // static NOTIFICATIONS_ADD: string = 'home.jmlfdcAdmin.viewNotifications.createNotification';
  // static NOTIFICATIONS_EDIT: string = 'home.jmlfdcAdmin.viewNotifications.editNotification';

  // static ORDER: string                = 'home.order';
  // static ORDER_BUYER: string          = 'home.order.buyer';
  // static ORDER_CART: string           = 'home.order.cart';
  // static ORDER_CART_CHECKOUT: string  = 'home.order.cart.checkout';
  // static ORDER_CART_SUMMARY: string   = 'home.order.cart.summary';
  // static ORDER_VIEW: string           = 'home.order.view';
  // static ORDER_RECEIPT: string        = 'home.order.receipts';
  // static ORDER_SELLER: string         = 'home.order.seller';
  // static ORDER_FULFILLMENT: string    = 'home.order.fulfillment';

  // static GENERATE_PICKLIST: string    = 'home.order.generatePicklist';
  // static CONFIRM_PICKLIST: string     = 'home.order.confirmPicklist';
  // static COFFEE: string               = 'home.coffee';


  constructor() {}

}
