
export class ApiConstants {

    // Note: Keep these lines sorted to avoid merge conflicts
    public static ABI_API: string = 'abi/';
    public static ABI_DELTA_API: string = 'abi/delta/';
    public static ABI_PRODUCTION_API: string = 'production/';
    public static ABI_SITE_CATALOG_API: string = 'sitecatalog/';
    public static ABI_STAGING_API: string = 'abi/staging/';
    public static ABI_STAGING_JOIN_API: string = 'abi/staging/join/';
    public static ABI_STAGING_LOOKUP_API: string = 'abi/staging/lookup/';
    public static ABI_TASK_HISTORY_MANAGER_API: string = 'abi/taskHistory/';
    public static ABI_TAXONOMY_API: string = 'abi/taxonomy/';
    public static ABI_STAGING_MOVE_RECORDS_API: string = 'abi/staging/moveRecords/';
    public static CLIENT_ID: string = 'dmles';
    public static COMMUNICATIONS_ADMIN_API: string = 'communicationsAdmin/';
    public static DMLES_TOKEN: string = 'dmles-token';
    public static DMLES_USER: string = 'dmles-user';
    public static EQUIPMENT_API: string = 'equipment/';
    public static FILE_MANAGER_API: string = 'fileManager/';
    public static FINANCE_ADMIN_API: string = 'financeAdmin/';
    public static INVENTORY_API: string = 'inventory/';
    public static ORG_API: string = 'organization/';
    public static CART_API: string = 'cart/';
    public static ORDER_API: string = 'order/';
    public static BUYER_API: string = 'buyer/';
    public static SELLER_API: string = 'seller/';
    public static ROLE_API: string = 'role/';
    public static SERVICE_PROVIDER_API: string = 'organization/';
    public static SITE_API: string = 'site/';
    public static SYSTEM_API: string = 'system/';
    public static SYSTEM_APP_HISTORY: string = 'appHistory/';
    public static SYSTEM_NOTIFICATION_API: string = 'systemNotification/';
    public static UNREGISTERED_USER: string = 'UnregisteredUser';
    public static USER_API: string = 'user/';

}
