
export class ServiceLongName {

    static AIR_FORCE_LONG_NAME: string = 'Air Force';
    static ARMY_LONG_NAME: string = 'Army';
    static NAVY_LONG_NAME: string = 'Navy';
    constructor() {}
}
