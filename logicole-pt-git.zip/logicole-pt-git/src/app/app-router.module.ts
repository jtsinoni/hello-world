import {Injectable, NgModule} from '@angular/core';
import {RootModule, UIRouterModule} from '@uirouter/angular';
import {uiRouterConfigFn} from './router-config';
import {HomeStates} from './home/home-states';
import {LoginStates} from './login/login-states';

export const appRoutes: RootModule = {
  states: [
    {name: LoginStates.LOGIN_ROOT.name + '.**', url: LoginStates.LOGIN_ROOT.url,
      loadChildren: 'app/login/login-shell.module#LoginShellModule'},  // Using load children lets you add a new ui-view
    {name: HomeStates.HOME_ROOT.name + '.**', url: HomeStates.HOME_ROOT.url,
      loadChildren: 'app/home/home.module#HomeModule'}  // Using load children lets you add a new ui-view
  ],
  config: uiRouterConfigFn,
  useHash: false
};

@NgModule({
imports: [UIRouterModule.forRoot(appRoutes)],
exports: [UIRouterModule]
})
export class AppRouterModule {

}
