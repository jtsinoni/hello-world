import {BrowserModule} from '@angular/platform-browser';
import {NgModule, Injector, NgModuleFactoryLoader, SystemJsNgModuleLoader} from '@angular/core';
import {FormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';

import {AppComponent} from './app.component';
import {setAppInjector} from './app.injector';
import {AppRouterModule} from './app-router.module';
import {ServicesModule} from './services/services.module';
import {CommonComponentsModule} from './common-components/common-components.module';
import {PipesModule} from './pipes/pipes.module';
import {BrowserAnimationsModule, NoopAnimationsModule} from '@angular/platform-browser/animations';
import {ToastrModule} from 'ngx-toastr';
import {DirectivesModule} from './directives/directives.module';
import {LoginShellModule} from './login/login-shell.module';


@NgModule({
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRouterModule,
    FormsModule,
    BrowserAnimationsModule,
    NoopAnimationsModule,
    ServicesModule.forRoot(),
    CommonComponentsModule.forRoot(),
    PipesModule.forRoot(),
    DirectivesModule,
    LoginShellModule,
    ToastrModule.forRoot({
       closeButton: true,
       maxOpened: 5,
       preventDuplicates: true,
       progressAnimation: 'increasing',
       progressBar: true,
       timeOut: 10000
     }),

  ],
  declarations: [
    AppComponent
  ],
  exports: [
    BrowserAnimationsModule,
    NoopAnimationsModule,
    ToastrModule,
    DirectivesModule
  ],
  providers: [{ provide: NgModuleFactoryLoader, useClass: SystemJsNgModuleLoader }],
  bootstrap: [AppComponent],
})
export class AppModule {
  constructor(injector: Injector) {
    setAppInjector(injector);
  }
}
