import {TestBed, async} from '@angular/core/testing';
import {AppComponent} from './app.component';
import {HomeFooterComponent} from './home/home-footer/home-footer.component';
import {HomeHeaderComponent} from './home/home-header/home-header.component';
import {NO_ERRORS_SCHEMA} from '@angular/core';
import {LoggerService} from './services/logger/logger.service';
import {PipesModule} from './pipes/pipes.module';
import {UtilService} from './services/util.service';
import {CurrencyPipe} from '@angular/common';
import {UIRouter} from '@uirouter/core/lib';

describe('AppComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [PipesModule],
      declarations: [
        AppComponent, HomeFooterComponent,
        HomeHeaderComponent
      ],
      providers: [LoggerService, UtilService, CurrencyPipe, {provide: UIRouter, useClass:
        class {mockUIRouter = new UIRouter(); }}],
      schemas: [NO_ERRORS_SCHEMA],
    }).compileComponents();
  }));
  it('should create the app', async(() => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  }));
});
