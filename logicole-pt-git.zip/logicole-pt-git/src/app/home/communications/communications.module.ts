import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ComponentsModule } from './components/components.module';
import { ViewsModule } from './views/views.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MainCommsViewModule } from './views/main-comms-view/main-comms-view.module';
import { CommsServicesModule } from './services/comms-services.module';

@NgModule({
  imports: [
    CommonModule,
    ComponentsModule,
    ViewsModule,
    FormsModule,
    ReactiveFormsModule,
    MainCommsViewModule,
    CommsServicesModule,
  ],
  declarations: [
  ]
})
export class CommunicationsModule { }
