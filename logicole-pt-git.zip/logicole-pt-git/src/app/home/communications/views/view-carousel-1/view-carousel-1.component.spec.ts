import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {NO_ERRORS_SCHEMA} from '@angular/core';

import { ViewCarousel1Component } from './view-carousel-1.component';

describe('ViewCarousel1Component', () => {
  let component: ViewCarousel1Component;
  let fixture: ComponentFixture<ViewCarousel1Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewCarousel1Component ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewCarousel1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
