import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-carousel-1',
  templateUrl: './view-carousel-1.component.html',
  styleUrls: ['./view-carousel-1.component.scss']
})
export class ViewCarousel1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
