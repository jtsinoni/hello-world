import {Ng2StateDeclaration} from '@uirouter/angular';
import {RouteConstants} from '../../../../constants/route.constants';
import {MainCommsViewComponent} from './main-comms-view.component';

export class CommsConfigurationsStates {

  static COMMUNICATIONS_CONFIGURATION_VIEW: Ng2StateDeclaration = {
    url: RouteConstants.COMMUNICATIONS_CONFIGURATIONS.url,
    name: RouteConstants.COMMUNICATIONS_CONFIGURATIONS.name,
    component: MainCommsViewComponent, data: {'route': RouteConstants.COMMUNICATIONS_CONFIGURATIONS}
  };

}
