import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { ViewBsmComponent } from '../view-bsm/view-bsm.component';
import { ViewCarousel1Component } from '../view-carousel-1/view-carousel-1.component';
import { ViewCarousel2Component } from '../view-carousel-2/view-carousel-2.component';
import { ViewDeamsComponent } from '../view-deams/view-deams.component';
import { ViewDfasComponent } from '../view-dfas/view-dfas.component';
import { ViewFastdataComponent } from '../view-fastdata/view-fastdata.component';
import { ViewFmsComponent } from '../view-fms/view-fms.component';
import { ViewFoaExcessComponent } from '../view-foa-excess/view-foa-excess.component';
import { ViewGafsComponent } from '../view-gafs/view-gafs.component';
import { ViewGfebsComponent } from '../view-gfebs/view-gfebs.component';
import { ViewPouComponent } from '../view-pou/view-pou.component';
import { ViewSabrsComponent } from '../view-sabrs/view-sabrs.component';
import { ViewSpsComponent } from '../view-sps/view-sps.component';
import { CommunicationsConfigModule } from '../../components/communications-config/communications-config.module';
import { MainCommsViewComponent } from './main-comms-view.component';
import { ComponentsModule } from '../../components/components.module';

import { MainCommsViewsRouterModule } from './main-comms-view.router';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    CommunicationsConfigModule,
    MainCommsViewsRouterModule,
  ],
  declarations: [
    ViewBsmComponent,
    ViewCarousel1Component,
    ViewCarousel2Component,
    ViewDeamsComponent,
    ViewDfasComponent,
    ViewDfasComponent,
    ViewFastdataComponent,
    ViewFmsComponent,
    ViewFoaExcessComponent,
    ViewGafsComponent,
    ViewGfebsComponent,
    ViewPouComponent,
    ViewSabrsComponent,
    ViewSpsComponent,
    MainCommsViewComponent,
  ],
  exports: [
    ViewBsmComponent,
    ViewCarousel1Component,
    ViewCarousel2Component,
    ViewDeamsComponent,
    ViewDfasComponent,
    ViewDfasComponent,
    ViewFastdataComponent,
    ViewFmsComponent,
    ViewFoaExcessComponent,
    ViewGafsComponent,
    ViewGfebsComponent,
    ViewPouComponent,
    ViewSabrsComponent,
    ViewSpsComponent,
    MainCommsViewComponent,
    MainCommsViewsRouterModule,
  ]
})
export class MainCommsViewModule { }
