import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginService } from '../../../../services/login.service';
import { MainCommsViewComponent } from './main-comms-view.component';
import { RouteConstants } from '../../../../constants/route.constants';

import { RootModule, UIRouterModule } from '@uirouter/angular';
import { CommsConfigurationsStates } from './main-comms-view-states';

const mainCommsViewsRoutes: RootModule = {

  states: [
    CommsConfigurationsStates.COMMUNICATIONS_CONFIGURATION_VIEW
  ]
};

@NgModule({
  imports: [UIRouterModule.forChild(mainCommsViewsRoutes)],
  exports: [UIRouterModule]
})
  export class MainCommsViewsRouterModule {

  }


/*
const mainCommsViewsRoutes: Routes = [
//    {
//      path: '',
//      component:  MainCommsViewComponent,
//      data: {breadcrumb: 'Configurations'},
//      canActivate: [LoginService]
//    },
//    {
//      path: '',
//      redirectTo: RouteConstants.COMMUNICATIONS_CONFIGURATIONS.route
//    }
  ];

  @NgModule({
    imports: [RouterModule.forChild(mainCommsViewsRoutes)],
    exports: [RouterModule]
  })

  export class MainCommsViewsRouterModule {

  }
  */
