import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-main-comms-view',
  templateUrl: './main-comms-view.component.html',
  styleUrls: ['./main-comms-view.component.scss']
})
export class MainCommsViewComponent implements OnInit {

  public activeComponent: string;

  constructor() { }

  ngOnInit() {
  }

  public showComponent(component: string): void {
    this.activeComponent = component;
    console.log('component is now : ' + this.activeComponent);
  }

  public isActive(component: string): boolean {
    return (this.activeComponent === component);
  }
}
