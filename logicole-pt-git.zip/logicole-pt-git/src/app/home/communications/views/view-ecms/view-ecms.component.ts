import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-ecms',
  templateUrl: './view-ecms.component.html',
  styleUrls: ['./view-ecms.component.scss']
})
export class ViewEcmsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
