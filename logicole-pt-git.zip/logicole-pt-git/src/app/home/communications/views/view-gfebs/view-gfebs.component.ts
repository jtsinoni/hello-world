import { Component, OnInit } from '@angular/core';
import { LabelValue } from '../../components/communications-config/models/label-value';

@Component({
  selector: 'app-view-gfebs',
  templateUrl: './view-gfebs.component.html',
  styleUrls: ['./view-gfebs.component.scss']
})
export class ViewGfebsComponent implements OnInit {
  public gfebsLabelValues: LabelValue[];

  constructor() {
    this.createGfebsLabelValues();
  }

  ngOnInit() {
  }

  public createGfebsLabelValues(): void {
    this.gfebsLabelValues = new Array<LabelValue>();
    this.gfebsLabelValues.push({
      label: 'Next Block Number:',
      value: '1'
    });
    this.gfebsLabelValues.push({
      label: '2090:',
      value: 'C77'
    });
    this.gfebsLabelValues.push({
      label: '2091:',
      value: 'A553'
    });
    this.gfebsLabelValues.push({
      label: '2064:',
      value: 'B326'
    });
  }

}
