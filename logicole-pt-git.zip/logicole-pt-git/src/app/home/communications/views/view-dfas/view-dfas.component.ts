import { Component, OnInit } from '@angular/core';
import { LabelValue } from '../../components/communications-config/models/label-value';

@Component({
  selector: 'app-view-dfas',
  templateUrl: './view-dfas.component.html',
  styleUrls: ['./view-dfas.component.scss']
})
export class ViewDfasComponent implements OnInit {
  public dfasLabelValues: LabelValue[];
  constructor() {
    this.createDfasLabelValues();
   }

  ngOnInit() {
  }

  public createDfasLabelValues(): void {
    this.dfasLabelValues = new Array<LabelValue>();
    this.dfasLabelValues.push({
      label: 'DLA Sequence Number:',
      value: '409'
    });
  }

}
