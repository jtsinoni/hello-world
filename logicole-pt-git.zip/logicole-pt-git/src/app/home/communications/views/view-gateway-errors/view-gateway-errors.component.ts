import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-gateway-errors',
  templateUrl: './view-gateway-errors.component.html',
  styleUrls: ['./view-gateway-errors.component.scss']
})
export class ViewGatewayErrorsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
