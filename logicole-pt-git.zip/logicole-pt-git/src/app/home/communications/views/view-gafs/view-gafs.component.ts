/*
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-gafs',
  templateUrl: './view-gafs.component.html',
  styleUrls: ['./view-gafs.component.scss']
})
export class ViewGafsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
*/


import { Component, OnInit } from '@angular/core';
import { LabelValue } from '../../components/communications-config/models/label-value';

@Component({
  selector: 'app-view-gafs',
  templateUrl: './view-gafs.component.html',
  styleUrls: ['./view-gafs.component.scss']
})
export class ViewGafsComponent implements OnInit {
  public gafsLabelValues: LabelValue[];

  constructor() {
    this.createGafsLabelValues();
  }

  ngOnInit() {

  }

  public createGafsLabelValues(): void {
    this.gafsLabelValues = new Array<LabelValue>();
    this.gafsLabelValues.push({
      label: 'Next GAFS Sequence Number',
      value: '180'
    });
  }

}
