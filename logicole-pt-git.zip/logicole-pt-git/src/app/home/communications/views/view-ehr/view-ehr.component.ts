import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-ehr',
  templateUrl: './view-ehr.component.html',
  styleUrls: ['./view-ehr.component.scss']
})
export class ViewEhrComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
