import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-foa-excess',
  templateUrl: './view-foa-excess.component.html',
  styleUrls: ['./view-foa-excess.component.scss']
})
export class ViewFoaExcessComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
