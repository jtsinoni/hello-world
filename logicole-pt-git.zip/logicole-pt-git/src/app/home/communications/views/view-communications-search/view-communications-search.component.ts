import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-communications-search',
  templateUrl: './view-communications-search.component.html',
  styleUrls: ['./view-communications-search.component.css']
})
export class ViewCommunicationsSearchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
