import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'view-communications-outbound-config',
  templateUrl: './view-communications-outbound-config.component.html',
  styleUrls: ['./view-communications-outbound-config.component.scss']
})
export class ViewCommunicationsOutboundConfigComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
