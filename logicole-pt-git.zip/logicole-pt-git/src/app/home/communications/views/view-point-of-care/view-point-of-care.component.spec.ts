import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewPointOfCareComponent } from './view-point-of-care.component';

describe('ViewPointOfCareComponent', () => {
  let component: ViewPointOfCareComponent;
  let fixture: ComponentFixture<ViewPointOfCareComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewPointOfCareComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewPointOfCareComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
