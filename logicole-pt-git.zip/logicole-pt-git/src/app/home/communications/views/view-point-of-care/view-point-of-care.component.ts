import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-point-of-care',
  templateUrl: './view-point-of-care.component.html',
  styleUrls: ['./view-point-of-care.component.scss']
})
export class ViewPointOfCareComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
