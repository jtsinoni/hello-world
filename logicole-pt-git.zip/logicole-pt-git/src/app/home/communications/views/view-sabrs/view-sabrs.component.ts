import { Component, OnInit } from '@angular/core';
import { LabelValue } from '../../components/communications-config/models/label-value';

@Component({
  selector: 'app-view-sabrs',
  templateUrl: './view-sabrs.component.html',
  styleUrls: ['./view-sabrs.component.scss']
})
export class ViewSabrsComponent implements OnInit {
  public sabrsLabelValues: LabelValue[];

  constructor() {
    this.createSabrsLabelValues();
  }

  ngOnInit() {
  }

  public createSabrsLabelValues(): void {
    this.sabrsLabelValues = new Array<LabelValue>();
    this.sabrsLabelValues.push({
      label: 'Next 821 Block Number',
      value: 'D00063'
    });
    this.sabrsLabelValues.push({
      label: 'Next 861 Block Number',
      value: 'D00101'
    });
  }

}
