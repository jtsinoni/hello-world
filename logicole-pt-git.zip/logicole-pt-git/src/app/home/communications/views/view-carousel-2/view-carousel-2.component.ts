import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-carousel-2',
  templateUrl: './view-carousel-2.component.html',
  styleUrls: ['./view-carousel-2.component.scss']
})
export class ViewCarousel2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
