import { Component, OnInit } from '@angular/core';
import { LabelValue } from '../../components/communications-config/models/label-value';

@Component({
  selector: 'app-view-deams',
  templateUrl: './view-deams.component.html',
  styleUrls: ['./view-deams.component.scss']
})
export class ViewDeamsComponent implements OnInit {
  public deamsLabelValues: LabelValue[];

  constructor() {
    this.createDeamsLabelValues();
  }

  ngOnInit() {
  }

  public createDeamsLabelValues(): void {
    this.deamsLabelValues = new Array<LabelValue>();
    this.deamsLabelValues.push({
      label: 'Next Block Number',
      value: '1'
    });
    this.deamsLabelValues.push({
      label: '2090',
      value: 'C77'
    });
    this.deamsLabelValues.push({
      label: '2091',
      value: 'A553'
    });
    this.deamsLabelValues.push({
      label: '2064',
      value: 'B326'
    });
  }

}
