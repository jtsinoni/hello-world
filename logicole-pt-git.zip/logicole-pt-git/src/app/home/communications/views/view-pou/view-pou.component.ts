import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-pou',
  templateUrl: './view-pou.component.html',
  styleUrls: ['./view-pou.component.scss']
})
export class ViewPouComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
