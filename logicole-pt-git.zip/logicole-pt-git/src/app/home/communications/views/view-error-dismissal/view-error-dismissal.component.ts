import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lc-view-error-dismissal',
  templateUrl: './view-error-dismissal.component.html',
  styleUrls: ['./view-error-dismissal.component.scss']
})
export class ViewErrorDismissalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
