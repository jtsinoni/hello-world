import { Component, OnInit } from '@angular/core';
import { LabelValue } from '../../components/communications-config/models/label-value';

@Component({
  selector: 'app-view-bsm',
  templateUrl: './view-bsm.component.html',
  styleUrls: ['./view-bsm.component.scss']
})
export class ViewBsmComponent implements OnInit {
  public bsmLabelValues: LabelValue[];

  constructor() {
    this.createBsmLabelValues();
  }

  ngOnInit() {
  }

  public createBsmLabelValues(): void {
    this.bsmLabelValues = new Array<LabelValue>();
    this.bsmLabelValues.push({
      label: 'DLA Sequence Number',
      value: '409'
    });
  }

}
