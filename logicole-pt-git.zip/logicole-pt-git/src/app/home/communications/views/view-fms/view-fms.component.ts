import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-fms',
  templateUrl: './view-fms.component.html',
  styleUrls: ['./view-fms.component.scss']
})
export class ViewFmsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
