import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-fastdata',
  templateUrl: './view-fastdata.component.html',
  styleUrls: ['./view-fastdata.component.scss']
})
export class ViewFastdataComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
