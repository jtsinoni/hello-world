import { Ng2StateDeclaration } from '@uirouter/angular';
import { RouteConstants } from '../../constants/route.constants';

export class CommunicationsStates {
  static COMMUNICATIONS_GATEWAY_ERRORS_MODULE: Ng2StateDeclaration = {
    name:  RouteConstants.COMMUNICATIONS_GATEWAY_ERRORS.name + '.**', url: RouteConstants.COMMUNICATIONS_GATEWAY_ERRORS.url,
    loadChildren: 'app/home/communications/components/communications-gateway-errors/communications-gateway-errors.module#CommunicationsGatewayErrorsModule'
  };
  static COMMUNICATIONS_SEARCH_MODULE: Ng2StateDeclaration = {
    name:  RouteConstants.COMMUNICATIONS_SEARCH.name + '.**', url: RouteConstants.COMMUNICATIONS_SEARCH.url,
    loadChildren: 'app/home/communications/components/communications-search/communications-search.module#CommunicationsSearchModule'
  };
  static COMMUNICATIONS_RESUBMIT_MODULE: Ng2StateDeclaration = {
    name:  RouteConstants.COMMUNICATIONS_RESUBMIT.name + '.**', url: RouteConstants.COMMUNICATIONS_RESUBMIT.url,
    loadChildren: 'app/home/communications/components/communications-resubmit/communications-resubmit.module#CommunicationsResubmitModule'
  };
  static COMMUNICATIONS_FINANCIAL_RESUBMIT_MODULE: Ng2StateDeclaration = {
    name:  RouteConstants.COMMUNICATIONS_FINANCIAL_RESUBMIT.name + '.**', url: RouteConstants.COMMUNICATIONS_FINANCIAL_RESUBMIT.url,
    loadChildren: 'app/home/communications/components/communications-financial-resubmit/communications-financial-resubmit.module#CommunicationsFinancialResubmitModule'
  };
  static COMMUNICATIONS_ERROR_DISMISSAL_MODULE: Ng2StateDeclaration = {
    name:  RouteConstants.COMMUNICATIONS_ERROR_DISMISSAL.name + '.**', url: RouteConstants.COMMUNICATIONS_ERROR_DISMISSAL.url,
    loadChildren: 'app/home/communications/components/comms-error-dismissal/comms-error-dismissal.module#CommsErrorDismissalModule'
  };
  static COMMUNICATIONS_EHR_MODULE: Ng2StateDeclaration = {
    name:  RouteConstants.COMMUNICATIONS_EHR.name + '.**', url: RouteConstants.COMMUNICATIONS_EHR.url,
    loadChildren: 'app/home/communications/components/comms-ehr/comms-ehr.module#CommsEhrModule'
  };
  static COMMUNICATIONS_ECMS_MODULE: Ng2StateDeclaration = {
    name:  RouteConstants.COMMUNICATIONS_ECMS.name + '.**', url: RouteConstants.COMMUNICATIONS_ECMS.url,
    loadChildren: 'app/home/communications/components/comms-ecms/comms-ecms.module#CommsEcmsModule'
  };
  static COMMUNICATIONS_POINT_OF_CARE_MODULE: Ng2StateDeclaration = {
    name:  RouteConstants.COMMUNICATIONS_POINT_OF_CARE.name + '.**', url: RouteConstants.COMMUNICATIONS_POINT_OF_CARE.url,
    loadChildren: 'app/home/communications/components/comms-point-of-care/comms-point-of-care.module#CommsPointOfCareModule'
  };
  static COMMUNICATIONS_OUTBOUND_CONFIG_MODULE: Ng2StateDeclaration = {
    name:  RouteConstants.COMMUNICATIONS_OUTBOUND_CONFIG.name + '.**', url: RouteConstants.COMMUNICATIONS_OUTBOUND_CONFIG.url,
    loadChildren: 'app/home/communications/components/communications-outbound-config/communications-outbound-config.module#CommunicationsOutboundConfigModule'
  };
  static COMMUNICATIONS_CONFIGURATION_MODULE: Ng2StateDeclaration = {
    name:  RouteConstants.COMMUNICATIONS_CONFIGURATIONS.name + '.**', url: RouteConstants.COMMUNICATIONS_CONFIGURATIONS.url,
    loadChildren: 'app/home/communications/views/main-comms-view/main-comms-view.module#MainCommsViewModule'
  };

}
