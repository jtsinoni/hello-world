import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SearchResultModelService } from './communications-record-detail.service';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [],
  providers: [
    SearchResultModelService,
  ]
})
export class CommunicationsRecordDetailServicesModule { }
