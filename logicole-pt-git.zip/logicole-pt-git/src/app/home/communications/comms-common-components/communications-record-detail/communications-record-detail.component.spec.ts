import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {NO_ERRORS_SCHEMA} from '@angular/core';

import { FormBuilder, FormGroup } from '@angular/forms';
import {RouterTestingModule} from '@angular/router/testing';
import {HttpTestModule} from '../../../../common-components/test/http-test.module';
import {ToastrModule} from 'ngx-toastr';
import {NavigationTestModule} from '../../../../common-components/test/navigation-test/navigation-test.module';

import {LoggerService} from '../../../../services/logger/logger.service';
import {PermissionService} from '../../../../services/permission.service';
import {LoginService} from '../../../../services/login.service';
import {NotificationService} from '../../../../services/notification.service';
import {ProfileApiService} from '../../../../services/profile-api.service';
import {CommonComponentsModule} from '../../../../common-components/common-components.module';

import { CommunicationsRecordDetailComponent } from './communications-record-detail.component';
import { SearchResultModelService } from './services/communications-record-detail.service';
import { StateNavigationService } from '../../../../../app/services/state-navigation.service';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommsUtilityService } from '../../services/comms-utility.service';
import { CommunicationsSearchResult } from '../../comms-common-models/communications-search-result';
import { IcommunicationsSearchResult } from '../../comms-common-models/icommunications-search-result';

export class SearchResultModelServiceMock {

  constructor() {
  }

  getSelectedResultRecord(): any {
    return     {
      'id': '333b',
      'callNumber': '0062',
      'method': '',
      'forms': '',
      'auditDate': '10/18/2017 11:03:26 AM',
      'PV_STATUS_SERIAL': '2',
      'PROCESS_CD_SERIAL': '54',
      'contractNumber': 'SPE2DH17D0003',
      'DTL_AUDIT_SERIAL': '861877',
      'PROCESS_TEXT': 'FILE WAS SUCCESSFULLY FORMATTED.',
      'PROCESS_CD': 'FMTGOOD',
      'direction': 'INBOUND',
      'transactionTypeTpcode': 'WAFHTPE856N',
      'transactionTypeExtension': '',
      'inboundFilename': 'DAASCEDIINB.180276',
      'sosCode': '',
      'HEAD_AUDIT_SERIAL': '323239',
      'resubmitIndicator': 'N',
      'userId': '/C=US/O=U.S.Government/OU=DOD/OU=PKI/OU=DLA/CN=gexb.daas.dla.mil',
      'ORIG_ARCH_SERIAL': '251771',
      'applicationId': '',
      'channelId': 'EDI',
      'FMT_ARCH_SERIAL': '',
      'shipmentId': 'BAXM291Z',
      'targetFilename': '',
      'TXN_SERIAL': '0',
      'dismissErrorIndicator': 'Y',
      'dismissErrorUserId': 'e_fudd_',
      'dismissErrorDate': '10/25/2017 10:55:01 AM',
      'dismissableErrorIndicator': 'N',
    };
  }

  getTableData(): any {
    return [{
      'id': '333b',
      'callNumber': '0062',
      'method': '',
      'forms': '',
      'auditDate': '10/18/2017 11:03:26 AM',
      'PV_STATUS_SERIAL': '2',
      'PROCESS_CD_SERIAL': '54',
      'contractNumber': 'SPE2DH17D0003',
      'DTL_AUDIT_SERIAL': '861877',
      'PROCESS_TEXT': 'FILE WAS SUCCESSFULLY FORMATTED.',
      'PROCESS_CD': 'FMTGOOD',
      'direction': 'INBOUND',
      'transactionTypeTpcode': 'WAFHTPE856N',
      'transactionTypeExtension': '',
      'inboundFilename': 'DAASCEDIINB.180276',
      'sosCode': '',
      'HEAD_AUDIT_SERIAL': '323239',
      'resubmitIndicator': 'N',
      'userId': '/C=US/O=U.S.Government/OU=DOD/OU=PKI/OU=DLA/CN=gexb.daas.dla.mil',
      'ORIG_ARCH_SERIAL': '251771',
      'applicationId': '',
      'channelId': 'EDI',
      'FMT_ARCH_SERIAL': '',
      'shipmentId': 'BAXM291Z',
      'targetFilename': '',
      'TXN_SERIAL': '0',
      'dismissErrorIndicator': 'Y',
      'dismissErrorUserId': 'e_fudd_',
      'dismissErrorDate': '10/25/2017 10:55:01 AM',
      'dismissableErrorIndicator': 'N',
    }];
  }

  setSelectedResultRecord(selectedResult: CommunicationsSearchResult): void {
  }

  getBeforeImageData(): string {
    return '';
  }

  getAfterImageData(): string {
    return '';
  }

  getBeforeImageDataLength(): number {
    return 1;
  }

  getAfterImageDataLength(): number {
    return 1;
  }

  getReturnLocation(): string {
    return 'SEARCH';
  }
}

describe('CommunicationsRecordDetailComponent', () => {
  let component: CommunicationsRecordDetailComponent;
  let fixture: ComponentFixture<CommunicationsRecordDetailComponent>;

  beforeEach(async(() => {
  TestBed.configureTestingModule({
    imports: [
      CommonComponentsModule,
      FormsModule,
      ReactiveFormsModule,
      RouterTestingModule,
      HttpTestModule.forRoot(),
      ToastrModule.forRoot(),
      NavigationTestModule.forRoot()
    ],
      declarations: [ CommunicationsRecordDetailComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
      providers: [
        LoggerService,
        FormBuilder,
        {provide: SearchResultModelService, useClass: SearchResultModelServiceMock, useValue: {}},
        StateNavigationService,
        CommsUtilityService
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommunicationsRecordDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
