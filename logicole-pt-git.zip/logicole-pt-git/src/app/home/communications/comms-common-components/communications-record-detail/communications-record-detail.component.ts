import { Component, OnInit, EventEmitter, Input, Output, SimpleChanges, ViewChild } from '@angular/core';
import { CommunicationsSearchResult } from '../../comms-common-models/communications-search-result';
import { LoggerService } from '../../../../services/logger/logger.service';
import { FormBuilder, FormGroup } from '@angular/forms';

import { StateNavigationService } from '../../../../../app/services/state-navigation.service';
import { RouteConstants } from '../../../../../app/constants/route.constants';

import { SearchResultModelService } from './services/communications-record-detail.service';

import { LcButtonCallbackEvent } from '../../../../common-components/lc-table/models/lc-button-callback-event';
import { LcButtonCellComponent } from '../../../../common-components/lc-table/lc-button-cell/lc-button-cell.component';
import { NotificationService } from '../../../../services/notification.service';
import { MessageBoxComponent } from '../../../../common-components/panels/message-box/message-box.component';
import { MessageBoxConfiguration } from '../../../../models/message-box-configuration';
import { MessageBoxIcon } from '../../../../models/message-box-icon';

@Component({
    selector: 'lc-communications-record-detail',
    templateUrl: './communications-record-detail.component.html',
    styleUrls: ['./communications-record-detail.component.scss']
})
export class CommunicationsRecordDetailComponent implements OnInit {
    @ViewChild('confirmationDialog') messageBox: MessageBoxComponent;
    @Output() public goBackClicked: EventEmitter<string> = new EventEmitter();
    @Output() public dismissClicked: EventEmitter<string> = new EventEmitter();

    public currentRecord: CommunicationsSearchResult;
    public searchResults: Array<CommunicationsSearchResult>;
    public currentPageIndex: number;

    public communicationsRecordDetailForm: FormGroup;

    public showDismissButton: boolean = false;
    public showResubmitButton: boolean = false;

    public communicationsResubmitDialogTitle: string;
    public communicationsResubmitDialogMessage: string;
    public showCommunicationsResubmitDialog: boolean = false;
    public communicationsResubmitDialogContent: string;

    public financialResubmitDialogTitle: string;
    public financialResubmitDialogMessage: string;
    public showFinancialResubmitDialog: boolean = false;
    private resubmitType: string = 'Communications';

    private resubmitCallNumber: string;

    msgBoxConfig: MessageBoxConfiguration = {
        showCloseButton: false,
        showOkCancelButtons: false,
        showYesNoButtons: true,
        allowBackdropClickToClose: false,
        allowEscapeToClose: false,
        showLargeModal: true,
        icon: MessageBoxIcon.informationIcon,
    };

    constructor(private logger: LoggerService,
        private fb: FormBuilder,
        public commsRecordDetailService: SearchResultModelService,
        private navigationService: StateNavigationService,
        private notify: NotificationService) {
    }

    ngOnInit() {
        this.createForm();
        this.logger.debug(`In record-detail ngOnInit()`);
        this.currentRecord = this.commsRecordDetailService.getSelectedResultRecord();
        this.searchResults = this.commsRecordDetailService.getTableData();

        this.refreshForm();
    }

    goToParentList() {
        if (this.commsRecordDetailService.getReturnLocation() === 'DISMISSAL') {
            this.logger.debug(`GOING TO COMMUNICATIONS_ERROR_DISMISSAL...`);
            this.navigationService.navigateTo(RouteConstants.COMMUNICATIONS_ERROR_DISMISSAL);
        } else {
            this.logger.debug(`GOING TO COMMUNICATIONS_SEARCH...`);
            this.navigationService.navigateTo(RouteConstants.COMMUNICATIONS_SEARCH);
        }
    }

    private refreshForm(): void {
        this.currentPageIndex = this.findIndexOfCurrentRecord();
        this.communicationsRecordDetailForm.reset({
            callNumber: this.currentRecord.callNumber,
            method: this.currentRecord.method,
            forms: this.currentRecord.forms,
            auditDate: this.currentRecord.auditDate,
            contractNumber: this.currentRecord.contractNumber,
            processCode: this.currentRecord.processCode,
            direction: this.currentRecord.direction,
            transactionTypeTpcode: this.currentRecord.transactionTypeTpcode,
            transactionTypeExtension: this.currentRecord.transactionTypeExtension,
            inboundFilename: this.currentRecord.inboundFilename,
            sosCode: this.currentRecord.sosCode,
            resubmitIndicator: this.currentRecord.resubmitIndicator,
            userId: this.currentRecord.userId,
            applicationId: this.currentRecord.applicationId,
            channelId: this.currentRecord.channelId,
            shipmentId: this.currentRecord.shipmentId,
            targetFilename: this.currentRecord.targetFilename,
            dismissErrorIndicator: this.currentRecord.dismissErrorIndicator,
            dismissErrorUserId: this.currentRecord.dismissErrorUserId,
            dismissErrorDate: this.currentRecord.dismissErrorDate,
            dissmissableErrorIndicator: this.currentRecord.dismissableErrorIndicator
        });

        this.showDismissButton = (this.currentRecord.dismissErrorIndicator === false && this.currentRecord.dismissableErrorIndicator === true);
        this.showResubmitButton = (this.commsRecordDetailService.getReturnLocation() === 'SEARCH');

        this.commsRecordDetailService.setSelectedResultRecord(this.currentRecord);
    }

    public onBackClicked(): void {
        this.goBackClicked.emit(null);
        this.goToParentList();
    }

    public onDismissClicked(): void {
        this.logger.debug(`In COMMUNICATIONS_RECORD_DETAIL::onDismissClicked`);
        // Need to set the three Dismissal values to indicate it was dismissed
        this.currentRecord.dismissableErrorIndicator = true;
        this.currentRecord.dismissErrorDate = new Date();
        this.currentRecord.dismissErrorUserId = 'Howard Devoto';
        this.commsRecordDetailService.setSelectedResultRecord(this.currentRecord);

        this.commsRecordDetailService.dismissRecord(this.currentRecord.id);

        this.dismissClicked.emit(this.currentRecord.id);
        // this.searchResults = this.commsRecordDetailService.getTableData();

        // if (this.commsRecordDetailService.getReturnLocation() === 'DISMISSAL') {
        //     this.commsErrorDismissalService.setTableData(this.searchResults);
        // } else {
        //     this.commsSearchService.setTableData(this.searchResults);
        // }

        this.goToParentList();
    }

    onPageIndexChanged(newPageIndex: number): void {
        this.currentPageIndex = newPageIndex;
        this.currentRecord = this.searchResults[this.currentPageIndex];
        this.refreshForm();
    }

    private findIndexOfCurrentRecord(): number {
        let pageIndex = 0;
        for (let i = 0; i < this.searchResults.length; i++) {
            if (this.searchResults[i].id === this.currentRecord.id) {
                pageIndex = i;
                break;
            }
        }
        return pageIndex;
    }

    public onResubmitClicked(): void {
        this.resubmitCallNumber = this.commsRecordDetailService.getSelectedResultRecord().callNumber;
        if (this.commsRecordDetailService.getSelectedResultRecord().direction === 'OUTBOUND') {
            this.showFinancialResubmitDialog = true;
            this.financialResubmitDialogTitle = 'Select Resubmit Type';
            this.financialResubmitDialogMessage = 'Do you want to perform a financial resubmit on call number "' +
            this.resubmitCallNumber + '"?';
        } else {
                this.onFinancialResubmitNoClicked();
        }
}

    private onFinancialResubmitYesClicked(): void {
        this.resubmitType = 'Financial';
        this.showFinancialResubmitDialog = false;
        this.showResubmitDialog();
    }

    private onFinancialResubmitNoClicked(): void {
        this.resubmitType = 'Communications';
        this.showFinancialResubmitDialog = false;
        this.showResubmitDialog();
    }

    onMessageBoxButtonClicked(buttonThatWasClicked: string): void {
        this.logger.debug('CommunicationsSearchComponent.onMsgBoxButtonClicked(): button that was clicked is ' + buttonThatWasClicked);

        switch (buttonThatWasClicked) {
            case 'Yes':
                this.notify.successMsg('Call number ' + this.resubmitCallNumber + ' was resubmitted.');
                break;
            case 'No':
                this.notify.infoMsg('Resubmit cancelled for call number ' + this.resubmitCallNumber + '.');
                break;
        }

        this.messageBox.hideDialog();
    }

    showResubmitDialog(): void {
        this.messageBox.showDialog();
        this.communicationsResubmitDialogTitle = this.resubmitType + ' Resubmit';
        this.communicationsResubmitDialogMessage = 'Perform a ' + this.resubmitType + ' Resubmit on call number ' + this.resubmitCallNumber + '?';
        this.communicationsResubmitDialogContent = 'Call Number to resubmit: ' + this.resubmitCallNumber;
    }

    private createForm(): void {
        this.communicationsRecordDetailForm = this.fb.group({
            callNumber: null,
            method: null,
            forms: null,
            auditDate: null,
            contractNumber: null,
            processCode: null,
            direction: null,
            transactionTypeTpcode: null,
            transactionTypeExtension: null,
            inboundFilename: null,
            sosCode: null,
            resubmitIndicator: null,
            userId: null,
            applicationId: null,
            channelId: null,
            shipmentId: null,
            targetFilename: null,
            dismissErrorIndicator: null,
            dismissErrorUserId: null,
            dismissErrorDate: null,
            dismissableErrorIndicator: null
        });
    }
}
