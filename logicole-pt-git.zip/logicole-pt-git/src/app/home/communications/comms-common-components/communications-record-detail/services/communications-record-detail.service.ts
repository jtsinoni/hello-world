import { Injectable } from '@angular/core';
import { CommsUtilityService } from '../../../services/comms-utility.service';
import { CommunicationsSearchResult } from '../../../comms-common-models/communications-search-result';
import { IcommunicationsSearchResult } from '../../../comms-common-models/icommunications-search-result';
import { LoggerService } from '../../../../../services/logger/logger.service';

@Injectable()
export class SearchResultModelService {
  private selectedResultRecord: CommunicationsSearchResult;
  private communicationsSearchResults: Array<CommunicationsSearchResult> = [];
  private returnTo: string;

  private gridApi;
  private gridColumnApi;

  constructor(private commsUtilityService: CommsUtilityService,
    private logger: LoggerService) { }

  public setReturnLocation(location: string): void {
    this.returnTo = location;
  }

  public getReturnLocation(): string {
    return this.returnTo;
  }

  public setSelectedResultRecord(selectedResult: CommunicationsSearchResult): void {
    this.logger.debug(`In Record Detail setSelectedResultRecord`);
    this.selectedResultRecord = selectedResult;
  }

  public getSelectedResultRecord(): CommunicationsSearchResult {
    return this.selectedResultRecord;
  }

  public setTableData(tableData: Array<CommunicationsSearchResult>): void {
    this.logger.debug(`In Record Detail setTableData`);
    this.communicationsSearchResults = tableData;
  }

  public getTableData(): Array<CommunicationsSearchResult> {
    return this.communicationsSearchResults;
  }

  public dismissRecord(guid: string): void {
    this.logger.debug(`in communications-record-detail.service removing guid: ${guid}`);

    let guidIndex: number;
    const newTableData: Array<CommunicationsSearchResult> = [];
    let newTableIndex: number = 0;

    for (let i = (this.communicationsSearchResults.length - 1); i >= 0; i--) {
      guidIndex = this.communicationsSearchResults.findIndex(x => x.id === guid);
      this.logger.debug(`removing index ${guidIndex}`);
      if (guidIndex === undefined || i !== guidIndex) {
        newTableData[newTableIndex++] = this.communicationsSearchResults[i];
      }
    }

    this.logger.debug(`Removing row ${guidIndex} ..... ${JSON.stringify(this.communicationsSearchResults[guidIndex])}`);
    this.logger.debug(`Length of newTableData = ${newTableData.length}`);
    this.communicationsSearchResults = newTableData;

    this.updateGridApiRowData();
  }

  public getBeforeImageData(): string {
    let guid: string;
    let callNum: string;
    let beforeImage: string;

    guid = this.getSelectedResultRecord().id;
    callNum = this.getSelectedResultRecord().callNumber;
    beforeImage = this.getSelectedResultRecord().beforeImage;

    if (beforeImage === undefined || beforeImage === null) {
      beforeImage = 'This is the before image data for call number: ' + callNum + ' \r\n' +
      'line 2 \r\n' +
      'line 3 \r\n' +
      'line 4 \r\n' +
      'line 5 \r\n' +
      'line 6';
    }

    return beforeImage;
  }

  public getAfterImageData(): string {
    let guid: string;
    let callNum: string;
    let afterImage: string;

    guid = this.getSelectedResultRecord().id;
    callNum = this.getSelectedResultRecord().callNumber;
    afterImage = this.getSelectedResultRecord().afterImage;

    if (afterImage === undefined || afterImage === null) {
      afterImage = 'This is the after image data for call number: ' + callNum + ' \r\n' +
      'line 2 \r\n' +
      'line 3 \r\n' +
      'line 4 \r\n' +
      'line 5 \r\n' +
      'line 6';
    }

    return afterImage;
  }

  public getBeforeImageDataLength(): number {
    let imageLength: number = 10000000;
    let beforeImage: string;
    beforeImage = this.getSelectedResultRecord().beforeImage;

    if (beforeImage !== undefined && beforeImage !== null) {
      imageLength = beforeImage.length;
    }

    return imageLength + 100;
  }

  public getAfterImageDataLength(): number {
    let imageLength: number = 10000000;
    let afterImage: string;
    afterImage = this.getSelectedResultRecord().afterImage;

    if (afterImage !== undefined && afterImage !== null) {
      imageLength = afterImage.length;
    }

    return imageLength + 100;
  }

  public setGridApi(gridApi: any): void {
    this.gridApi = gridApi;
  }

  private updateGridApiRowData(): void {
    this.gridApi.setRowData(this.getTableData());

  }
}
