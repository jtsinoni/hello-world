import { TestBed, inject } from '@angular/core/testing';

import { SearchResultModelService } from './communications-record-detail.service';
import { LoggerService } from '../../../../../services/logger/logger.service';
import { CommsUtilityService } from '../../../services/comms-utility.service';

describe('SearchResultModelService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SearchResultModelService, CommsUtilityService, LoggerService]
    });
  });

  it('should be created', inject([SearchResultModelService], (service: SearchResultModelService) => {
    expect(service).toBeTruthy();
  }));
});
