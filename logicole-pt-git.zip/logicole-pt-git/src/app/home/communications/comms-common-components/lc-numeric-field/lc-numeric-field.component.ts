import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { LoggerService } from '../../../../services/logger/logger.service';
import {isNumber} from 'util';

@Component({
  selector: 'lc-numeric-field',
  templateUrl: './lc-numeric-field.component.html'
})
export class NumericFieldComponent implements OnInit {
  // public max: number;
  // public min: number;
  private defaultMax: number = 9999;
  private defaultMin: number = 0;

  @Input() public dmlesValue: number = 0;
  @Input() public minValue: number;
  @Input() public maxValue: number;
  @Input() public showErrorMessage: boolean;
  @Input() public inputId: string;
  @Input() public label: string;
  @Input() public isRequired: boolean;
  @Input() public isReadOnly: boolean;
  @Input() public myTitle: string;
  @Output() public callback = new EventEmitter<number>();
  @Output() public quantityChange = new EventEmitter();
  @Output() public isValueValid = new EventEmitter<boolean>();

  constructor(private logger: LoggerService) { }

  ngOnInit() {
    if (this.maxValue == null){
      this.maxValue = this.defaultMax;
    }

    if (this.minValue == null){
      this.minValue = this.defaultMin;
    }
  }

  public isValid(){
    let isValid = true;

    if (!(this.dmlesValue == null  || this.dmlesValue === undefined)) {
      if (this.maxValue < this.dmlesValue || this.dmlesValue < this.minValue) {
        isValid = false;
      }
    }

    return isValid;
  }

  checkIfValid() {
    const valid: boolean = this.isValid();

    if (valid) {
      this.callback.emit(this.dmlesValue);
    }
    this.logger.debug(`In checkIfValid() - ${valid}`);

    this.isValueValid.emit(valid);
  }

  checkIfChangeIsValid() {
    const valid: boolean = this.isValid();

    if (valid) {
      this.quantityChange.emit();
    }
    this.logger.debug(`In checkIfChangeIsValid() - ${valid}`);

    this.isValueValid.emit(valid);
  }



}
