import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LcYesNoDialogComponent } from './lc-yes-no-dialog.component';

describe('LcYesNoDialogComponent', () => {
  let component: LcYesNoDialogComponent;
  let fixture: ComponentFixture<LcYesNoDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LcYesNoDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LcYesNoDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
