import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
    selector: 'lc-yes-no-dialog',
    templateUrl: './lc-yes-no-dialog.component.html',
    styleUrls: ['./lc-yes-no-dialog.component.scss']
})
export class LcYesNoDialogComponent implements OnInit {
    @Input() title: string;
    @Input() message: string;

    @Output() yesClicked: EventEmitter<string> = new EventEmitter();
    @Output() noClicked: EventEmitter<string> = new EventEmitter();

    constructor() { }

    ngOnInit() {
    }

    public onYesClicked(): void {
        this.yesClicked.emit('yes');
    }

    public onNoClicked(): void {
        this.noClicked.emit('no');
    }
}
