import { Component, OnInit, Input, Output, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { InternalCustomer } from '../../comms-common-models/internal-customer';
import { LoggerService } from '../../../../services/logger/logger.service';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
    selector: 'lc-customer-picker',
    templateUrl: './customer-picker.component.html',
    styleUrls: ['./customer-picker.component.scss']
})
export class CustomerPickerComponent implements OnInit, OnChanges {
    @Input() assignedCustomers: Array<InternalCustomer>;
    @Input() availableCustomers: Array<InternalCustomer>;
    @Output() assignedCustomersChanged: EventEmitter<Array<InternalCustomer>> = new EventEmitter();

    public leftList: Array<InternalCustomer>;
    public rightList: Array<InternalCustomer>;
    public leftSelectedItems: Array<number>;
    public rightSelectedItems: Array<number>;

    constructor(private logger: LoggerService) {
        this.createForm();
    }

    ngOnInit() {
        this.leftList = [];
        this.assignedCustomers.forEach((cust) => {
            this.leftList.push(cust);
        });

        this.rightList = [];
        this.availableCustomers.forEach((cust) => {
            if (this.getIndexInCustomerList(cust, this.leftList) < 0) {
                this.rightList.push(cust);
            }
        });

        this.leftSelectedItems = [];
        this.rightSelectedItems = [];
    }

    ngOnChanges(changes: SimpleChanges): void {
    }

    public onAssignedCustomersChanged(): void {
        this.logger.debug('customerPickerComponent.onAssignedCustomersChanged(). list is ' + JSON.stringify(this.leftList, null, 3));
        const assignedCustomers: Array<InternalCustomer> = [];
        assignedCustomers.push(...this.leftList);
        this.assignedCustomersChanged.emit(assignedCustomers);
    }

    public moveSelectedRight() {
        for (let i = this.leftSelectedItems.length - 1; i >= 0; i--) {
            const listIndex = this.leftSelectedItems[i];
            this.rightList.splice(this.rightList.length, 0, this.leftList[listIndex]);
            this.leftList.splice(Number(listIndex), 1);
        }
        this.rightList.sort((left: InternalCustomer, right: InternalCustomer) => {
            return (left.displayName.localeCompare(right.displayName));
        });
        this.leftSelectedItems = [];
        this.onAssignedCustomersChanged();
    }

    public moveSelectedLeft() {
        this.logger.debug('customerPicker.moveSelectedLeft(): rightSelectedItems is ' + JSON.stringify(this.rightSelectedItems, null, 3));
        for (let i = this.rightSelectedItems.length - 1; i >= 0 ; i--) {
            const listIndex = this.rightSelectedItems[i];
            this.leftList.splice(this.leftList.length, 0, this.rightList[listIndex]);
            this.rightList.splice(Number(listIndex), 1);
        }
        this.leftList.sort((left: InternalCustomer, right: InternalCustomer) => {
            return (left.displayName.localeCompare(right.displayName));
        });
        this.rightSelectedItems = [];
        this.onAssignedCustomersChanged();
    }

    public moveAllRight() {
        for (let i = 0; i < this.leftList.length; i++) {
            const value = this.leftList[i];
            this.rightList.push(value);
        }
        this.leftList = [];
        this.leftSelectedItems = [];
        this.rightList.sort((left: InternalCustomer, right: InternalCustomer) => {
            return (left.displayName.localeCompare(right.displayName));
        });
        this.onAssignedCustomersChanged();
    }

    public moveAllLeft() {
        for (let i = 0; i < this.rightList.length; i++) {
            const value = this.rightList[i];
            this.leftList.push(value);
        }
        this.rightList = [];
        this.rightSelectedItems = [];
        this.leftList.sort((left: InternalCustomer, right: InternalCustomer) => {
            return (left.displayName.localeCompare(right.displayName));
        });
        this.onAssignedCustomersChanged();
    }

    private createForm(): void {
    }

    private getIndexInCustomerList(customer: InternalCustomer, list: Array<InternalCustomer>): number {
        let index = -1;
        for (let i = 0; i < list.length; i++) {
            if (list[i].orgSerial === customer.orgSerial) {
                index = i;
                break;
            }
        }
        return index;
    }
}




// public listContainsStringValue(list: Array<string>, stringValue: string): boolean {
//     var listContainsStringValue: boolean = false;
//     for (var i=0; i < list.length; i++) {
//         if (list[i] === stringValue) {
//             listContainsStringValue = true;
//             break;
//         }
//     }
//     return listContainsStringValue;
// }


// public moveAllRight(): void {
//     this.updateDestinationModel();
// }

// public moveAllLeft(): void {
//     this.updateDestinationModel();
// }
