
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {NO_ERRORS_SCHEMA} from '@angular/core';

import {FormsModule} from '@angular/forms';
import {RouterTestingModule} from '@angular/router/testing';
import {HttpTestModule} from '../../../../common-components/test/http-test.module';
import {ToastrModule} from 'ngx-toastr';
import {NavigationTestModule} from '../../../../common-components/test/navigation-test/navigation-test.module';

import {LoggerService} from '../../../../services/logger/logger.service';
import {PermissionService} from '../../../../services/permission.service';
import {LoginService} from '../../../../services/login.service';
import {NotificationService} from '../../../../services/notification.service';
import {ProfileApiService} from '../../../../services/profile-api.service';

import { CustomerPickerComponent } from './customer-picker.component';
import { InternalCustomer } from '../../comms-common-models/internal-customer';
import { DebugElement } from '@angular/core/src/debug/debug_node';

import { By } from '@angular/platform-browser';

describe('CustomerPickerComponent', () => {
  let component: CustomerPickerComponent;
  let fixture: ComponentFixture<CustomerPickerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        RouterTestingModule,
        HttpTestModule.forRoot(),
        ToastrModule.forRoot(),
        NavigationTestModule.forRoot(),
      ],
        declarations: [ CustomerPickerComponent ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
      providers: [
        LoggerService,
        PermissionService,
        LoginService,
        NotificationService,
        ProfileApiService,
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerPickerComponent);
    component = fixture.componentInstance;
    component.assignedCustomers = [{
      'orgSerial': 5482,
      'customerAccountId': 'YMVPHN',
      'customerName': 'WINDER VAULT - PHARMACY',
      'displayName': 'YMVPHN - WINDER VAULT - PHARMACY',
      'pointOfCareSystemGuid': '82693049-2416-4f48-8630-466bf85026ea',
      'sendCatalogIndicator': true,
      'sendEquipmentIndicator': true,
      'lastCatalogRequestDate': new Date('2017-07-28T14:49:20.635'),
      'lastEquipmentRequestDate': new Date('0001-01-01T00:00:00')
    }];
    component.availableCustomers = [{
      'orgSerial': 5482,
      'customerAccountId': 'YMVPHN',
      'customerName': 'WINDER VAULT - PHARMACY',
      'displayName': 'YMVPHN - WINDER VAULT - PHARMACY',
      'pointOfCareSystemGuid': '82693049-2416-4f48-8630-466bf85026ea',
      'sendCatalogIndicator': true,
      'sendEquipmentIndicator': true,
      'lastCatalogRequestDate': new Date('2017-07-28T14:49:20.635'),
      'lastEquipmentRequestDate': new Date('0001-01-01T00:00:00')
    }];
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
