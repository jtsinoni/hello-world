import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CustomerPickerComponent } from './customer-picker/customer-picker.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LcYesNoDialogComponent } from './lc-yes-no-dialog/lc-yes-no-dialog.component';
import { CommunicationsRecordDetailComponent } from './communications-record-detail/communications-record-detail.component';
import { CommonComponentsModule } from '../../../common-components/common-components.module';
import { NumericFieldComponent } from './lc-numeric-field/lc-numeric-field.component';
import { ComponentsModule } from '../components/components.module';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        CommonComponentsModule,
        ],
    declarations: [
        CustomerPickerComponent,
        LcYesNoDialogComponent,
        CommunicationsRecordDetailComponent,
        NumericFieldComponent,
    ],
    exports: [
        CustomerPickerComponent,
        LcYesNoDialogComponent,
        CommunicationsRecordDetailComponent,
        NumericFieldComponent,
    ]
})
export class CommsCommonComponentsModule { }
