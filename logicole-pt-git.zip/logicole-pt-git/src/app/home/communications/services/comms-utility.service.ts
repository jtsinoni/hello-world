import { Injectable } from '@angular/core';
import { LcTableColumn } from '../../../common-components/lc-table/models/lc-table-column';
import { LcCheckboxCellComponent } from '../../../common-components/lc-table/lc-checkbox-cell/lc-checkbox-cell.component';
import { LcDateCellComponent } from '../../../common-components/lc-table/lc-date-cell/lc-date-cell.component';
import { InternalCustomer } from '../comms-common-models/internal-customer';
import { LoggerService } from '../../../services/logger/logger.service';

@Injectable()
export class CommsUtilityService {

    constructor(private logger: LoggerService) { }

    public createTextColumn(title: string): LcTableColumn {
        const col: LcTableColumn = new LcTableColumn();
        col.title = title;
        return col;
    }

    public createCheckboxColumn(title: string): LcTableColumn {
        const col: LcTableColumn = new LcTableColumn();
        col.title = title;
        col.type = 'custom';
        col.width = '1%';
        col.renderComponent = LcCheckboxCellComponent;
        return col;
    }

    public createDateColumn(title: string): LcTableColumn {
        const col: LcTableColumn = new LcTableColumn();
        col.title = title;
        col.type = 'custom';
        col.renderComponent = LcDateCellComponent;
        return col;
    }

    public getCustomerList(): Array<InternalCustomer> {
        const customerList: Array<InternalCustomer> = [];
        customerList.push({
            'orgSerial': 5479,
            'customerAccountId': 'YMVPHC',
            'customerName': 'MCCHORD VAULT - PHARMACY',
            'displayName': 'YMVPHC - MCCHORD VAULT - PHARMACY',
            'pointOfCareSystemGuid': 'b3d06bab-5809-4a52-9e4e-cd8e494ed1a0',
            'sendCatalogIndicator': true,
            'sendEquipmentIndicator': true,
            'lastCatalogRequestDate': new Date(),
            'lastEquipmentRequestDate': new Date(),
        });
        customerList.push({
            'orgSerial': 5481,
            'customerAccountId': 'YMVPHK',
            'customerName': 'OKUBO VAULT - PHARMACY',
            'displayName': 'YMVPHK - OKUBO VAULT - PHARMACY',
            'pointOfCareSystemGuid': '00000000-0000-0000-0000-000000000000',
            'sendCatalogIndicator': false,
            'sendEquipmentIndicator': false,
            'lastCatalogRequestDate': new Date(),
            'lastEquipmentRequestDate': null,
        });
        customerList.push({
            'orgSerial': 4109,
            'customerAccountId': 'GEBULK',
            'customerName': 'E BULK',
            'displayName': 'GEBULK - E BULK',
            'pointOfCareSystemGuid': '7c1146aa-4844-40f8-b6d2-afb46d646166',
            'sendCatalogIndicator': true,
            'sendEquipmentIndicator': true,
            'lastCatalogRequestDate': null,
            'lastEquipmentRequestDate': null,
        });
        customerList.push({
            'orgSerial': 3386,
            'customerAccountId': 'MEDSTP',
            'customerName': 'MEDSTEP PROGRAM',
            'displayName': 'MEDSTP - MEDSTEP PROGRAM',
            'pointOfCareSystemGuid': '00000000-0000-0000-0000-000000000000',
            'sendCatalogIndicator': false,
            'sendEquipmentIndicator': false,
            'lastCatalogRequestDate': null,
            'lastEquipmentRequestDate': null,
        });
        customerList.push({
            'orgSerial': 1711,
            'customerAccountId': 'Y03AFD',
            'customerName': 'COMMAND COLOR GUARD',
            'displayName': 'Y03AFD - COMMAND COLOR GUARD',
            'pointOfCareSystemGuid': '00000000-0000-0000-0000-000000000000',
            'sendCatalogIndicator': false,
            'sendEquipmentIndicator': false,
            'lastCatalogRequestDate': null,
            'lastEquipmentRequestDate': null,
        });
        customerList.push({
            'orgSerial': 1789,
            'customerAccountId': 'Y03AFF',
            'customerName': 'QUALITY ASSURANCE',
            'displayName': 'Y03AFF - QUALITY ASSURANCE',
            'pointOfCareSystemGuid': '00000000-0000-0000-0000-000000000000',
            'sendCatalogIndicator': false,
            'sendEquipmentIndicator': false,
            'lastCatalogRequestDate': null,
            'lastEquipmentRequestDate': null,
        });
        customerList.push({
            'orgSerial': 1781,
            'customerAccountId': 'Y03AKL',
            'customerName': 'COMPUTER ROOM - HARDWARE',
            'displayName': 'Y03AKL - COMPUTER ROOM - HARDWARE',
            'pointOfCareSystemGuid': '00000000-0000-0000-0000-000000000000',
            'sendCatalogIndicator': false,
            'sendEquipmentIndicator': false,
            'lastCatalogRequestDate': null,
            'lastEquipmentRequestDate': null,
        });
        customerList.push({
            'orgSerial': 1782,
            'customerAccountId': 'Y03AKM',
            'customerName': 'MAILROOM DISTRIBUTION',
            'displayName': 'Y03AKM - MAILROOM DISTRIBUTION',
            'pointOfCareSystemGuid': '00000000-0000-0000-0000-000000000000',
            'sendCatalogIndicator': false,
            'sendEquipmentIndicator': false,
            'lastCatalogRequestDate': null,
            'lastEquipmentRequestDate': null,
        });
        customerList.push({
            'orgSerial': 1783,
            'customerAccountId': 'Y03AKN',
            'customerName': 'ADPE AWAITING DISPOSITION',
            'displayName': 'Y03AKN - ADPE AWAITING DISPOSITION',
            'pointOfCareSystemGuid': '00000000-0000-0000-0000-000000000000',
            'sendCatalogIndicator': false,
            'sendEquipmentIndicator': false,
            'lastCatalogRequestDate': null,
            'lastEquipmentRequestDate': null,
        });
        customerList.push({
            'orgSerial': 1784,
            'customerAccountId': 'Y03AKP',
            'customerName': 'PAGER/CELL PHONE DISTRIBUTION',
            'displayName': 'Y03AKP - PAGER/CELL PHONE DISTRIBUTION',
            'pointOfCareSystemGuid': '00000000-0000-0000-0000-000000000000',
            'sendCatalogIndicator': false,
            'sendEquipmentIndicator': false,
            'lastCatalogRequestDate': null,
            'lastEquipmentRequestDate': null,
        });
        customerList.push({
            'orgSerial': 1785,
            'customerAccountId': 'Y03AKT',
            'customerName': 'LIFE CYCLE REPLACEMENT/COMPUTERS',
            'displayName': 'Y03AKT - LIFE CYCLE REPLACEMENT/COMPUTERS',
            'pointOfCareSystemGuid': '00000000-0000-0000-0000-000000000000',
            'sendCatalogIndicator': false,
            'sendEquipmentIndicator': false,
            'lastCatalogRequestDate': null,
            'lastEquipmentRequestDate': null,
        });
        for (let i = 0; i < 40; i++) {
            const cust = {
                orgSerial: Number(30000 + i),
                customerAccountId: 'CST' + this.zeroFillLeft(String(i), 3),
                customerName: 'Random Customer ' + (i + 1),
                displayName: '',
                'pointOfCareSystemGuid': '00000000-0000-0000-0000-000000000000',
                'sendCatalogIndicator': false,
                'sendEquipmentIndicator': false,
                'lastCatalogRequestDate': null,
                'lastEquipmentRequestDate': null,
            };
            cust.displayName = cust.customerAccountId + ' - ' + cust.customerName;
            customerList.push(cust);
        }
        return customerList;
    }

    public zeroFillLeft(str: string, length: number): string {
        let retString: string = '';
        for (let i = 0; i < length; i++) {
            retString += '0';
        }
        retString += str;
        retString = retString.substring(retString.length - length);
        return retString;
    }

    public getRandomBoolean(): boolean {
        const value: number = Math.floor(Math.random() * 2);
        this.logger.debug('EhrService.getRandomBoolean() random value is ' + value);
        const boolVal: boolean = ((value % 2) === 0);
        this.logger.debug('EhrService.getRandomBoolean() returns ' + boolVal);
        return boolVal;
    }

    public generateGuidLikeString(): string {
        const guid: string = (this.generate4CharString() + this.generate4CharString() + '-' +
            this.generate4CharString() + '-4' + this.generate4CharString().substr(0, 3) + '-' +
            this.generate4CharString() + '-' + this.generate4CharString() + this.generate4CharString() + this.generate4CharString()).toLowerCase();
        return guid;
    }

    private generate4CharString(): string {
        return (((1 + Math.random()) * 0x10000)).toString(16).substring(1);
    }

    public getRandomInt(maxValue: number) {
        const value: number = Math.floor(Math.random() * maxValue);
        return value;
    }

}
