import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CommsUtilityService } from './comms-utility.service';
import { CommunicationsAdminApiService } from './communications-admin-api.service';

@NgModule({
  imports: [
    CommonModule,
  ],
  providers: [
      CommsUtilityService,
      CommunicationsAdminApiService,
  ],
  declarations: []
})
export class CommsServicesModule { }
