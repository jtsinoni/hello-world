import { TestBed, inject } from '@angular/core/testing';
import { HttpClient, HttpClientModule, HttpHandler } from '@angular/common/http';
import { CommonModule, CurrencyPipe } from '@angular/common';
import { LoggerService } from '@lc-services/*';
import { AuthenticationService } from '../../../services/authentication.service';
import { NavigationTestModule } from '../../../common-components/test/navigation-test/navigation-test.module';
import { HttpTestModule } from '../../../common-components/test/http-test.module';

import { CommsServicesModule } from './comms-services.module';
import { CommunicationsAdminApiService } from './communications-admin-api.service';

describe('CommunicationsAdminApiService', () => {
  let http: HttpClient;
  let logger: LoggerService;
  let authenticationService: AuthenticationService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpTestModule.forRoot(), CommsServicesModule, NavigationTestModule.forRoot(), CommonModule],
      providers: [HttpClient, HttpClientModule, HttpHandler, LoggerService, AuthenticationService, CommunicationsAdminApiService]
    });
    http = TestBed.get(HttpClient);
    logger = TestBed.get(LoggerService);
    authenticationService = TestBed.get(AuthenticationService);
  });

  it('should be created', inject([CommunicationsAdminApiService], (service: CommunicationsAdminApiService) => {
    expect(service).toBeTruthy();
  }));
});
