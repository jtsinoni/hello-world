import { TestBed, inject } from '@angular/core/testing';

import { CommsUtilityService } from './comms-utility.service';
import { LoggerService } from '../../../services/logger/logger.service';

describe('CommsUtilityService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CommsUtilityService, LoggerService]
    });
  });

  it('should be created', inject([CommsUtilityService], (service: CommsUtilityService) => {
    expect(service).toBeTruthy();
  }));
});
