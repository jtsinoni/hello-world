import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ApiConstants } from '../../../constants/api.constants';
import { ApiService } from '../../../services/api.service';
import { Observable } from 'rxjs/Observable';
import { AuthenticationService, LoggerService } from '@lc-services/*';
import { CommunicationsSearchResult } from '../comms-common-models/communications-search-result';

@Injectable()
export class CommunicationsAdminApiService extends ApiService {
  private serviceName: string = 'CommunicationsAdminApiService';
  constructor(logger: LoggerService,
              http: HttpClient,
              authenticationService: AuthenticationService) {
    super(ApiConstants.COMMUNICATIONS_ADMIN_API, logger, http, authenticationService);
    this.logger.debug(`${this.serviceName} - Start`);
  }

  public getAuditRecordList(): Observable<CommunicationsSearchResult[]> {
    return this.get(`getAuditRecordList`);
  }

  public getAuditRecordListByDateRange(beginDate: string, endDate: string): Observable<CommunicationsSearchResult[]> {
    const bDate: Date = new Date(beginDate);
    const eDate: Date = new Date(endDate);
    return this.get(`getAuditRecordListByDateRange?beginDate=${bDate}&endDate=${eDate}`);
  }
}
