import { IcommunicationsSearchResult } from './icommunications-search-result';

export class CommunicationsSearchResult implements IcommunicationsSearchResult {
    public id: string;
    public callNumber: string;
    public method: string;
    public forms: string;
    public auditDate: Date;
    public primeVendorStatus: string;
    public contractNumber: string;
    public processText: string;
    public processCode: string;
    public direction: string;
    public transactionTypeTpcode: string;
    public transactionTypeExtension: string;
    public inboundFilename: string;
    public sosCode: string;
    public resubmitIndicator: boolean;
    public userId: string;
    public applicationId: string;
    public channelId: string;
    public shipmentId: string;
    public targetFilename: string;
    public dismissErrorIndicator: boolean;
    public dismissErrorUserId: string;
    public dismissErrorDate: Date;
    public dismissableErrorIndicator: boolean;
    public beforeImage?: string;
    public afterImage?: string;
    public dmlesCurrent?: string;
}

