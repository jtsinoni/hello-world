export interface InternalCustomer {
    orgSerial: number;
    customerAccountId: string;
    customerName: string;
    displayName: string;
    pointOfCareSystemGuid: string;
    sendCatalogIndicator: boolean;
    sendEquipmentIndicator: boolean;
    lastCatalogRequestDate: Date;
    lastEquipmentRequestDate: Date;
}

// {
//     "OrgSerial": 5482,
//     "CustomerAccountId": "YMVPHN",
//     "CustomerName": "WINDER VAULT - PHARMACY",
//     "DisplayName": "YMVPHN - WINDER VAULT - PHARMACY",
//     "PointOfCareSystemGuid": "82693049-2416-4f48-8630-466bf85026ea",
//     "SendCatalogIndicator": true,
//     "SendEquipmentIndicator": true,
//     "LastCatalogRequestDate": "2017-07-28T14:49:20.635",
//     "LastEquipmentRequestDate": "0001-01-01T00:00:00"
// }
