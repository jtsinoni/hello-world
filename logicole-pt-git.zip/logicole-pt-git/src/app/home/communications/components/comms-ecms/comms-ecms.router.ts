import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginService } from '../../../../services/login.service';
import { CommsEcmsComponent } from './comms-ecms.component';
import { RouteConstants } from '../../../../constants/route.constants';
import { RootModule, UIRouterModule } from '@uirouter/angular';
import { CommsEcmsStates } from './comms-ecms-states';

const commsEcmsRoutes: RootModule = {

  states: [
    CommsEcmsStates.COMMUNICATIONS_ECMS_VIEW
  ]
};

/*
const commsEcmsRoutes: Routes = [
//    {
//      path: '',
//      component:  CommsEcmsComponent,
//      data: {breadcrumb: 'ECMS'},
//      canActivate: [LoginService]
//    },
//    {
//      path: '',
//      redirectTo: RouteConstants.COMMUNICATIONS_ECMS.route
//    }
  ];
*/

@NgModule({
  imports: [UIRouterModule.forChild(commsEcmsRoutes)],
  exports: [UIRouterModule]
})
export class CommsEcmsRouterModule {
}
