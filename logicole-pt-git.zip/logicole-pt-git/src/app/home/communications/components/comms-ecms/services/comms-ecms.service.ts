import { Injectable } from '@angular/core';
import { CommsEcmsInfo } from '../models/comms-ecms-info';

@Injectable()
export class CommsEcmsService {

    // TODO: Need to move stuff out of component and into here.

    constructor() { }

    public getCommsEcmsInfo(dodaac: string): CommsEcmsInfo {
        const commsEcmsInfo: CommsEcmsInfo = {
            currentSettings: {
                hostUrl: 'https://www.whatever.com',
                testUrl: 'https://www.testEcms.com',
                numberOfRetries: 3,
                serverStatusEnabled: true,
                timeoutOpen: 15,
                timeoutSend: 20,
                timeoutReceive: 25,
                timeoutClose: 30,
                logLevel: 'FULL',
                logRetention: 10,
                lastUpdatedBy: 'Howard Devoto',
                lastUpdateDate: new Date('3/25/2018 10:15:25 AM')
            },
            numberOfRetriesRange: {
                minValue: 1,
                maxValue: 5
            },
            timeoutOpenRange: {
                minValue: 1,
                maxValue: 60
            },
            timeoutSendRange: {
                minValue: 1,
                maxValue: 60
            },
            timeoutReceiveRange: {
                minValue: 1,
                maxValue: 60
            },
            timeoutCloseRange: {
                minValue: 1,
                maxValue: 60
            }
        };
        return commsEcmsInfo;
    }
}
