import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {NO_ERRORS_SCHEMA} from '@angular/core';

// import {FormsModule} from '@angular/forms';
import {RouterTestingModule} from '@angular/router/testing';
import {HttpTestModule} from '../../../../common-components/test/http-test.module';
import {ToastrModule} from 'ngx-toastr';
import {NavigationTestModule} from '../../../../common-components/test/navigation-test/navigation-test.module';

import {LoggerService} from '../../../../services/logger/logger.service';
import {PermissionService} from '../../../../services/permission.service';
import {LoginService} from '../../../../services/login.service';
import {NotificationService} from '../../../../services/notification.service';
import {ProfileApiService} from '../../../../services/profile-api.service';

import { CommsEcmsComponent } from './comms-ecms.component';
import { CommsEcmsService } from './services/comms-ecms.service';
import { CommsEcmsInfo } from './models/comms-ecms-info';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';
import {CommonComponentsModule} from '../../../../common-components/common-components.module';
import { CommsCommonComponentsModule } from '../../comms-common-components/comms-common-components.module';
import { ModelsModule } from './models/models.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


describe('CommsEcmsComponent', () => {
  let component: CommsEcmsComponent;
  let fixture: ComponentFixture<CommsEcmsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        ReactiveFormsModule,
        ModelsModule,
        CommsCommonComponentsModule,
        CommonComponentsModule,
        RouterTestingModule,
        HttpTestModule.forRoot(),
        ToastrModule.forRoot(),
        NavigationTestModule.forRoot(),
      ],
      declarations: [ CommsEcmsComponent ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
      providers: [
        LoggerService,
        CommsEcmsService,
        NotificationService,
        FormBuilder
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommsEcmsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
