import { CommsEcmsSettings } from './comms-ecms-settings';
import { CommsEcmsRange } from './comms-ecms-range';

export class CommsEcmsInfo {
    public currentSettings: CommsEcmsSettings;
    public numberOfRetriesRange: CommsEcmsRange;
    public timeoutOpenRange: CommsEcmsRange;
    public timeoutSendRange: CommsEcmsRange;
    public timeoutReceiveRange: CommsEcmsRange;
    public timeoutCloseRange: CommsEcmsRange;
}
