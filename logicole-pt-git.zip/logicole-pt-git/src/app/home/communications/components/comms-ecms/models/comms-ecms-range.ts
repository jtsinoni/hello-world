export class CommsEcmsRange {
    public minValue: number;
    public maxValue: number;
}
