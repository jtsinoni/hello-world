import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CommsEcmsComponent } from './comms-ecms.component';
import { ModelsModule } from './models/models.module';
import { ServicesModule } from './services/services.module';
import { CommsEcmsRouterModule } from './comms-ecms.router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommsCommonComponentsModule } from '../../comms-common-components/comms-common-components.module';
import { CommonComponentsModule } from '../../../../common-components/common-components.module';

@NgModule({
  imports: [
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    ModelsModule,
    ServicesModule,
    CommsEcmsRouterModule,
    CommsCommonComponentsModule,
    CommonComponentsModule,
  ],
  declarations: [
    CommsEcmsComponent,
  ],
  exports: [
    CommsEcmsComponent,
    CommsEcmsRouterModule,
    CommsCommonComponentsModule
  ]
})
export class CommsEcmsModule { }
