import { TestBed, inject } from '@angular/core/testing';

import { CommsEcmsService } from './comms-ecms.service';

describe('CommsEcmsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CommsEcmsService]
    });
  });

  it('should be created', inject([CommsEcmsService], (service: CommsEcmsService) => {
    expect(service).toBeTruthy();
  }));
});
