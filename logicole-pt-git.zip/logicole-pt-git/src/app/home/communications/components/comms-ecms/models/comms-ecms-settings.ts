export class CommsEcmsSettings {
    public hostUrl: string;
    public testUrl: string;
    public numberOfRetries: number;
    public serverStatusEnabled: boolean;
    public timeoutOpen: number;
    public timeoutSend: number;
    public timeoutReceive: number;
    public timeoutClose: number;
    public logLevel: string;
    public logRetention: number;
    public lastUpdatedBy: string;
    public lastUpdateDate: Date;
}
