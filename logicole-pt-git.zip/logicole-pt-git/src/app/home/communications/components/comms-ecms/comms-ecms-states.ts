import {Ng2StateDeclaration} from '@uirouter/angular';
import {RouteConstants} from '../../../../constants/route.constants';
import {CommsEcmsComponent} from './comms-ecms.component';

export class CommsEcmsStates {

  static COMMUNICATIONS_ECMS_VIEW: Ng2StateDeclaration = {
    url: RouteConstants.COMMUNICATIONS_ECMS.url,
    name: RouteConstants.COMMUNICATIONS_ECMS.name,
    component: CommsEcmsComponent, data: {'route': RouteConstants.COMMUNICATIONS_ECMS}
  };

}
