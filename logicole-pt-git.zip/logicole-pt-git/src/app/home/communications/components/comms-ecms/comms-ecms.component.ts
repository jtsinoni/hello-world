import { Component, OnInit } from '@angular/core';
import { LoggerService } from '../../../../services/logger/logger.service';
import { NotificationService } from '../../../../services/notification.service';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { CommsEcmsService } from './services/comms-ecms.service';
import { CommsEcmsInfo } from './models/comms-ecms-info';

@Component({
  selector: 'app-comms-ecms',
  templateUrl: './comms-ecms.component.html',
  styleUrls: ['./comms-ecms.component.scss']
})
export class CommsEcmsComponent implements OnInit {
  private commsEcmsInfo: CommsEcmsInfo;


  public aValueChanged: boolean = false;
  public manageEcmsForm: FormGroup;

  public retryValue = 3;
  public retryMinValue = 1;
  public retryMaxValue = 5;

  public timeoutOpen = 30;
  public timeoutSend = 30;
  public timeoutReceive = 30;
  public timeoutClose = 30;
  public timeoutMinValue = 1;
  public timeoutMaxValue = 60;

  public logLevelValue = 'NONE';

  public acceptedLogLevelsTypes: string[] = [
    'NONE',
    'TERSE',
    'FULL',
  ];


  constructor(private logger: LoggerService,
    private commsEcmsService: CommsEcmsService,
    private notify: NotificationService,
    private formBuilder: FormBuilder) {

  }

  ngOnInit() {
    this.aValueChanged = false;

    this.commsEcmsInfo = this.commsEcmsService.getCommsEcmsInfo('FM3500');
    this.createForm();

    this.logLevelValue = this.commsEcmsInfo.currentSettings.logLevel;
    this.retryValue = this.commsEcmsInfo.currentSettings.numberOfRetries;
    this.retryMinValue = this.commsEcmsInfo.numberOfRetriesRange.minValue;
    this.retryMaxValue = this.commsEcmsInfo.numberOfRetriesRange.maxValue;
    this.timeoutOpen = this.commsEcmsInfo.currentSettings.timeoutOpen;
    this.timeoutSend = this.commsEcmsInfo.currentSettings.timeoutSend;
    this.timeoutReceive = this.commsEcmsInfo.currentSettings.timeoutReceive;
    this.timeoutClose = this.commsEcmsInfo.currentSettings.timeoutClose;
  }

  private createForm(): void {
    this.manageEcmsForm = this.formBuilder.group({
      hostUrl: this.commsEcmsInfo.currentSettings.hostUrl,
      testUrl: this.commsEcmsInfo.currentSettings.testUrl,
      numberOfRetries: this.commsEcmsInfo.currentSettings.numberOfRetries,
      logRetention: this.commsEcmsInfo.currentSettings.logRetention,
      lastUpdatedBy: new FormControl({ value: this.commsEcmsInfo.currentSettings.lastUpdatedBy, disabled: true }),
      lastUpdatedDate: new FormControl({ value: this.commsEcmsInfo.currentSettings.lastUpdateDate, disabled: true }),
      isEnabledFormField: this.commsEcmsInfo.currentSettings.serverStatusEnabled,
    });
  }

  public saveConfigurationChanges(): void {
    this.notify.successMsg('Configuration updated successfully');
    this.aValueChanged = false;
  }

  public valueChanged(event): void {
    this.logger.debug(`In valueChanged() - ${event}`);
    if (event === true) {
      this.aValueChanged = true;
    } else {
      this.aValueChanged = false;
    }
  }

}
