import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CommsErrorsResult } from './comms-errors-result';

@NgModule({
  imports: [
    CommonModule,
  ],
  declarations: [],
  exports: [
  ]
})
export class ModelsModule { }
