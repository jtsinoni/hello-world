import { NgModule } from '@angular/core';
// import { Routes, RouterModule } from '@angular/router';
// import { LoginService } from '../../../../services/login.service';
// import { CommsErrorDismissalComponent } from './comms-error-dismissal.component';
// import { RouteConstants } from '../../../../constants/route.constants';
import { RootModule, UIRouterModule } from '@uirouter/angular';
import { CommsErrorDismissalStates } from './comms-error-dismissal-states';

const commsErrorDismissalRoutes: RootModule = {

  states: [
    CommsErrorDismissalStates.COMMS_ERROR_DISMISSAL_VIEW,
    CommsErrorDismissalStates.COMMS_ERROR_DISMISSAL_DETAIL
  ]
};

  @NgModule({
    imports: [UIRouterModule.forChild(commsErrorDismissalRoutes)],
    exports: [UIRouterModule]
  })
  export class CommsErrorDismissalRouterModule {

  }
