import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CommsErrorDismissalService } from './comms-error-dismissal.service';

@NgModule({
  imports: [
    CommonModule,
  ],
  declarations: [],
  providers: [
    CommsErrorDismissalService,
  ]
})
export class ServicesModule { }
