import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ModelsModule } from './models/models.module';
import { ServicesModule } from './services/services.module';
import { CommsErrorDismissalComponent } from './comms-error-dismissal.component';
import { CommonComponentsModule } from '../../../../common-components/common-components.module';
import { LcTableModule } from '../../../../common-components/lc-table/lc-table.module';
import { CommsErrorDismissalRouterModule } from './comms-error-dismissal.router';
import { CommsCommonComponentsModule } from '../../comms-common-components/comms-common-components.module';
import { CommsUtilityService } from '../../services/comms-utility.service';
import { CommunicationsRecordDetailComponent } from '../../comms-common-components/communications-record-detail/communications-record-detail.component';
import { CommunicationsRecordDetailServicesModule } from '../../comms-common-components/communications-record-detail/services/services.module';

@NgModule({
  imports: [
    CommonModule,
    ModelsModule,
    ServicesModule,
    LcTableModule,
    CommonComponentsModule,
    CommsErrorDismissalRouterModule,
    CommsCommonComponentsModule,
    CommunicationsRecordDetailServicesModule,
  ],
  declarations: [
    CommsErrorDismissalComponent,
  ],
  exports: [
    CommsErrorDismissalComponent,
    CommsErrorDismissalRouterModule,
    CommunicationsRecordDetailComponent,
  ],
  providers: [CommsUtilityService]

})
export class CommsErrorDismissalModule { }
