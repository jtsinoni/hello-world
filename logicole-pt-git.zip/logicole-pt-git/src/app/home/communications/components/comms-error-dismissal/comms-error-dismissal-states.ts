import {Ng2StateDeclaration} from '@uirouter/angular';
import {RouteConstants} from '../../../../constants/route.constants';
import {CommsErrorDismissalComponent} from './comms-error-dismissal.component';
import {CommunicationsRecordDetailComponent} from '../../comms-common-components/communications-record-detail/communications-record-detail.component';

export class CommsErrorDismissalStates {

  static COMMS_ERROR_DISMISSAL_VIEW: Ng2StateDeclaration = {
    url: RouteConstants.COMMUNICATIONS_ERROR_DISMISSAL.url,
    name: RouteConstants.COMMUNICATIONS_ERROR_DISMISSAL.name,
    component: CommsErrorDismissalComponent,
    data: {'route': RouteConstants.COMMUNICATIONS_ERROR_DISMISSAL}
  };

  static COMMS_ERROR_DISMISSAL_DETAIL: Ng2StateDeclaration = {
    url: RouteConstants.COMMUNICATIONS_ERROR_DISMISSAL_DETAIL.url,
    name: RouteConstants.COMMUNICATIONS_ERROR_DISMISSAL_DETAIL.name,
    component: CommunicationsRecordDetailComponent,
    data: {'route': RouteConstants.COMMUNICATIONS_ERROR_DISMISSAL_DETAIL}
  };

}
