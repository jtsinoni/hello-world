import { Component, OnInit } from '@angular/core';
import { LcButtonCellComponent } from '../../../../common-components/lc-table/lc-button-cell/lc-button-cell.component';
import { LcButtonCallbackEvent } from '../../../../common-components/lc-table/models/lc-button-callback-event';
import { LoggerService } from '../../../../services/logger/logger.service';
import { NotificationService } from '../../../../services/notification.service';
import { CommsErrorDismissalService } from './services/comms-error-dismissal.service';
import { SearchResultModelService } from '../../comms-common-components/communications-record-detail/services/communications-record-detail.service';
import { LcLinkCellComponent } from '../../../../common-components/lc-table/lc-link-cell/lc-link-cell.component';
import { CommunicationsSearchResult } from '../../comms-common-models/communications-search-result';
import { CommsUtilityService } from '../../services/comms-utility.service';
import { StateNavigationService } from '../../../../services/state-navigation.service';
import { RouteConstants } from '../../../../constants/route.constants';

import { GridOptions } from 'ag-grid/main';
import { LcGridCardSettings  } from '../../../../common-components/lc-grid/models/lc-grid-card-settings';
import { LcButtonLinkCellComponent } from '../../../../common-components/lc-grid/lc-button-link-cell/lc-button-link-cell.component';
import { LcGridButtonCellComponent } from '../../../../common-components/lc-grid/lc-button-cell/lc-button-cell.component';
import { LcGridCheckboxCellComponent } from '../../../../common-components/lc-grid/lc-grid-checkbox-cell/lc-grid-checkbox-cell.component';

@Component({
  selector: 'lc-comms-error-dismissal',
  templateUrl: './comms-error-dismissal.component.html',
  styleUrls: ['./comms-error-dismissal.component.scss']
})
export class CommsErrorDismissalComponent implements OnInit {
  public selected = [];

  public dismissAllButtonEnabled: boolean;

  public selectedCommsErrorResult: CommunicationsSearchResult;

    // ag-grid (lc-grid) setup
    private gridApi;
    private gridColumnApi;

    public gridCardSettings: LcGridCardSettings = {
        cardId: 'communicationsErrorDismissal',
        cardShowDownload: true,
        cardShowGlobalSearch: true,
        cardShowHeader: true,
        cardShowRefresh: true,
        cardTitle: 'Communications Error Dismissal Results',
        cardTitleIcon: 'fa fa-phone',
        cardDownloadCsvFilename: 'communicationsErrorDismissalRecords.csv',
    };

    public gridOptions: GridOptions = {
        enableFilter: true,
        floatingFilter: false,
        pagination: true,
        paginationPageSize: 20,
        domLayout: 'autoHeight',
        enableColResize: true,
        enableSorting: true,
        // rowHeight: 25,  // 25 is the default
        rowSelection: 'single',
        debug: false,

        defaultColDef: {
          // make every column non-editable
        editable: false,
          // make every column use 'text' filter by default
        },

        context: {componentParent: this,
                  buttonIconName: 'fa-check-square-o',
                  buttonToolTip: 'Dismiss record',
                  buttonId: 'dismissRecord'},

        columnDefs: [
          {
            width: 70,
            cellRendererFramework: LcGridButtonCellComponent
          },
          {
            headerName: 'Call/Sequence/Block Number',
            headerTooltip: 'Call Number',
            field: 'callNumber',
            tooltipField: 'callNumber',
            cellRendererFramework: LcButtonLinkCellComponent,
          },
          {
            headerName: 'Contract Number',
            headerTooltip: 'Contract Number',
            field: 'contractNumber',
            tooltipField: 'contractNumber',
          },
          {
            headerName: 'Audit Date',
            headerTooltip: 'Audit Date',
            field: 'auditDate',
            tooltipField: 'auditDate',
            filter: 'agDateColumnFilter',
          },
          {
            headerName: 'Process Code',
            headerTooltip: 'Process Code',
            field: 'processCode',
            tooltipField: 'processCode',
          },
          {
            headerName: 'Txn Type TP Code',
            headerTooltip: 'Txn Type TP Code',
            field: 'transactionTypeTpcode',
            tooltipField: 'transactionTypeTpcode'
          },
          {
            headerName: 'Direction',
            headerTooltip: 'Direction',
            field: 'direction',
            tooltipField: 'direction'
          },
          {
            headerName: 'Channel ID',
            headerTooltip: 'Channel ID',
            field: 'channelId',
            tooltipField: 'channelId',
          },
          {
            headerName: 'Shipment ID',
            headerTooltip: 'Shipment ID',
            field: 'shipmentId',
            tooltipField: 'shipmentId',
          },
          {
            headerName: 'User ID',
            headerTooltip: 'User ID',
            field: 'userId',
            tooltipField: 'userId',
          },
          {
            headerName: 'ID',
            headerTooltip: 'ID',
            field: 'id',
            tooltipField: 'id',
            hide: true,
          },
          {
            headerName: 'Method',
            headerTooltip: 'Method',
            field: 'method',
            tooltipField: 'method',
            hide: true,
          },
          {
            headerName: 'Prime Vendor Status',
            headerTooltip: 'Prime Vendor Status',
            field: 'primeVendorStatus',
            tooltipField: 'primeVendorStatus',
            hide: true,
          },
          {
            headerName: 'Process Text',
            headerTooltip: 'Process Text',
            field: 'processText',
            tooltipField: 'processText',
            hide: true,
          },
          {
            headerName: 'Transaction Type Ext',
            headerTooltip: 'Transaction Type Ext',
            field: 'transactionTypeExtension',
            tooltipField: 'transactionTypeExtension',
            hide: true,
          },
          {
            headerName: 'Inbound Filename',
            headerTooltip: 'Inbound Filename',
            field: 'inboundFilename',
            tooltipField: 'inboundFilename',
            hide: true
          },
          {
            headerName: 'Source of Supply',
            headerTooltip: 'Source of Supply',
            field: 'sosCode',
            tooltipField: 'sosCode',
            hide: true,
          },
          {
            headerName: 'Resubmit Indicator',
            headerTooltip: 'Resubmit Indicator',
            field: 'resubmitIndicator',
            tooltipField: 'resubmitIndicator',
            hide: true,
          },
          {
            headerName: 'Application ID',
            headerTooltip: 'Application ID',
            field: 'applicationId',
            tooltipField: 'applicationId',
            hide: true,
          },
          {
            headerName: 'Target Filename',
            headerTooltip: 'Target Filename',
            field: 'targetFilename',
            tooltipField: 'targetFilename',
            hide: true,
          },
          {
            headerName: 'Dismiss Error Indicator',
            headerTooltip: 'Dissmiss Error Indicator',
            field: 'dismissErrorIndicator',
            tooltipField: 'dismissErrorIndicator',
            cellRendererFramework: LcGridCheckboxCellComponent, // This shows an example of using the lgGridCheckboxCellComponent (see lcGridCheckboxClicked, as well)
            hide: true,
          },
          {
            headerName: 'Dismiss Error User ID',
            headerTooltip: 'Dismiss Error User ID',
            field: 'dismissErrorUserId',
            tooltipField: 'dismissErrorUserId',
            hide: true,
          },
          {
            headerName: 'Dismiss Error Date',
            headerTooltip: 'Dismiss Error Date',
            field: 'dismissErrorDate',
            tooltipField: 'dismissErrorDate',
            hide: true,
          },
          {
            headerName: 'Dismissable Error Indicator',
            headerTooltip: 'Dismissable Error Indicator',
            field: 'dismissableErrorIndicator',
            tooltipField: 'dismissableErrorIndicator',
            hide: true,
          },
        ],
      };
    // ag-grid setup end

  constructor(private commsErrorDismissalService: CommsErrorDismissalService,
              public commsRecordDetailService: SearchResultModelService,
              private commsUtilityService: CommsUtilityService,
              private notify: NotificationService,
              private logger: LoggerService,
              private navigationService: StateNavigationService) {}

  ngOnInit() {
    this.getInboundErrorResults();
    this.setDismissAllButtonState();
    this.commsRecordDetailService.setReturnLocation('DISMISSAL');
  }

  goToDetail() {
    this.logger.debug(`going to COMMUNICATIONS_ERROR_DISMISSAL_DETAIL`);
    this.navigationService.navigateToState(RouteConstants.COMMUNICATIONS_ERROR_DISMISSAL_DETAIL);
  }

  private setDismissAllButtonState(): void {
    this.dismissAllButtonEnabled = this.commsRecordDetailService.getTableData().length > 0;
  }


  private contractNumberClicked(rowData: CommunicationsSearchResult): void {
    this.logger.debug('viewDetails link was clicked: ' + JSON.stringify(rowData, null, 3));
    this.selectedCommsErrorResult = rowData;
    this.commsErrorDismissalService.setSelectedInboundErrorResult(rowData);

    this.commsRecordDetailService.setSelectedResultRecord(rowData);
    this.goToDetail();
  }

  public onDismissClicked(guid: string): void {
    this.logger.debug(`Dismiss button was clicked. Removing record with guid = ${guid}`);
    this.commsRecordDetailService.dismissRecord(guid);
  }

  onDismissAllClicked() {
    let guid: string;
    const tableLength: number = this.commsRecordDetailService.getTableData().length;

    this.logger.debug(`In onDismissAllClicked() - length = ${tableLength}`);

    while (this.commsRecordDetailService.getTableData().length > 0) {
      guid = this.commsRecordDetailService.getTableData()[0].id;
      this.commsRecordDetailService.dismissRecord(guid);
    }

    this.gridApi.setRowData(this.commsRecordDetailService.getTableData());

    this.setDismissAllButtonState();

    this.notify.successMsg(tableLength + ' communications error records dismissd.');
  }

  public getTableData(): Array<CommunicationsSearchResult> {
    this.setDismissAllButtonState();
    return this.commsRecordDetailService.getTableData();
  }

  public getInboundErrorResults(): void {
    this.commsRecordDetailService.setTableData(this.commsErrorDismissalService.getInboundErrorResults('FM3500'));
  }

    // ag-grid functions
    onGridReady(params) {
      this.logger.debug(`communications-search onGridReady`);

      this.gridApi = params.api;
      this.gridColumnApi = params.columnApi;

      params.api.setRowData(this.getTableData());
      params.api.sizeColumnsToFit();

      this.commsRecordDetailService.setGridApi(this.gridApi);

      // just here to show how to listen for an event - in this case a column event
      // params.api.addGlobalListener(function (type, event) {
      //  if (type.indexOf("column") >= 0) {
      // console.log("Got column event: ", event);
      //  }
      // });
  }

  onGridSizeChanged(params) {
      params.api.sizeColumnsToFit();
  }

  onRefreshClick(param: string = '') {
    this.gridApi.setRowData([]);
    this.logger.debug(`communications-error-dismissal: onRefreshClick(${param})`);
    this.getInboundErrorResults();
    this.gridApi.setRowData(this.commsRecordDetailService.getTableData());
    this.commsRecordDetailService.setGridApi(this.gridApi);
  }

  public lcGridGoToRowDetails(row: any) {
      this.logger.debug(`communications-error-dismissal: lcGridGoToRowDetails(${row.callNumber})`);
      this.contractNumberClicked(row);
    }

  public lcGridRowButtonClicked(searchTableRow: any) {
    this.logger.debug(`Removing guid (id)... ${searchTableRow.id}`);

    this.commsRecordDetailService.dismissRecord(searchTableRow.id);
    this.gridApi.setRowData(this.commsRecordDetailService.getTableData());

    this.setDismissAllButtonState();
  }

  // This method demonstrates how to process values from the LcGridCheckboxCellComponent
  lcGridCheckboxClicked(row: any, value: boolean): void {
      row.dismissErrorIndicator = value;
      this.commsRecordDetailService.setSelectedResultRecord(row);
      // would need to update the grid too.
  }
}
