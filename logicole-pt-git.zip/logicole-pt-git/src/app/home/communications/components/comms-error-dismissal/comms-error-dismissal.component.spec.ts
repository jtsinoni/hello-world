import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {NO_ERRORS_SCHEMA} from '@angular/core';

import {FormsModule} from '@angular/forms';
import {RouterTestingModule} from '@angular/router/testing';
import {HttpTestModule} from '../../../../common-components/test/http-test.module';
import {ToastrModule} from 'ngx-toastr';
import {NavigationTestModule} from '../../../../common-components/test/navigation-test/navigation-test.module';

import { CommsErrorDismissalComponent } from './comms-error-dismissal.component';
import { CommsErrorDismissalService } from './services/comms-error-dismissal.service';
import { SearchResultModelService } from '../../comms-common-components/communications-record-detail/services/communications-record-detail.service';
import { CommsUtilityService } from '../../services/comms-utility.service';
import { NotificationService } from '../../../../services/notification.service';
import { LoggerService } from '../../../../services/logger/logger.service';
import { StateNavigationService } from '../../../../services/state-navigation.service';

describe('CommsErrorDismissalComponent', () => {
  let component: CommsErrorDismissalComponent;
  let fixture: ComponentFixture<CommsErrorDismissalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        RouterTestingModule,
        HttpTestModule.forRoot(),
        ToastrModule.forRoot(),
        NavigationTestModule.forRoot(),
      ],
      declarations: [ CommsErrorDismissalComponent ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
      providers: [
        CommsErrorDismissalService,
        SearchResultModelService,
        CommsUtilityService,
        NotificationService,
        LoggerService,
        StateNavigationService,
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommsErrorDismissalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
