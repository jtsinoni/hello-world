import { TestBed, inject } from '@angular/core/testing';

import { CommsErrorDismissalService } from './comms-error-dismissal.service';
import { CommsUtilityService } from '../../../services/comms-utility.service';
import { LoggerService } from '../../../../../services/logger/logger.service';

describe('CommsErrorDismissalService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CommsErrorDismissalService, CommsUtilityService, LoggerService]
    });
  });

  it('should be created', inject([CommsErrorDismissalService], (service: CommsErrorDismissalService) => {
    expect(service).toBeTruthy();
  }));
});
