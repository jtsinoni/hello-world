export interface IcommsErrorsResult {
    id: string;
    callNumber: string;
    method: string;
    forms: string;
    auditDate: Date;
    primeVendorStatus: string;
    contractNumber: string;
    processText: string;
    processCode: string;
    direction: string;
    transactionTypeTpcode: string;
    transactionTypeExtension: string;
    inboundFilename: string;
    sosCode: string;
    resubmitIndicator: boolean;
    userId: string;
    applicationId: string;
    channelId: string;
    shipmentId: string;
    targetFilename: string;
    dismissErrorIndicator: boolean;
    dismissErrorUserId: string;
    dismissErrorDate: Date;
    dismissableErrorIndicator: boolean;
    [others: string]: any;
}
