export class SabrsConfigurationClass {
    public nextBlockNumber: string;
    public next821FileId: string;
    public next861FileId: string;
}
