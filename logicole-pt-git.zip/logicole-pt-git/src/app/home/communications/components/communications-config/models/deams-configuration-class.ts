export class DeamsConfigurationClass {
    public nextBlockNumber: string;
    public nextGfebsFile2090: string;
    public nextGfebsFile2091: string;
    public nextGfebsFile2064: string;
}

