export class CarouselConfigurationClass {
    public carouselOrgId: string;
}
