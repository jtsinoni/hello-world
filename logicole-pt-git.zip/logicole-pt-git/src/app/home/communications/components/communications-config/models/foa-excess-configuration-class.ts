import { DaascDdnClass } from './daasc-ddn-class';

export class FoaExcessConfigurationClass {
    public daascDdnList: DaascDdnClass[];
}
