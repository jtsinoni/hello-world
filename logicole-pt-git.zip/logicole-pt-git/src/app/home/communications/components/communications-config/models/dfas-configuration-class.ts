import { DaascDdnClass } from './daasc-ddn-class';

export class DfasConfigurationClass {
    public showSequenceNumber: boolean;
    public showSerialNumberAndBlockNumber: boolean;
    public nextDfasSequenceNumber: string;
    public nextSerialNumber: string;
    public nextBlockNumber: string;
    public daascDdnList: DaascDdnClass[];
}
