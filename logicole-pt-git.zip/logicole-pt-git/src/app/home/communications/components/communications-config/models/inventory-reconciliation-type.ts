export enum InventoryReconciliationType {
    None,
    AsRequired,
    Annual
}
