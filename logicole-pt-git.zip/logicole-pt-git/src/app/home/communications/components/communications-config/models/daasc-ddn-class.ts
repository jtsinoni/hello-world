export class DaascDdnClass {
    public id: string;
    public type: string;
    public commRI: string;
}
