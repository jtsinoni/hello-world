export class LabelValue {
    public label: string;
    public value: string;
}
