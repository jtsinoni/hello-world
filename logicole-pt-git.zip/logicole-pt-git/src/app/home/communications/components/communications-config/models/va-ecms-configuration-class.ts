export class VaEcmsConfigurationClass {
    public nextBlockNumberMo: string;
    public nextBlockNumberEt: string;
    public nextBlockNumberFaD: string;
}
