export class DcdConfigurationClass {
    public nextDcdSequenceNumber: string;
}

