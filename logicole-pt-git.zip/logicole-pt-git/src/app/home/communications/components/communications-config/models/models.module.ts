import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LabelValue } from './label-value';
import { BsmConfigurationClass } from './bsm-configuration-class';
import { CarouselConfigurationClass } from './carousel-configuration-class';
import { DaascDdnClass } from './daasc-ddn-class';
import { DcdConfigurationClass } from './dcd-configuration-class';
import { CommunicationsConfigurationClass } from './communications-configuration-class';
import { DeamsConfigurationClass } from './deams-configuration-class';
import { DfasConfigurationClass } from './dfas-configuration-class';
import { FastdataConfigurationClass } from './fastdata-configuration-class';
import { FastdataInfoClass } from './fastdata-info-class';
import { FoaExcessConfigurationClass } from './foa-excess-configuration-class';
import { GafsConfigurationClass } from './gafs-configuration-class';
import { GfebsConfigurationClass } from './gfebs-configuration-class';
import { InventoryReconciliationType } from './inventory-reconciliation-type';
import { SabrsConfigurationClass } from './sabrs-configuration-class';
import { VaEcmsConfigurationClass } from './va-ecms-configuration-class';
import { VaFmsConfigurationClass } from './va-fms-configuration-class';
import { VaIfrrInrrConfigurationClass } from './va-ifrr-inrr-configuration-class';

@NgModule({
  imports: [
    CommonModule,
  ],
  declarations: []
})
export class ModelsModule { }
