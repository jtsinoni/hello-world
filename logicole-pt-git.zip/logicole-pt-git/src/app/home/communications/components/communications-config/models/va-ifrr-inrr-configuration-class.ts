export class VaIfrrInrrConfigurationClass {
    public nextBlockNumber: string;
}
