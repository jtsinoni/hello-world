import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CommunicationsConfigurationService } from './communications-configuration.service';

@NgModule({
  imports: [
    CommonModule,
  ],
  declarations: [],
  providers: [
    CommunicationsConfigurationService
  ]
})
export class ServicesModule { }
