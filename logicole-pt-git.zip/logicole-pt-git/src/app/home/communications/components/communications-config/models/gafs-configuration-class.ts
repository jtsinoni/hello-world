export class GafsConfigurationClass {
    public nextGafsSequenceNumber: string;
}
