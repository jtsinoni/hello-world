import { Injectable } from '@angular/core';
import { DaascDdnClass } from '../models/daasc-ddn-class';
import { CommsUtilityService } from '../../../services/comms-utility.service';
import { LoggerService } from '../../../../../services/logger/logger.service';

@Injectable()
export class CommunicationsConfigurationService {

  constructor(private logger: LoggerService,
              private commsUtilService: CommsUtilityService) {
    this.buildRecordList();
  }

  private commRiList: Array<DaascDdnClass> = [];

  public getConfigurationCodeList(): string[] {
    const configList: string[] = [
      'ATS',
      'BSM',
      'CAROUSEL-1',
      'CAROUSEL-2',
      'CMOS',
      'DAASC',
      'DAASC-X12',
      'DBP',
      'DEAMS',
      'GAFS',
      'DFAS',
      'DLIS',
      'DSCP-EDI',
      'EQUIPMENT UID',
      'FASTDATA',
      'FMS',
      'FOA EXCESS',
      'FOA REPORTS',
      'GFEBS',
      'JMAR',
      'MAXIMO',
      'POUSRV',
      'PVM-E830A',
      'PVP-E830A',
      'QA FTP',
      'SABRS',
      'USAMMA-MRE',
      'VA-FMS',
      'VA-IFRR-INRR',
      'VA-eCMS',
      'WAWF'
    ];
    return configList;
  }

  public getCommRiForDodaac(dodaac: string): Array<DaascDdnClass> {
    const list: Array<DaascDdnClass> = [];
    list.push(...this.commRiList);
    return list;
}

  private getCommRiType(index: number): string {
    const typeList: Array<string> = ['AFMLO', 'DAASC', 'DMLSS', 'VVVVV', 'XXXXX', 'MMMMM'];
    const slot: number = index % 6;
    return typeList[slot];
  }

  private getCommRi(index: number): string {
    const commRiList: Array<string> = ['RUQAAEC', 'RUSAZZA', 'RUQAAQD', 'RUQTTEC', 'RUSALLA', 'RUQBBQD'];
    const slot: number = index % 6;
    return commRiList[slot];
  }

  private buildRecordList(): void {
    const numRecords: number = 6;
    for (let i = 0; i < numRecords; i++) {
        this.commRiList.push({
            id: this.commsUtilService.generateGuidLikeString(),
            type: this.getCommRiType(i),
            commRI: this.getCommRi(i)
        });
    }
  }

  public updateCommRiRecord(recordToUpdate: DaascDdnClass): number {
    let numUpdated: number = 0;
    const index = this.getIndexForRecord(recordToUpdate);
    if (index >= 0) {
        this.commRiList[index] = recordToUpdate;
        numUpdated = 1;
    }
    return numUpdated;
  }

  private getIndexForRecord(recordToFind: DaascDdnClass): number {
    let index: number = -1;
    for (let i: number = 0; i < this.commRiList.length; i++) {
        if (this.commRiList[i].id === recordToFind.id) {
            index = i;
            break;
        }
    }
    return index;
  }
}
