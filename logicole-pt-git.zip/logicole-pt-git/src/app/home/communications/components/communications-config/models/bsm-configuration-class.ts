export class BsmConfigurationClass {
    public dlaSequenceNumber: string;
}
