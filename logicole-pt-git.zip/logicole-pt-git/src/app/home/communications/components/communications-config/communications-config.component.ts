import { Component, OnInit, Input } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { CommunicationsConfigurationService } from './services/communications-configuration.service';
import { InventoryReconciliationType } from './models/inventory-reconciliation-type';
import { LabelValue } from './models/label-value';

import { LcTableSettings } from '../../../../common-components/lc-table/models/lc-table-settings';
import { LcTableColumn } from '../../../../common-components/lc-table/models/lc-table-column';
import { LcLinkCellComponent } from '../../../../common-components/lc-table/lc-link-cell/lc-link-cell.component';
import { LcButtonCellComponent } from '../../../../common-components/lc-table/lc-button-cell/lc-button-cell.component';
import { LcButtonCallbackEvent } from '../../../../common-components/lc-table/models/lc-button-callback-event';
import { CommsUtilityService } from '../../services/comms-utility.service';
import { LoggerService } from '../../../../services/logger/logger.service';
import { NotificationService } from '../../../../services/notification.service';
import { DaascDdnClass } from '../communications-config/models/daasc-ddn-class';

@Component({
  selector: 'communications-config',
  viewProviders: [ CommunicationsConfigurationService, ],
  templateUrl: './communications-config.component.html',
  styleUrls: ['./communications-config.component.scss']
})
export class CommunicationsConfigComponent implements OnInit {
  @Input() public selectedConfig: string;
  @Input() public configLabelValues: LabelValue[];

  fastdataRows = [
    {header: '17321DMO', recdate: '11/17/2017 09:19:58', acttypecddes: ''},
    {header: '17314DMM', recdate: '11/10/2017 09:22:10', acttypecddes: 'FX - SKIPPED FASTDATA EXPENDITURE FILE'},
    {header: '1730DLL', recdate: '11/17/2017 09:23:33', acttypecddes: 'FX - SKIPPED FASTDATA EXPENDITURE FILE'},
    {header: '17431DMO', recdate: '01/24/2018 05:19:58', acttypecddes: ''},
    {header: '17564DMM', recdate: '01/10/2018 08:22:10', acttypecddes: 'FX - SKIPPED FASTDATA EXPENDITURE FILE'},
    {header: '1738DLL', recdate: '12/27/2017 02:23:33', acttypecddes: 'FX - SKIPPED FASTDATA EXPENDITURE FILE'}
  ];

  private manageCommRiForm: FormGroup;

  public communicationsConfigForm: FormGroup;
  public currentConfig: string;
  public ipAddress: string;
  public loginId: string;
  public password: string;
  public field1: string;
  public field2: string;
  public field3: string;
  public currentLabelValues: LabelValue[];

  public lcFastdataTableColumns: any;
  public lcFastdataTableSettings: LcTableSettings;
  public lcFastdataTableData: Array<any> = this.fastdataRows;

  public lcCommRiTableColumns: any;
  public lcCommRiTableSettings: LcTableSettings;
  public lcCommRiTableData: Array<DaascDdnClass> = [];
  public selectedCommRiRow: DaascDdnClass;
  public viewCommRiDetailsMode: boolean = false;

  constructor(private communicationsConfigService: CommunicationsConfigurationService,
              private fb: FormBuilder,
              private commsUtilityService: CommsUtilityService,
              private notify: NotificationService,
              private logger: LoggerService) {
    this.createForm();
  }

  ngOnInit() {
    this.currentConfig = this.communicationsConfigService.getConfigurationCodeList()[0];

    this.currentConfig = this.selectedConfig;

    this.currentLabelValues = this.configLabelValues;

    this.initializeTable();
    this.loadCommRiData();
  }

  setManageCommRiForm(): void {
     this.manageCommRiForm.reset({
        type: this.selectedCommRiRow.type,
        commRI: this.selectedCommRiRow.commRI
    });
  }

  // ng-smart-table stuff
  private initializeTable() {
    this.lcFastdataTableSettings = new LcTableSettings();
    this.lcFastdataTableSettings.cardId = 'fastdataHeaderTable';
    this.lcFastdataTableSettings.cardTitle = 'FASTDATA Header Table';
    this.lcFastdataTableSettings.cardTitleIcon = 'fa fa-car';
    this.lcFastdataTableSettings.tableAttr.id = 'fastdataHeaderTableAttr';

    this.lcFastdataTableSettings.cardShowDownload = false;
    this.lcFastdataTableSettings.cardShowGlobalSearch = false;
    this.lcFastdataTableSettings.cardShowRefresh = false;
    this.lcFastdataTableSettings.tableHideSubHeader = false;

    this.lcFastdataTableColumns = {
      header: this.commsUtilityService.createTextColumn('Header'),
      recdate: this.commsUtilityService.createDateColumn('Date Received'),
      acttypecddes: this.commsUtilityService.createTextColumn('Act Type CD - Description'),
    };

    this.lcCommRiTableSettings = new LcTableSettings();
    this.lcCommRiTableSettings.cardId = 'commRiTable';
    this.lcCommRiTableSettings.cardTitle = 'Comm Ri Table';
    this.lcCommRiTableSettings.cardTitleIcon = 'fa fa-phone';
    this.lcCommRiTableSettings.tableAttr.id = 'commRiTableAttr';

    this.lcCommRiTableSettings.cardShowDownload = false;
    this.lcCommRiTableSettings.cardShowGlobalSearch = false;
    this.lcCommRiTableSettings.cardShowRefresh = false;
    this.lcCommRiTableSettings.tableHideSubHeader = false;

    this.lcCommRiTableColumns = {
      editRecord: this.createButtonColumn('editCommRi', '', 'Edit Comm Ri', 'fa-pencil'),
      type: this.commsUtilityService.createTextColumn('Type'),
      commRI: this.commsUtilityService.createTextColumn('Comm Ri')
    };
  }

  private createButtonColumn(buttonId: string, columnTitle: string, buttonToolTip: string, iconName: string) {
    const col: LcTableColumn = new LcTableColumn();
    col.title = columnTitle;
    col.type = 'custom';
    col.renderComponent = LcButtonCellComponent;
    col.width = '1%';
    col.filter = false;
    col.onComponentInitFunction = ((instance: LcButtonCellComponent) => {
        instance.buttonId = buttonId;
        instance.buttonToolTip = buttonToolTip;
        instance.iconName = iconName;
        instance.callbackFunction.subscribe((buttonCallbackEvent: LcButtonCallbackEvent) => {
            this.processButtonCallbackEvent(buttonCallbackEvent);
        });
    });
    return col;
  }

  private processButtonCallbackEvent(buttonCallbackEvent: LcButtonCallbackEvent): void {
            this.logger.debug('editCommRi button was clicked: ' + JSON.stringify(buttonCallbackEvent.rowData, null, 3));
            this.selectedCommRiRow = buttonCallbackEvent.rowData;
            this.setManageCommRiForm();
            this.viewCommRiDetailsMode = true;
  }

  private commRiClicked(rowData: DaascDdnClass) {
    this.logger.debug('Comm Ri View Details link was clicked: ' + JSON.stringify(rowData, null, 3));
    this.selectedCommRiRow = rowData;
    this.viewCommRiDetailsMode = true;
  }

  public onSaveClicked(): void {

    const model = this.manageCommRiForm.value;
    const updatedRecord: DaascDdnClass = {
        id: this.selectedCommRiRow.id,
        type: this.selectedCommRiRow.type,
        commRI: model.commRI,
    };

    this.logger.debug('onSaveClicked: got this back: ' + JSON.stringify(updatedRecord, null, 3));

    // update record via service
    this.communicationsConfigService.updateCommRiRecord(updatedRecord);
    this.notify.successMsg('Record was updated successfully.');

    this.loadCommRiData();
    this.viewCommRiDetailsMode = false;
  }

  public onCancelClicked(): void {
    this.viewCommRiDetailsMode = false;
  }

  private loadCommRiData(): void {
    this.lcCommRiTableData = [];
    const tableData: Array<DaascDdnClass> = this.communicationsConfigService.getCommRiForDodaac('ABC');
    this.lcCommRiTableData = this.communicationsConfigService.getCommRiForDodaac('ABC');
  }

  public isInEditMode(): boolean {
    return this.viewCommRiDetailsMode;
  }
// end ng-smart-table stuff

  public createForm(): any {
    console.log('creating form');
    this.communicationsConfigForm = this.fb.group( {
      dodaac: [ 'FM3500', Validators.required ],
      siteType: 'AF',
      showBsmConfigurationPanel: false,
      showCarouselConfigurationPanel: false,
      showDeamsConfigurationPanel: false,
      showGafsConfigurationPanel: false,
      showDcdConfigurationPanel: false,
      showDfasConfigurationPanel: false,
      showFastdataConfigurationPanel: false,
      showFoaExcessConfigurationPanel: false,
      showGfebsConfigurationPanel: false,
      showSabrsConfigurationPanel: false,
      showVaFmsConfigurationPanel: false,
      showVaIfrrInrrConfigurationPanel: false,
      showVaEcmsConfigurationPanel: false,
      showInventoryReconciliationPanel: false,
      showSendPanel: false,
      showActivePanel: false,
      showTransmitPcTransactionPanel: false,
      showUsesFinancialReportingPanel: false,
      showCommRiPanel: false,
      showIpAddressAndLoginFields: true,
      ipAddressOrUrl: '0.0.0.0',
      loginId: 'test_user_',
      password: 'test_pwd',
      showEmailField: false,
      emailAddress: '',
      communicationInfo1: 'Field one',
      communicationInfo2: 'Field two',
      communicationInfo3: 'Field three',
      communicationInfo1Label: 'Field 1',
      communicationInfo2Label: 'Field 2',
      communicationInfo3Label: 'Field 3',
      canSend: false,
      isActive: false,
      canTransmitPcTransaction: false,
      usesFinancialReporting: false,
      inventoryReconciliation: InventoryReconciliationType.AsRequired,
      updatedBy: '',
      // lastUpdated: null,
    });

    this.manageCommRiForm = this.fb.group({
      type: new FormControl({value: '', disabled: true}),
      commRI: new FormControl({value: ''})
  });

  }

  public onConfigClicked(cfgName: string): void {
    this.currentConfig = cfgName;
  }

  public showSendPanel(): boolean {
    return true;
  }

  public showActivePanel(): boolean {
    let show = false;
    switch (this.currentConfig) {
      case 'DEAMS':
      case 'DFAS':
      case 'FMS':
      case 'GFEBS':
        show = true;
        break;
    }
    return show;
  }

  public showTransmitPcTransactionPanel(): boolean {
    let show = false;
    switch (this.currentConfig) {
      case 'DFAS':
        show = true;
        break;
    }
    return show;
  }

  public showFinancialReportingPanel(): boolean {
    let show = false;
    switch (this.currentConfig) {
      case 'DEAMS':
      case 'DFAS':
      case 'GFEBS':
        show = true;
        break;
    }
    return show;
  }

  public showInventoryReconciliationPanel(): boolean {
    let show = false;
    switch (this.currentConfig) {
      case 'BSM':
        show = true;
        break;
    }
    return show;
  }

  public showCommRiPanel(): boolean {
    let show = false;
    switch (this.currentConfig) {
      case 'DFAS':
      case 'FOA EXCESS':
        show = true;
        break;
    }
    return show;
  }

  public showFastdataGridPanel(): boolean {
    let show = false;
    switch (this.currentConfig) {
      case 'FASTDATA':
        show = true;
        break;
    }
    return show;
  }
}
