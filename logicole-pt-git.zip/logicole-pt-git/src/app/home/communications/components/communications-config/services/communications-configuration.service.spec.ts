import { TestBed, inject } from '@angular/core/testing';

import { CommunicationsConfigurationService } from './communications-configuration.service';
import { CommsUtilityService } from '../../../services/comms-utility.service';
import { LoggerService } from '../../../../../services/logger/logger.service';

describe('CommunicationsConfigurationService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CommunicationsConfigurationService, LoggerService, CommsUtilityService]
    });
  });

  it('should be created', inject([CommunicationsConfigurationService], (service: CommunicationsConfigurationService) => {
    expect(service).toBeTruthy();
  }));
});
