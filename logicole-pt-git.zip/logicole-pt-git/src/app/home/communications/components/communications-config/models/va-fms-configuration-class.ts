export class VaFmsConfigurationClass {
    public nextBlockNumber: string;
}
