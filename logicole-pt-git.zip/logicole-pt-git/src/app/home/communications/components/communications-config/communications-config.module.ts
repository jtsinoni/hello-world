import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ModelsModule } from '../../../jmlfdc-admin/system-notification/models/models.module';
import { ServicesModule } from '../../../jmlfdc-admin/system-notification/services/services.module';
import { CommunicationsConfigComponent } from './communications-config.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LcTableModule } from '../../../../common-components/lc-table/lc-table.module';
import { CommsUtilityService } from '../../services/comms-utility.service';

@NgModule({
  imports: [
    CommonModule,
    ModelsModule,
    ServicesModule,
    LcTableModule,
    FormsModule,
    ReactiveFormsModule,
  ],
  declarations: [
    CommunicationsConfigComponent,
  ],
  exports: [
    CommunicationsConfigComponent,
  ],
  providers: [CommsUtilityService]
})
export class CommunicationsConfigModule { }
