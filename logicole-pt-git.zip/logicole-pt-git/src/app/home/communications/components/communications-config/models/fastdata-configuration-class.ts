import { FastdataInfoClass } from './fastdata-info-class';

export class FastdataConfigurationClass {
    public fasdataInfo: FastdataInfoClass[];
}
