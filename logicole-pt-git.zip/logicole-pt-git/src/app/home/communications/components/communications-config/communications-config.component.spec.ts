import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {NO_ERRORS_SCHEMA} from '@angular/core';

import {RouterTestingModule} from '@angular/router/testing';
import {HttpTestModule} from '../../../../common-components/test/http-test.module';
import {ToastrModule} from 'ngx-toastr';
import {NavigationTestModule} from '../../../../common-components/test/navigation-test/navigation-test.module';

import { CommunicationsConfigComponent } from './communications-config.component';
import { CommunicationsConfigurationService } from './services/communications-configuration.service';
import { CommsUtilityService } from '../../services/comms-utility.service';
import { LoggerService } from '../../../../services/logger/logger.service';
import { NotificationService } from '../../../../services/notification.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LcTableModule } from '../../../../common-components/lc-table/lc-table.module';
import { ModelsModule } from '../../../jmlfdc-admin/system-notification/models/models.module';
import { ServicesModule } from '../../../jmlfdc-admin/system-notification/services/services.module';

describe('CommunicationsConfigComponent', () => {
  let component: CommunicationsConfigComponent;
  let fixture: ComponentFixture<CommunicationsConfigComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        ReactiveFormsModule,
        LcTableModule,
        ModelsModule,
        ServicesModule,
        RouterTestingModule,
        HttpTestModule.forRoot(),
        ToastrModule.forRoot(),
        NavigationTestModule.forRoot(),
      ],
      declarations: [ CommunicationsConfigComponent ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
      providers: [
        CommunicationsConfigurationService,
        FormBuilder,
        CommsUtilityService,
        NotificationService,
        LoggerService
      ]

    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommunicationsConfigComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
