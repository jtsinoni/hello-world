export class FastdataInfoClass {
    public header: string;
    public receivedDate: Date;
    public actTypeCodeAndDescription: string;
}
