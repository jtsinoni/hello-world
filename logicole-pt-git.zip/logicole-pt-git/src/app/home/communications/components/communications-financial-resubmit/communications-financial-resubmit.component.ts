import { Component, OnInit, ViewChild } from '@angular/core';
import { LoggerService } from '../../../../services/logger/logger.service';
import { StateNavigationService } from 'app/services/state-navigation.service';
import { GridOptions } from 'ag-grid/main';
import { CommunicationsSearchResult } from '../../comms-common-models/communications-search-result';
import { CommsUtilityService } from '../../services/comms-utility.service';
import { CommunicationsFinancialResubmitService } from './services/communications-financial-resubmit.service';

import { NotificationService } from '../../../../services/notification.service';
import { MessageBoxComponent } from '../../../../common-components/panels/message-box/message-box.component';
import { MessageBoxConfiguration } from '../../../../models/message-box-configuration';
import { MessageBoxIcon } from '../../../../models/message-box-icon';

import { LcGridCardSettings  } from '../../../../common-components/lc-grid/models/lc-grid-card-settings';
import { LcButtonLinkCellComponent } from '../../../../common-components/lc-grid/lc-button-link-cell/lc-button-link-cell.component';
import { LcGridButtonCellComponent } from '../../../../common-components/lc-grid/lc-button-cell/lc-button-cell.component';

@Component({
  selector: 'lc-communications-financial-resubmit',
  templateUrl: './communications-financial-resubmit.component.html',
  styleUrls: ['./communications-financial-resubmit.component.scss']
})
export class CommunicationsFinancialResubmitComponent implements OnInit {
  @ViewChild('confirmationDialog') messageBox: MessageBoxComponent;

  private gridApi;
  private gridColumnApi;

  public gridCardSettings: LcGridCardSettings = {
    cardId: 'communicationsFinancialResubmitRecords',
    cardShowDownload: true,
    cardShowGlobalSearch: true,
    cardShowHeader: true,
    cardShowRefresh: true,
    cardTitle: 'Communications Records',
    cardTitleIcon: 'fa fa-phone',
    cardDownloadCsvFilename: 'communicationsFinancialResubmitRecords.csv',
  };

  public gridOptions: GridOptions = {
    floatingFilter: true,
    pagination: true,
    paginationPageSize: 20,
    domLayout: 'autoHeight',
    enableColResize: true,
    enableSorting: true,
    // rowHeight: 25,  // 25 is the default
    rowSelection: 'multiple',
    debug: true,

    defaultColDef: {
      // make every column non-editable
      editable: false,
      // make every column use 'text' filter by default
    },

    context: {componentParent: this},

    columnDefs: [
      {
        headerName: 'Call/Sequence/Block Number',
        headerTooltip: 'Call Number',
        field: 'callNumber',
        tooltipField: 'callNumber',
        headerCheckboxSelection: true,
        headerCheckboxSelectionFilteredOnly: true,
        checkboxSelection: true
      },
      {
        headerName: 'Contract Number',
        headerTooltip: 'Contract Number',
        field: 'contractNumber',
        tooltipField: 'contractNumber'
      },
      {
        headerName: 'Audit Date',
        headerTooltip: 'Audit Date',
        field: 'auditDate',
        tooltipField: 'auditDate',
        filter: 'agDateColumnFilter',
      },
      {
        headerName: 'Process Code',
        headerTooltip: 'Process Code',
        field: 'processCode',
        tooltipField: 'processCode',
      },
      {
        headerName: 'Txn Type TP Code',
        headerTooltip: 'Txn Type TP Code',
        field: 'transactionTypeTpcode',
        tooltipField: 'transactionTypeTpcode'
      },
      {
        headerName: 'Direction',
        headerTooltip: 'Direction',
        field: 'direction',
        tooltipField: 'direction'
      },
      {
        headerName: 'Channel ID',
        headerTooltip: 'Channel ID',
        field: 'channelId',
        tooltipField: 'channelId',
      },
      {
        headerName: 'Shipment ID',
        headerTooltip: 'Shipment ID',
        field: 'shipmentId',
        tooltipField: 'shipmentId',
      },
      {
        headerName: 'User ID',
        headerTooltip: 'User ID',
        field: 'userId',
        tooltipField: 'userId',
      },
      {
        headerName: 'ID',
        headerTooltip: 'ID',
        field: 'id',
        tooltipField: 'id',
        hide: true,
      },
      {
        headerName: 'Method',
        headerTooltip: 'Method',
        field: 'method',
        tooltipField: 'method',
        hide: true,
      },
      {
        headerName: 'Prime Vendor Status',
        headerTooltip: 'Prime Vendor Status',
        field: 'primeVendorStatus',
        tooltipField: 'primeVendorStatus',
        hide: true,
      },
      {
        headerName: 'Process Text',
        headerTooltip: 'Process Text',
        field: 'processText',
        tooltipField: 'processText',
        hide: true,
      },
      {
        headerName: 'Transaction Type Ext',
        headerTooltip: 'Transaction Type Ext',
        field: 'transactionTypeExtension',
        tooltipField: 'transactionTypeExtension',
        hide: true,
      },
      {
        headerName: 'Inbound Filename',
        headerTooltip: 'Inbound Filename',
        field: 'inboundFilename',
        tooltipField: 'inboundFilename',
        hide: true
      },
      {
        headerName: 'Source of Supply',
        headerTooltip: 'Source of Supply',
        field: 'sosCode',
        tooltipField: 'sosCode',
        hide: true,
      },
      {
        headerName: 'Resubmit Indicator',
        headerTooltip: 'Resubmit Indicator',
        field: 'resubmitIndicator',
        tooltipField: 'resubmitIndicator',
        hide: true,
      },
      {
        headerName: 'Application ID',
        headerTooltip: 'Application ID',
        field: 'applicationId',
        tooltipField: 'applicationId',
        hide: true,
      },
      {
        headerName: 'Target Filename',
        headerTooltip: 'Target Filename',
        field: 'targetFilename',
        tooltipField: 'targetFilename',
        hide: true,
      },
      {
        headerName: 'Dismiss Error Indicator',
        headerTooltip: 'Dissmiss Error Indicator',
        field: 'dismissErrorIndicator',
        tooltipField: 'dismissErrorIndicator',
        hide: true,
      },
      {
        headerName: 'Dismiss Error User ID',
        headerTooltip: 'Dismiss Error User ID',
        field: 'dismissErrorUserId',
        tooltipField: 'dismissErrorUserId',
        hide: true,
      },
      {
        headerName: 'Dismiss Error Date',
        headerTooltip: 'Dismiss Error Date',
        field: 'dismissErrorDate',
        tooltipField: 'dismissErrorDate',
        hide: true,
      },
      {
        headerName: 'Dismissable Error Indicator',
        headerTooltip: 'Dismissable Error Indicator',
        field: 'dismissableErrorIndicator',
        tooltipField: 'dismissableErrorIndicator',
        hide: true,
      },
    ],
  };

  minDate: Date = new Date();
  maxDate: Date = new Date();
  bsValue: Date = new Date();
  bsRangeValue: any = [];

  public showResubmitButton: boolean = false;

  public communicationsResubmitDialogTitle: string;
  public communicationsResubmitDialogMessage: string;
  public showCommunicationsResubmitDialog: boolean = false;
  public communicationsResubmitDialogContent: string;

  private recordArray: CommunicationsSearchResult[];

  msgBoxConfig: MessageBoxConfiguration = {
    showCloseButton: false,
    showOkCancelButtons: false,
    showYesNoButtons: true,
    allowBackdropClickToClose: false,
    allowEscapeToClose: false,
    showLargeModal: true,
    icon: MessageBoxIcon.informationIcon,
  };

  constructor(private communicationsFinancialResubmitService: CommunicationsFinancialResubmitService,
    private commsUtilityService: CommsUtilityService,
    private logger: LoggerService,
    private navigationService: StateNavigationService,
    private notify: NotificationService) {
  }

  ngOnInit() {
    this.logger.info(`RESUBMIT -ngOnInit()`);
    this.minDate.setDate(this.minDate.getDate() - 200);
    this.maxDate.setDate(this.minDate.getDate() + 7);
    this.bsRangeValue = [this.minDate, this.maxDate];

    this.getSearchResults();
}

  public getSearchResults(): void {
    this.loadData();
  }

  public loadData(): void {
    this.logger.debug(`In loadData()  -  bsRangeValue = ${this.bsRangeValue}`);
    this.communicationsFinancialResubmitService.setTableData(
      this.communicationsFinancialResubmitService.getCommunicationsSearchResults(this.bsRangeValue[0], this.bsRangeValue[1]));
  }

  public getSearchTableData(): Array<CommunicationsSearchResult> {
    return this.communicationsFinancialResubmitService.getTableData();
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;

    this.logger.info(`In onGridReady`);

    params.api.setRowData(this.communicationsFinancialResubmitService.getTableData());
    params.api.sizeColumnsToFit();


    // just here to show how to listen for an event - in this case a column event
    // params.api.addGlobalListener(function (type, event) {
    //  if (type.indexOf("column") >= 0) {
    // console.log("Got column event: ", event);
    //  }
    // });
  }

  onSelectionChanged(event: any) {
    this.recordArray = this.gridOptions.api.getSelectedRows();

    if (this.recordArray.length > 0) {
      this.showResubmitButton = true;
    } else {
      this.showResubmitButton = false;
    }

    for (let i = 0; i < this.recordArray.length; i++) {
      this.logger.info(`Call Number: ${this.recordArray[i].callNumber}`);
    }
  }

  onGridSizeChanged(params) {
    params.api.sizeColumnsToFit();
  }

  private onModelUpdated() {
  }

  onRefreshClick(param: string = '') {
    this.gridApi.setRowData([]);
    this.logger.debug(`communications-financial-resubmit: onRefreshClick(${param})`);
    this.getSearchResults();
    this.gridApi.setRowData(this.communicationsFinancialResubmitService.getTableData());

    this.showResubmitButton = false;
  }

/*
  private selectAllRows() {
    this.logger.debug(`communications-financial-resubmit selectAllRows`);
    this.gridOptions.api.selectAll();
  }
*/

  onResubmitClicked(): void {
    this.showCommunicationsResubmitDialog = true;
    this.communicationsResubmitDialogTitle = 'Resubmit Selected Records';
    this.communicationsResubmitDialogMessage = 'Do you want to perform a financial resubmit on the ' +
      (this.recordArray.length > 1 ? this.recordArray.length : '') +
      ' selected ' + (this.recordArray.length > 1 ? 'records' : 'record') + '?';

    this.messageBox.showDialog();
  }

  onMessageBoxButtonClicked(buttonThatWasClicked: string): void {
    switch (buttonThatWasClicked) {
        case 'Yes':
            this.notify.successMsg(this.recordArray.length +
              (this.recordArray.length > 1 ? ' records were' : ' record was') +
              ' resubmitted.');
            this.onRefreshClick();
            break;
        case 'No':
            this.notify.infoMsg('Resubmit cancelled.');
            break;
    }

  this.messageBox.hideDialog();
  }
}
