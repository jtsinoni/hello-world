import { TestBed, inject } from '@angular/core/testing';

import { CommunicationsFinancialResubmitService } from './communications-financial-resubmit.service';
import { LoggerService } from '../../../../../services/logger/logger.service';
import { CommsUtilityService } from '../../../services/comms-utility.service';

describe('CommunicationsFinancialResubmitService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CommunicationsFinancialResubmitService, LoggerService, CommsUtilityService]
    });
  });

  it('should be created', inject([CommunicationsFinancialResubmitService], (service: CommunicationsFinancialResubmitService) => {
    expect(service).toBeTruthy();
  }));
});
