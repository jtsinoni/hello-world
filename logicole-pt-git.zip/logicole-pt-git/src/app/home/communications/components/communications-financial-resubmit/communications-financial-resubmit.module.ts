import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';
import {Ng2SmartTableModule} from 'ng2-smart-table';
import {AgGridModule} from 'ag-grid-angular';
import {PipesModule} from '../../../../pipes/pipes.module';
import {CommonComponentsModule} from '../../../../common-components/common-components.module';

import { ServicesModule  } from './services/services.module';
import { CommunicationsFinancialResubmitComponent  } from './communications-financial-resubmit.component';
import { CommunicationsFinancialResubmitRouterModule  } from './communications-financial-resubmit.router';
import { CommsCommonComponentsModule } from 'app/home/communications/comms-common-components/comms-common-components.module';
import { CommsUtilityService } from '../../services/comms-utility.service';


@NgModule({
    imports: [
      CommonModule,
      FormsModule,
      Ng2SmartTableModule,
      AgGridModule,
      PipesModule,
      CommonComponentsModule,
      CommunicationsFinancialResubmitRouterModule,
      CommsCommonComponentsModule,
      ServicesModule,
    ],
    declarations: [
        CommunicationsFinancialResubmitComponent,
    ],
    exports: [
        CommunicationsFinancialResubmitComponent,
        CommunicationsFinancialResubmitRouterModule,
        CommsCommonComponentsModule,
        ServicesModule,
    ],
    providers: [CommsUtilityService]
  })
  export class CommunicationsFinancialResubmitModule {
  }
