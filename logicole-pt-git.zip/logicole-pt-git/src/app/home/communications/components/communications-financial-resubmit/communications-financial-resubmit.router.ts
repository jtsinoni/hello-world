import { NgModule } from '@angular/core';

import { RootModule, UIRouterModule } from '@uirouter/angular';
import { CommunicationsFinancialResubmitStates } from './communications-financial-resubmit-states';

const communicationsFinancialResubmitRoutes: RootModule = {

  states: [
    CommunicationsFinancialResubmitStates.COMMUNICATIONS_FINANCIAL_RESUBMIT_VIEW,
  ]
};

  @NgModule({
    imports: [UIRouterModule.forChild(communicationsFinancialResubmitRoutes)],
    exports: [UIRouterModule]
  })
  export class CommunicationsFinancialResubmitRouterModule {

  }
