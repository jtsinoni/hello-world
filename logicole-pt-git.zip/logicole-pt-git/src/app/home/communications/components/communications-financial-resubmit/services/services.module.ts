import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CommunicationsFinancialResubmitService } from './communications-financial-resubmit.service';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [],
  providers: [
    CommunicationsFinancialResubmitService,
  ]
})
export class ServicesModule { }
