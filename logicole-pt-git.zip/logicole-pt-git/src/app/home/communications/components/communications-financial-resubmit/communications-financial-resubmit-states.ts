import {Ng2StateDeclaration} from '@uirouter/angular';
import {RouteConstants} from '../../../../constants/route.constants';
import {CommunicationsFinancialResubmitComponent} from './communications-financial-resubmit.component';

export class CommunicationsFinancialResubmitStates {

  static COMMUNICATIONS_FINANCIAL_RESUBMIT_VIEW: Ng2StateDeclaration = {
    url: RouteConstants.COMMUNICATIONS_FINANCIAL_RESUBMIT.url,
    name: RouteConstants.COMMUNICATIONS_FINANCIAL_RESUBMIT.name,
    component: CommunicationsFinancialResubmitComponent,
    data: {'route': RouteConstants.COMMUNICATIONS_FINANCIAL_RESUBMIT}
  };
}
