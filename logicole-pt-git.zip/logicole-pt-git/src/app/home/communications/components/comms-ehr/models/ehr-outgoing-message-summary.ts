export class EhrOutgoingMessageSummary {
    public beginDate: Date;
    public endDate: Date;
    public queuedCount: number;
    public sentCount: number;
    public errorCount: number;
}
