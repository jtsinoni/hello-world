export class ManageCustomersTableRow {
    customerAccountId: string;
    customerName: string;
    sendCatalog: boolean;
    sendEquipment: boolean;
    lastCatalogRequestDate: Date;
    lastEquipmentRequestDate: Date;

    constructor() {

    }
}
