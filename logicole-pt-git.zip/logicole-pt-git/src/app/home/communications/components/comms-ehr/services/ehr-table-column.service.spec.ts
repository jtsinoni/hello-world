import { TestBed, inject } from '@angular/core/testing';

import { LcTableColumn } from '../../../../../common-components/lc-table/models/lc-table-column';
import { LcCheckboxCellComponent } from '../../../../../common-components/lc-table/lc-checkbox-cell/lc-checkbox-cell.component';
import { LcDateCellComponent } from '../../../../../common-components/lc-table/lc-date-cell/lc-date-cell.component';

import { EhrTableColumnService } from './ehr-table-column.service';

describe('EhrTableColumnService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [EhrTableColumnService]
    });
  });

  it('should be created', inject([EhrTableColumnService], (service: EhrTableColumnService) => {
    expect(service).toBeTruthy();
  }));
});
