import { Component, OnInit, EventEmitter, Input, Output } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LoggerService } from '../../../../../../services/logger/logger.service';
import { EhrService } from '../../services/ehr.service';
import { EhrSystemRecord } from '../../models/ehr-system-record';
import { EhrSystemRecordTableRow } from '../../models/ehr-system-record-table-row';
import { LcTableSettings } from '../../../../../../common-components/lc-table/models/lc-table-settings';
import { ManageCustomersTableRow } from '../../models/manage-customers-table-row';
import { EhrTableColumnService } from '../../services/ehr-table-column.service';
import { LcTableColumn } from '../../../../../../common-components/lc-table/models/lc-table-column';
import { LcButtonCellComponent } from '../../../../../../common-components/lc-table/lc-button-cell/lc-button-cell.component';
import { LcButtonCallbackEvent } from '../../../../../../common-components/lc-table/models/lc-button-callback-event';
import { NotificationService } from '../../../../../../services/notification.service';
import { ManageMessagesTableRow } from '../../models/manage-messages-table-row';
import { CommsUtilityService } from '../../../../services/comms-utility.service';
import { EhrStateService } from '../../services/ehr-state.service';
import { StateNavigationService } from '@lc-services/*';
import { RouteConstants } from '../../../../../../constants/route.constants';
import { LcLinkCellComponent } from 'app/common-components/lc-table/lc-link-cell/lc-link-cell.component';
import { UIRouterModule } from '@uirouter/angular';

@Component({
    selector: 'lc-manage-messages',
    templateUrl: './manage-messages.component.html',
    styleUrls: ['./manage-messages.component.scss'],
})
export class ManageMessagesComponent implements OnInit {

    public manageMessagesColumns: any;
    public manageMessagesTableSettings: LcTableSettings;
    public manageMessagesTableData: Array<ManageMessagesTableRow> = [];

    // public showOrderLines: boolean;
    // public selectedMessageTableRow: ManageMessagesTableRow;

    public minDate: Date = new Date();
    public maxDate: Date = new Date();
    public bsValue: Date = new Date();
    public bsRangeValue: any = [];

    constructor(private logger: LoggerService,
                private ehrService: EhrService,
                public ehrStateService: EhrStateService,
                private notify: NotificationService,
                private commsUtilService: CommsUtilityService,
                private navigationService: StateNavigationService) { }

    ngOnInit() {
        this.initializeTable();
        this.minDate.setDate(this.minDate.getDate() - 30);
        this.maxDate.setDate(this.minDate.getDate() + 7);
        this.bsRangeValue = [this.minDate, this.maxDate];
        // this.showOrderLines = false;
        this.loadData();
        this.ehrStateService.MessageRecord = null;
    }

    public onBackClicked(): void {
        this.navigationService.navigateToState(RouteConstants.COMMUNICATIONS_EHR);
    }

    private initializeTable(): void {
        this.manageMessagesTableSettings = new LcTableSettings();
        this.manageMessagesTableSettings.cardId = 'ehrMessages';
        this.manageMessagesTableSettings.cardTitle = 'Manage Messages';
        this.manageMessagesTableSettings.cardTitleIcon = 'fa fa-phone';
        this.manageMessagesTableSettings.tableAttr.id = 'ehrMessagesTableAttr';

        this.manageMessagesTableSettings.cardShowDownload = false;
        this.manageMessagesTableSettings.cardShowGlobalSearch = false;
        this.manageMessagesTableSettings.cardShowRefresh = true;
        this.manageMessagesTableSettings.tableHideSubHeader = false;

        this.manageMessagesColumns = {
            resubmitRecord: this.createButtonColumn('resubmit', '', 'Resubmit Message', 'fa-send'),
            dodaac: this.commsUtilService.createTextColumn('Dodaac'),
            customerAccountId: this.commsUtilService.createTextColumn('Customer Account Id'),
            messageIdentifier: this.createMessageIdentifierLinkColumn(),
            recordStatus: this.commsUtilService.createTextColumn('Record Status'),
            poNumber: this.commsUtilService.createTextColumn('Purchase Order Number'),
            poStatusType: this.commsUtilService.createTextColumn('Status Type'),
            orderDate: this.commsUtilService.createDateColumn('Order Date'),
            sentDate: this.commsUtilService.createDateColumn('Sent Date'),
        };
    }

    loadData(): void {
        this.manageMessagesTableData = this.ehrService.getOutgoingMessages(this.ehrStateService.EhrSystemRecord.guid,
                                      this.bsRangeValue[0], this.bsRangeValue[1], this.ehrStateService.EhrSystemRecord.messageSummary);
    }

    private createButtonColumn(buttonId: string, columnTitle: string, buttonToolTip: string, iconName: string) {
        const col: LcTableColumn = new LcTableColumn();
        col.title = columnTitle;
        col.type = 'custom';
        col.renderComponent = LcButtonCellComponent;
        col.width = '1%';
        col.filter = false;
        col.onComponentInitFunction = ((instance: LcButtonCellComponent) => {
            instance.buttonId = buttonId;
            instance.buttonToolTip = buttonToolTip;
            instance.iconName = iconName;
            instance.callbackFunction.subscribe((buttonCallbackEvent: LcButtonCallbackEvent) => {
                this.processButtonCallbackEvent(buttonCallbackEvent);
            });
        });
        return col;
    }

    private createMessageIdentifierLinkColumn(): LcTableColumn {
        const col: LcTableColumn = new LcTableColumn();
        col.title = 'Message Identifier';
        col.type = 'custom';
        col.renderComponent = LcLinkCellComponent;
        col.width = '15%';
        col.onComponentInitFunction = ((instance: LcLinkCellComponent) => {
            instance.cellSelected.subscribe((row) => {
                this.showMessageIdentifiersClicked(row);
            });
        });
        return col;

    }

    private processButtonCallbackEvent(buttonCallbackEvent: LcButtonCallbackEvent): void {
        const msgTableRow: ManageMessagesTableRow = buttonCallbackEvent.rowData;

        switch (buttonCallbackEvent.buttonId) {
            case 'resubmit':
                this.logger.debug('resubmit button was clicked: ' + JSON.stringify(msgTableRow, null, 3));
                this.notify.successMsg('Message ID ' + msgTableRow.messageIdentifier + ' was resubmitted.');
                break;
        }
    }

    private showMessageIdentifiersClicked(row: ManageMessagesTableRow) {
        this.ehrStateService.MessageRecord = row;
        this.logger.debug('showMessageIdentifiersClicked: ' + JSON.stringify(row, null, 3));
        // this.showOrderLines = true;
        this.navigationService.navigateToState(RouteConstants.COMMUNICATIONS_EHR_VIEW_MESSAGE_ORDER_LINES);
    }

    // private onBackOrderLinesClicked(): void {
    //     // this.showOrderLines = false;
    // }
}
