import { Injectable } from '@angular/core';
import { InternalCustomer } from 'app/home/communications/comms-common-models/internal-customer';
import { EhrSystemRecord } from 'app/home/communications/components/comms-ehr/models/ehr-system-record';
import { ManageEhrEndpointMode } from '../models/manage-ehr-endpoint-mode';
import { EhrSystemRecordTableRow } from 'app/home/communications/components/comms-ehr/models/ehr-system-record-table-row';
import { ManageMessagesTableRow } from 'app/home/communications/components/comms-ehr/models/manage-messages-table-row';

@Injectable()
export class EhrStateService {
    private availableCustomers: Array<InternalCustomer>;
    private ehrSystemRecord: EhrSystemRecordTableRow;
    private manageEhrEndpointMode: ManageEhrEndpointMode;
    private messageRecord: ManageMessagesTableRow;

    constructor() { }

    public get AvailableCustomers(): Array<InternalCustomer> {
        return this.availableCustomers;
    }

    public set AvailableCustomers(availableCustomers: Array<InternalCustomer>) {
        this.availableCustomers = availableCustomers;
    }

    public get EhrSystemRecord(): EhrSystemRecordTableRow {
        return this.ehrSystemRecord;
    }

    public set EhrSystemRecord(ehrSystemRecord: EhrSystemRecordTableRow) {
        this.ehrSystemRecord = ehrSystemRecord;
    }

    public get ManageEhrEndpointMode(): ManageEhrEndpointMode {
        return this.manageEhrEndpointMode;
    }

    public set ManageEhrEndpointMode(manageEhrEndpointMode: ManageEhrEndpointMode) {
        this.manageEhrEndpointMode = manageEhrEndpointMode;
    }

    public get MessageRecord(): ManageMessagesTableRow {
        return this.messageRecord;
    }

    public set MessageRecord(messageRecord: ManageMessagesTableRow) {
        this.messageRecord = messageRecord;
    }
}
