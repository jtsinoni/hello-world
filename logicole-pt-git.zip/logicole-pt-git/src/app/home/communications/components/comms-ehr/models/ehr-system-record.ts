import { InternalCustomer } from '../../../comms-common-models/internal-customer';
import { EhrOutgoingEndpoint } from './ehr-outgoing-endpoint';
import { EhrOutgoingMessageSummary } from './ehr-outgoing-message-summary';

export class EhrSystemRecord {
    public id: string;
    public guid: string;
    public dodaac: string;
    public name: string;
    public description?: string;
    public distinguishedName: string;
    public enabled: boolean;
    public deleted: boolean;
    public acknowledgementOutgoingEndpoint: EhrOutgoingEndpoint;
    public changeNoticeOutgoingEndpoint: EhrOutgoingEndpoint;
    public shippingNoticeOutgoingEndpoint: EhrOutgoingEndpoint;
    public assignedCustomers: Array<InternalCustomer>;
}
