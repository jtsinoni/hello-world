import { TestBed, inject } from '@angular/core/testing';

import { EhrStateService } from './ehr-state.service';

describe('EhrStateService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [EhrStateService]
    });
  });

  it('should be created', inject([EhrStateService], (service: EhrStateService) => {
    expect(service).toBeTruthy();
  }));
});
