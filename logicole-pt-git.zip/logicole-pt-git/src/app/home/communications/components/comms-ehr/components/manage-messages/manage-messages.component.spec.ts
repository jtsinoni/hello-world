import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageMessagesComponent } from './manage-messages.component';
import { FormsModule, ReactiveFormsModule, FormBuilder } from '@angular/forms';
import { Ng2SmartTableModule } from 'ng2-smart-table';
import { CommonComponentsModule } from 'app/common-components/common-components.module';
import { CommsCommonComponentsModule } from 'app/home/communications/comms-common-components/comms-common-components.module';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpTestModule } from 'app/common-components/test/http-test.module';
import { ToastrModule } from 'ngx-toastr';
import { NavigationTestModule } from 'app/common-components/test/navigation-test/navigation-test.module';
import { LoggerService } from 'app/services/logger/logger.service';
import { NotificationService } from 'app/services/notification.service';
import { EhrService } from 'app/home/communications/components/comms-ehr/services/ehr.service';
import { EhrStateService } from 'app/home/communications/components/comms-ehr/services/ehr-state.service';
import { StateNavigationService } from 'app/services/state-navigation.service';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { CommsUtilityService } from '../../../../services/comms-utility.service';
import { EhrSystemRecordTableRow } from 'app/home/communications/components/comms-ehr/models/ehr-system-record-table-row';

export class EhrStateServiceMock {

  constructor() {
  }

  public get EhrSystemRecord(): EhrSystemRecordTableRow {
    return {id: 'abcd',
            guid: 'xxxxx',
            dodaac: 'aaaaa',
            name: 'fred',
            description: 'desc',
            distinguishedName: 'frederick',
            enabled: true,
            deleted: false,
            acknowledgementOutgoingEndpoint: {enabled: true, url: 'https://ack.gov'},
            changeNoticeOutgoingEndpoint: {enabled: true, url: 'https://ack.gov'},
            shippingNoticeOutgoingEndpoint: {enabled: true, url: 'https://ack.gov'},
            assignedCustomers: [{
              'orgSerial': 5482,
              'customerAccountId': 'YMVPHN',
              'customerName': 'WINDER VAULT - PHARMACY',
              'displayName': 'YMVPHN - WINDER VAULT - PHARMACY',
              'pointOfCareSystemGuid': '82693049-2416-4f48-8630-466bf85026ea',
              'sendCatalogIndicator': true,
              'sendEquipmentIndicator': true,
              'lastCatalogRequestDate': new Date('2017-07-28T14:49:20.635'),
              'lastEquipmentRequestDate': new Date('0001-01-01T00:00:00')
            }],
            customerCount: 1,
            messageSummary: 'whatever'};
  }
}

export class EhrServiceMock {

  constructor() {
  }

  getOutgoingMessages(ehrSystemGuid: string, beginDate: Date, endDate: Date, msgSummary: string): any {
    return     [{
      'id': '333b',
      'guid': 'abcdefg',
      'dodaac': 'AAAAAA',
      'name': 'fred',
      'description': 'description here',
      'distinguishedName': 'DESTINGUISHED NAME',
      'enabled': true,
      'deleted': false,
      'acknowledgementOutgoingEndpoint': null,
      'changeNoticeOutgoingEndpoint': null,
      'shippingNoticeOutgoingEndpoint': null,
      'assignedCustomers': [],
      'customerCount': 0,
      'messageSummary': 'summary text here',
    }];
  }
}

describe('ManageMessagesComponent', () => {
  let component: ManageMessagesComponent;
  let fixture: ComponentFixture<ManageMessagesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManageMessagesComponent ],
      imports: [
        FormsModule,
        ReactiveFormsModule,
        Ng2SmartTableModule,
        CommonComponentsModule,
        CommsCommonComponentsModule,
        RouterTestingModule,
        HttpTestModule.forRoot(),
        ToastrModule.forRoot(),
        NavigationTestModule.forRoot(),
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
      providers: [
        LoggerService,
        FormBuilder,
        NotificationService,
        {provide: EhrService, useClass: EhrServiceMock, useValue: EhrServiceMock},
//        EhrService,
        {provide: EhrStateService, useClass: EhrStateServiceMock, useValue: {}},
//        EhrStateService,
        StateNavigationService,
        CommsUtilityService,
    ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageMessagesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
