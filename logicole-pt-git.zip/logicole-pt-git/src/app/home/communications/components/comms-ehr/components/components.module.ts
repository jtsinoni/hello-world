import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ManageEhrEndpointComponent } from './manage-ehr-endpoint/manage-ehr-endpoint.component';
import { CommsCommonComponentsModule } from '../../../comms-common-components/comms-common-components.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ManageOutgoingEndpointsComponent } from './manage-outgoing-endpoints/manage-outgoing-endpoints.component';
import { ManageCustomersComponent } from './manage-customers/manage-customers.component';
import { ManageMessagesComponent } from './manage-messages/manage-messages.component';
import { LcTableModule } from '../../../../../common-components/lc-table/lc-table.module';
import { OrderLinesComponent } from './order-lines/order-lines.component';
import { CommonComponentsModule } from '../../../../../common-components/common-components.module';

import { OrderLinesModule } from '../components/order-lines/order-lines.module';
import { ManageMessagesModule } from '../components/manage-messages/manage-messages.module';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        CommsCommonComponentsModule,
        LcTableModule,
        CommonComponentsModule,
        OrderLinesModule,
        ManageMessagesModule,
    ],
    declarations: [
        ManageEhrEndpointComponent,
        ManageOutgoingEndpointsComponent,
        ManageCustomersComponent,
//        ManageMessagesComponent,
//        OrderLinesComponent,
    ],
    exports: [
        ManageEhrEndpointComponent,
        ManageOutgoingEndpointsComponent,
        ManageCustomersComponent,
//        ManageMessagesComponent,
//        OrderLinesComponent,
    ],
})
export class ComponentsModule { }
