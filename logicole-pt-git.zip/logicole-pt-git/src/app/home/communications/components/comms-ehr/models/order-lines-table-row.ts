import { OrderLine } from './order-line';

export class OrderLinesTableRow extends OrderLine {
    statusCode: string;
    lineNumber: number;
    itemId: string;
    packCode: string;
    unitOfPurchasePrice: number;
    orderQuantity: number;
    acknowledgedQuantity: number;
    shippedQuantity: number;
    remainingQuantity: number;
}
