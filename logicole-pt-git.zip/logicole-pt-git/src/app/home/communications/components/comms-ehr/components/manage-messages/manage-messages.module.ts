import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';
import {CommonComponentsModule} from '../../../../../../common-components/common-components.module';
import {ManageMessagesComponent} from './manage-messages.component';
import {ManageMessagesRouterModule} from './manage-messages.router';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    CommonComponentsModule,
//    ManageMessagesComponent,
    ManageMessagesRouterModule,
  ],
  declarations: [
    ManageMessagesComponent
  ],
  exports: [
    ManageMessagesRouterModule,
    ManageMessagesComponent,
  ],
})
export class ManageMessagesModule {
}
