import { Component, OnInit, Input, Output, EventEmitter, SimpleChanges } from '@angular/core';
import { EhrSystemRecord } from '../../models/ehr-system-record';
import { InternalCustomer } from '../../../../comms-common-models/internal-customer';
import { FormBuilder, FormGroup } from '@angular/forms';
import { LoggerService } from '../../../../../../services/logger/logger.service';
import { OnChanges } from '@angular/core/src/metadata/lifecycle_hooks';
import { EhrOutgoingEndpoint } from '../../models/ehr-outgoing-endpoint';
import { NotificationService } from '../../../../../../services/notification.service';
import { EhrStateService } from '../../services/ehr-state.service';
import { EhrService } from '../../services/ehr.service';
import { ManageEhrEndpointMode } from '../../models/manage-ehr-endpoint-mode';
import { StateNavigationService } from '@lc-services/*';
import { RouteConstants } from 'app/constants/route.constants';

@Component({
    selector: 'lc-manage-ehr-endpoint',
    templateUrl: './manage-ehr-endpoint.component.html',
    styleUrls: ['./manage-ehr-endpoint.component.scss']
})
export class ManageEhrEndpointComponent implements OnInit, OnChanges {
    manageEhrEndpointForm: FormGroup;

    constructor(private logger: LoggerService,
        private formBuilder: FormBuilder,
        private notificationService: NotificationService,
        private ehrService: EhrService,
        public ehrStateService: EhrStateService,
        private navigationService: StateNavigationService) {
        this.createForm();
    }

    ngOnInit() {
        this.logger.debug('Inside of ngOnInit - setting form value.');
        this.ngOnChanges(null);
    }

    ngOnChanges(changes: SimpleChanges): void {
        this.logger.debug('Inside of ngOnInit - resetting form value.');
        this.manageEhrEndpointForm.reset({
            name: this.ehrStateService.EhrSystemRecord.name,
            description: this.ehrStateService.EhrSystemRecord.description,
            distinguishedName: this.ehrStateService.EhrSystemRecord.distinguishedName,
            enabled: this.ehrStateService.EhrSystemRecord.enabled,
        });
    }

    public onCancelClicked(): void {
        this.ngOnChanges(null);
        this.navigationService.navigateToState(RouteConstants.COMMUNICATIONS_EHR);
    }

    public onSaveClicked(): void {
        const model = this.manageEhrEndpointForm.value;

        const updatedRecord: EhrSystemRecord = {
            id: this.ehrStateService.EhrSystemRecord.id,
            dodaac: this.ehrStateService.EhrSystemRecord.dodaac,
            guid: this.ehrStateService.EhrSystemRecord.guid,
            name: model.name,
            description: model.description,
            distinguishedName: model.distinguishedName,
            enabled: model.enabled,
            deleted: this.ehrStateService.EhrSystemRecord.deleted,
            acknowledgementOutgoingEndpoint: this.ehrStateService.EhrSystemRecord.acknowledgementOutgoingEndpoint,
            changeNoticeOutgoingEndpoint: this.ehrStateService.EhrSystemRecord.changeNoticeOutgoingEndpoint,
            shippingNoticeOutgoingEndpoint: this.ehrStateService.EhrSystemRecord.shippingNoticeOutgoingEndpoint,
            assignedCustomers: [],
        };
        updatedRecord.assignedCustomers.push(...this.ehrStateService.EhrSystemRecord.assignedCustomers);
        this.logger.debug('ManageEhrEndpoint.onSaveClicked(): updatedRecord is ' + JSON.stringify(updatedRecord, null, 3));
        switch (this.ehrStateService.ManageEhrEndpointMode) {
            case ManageEhrEndpointMode.ADD_MODE:
                this.ehrService.addEhrSystemRecord(updatedRecord);
                this.notificationService.successMsg('Record was added successfully.');
                break;
            case ManageEhrEndpointMode.EDIT_MODE:
                this.ehrService.updateEhrSystemRecord(updatedRecord);
                this.notificationService.successMsg('Record was updated successfully.');
                break;
        }
        this.navigationService.navigateToState(RouteConstants.COMMUNICATIONS_EHR);
    }

    private createForm(): void {
        this.manageEhrEndpointForm = this.formBuilder.group({
            name: '',
            description: '',
            distinguishedName: '',
            enabled: false,
        });
    }

    onAckEndpointChanged(data: EhrOutgoingEndpoint): void {
        this.logger.debug('manageEhrEndpoint: onAckEndpointChanged: ' + JSON.stringify(data, null, 3));
        this.ehrStateService.EhrSystemRecord.acknowledgementOutgoingEndpoint.enabled = data.enabled;
        this.ehrStateService.EhrSystemRecord.acknowledgementOutgoingEndpoint.url = data.url;
    }

    onChangeEndpointChanged(data: EhrOutgoingEndpoint): void {
        this.logger.debug('manageEhrEndpoint: onChangeEndpointChanged: ' + JSON.stringify(data, null, 3));
        this.ehrStateService.EhrSystemRecord.changeNoticeOutgoingEndpoint.enabled = data.enabled;
        this.ehrStateService.EhrSystemRecord.changeNoticeOutgoingEndpoint.url = data.url;
    }

    onShipEndpointChanged(data: EhrOutgoingEndpoint): void {
        this.logger.debug('manageEhrEndpoint: onShipEndpointChanged: ' + JSON.stringify(data, null, 3));
        this.ehrStateService.EhrSystemRecord.shippingNoticeOutgoingEndpoint.enabled = data.enabled;
        this.ehrStateService.EhrSystemRecord.shippingNoticeOutgoingEndpoint.url = data.url;
    }

    onAssignedCustomersChanged(assignedCustomers: Array<InternalCustomer>): void {
        this.logger.debug('manageEhrEndpoint.onAssignedCustomersChanged(): assignedCustomers is now: ' + JSON.stringify(assignedCustomers, null, 3));
        this.ehrStateService.EhrSystemRecord.assignedCustomers = [];
        this.ehrStateService.EhrSystemRecord.assignedCustomers.push(...assignedCustomers);
    }

    getModeString(): string {
        let modeString: string = '';

        switch (this.ehrStateService.ManageEhrEndpointMode) {
            case ManageEhrEndpointMode.ADD_MODE:
                modeString = 'Add';
                break;
            case ManageEhrEndpointMode.EDIT_MODE:
                modeString = 'Edit';
                break;
        }
        return modeString;
    }
}
