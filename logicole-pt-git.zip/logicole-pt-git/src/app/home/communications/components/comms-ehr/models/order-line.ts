export class OrderLine {
    statusCode: string;
    lineNumber: number;
    itemId: string;
    packCode: string;
    unitOfPurchasePrice: number;
    orderQuantity: number;
    acknowledgedQuantity: number;
    shippedQuantity: number;
    remainingQuantity: number;

    constructor() {

    }
}
