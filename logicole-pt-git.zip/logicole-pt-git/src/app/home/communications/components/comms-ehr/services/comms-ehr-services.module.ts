import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EhrService } from './ehr.service';
import { EhrTableColumnService } from './ehr-table-column.service';
import { CommsServicesModule } from '../../../services/comms-services.module';
import { EhrStateService } from './ehr-state.service';

@NgModule({
  imports: [
    CommonModule,
    CommsServicesModule
  ],
  declarations: [],
  providers: [
    EhrService,
    EhrStateService,
    EhrTableColumnService,
  ]
})
export class CommsEhrServicesModule { }
