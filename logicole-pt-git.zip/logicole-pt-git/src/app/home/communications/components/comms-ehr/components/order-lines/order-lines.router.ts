import {NgModule} from '@angular/core';
import {RootModule, UIRouterModule} from '@uirouter/angular';

const orderLinesRoutes: RootModule = {
  states: []
};

@NgModule({
  imports: [UIRouterModule.forChild(orderLinesRoutes)],
  exports: [UIRouterModule]
})
export class OrderLinesRouterModule {
}
