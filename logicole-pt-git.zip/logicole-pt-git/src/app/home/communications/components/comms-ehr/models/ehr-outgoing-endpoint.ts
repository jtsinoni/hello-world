export class EhrOutgoingEndpoint {
    public enabled: boolean;
    public url: string;
}
