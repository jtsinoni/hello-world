import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageOutgoingEndpointsComponent } from './manage-outgoing-endpoints.component';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup } from '@angular/forms';
import { Ng2SmartTableModule } from 'ng2-smart-table';
import { CommonComponentsModule } from 'app/common-components/common-components.module';
import { CommsCommonComponentsModule } from 'app/home/communications/comms-common-components/comms-common-components.module';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpTestModule } from 'app/common-components/test/http-test.module';
import { ToastrModule } from 'ngx-toastr';
import { NavigationTestModule } from 'app/common-components/test/navigation-test/navigation-test.module';
import { LoggerService } from 'app/services/logger/logger.service';
import { NotificationService } from 'app/services/notification.service';
import { EhrService } from 'app/home/communications/components/comms-ehr/services/ehr.service';
import { EhrStateService } from 'app/home/communications/components/comms-ehr/services/ehr-state.service';
import { StateNavigationService } from 'app/services/state-navigation.service';
import { BrowserModule } from '@angular/platform-browser';


describe('ManageOutgoingEndpointsComponent', () => {
  let component: ManageOutgoingEndpointsComponent;
  let fixture: ComponentFixture<ManageOutgoingEndpointsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManageOutgoingEndpointsComponent ],
      imports: [
          BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        Ng2SmartTableModule,
        CommonComponentsModule,
        CommsCommonComponentsModule,
        RouterTestingModule,
        HttpTestModule.forRoot(),
        ToastrModule.forRoot(),
        NavigationTestModule.forRoot(),
      ],
      providers: [
        LoggerService,
        FormBuilder,
        NotificationService,
        EhrService,
        EhrStateService,
        StateNavigationService,
    ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageOutgoingEndpointsComponent);
    component = fixture.componentInstance;
    component.ackOutgoingEndpoint = {enabled: true,
      url: 'https://ack.gov'};
    component.changeOutgoingEndpoint = {enabled: true,
      url: 'https://change.gov'};
    component.shipOutgoingEndpoint = {enabled: true,
      url: 'https://ship.gov'};
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
