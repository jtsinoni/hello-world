import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ModelsModule } from './models/models.module';
import { CommsEhrServicesModule } from './services/comms-ehr-services.module';
import { CommsEhrComponent } from './comms-ehr.component';
import { CommonComponentsModule } from '../../../../common-components/common-components.module';
import { Ng2SmartTableModule } from 'ng2-smart-table';
import { LcTableModule } from '../../../../common-components/lc-table/lc-table.module';
import { ManageEhrEndpointComponent } from './components/manage-ehr-endpoint/manage-ehr-endpoint.component';
import { ComponentsModule } from './components/components.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommunicationsEhrRouterModule } from './comms-ehr.router';
import { CommsCommonComponentsModule } from '../../comms-common-components/comms-common-components.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    ModelsModule,
    CommsEhrServicesModule,
    LcTableModule,
    CommonComponentsModule,
    ComponentsModule,
    CommunicationsEhrRouterModule,
    CommsCommonComponentsModule,
  ],
  declarations: [
    CommsEhrComponent,
  ],
  exports: [
    CommsEhrComponent,
    CommunicationsEhrRouterModule
  ]
})
export class CommsEhrModule { }
