export enum ManageEhrEndpointMode {
    ADD_MODE,
    EDIT_MODE,
}
