import { TestBed, inject } from '@angular/core/testing';

import { LoggerService } from '../../../../../services/logger/logger.service';
import { CommsUtilityService } from '../../../services/comms-utility.service';

import { EhrService } from './ehr.service';

describe('EhrService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [EhrService, LoggerService, CommsUtilityService]
    });
  });

  it('should be created', inject([EhrService], (service: EhrService) => {
    expect(service).toBeTruthy();
  }));
});
