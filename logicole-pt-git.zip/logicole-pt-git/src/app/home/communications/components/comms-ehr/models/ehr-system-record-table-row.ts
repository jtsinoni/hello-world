import { EhrSystemRecord } from './ehr-system-record';
import { EhrOutgoingEndpoint } from './ehr-outgoing-endpoint';
import { InternalCustomer } from '../../../comms-common-models/internal-customer';

export class EhrSystemRecordTableRow implements EhrSystemRecord {
    public id: string;
    public guid: string;
    public dodaac: string;
    public name: string;
    public description?: string;
    public distinguishedName: string;
    public enabled: boolean;
    public deleted: boolean;
    public acknowledgementOutgoingEndpoint: EhrOutgoingEndpoint;
    public changeNoticeOutgoingEndpoint: EhrOutgoingEndpoint;
    public shippingNoticeOutgoingEndpoint: EhrOutgoingEndpoint;
    public assignedCustomers: Array<InternalCustomer>;
    public customerCount: number;
    public messageSummary: string;
}
