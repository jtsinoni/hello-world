export class OutgoingMessage {
    dodaac: string;
    customerAccountId: string;
    messageIdentifier: string;
    recordStatus: string;
    poNumber: string;
    poStatusType: string;
    orderDate: Date;
    sentDate: Date;

    constructor() {
    }
}
