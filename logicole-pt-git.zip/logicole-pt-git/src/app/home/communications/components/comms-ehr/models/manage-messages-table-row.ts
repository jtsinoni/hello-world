import { OutgoingMessage } from './outgoing-message';

export class ManageMessagesTableRow implements OutgoingMessage {
    dodaac: string;
    customerAccountId: string;
    messageIdentifier: string;
    recordStatus: string;
    poNumber: string;
    poStatusType: string;
    orderDate: Date;
    sentDate: Date;

    constructor() {

    }
}
