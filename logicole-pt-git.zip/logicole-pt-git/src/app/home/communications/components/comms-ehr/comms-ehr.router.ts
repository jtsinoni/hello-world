import { NgModule } from '@angular/core';
import { LoginService } from '../../../../services/login.service';
import { CommsEhrComponent } from './comms-ehr.component';
import { RouteConstants } from '../../../../constants/route.constants';

import { RootModule, UIRouterModule } from '@uirouter/angular';
import { CommsEhrStates } from './comms-ehr-states';

const commsEhrRoutes: RootModule = {

  states: [
    CommsEhrStates.COMMUNICATIONS_EHR_VIEW,
    CommsEhrStates.COMMUNICATIONS_EHR_ADD_SYSTEM_VIEW,
    CommsEhrStates.COMMUNICATIONS_EHR_EDIT_SYSTEM_VIEW,
    CommsEhrStates.COMMUNICATIONS_EHR_MANAGE_CUSTOMERS_VIEW,
    CommsEhrStates.COMMUNICATIONS_EHR_MANAGE_MESSAGES_VIEW,
    CommsEhrStates.COMMUNICATIONS_EHR_MESSAGE_ORDER_LINES_VIEW,
  ]
};

  @NgModule({
    imports: [UIRouterModule.forChild(commsEhrRoutes)],
    exports: [UIRouterModule]
  })
  export class CommunicationsEhrRouterModule {
  }
