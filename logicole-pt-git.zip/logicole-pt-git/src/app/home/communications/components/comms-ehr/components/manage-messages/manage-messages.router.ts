import {NgModule} from '@angular/core';
import {RootModule, UIRouterModule} from '@uirouter/angular';

const manageMessagessRoutes: RootModule = {
  states: []
};

@NgModule({
  imports: [UIRouterModule.forChild(manageMessagessRoutes)],
  exports: [UIRouterModule]
})
export class ManageMessagesRouterModule {
}
