import {Ng2StateDeclaration} from '@uirouter/angular';
import {RouteConstants} from '../../../../constants/route.constants';
import {CommsEhrComponent} from './comms-ehr.component';
import { ManageEhrEndpointComponent } from './components/manage-ehr-endpoint/manage-ehr-endpoint.component';
import { ManageCustomersComponent } from './components/manage-customers/manage-customers.component';
import { ManageMessagesComponent } from './components/manage-messages/manage-messages.component';
import { OrderLinesComponent } from './components/order-lines/order-lines.component';

export class CommsEhrStates {

  static COMMUNICATIONS_EHR_VIEW: Ng2StateDeclaration = {
    url: RouteConstants.COMMUNICATIONS_EHR.url,
    name: RouteConstants.COMMUNICATIONS_EHR.name,
    component: CommsEhrComponent, data: {'route': RouteConstants.COMMUNICATIONS_EHR}
  };
  static COMMUNICATIONS_EHR_ADD_SYSTEM_VIEW: Ng2StateDeclaration = {
    url: RouteConstants.COMMUNICATIONS_EHR_ADD_SYSTEM.url,
    name: RouteConstants.COMMUNICATIONS_EHR_ADD_SYSTEM.name,
    component: ManageEhrEndpointComponent, data: {'route': RouteConstants.COMMUNICATIONS_EHR_ADD_SYSTEM}
  };
  static COMMUNICATIONS_EHR_EDIT_SYSTEM_VIEW: Ng2StateDeclaration = {
    url: RouteConstants.COMMUNICATIONS_EHR_EDIT_SYSTEM.url,
    name: RouteConstants.COMMUNICATIONS_EHR_EDIT_SYSTEM.name,
    component: ManageEhrEndpointComponent, data: {'route': RouteConstants.COMMUNICATIONS_EHR_EDIT_SYSTEM}
  };
  static COMMUNICATIONS_EHR_MANAGE_CUSTOMERS_VIEW: Ng2StateDeclaration = {
    url: RouteConstants.COMMUNICATIONS_EHR_MANAGE_CUSTOMERS.url,
    name: RouteConstants.COMMUNICATIONS_EHR_MANAGE_CUSTOMERS.name,
    component: ManageCustomersComponent, data: {'route': RouteConstants.COMMUNICATIONS_EHR_MANAGE_CUSTOMERS}
  };
  static COMMUNICATIONS_EHR_MANAGE_MESSAGES_VIEW: Ng2StateDeclaration = {
    url: RouteConstants.COMMUNICATIONS_EHR_MANAGE_MESSAGES.url,
    name: RouteConstants.COMMUNICATIONS_EHR_MANAGE_MESSAGES.name,
    component: ManageMessagesComponent, data: {'route': RouteConstants.COMMUNICATIONS_EHR_MANAGE_MESSAGES}
  };
  static COMMUNICATIONS_EHR_MESSAGE_ORDER_LINES_VIEW: Ng2StateDeclaration = {
    url: RouteConstants.COMMUNICATIONS_EHR_VIEW_MESSAGE_ORDER_LINES.url,
    name: RouteConstants.COMMUNICATIONS_EHR_VIEW_MESSAGE_ORDER_LINES.name,
    component: OrderLinesComponent, data: {'route': RouteConstants.COMMUNICATIONS_EHR_VIEW_MESSAGE_ORDER_LINES}
  };

}
