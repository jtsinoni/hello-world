import { Injectable } from '@angular/core';
import { LcTableColumn } from '../../../../../common-components/lc-table/models/lc-table-column';
import { LcCheckboxCellComponent } from '../../../../../common-components/lc-table/lc-checkbox-cell/lc-checkbox-cell.component';
import { LcDateCellComponent } from '../../../../../common-components/lc-table/lc-date-cell/lc-date-cell.component';

@Injectable()
export class EhrTableColumnService {

    constructor() { }

    public createTextColumn(title: string): LcTableColumn {
        const col: LcTableColumn = new LcTableColumn();
        col.title = title;
        return col;
    }

    public createCheckboxColumn(title: string): LcTableColumn {
        const col: LcTableColumn = new LcTableColumn();
        col.title = title;
        col.type = 'custom';
        col.width = '1%';
        col.renderComponent = LcCheckboxCellComponent;
        return col;
    }

    public createDateColumn(title: string): LcTableColumn {
        const col: LcTableColumn = new LcTableColumn();
        col.title = title;
        col.type = 'custom';
        col.renderComponent = LcDateCellComponent;
        return col;
    }
}
