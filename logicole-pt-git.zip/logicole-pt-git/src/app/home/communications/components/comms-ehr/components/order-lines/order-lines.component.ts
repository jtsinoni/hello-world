import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ManageMessagesTableRow } from '../../models/manage-messages-table-row';
import { LoggerService } from '../../../../../../services/logger/logger.service';
import { EhrService } from '../../services/ehr.service';
import { EhrTableColumnService } from '../../services/ehr-table-column.service';
import { NotificationService } from '../../../../../../services/notification.service';
import { LcTableSettings } from '../../../../../../common-components/lc-table/models/lc-table-settings';
import { OrderLinesTableRow } from '../../models/order-lines-table-row';
import { CommsUtilityService } from '../../../../services/comms-utility.service';
import { EhrStateService } from '../../services/ehr-state.service';
import { StateNavigationService } from '@lc-services/*';
import { RouteConstants } from '../../../../../../constants/route.constants';

@Component({
    selector: 'lc-order-lines',
    templateUrl: './order-lines.component.html',
    styleUrls: ['./order-lines.component.scss']
})
export class OrderLinesComponent implements OnInit {

    // @Input() manageMessageTableRow: ManageMessagesTableRow;
    // @Output() backClicked: EventEmitter<string> = new EventEmitter();

    public orderLinesColumns: any;
    public orderLinesTableSettings: LcTableSettings;
    public orderLinesTableData: Array<OrderLinesTableRow> = [];

    constructor(private logger: LoggerService,
                private ehrService: EhrService,
                public ehrStateService: EhrStateService,
                private notify: NotificationService,
                private commsUtilService: CommsUtilityService,
                private navigationService: StateNavigationService) { }

    ngOnInit() {
        this.initializeTable();
        this.loadData();
    }

    public onBackClicked(): void {
        // this.backClicked.emit(null);
        this.navigationService.navigateToState(RouteConstants.COMMUNICATIONS_EHR_MANAGE_MESSAGES);
    }

    private initializeTable(): void {
        this.orderLinesTableSettings = new LcTableSettings();
        this.orderLinesTableSettings.cardId = 'orderLines';
        this.orderLinesTableSettings.cardTitle = 'Order Lines for Purchase Order ' + this.ehrStateService.MessageRecord.poNumber;
        this.orderLinesTableSettings.cardTitleIcon = 'fa fa-bolt';
        this.orderLinesTableSettings.tableAttr.id = 'orderLinesTableAttr';

        this.orderLinesTableSettings.cardShowDownload = false;
        this.orderLinesTableSettings.cardShowGlobalSearch = false;
        this.orderLinesTableSettings.cardShowRefresh = false;
        this.orderLinesTableSettings.tableHideSubHeader = false;

        this.orderLinesColumns = {
            statusCode: this.commsUtilService.createTextColumn('Status Code'),
            lineNumber: this.commsUtilService.createTextColumn('Line Number'),
            itemId: this.commsUtilService.createTextColumn('Item ID'),
            packCode: this.commsUtilService.createTextColumn('Pack Code'),
            unitOfPurchasePrice: this.commsUtilService.createTextColumn('UOP Price'),
            orderQuantity: this.commsUtilService.createTextColumn('Quantity'),
            acknowledgedQuantity: this.commsUtilService.createTextColumn('Ack Quantity'),
            shippedQuantity: this.commsUtilService.createTextColumn('Ship Quantity'),
            remainingQuantity: this.commsUtilService.createTextColumn('Remaining Quantity'),
        };
    }

    private loadData(): void {
        this.orderLinesTableData = this.ehrService.getOrderLines(this.ehrStateService.MessageRecord.customerAccountId,
                                                                 this.ehrStateService.MessageRecord.poNumber);
    }

}
