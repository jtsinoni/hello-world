import { Injectable } from '@angular/core';
import { InternalCustomer } from '../../../comms-common-models/internal-customer';
import { EhrSystemRecord } from '../models/ehr-system-record';
import { LoggerService } from '../../../../../services/logger/logger.service';
import { EhrOutgoingMessageSummary } from '../models/ehr-outgoing-message-summary';
import { OutgoingMessage } from '../models/outgoing-message';
import { OrderLine } from '../models/order-line';
import { CommsUtilityService } from '../../../services/comms-utility.service';

@Injectable()
export class EhrService {

    private systemList: Array<EhrSystemRecord> = [];

    constructor(private logger: LoggerService, private commsUtilService: CommsUtilityService) {
        this.buildRecordList();
    }

    public getEhrSystemsForDodaac(dodaac: string): Array<EhrSystemRecord> {
        const list: Array<EhrSystemRecord> = [];
        list.push(...this.systemList);
        return list;
    }

    public getOutgoingMessageSummary(ehrSystemGuid: string, beginDate: Date, endDate: Date) {

        const summary: EhrOutgoingMessageSummary = {
            beginDate: beginDate,
            endDate: endDate,
            queuedCount: this.commsUtilService.getRandomInt(5),
            sentCount: this.commsUtilService.getRandomInt(10),
            errorCount: this.commsUtilService.getRandomInt(3),
        };
        return summary;
    }

    public getOutgoingMessages(ehrSystemGuid: string, beginDate: Date, endDate: Date, msgSummary: string): Array<OutgoingMessage> {
        const results = [];
        // Queued: 0, Sent: 7, Error: 1
        const parts: string[] = msgSummary.split(',');
        let queuedCount: number = 0;
        let sentCount: number = 0;
        let errorCount: number = 0;
        for (let i = 0; i < parts.length; i++) {
            const attrVal: string[] = parts[i].split(':');
            const attr = attrVal[0].trim().toLowerCase();
            const val = Number(attrVal[1]);
            switch (attr) {
                case 'queued':
                    queuedCount = val;
                    break;
                case 'sent':
                    sentCount = val;
                    break;
                case 'error':
                    errorCount = val;
                    break;
            }
        }

        const systemRecord = this.getSystemRecordForSystemGuid(ehrSystemGuid);
        for (let i = 0; i < queuedCount; i++) {
            const cust: InternalCustomer = this.getRandomCustomer(systemRecord.assignedCustomers);
            const orderDate: Date = this.getRandomOrderDate();
            const row = new OutgoingMessage();
            row.customerAccountId = cust.customerAccountId;
            row.dodaac = systemRecord.dodaac;
            row.messageIdentifier = this.generateRandomMessageIdentifier();
            row.recordStatus = 'Queued';
            row.orderDate = orderDate;
            row.poNumber = this.generateRandomPurchaseOrderNumber();
            row.poStatusType = this.getRandomStatusType();
            row.sentDate = null;

            if (orderDate.getTime() >= beginDate.getTime() && orderDate.getTime() <= endDate.getTime()) {
                results.push(row);
            }
        }
        for (let i = 0; i < errorCount; i++) {
            const cust: InternalCustomer = this.getRandomCustomer(systemRecord.assignedCustomers);
            const orderDate: Date = this.getRandomOrderDate();
            const row = new OutgoingMessage();
            row.customerAccountId = cust.customerAccountId;
            row.dodaac = systemRecord.dodaac;
            row.messageIdentifier = this.generateRandomMessageIdentifier();
            row.recordStatus = 'Error';
            row.orderDate = orderDate;
            row.poNumber = this.generateRandomPurchaseOrderNumber();
            row.poStatusType = this.getRandomStatusType();
            row.sentDate = this.getRandomSentDate(orderDate);

            if (orderDate.getTime() >= beginDate.getTime() && orderDate.getTime() <= endDate.getTime()) {
                results.push(row);
            }
        }
        for (let i = 0; i < sentCount; i++) {
            const cust: InternalCustomer = this.getRandomCustomer(systemRecord.assignedCustomers);
            const orderDate: Date = this.getRandomOrderDate();
            const row = new OutgoingMessage();
            row.customerAccountId = cust.customerAccountId;
            row.dodaac = systemRecord.dodaac;
            row.messageIdentifier = this.generateRandomMessageIdentifier();
            row.recordStatus = 'Sent';
            row.orderDate = orderDate;
            row.poNumber = this.generateRandomPurchaseOrderNumber();
            row.poStatusType = this.getRandomStatusType();
            row.sentDate = this.getRandomSentDate(orderDate);

            if (orderDate.getTime() >= beginDate.getTime() && orderDate.getTime() <= endDate.getTime()) {
                results.push(row);
            }
        }

        return results;
    }

    public getOrderLines(customerAccountId: string, poNumber: string): Array<OrderLine> {
        const orderLines: Array<OrderLine> = [];
        for (let i = 0; i < (this.commsUtilService.getRandomInt(5) + 1); i++) {

            const line: OrderLine = new OrderLine();
            line.lineNumber = i + 1;
            line.statusCode = this.getRandomStatusCode();
            line.itemId = this.getRandomItemId();
            line.orderQuantity = this.commsUtilService.getRandomInt(15) + 10;
            line.acknowledgedQuantity = line.orderQuantity - this.commsUtilService.getRandomInt(4);
            line.shippedQuantity = line.acknowledgedQuantity - this.commsUtilService.getRandomInt(3);
            line.packCode = this.getRandomPackCode();
            line.remainingQuantity = line.shippedQuantity - this.commsUtilService.getRandomInt(7);
            line.unitOfPurchasePrice = this.commsUtilService.getRandomInt(10);

            orderLines.push(line);
        }
        return orderLines;
    }

    public updateEhrSystemRecord(recordToUpdate: EhrSystemRecord): number {
        let numUpdated: number = 0;
        const index = this.getIndexForRecord(recordToUpdate);
        if (index >= 0) {
            this.systemList[index] = recordToUpdate;
            numUpdated = 1;
        }
        return numUpdated;
    }

    public addEhrSystemRecord(recordToAdd: EhrSystemRecord): number {
        const numAdded: number = 1;

        recordToAdd.guid = this.commsUtilService.generateGuidLikeString();
        recordToAdd.id = this.commsUtilService.generateGuidLikeString();
        this.systemList.push(recordToAdd);
        return numAdded;
    }

    public deleteEhrSystemRecord(recordToDelete: EhrSystemRecord): number {
        let numDeleted: number = 0;
        const index = this.getIndexForRecord(recordToDelete);
        if (index >= 0) {
            this.logger.debug('Deleting ehrSystemRecord at index ' + index);
            numDeleted = 1;
            this.systemList.splice(Number(index), 1);
            this.logger.debug('now systemList looks like ' + JSON.stringify(this.systemList, null, 3));
        }
        return numDeleted;
    }

    private getIndexForRecord(recordToFind: EhrSystemRecord): number {
        let index: number = -1;
        for (let i: number = 0; i < this.systemList.length; i++) {
            if (this.systemList[i].id === recordToFind.id) {
                index = i;
                break;
            }
        }
        return index;
    }

    private formatId(index: number): string {
        return this.commsUtilService.zeroFillLeft(index.toString(), 4);
    }

    private getDodaac(index: number): string {
        const dodaacList: Array<string> = ['ABC123', 'DEF456', 'GHI789'];
        const slot: number = index % 3;
        return dodaacList[slot];
    }

    private buildRecordList(): void {
        const numRecords: number = 6;
        for (let i = 0; i < numRecords; i++) {
            const ipAddress: string = this.getIpAddress(i);
            this.systemList.push({
                id: this.commsUtilService.generateGuidLikeString(),
                dodaac: this.getDodaac(i),
                guid: this.commsUtilService.generateGuidLikeString(),
                name: ((i === 0) ? 'Main EHR System' : 'TEST EHR SYSTEM ' + (i + 1)),
                description: ((i === 0) ? 'Main EHR System' : 'Test ' + (i + 1)),
                distinguishedName: '/C=US/O=U.S. GOVERNMENT/OU=DOD/OU=PKI/OU=CONTRACTOR/CN=ABCDE.' + (i * 1000),
                enabled: this.commsUtilService.getRandomBoolean(),
                deleted: false,
                acknowledgementOutgoingEndpoint: {
                    enabled: this.commsUtilService.getRandomBoolean(),
                    url: 'http://' + ipAddress + '/acks',
                },
                changeNoticeOutgoingEndpoint: {
                    enabled: this.commsUtilService.getRandomBoolean(),
                    url: 'http://' + ipAddress + '/change',
                },
                shippingNoticeOutgoingEndpoint: {
                    enabled: this.commsUtilService.getRandomBoolean(),
                    url: 'http://' + ipAddress + '/ship',
                },
                assignedCustomers: []
            });
        }

        const customers: Array<InternalCustomer> = this.commsUtilService.getCustomerList();

        for (let i = 0; i < numRecords; i++) {
            for (let j = 0; j < this.commsUtilService.getRandomInt(6) + 1; j++) {
                const custIdx: number = this.commsUtilService.getRandomInt(customers.length);
                this.systemList[i].assignedCustomers.push(customers[custIdx]);
                customers.splice(custIdx, 1);
            }
        }
    }

    private getIpAddress(index: number): string {
        const node: string = this.commsUtilService.zeroFillLeft(index.toString(), 3);
        this.logger.debug('EhrService.getIpAddress() - node is ' + index);
        const ipAddr: string = '192.168.0.' + node;
        return ipAddr;
    }

    private getRandomStatusType(): string {
        const val: Number = this.commsUtilService.getRandomInt(3);
        let statusType: string = '';
        switch (val) {
            case 0:
                statusType = 'Acknowledgement';
                break;
            case 1:
                statusType = 'Change Notice';
                break;
            case 2:
                statusType = 'Ship Notice';
                break;
        }
        return statusType;
    }

    private generateRandomPurchaseOrderNumber() {
        const poNumber = 'PO' + this.commsUtilService.zeroFillLeft(String(this.commsUtilService.getRandomInt(40000)), 5);
        return poNumber;
    }

    private getSystemRecordForSystemGuid(ehrSystemGuid: string): EhrSystemRecord {
        let record: EhrSystemRecord = null;
        for (let i = 0; i < this.systemList.length; i++) {
            if (this.systemList[i].guid === ehrSystemGuid) {
                record = this.systemList[i];
                break;
            }
        }
        return record;
    }

    private getRandomCustomer(custList: Array<InternalCustomer>): InternalCustomer {
        this.logger.debug('EhrService.getRandomCustomer(): custList is ' + JSON.stringify(custList, null, 3));
        const slot = this.commsUtilService.getRandomInt(custList.length);
        this.logger.debug('EhrService.getRandomCustomer(): random slot is ' + slot);
        const cust: InternalCustomer = custList[slot];
        this.logger.debug('EhrService.getRandomCustomer(): returning cust ' + JSON.stringify(cust, null, 3));
        return cust;
    }

    private generateRandomMessageIdentifier(): string {
        return 'MSG' + this.commsUtilService.zeroFillLeft(String(this.commsUtilService.getRandomInt(27928)), 5);
    }

    private getRandomOrderDate(): Date {
        const orderDate: Date = new Date();
        orderDate.setMinutes(orderDate.getMinutes() - this.commsUtilService.getRandomInt(orderDate.getMinutes()));
        orderDate.setDate(orderDate.getDate() - this.commsUtilService.getRandomInt(orderDate.getDate() + 7));
        orderDate.setMonth(orderDate.getMonth() - this.commsUtilService.getRandomInt(orderDate.getMonth()));
        return orderDate;
    }

    private getRandomSentDate(orderDate: Date) {
        const sentDate = new Date(orderDate);
        sentDate.setMinutes(sentDate.getMinutes() - this.commsUtilService.getRandomInt(2));
        return sentDate;
    }

    private getRandomStatusCode(): string {
        const statusCodes: Array<string> = ['CS', 'CJ', 'CG', 'BJ', 'SS', 'ID', 'R6', 'IA'];
        const result = statusCodes[this.commsUtilService.getRandomInt(statusCodes.length)];
        return result;
    }

    private getRandomPackCode(): string {
        const packCodes: Array<string> = ['PH', 'BT', 'VI', 'CS', 'PG', 'TT', 'JR', 'TU', 'EA', 'KT', 'CT', 'IH', 'BX', 'SZ'];
        const result = packCodes[this.commsUtilService.getRandomInt(packCodes.length)];
        return result;
    }

    private getRandomItemId(): string {
        const result: string = 'ITEM' + this.commsUtilService.zeroFillLeft(String(this.commsUtilService.getRandomInt(32000)), 5);
        return result;
    }
}

// getEhrSystems
// getInternalCustomers
