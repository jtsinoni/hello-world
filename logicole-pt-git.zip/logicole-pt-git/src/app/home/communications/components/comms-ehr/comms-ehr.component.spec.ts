import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {NO_ERRORS_SCHEMA} from '@angular/core';

import {FormsModule} from '@angular/forms';
import {RouterTestingModule} from '@angular/router/testing';
import {HttpTestModule} from '../../../../common-components/test/http-test.module';
import {ToastrModule} from 'ngx-toastr';
import {NavigationTestModule} from '../../../../common-components/test/navigation-test/navigation-test.module';

import { CommsEhrComponent } from './comms-ehr.component';
import { LoggerService } from '../../../../services/logger/logger.service';
import { EhrService } from './services/ehr.service';
import { NotificationService } from '../../../../services/notification.service';
import { CommsUtilityService } from '../../services/comms-utility.service';
import { EhrStateService } from './services/ehr-state.service';
import { StateNavigationService } from '@lc-services/*';

describe('CommsEhrComponent', () => {
  let component: CommsEhrComponent;
  let fixture: ComponentFixture<CommsEhrComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        RouterTestingModule,
        HttpTestModule.forRoot(),
        ToastrModule.forRoot(),
        NavigationTestModule.forRoot(),
      ],
      declarations: [ CommsEhrComponent ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
      providers: [
        LoggerService,
        EhrService,
        EhrStateService,
        NotificationService,
        CommsUtilityService,
        StateNavigationService
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommsEhrComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
