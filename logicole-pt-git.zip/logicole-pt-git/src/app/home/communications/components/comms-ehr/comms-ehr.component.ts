import { Component, OnInit } from '@angular/core';
import { LcTableSettings } from '../../../../common-components/lc-table/models/lc-table-settings';
import { EhrSystemRecord } from './models/ehr-system-record';
import { EhrService } from './services/ehr.service';
import { LcTableColumn } from '../../../../common-components/lc-table/models/lc-table-column';
import { LcCheckboxCellComponent } from '../../../../common-components/lc-table/lc-checkbox-cell/lc-checkbox-cell.component';
import { LcButtonCellComponent } from '../../../../common-components/lc-table/lc-button-cell/lc-button-cell.component';
import { LcButtonCallbackEvent } from '../../../../common-components/lc-table/models/lc-button-callback-event';
import { LoggerService } from '../../../../services/logger/logger.service';
import { InternalCustomer } from '../../comms-common-models/internal-customer';
import { NotificationService } from '../../../../services/notification.service';
import { LcLinkCellComponent } from '../../../../common-components/lc-table/lc-link-cell/lc-link-cell.component';
import { EhrSystemRecordTableRow } from './models/ehr-system-record-table-row';
import { EhrOutgoingMessageSummary } from './models/ehr-outgoing-message-summary';
import { CommsUtilityService } from '../../services/comms-utility.service';
import { StateNavigationService } from 'app/services/state-navigation.service';
import { EhrStateService } from 'app/home/communications/components/comms-ehr/services/ehr-state.service';
import { RouteConstants } from 'app/constants/route.constants';
import { ManageEhrEndpointMode } from './models/manage-ehr-endpoint-mode';
// import { LcBadgeLinkCellComponent } from 'app/common-components/lc-table/lc-badge-link-cell/lc-badge-link-cell.component';

@Component({
    selector: 'comms-ehr',
    templateUrl: './comms-ehr.component.html',
    styleUrls: ['./comms-ehr.component.scss']
})
export class CommsEhrComponent implements OnInit {

    public lcTableColumns: any;
    public lcTableSettings: LcTableSettings;
    public lcTableData: Array<EhrSystemRecordTableRow> = [];

    public dialogTitle: string;
    public dialogMessage: string;
    public showDialog: boolean = false;
    private ehrSystemRecordToDelete: EhrSystemRecord;

    constructor(private logger: LoggerService,
                private ehrService: EhrService,
                private ehrStateService: EhrStateService,
                private notify: NotificationService,
                private commsUtilService: CommsUtilityService,
                private navigationService: StateNavigationService) { }

    ngOnInit() {
        this.initializeTable();
        this.loadData();
        this.ehrStateService.AvailableCustomers = this.commsUtilService.getCustomerList();
    }

    private initializeTable() {

        this.lcTableSettings = new LcTableSettings();
        this.lcTableSettings.cardId = 'ehrSystems';
        this.lcTableSettings.cardTitle = 'Manage EHR Systems';
        this.lcTableSettings.cardTitleIcon = 'fa fa-phone';
        this.lcTableSettings.tableAttr.id = 'ehrSystemsTableAttr';

        this.lcTableSettings.cardShowDownload = false;
        this.lcTableSettings.cardShowGlobalSearch = false;
        this.lcTableSettings.cardShowRefresh = false;
        this.lcTableSettings.tableHideSubHeader = false;

        this.lcTableColumns = {
            deleteRecord: this.createButtonColumn('deleteEndpoint', '', 'Delete EHR Endpoint', 'fa-times'),
            name: this.createNameLinkColumn(),
            description: this.commsUtilService.createTextColumn('Description'),
            distinguishedName: this.commsUtilService.createTextColumn('Distinguished Name'),
            enabled: this.commsUtilService.createCheckboxColumn('Enabled'),
            customerCount: this.createCustomersLinkColumn(),
            messageSummary: this.createMessagesLinkColumn(),
        };
    }

    private loadData(): void {
        this.lcTableData = [];
        const tableData: Array<EhrSystemRecordTableRow> =  <Array<EhrSystemRecordTableRow>> this.ehrService.getEhrSystemsForDodaac('ABC');

        const beginDate: Date = new Date();
        beginDate.setDate(beginDate.getDate() - 7);
        const endDate: Date = new Date();

        for (let i: number = 0; i < tableData.length; i++) {
            const ehrSystemGuid: string = tableData[i]['guid'];
            tableData[i]['customerCount'] = tableData[i].assignedCustomers.length;
            const summaryData: EhrOutgoingMessageSummary = this.ehrService.getOutgoingMessageSummary(ehrSystemGuid, beginDate, endDate);
            tableData[i]['messageSummary'] = this.formatMessageSummary(summaryData);
        }

        this.lcTableData = tableData;
    }

    private formatMessageSummary(summaryData: EhrOutgoingMessageSummary): string {
        const value = 'Queued: ' + summaryData.queuedCount + ', Sent: ' + summaryData.sentCount + ', Error: ' + summaryData.errorCount;
        return value;
    }

    private createButtonColumn(buttonId: string, columnTitle: string, buttonToolTip: string, iconName: string) {
        const col: LcTableColumn = new LcTableColumn();
        col.title = columnTitle;
        col.type = 'custom';
        col.renderComponent = LcButtonCellComponent;
        col.width = '1%';
        col.filter = false;
        col.onComponentInitFunction = ((instance: LcButtonCellComponent) => {
            instance.buttonId = buttonId;
            instance.buttonToolTip = buttonToolTip;
            instance.iconName = iconName;
            instance.callbackFunction.subscribe((buttonCallbackEvent: LcButtonCallbackEvent) => {
                this.processButtonCallbackEvent(buttonCallbackEvent);
            });
        });
        return col;
    }

    private createNameLinkColumn(): LcTableColumn {
        const col: LcTableColumn = new LcTableColumn();
        col.title = 'Name';
        col.type = 'custom';
        col.renderComponent = LcLinkCellComponent;
        col.width = '15%';
        col.onComponentInitFunction = ((instance: LcLinkCellComponent) => {
            instance.cellSelected.subscribe((row) => {
                this.manageSystemNameClicked(row);
            });
        });
        return col;

    }

    private createCustomersLinkColumn(): LcTableColumn {
        const col: LcTableColumn = new LcTableColumn();
        col.title = 'Manage Customers';
        col.type = 'custom';
        col.renderComponent = LcLinkCellComponent;
        col.width = '2%';
        col.onComponentInitFunction = ((instance: LcLinkCellComponent) => {
            instance.cellSelected.subscribe((row) => {
                this.manageCustomersClicked(row);
            });
        });
        return col;
    }

    private createMessagesLinkColumn(): LcTableColumn {
        const col: LcTableColumn = new LcTableColumn();
        col.title = 'Outgoing Messages';
        col.type = 'custom';
        col.renderComponent = LcLinkCellComponent;
        col.width = '15%';
        col.onComponentInitFunction = ((instance: LcLinkCellComponent) => {
            instance.cellSelected.subscribe((row) => {
                this.manageMessagesClicked(row);
            });
        });
        return col;
    }

    private processButtonCallbackEvent(buttonCallbackEvent: LcButtonCallbackEvent): void {
        switch (buttonCallbackEvent.buttonId) {
            case 'deleteEndpoint':
                this.ehrSystemRecordToDelete = buttonCallbackEvent.rowData;
                this.logger.debug('deleteEndpoint button was clicked: ' + JSON.stringify(buttonCallbackEvent.rowData, null, 3));
                this.showDialog = true;
                this.dialogTitle = 'Confirm Delete Endpoint';
                this.dialogMessage = 'Are you sure you wish to delete endpoint "' + this.ehrSystemRecordToDelete.name +
                                    '" with Distinguished Name "' + this.ehrSystemRecordToDelete.distinguishedName + '"?';
                break;
        }
    }

    private manageSystemNameClicked(row: EhrSystemRecordTableRow) {
        this.logger.debug('editEndpoint button was clicked: ' + JSON.stringify(row, null, 3));
        this.ehrStateService.EhrSystemRecord = row;
        this.ehrStateService.ManageEhrEndpointMode = ManageEhrEndpointMode.EDIT_MODE;
        this.navigationService.navigateToState(RouteConstants.COMMUNICATIONS_EHR_EDIT_SYSTEM);
    }

    private manageCustomersClicked(row: any) {
        this.logger.debug('manageCustomersClicked(): row is ' + JSON.stringify(row, null, 3));
        this.ehrStateService.EhrSystemRecord = row;
        this.navigationService.navigateToState(RouteConstants.COMMUNICATIONS_EHR_MANAGE_CUSTOMERS);
    }

    private manageMessagesClicked(row: EhrSystemRecordTableRow) {
        this.ehrStateService.EhrSystemRecord = row;
        this.ehrStateService.EhrSystemRecord = row;
        this.navigationService.navigateToState(RouteConstants.COMMUNICATIONS_EHR_MANAGE_MESSAGES);
    }

    private onDeleteEndpointYesClicked(): void {
        const numDeleted: number = this.ehrService.deleteEhrSystemRecord(this.ehrSystemRecordToDelete);
        this.notify.successMsg('The EHR Endpoint was successfully deleted.');
        this.loadData();
        this.showDialog = false;
    }

    private onDeleteEndpointNoClicked(): void {
        this.showDialog = false;
    }


    public onAddNewEndpointClicked(): void {
        const newRecord: EhrSystemRecordTableRow = {
            id: null,
            guid: null,
            name: '',
            description: '',
            enabled: false,
            assignedCustomers: [],
            distinguishedName: '',
            dodaac: 'ABC',
            deleted: false,
            acknowledgementOutgoingEndpoint: {
                enabled: false,
                url: '',
            },
            changeNoticeOutgoingEndpoint: {
                enabled: false,
                url: '',
            },
            shippingNoticeOutgoingEndpoint: {
                enabled: false,
                url: '',
            },
            customerCount: 0,
            messageSummary: '',
        };
        this.ehrStateService.EhrSystemRecord = newRecord;
        this.ehrStateService.ManageEhrEndpointMode = ManageEhrEndpointMode.ADD_MODE;
        this.navigationService.navigateToState(RouteConstants.COMMUNICATIONS_EHR_ADD_SYSTEM);
    }
}
