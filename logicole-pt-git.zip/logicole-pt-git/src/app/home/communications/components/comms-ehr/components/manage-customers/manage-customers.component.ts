import { Component, OnInit, EventEmitter, Input, Output } from '@angular/core';
import { LoggerService } from '../../../../../../services/logger/logger.service';
import { EhrService } from '../../services/ehr.service';
import { EhrSystemRecord } from '../../models/ehr-system-record';
import { EhrSystemRecordTableRow } from '../../models/ehr-system-record-table-row';
import { InternalCustomer } from '../../../../comms-common-models/internal-customer';
import { LcTableSettings } from '../../../../../../common-components/lc-table/models/lc-table-settings';
import { NotificationService } from '../../../../../../services/notification.service';
import { EhrTableColumnService } from '../../services/ehr-table-column.service';
import { ManageCustomersTableRow } from '../../models/manage-customers-table-row';
import { CommsUtilityService } from '../../../../services/comms-utility.service';
import { EhrStateService } from 'app/home/communications/components/comms-ehr/services/ehr-state.service';
import { StateNavigationService } from '@lc-services/*';
import { RouteConstants } from '../../../../../../constants/route.constants';

@Component({
    selector: 'lc-manage-customers',
    templateUrl: './manage-customers.component.html',
    styleUrls: ['./manage-customers.component.scss']
})
export class ManageCustomersComponent implements OnInit {

    public manageCustomersColumns: any;
    public manageCustomersTableSettings: LcTableSettings;
    public manageCustomersTableData: Array<ManageCustomersTableRow> = [];

    constructor(private logger: LoggerService,
                private ehrService: EhrService,
                public ehrStateService: EhrStateService,
                private notify: NotificationService,
                private commsUtilService: CommsUtilityService,
                private navigationService: StateNavigationService) { }

    ngOnInit() {
        this.initializeTable();
        this.loadData();
        this.ehrStateService.AvailableCustomers = this.commsUtilService.getCustomerList();
    }

    public onGoBackClicked(): void {
        this.navigationService.navigateToState(RouteConstants.COMMUNICATIONS_EHR);
    }

    private initializeTable(): void {
        this.manageCustomersTableSettings = new LcTableSettings();
        this.manageCustomersTableSettings.cardId = 'ehrCustomers';
        this.manageCustomersTableSettings.cardTitle = 'Manage Customers';
        this.manageCustomersTableSettings.cardTitleIcon = 'fa fa-phone';
        this.manageCustomersTableSettings.tableAttr.id = 'ehrCustomersTableAttr';

        this.manageCustomersTableSettings.cardShowDownload = false;
        this.manageCustomersTableSettings.cardShowGlobalSearch = false;
        this.manageCustomersTableSettings.cardShowRefresh = false;
        this.manageCustomersTableSettings.tableHideSubHeader = false;

        this.manageCustomersColumns = {
            customerAccountId: this.commsUtilService.createTextColumn('Customer Account Id'),
            customerName: this.commsUtilService.createTextColumn('Customer Name'),
            sendCatalog: this.commsUtilService.createCheckboxColumn('Send Catalog?'),
            sendEquipment: this.commsUtilService.createCheckboxColumn('Send Equipment?'),
            lastCatalogRequestDate: this.commsUtilService.createDateColumn('Last Catalog Request Date'),
            lastEquipmentRequestDate: this.commsUtilService.createDateColumn('Last Equipment Request Date'),
        };
    }

    private loadData(): void {
        this.manageCustomersTableData = [];
        for (let i = 0; i < this.ehrStateService.EhrSystemRecord.assignedCustomers.length; i++) {
            const cust: InternalCustomer = this.ehrStateService.EhrSystemRecord.assignedCustomers[i];
            const newRow: ManageCustomersTableRow = new ManageCustomersTableRow();
            newRow.customerAccountId = cust.customerAccountId;
            newRow.customerName = cust.customerName;
            newRow.sendCatalog = cust.sendCatalogIndicator;
            newRow.sendEquipment = cust.sendEquipmentIndicator;
            newRow.lastCatalogRequestDate = cust.lastCatalogRequestDate;
            newRow.lastEquipmentRequestDate = cust.lastEquipmentRequestDate;
            this.manageCustomersTableData.push(newRow);
        }
    }
}
