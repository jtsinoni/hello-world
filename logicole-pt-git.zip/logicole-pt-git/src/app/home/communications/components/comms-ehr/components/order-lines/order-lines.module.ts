import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';
import {CommonComponentsModule} from '../../../../../../common-components/common-components.module';
import {OrderLinesComponent} from './order-lines.component';
import {OrderLinesRouterModule} from './order-lines.router';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    CommonComponentsModule,
//    OrderLinesComponent,
    OrderLinesRouterModule,
  ],
  declarations: [
    OrderLinesComponent
  ],
  exports: [
    OrderLinesRouterModule,
    OrderLinesComponent,
  ],
})
export class OrderLinesModule {
}
