import { Component, OnInit, Input, Output, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { EhrOutgoingEndpoint } from '../../models/ehr-outgoing-endpoint';
import { LoggerService } from '../../../../../../services/logger/logger.service';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
    selector: 'lc-manage-outgoing-endpoints',
    templateUrl: './manage-outgoing-endpoints.component.html',
    styleUrls: ['./manage-outgoing-endpoints.component.scss']
})
export class ManageOutgoingEndpointsComponent implements OnInit, OnChanges {
    @Input() ackOutgoingEndpoint: EhrOutgoingEndpoint;
    @Input() changeOutgoingEndpoint: EhrOutgoingEndpoint;
    @Input() shipOutgoingEndpoint: EhrOutgoingEndpoint;

    @Output() ackEndpointChanged: EventEmitter<EhrOutgoingEndpoint> = new EventEmitter();
    @Output() changeEndpointChanged: EventEmitter<EhrOutgoingEndpoint> = new EventEmitter();
    @Output() shipEndpointChanged: EventEmitter<EhrOutgoingEndpoint> = new EventEmitter();

    outgoingEndpointsForm: FormGroup;

    constructor(private logger: LoggerService, private formBuilder: FormBuilder ) {
        this.createForm();
    }

    ngOnInit(): void {
        this.logger.debug('inside manageOutgoingEndpoints.ngOnInit()');
        this.logger.debug('ackOutgoingEndpoint is ' + JSON.stringify(this.ackOutgoingEndpoint, null, 3));
        this.outgoingEndpointsForm.reset({
            ackEnabled: this.ackOutgoingEndpoint.enabled,
            ackUrl: this.ackOutgoingEndpoint.url,
            changeEnabled: this.changeOutgoingEndpoint.enabled,
            changeUrl: this.changeOutgoingEndpoint.url,
            shipEnabled: this.shipOutgoingEndpoint.enabled,
            shipUrl: this.shipOutgoingEndpoint.url,
        });
    }

    ngOnChanges(changes: SimpleChanges): void {
        this.logger.debug('inside manageOutgoingEndpoints.ngOnChanges()');
        this.outgoingEndpointsForm.reset({
            ackEnabled: this.ackOutgoingEndpoint.enabled,
            ackUrl: this.ackOutgoingEndpoint.url,
            changeEnabled: this.changeOutgoingEndpoint.enabled,
            changeUrl: this.changeOutgoingEndpoint.url,
            shipEnabled: this.shipOutgoingEndpoint.enabled,
            shipUrl: this.shipOutgoingEndpoint.url,
        });
    }

    private createForm(): void {
        this.logger.debug('Created manageOutgoingEndpointsForm');
        this.outgoingEndpointsForm = this.formBuilder.group({
            ackEnabled: false,
            ackUrl: '',
            changeEnabled: false,
            changeUrl: '',
            shipEnabled: false,
            shipUrl: ''
        });
    }

    onAckEndpointChanged(): void {
        this.logger.debug('onAckEndpointChanged...');
        const eventValue: EhrOutgoingEndpoint = {
            enabled: this.outgoingEndpointsForm.get('ackEnabled').value,
            url: this.outgoingEndpointsForm.get('ackUrl').value,
        };
        this.ackEndpointChanged.emit(eventValue);
    }

    onChangeEndpointChanged(): void {
        this.logger.debug('onChangeEndpointChanged...');
        const eventValue: EhrOutgoingEndpoint = {
            enabled: this.outgoingEndpointsForm.get('changeEnabled').value,
            url: this.outgoingEndpointsForm.get('changeUrl').value,
        };
        this.changeEndpointChanged.emit(eventValue);
    }

    onShipEndpointChanged(): void {
        this.logger.debug('onShipEndpointChanged...');
        const eventValue: EhrOutgoingEndpoint = {
            enabled: this.outgoingEndpointsForm.get('shipEnabled').value,
            url: this.outgoingEndpointsForm.get('shipUrl').value,
        };
        this.shipEndpointChanged.emit(eventValue);
    }
}
