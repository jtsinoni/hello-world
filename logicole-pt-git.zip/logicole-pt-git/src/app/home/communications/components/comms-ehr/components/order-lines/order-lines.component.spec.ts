import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {NO_ERRORS_SCHEMA} from '@angular/core';

import {FormsModule} from '@angular/forms';
import {RouterTestingModule} from '@angular/router/testing';
import {HttpTestModule} from '../../../../../../common-components/test/http-test.module';
import {ToastrModule} from 'ngx-toastr';
import {NavigationTestModule} from '../../../../../../common-components/test/navigation-test/navigation-test.module';

import { OrderLinesComponent } from './order-lines.component';
import { LoggerService } from '../../../../../../services/logger/logger.service';
import { EhrService } from '../../services/ehr.service';
import { NotificationService } from '../../../../../../services/notification.service';
import { CommsUtilityService } from '../../../../services/comms-utility.service';

describe('OrderLinesComponent', () => {
  let component: OrderLinesComponent;
  let fixture: ComponentFixture<OrderLinesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        RouterTestingModule,
        HttpTestModule.forRoot(),
        ToastrModule.forRoot(),
        NavigationTestModule.forRoot(),
      ],
      declarations: [ OrderLinesComponent ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
      providers: [
        LoggerService,
        EhrService,
        NotificationService,
        CommsUtilityService
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrderLinesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
/*
  it('should create', () => {
    expect(component).toBeTruthy();
  });
*/
});
