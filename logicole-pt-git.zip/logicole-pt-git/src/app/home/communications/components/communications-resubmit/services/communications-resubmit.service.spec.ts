import { TestBed, inject } from '@angular/core/testing';

import { CommunicationsResubmitService } from './communications-resubmit.service';
import { LoggerService } from '../../../../../services/logger/logger.service';
import { CommsUtilityService } from '../../../services/comms-utility.service';

describe('CommunicationsResubmitService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CommunicationsResubmitService, LoggerService, CommsUtilityService]
    });
  });

  it('should be created', inject([CommunicationsResubmitService], (service: CommunicationsResubmitService) => {
    expect(service).toBeTruthy();
  }));
});
