import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';
import {Ng2SmartTableModule} from 'ng2-smart-table';
import {AgGridModule} from 'ag-grid-angular';
import {PipesModule} from '../../../../pipes/pipes.module';
import {CommonComponentsModule} from '../../../../common-components/common-components.module';

import { ServicesModule  } from './services/services.module';
import { CommunicationsResubmitComponent  } from './communications-resubmit.component';
import { CommunicationsResubmitRouterModule  } from './communications-resubmit.router';
import { CommsCommonComponentsModule } from 'app/home/communications/comms-common-components/comms-common-components.module';
import { CommsUtilityService } from '../../services/comms-utility.service';
import { LcGridModule  } from '../../../../common-components/lc-grid/lc-grid.module';
import { LcButtonLinkCellComponent } from '../../../../common-components/lc-grid/lc-button-link-cell/lc-button-link-cell.component';
import { LcGridButtonCellComponent } from '../../../../common-components/lc-grid/lc-button-cell/lc-button-cell.component';
import { LcGridCheckboxCellComponent } from '../../../../common-components/lc-grid/lc-grid-checkbox-cell/lc-grid-checkbox-cell.component';

@NgModule({
    imports: [
      CommonModule,
      FormsModule,
      Ng2SmartTableModule,
      AgGridModule.withComponents(
        [
            LcButtonLinkCellComponent,
            LcGridButtonCellComponent,
            LcGridCheckboxCellComponent,
        ]),
      PipesModule,
      CommonComponentsModule,
      CommunicationsResubmitRouterModule,
      CommsCommonComponentsModule,
      ServicesModule,
      LcGridModule,
    ],
    declarations: [
        CommunicationsResubmitComponent,
    ],
    exports: [
        CommunicationsResubmitComponent,
        CommunicationsResubmitRouterModule,
        CommsCommonComponentsModule,
        ServicesModule,
    ],
    providers: [CommsUtilityService]
  })
  export class CommunicationsResubmitModule {
  }
