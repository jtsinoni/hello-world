import {Ng2StateDeclaration} from '@uirouter/angular';
import {RouteConstants} from '../../../../constants/route.constants';
import {CommunicationsResubmitComponent} from './communications-resubmit.component';

export class CommunicationsResubmitStates {

  static COMMUNICATIONS_RESUBMIT_VIEW: Ng2StateDeclaration = {
    url: RouteConstants.COMMUNICATIONS_RESUBMIT.url,
    name: RouteConstants.COMMUNICATIONS_RESUBMIT.name,
    component: CommunicationsResubmitComponent,
    data: {'route': RouteConstants.COMMUNICATIONS_RESUBMIT}
  };
}
