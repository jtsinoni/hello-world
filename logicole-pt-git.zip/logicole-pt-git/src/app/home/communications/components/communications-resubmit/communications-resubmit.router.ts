import { NgModule } from '@angular/core';

import { RootModule, UIRouterModule } from '@uirouter/angular';
import { CommunicationsResubmitStates } from './communications-resubmit-states';

const communicationsResubmitRoutes: RootModule = {

  states: [
    CommunicationsResubmitStates.COMMUNICATIONS_RESUBMIT_VIEW,
  ]
};

  @NgModule({
    imports: [UIRouterModule.forChild(communicationsResubmitRoutes)],
    exports: [UIRouterModule]
  })
  export class CommunicationsResubmitRouterModule {

  }
