import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CommunicationsResubmitService } from './communications-resubmit.service';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [],
  providers: [
    CommunicationsResubmitService,
  ]
})
export class ServicesModule { }
