import { TestBed, inject } from '@angular/core/testing';

import { CommunicationsOutboundService } from './communications-outbound.service';

describe('CommunicationsOutboundServiceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CommunicationsOutboundService]
    });
  });

  it('should be created', inject([CommunicationsOutboundService], (service: CommunicationsOutboundService) => {
    expect(service).toBeTruthy();
  }));
});
