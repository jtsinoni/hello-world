import {Ng2StateDeclaration} from '@uirouter/angular';
import {RouteConstants} from '../../../../constants/route.constants';
import {CommunicationsOutboundConfigComponent} from './communications-outbound-config.component';

export class CommunicationsOutboundConfigStates {

  static COMMUNICATIONS_OUTBOUND_CONFIG_VIEW: Ng2StateDeclaration = {
    url: RouteConstants.COMMUNICATIONS_OUTBOUND_CONFIG.url,
    name: RouteConstants.COMMUNICATIONS_OUTBOUND_CONFIG.name,
    component: CommunicationsOutboundConfigComponent, data: {'route': RouteConstants.COMMUNICATIONS_OUTBOUND_CONFIG}
  };

}
