import { Injectable } from '@angular/core';
import { OutboundConfigInfo } from '../models/outbound-config-info';

@Injectable()
export class CommunicationsOutboundService {

  constructor() { }

  public getOutboundConfigInfo(dodaac: string): OutboundConfigInfo {
    const outboundConfigInfo: OutboundConfigInfo = {
      bufferSizeRange: {
        maxValue: 10000,
        minValue: 100,
      },
      currentSettings: {
        bufferSize: 4096,
        httpsRetries: 3,
        maxDataSize: 8192,
        maxTransferTime: 30,
        timeout: 30,
        tracingEnabled: true,
        truncate: true,
      },
      httpsRetriesRange: {
        maxValue: 60,
        minValue: 0,
      },
      maxTransferTimeRange: {
        maxValue: 3600,
        minValue: 1,
      },
      timeoutRange: {
        maxValue: 3600,
        minValue: 10,
      },
      maximumDataSizeRange: {
        maxValue: 10000,
        minValue: 100
      }
    };

    return outboundConfigInfo;
  }
}
