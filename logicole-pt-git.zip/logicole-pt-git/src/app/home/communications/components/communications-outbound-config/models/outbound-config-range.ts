export class OutboundConfigRange {
    public minValue: number;
    public maxValue: number;
}
