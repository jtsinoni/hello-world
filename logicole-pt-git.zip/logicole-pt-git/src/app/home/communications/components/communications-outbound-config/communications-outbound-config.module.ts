import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CommunicationsOutboundConfigComponent } from './communications-outbound-config.component';
import { ModelsModule } from './models/models.module';
// import { ServicesModule } from '../../../my-dashboard/services/services.module';
import { CommunicationsOutboundConfigRouterModule } from './communications-outbound-config.router';
import { CommsCommonComponentsModule } from '../../comms-common-components/comms-common-components.module';
import { ServicesModule } from './services/services.module';

@NgModule({
  imports: [
    CommonModule,
    ModelsModule,
//    ServicesModule,
    CommunicationsOutboundConfigRouterModule,
    CommsCommonComponentsModule,
    ServicesModule,
  ],
  declarations: [
    CommunicationsOutboundConfigComponent,
  ],
  exports: [
    CommunicationsOutboundConfigComponent,
    CommunicationsOutboundConfigRouterModule,
    CommsCommonComponentsModule,
    ServicesModule,
  ]
})
export class CommunicationsOutboundConfigModule { }
