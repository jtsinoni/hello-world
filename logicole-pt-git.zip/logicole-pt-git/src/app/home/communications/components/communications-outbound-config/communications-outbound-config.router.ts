import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginService } from '../../../../services/login.service';
import { CommunicationsOutboundConfigComponent } from './communications-outbound-config.component';
import { RouteConstants } from '../../../../constants/route.constants';

import { RootModule, UIRouterModule } from '@uirouter/angular';
import { CommunicationsOutboundConfigStates } from './communications-outbound-config-states';

const communicationsOutboundConfigRoutes: RootModule = {

  states: [
    CommunicationsOutboundConfigStates.COMMUNICATIONS_OUTBOUND_CONFIG_VIEW
  ]
};


@NgModule({
  imports: [UIRouterModule.forChild(communicationsOutboundConfigRoutes)],
  exports: [UIRouterModule]
})
  export class CommunicationsOutboundConfigRouterModule {

  }
/*
const communicationsOutboundConfigRoutes: Routes = [
//    {
//      path: '',
//      component:  CommunicationsOutboundConfigComponent,
//      data: {breadcrumb: 'Outbound Config'},
//      canActivate: [LoginService]
//    },
//    {
//      path: '',
//      redirectTo: RouteConstants.COMMUNICATIONS_OUTBOUND_CONFIG.route
//    }
  ];

  @NgModule({
    imports: [RouterModule.forChild(communicationsOutboundConfigRoutes)],
    exports: [RouterModule]
  })

  export class CommunicationsOutboundConfigRouterModule {

  }
*/
