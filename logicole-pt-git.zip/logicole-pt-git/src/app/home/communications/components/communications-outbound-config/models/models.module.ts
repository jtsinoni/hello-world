import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OutboundConfigInfo } from './outbound-config-info';

@NgModule({
  imports: [
    CommonModule,
  ],
  declarations: []
})
export class ModelsModule { }
