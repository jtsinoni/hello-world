import { OutboundConfigSettings } from './outbound-config-settings';
import { OutboundConfigRange } from './outbound-config-range';

export class OutboundConfigInfo {
    public currentSettings: OutboundConfigSettings;
    public httpsRetriesRange: OutboundConfigRange;
    public bufferSizeRange: OutboundConfigRange;
    public maxTransferTimeRange: OutboundConfigRange;
    public timeoutRange: OutboundConfigRange;
    public maximumDataSizeRange: OutboundConfigRange;
}
