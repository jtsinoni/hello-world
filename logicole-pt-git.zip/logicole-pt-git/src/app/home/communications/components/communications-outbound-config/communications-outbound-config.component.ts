import { Component, OnInit, Input } from '@angular/core';
import {LoggerService} from '../../../../services/logger/logger.service';
import { NotificationService } from '../../../../services/notification.service';
import { CommunicationsOutboundService } from './services/communications-outbound.service';
import { OutboundConfigInfo } from './models/outbound-config-info';

@Component({
  selector: 'communications-outbound-config',
  templateUrl: './communications-outbound-config.component.html',
  styleUrls: ['./communications-outbound-config.component.scss']
})
export class CommunicationsOutboundConfigComponent implements OnInit {

  public aValueChanged: boolean = false;
  public outboundTransmissionConfigurationExpanded: boolean = true;
  public outboundConfigInfo: OutboundConfigInfo;

  constructor(
    private configService: CommunicationsOutboundService,
    private logger: LoggerService,
    private notify: NotificationService) { }

  ngOnInit() {
    this.outboundTransmissionConfigurationExpanded = true;
    this.aValueChanged = false;
    this.outboundConfigInfo = this.configService.getOutboundConfigInfo('FM3500');

    this.logger.debug(`In Outbound Config ngOnInit() - maxBufferSize = ${this.outboundConfigInfo.bufferSizeRange.maxValue}`);
  }

  public getOutboundTransmissionConfigurationHeaderClass(): String {
    return this.outboundTransmissionConfigurationExpanded ? 'fa-caret-down' : 'fa-caret-right';
  }

  public getOutboundTransmissionConfigurationPanelClass(): String {
    return this.outboundTransmissionConfigurationExpanded ? 'in' : 'collapse';
  }

  public saveConfigurationChanges(): void {
    this.notify.successMsg('Configuration updated successfully');
    this.aValueChanged = false;
  }

  public onTracingEnabledChanged(): void {
    this.aValueChanged = true;
  }

  public onTruncateEnabledChanged(): void {
    this.aValueChanged = true;
  }

  public valueChanged(event): void {
    this.logger.debug(`In valueChanged() - ${event}`);
    if (event === true) {
      this.aValueChanged = true;
    } else {
      this.aValueChanged = false;
    }
  }
}
