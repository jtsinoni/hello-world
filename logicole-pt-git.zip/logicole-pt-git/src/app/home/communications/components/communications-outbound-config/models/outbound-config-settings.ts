export class OutboundConfigSettings {
    public httpsRetries: number;
    public bufferSize: number;
    public maxTransferTime: number;
    public timeout: number;
    public tracingEnabled: boolean;
    public truncate: boolean;
    public maxDataSize: number;
}
