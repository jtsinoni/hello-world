import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {NO_ERRORS_SCHEMA} from '@angular/core';

import {RouterTestingModule} from '@angular/router/testing';
import {HttpTestModule} from '../../../../common-components/test/http-test.module';
import {ToastrModule} from 'ngx-toastr';
import {NavigationTestModule} from '../../../../common-components/test/navigation-test/navigation-test.module';

import { CommunicationsSearchService } from './services/communications-search.service';
import { SearchResultModelService } from '../../comms-common-components/communications-record-detail/services/communications-record-detail.service';
import { FormBuilder } from '@angular/forms';
import { CommsUtilityService } from '../../services/comms-utility.service';
import { LoggerService } from '../../../../services/logger/logger.service';
import { StateNavigationService } from '../../../../services/state-navigation.service';

import { CommunicationsSearchComponent } from './communications-search.component';
import { CommunicationsSearchResult } from '../../comms-common-models/communications-search-result';
import { CommunicationsRecordDetailComponent } from '../../comms-common-components/communications-record-detail/communications-record-detail.component';

import { Ng2SmartTableModule } from 'ng2-smart-table';
import { ModelsModule } from './models/models.module';
import { ServicesModule } from './services/services.module';
import { CommonComponentsModule } from '../../../../common-components/common-components.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommsCommonComponentsModule } from '../../comms-common-components/comms-common-components.module';
import { CommunicationsRecordDetailServicesModule } from '../../comms-common-components/communications-record-detail/services/services.module';
import { LcButtonLinkCellComponent } from '../../../../common-components/lc-grid/lc-button-link-cell/lc-button-link-cell.component';
import { LcGridButtonCellComponent } from '../../../../common-components/lc-grid/lc-button-cell/lc-button-cell.component';
import { AgGridModule } from 'ag-grid-angular';

describe('CommunicationsSearchComponent', () => {
  let component: CommunicationsSearchComponent;
  let fixture: ComponentFixture<CommunicationsSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        ReactiveFormsModule,
        ModelsModule,
        Ng2SmartTableModule,
        ServicesModule,
        CommonComponentsModule,
        CommsCommonComponentsModule,
        CommunicationsRecordDetailServicesModule,
        RouterTestingModule,
        HttpTestModule.forRoot(),
        ToastrModule.forRoot(),
        NavigationTestModule.forRoot(),
        AgGridModule.withComponents(
          [
              LcButtonLinkCellComponent,
              LcGridButtonCellComponent,
          ]),
      ],
      declarations: [ CommunicationsSearchComponent ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
      providers: [
        CommunicationsSearchService,
        SearchResultModelService,
        FormBuilder,
        CommsUtilityService,
        LoggerService,
        StateNavigationService
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommunicationsSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
