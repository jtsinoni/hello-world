import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CommunicationsSearchResult } from '../../../comms-common-models/communications-search-result';

@NgModule({
  imports: [
    CommonModule,
  ],
  declarations: [],
  exports: [
  ]
})
export class ModelsModule { }
