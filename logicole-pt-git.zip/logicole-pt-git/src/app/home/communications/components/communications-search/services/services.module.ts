import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CommunicationsSearchService } from './communications-search.service';
import { CommsServicesModule } from '../../../services/comms-services.module';

@NgModule({
  imports: [
    CommonModule,
    CommsServicesModule,
  ],
  declarations: [],
  providers: [
    CommunicationsSearchService,
  ]
})
export class ServicesModule { }
