import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
// import { ModelsModule } from '../models/models.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonComponentsModule } from '../../../../../common-components/common-components.module';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        CommonComponentsModule,
    ],
    declarations: [
    ],
    exports: [
    ]
})
export class CommunicationsSearchComponentsModule { }
