import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CommunicationsSearchComponent } from './communications-search.component';
import { Ng2SmartTableModule } from 'ng2-smart-table';
import { ModelsModule } from './models/models.module';
import { ServicesModule } from './services/services.module';
import { CommonComponentsModule } from '../../../../common-components/common-components.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommunicationsSearchRouterModule } from './communications-search.router';
import { CommsCommonComponentsModule } from '../../comms-common-components/comms-common-components.module';
import { CommsUtilityService } from '../../services/comms-utility.service';
import { CommunicationsRecordDetailComponent } from '../../comms-common-components/communications-record-detail/communications-record-detail.component';
import { CommunicationsRecordDetailServicesModule } from '../../comms-common-components/communications-record-detail/services/services.module';
import { LcGridModule  } from '../../../../common-components/lc-grid/lc-grid.module';
import { LcButtonLinkCellComponent } from '../../../../common-components/lc-grid/lc-button-link-cell/lc-button-link-cell.component';
import { LcGridButtonCellComponent } from '../../../../common-components/lc-grid/lc-button-cell/lc-button-cell.component';
import { LcGridCheckboxCellComponent } from '../../../../common-components/lc-grid/lc-grid-checkbox-cell/lc-grid-checkbox-cell.component';
import {AgGridModule} from 'ag-grid-angular';

@NgModule({
  imports: [
    CommonModule,
    Ng2SmartTableModule,
    AgGridModule.withComponents(
      [
          LcButtonLinkCellComponent,
          LcGridButtonCellComponent,
          LcGridCheckboxCellComponent,
      ]),
  ModelsModule,
    ServicesModule,
    CommonComponentsModule,
    FormsModule,
    ReactiveFormsModule,
    CommunicationsSearchRouterModule,
    CommsCommonComponentsModule,
    CommunicationsRecordDetailServicesModule,
    LcGridModule,
  ],
  declarations: [
    CommunicationsSearchComponent,
  ],
  exports: [
    ModelsModule,
    ServicesModule,
    CommunicationsSearchComponent,
    CommunicationsSearchRouterModule,
    CommunicationsRecordDetailComponent,
  ],
  providers: [CommsUtilityService]
})
export class CommunicationsSearchModule { }
