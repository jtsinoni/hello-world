import { TestBed, inject } from '@angular/core/testing';
import {CommonModule} from '@angular/common';

import { NavigationTestModule } from '../../../../../common-components/test/navigation-test/navigation-test.module';
import { HttpTestModule } from '../../../../../common-components/test/http-test.module';

import { CommunicationsSearchService } from './communications-search.service';
import { LoggerService } from '../../../../../services/logger/logger.service';
import { CommsUtilityService } from '../../../services/comms-utility.service';
import { CommunicationsAdminApiService } from '../../../services/communications-admin-api.service';
import { ServicesModule } from './services.module';

describe('CommunicationsSearchService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpTestModule.forRoot(),
                ServicesModule,
                NavigationTestModule.forRoot(),
                CommonModule,
      ],
      providers: [CommunicationsSearchService, LoggerService, CommsUtilityService, CommunicationsAdminApiService]
    });
  });

  it('should be created', inject([CommunicationsSearchService], (service: CommunicationsSearchService) => {
    expect(service).toBeTruthy();
  }));
});
