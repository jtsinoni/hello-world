import { NgModule } from '@angular/core';

import { RootModule, UIRouterModule } from '@uirouter/angular';
import { CommunicationsSearchStates } from './communications-search-states';

const communicationsSearchRoutes: RootModule = {

  states: [
    CommunicationsSearchStates.COMMUNICATIONS_SEARCH_VIEW,
    CommunicationsSearchStates.COMMUNICATIONS_SEARCH_RECORD_DETAIL
  ]
};

  @NgModule({
    imports: [UIRouterModule.forChild(communicationsSearchRoutes)],
    exports: [UIRouterModule]
  })
  export class CommunicationsSearchRouterModule {

  }
