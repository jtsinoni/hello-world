import {Ng2StateDeclaration} from '@uirouter/angular';
import {RouteConstants} from '../../../../constants/route.constants';
import {CommunicationsSearchComponent} from './communications-search.component';
import {CommunicationsRecordDetailComponent} from '../../comms-common-components/communications-record-detail/communications-record-detail.component';

export class CommunicationsSearchStates {

  static COMMUNICATIONS_SEARCH_VIEW: Ng2StateDeclaration = {
    url: RouteConstants.COMMUNICATIONS_SEARCH.url,
    name: RouteConstants.COMMUNICATIONS_SEARCH.name,
    component: CommunicationsSearchComponent,
    data: {'route': RouteConstants.COMMUNICATIONS_SEARCH}
  };

  static COMMUNICATIONS_SEARCH_RECORD_DETAIL: Ng2StateDeclaration = {
    url: RouteConstants.COMMUNICATIONS_SEARCH_RECORD_DETAIL.url,
    name: RouteConstants.COMMUNICATIONS_SEARCH_RECORD_DETAIL.name,
    component: CommunicationsRecordDetailComponent,
    data: {'route': RouteConstants.COMMUNICATIONS_SEARCH_RECORD_DETAIL}
  };

}
