import { Component, OnInit, ViewChild } from '@angular/core';
import { CommunicationsSearchService } from './services/communications-search.service';
import { SearchResultModelService } from '../../comms-common-components/communications-record-detail/services/communications-record-detail.service';
import { FormGroup } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { CommunicationsSearchResult } from '../../comms-common-models/communications-search-result';

import { CommsUtilityService } from '../../services/comms-utility.service';
import { LoggerService } from '../../../../services/logger/logger.service';
import { StateNavigationService } from '../../../../services/state-navigation.service';
import { RouteConstants } from '../../../../constants/route.constants';

import { NotificationService } from '../../../../services/notification.service';
import { MessageBoxComponent } from '../../../../common-components/panels/message-box/message-box.component';
import { MessageBoxConfiguration } from '../../../../models/message-box-configuration';
import { MessageBoxIcon } from '../../../../models/message-box-icon';

import { GridOptions } from 'ag-grid/main';
import { LcGridCardSettings  } from '../../../../common-components/lc-grid/models/lc-grid-card-settings';
import { LcButtonLinkCellComponent } from '../../../../common-components/lc-grid/lc-button-link-cell/lc-button-link-cell.component';
import { LcGridButtonCellComponent } from '../../../../common-components/lc-grid/lc-button-cell/lc-button-cell.component';
import { LcGridCheckboxCellComponent } from '../../../../common-components/lc-grid/lc-grid-checkbox-cell/lc-grid-checkbox-cell.component';
import { LcGridDateCellComponent } from '../../../../common-components/lc-grid/lc-grid-date-cell/lc-grid-date-cell.component';
import { LcGridDatetimeCellComponent } from '../../../../common-components/lc-grid/lc-grid-datetime-cell/lc-grid-datetime-cell.component';
@Component({
    selector: 'communications-search',
    templateUrl: './communications-search.component.html',
    styleUrls: ['./communications-search.component.scss']
})
export class CommunicationsSearchComponent implements OnInit {
    @ViewChild('confirmationDialog') messageBox: MessageBoxComponent;
    public searchOptionsForm: FormGroup;

    minDate: Date = new Date();
    maxDate: Date = new Date();
    bsValue: Date = new Date();
    bsRangeValue: any = [];

    public communicationsResubmitDialogTitle: string;
    public communicationsResubmitDialogMessage: string;
    public showCommunicationsResubmitDialog: boolean = false;
    public communicationsResubmitDialogContent: string;

    public financialResubmitDialogTitle: string;
    public financialResubmitDialogMessage: string;
    public showFinancialResubmitDialog: boolean = false;
    private resubmitType: string = 'Communications';

    private resubmitCallNumber: string;

    msgBoxConfig: MessageBoxConfiguration = {
        showCloseButton: false,
        showOkCancelButtons: false,
        showYesNoButtons: true,
        allowBackdropClickToClose: false,
        allowEscapeToClose: false,
        showLargeModal: true,
        icon: MessageBoxIcon.informationIcon,
    };

    // ag-grid (lc-grid) setup
    private gridApi;
    private gridColumnApi;

    public gridCardSettings: LcGridCardSettings = {
        cardId: 'communicationsSearch',
        cardShowDownload: true,
        cardShowGlobalSearch: true,
        cardShowHeader: true,
        cardShowRefresh: true,
        cardTitle: 'Communications Search Results',
        cardTitleIcon: 'fa fa-phone',
        cardDownloadCsvFilename: 'communicationsSearch.csv',
    };

    public gridOptions: GridOptions = {
        enableFilter: true,
        floatingFilter: false,
        pagination: true,
        paginationPageSize: 20,
        domLayout: 'autoHeight',
        enableColResize: true,
        enableSorting: true,
        // rowHeight: 25,  // 25 is the default
        rowSelection: 'single',
        debug: false,

        defaultColDef: {
          // make every column non-editable
        editable: false,
          // make every column use 'text' filter by default
        },

        context: {componentParent: this,
                  buttonIconName: 'fa-send',
                  buttonToolTip: 'Resubmit',
                  buttonId: 'Resubmit'},

        columnDefs: [
          {
            width: 70,
            cellRendererFramework: LcGridButtonCellComponent
          },
          {
            headerName: 'Call/Sequence/Block Number',
            headerTooltip: 'Call Number',
            field: 'callNumber',
            tooltipField: 'callNumber',
            cellRendererFramework: LcButtonLinkCellComponent,
          },
          {
            headerName: 'Contract Number',
            headerTooltip: 'Contract Number',
            field: 'contractNumber',
            tooltipField: 'contractNumber',
          },
          {
            headerName: 'Audit Date',
            headerTooltip: 'Audit Date',
            field: 'auditDate',
            tooltipField: 'auditDate',
            cellRendererFramework: LcGridDatetimeCellComponent,
          },
          {
            headerName: 'Process Code',
            headerTooltip: 'Process Code',
            field: 'processCode',
            tooltipField: 'processCode',
          },
          {
            headerName: 'Txn Type TP Code',
            headerTooltip: 'Txn Type TP Code',
            field: 'transactionTypeTpcode',
            tooltipField: 'transactionTypeTpcode'
          },
          {
            headerName: 'Direction',
            headerTooltip: 'Direction',
            field: 'direction',
            tooltipField: 'direction'
          },
          {
            headerName: 'Channel ID',
            headerTooltip: 'Channel ID',
            field: 'channelId',
            tooltipField: 'channelId',
          },
          {
            headerName: 'Shipment ID',
            headerTooltip: 'Shipment ID',
            field: 'shipmentId',
            tooltipField: 'shipmentId',
          },
          {
            headerName: 'User ID',
            headerTooltip: 'User ID',
            field: 'userId',
            tooltipField: 'userId',
          },
          {
            headerName: 'ID',
            headerTooltip: 'ID',
            field: 'id',
            tooltipField: 'id',
            hide: true,
          },
          {
            headerName: 'Method',
            headerTooltip: 'Method',
            field: 'method',
            tooltipField: 'method',
            hide: true,
          },
          {
            headerName: 'Prime Vendor Status',
            headerTooltip: 'Prime Vendor Status',
            field: 'primeVendorStatus',
            tooltipField: 'primeVendorStatus',
            hide: true,
          },
          {
            headerName: 'Process Text',
            headerTooltip: 'Process Text',
            field: 'processText',
            tooltipField: 'processText',
            hide: true,
          },
          {
            headerName: 'Transaction Type Ext',
            headerTooltip: 'Transaction Type Ext',
            field: 'transactionTypeExtension',
            tooltipField: 'transactionTypeExtension',
            hide: true,
          },
          {
            headerName: 'Inbound Filename',
            headerTooltip: 'Inbound Filename',
            field: 'inboundFilename',
            tooltipField: 'inboundFilename',
            hide: true
          },
          {
            headerName: 'Source of Supply',
            headerTooltip: 'Source of Supply',
            field: 'sosCode',
            tooltipField: 'sosCode',
            hide: true,
          },
          {
            headerName: 'Resubmit Indicator',
            headerTooltip: 'Resubmit Indicator',
            field: 'resubmitIndicator',
            tooltipField: 'resubmitIndicator',
            hide: true,
          },
          {
            headerName: 'Application ID',
            headerTooltip: 'Application ID',
            field: 'applicationId',
            tooltipField: 'applicationId',
            hide: true,
          },
          {
            headerName: 'Target Filename',
            headerTooltip: 'Target Filename',
            field: 'targetFilename',
            tooltipField: 'targetFilename',
            hide: true,
          },
          {
            headerName: 'Dismiss Error Indicator',
            headerTooltip: 'Dissmiss Error Indicator',
            field: 'dismissErrorIndicator',
            tooltipField: 'dismissErrorIndicator',
            cellRendererFramework: LcGridCheckboxCellComponent, // This shows an example of using the lgGridCheckboxCellComponent (see lcGridCheckboxClicked, as well)
            hide: true,
          },
          {
            headerName: 'Dismiss Error User ID',
            headerTooltip: 'Dismiss Error User ID',
            field: 'dismissErrorUserId',
            tooltipField: 'dismissErrorUserId',
            hide: true,
          },
          {
            headerName: 'Dismiss Error Date',
            headerTooltip: 'Dismiss Error Date',
            field: 'dismissErrorDate',
            tooltipField: 'dismissErrorDate',
            hide: true,
          },
          {
            headerName: 'Dismissable Error Indicator',
            headerTooltip: 'Dismissable Error Indicator',
            field: 'dismissableErrorIndicator',
            tooltipField: 'dismissableErrorIndicator',
            hide: true,
          },
        ],
      };
    // ag-grid setup end

    constructor(private communicationsSearchService: CommunicationsSearchService,
                private commsRecordDetailService: SearchResultModelService,
                private fb: FormBuilder,
                private commsUtilityService: CommsUtilityService,
                private logger: LoggerService,
                private navigationService: StateNavigationService,
                private notify: NotificationService) {
        this.createSearchOptionsForm();
    }

    ngOnInit() {
        this.logger.debug(`IN communications-search ngOnInit()`);
        this.minDate.setDate(this.minDate.getDate() - 7);
        this.maxDate.setDate(this.minDate.getDate() + 7);
        this.bsRangeValue = [this.minDate, this.maxDate];

        this.getSearchResults();
        this.commsRecordDetailService.setReturnLocation('SEARCH');
    }

    goToDetail() {
        this.logger.debug(`going to COMMUNICATIONS_SEARCH_RECORD_DETAIL`);
        this.navigationService.navigateToState(RouteConstants.COMMUNICATIONS_SEARCH_RECORD_DETAIL);
    }

    public createSearchOptionsForm(): void {
        const beginDate = new Date();
        beginDate.setDate(beginDate.getDate() - 7);

        this.logger.debug('date format is ' + beginDate.toISOString().substring(0, 10));

        this.searchOptionsForm = this.fb.group({
            'beginDate': beginDate.toISOString().substring(0, 10),
            'endDate': new Date().toISOString().substring(0, 10),
        });
    }

    private createColumn(columnsObject: any, fieldId: string, columnTitle): any {
        const newColumn = {
            title: columnTitle,
        };
        columnsObject[fieldId] = newColumn;
        return newColumn;
    }

    public getSearchResults(): void {
        this.loadData();
    }

    private contractNumberClicked(rowData: CommunicationsSearchResult) {
        this.logger.debug('viewDetails button was clicked: ' + JSON.stringify(rowData, null, 3));

        this.communicationsSearchService.setSelectedSearchResult(rowData);
        this.commsRecordDetailService.setSelectedResultRecord(rowData);
        this.goToDetail();
    }

    public loadData(): void {
        this.logger.debug(`In loadData()  -  bsRangeValue = ${this.bsRangeValue}`);
        this.commsRecordDetailService.setTableData(this.communicationsSearchService.getCommunicationsSearchResults(this.bsRangeValue[0], this.bsRangeValue[1]));
    }

    public getSearchTableData(): Array<CommunicationsSearchResult> {
        return this.commsRecordDetailService.getTableData();
    }

    public onDismissClicked(guid: string): void {
        this.logger.debug(`Dismiss button was clicked. Removing record with guid = ${guid}`);
        this.commsRecordDetailService.dismissRecord(guid);
    }

    private onFinancialResubmitYesClicked(): void {
        this.resubmitType = 'Financial';
        this.showFinancialResubmitDialog = false;
        this.showResubmitDialog();
    }

    private onFinancialResubmitNoClicked(): void {
        this.resubmitType = 'Communications';
        this.showFinancialResubmitDialog = false;
        this.showResubmitDialog();
    }

    onMessageBoxButtonClicked(buttonThatWasClicked: string): void {
        this.logger.debug('CommunicationsSearchComponent.onMsgBoxButtonClicked(): button that was clicked is ' + buttonThatWasClicked);

        switch (buttonThatWasClicked) {
            case 'Yes':
                this.notify.successMsg('Call number ' + this.resubmitCallNumber + ' was resubmitted.');
                break;
            case 'No':
                this.notify.infoMsg('Resubmit cancelled for call number ' + this.resubmitCallNumber + '.');
                break;
        }

        this.messageBox.hideDialog();
    }

    showResubmitDialog(): void {
        this.messageBox.showDialog();
        this.communicationsResubmitDialogTitle = this.resubmitType + ' Resubmit';
        this.communicationsResubmitDialogMessage = 'Perform a ' + this.resubmitType + ' Resubmit on call number ' + this.resubmitCallNumber + '?';
        this.communicationsResubmitDialogContent = 'Call Number to resubmit: ' + this.resubmitCallNumber;
    }

    // ag-grid functions
    onGridReady(params) {
        this.logger.debug(`communications-search onGridReady`);

        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;

        if (this.communicationsSearchService.getSearchResultsLoaded()) {
            params.api.setRowData(this.commsRecordDetailService.getTableData());
            params.api.sizeColumnsToFit();
        }

        this.commsRecordDetailService.setGridApi(this.gridApi);
        this.communicationsSearchService.setGridApi(this.gridApi);

        // just here to show how to listen for an event - in this case a column event
        // params.api.addGlobalListener(function (type, event) {
        //  if (type.indexOf("column") >= 0) {
        // console.log("Got column event: ", event);
        //  }
        // });
    }

    onGridSizeChanged(params) {
        params.api.sizeColumnsToFit();
    }

    onRefreshClick(param: string = '') {
//        this.gridApi.setRowData([]);
        this.gridApi.showLoadingOverlay();
        this.logger.debug(`communications-search: onRefreshClick(${param})`);
        this.getSearchResults();
//        this.gridApi.setRowData(this.commsRecordDetailService.getTableData());
//        this.commsRecordDetailService.setGridApi(this.gridApi);
    }

    public lcGridGoToRowDetails(row: any) {
        this.logger.debug(`communications-resubmit: lcGridGoToRowDetails(${row.callNumber})`);
        this.commsRecordDetailService.setTableData(this.communicationsSearchService.getTableData());
        this.contractNumberClicked(row);
    }

    public lcGridRowButtonClicked(searchTableRow: any) {
        this.resubmitCallNumber = searchTableRow.callNumber;
        this.logger.debug('resubmit button was clicked for call number: ' + JSON.stringify(this.resubmitCallNumber, null, 3));
        this.commsRecordDetailService.setSelectedResultRecord(searchTableRow);

        if (searchTableRow.direction === 'OUTBOUND') {
            this.showFinancialResubmitDialog = true;
            this.financialResubmitDialogTitle = 'Select Resubmit Type';
            this.financialResubmitDialogMessage = 'Do you want to perform a financial resubmit on call number "' +
                searchTableRow.callNumber + '"?';
        } else {
            this.onFinancialResubmitNoClicked();
        }
    }

    // This method demonstrates how to process values from the LcGridCheckboxCellComponent
    lcGridCheckboxClicked(row: any, value: boolean): void {
        row.dismissErrorIndicator = value;
        this.communicationsSearchService.setSelectedSearchResult(row);
        // would need to update the grid too.
    }
}
