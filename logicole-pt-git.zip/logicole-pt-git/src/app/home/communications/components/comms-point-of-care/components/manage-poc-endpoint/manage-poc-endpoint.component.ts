import { Component, OnInit, OnChanges, Input, Output, EventEmitter, SimpleChanges } from '@angular/core';
import { PocSystemRecord } from '../../models/poc-system-record';
import { InternalCustomer } from '../../../../comms-common-models/internal-customer';
import { FormBuilder, FormGroup } from '@angular/forms';
import { LoggerService } from '../../../../../../services/logger/logger.service';
import { StateNavigationService } from 'app/services/state-navigation.service';
import { RouteConstants } from 'app/constants/route.constants';
import { PocStateService } from '../../services/poc-state.service';
import { ManagePocEndpointMode } from '../../models/manage-poc-endpoint-mode';
import { PocService } from '../../services/poc.service';
import { NotificationService } from '../../../../../../services/notification.service';

@Component({
  selector: 'lc-manage-poc-endpoint',
  templateUrl: './manage-poc-endpoint.component.html',
  styleUrls: ['./manage-poc-endpoint.component.scss']
})
export class ManagePocEndpointComponent implements OnInit, OnChanges {

    public managePocEndpointForm: FormGroup;

    constructor(private logger: LoggerService,
                private formBuilder: FormBuilder,
                private pocService: PocService,
                private notificationService: NotificationService,
                private navigationService: StateNavigationService,
                public pocStateService: PocStateService) {
        this.logger.debug('Inside ManagePocEndpointComponent constructor');
        this.createForm();
     }

    ngOnInit() {
        this.logger.debug('Inside of ManagePocEndpointComponent.ngOnInit.');
        this.ngOnChanges(null);
    }

    ngOnChanges(changes: SimpleChanges): void {
        this.logger.debug('Inside of ManagePocEndpointComponent.ngOnInit - resetting form value.');
        this.managePocEndpointForm.reset({
            name: this.pocStateService.PocSystemRecord.name,
            description: this.pocStateService.PocSystemRecord.description,
            distinguishedName: this.pocStateService.PocSystemRecord.distinguishedName,
            enabled: this.pocStateService.PocSystemRecord.enabled,
        });
    }

    public onCancelClicked(): void {
        this.ngOnChanges(null);
        this.logger.debug('ManagePocEndpointComponent.onCancelClicked().  Navigating...');
        this.navigationService.navigateToState(RouteConstants.COMMUNICATIONS_POINT_OF_CARE);
    }

    public onSaveClicked(): void {
        const model = this.managePocEndpointForm.value;

        const updatedRecord: PocSystemRecord = {
            id: this.pocStateService.PocSystemRecord.id,
            dodaac: this.pocStateService.PocSystemRecord.dodaac,
            guid: this.pocStateService.PocSystemRecord.guid,
            name: model.name,
            description: model.description,
            distinguishedName: model.distinguishedName,
            enabled: model.enabled,
            deleted: this.pocStateService.PocSystemRecord.deleted,
            assignedCustomers: [],
        };
        updatedRecord.assignedCustomers.push(...this.pocStateService.PocSystemRecord.assignedCustomers);
        this.logger.debug('ManagePocEndpointDialog.onSaveClicked(): updatedRecord is ' + JSON.stringify(updatedRecord, null, 3));
        switch (this.pocStateService.ManagePocEndpointMode) {
            case ManagePocEndpointMode.ADD_MODE:
                this.pocService.addPocSystemRecord(updatedRecord);
                this.notificationService.successMsg('Record was added successfully.');
                break;
            case ManagePocEndpointMode.EDIT_MODE:
                this.pocService.updatePocSystemRecord(updatedRecord);
                this.notificationService.successMsg('Record was updated successfully.');
                break;
        }

        this.navigationService.navigateToState(RouteConstants.COMMUNICATIONS_POINT_OF_CARE);
    }

    private createForm(): void {
        this.managePocEndpointForm = this.formBuilder.group({
            name: '',
            description: '',
            distinguishedName: '',
            enabled: false,
        });
    }

    onAssignedCustomersChanged(assignedCustomers: Array<InternalCustomer>): void {
        this.logger.debug('ManagePocEndpointDialog.onAssignedCustomersChanged(): assignedCustomers is now: ' + JSON.stringify(assignedCustomers, null, 3));
        this.pocStateService.PocSystemRecord.assignedCustomers = [];
        this.pocStateService.PocSystemRecord.assignedCustomers.push(...assignedCustomers);
    }

    getModeString(): string {
        let modeString: string = '';
        switch (this.pocStateService.ManagePocEndpointMode) {
            case ManagePocEndpointMode.ADD_MODE:
                modeString = 'Add';
                break;
            case ManagePocEndpointMode.EDIT_MODE:
                modeString = 'Edit';
                break;
        }
        return modeString;
    }
}
