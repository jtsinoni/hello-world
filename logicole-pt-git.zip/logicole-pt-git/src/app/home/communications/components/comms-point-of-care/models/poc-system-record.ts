import { InternalCustomer } from '../../../comms-common-models/internal-customer';

export class PocSystemRecord {
    public id: string;
    public guid: string;
    public dodaac: string;
    public name: string;
    public description?: string;
    public distinguishedName: string;
    public enabled: boolean;
    public deleted: boolean;
    public assignedCustomers: Array<InternalCustomer>;
}
