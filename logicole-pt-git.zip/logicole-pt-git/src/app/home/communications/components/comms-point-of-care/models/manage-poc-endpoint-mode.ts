export enum ManagePocEndpointMode {
    ADD_MODE,
    EDIT_MODE,
}
