import { Injectable } from '@angular/core';
import { PocSystemRecord } from 'app/home/communications/components/comms-point-of-care/models/poc-system-record';
import { InternalCustomer } from 'app/home/communications/comms-common-models/internal-customer';
import { ManagePocEndpointMode } from '../models/manage-poc-endpoint-mode';

@Injectable()
export class PocStateService {
    public pocSystemRecord: PocSystemRecord;
    private availableCustomers: Array<InternalCustomer>;
    private managePocEndpointMode: ManagePocEndpointMode;

  constructor() {
      this.managePocEndpointMode = ManagePocEndpointMode.ADD_MODE;
  }

  public get PocSystemRecord(): PocSystemRecord {
      return this.pocSystemRecord;
  }

  public set PocSystemRecord(pocSystemRecord: PocSystemRecord) {
      this.pocSystemRecord = pocSystemRecord;
  }

  public get AvailableCustomers(): Array<InternalCustomer> {
      return this.availableCustomers;
  }

  public set AvailableCustomers(availableCustomers: Array<InternalCustomer>) {
      this.availableCustomers = availableCustomers;
  }

  public get ManagePocEndpointMode(): ManagePocEndpointMode {
      return this.managePocEndpointMode;
  }

  public set ManagePocEndpointMode(managePocEndpointMode: ManagePocEndpointMode) {
      this.managePocEndpointMode = managePocEndpointMode;
  }
}
