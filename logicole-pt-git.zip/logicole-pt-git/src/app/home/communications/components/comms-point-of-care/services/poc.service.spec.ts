import { TestBed, inject } from '@angular/core/testing';

import { PocService } from './poc.service';
import { LoggerService } from '../../../../../services/logger/logger.service';
import { CommsUtilityService } from '../../../services/comms-utility.service';

describe('PocService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PocService, LoggerService, CommsUtilityService]
    });
  });

  it('should be created', inject([PocService], (service: PocService) => {
    expect(service).toBeTruthy();
  }));
});
