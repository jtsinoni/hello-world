import { Injectable } from '@angular/core';
import { PocSystemRecord } from '../models/poc-system-record';
import { LoggerService } from '../../../../../services/logger/logger.service';
import { CommsUtilityService } from '../../../services/comms-utility.service';
import { InternalCustomer } from '../../../comms-common-models/internal-customer';

@Injectable()
export class PocService {

    private systemList: Array<PocSystemRecord> = [];
    private gridApi;

    constructor(private logger: LoggerService, private commsUtilService: CommsUtilityService) {
        this.buildRecordList();
    }

    public getPocSystemsForDodaac(dodaac: string): Array<PocSystemRecord> {
        const list: Array<PocSystemRecord> = [];
        list.push(...this.systemList);
        return list;
    }

    public updatePocSystemRecord(recordToUpdate: PocSystemRecord): number {
        let numUpdated: number = 0;
        const index = this.getIndexForRecord(recordToUpdate);
        if (index >= 0) {
            this.systemList[index] = recordToUpdate;
            numUpdated = 1;
        }
        this.updateGridApiRowData();
        return numUpdated;
    }

    public addPocSystemRecord(recordToAdd: PocSystemRecord): number {
        const numAdded: number = 1;

        recordToAdd.guid = this.commsUtilService.generateGuidLikeString();
        recordToAdd.id = this.commsUtilService.generateGuidLikeString();
        this.systemList.push(recordToAdd);
        this.updateGridApiRowData();
        return numAdded;
    }

    public deleteEhrSystemRecord(recordToDelete: PocSystemRecord): number {
        let numDeleted: number = 0;
        const index = this.getIndexForRecord(recordToDelete);
        if (index >= 0) {
            this.logger.debug('Deleting pocSystemRecord at index ' + index);
            numDeleted = 1;
            this.systemList.splice(Number(index), 1);
            this.logger.debug('now systemList looks like ' + JSON.stringify(this.systemList, null, 3));
        }
        return numDeleted;
    }

    private getIndexForRecord(recordToFind: PocSystemRecord): number {
        let index: number = -1;
        for (let i: number = 0; i < this.systemList.length; i++) {
            if (this.systemList[i].id === recordToFind.id) {
                index = i;
                break;
            }
        }
        return index;
    }

    private buildRecordList(): void {
        for (let i = 0; i < 7; i++) {
            this.systemList.push(this.createRandomPocRecord(i));
        }
        const customers: Array<InternalCustomer> = this.commsUtilService.getCustomerList();

        for (let i = 0; i < this.systemList.length; i++) {
            for (let j = 0; j < this.commsUtilService.getRandomInt(6) + 1; j++) {
                const custIdx: number = this.commsUtilService.getRandomInt(customers.length);
                this.systemList[i].assignedCustomers.push(customers[custIdx]);
                customers.splice(custIdx, 1);
            }
        }
    }

    private createRandomPocRecord(index: number): PocSystemRecord {
        const record = new PocSystemRecord();
        record.assignedCustomers = [];
        record.deleted = false;
        record.description = 'POC Test System ' + (index + 1);
        record.distinguishedName = '/C=US/O=U.S. GOVERNMENT/OU=DOD/OU=PKI/OU=CONTRACTOR/CN=POCSYS.' + this.commsUtilService.zeroFillLeft(String(index), 4);
        record.dodaac = 'ABC';
        record.enabled = this.commsUtilService.getRandomBoolean();
        record.guid = this.commsUtilService.generateGuidLikeString();
        record.id = this.commsUtilService.generateGuidLikeString();
        record.name = 'POC' + this.commsUtilService.zeroFillLeft(String(index + 1), 3);

        record.assignedCustomers = [];
        return record;
    }

    public setGridApi(gridApi: any): void {
        this.gridApi = gridApi;
    }

    private updateGridApiRowData(): void {
        this.gridApi.setRowData(this.systemList);
    }
}
