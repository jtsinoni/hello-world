import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {NO_ERRORS_SCHEMA} from '@angular/core';

import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {RouterTestingModule} from '@angular/router/testing';
import {ToastrModule} from 'ngx-toastr';

import { ManagePocEndpointComponent } from './manage-poc-endpoint.component';
import { FormBuilder, FormGroup } from '@angular/forms';
import { PocService } from '../../services/poc.service';
import { StateNavigationService } from '@lc-services/*';
import { Ng2SmartTableModule } from 'ng2-smart-table';
import { CommonComponentsModule } from 'app/common-components/common-components.module';
import { CommsCommonComponentsModule } from 'app/home/communications/comms-common-components/comms-common-components.module';
import { HttpTestModule } from 'app/common-components/test/http-test.module';
import { NavigationTestModule } from 'app/common-components/test/navigation-test/navigation-test.module';
import { LoggerService } from 'app/services/logger/logger.service';
import { NotificationService } from 'app/services/notification.service';
import { PocStateService } from 'app/home/communications/components/comms-point-of-care/services/poc-state.service';
import { CommsUtilityService } from '../../../../services/comms-utility.service';
import { PocSystemRecord } from 'app/home/communications/components/comms-point-of-care/models/poc-system-record';
import { InternalCustomer } from '../../../../comms-common-models/internal-customer';

export class PocStateServiceMock {
  public pocSystemRecord: PocSystemRecord = {id: 'abcd',
  guid: 'xxxxx',
  dodaac: 'aaaaa',
  name: 'fred',
  description: 'desc',
  distinguishedName: 'frederick',
  enabled: true,
  deleted: false,
  assignedCustomers: [{
    'orgSerial': 5482,
    'customerAccountId': 'YMVPHN',
    'customerName': 'WINDER VAULT - PHARMACY',
    'displayName': 'YMVPHN - WINDER VAULT - PHARMACY',
    'pointOfCareSystemGuid': '82693049-2416-4f48-8630-466bf85026ea',
    'sendCatalogIndicator': true,
    'sendEquipmentIndicator': true,
    'lastCatalogRequestDate': new Date('2017-07-28T14:49:20.635'),
    'lastEquipmentRequestDate': new Date('0001-01-01T00:00:00')
  }]};

  public availableCustomers: Array<InternalCustomer> = [{
    'orgSerial': 5482,
    'customerAccountId': 'YMVPHN',
    'customerName': 'WINDER VAULT - PHARMACY',
    'displayName': 'YMVPHN - WINDER VAULT - PHARMACY',
    'pointOfCareSystemGuid': '82693049-2416-4f48-8630-466bf85026ea',
    'sendCatalogIndicator': true,
    'sendEquipmentIndicator': true,
    'lastCatalogRequestDate': new Date('2017-07-28T14:49:20.635'),
    'lastEquipmentRequestDate': new Date('0001-01-01T00:00:00')
  }];

  constructor() {
  }

  public get PocSystemRecord(): PocSystemRecord {
    return {id: 'abcd',
            guid: 'xxxxx',
            dodaac: 'aaaaa',
            name: 'fred',
            description: 'desc',
            distinguishedName: 'frederick',
            enabled: true,
            deleted: false,
            assignedCustomers: [{
              'orgSerial': 5482,
              'customerAccountId': 'YMVPHN',
              'customerName': 'WINDER VAULT - PHARMACY',
              'displayName': 'YMVPHN - WINDER VAULT - PHARMACY',
              'pointOfCareSystemGuid': '82693049-2416-4f48-8630-466bf85026ea',
              'sendCatalogIndicator': true,
              'sendEquipmentIndicator': true,
              'lastCatalogRequestDate': new Date('2017-07-28T14:49:20.635'),
              'lastEquipmentRequestDate': new Date('0001-01-01T00:00:00')
            }]};
  }

  public set PocSystemRecord(pocSystemRecord: PocSystemRecord) {
    this.pocSystemRecord = {id: 'abcd',
    guid: 'xxxxx',
    dodaac: 'aaaaa',
    name: 'fred',
    description: 'desc',
    distinguishedName: 'frederick',
    enabled: true,
    deleted: false,
    assignedCustomers: [{
      'orgSerial': 5482,
      'customerAccountId': 'YMVPHN',
      'customerName': 'WINDER VAULT - PHARMACY',
      'displayName': 'YMVPHN - WINDER VAULT - PHARMACY',
      'pointOfCareSystemGuid': '82693049-2416-4f48-8630-466bf85026ea',
      'sendCatalogIndicator': true,
      'sendEquipmentIndicator': true,
      'lastCatalogRequestDate': new Date('2017-07-28T14:49:20.635'),
      'lastEquipmentRequestDate': new Date('0001-01-01T00:00:00')
    }]};
  }

  public get AvailableCustomers(): Array<InternalCustomer> {
  //  return this.availableCustomers;

    return [{
      'orgSerial': 5482,
      'customerAccountId': 'YMVPHN',
      'customerName': 'WINDER VAULT - PHARMACY',
      'displayName': 'YMVPHN - WINDER VAULT - PHARMACY',
      'pointOfCareSystemGuid': '82693049-2416-4f48-8630-466bf85026ea',
      'sendCatalogIndicator': true,
      'sendEquipmentIndicator': true,
      'lastCatalogRequestDate': new Date('2017-07-28T14:49:20.635'),
      'lastEquipmentRequestDate': new Date('0001-01-01T00:00:00')
    }];
}

public set AvailableCustomers(availableCustomers: Array<InternalCustomer>) {
    this.availableCustomers = [{
      'orgSerial': 5482,
      'customerAccountId': 'YMVPHN',
      'customerName': 'WINDER VAULT - PHARMACY',
      'displayName': 'YMVPHN - WINDER VAULT - PHARMACY',
      'pointOfCareSystemGuid': '82693049-2416-4f48-8630-466bf85026ea',
      'sendCatalogIndicator': true,
      'sendEquipmentIndicator': true,
      'lastCatalogRequestDate': new Date('2017-07-28T14:49:20.635'),
      'lastEquipmentRequestDate': new Date('0001-01-01T00:00:00')
    }];
}

}

describe('ManagePocEndpointComponent', () => {
  let component: ManagePocEndpointComponent;
  let fixture: ComponentFixture<ManagePocEndpointComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
    declarations: [ ManagePocEndpointComponent ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
    imports: [
        FormsModule,
        ReactiveFormsModule,
        Ng2SmartTableModule,
        CommonComponentsModule,
        CommsCommonComponentsModule,
        RouterTestingModule,
        HttpTestModule.forRoot(),
        ToastrModule.forRoot(),
        NavigationTestModule.forRoot(),
      ],
    providers: [
      LoggerService,
      FormBuilder,
      PocService,
      NotificationService,
      StateNavigationService,
      {provide: PocStateService, useClass: PocStateServiceMock, useValue: {}},
//      PocStateService,
      CommsUtilityService,
    ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManagePocEndpointComponent);
    component = fixture.componentInstance;

/*     component.managePocEndpointForm.reset({
      name: 'howard',
      description: 'hello',
      distinguishedName: 'frederick',
      enabled: true,
    });
 */
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
