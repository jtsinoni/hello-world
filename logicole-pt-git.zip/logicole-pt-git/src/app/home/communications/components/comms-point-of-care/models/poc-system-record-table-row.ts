import { PocSystemRecord } from './poc-system-record';

export class PocSystemRecordTableRow extends PocSystemRecord {
    public customerCount: number;
}
