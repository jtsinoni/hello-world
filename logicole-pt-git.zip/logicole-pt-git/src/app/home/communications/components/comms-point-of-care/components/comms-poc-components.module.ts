import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ManagePocEndpointComponent } from './manage-poc-endpoint/manage-poc-endpoint.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommsCommonComponentsModule } from '../../../comms-common-components/comms-common-components.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    CommsCommonComponentsModule,
  ],
  declarations: [ManagePocEndpointComponent],
  exports: [ ManagePocEndpointComponent ]
})
export class CommsPocComponentsModule { }
