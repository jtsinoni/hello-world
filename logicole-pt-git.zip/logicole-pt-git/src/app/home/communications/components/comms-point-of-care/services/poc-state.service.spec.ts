import { TestBed, inject } from '@angular/core/testing';

import { PocStateService } from './poc-state.service';

describe('PocStateService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PocStateService]
    });
  });

  it('should be created', inject([PocStateService], (service: PocStateService) => {
    expect(service).toBeTruthy();
  }));
});
