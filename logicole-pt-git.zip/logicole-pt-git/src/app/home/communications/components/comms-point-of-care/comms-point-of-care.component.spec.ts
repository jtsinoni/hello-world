import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {NO_ERRORS_SCHEMA} from '@angular/core';

import {FormsModule} from '@angular/forms';
import {RouterTestingModule} from '@angular/router/testing';
import {HttpTestModule} from '../../../../common-components/test/http-test.module';
import {ToastrModule} from 'ngx-toastr';
import {NavigationTestModule} from '../../../../common-components/test/navigation-test/navigation-test.module';

import { CommsPointOfCareComponent } from './comms-point-of-care.component';
import { LoggerService } from '../../../../services/logger/logger.service';
import { PocService } from './services/poc.service';
import { NotificationService } from '../../../../services/notification.service';
import { CommsUtilityService } from '../../services/comms-utility.service';
import { StateNavigationService } from '@lc-services/*';
import { PocStateService } from './services/poc-state.service';

describe('CommsPointOfCareComponent', () => {
  let component: CommsPointOfCareComponent;
  let fixture: ComponentFixture<CommsPointOfCareComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        RouterTestingModule,
        HttpTestModule.forRoot(),
        ToastrModule.forRoot(),
        NavigationTestModule.forRoot(),
      ],
      declarations: [ CommsPointOfCareComponent ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
      providers: [
        LoggerService,
        PocService,
        NotificationService,
        CommsUtilityService,
        StateNavigationService,
        PocStateService,
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommsPointOfCareComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
