import { NgModule } from '@angular/core';
import { LoginService } from '../../../../services/login.service';
import { CommsPointOfCareComponent } from './comms-point-of-care.component';
import { RouteConstants } from '../../../../constants/route.constants';

import { RootModule, UIRouterModule } from '@uirouter/angular';
import { CommsPointOfCareStates } from './comms-point-of-care-states';

const commsPointOfCareRoutes: RootModule = {

  states: [
    CommsPointOfCareStates.COMMUNICATIONS_POC_VIEW,
    CommsPointOfCareStates.COMMUNICATIONS_POC_ADD_SYSTEM_VIEW,
    CommsPointOfCareStates.COMMUNICATIONS_POC_EDIT_SYSTEM_VIEW
  ]
};

  @NgModule({
    imports: [UIRouterModule.forChild(commsPointOfCareRoutes)],
    exports: [UIRouterModule]
  })
  export class CommsPocRouterModule {
  }
