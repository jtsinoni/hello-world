import { Component, OnInit, ViewChild } from '@angular/core';
import { LcTableSettings } from '../../../../common-components/lc-table/models/lc-table-settings';
import { PocSystemRecordTableRow } from './models/poc-system-record-table-row';
import { LoggerService } from '../../../../services/logger/logger.service';
import { PocService } from './services/poc.service';
import { NotificationService } from '../../../../services/notification.service';
import { EhrTableColumnService } from '../comms-ehr/services/ehr-table-column.service';
import { CommsUtilityService } from '../../services/comms-utility.service';
import { InternalCustomer } from '../../comms-common-models/internal-customer';
import { PocSystemRecord } from './models/poc-system-record';
import { MessageBoxComponent } from '../../../../common-components/panels/message-box/message-box.component';
import { MessageBoxConfiguration } from '../../../../models/message-box-configuration';
import { MessageBoxIcon } from '../../../../models/message-box-icon';
import { StateNavigationService } from 'app/services/state-navigation.service';
import { RouteConstants } from 'app/constants/route.constants';
import { PocStateService } from './services/poc-state.service';
import { ManagePocEndpointMode } from './models/manage-poc-endpoint-mode';

import { GridOptions } from 'ag-grid/main';
import { LcGridCardSettings  } from '../../../../common-components/lc-grid/models/lc-grid-card-settings';
import { LcButtonLinkCellComponent } from '../../../../common-components/lc-grid/lc-button-link-cell/lc-button-link-cell.component';
import { LcGridButtonCellComponent } from '../../../../common-components/lc-grid/lc-button-cell/lc-button-cell.component';
import { LcGridCheckboxCellComponent } from '../../../../common-components/lc-grid/lc-grid-checkbox-cell/lc-grid-checkbox-cell.component';

@Component({
    selector: 'app-comms-point-of-care',
    templateUrl: './comms-point-of-care.component.html',
    styleUrls: ['./comms-point-of-care.component.scss']
})
export class CommsPointOfCareComponent implements OnInit {
    @ViewChild('confirmationDialog') messageBox: MessageBoxComponent;

    public pointOfCareTableData: Array<PocSystemRecordTableRow> = [];

    public dialogTitle: string;
    public dialogMessage: string;
    public dialogContent: string;
    private pocSystemRecordToDelete: PocSystemRecord;

    msgBoxConfig: MessageBoxConfiguration = {
        showCloseButton: false,
        showOkCancelButtons: false,
        showYesNoButtons: true,
        allowBackdropClickToClose: false,
        allowEscapeToClose: false,
        showLargeModal: true,
        icon: MessageBoxIcon.warningIcon,
    };

    // ag-grid (lc-grid) setup
    private gridApi;
    private gridColumnApi;

    public gridCardSettings: LcGridCardSettings = {
        cardId: 'managePointOfCareSystems',
        cardShowDownload: true,
        cardShowGlobalSearch: true,
        cardShowHeader: true,
        cardShowRefresh: true,
        cardTitle: 'Manage Point of Care Systems',
        cardTitleIcon: 'fa fa-phone',
        cardDownloadCsvFilename: 'managePointOfCareSsytems.csv',
    };

    public gridOptions: GridOptions = {
        enableFilter: true,
        floatingFilter: false,
        pagination: true,
        paginationPageSize: 20,
        domLayout: 'autoHeight',
        enableColResize: true,
        enableSorting: true,
        // rowHeight: 25,  // 25 is the default
        rowSelection: 'single',
        debug: false,

        defaultColDef: {
          // make every column non-editable
        editable: false,
        },

        context: {componentParent: this,
                  buttonIconName: 'fa-times',
                  buttonToolTip: 'Delete Point of Care Endpoint',
                  buttonId: 'deletePointOfCareEndpoint'},

        columnDefs: [
          {
            width: 70,
            cellRendererFramework: LcGridButtonCellComponent
          },
          {
            headerName: 'Name',
            headerTooltip: 'Endpoint Name',
            field: 'name',
            tooltipField: 'name',
            cellRendererFramework: LcButtonLinkCellComponent,
          },
          {
            headerName: 'Description',
            headerTooltip: 'Description',
            field: 'description',
            tooltipField: 'description',
          },
          {
            headerName: 'Distinguished Name',
            headerTooltip: 'Distinguished Name',
            field: 'distinguishedName',
            tooltipField: 'distinguishedName',
          },
          {
            headerName: 'Enabled',
            headerTooltip: 'Enabled',
            field: 'enabled',
            tooltipField: 'enabled',
            cellRendererFramework: LcGridCheckboxCellComponent,
          },
          {
            headerName: 'Customer Count',
            headerTooltip: 'Customer Count',
            field: 'customerCount',
            tooltipField: 'customerCount',
            filter: 'agNumberColumnFilter',
          },
        ],
      };
    // ag-grid setup end

    constructor(private logger: LoggerService,
        private pocService: PocService,
        private pocStateService: PocStateService,
        private notify: NotificationService,
        private commsUtilService: CommsUtilityService,
        private navigationService: StateNavigationService) { }

    ngOnInit() {
        this.logger.debug('Inside of CommsPointOfCareComponent.ngOnInit()');
        this.loadData();
        this.pocStateService.AvailableCustomers = this.commsUtilService.getCustomerList();
    }

    private managePointOfCareNameClicked(row: PocSystemRecordTableRow): void {
        this.logger.debug('managePointOfCareNameClicked: ' + JSON.stringify(row, null, 3));
        this.pocStateService.PocSystemRecord = row;
        this.pocStateService.ManagePocEndpointMode = ManagePocEndpointMode.EDIT_MODE;
        this.navigationService.navigateToState(RouteConstants.COMMUNICATIONS_POINT_OF_CARE_EDIT_SYSTEM);
    }

    private loadData(): void {
        this.pointOfCareTableData = [];
        const tableData: Array<PocSystemRecordTableRow> =  <Array<PocSystemRecordTableRow>> this.pocService.getPocSystemsForDodaac('ABC');

        for (let i = 0; i < tableData.length; i++) {
            tableData[i].customerCount = tableData[i].assignedCustomers.length;
        }
        this.pointOfCareTableData = tableData;
    }


    private onDeleteEndpointYesClicked(): void {
        const numDeleted: number = this.pocService.deleteEhrSystemRecord(this.pocSystemRecordToDelete);
        this.notify.successMsg('The Point of Care Endpoint was successfully deleted.');
        this.onRefreshClick();
    }

    private onDeleteEndpointNoClicked(): void {
    }


    public onAddNewEndpointClicked(): void {
        const newRecord: PocSystemRecord = {
            id: null,
            guid: null,
            name: '',
            description: '',
            enabled: false,
            assignedCustomers: [],
            distinguishedName: '',
            dodaac: 'ABC',
            deleted: false,
        };
        this.pocStateService.PocSystemRecord = <PocSystemRecordTableRow>newRecord;
        this.pocStateService.ManagePocEndpointMode = ManagePocEndpointMode.ADD_MODE;
        this.logger.debug('onAddNewEndpointClicked: going to new state');
        this.navigationService.navigateToState(RouteConstants.COMMUNICATIONS_POINT_OF_CARE_ADD_SYSTEM);
    }

    onMessageBoxButtonClicked(buttonThatWasClicked: string): void {
        this.logger.debug('CommsPointOfCareComponent.onMsgBoxButtonClicked(): button that was clicked is ' + buttonThatWasClicked);
        switch (buttonThatWasClicked) {
            case 'Yes':
                this.onDeleteEndpointYesClicked();
                break;
            case 'No':
                this.onDeleteEndpointNoClicked();
                break;
        }
        this.messageBox.hideDialog();
    }

    // ag-grid functions
    onGridReady(params) {
        this.logger.debug(`point of care onGridReady`);

        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;

        params.api.setRowData(this.pointOfCareTableData);
        params.api.sizeColumnsToFit();

        this.pocService.setGridApi(this.gridApi);

        // just here to show how to listen for an event - in this case a column event
        // params.api.addGlobalListener(function (type, event) {
        //  if (type.indexOf("column") >= 0) {
        // console.log("Got column event: ", event);
        //  }
        // });
    }

    onGridSizeChanged(params) {
        params.api.sizeColumnsToFit();
    }

    onRefreshClick(param: string = '') {
        this.gridApi.setRowData([]);
        this.logger.debug(`point of care: onRefreshClick(${param})`);
        this.loadData();
        this.gridApi.setRowData(this.pointOfCareTableData);
    }

    public lcGridGoToRowDetails(row: any) {
        this.logger.debug(`point of care: lcGridGoToRowDetails(${row.name})`);
        this.managePointOfCareNameClicked(row);
    }

    public lcGridRowButtonClicked(rowData: any) {
        this.pocSystemRecordToDelete = rowData;
        this.logger.debug('deleteEndpoint button was clicked: ' + JSON.stringify(rowData, null, 3));
        this.messageBox.showDialog();
        this.dialogTitle = 'Confirm Delete Endpoint';
        this.dialogMessage = 'Are you sure you wish to delete endpoint "' + this.pocSystemRecordToDelete.name +
                            '" with the following Distinguished Name?';
        this.dialogContent = this.pocSystemRecordToDelete.distinguishedName;
    }

    // This method demonstrates how to process values from the LcGridCheckboxCellComponent
    lcGridCheckboxClicked(row: any, value: boolean): void {
        row.enabled = value;
    }
}
