import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ModelsModule } from './models/models.module';
import { CommsPocServicesModule } from './services/comms-poc-services.module';
import { CommsPointOfCareComponent } from './comms-point-of-care.component';
import { CommsPocRouterModule } from './comms-point-of-care.router';
import { LcTableModule } from '../../../../common-components/lc-table/lc-table.module';
import { CommsPocComponentsModule } from './components/comms-poc-components.module';
import { CommsCommonComponentsModule } from '../../comms-common-components/comms-common-components.module';
import { CommonComponentsModule } from '../../../../common-components/common-components.module';
import { CommsUtilityService } from '../../services/comms-utility.service';

@NgModule({
  imports: [
    CommonModule,
    ModelsModule,
    CommsPocServicesModule,
    CommsPocRouterModule,
    LcTableModule,
    CommsPocComponentsModule,
    CommsCommonComponentsModule,
    CommonComponentsModule,
  ],
  declarations: [
    CommsPointOfCareComponent,
  ],
  exports: [
    CommsPointOfCareComponent,
    CommsPocRouterModule,
  ],
  providers: [CommsUtilityService]
})
export class CommsPointOfCareModule { }
