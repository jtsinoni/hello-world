import {Ng2StateDeclaration} from '@uirouter/angular';
import {RouteConstants} from '../../../../constants/route.constants';
import {CommsPointOfCareComponent} from './comms-point-of-care.component';
import { ManagePocEndpointComponent } from './components/manage-poc-endpoint/manage-poc-endpoint.component';

export class CommsPointOfCareStates {

  static COMMUNICATIONS_POC_VIEW: Ng2StateDeclaration = {
    url: RouteConstants.COMMUNICATIONS_POINT_OF_CARE.url,
    name: RouteConstants.COMMUNICATIONS_POINT_OF_CARE.name,
    component: CommsPointOfCareComponent, data: {'route': RouteConstants.COMMUNICATIONS_POINT_OF_CARE}
  };
  static COMMUNICATIONS_POC_ADD_SYSTEM_VIEW: Ng2StateDeclaration = {
    url: RouteConstants.COMMUNICATIONS_POINT_OF_CARE_ADD_SYSTEM.url,
    name: RouteConstants.COMMUNICATIONS_POINT_OF_CARE_ADD_SYSTEM.name,
    component: ManagePocEndpointComponent, data: {'route': RouteConstants.COMMUNICATIONS_POINT_OF_CARE_ADD_SYSTEM}
  };
  static COMMUNICATIONS_POC_EDIT_SYSTEM_VIEW: Ng2StateDeclaration = {
    url: RouteConstants.COMMUNICATIONS_POINT_OF_CARE_EDIT_SYSTEM.url,
    name: RouteConstants.COMMUNICATIONS_POINT_OF_CARE_EDIT_SYSTEM.name,
    component: ManagePocEndpointComponent, data: {'route': RouteConstants.COMMUNICATIONS_POINT_OF_CARE_EDIT_SYSTEM}
  };

}
