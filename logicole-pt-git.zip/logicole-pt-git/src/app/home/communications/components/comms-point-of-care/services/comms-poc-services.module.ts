import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PocService } from './poc.service';
import { PocStateService } from './poc-state.service';

@NgModule({
  imports: [
    CommonModule,
  ],
  declarations: [
  ],
  providers: [
    PocService,
    PocStateService,
  ]
})
export class CommsPocServicesModule { }
