import { Component, OnInit, EventEmitter, Input, Output, SimpleChanges } from '@angular/core';
import { CommunicationsGatewayErrorsObject } from '../models/communications-gateway-errors-object';
import { CommunicationsGatewayErrorService } from '../services/communications-gateway-error.service';
import { LoggerService } from '../../../../../services/logger/logger.service';
import { FormBuilder, FormGroup } from '@angular/forms';
import { StateNavigationService } from '../../../../../services/state-navigation.service';
import { RouteConstants } from '../../../../../constants/route.constants';

import { CommunicationsGatewayErrorsComponent } from '../communications-gateway-errors.component';

@Component({
    selector: 'lc-gateway-error-detail',
    templateUrl: './gateway-error-detail.component.html',
    styleUrls: ['./gateway-error-detail.component.scss']
})
export class GatewayErrorDetailComponent implements OnInit {
    @Output() public goBackClicked: EventEmitter<string> = new EventEmitter();
    @Output() public dismissClicked: EventEmitter<string> = new EventEmitter();

    public currentRecord: CommunicationsGatewayErrorsObject;
    public searchResults: Array<CommunicationsGatewayErrorsObject>;
    public currentPageIndex: number;

    public gatewayErrorDetailForm: FormGroup;

    public showDismissButton: boolean = false;

    constructor(private logger: LoggerService,
                private fb: FormBuilder,
                private commsGatewayErrorService: CommunicationsGatewayErrorService,
                private navigationService: StateNavigationService) {
        this.createForm();
    }

    ngOnInit() {
            this.currentRecord = this.commsGatewayErrorService.getSelectedGatewayErrorResult();
            this.searchResults = this.commsGatewayErrorService.getTableData();

            this.logger.debug(`currentRecord id = ${this.currentRecord.id}`);
            this.logger.debug(`NUMBER OF ROWS IN searchResults = ${this.searchResults.length}`);


            this.refreshForm();
    }

    goToGatewayErrorsList() {
        this.navigationService.navigateTo(RouteConstants.COMMUNICATIONS_GATEWAY_ERRORS);
    }

    private refreshForm(): void {
        if (this.currentRecord === undefined || this.currentRecord === null || this.searchResults === undefined || this.searchResults === null) {
            this.goToGatewayErrorsList();
            return;
        }

        this.currentPageIndex = this.findIndexOfCurrentRecord();
        this.gatewayErrorDetailForm.reset({
            dateReceived: this.currentRecord.dateReceived,
            fileNameSize: this.currentRecord.fileNameSize,
            httpResponseCode: this.currentRecord.httpResponseCode,
            responseSummary: this.currentRecord.responseSummary,
            responseSize: this.currentRecord.responseSize,
            user: this.currentRecord.user,
            inboundUrl: this.currentRecord.inboundUrl,
            channelId: this.currentRecord.channelId,
            inboundFilename: this.currentRecord.inboundFilename,
            method: this.currentRecord.method,
            dataFormat: this.currentRecord.dataFormat,
            queryFields: this.currentRecord.queryFields,
            dismissErrorIndicator: this.currentRecord.dismissErrorIndicator,
            dismissErrorUserId: this.currentRecord.dismissErrorUserId,
            dismissErrorDate: this.currentRecord.dismissErrorDate,
            commsErrorIndicator: this.currentRecord.commsErrorIndicator
        });

        const currentDissmissErrorIndicator = String(this.currentRecord.dismissErrorIndicator);
        this.showDismissButton = ( this.currentRecord.dismissErrorIndicator === false || currentDissmissErrorIndicator === 'N');
    }

    public onBackClicked(): void {
        this.goBackClicked.emit(null);
        this.goToGatewayErrorsList();
    }

    public onDismissClicked(): void {
        this.dismissClicked.emit(this.currentRecord.id);
        this.commsGatewayErrorService.dismissRecord(this.currentRecord.id);
        this.searchResults = this.commsGatewayErrorService.getTableData();
        this.goToGatewayErrorsList();
    }

    onPageIndexChanged(newPageIndex: number): void {
        this.currentPageIndex = newPageIndex;
        this.currentRecord = this.searchResults[this.currentPageIndex];
        this.refreshForm();
    }

    private findIndexOfCurrentRecord(): number {
        let pageIndex = 0;
        for (let i = 0; i < this.searchResults.length; i++) {
            if (this.searchResults[i].id === this.currentRecord.id) {
                pageIndex = i;
                break;
            }
        }
        return pageIndex;
    }

    private createForm(): void {
        this.gatewayErrorDetailForm = this.fb.group({
            dateReceived: null,
            fileNameSize: null,
            httpResponseCode: null,
            responseSummary: null,
            responseSize: null,
            user: null,
            inboundUrl: null,
            channelId: null,
            inboundFilename: null,
            method: null,
            dataFormat: null,
            queryFields: null,
            dismissErrorIndicator: null,
            dismissErrorUserId: null,
            dismissErrorDate: null,
            commsErrorIndicator: null
        });
    }
}

