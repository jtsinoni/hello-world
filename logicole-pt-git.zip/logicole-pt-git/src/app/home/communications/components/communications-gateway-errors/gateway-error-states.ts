import {Ng2StateDeclaration} from '@uirouter/angular';
import {RouteConstants} from '../../../../constants/route.constants';
import {CommunicationsGatewayErrorsComponent} from './communications-gateway-errors.component';
import {GatewayErrorDetailComponent} from './gateway-error-detail/gateway-error-detail.component';
export class GatewayErrorsStates {

  static GATEWAY_ERROR_VIEW: Ng2StateDeclaration = {
    url: RouteConstants.COMMUNICATIONS_GATEWAY_ERRORS.url,
    name: RouteConstants.COMMUNICATIONS_GATEWAY_ERRORS.name,
    component: CommunicationsGatewayErrorsComponent,
    data: {'route': RouteConstants.COMMUNICATIONS_GATEWAY_ERRORS}
  };

  static GATEWAY_ERROR_DETAIL: Ng2StateDeclaration = {
    url: RouteConstants.COMMUNICATIONS_GATEWAY_ERROR_DETAIL.url,
    name: RouteConstants.COMMUNICATIONS_GATEWAY_ERROR_DETAIL.name,
    component: GatewayErrorDetailComponent,
    data: {'route': RouteConstants.COMMUNICATIONS_GATEWAY_ERROR_DETAIL}
  };

}
