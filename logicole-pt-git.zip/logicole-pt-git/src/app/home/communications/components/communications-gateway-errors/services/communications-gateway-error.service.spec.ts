import { TestBed, inject } from '@angular/core/testing';

import { CommunicationsGatewayErrorService } from './communications-gateway-error.service';
import { CommsUtilityService } from '../../../services/comms-utility.service';
import { LoggerService } from '../../../../../services/logger/logger.service';

describe('CommunicationsGatewayErrorService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CommunicationsGatewayErrorService, LoggerService, CommsUtilityService]
    });
  });

  it('should be created', inject([CommunicationsGatewayErrorService], (service: CommunicationsGatewayErrorService) => {
    expect(service).toBeTruthy();
  }));
});
