import { Component, OnInit, ViewChild} from '@angular/core';
import { CommunicationsGatewayErrorsObject } from './models/communications-gateway-errors-object';
import { CommunicationsGatewayErrorService } from './services/communications-gateway-error.service';
import { LoggerService } from '../../../../services/logger/logger.service';
import { NotificationService } from '../../../../services/notification.service';
import { LcButtonCellComponent } from '../../../../common-components/lc-table/lc-button-cell/lc-button-cell.component';
import { LcButtonCallbackEvent } from '../../../../common-components/lc-table/models/lc-button-callback-event';
import { LcLinkCellComponent } from '../../../../common-components/lc-table/lc-link-cell/lc-link-cell.component';
import { CommsUtilityService } from '../../services/comms-utility.service';
import { LocalDataSource } from 'ng2-smart-table/lib/data-source/local/local.data-source';
import { GatewayErrorDetailComponent } from '../communications-gateway-errors/gateway-error-detail/gateway-error-detail.component';
import {StateNavigationService} from '../../../../services/state-navigation.service';
import {RouteConstants} from '../../../../constants/route.constants';

import { GridOptions } from 'ag-grid/main';
import { LcGridCardSettings  } from '../../../../common-components/lc-grid/models/lc-grid-card-settings';
import { LcGridButtonCellComponent } from '../../../../common-components/lc-grid/lc-button-cell/lc-button-cell.component';
import { LcButtonLinkCellComponent } from '../../../../common-components/lc-grid/lc-button-link-cell/lc-button-link-cell.component';

@Component({
  selector: 'communications-gateway-errors',
  templateUrl: './communications-gateway-errors.component.html',
  styleUrls: ['./communications-gateway-errors.component.scss']
})

export class CommunicationsGatewayErrorsComponent implements OnInit {
  public selected = [];
  public dismissAllButtonEnabled: boolean;

  public selectedDismissCount: number;

  public selectedGatewayErrorResult: CommunicationsGatewayErrorsObject;
  public dataSource: LocalDataSource;

  // ag-grid (lc-grid) setup
  private gridApi;
  private gridColumnApi;

  public gridCardSettings: LcGridCardSettings = {
      cardId: 'communicationsGatewayDismissal',
      cardShowDownload: true,
      cardShowGlobalSearch: true,
      cardShowHeader: true,
      cardShowRefresh: true,
      cardTitle: 'Communications Gateway Dismissal Results',
      cardTitleIcon: 'fa fa-phone',
      cardDownloadCsvFilename: 'communicationsGatewayDismissal.csv',
  };

    public gridOptions: GridOptions = {
      enableFilter: true,
      floatingFilter: false,
      pagination: true,
      paginationPageSize: 20,
      domLayout: 'autoHeight',
      enableColResize: true,
      enableSorting: true,
      // rowHeight: 25,  // 25 is the default
      rowSelection: 'single',
      debug: false,

      defaultColDef: {
        // make every column non-editable
      editable: false,
        // make every column use 'text' filter by default
      },

      context: {componentParent: this,
                buttonIconName: 'fa-check-square-o',
                buttonToolTip: 'Dismiss record',
                buttonId: 'dismissGatewayRecord'},

      columnDefs: [
        {
//          colId: 'dismissButton',
//          headerName: 'Dismiss',
          width: 40,
          cellRendererFramework: LcGridButtonCellComponent
        },
        {
          headerName: 'Date Received',
          headerTooltip: 'Date Received',
          field: 'dateReceived',
          tooltipField: 'dateReceived',
          filter: 'agDateColumnFilter',
        },
        {
          headerName: 'Inbound URL',
          headerTooltip: 'Inbound URL',
          field: 'inboundUrl',
          tooltipField: 'inboundUrl',
          cellRendererFramework: LcButtonLinkCellComponent
        },
        {
          headerName: 'HTTP Response Code',
          headerTooltip: 'HTTP Response Code',
          field: 'httpResponseCode',
          tooltipField: 'httpResponseCode',
        },
        {
          headerName: 'Response Summary',
          headerTooltip: 'Response Summary',
          field: 'responseSummary',
          tooltipField: 'responseSummary',
        },
        {
          headerName: 'Inbound Filename',
          headerTooltip: 'Inbound Filename',
          field: 'inboundFilename',
          tooltipField: 'inboundFilename',
        },
        {
          headerName: 'Filename Size',
          headerTooltip: 'Filename Size',
          field: 'fileNameSize',
          tooltipField: 'fileNameSize',
          hide: true,
        },
        {
          headerName: 'Response Size',
          headerTooltip: 'Response Size',
          field: 'responseSize',
          tooltipField: 'responseSize',
          hide: true,
        },
        {
          headerName: 'Channel ID',
          headerTooltip: 'Channel ID',
          field: 'channelId',
          tooltipField: 'channelId',
          hide: true,
        },
        {
          headerName: 'ID',
          headerTooltip: 'ID',
          field: 'id',
          tooltipField: 'id',
          hide: true,
        },
        {
          headerName: 'Method',
          headerTooltip: 'Method',
          field: 'method',
          tooltipField: 'method',
          hide: true,
        },
        {
          headerName: 'Data Format',
          headerTooltip: 'Data Format',
          field: 'dataFormat',
          tooltipField: 'dataFormat',
          hide: true,
        },
        {
          headerName: 'Query Fields',
          headerTooltip: 'Query Fields',
          field: 'queryFields',
          tooltipField: 'queryFields',
          hide: true,
        },
        {
          headerName: 'User',
          headerTooltip: 'User',
          field: 'user',
          tooltipField: 'user',
          hide: true,
        },
        {
          headerName: 'Dismiss Error Indicator',
          headerTooltip: 'Dissmiss Error Indicator',
          field: 'dismissErrorIndicator',
          tooltipField: 'dismissErrorIndicator',
          hide: true,
        },
        {
          headerName: 'Dismiss Error User ID',
          headerTooltip: 'Dismiss Error User ID',
          field: 'dismissErrorUserId',
          tooltipField: 'dismissErrorUserId',
          hide: true,
        },
        {
          headerName: 'Dismiss Error Date',
          headerTooltip: 'Dismiss Error Date',
          field: 'dismissErrorDate',
          tooltipField: 'dismissErrorDate',
          hide: true,
        },
        {
          headerName: 'Dismissable Error Indicator',
          headerTooltip: 'Dismissable Error Indicator',
          field: 'dismissableErrorIndicator',
          tooltipField: 'dismissableErrorIndicator',
          hide: true,
        },
      ],
    };
  // ag-grid setup end

  constructor(public communicationsGatewayErrorService: CommunicationsGatewayErrorService,
              private commsUtilityService: CommsUtilityService,
              private notify: NotificationService,
              private logger: LoggerService,
              private navigationService: StateNavigationService) {
    this.dataSource = new LocalDataSource(this.communicationsGatewayErrorService.getTableData());
  }

  ngOnInit() {
    this.logger.debug(`IN NGONINIT() OF GATEWAY ERRORS COMPONENT`);
    this.selectedDismissCount = 0;
//    this.initializeTable();
    this.loadData();
    this.setDismissAllButtonState();
  }

  gotToDetail() {
    this.navigationService.navigateToState(RouteConstants.COMMUNICATIONS_GATEWAY_ERROR_DETAIL);
  }

  private setDismissAllButtonState(): void {
    this.dismissAllButtonEnabled = this.communicationsGatewayErrorService.getTableData().length > 0;
  }

// ng2-smart-table methods
  public loadData(): void {
    this.communicationsGatewayErrorService.getGatewayErrorResults('FM4500');
  }
  private inboundUrlClicked(rowData: CommunicationsGatewayErrorsObject) {
    this.selectedGatewayErrorResult = rowData;
    this.communicationsGatewayErrorService.setSelectedGatewayErrorResult(rowData);
    this.gotToDetail();
  }

  private processButtonCallbackEvent(buttonCallbackEvent: LcButtonCallbackEvent): void {
    this.communicationsGatewayErrorService.dismissRecord(buttonCallbackEvent.rowData.id);
    this.setDismissAllButtonState();
  }

  public getTableData(): Array<CommunicationsGatewayErrorsObject> {
    this.setDismissAllButtonState();
    return this.communicationsGatewayErrorService.getTableData();
  }

  onDismissAllClicked() {
    let guid: string;
    const lcTableData = this.communicationsGatewayErrorService.getTableData();
    const totalDismissed: number = this.communicationsGatewayErrorService.getTableData().length;

    for (let i = 0; i < lcTableData.length; i++) {
      guid = lcTableData[i].id;
      this.communicationsGatewayErrorService.dismissRecord(guid);
    }

    this.setDismissAllButtonState();
    this.notify.successMsg(totalDismissed + ' gateway error records dismissd.');
  }

    // ag-grid functions
    onGridReady(params) {
      this.logger.debug(`communications-search onGridReady`);

      this.gridApi = params.api;
      this.gridColumnApi = params.columnApi;

      params.api.setRowData(this.getTableData());
      params.api.sizeColumnsToFit();

      this.communicationsGatewayErrorService.setGridApi(this.gridApi);

      this.setDismissAllButtonState();

      // just here to show how to listen for an event - in this case a column event
      // params.api.addGlobalListener(function (type, event) {
      //  if (type.indexOf("column") >= 0) {
      // console.log("Got column event: ", event);
      //  }
      // });
  }

  onGridSizeChanged(params) {
      params.api.sizeColumnsToFit();
  }

  onRefreshClick(param: string = '') {
    this.gridApi.setRowData([]);
    this.logger.debug(`communications-error-dismissal: onRefreshClick(${param})`);
    this.loadData();
    this.gridApi.setRowData(this.communicationsGatewayErrorService.getTableData());
    this.communicationsGatewayErrorService.setGridApi(this.gridApi);
    this.setDismissAllButtonState();
  }

  public lcGridGoToRowDetails(row: any) {
    this.logger.debug(`communications-resubmit: lcGridGoToRowDetails(${row.inboundUrl})`);
    this.inboundUrlClicked(row);
}

  public lcGridRowButtonClicked(searchTableRow: any) {
    this.logger.debug(`Removing guid (id)... ${searchTableRow.id}`);

    this.communicationsGatewayErrorService.dismissRecord(searchTableRow.id);
    this.gridApi.setRowData(this.communicationsGatewayErrorService.getTableData());

    this.setDismissAllButtonState();
  }
}
