import { IcommunicationsGatewayErrorsObject } from './icommunications-gateway-errors-object';

export class CommunicationsGatewayErrorsObject implements IcommunicationsGatewayErrorsObject {
    public id: string;
    public dateReceived: Date;
    public fileNameSize: string;
    public httpResponseCode: string;
    public responseSummary: string;
    public responseSize: number;
    public user: string;
    public inboundUrl: string;
    public channelId: string;
    public inboundFilename: string;
    public method: string;
    public dataFormat: string;
    public queryFields: string;
    public dismissErrorIndicator: boolean;
    public dismissErrorUserId: string;
    public dismissErrorDate: Date;
    public commsErrorIndicator: boolean;
}
