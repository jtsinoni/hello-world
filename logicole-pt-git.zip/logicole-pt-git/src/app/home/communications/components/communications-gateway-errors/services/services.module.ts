import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CommunicationsGatewayErrorService } from './communications-gateway-error.service';

@NgModule({
  imports: [
    CommonModule,
  ],
  declarations: [],
  providers: [
    CommunicationsGatewayErrorService,
  ]
})
export class ServicesModule { }
