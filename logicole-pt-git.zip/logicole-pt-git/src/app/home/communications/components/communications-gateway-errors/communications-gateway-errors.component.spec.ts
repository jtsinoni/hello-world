import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {NO_ERRORS_SCHEMA} from '@angular/core';

import {RouterTestingModule} from '@angular/router/testing';
import {HttpTestModule} from '../../../../common-components/test/http-test.module';
import {ToastrModule} from 'ngx-toastr';
import {NavigationTestModule} from '../../../../common-components/test/navigation-test/navigation-test.module';

import { CommunicationsGatewayErrorsComponent } from './communications-gateway-errors.component';
import { CommunicationsGatewayErrorService } from './services/communications-gateway-error.service';
import { CommsUtilityService } from '../../services/comms-utility.service';
import { LoggerService } from '../../../../services/logger/logger.service';
import { StateNavigationService } from '../../../../services/state-navigation.service';
import { NotificationService } from '../../../../services/notification.service';

import { ServicesModule } from './services/services.module';
import { CommonComponentsModule } from '../../../../common-components/common-components.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ModelsModule } from './models/models.module';
import { AgGridModule } from 'ag-grid-angular';
import { LcGridModule  } from '../../../../common-components/lc-grid/lc-grid.module';
import { LcButtonLinkCellComponent } from '../../../../common-components/lc-grid/lc-button-link-cell/lc-button-link-cell.component';
import { LcGridButtonCellComponent } from '../../../../common-components/lc-grid/lc-button-cell/lc-button-cell.component';
import { LcGridCheckboxCellComponent } from '../../../../common-components/lc-grid/lc-grid-checkbox-cell/lc-grid-checkbox-cell.component';

describe('CommunicationsGatewayErrorsComponent', () => {
  let component: CommunicationsGatewayErrorsComponent;
  let fixture: ComponentFixture<CommunicationsGatewayErrorsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        ServicesModule,
        CommonComponentsModule,
        AgGridModule.withComponents(
          [
              LcButtonLinkCellComponent,
              LcGridButtonCellComponent,
              LcGridCheckboxCellComponent,
          ]),
        ModelsModule,
        FormsModule,
        ReactiveFormsModule,
        RouterTestingModule,
        HttpTestModule.forRoot(),
        ToastrModule.forRoot(),
        NavigationTestModule.forRoot(),
        LcGridModule,
      ],
      declarations: [ CommunicationsGatewayErrorsComponent ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
      providers: [
        CommunicationsGatewayErrorService,
        CommsUtilityService,
        NotificationService,
        LoggerService,
        StateNavigationService,
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommunicationsGatewayErrorsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
