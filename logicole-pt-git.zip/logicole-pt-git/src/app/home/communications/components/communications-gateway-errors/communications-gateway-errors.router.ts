import { NgModule } from '@angular/core';
import { RootModule, UIRouterModule } from '@uirouter/angular';
import { GatewayErrorsStates } from './gateway-error-states';

const communicationsGatewayErrorsRoutes: RootModule = {

  states: [
    GatewayErrorsStates.GATEWAY_ERROR_VIEW,
    GatewayErrorsStates.GATEWAY_ERROR_DETAIL
  ]
};

@NgModule({
  imports: [UIRouterModule.forChild(communicationsGatewayErrorsRoutes)],
  exports: [UIRouterModule]
})
  export class CommunicationsGatewayErrorsRouterModule {

  }
