import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import {GatewayErrorDetailComponent} from './gateway-error-detail.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {ToastrModule} from 'ngx-toastr';
import {CommunicationsGatewayErrorService} from '../services/communications-gateway-error.service';
import {CommsUtilityService} from '../../../services/comms-utility.service';
import {CommonComponentsModule} from '../../../../../common-components/common-components.module';
import {LoggerService} from '@lc-services/*';
import {CommunicationsGatewayErrorsObject} from '../models/communications-gateway-errors-object';
import {NavigationTestModule} from '../../../../../common-components/test/navigation-test/navigation-test.module';
import {NotificationService} from '../../../../../services/notification.service';


export class CommunicationsGatewayErrorServiceMock {

  constructor() {
  }

  getSelectedGatewayErrorResult(): CommunicationsGatewayErrorsObject  {
    return new CommunicationsGatewayErrorsObject();
  }

  getTableData(): Array<CommunicationsGatewayErrorsObject> {
    return new Array<CommunicationsGatewayErrorsObject>();
  }
}

describe('GatewayErrorDetailComponentComponent', () => {
  let component: GatewayErrorDetailComponent;
  let fixture: ComponentFixture<GatewayErrorDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        ReactiveFormsModule,
        ToastrModule.forRoot(),
        CommonComponentsModule,
        NavigationTestModule.forRoot()
        ],
      declarations: [ GatewayErrorDetailComponent ],
      providers: [
        CommunicationsGatewayErrorService,
        {provide: CommunicationsGatewayErrorService, useClass: CommunicationsGatewayErrorServiceMock, useValue: {}},
        LoggerService,
        CommsUtilityService,
        NotificationService
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GatewayErrorDetailComponent);
    component = fixture.componentInstance;
    component.currentRecord =  new CommunicationsGatewayErrorsObject();
    component.currentRecord.dateReceived = new Date();
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
