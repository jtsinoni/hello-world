export interface IcommunicationsGatewayErrorsObject {
    id: string;
    dateReceived: Date;
    fileNameSize: string;
    httpResponseCode: string;
    responseSummary: string;
    responseSize: number;
    user: string;
    inboundUrl: string;
    channelId: string;
    inboundFilename: string;
    method: string;
    dataFormat: string;
    queryFields: string;
    dismissErrorIndicator: boolean;
    dismissErrorUserId: string;
    dismissErrorDate: Date;
    commsErrorIndicator: boolean;
}
