import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ModelsModule } from './models/models.module';
import { ServicesModule } from './services/services.module';
import { CommunicationsGatewayErrorsComponent } from './communications-gateway-errors.component';
import { CommonComponentsModule } from '../../../../common-components/common-components.module';
import { LcTableModule } from '../../../../common-components/lc-table/lc-table.module';
import { CommunicationsGatewayErrorsRouterModule } from './communications-gateway-errors.router';
import { GatewayErrorDetailComponent } from '../communications-gateway-errors/gateway-error-detail/gateway-error-detail.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommsUtilityService } from '../../services/comms-utility.service';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    ModelsModule,
    ServicesModule,
    LcTableModule,
    CommonComponentsModule,
    CommunicationsGatewayErrorsRouterModule
  ],
  declarations: [
    CommunicationsGatewayErrorsComponent,
    GatewayErrorDetailComponent
  ],
  exports: [
    CommunicationsGatewayErrorsComponent,
    CommunicationsGatewayErrorsRouterModule,
    GatewayErrorDetailComponent
  ],
  providers: [CommsUtilityService]
})
export class CommunicationsGatewayErrorsModule { }
