import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CommsEcmsModule } from './comms-ecms/comms-ecms.module';
import { CommsEhrModule } from './comms-ehr/comms-ehr.module';
import { CommsPointOfCareModule } from './comms-point-of-care/comms-point-of-care.module';
import { CommunicationsOutboundConfigModule } from './communications-outbound-config/communications-outbound-config.module';
import { CommunicationsConfigModule } from './communications-config/communications-config.module';
import { CommunicationsGatewayErrorsModule } from './communications-gateway-errors/communications-gateway-errors.module';
import { CommunicationsSearchModule } from './communications-search/communications-search.module';

import { CommsErrorDismissalModule } from './comms-error-dismissal/comms-error-dismissal.module';
import { CommsCommonComponentsModule } from '../comms-common-components/comms-common-components.module';
import { CommunicationsResubmitModule  } from './communications-resubmit/communications-resubmit.module';
import { CommunicationsFinancialResubmitModule } from './communications-financial-resubmit/communications-financial-resubmit.module';

@NgModule({
  imports: [
    CommonModule,
    CommsEcmsModule,
    CommsEhrModule,
    CommsPointOfCareModule,
    CommunicationsOutboundConfigModule,
    CommunicationsConfigModule,
    CommunicationsGatewayErrorsModule,
    CommunicationsSearchModule,
    CommsErrorDismissalModule,
    CommsCommonComponentsModule,
    CommunicationsResubmitModule,
    CommunicationsFinancialResubmitModule,
  ],
  declarations: [
  ],
  entryComponents: [
  ]
})
export class ComponentsModule { }
