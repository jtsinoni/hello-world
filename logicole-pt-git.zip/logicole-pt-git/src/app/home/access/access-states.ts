import {Ng2StateDeclaration} from '@uirouter/angular';
import {RouteConstants} from 'app/constants/route.constants';
import {AccessComponent} from 'app/home/access/access.component';
import {UserProfileManagementComponent} from 'app/home/access/user-profile-management/user-profile-management.component';
import {RoleManagementComponent} from 'app/home/access/role-management/role-management.component';
import {PermissionManagementComponent} from 'app/home/access/permission-management/permission-management.component';
import {PermissionManagementDetailsComponent} from '@lc-app/home/access/permission-management/views/details/permission-management-details.component';
import {PermissionManagementEditGenInfoComponent} from '@lc-app/home/access/permission-management/views/edit-gen-info/permission-management-edit-gen-info.component';
import {PermissionManagementEditElementsComponent} from '@lc-app/home/access/permission-management/views/edit-elements/permission-management-edit-elements.component';
import {PermissionManagementEditStatesComponent} from '@lc-app/home/access/permission-management/views/edit-states/permission-management-edit-states.component';
import {PermissionManagementEditEndpointsComponent} from '@lc-app/home/access/permission-management/views/edit-endpoints/permission-management-edit-endpoints.component';

export class AccessStates {
  static ACCESS: Ng2StateDeclaration = {
    url: RouteConstants.ACCESS.url, name: RouteConstants.ACCESS.name,
    component: AccessComponent, data: {'route': RouteConstants.ACCESS}
  };
  static ACCESS_USER_PROFILE_MANAGEMENT: Ng2StateDeclaration = {
    url: RouteConstants.ACCESS_USER_PROFILE_MANAGEMENT.url, name: RouteConstants.ACCESS_USER_PROFILE_MANAGEMENT.name,
    component: UserProfileManagementComponent, data: {'route': RouteConstants.ACCESS_USER_PROFILE_MANAGEMENT}
  };
  static ACCESS_ROLE_MANAGEMENT: Ng2StateDeclaration = {
    url: RouteConstants.ACCESS_ROLE_MANAGEMENT.url, name: RouteConstants.ACCESS_ROLE_MANAGEMENT.name,
    component: RoleManagementComponent, data: {'route': RouteConstants.ACCESS_ROLE_MANAGEMENT}
  };
  static ACCESS_PERMISSION_MANAGEMENT: Ng2StateDeclaration = {
    url: RouteConstants.ACCESS_PERMISSION_MANAGEMENT.url, name: RouteConstants.ACCESS_PERMISSION_MANAGEMENT.name,
    component: PermissionManagementComponent, data: {'route': RouteConstants.ACCESS_PERMISSION_MANAGEMENT}
  };
  static ACCESS_PERMISSION_MANAGEMENT_DETAILS: Ng2StateDeclaration = {
    url: RouteConstants.ACCESS_PERMISSION_MANAGEMENT_DETAILS.url,
    name: RouteConstants.ACCESS_PERMISSION_MANAGEMENT_DETAILS.name,
    component: PermissionManagementDetailsComponent, data: {'route': RouteConstants.ACCESS_PERMISSION_MANAGEMENT_DETAILS}
  };

  static ACCESS_PERMISSION_MANAGEMENT_EDIT_GEN_INFO: Ng2StateDeclaration = {
    url: RouteConstants.ACCESS_PERMISSION_MANAGEMENT_EDIT_GEN_INFO.url,
    name: RouteConstants.ACCESS_PERMISSION_MANAGEMENT_EDIT_GEN_INFO.name,
    component: PermissionManagementEditGenInfoComponent, data: {'route': RouteConstants.ACCESS_PERMISSION_MANAGEMENT_EDIT_GEN_INFO}
  };
  static ACCESS_PERMISSION_MANAGEMENT_EDIT_ELEMENTS: Ng2StateDeclaration = {
    url: RouteConstants.ACCESS_PERMISSION_MANAGEMENT_EDIT_ELEMENTS.url,
    name: RouteConstants.ACCESS_PERMISSION_MANAGEMENT_EDIT_ELEMENTS.name,
    component: PermissionManagementEditElementsComponent, data: {'route': RouteConstants.ACCESS_PERMISSION_MANAGEMENT_EDIT_ELEMENTS}
  };
  static ACCESS_PERMISSION_MANAGEMENT_EDIT_STATES: Ng2StateDeclaration = {
    url: RouteConstants.ACCESS_PERMISSION_MANAGEMENT_EDIT_STATES.url,
    name: RouteConstants.ACCESS_PERMISSION_MANAGEMENT_EDIT_STATES.name,
    component: PermissionManagementEditStatesComponent, data: {'route': RouteConstants.ACCESS_PERMISSION_MANAGEMENT_EDIT_STATES}
  };
  static ACCESS_PERMISSION_MANAGEMENT_EDIT_ENDPOINTS: Ng2StateDeclaration = {
    url: RouteConstants.ACCESS_PERMISSION_MANAGEMENT_EDIT_ENDPOINTS.url,
    name: RouteConstants.ACCESS_PERMISSION_MANAGEMENT_EDIT_ENDPOINTS.name,
    component: PermissionManagementEditEndpointsComponent, data: {'route': RouteConstants.ACCESS_PERMISSION_MANAGEMENT_EDIT_ENDPOINTS}
  };

}
