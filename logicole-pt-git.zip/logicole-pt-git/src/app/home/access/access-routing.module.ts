import {NgModule} from '@angular/core';
import {RootModule, UIRouterModule} from '@uirouter/angular';

import {AccessStates} from './access-states';
const accessRoutes: RootModule = {
  states: [
    AccessStates.ACCESS,
    AccessStates.ACCESS_USER_PROFILE_MANAGEMENT,
    AccessStates.ACCESS_ROLE_MANAGEMENT,
    AccessStates.ACCESS_PERMISSION_MANAGEMENT,
    AccessStates.ACCESS_PERMISSION_MANAGEMENT_DETAILS,
    AccessStates.ACCESS_PERMISSION_MANAGEMENT_EDIT_GEN_INFO,
    AccessStates.ACCESS_PERMISSION_MANAGEMENT_EDIT_ELEMENTS,
    AccessStates.ACCESS_PERMISSION_MANAGEMENT_EDIT_STATES,
    AccessStates.ACCESS_PERMISSION_MANAGEMENT_EDIT_ENDPOINTS,
  ]
};

@NgModule({
  imports: [UIRouterModule.forChild(accessRoutes)],
  exports: [UIRouterModule]
})
export class AccessRoutingModule { }
