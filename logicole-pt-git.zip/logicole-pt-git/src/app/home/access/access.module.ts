import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {FormsModule} from '@angular/forms';

import {createLogger} from 'redux-logger';
import {NgReduxModule, NgRedux} from '@angular-redux/store';

import { AccessRoutingModule } from './access-routing.module';
import { UserProfileManagementComponent } from './user-profile-management/user-profile-management.component';
import { AccessComponent } from './access.component';
import { RoleManagementComponent } from './role-management/role-management.component';
import { PermissionManagementComponent } from './permission-management/permission-management.component';
import { CommonComponentsModule } from '../../common-components/common-components.module';
import {PermissionManagementModule} from './permission-management/permission-management.module';
import {Ng2SmartTableModule} from 'ng2-smart-table';

import {INITIAL_STATE, permissionManagementReducer} from './permission-management/redux/permission-management.reducer';
import {IPermissionState} from './permission-management/redux/permission-management.model';
import {PermissionManagementEpic} from './permission-management/redux/permission-management.epics';

@NgModule({
  imports: [
    CommonModule,
    AccessRoutingModule,
    CommonComponentsModule,
    FormsModule,
    Ng2SmartTableModule,
    NgReduxModule,
    PermissionManagementModule
  ],
  declarations: [AccessComponent, UserProfileManagementComponent, RoleManagementComponent],
  exports: [AccessComponent, UserProfileManagementComponent, RoleManagementComponent]
})
export class AccessModule {
  constructor(store: NgRedux<IPermissionState>, epics: PermissionManagementEpic) {
    store.configureStore(
      permissionManagementReducer, INITIAL_STATE, [createLogger(), ...epics.createEpics()]);
  }
}
