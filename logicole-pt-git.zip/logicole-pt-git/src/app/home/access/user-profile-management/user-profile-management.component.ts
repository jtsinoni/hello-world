import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-user-profile-management',
  templateUrl: './user-profile-management.component.html',
})
export class UserProfileManagementComponent implements OnInit {

  minDate: Date = new Date(2017, 5, 10);
  maxDate: Date = new Date(2018, 9, 15);
  bsValue: Date = new Date();
  bsRangeValue: any = [new Date(2017, 7, 4), new Date(2017, 7, 20)];

  constructor() { }

  ngOnInit() {
  }

}
