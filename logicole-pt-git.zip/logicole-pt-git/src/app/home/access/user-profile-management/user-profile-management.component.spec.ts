import {NO_ERRORS_SCHEMA} from '@angular/core';
import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {UserProfileManagementComponent} from './user-profile-management.component';
import {BsDatepickerModule} from 'ngx-bootstrap';
import {FormsModule} from '@angular/forms';
import {a11yTests, prettyPrintA11Y} from '@lc-a11y/';
import {LoggerService} from 'app/services';

describe('UserProfileManagementComponent', () => {
  let component: UserProfileManagementComponent;
  let fixture: ComponentFixture<UserProfileManagementComponent>;
  let logger: LoggerService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      providers: [LoggerService],
      declarations: [ UserProfileManagementComponent ],
      imports: [BsDatepickerModule.forRoot(), FormsModule],
      schemas: [NO_ERRORS_SCHEMA]
    })
    .compileComponents();

    logger = TestBed.get(LoggerService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserProfileManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('Accessibility Tests', () => {
    it('should have no a11y violations', async(() => {
      const options: any = { rules: { 'label': { enabled: false } } };

      a11yTests(fixture.nativeElement, options)
        .then((results) => {
          expect(results.violations.length).toBe(0, `${prettyPrintA11Y(results.violations)}`);
        })
        .catch((error) => {
          logger.error(`${error}`);
        });
    }));
  });
});
