import {Component, OnInit, ViewChild} from '@angular/core';
import {PermissionDetailed} from '@lc-app/models/permission-detailed.model';
import {LcTableSettings} from '@lc-app/common-components/lc-table/models/lc-table-settings';
import {LcTableColumn} from '@lc-app/common-components/lc-table/models/lc-table-column';
import {Observable} from 'rxjs/Observable';
import {LcLinkCellComponent} from '@lc-app/common-components/lc-table/lc-link-cell/lc-link-cell.component';
import {PermissionManagementActions} from '@lc-app/home/access/permission-management/redux/permission-management.actions';
import {select, dispatch} from '@angular-redux/store';
import {StateNavigationService} from '@lc-app/services';
import {RouteConstants} from '@lc-app/constants/route.constants';

@Component({
  selector: 'app-permission-management',
  templateUrl: './permission-management.component.html'
})
export class PermissionManagementComponent implements OnInit {
  @select() readonly permissionDetailed: Observable<PermissionDetailed[]>;

  lcTableColumns: any;
  lcTableSettings: LcTableSettings;
  lcTableData: Array<PermissionDetailed> = [];


  constructor(private permissionActions: PermissionManagementActions,
              private stateNavigationService: StateNavigationService) {}

  ngOnInit() {
    this.initializeTable();
    this.permissionActions.getAllPermissionsFull();
  }

  @dispatch()
  private setPermissionsSelected = (permission: PermissionDetailed) => (
    this.permissionActions.setPermissionsSelected(permission)
  )

  private initializeTable() {
    this.lcTableSettings = new LcTableSettings();
    this.lcTableSettings.cardId = 'permissionsTable';
    this.lcTableSettings.cardTitle = 'Permissions';
    this.lcTableSettings.tableMode = 'external';
    // this.lcTableSettings.cardTitleIcon = 'fa fa-phone';
    this.lcTableSettings.tableAttr.id = 'permissionsTableAttr';
    this.lcTableSettings.tableNoDataMessage = 'Loading ...';

    this.lcTableSettings.cardShowDownload = false;
    this.lcTableSettings.cardShowGlobalSearch = false;
    this.lcTableSettings.cardShowRefresh = false;
    this.lcTableSettings.tableHideSubHeader = true;


    const nameCol: LcTableColumn = new LcTableColumn('Name');
    nameCol.type = 'custom';
    nameCol.renderComponent = LcLinkCellComponent;

    nameCol.onComponentInitFunction = ((instance: LcLinkCellComponent) => {
        instance.cellSelected.subscribe((permission) => {
            this.goToPermissionView(permission);
        });
    });

    this.lcTableColumns = {
      name: nameCol,
      description: new LcTableColumn('Description'),
      functionalArea:  new LcTableColumn('Functional Area')
    };
  }

  private goToPermissionView(permission: PermissionDetailed) {
    this.stateNavigationService.navigateTo(RouteConstants.ACCESS_PERMISSION_MANAGEMENT_DETAILS)
      .then(() => {
        this.setPermissionsSelected(permission);
      });
  }
}
