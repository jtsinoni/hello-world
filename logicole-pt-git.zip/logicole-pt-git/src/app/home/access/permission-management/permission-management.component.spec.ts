import {NO_ERRORS_SCHEMA} from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { PermissionManagementComponent } from './permission-management.component';
import {PermissionManagementActions} from '@lc-app/home/access/permission-management/redux/permission-management.actions';
import {StateNavigationService, LoggerService} from '@lc-app/services';
import {NavigationTestModule} from '@lc-app/common-components/test/navigation-test/navigation-test.module';

describe('PermissionManagementComponent', () => {
  let component: PermissionManagementComponent;
  let fixture: ComponentFixture<PermissionManagementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [NavigationTestModule.forRoot()],
      declarations: [ PermissionManagementComponent ],
      providers: [PermissionManagementActions, LoggerService],
      schemas: [NO_ERRORS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PermissionManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
