import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {NgReduxTestingModule, MockNgRedux} from '@angular-redux/store/testing';
import {NO_ERRORS_SCHEMA} from '@angular/core';

import { PermissionManagementDetailsComponent } from './permission-management-details.component';
import {NavigationTestModule} from '@lc-app/common-components/test/navigation-test/navigation-test.module';
import {LoggerService} from '@lc-app/services';

describe('PermissionManagementDetailsComponent', () => {
  let component: PermissionManagementDetailsComponent;
  let fixture: ComponentFixture<PermissionManagementDetailsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [NavigationTestModule.forRoot(), NgReduxTestingModule],
      declarations: [ PermissionManagementDetailsComponent ],
      providers: [LoggerService],
      schemas: [NO_ERRORS_SCHEMA],
    }).compileComponents();

    fixture = TestBed.createComponent(PermissionManagementDetailsComponent);
    component = fixture.componentInstance;
    MockNgRedux.reset();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
