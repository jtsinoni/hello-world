import {Component, OnInit} from '@angular/core';
import {PermissionDetailed} from '@lc-app/models/permission-detailed.model';
import {Observable} from 'rxjs/Observable';
import {select} from '@angular-redux/store';
import {StateNavigationService} from '@lc-app/services';
import {RouteConstants} from '@lc-app/constants/route.constants';

@Component({
  selector: 'lc-permission-management-details',
  templateUrl: './permission-management-details.component.html'
})
export class PermissionManagementDetailsComponent implements OnInit {
  @select() readonly permissionSelected$: Observable<PermissionDetailed>;
  permission: PermissionDetailed;
  showJson: boolean = false;

  constructor(private stateNavigationService: StateNavigationService) { }

  ngOnInit() {
    this.permissionSelected$
      .subscribe(data => this.permission = data);
  }

  /**
   Return to Permission Admin page
    */
  goToPermissionAdmin() {
      this.stateNavigationService.navigateTo(RouteConstants.ACCESS_PERMISSION_MANAGEMENT);
  }

  /**
   Go to Permission Edit General Information page
   */
  goToEditPermissionGeneralInfo() {
    this.stateNavigationService.navigateTo(RouteConstants.ACCESS_PERMISSION_MANAGEMENT_EDIT_GEN_INFO);
  }

  /**
   Go to Permission Edit Elements page
   */
  goToEditPermissionElements() {
      this.stateNavigationService.navigateTo(RouteConstants.ACCESS_PERMISSION_MANAGEMENT_EDIT_ELEMENTS);
  }

  /**
   Go to Permission Edit Endpoints page
   */
  goToEditPermissionEndpoints() {
      this.stateNavigationService.navigateTo(RouteConstants.ACCESS_PERMISSION_MANAGEMENT_EDIT_ENDPOINTS);
  }

  /**
   Go to Permission Edit States page
   */
  goToEditPermissionStates() {
      this.stateNavigationService.navigateTo(RouteConstants.ACCESS_PERMISSION_MANAGEMENT_EDIT_STATES);
  }

  toggleJson() {
      this.showJson = !this.showJson;
  }
}
