import {Component, OnInit} from '@angular/core';
import {select} from '@angular-redux/store';
import {Observable} from 'rxjs/Observable';
import {PermissionDetailed} from '@lc-app/models/permission-detailed.model';
import {StateNavigationService, LoggerService} from '@lc-app/services';
import {RouteConstants} from '@lc-app/constants/route.constants';
import {RoleService} from '@lc-app/services/role.service';
import {PermissionManagementActions} from '@lc-app/home/access/permission-management/redux/permission-management.actions';

@Component({
  selector: 'lc-permission-management-edit-gen-info',
  templateUrl: './permission-management-edit-gen-info.component.html',
})
export class PermissionManagementEditGenInfoComponent implements OnInit {
  @select() readonly permissionSelected$: Observable<PermissionDetailed>;
  permission: PermissionDetailed;

  permissionGeneralInfoChanged: boolean;
  permissionFunctionalAreaOptions: Array<string> = ['Administration', 'Equipment_Request', 'Other'];

  constructor(private stateNavigationService: StateNavigationService,
              private permissionActions: PermissionManagementActions,
              private logger: LoggerService) { }

  ngOnInit() {
    this.permissionSelected$
      .subscribe(data => this.permission = data);
  }

  goToPermissionDetails() {
    this.stateNavigationService.navigateTo(RouteConstants.ACCESS_PERMISSION_MANAGEMENT_DETAILS);
  }

  onSubmit() {
    // this.logger.debug(`PermissionManagementEditGenInfoComponent submitting form ....\n${JSON.stringify(this.permission)}`);
    this.savePermissionGeneralInfo();
  }

  savePermissionGeneralInfo() {
    this.stateNavigationService.navigateTo(RouteConstants.ACCESS_PERMISSION_MANAGEMENT_DETAILS)
      .then(() => {
        this.permissionGeneralInfoChanged = false;
        this.permissionActions.savePermissionsSelected(this.permission);
      });
  }
}
