import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PermissionManagementEditStatesComponent } from './permission-management-edit-states.component';
import {NO_ERRORS_SCHEMA} from '@angular/core';

describe('PermissionManagementEditStatesComponent', () => {
  let component: PermissionManagementEditStatesComponent;
  let fixture: ComponentFixture<PermissionManagementEditStatesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PermissionManagementEditStatesComponent ],
      schemas: [NO_ERRORS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PermissionManagementEditStatesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
