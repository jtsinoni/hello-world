import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {NgReduxTestingModule, MockNgRedux} from '@angular-redux/store/testing';
import { PermissionManagementEditGenInfoComponent } from './permission-management-edit-gen-info.component';
import {NavigationTestModule} from '@lc-app/common-components/test/navigation-test/navigation-test.module';
import {PermissionManagementActions} from '@lc-app/home/access/permission-management/redux/permission-management.actions';
import {LoggerService} from '@lc-app/services';
import {NO_ERRORS_SCHEMA} from '@angular/core';

describe('PermissionManagementEditGenInfoComponent', () => {
  let component: PermissionManagementEditGenInfoComponent;
  let fixture: ComponentFixture<PermissionManagementEditGenInfoComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [NavigationTestModule.forRoot(), NgReduxTestingModule],
      declarations: [ PermissionManagementEditGenInfoComponent ],
      providers: [PermissionManagementActions, LoggerService],
      schemas: [NO_ERRORS_SCHEMA],
    }).compileComponents();

    fixture = TestBed.createComponent(PermissionManagementEditGenInfoComponent);
    component = fixture.componentInstance;
    MockNgRedux.reset();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
