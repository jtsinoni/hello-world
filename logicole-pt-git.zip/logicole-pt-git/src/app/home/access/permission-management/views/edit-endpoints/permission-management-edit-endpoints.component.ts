import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lc-permission-management-edit-endpoints',
  templateUrl: './permission-management-edit-endpoints.component.html',
  styles: []
})
export class PermissionManagementEditEndpointsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
