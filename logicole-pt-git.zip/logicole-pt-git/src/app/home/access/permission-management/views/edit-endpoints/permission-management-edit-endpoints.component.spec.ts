import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PermissionManagementEditEndpointsComponent } from './permission-management-edit-endpoints.component';
import {NO_ERRORS_SCHEMA} from '@angular/core';

describe('PermissionManagementEditEndpointsComponent', () => {
  let component: PermissionManagementEditEndpointsComponent;
  let fixture: ComponentFixture<PermissionManagementEditEndpointsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PermissionManagementEditEndpointsComponent ],
      schemas: [NO_ERRORS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PermissionManagementEditEndpointsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
