import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lc-permission-management-edit-states',
  templateUrl: './permission-management-edit-states.component.html',
  styles: []
})
export class PermissionManagementEditStatesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
