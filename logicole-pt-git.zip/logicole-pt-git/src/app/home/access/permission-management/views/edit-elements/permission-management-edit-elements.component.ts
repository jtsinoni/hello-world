import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lc-permission-management-edit-elements',
  templateUrl: './permission-management-edit-elements.component.html',
  styles: []
})
export class PermissionManagementEditElementsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
