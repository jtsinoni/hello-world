import {Injectable} from '@angular/core';
import {Action} from 'redux';
import {dispatch} from '@angular-redux/store';
import {FluxStandardAction} from 'flux-standard-action';

import {PermissionDetailed} from '@lc-app/models/permission-detailed.model';

import {IPermissionState} from './permission-management.model';

// Flux-standard-action gives us stronger typing of our actions.
// interface MetaData { permissionType: AccessType; }
// export type PermissionAction = FluxStandardAction<Payload, MetaData>;
// export type PermissionAction = FluxStandardAction<Payload>;

type Payload = PermissionDetailed[];
export type PermissionAction = Action & { payload?: Payload } & { meta?: any };

@Injectable()
export class PermissionManagementActions {
  static readonly GET_ALL_PERMISSIONS_FULL = 'GET_ALL_PERMISSIONS_FULL';
  static readonly GET_ALL_PERMISSIONS_FULL_SUCCEEDED = 'GET_ALL_PERMISSIONS_FULL_SUCCEEDED';
  static readonly GET_ALL_PERMISSIONS_FULL_UPDATED = 'GET_ALL_PERMISSIONS_UPDATED';
  static readonly SET_PERMISSION_SELECTED = 'SET_PERMISSION_SELECTED';
  static readonly GET_PERMISSION_SELECTED = 'GET_PERMISSION_SELECTED';
  static readonly SAVE_PERMISSION_SELECTED = 'SAVE_PERMISSION_SELECTED';
  static readonly SAVE_PERMISSION_SELECTED_SUCCEEDED = 'SAVE_PERMISSION_SELECTED_SUCCEEDED';

  @dispatch()
  getAllPermissionsFull = (): PermissionAction => ({
    type: PermissionManagementActions.GET_ALL_PERMISSIONS_FULL
  })
  getAllPermissionsFullSucceeded = (payload: Payload): PermissionAction => ({
    type: PermissionManagementActions.GET_ALL_PERMISSIONS_FULL_SUCCEEDED,
    payload
  })
  getAllPermissionsFullUpdated = (): PermissionAction => ({
    type: PermissionManagementActions.GET_ALL_PERMISSIONS_FULL_UPDATED,
  })

  @dispatch()
  savePermissionsSelected = (permission: PermissionDetailed): PermissionAction => ({
    type: PermissionManagementActions.SAVE_PERMISSION_SELECTED,
    meta: permission
  })
  setPermissionsSelected = (permission: PermissionDetailed): PermissionAction => ({
    type: PermissionManagementActions.SET_PERMISSION_SELECTED,
    meta: permission
  })
  savePermissionsSelectedSucceeded = (): PermissionAction => ({
    type: PermissionManagementActions.SAVE_PERMISSION_SELECTED_SUCCEEDED,
  })
}
