// import * as types from '../../redux/action-types';
import {Action} from 'redux';
import {IPermissionState} from './permission-management.model';
import {PermissionManagementActions, PermissionAction} from './permission-management.actions';

export const INITIAL_STATE: IPermissionState = {
  permissionDetailed: [],
  permissionSelected: null,
  permissionRowId: -1,
};

export function permissionManagementReducer(lastState: IPermissionState, action: PermissionAction): IPermissionState {
  switch (action.type) {
    case PermissionManagementActions.GET_ALL_PERMISSIONS_FULL_SUCCEEDED: {
      return {
        ...lastState,
        permissionDetailed: action.payload
      };
    }

    case PermissionManagementActions.GET_ALL_PERMISSIONS_FULL_UPDATED: {
      return {
        ...lastState,
        permissionDetailed: action.payload
      };
    }

    // case PermissionManagementActions.GET_PERMISSION_SELECTED:
    case PermissionManagementActions.SET_PERMISSION_SELECTED: {
      return {
        ...lastState,
        permissionSelected: action.meta
      };
    }

    // ...other actions

    default:
      return lastState;
  }
}
