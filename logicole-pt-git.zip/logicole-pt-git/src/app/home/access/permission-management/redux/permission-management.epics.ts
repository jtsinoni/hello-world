import {Injectable} from '@angular/core';
import {Epic, createEpicMiddleware, combineEpics, ofType} from 'redux-observable';

import {RoleService} from '@lc-app/services/role.service';
import {PermissionDetailed} from '@lc-app/models/permission-detailed.model';
import {PermissionManagementActions, PermissionAction} from './permission-management.actions';
import {IPermissionState} from './permission-management.model';
import { of } from 'rxjs/observable/of';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/startWith';

@Injectable()
export class PermissionManagementEpic {
  constructor(private roleService: RoleService,
              private permissionActions: PermissionManagementActions) {

  }

  public createEpics() {
    // TODO: does not work, need to look into, makes more sense to combine epics and pass to createEpicMiddleware once
    // return createEpicMiddleware(
    //           combineEpics(this.getAllPermissionsDetailedEpic(), this.savePermissionManagementEpic())
    //       );
    return [
      createEpicMiddleware(this.getAllPermissionsDetailedEpic()),
      createEpicMiddleware(this.savePermissionManagementEpic()),
    ];
  }

  private getAllPermissionsDetailedEpic(): Epic<PermissionAction, IPermissionState> {
    return (action$, store) => action$
      .ofType(PermissionManagementActions.GET_ALL_PERMISSIONS_FULL)
      .switchMap(
        () => this.roleService.getAllPermissionsDetailed()
        .map(data => this.permissionActions.getAllPermissionsFullSucceeded(data))
      );

  }

  private savePermissionManagementEpic(): Epic<PermissionAction, IPermissionState> {
    return (action$, store) => action$
      .ofType(PermissionManagementActions.SAVE_PERMISSION_SELECTED)
      .switchMap(
        (action) => this.roleService.savePermission(action.meta)
        .map(data => this.permissionActions.savePermissionsSelectedSucceeded())
      );
  }
}
