import {PermissionDetailed} from '@lc-app/models/permission-detailed.model';

export interface IPermissionState {
  permissionDetailed: PermissionDetailed[];
  permissionSelected: PermissionDetailed;
  permissionRowId: number;
}
