import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';
import {PermissionManagementComponent} from './permission-management.component';
import {CommonComponentsModule} from '../../../common-components/common-components.module';
import {AccessRoutingModule} from '../access-routing.module';
import {PermissionManagementActions} from '@lc-app/home/access/permission-management/redux/permission-management.actions';
import {PermissionManagementEpic} from '@lc-app/home/access/permission-management/redux/permission-management.epics';
import {PermissionManagementDetailsComponent} from '@lc-app/home/access/permission-management/views/details/permission-management-details.component';
import {PermissionManagementEditElementsComponent} from '@lc-app/home/access/permission-management/views/edit-elements/permission-management-edit-elements.component';
import {PermissionManagementEditStatesComponent} from '@lc-app/home/access/permission-management/views/edit-states/permission-management-edit-states.component';
import {PermissionManagementEditEndpointsComponent} from '@lc-app/home/access/permission-management/views/edit-endpoints/permission-management-edit-endpoints.component';
import {PermissionManagementEditGenInfoComponent} from '@lc-app/home/access/permission-management/views/edit-gen-info/permission-management-edit-gen-info.component';

@NgModule({
  imports: [
    CommonModule,
    CommonComponentsModule,
    FormsModule,
    AccessRoutingModule,
  ],
  declarations: [PermissionManagementComponent, PermissionManagementDetailsComponent, PermissionManagementEditGenInfoComponent,
                 PermissionManagementEditElementsComponent, PermissionManagementEditStatesComponent, PermissionManagementEditEndpointsComponent],
  exports: [PermissionManagementComponent, PermissionManagementDetailsComponent, PermissionManagementEditGenInfoComponent,
            PermissionManagementEditElementsComponent, PermissionManagementEditStatesComponent, PermissionManagementEditEndpointsComponent],
  providers: [PermissionManagementActions, PermissionManagementEpic]
})
export class PermissionManagementModule { }
