// export function CheckForMultipleInstances() {
//   return function(constructor) {
//     const originalConstructor = constructor;
//     let instances = 0;

//     // function to generate instances of a class
//     function construct(constructor, args) {
//       const classInstance: any = function () {
//           return constructor.apply(this, args);
//       };
//       classInstance.prototype = constructor.prototype;
//       return new classInstance();
//     }

//     // this anonymous function also behaves as a closure for the variable instances,
//     // instances retains it's count for multiple calls.
//     const newConstructor: any = function (...args) {

//       // args.forEach((arg) => {
//       //   console.log(`CheckForMultipleInstances => ${arg}`)
//       // });

//       // console.log(`CheckForMultipleInstances => ${JSON.parse(args)}`)
//       instances++;
//       if (instances > 1) {
//         throw new Error(`Only one instance of ${originalConstructor.name} is allowed.`);
//       }
//       return construct(originalConstructor, args);
//     };
//     newConstructor.prototype = originalConstructor.prototype;

//     // copy metadata to new constructor
//     const metadatakeys = Reflect.getMetadataKeys(originalConstructor);
//     metadatakeys.forEach(function (key) {
//         Reflect.defineMetadata(key, Reflect.getOwnMetadata(key, originalConstructor), newConstructor);
//     });

//     return newConstructor;
//   };
// }
