// import 'reflect-metadata';

// type Newable<T> = new (...args: any[]) => T;
// export class HomeGrownInjector {
//   private static constructedInstances: { cx: Newable<any>; object: any }[] = [];

//   public static inject<T>(originalConstructor: Newable<T>): Newable<T> {
//     const paramTypes = Reflect.getOwnMetadata(
//       'design:paramtypes',
//       originalConstructor
//     );

//     if (paramTypes.length === 0) {
//       HomeGrownInjector.constructedInstances.push({
//         cx: originalConstructor,
//         object: null
//       });
//       return originalConstructor;
//     }


//     const newArgs = paramTypes
//       .map((f: any) => {
//         return HomeGrownInjector.get(f);
//       });

//     Object.defineProperty(
//       originalConstructor.prototype,
//       'loginService',
//       {value: () => originalConstructor.name}
//     );
//     const newConstructor = originalConstructor.bind(null, newArgs);


//     HomeGrownInjector.constructedInstances.push({ cx: newConstructor, object: null });
//    // console.log(`newConstructor => ${originalConstructor.loginService()}`);

//     return newConstructor;
//   }

//   public static get(cx: Newable<any>): any {
//     const ci = this.constructedInstances.find(f => f.cx === cx);

//     if (!ci) {
//       throw new Error('Invalid DI configuration.');
//     }

//     if (ci.object == null) {
//       ci.object = new ci.cx();
//     }

//     return ci.object;
//   }
// }

// export function Inject<T>(originalConstructor: Newable<T>): Newable<T> {
//   return HomeGrownInjector.inject(originalConstructor);
// }

// // @Inject
// // class Engine {
// //   displacement: number;
// //   maker: string;

// //   constructor(){
// //       this.maker = 'Tesla';
// //       this.displacement = 500;
// //   }
// // }

// // @Inject
// // class Engine2 {
// //   displacement: number;
// //   maker: string;

// //   constructor(){
// //       this.maker = 'Mustang';
// //       this.displacement = 400;
// //   }
// // }

// // @Inject
// // class Car {
// //   constructor(private eng: Engine){}
// // }

// // @Inject
// // class MultiCar {
// //   constructor(private eng1: Engine, private eng2: Engine2){}
// // }

// // export function CheckForMultipleInstances() {
// //   return function (constructor: any) {
// //     //console.log(`AppInjector => ${AppInjector}`);
// //     //console.log(`constructor => ${constructor}`);
// //   };
// // }

// // console.log( Injector.get(Car) );
// // console.log( Injector.get(MultiCar) );
