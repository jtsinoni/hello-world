// import {CheckForMultipleInstances} from '@lc-decorators/';
// import 'reflect-metadata';

// describe('@CheckForMultipleInstances decorator', () => {
//   it('should throw error if two or more instances are created', () => {
//     expect(() => {
//       @CheckForMultipleInstances()
//       class Service {}

//       const service1: Service = new Service();
//       const service2: Service = new Service();
//     }).toThrow();
//   });

//   it('should return succesfull if only one instance has been created', () => {
//     expect(() => {
//       @CheckForMultipleInstances()
//       class Service {}

//       const service1: Service = new Service();
//     }).not.toThrow();
//   });
// });
