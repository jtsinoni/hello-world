import {AppInjector} from '../app.injector';
import {NotificationService} from 'app/services/notification.service';

export class CheckMultipleGuard<T> {
  constructor(private instance: T) {

    setTimeout(() => {
      if (instance && AppInjector) {
        const notificationService: NotificationService = AppInjector.get(NotificationService);
        const message: string = `${instance} is already loaded. Use static .forRoot() to load in AppModule only`;

        notificationService.errorMsg(message);
        throw new Error(message);
      }
    }, 0);
  }
}
