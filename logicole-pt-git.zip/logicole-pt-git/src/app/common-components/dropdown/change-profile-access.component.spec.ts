import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {RouterTestingModule} from '@angular/router/testing';
import {ToastrModule} from 'ngx-toastr';

import {ChangeProfileAccessComponent} from './change-profile-access.component';
import {LoggerService} from '../../services/logger/logger.service';
import {ProfileService} from '../../services/profile.service';
import {ProfileApiService} from '../../services/profile-api.service';
import {HttpTestModule} from '../test/http-test.module';
import {MainNavService} from '../../home/main-nav/main-nav.service';
import {LoginService} from '../../services/login.service';
import {PermissionService} from '../../services/permission.service';
import {NavigationTestModule} from 'app/common-components/test/navigation-test/navigation-test.module';

describe('ChangeProfileAccessComponent', () => {
  let component: ChangeProfileAccessComponent;
  let fixture: ComponentFixture<ChangeProfileAccessComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChangeProfileAccessComponent ],
      providers: [LoggerService, ProfileService, ProfileApiService,
                  MainNavService, LoginService, PermissionService],
      imports: [NavigationTestModule.forRoot(), HttpTestModule.forRoot(), ToastrModule.forRoot()]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChangeProfileAccessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
