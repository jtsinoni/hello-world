import {Component, OnInit} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {LoggerService, ProfileService} from '@lc-services/';

import {RouteInfo, RouteConstants} from '../../constants/route.constants';
import {StateNavigationService} from 'app/services/state-navigation.service';

@Component({
  selector: 'lc-not-used',
  templateUrl: './change-profile-access.component.html',
})
export class ChangeProfileAccessComponent implements OnInit {
  constructor(protected logger: LoggerService,
    protected profileService: ProfileService,
    protected navigationService: StateNavigationService) { }


  ngOnInit() {
    this.profileService.initSignedInProfile()
      .subscribe(() => {
    });
  }

  private doSwitch(id: string, routeInfo: RouteInfo, invoke: (param: string) => Observable<any>) {
    this.navigationService.navigateToState(RouteConstants.LOADING)
      .then(() => {
        invoke(id)
          .subscribe(() => {
            this.navigationService.navigateToState(routeInfo);
          });
      });
  }

  public changeAccess(newNodeId: string): void {
    this.doSwitch(newNodeId, RouteConstants.MY_DASHBOARD, () => this.profileService.changeAccess(newNodeId));
  }

  public changeProfile(newProfileId: string): void {
    this.doSwitch(newProfileId, RouteConstants.MY_DASHBOARD, () => this.profileService.changeProfile(newProfileId));
  }

}
