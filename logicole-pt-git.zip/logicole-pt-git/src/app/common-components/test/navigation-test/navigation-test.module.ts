import {ModuleWithProviders, NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {StateNavigationService} from '../../../services/state-navigation.service';
import {PermissionService} from '../../../services/permission.service';
import {LoginService} from '../../../services/login.service';
import {ProfileApiService} from '../../../services/profile-api.service';
import {StateService} from '@uirouter/angular';
import {UIRouter, Transition} from '@uirouter/core';
import {BreadcrumbService} from "../../../services/breadcrumb.service";

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: []
})
export class NavigationTestModule {

  static forRoot(): ModuleWithProviders {
    return {
      ngModule: NavigationTestModule,
      providers: [
        StateNavigationService,
        PermissionService,
        LoginService,
        ProfileApiService,
        BreadcrumbService,
        {
          provide: StateService, useClass: class {
          mockStateService = new StateService(new UIRouter());
        }},
        {
          provide: Transition, useValue: {
          params: function () {
            return {
              id: 'id'
            };
          }
        }}
      ]
    };
  }
}
