import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { LoggerService } from '../../services/logger/logger.service';
import { NodeTree } from '../../models/node-tree.model';
import { DmlesSimpleTreeService } from './dmles-simple-tree.service';

@Component({
  selector: 'dmles-simple-tree',
  templateUrl: './dmles-simple-tree.component.html',
  styleUrls: ['./dmles-simple-tree.component.scss']
})
export class DmlesSimpleTreeComponent implements OnInit {

  private controllerName: string = 'DmlesSimpleTreeController Component';
  private nodeChecked: any;

  @Input() isLoading: Boolean;
  @Input() treeFilter: String;

  // Passed in from the directive
  @Input() isMultiSelect: Boolean;
  @Input() isSingleSelect: Boolean;
  @Input() preSelectionIds: Array<string>;
  @Input() treeData: Array<any>;
  @Input() onItemSelection: any;
  @Input() showRefresh: Boolean;
  @Input() onRefresh: any;
  simpleTreeService: DmlesSimpleTreeService;

  constructor(private logger: LoggerService, private simpleTreeSvc: DmlesSimpleTreeService) { }

  ngOnInit() {
    this.simpleTreeService = this.simpleTreeSvc;
    this.simpleTreeService.isMultiSelect = this.isMultiSelect;
    this.simpleTreeService.isSingleSelect = this.isSingleSelect;
    if (this.preSelectionIds && this.preSelectionIds.length > 0){

      // The code below was for AngularJS, hopefully we won't need the watch (ChangeDetectorRef in Angular5) to watch the tree data, if the Observables behave themselves.
      // // Watches for data changes from parent
      // this.$scope.$watch(() => { return this.treeData; }, (newValue, oldValue) => {
      //
      //   //this.$log.debug('%s - preSelectItem', this.preSelectionId);
      //   //this.$log.debug('%s - treeData is of Type', typeof this.treeData);
      //
      //   if(typeof this.treeData === 'object'){
      //     this.applyPreSelections();
      //   }
      // });
    }
  }

  private applyPreSelections(){

    Object.values(this.preSelectionIds).forEach((id) => {
      this.logger.debug(this.controllerName + ' - applyPreSelections: %s', id);
      this.traverseAndLocate(this.treeData[0], id);
    });

    // TODO: Scroll the div not the window
    /* this.$timeout( ()=> {
     this.$location.hash(this.preSelectionId);
     this.$anchorScroll();
     }, 500); */

  }

  private updatePrevCheckedNode(data){
    if (this.nodeChecked){
      if (this.nodeChecked.id !== data.id){
        this.nodeChecked.checked = false;
      }
    }
    this.nodeChecked = data;
  }

  private traverseAndLocate(node, id){
    if (node !== undefined ) {
      if (node.id && node.id === id) {
        node.checked = true;
        this.nodeChecked = node;
      } else {
        if (node.childNodes) {
          for (let i = 0; i < node.childNodes.length; i++) {
            const child = node.childNodes[i];
            this.traverseAndLocate(child, id);
          }
        }
      }
    }
  }

  private traverseAndExpand(node, isExpanded){
    if (node !== undefined ) {
      node.expanded = isExpanded;
      if (node.childNodes) {
        for (let i = 0; i < node.childNodes.length; i++) {
          const child = node.childNodes[i];
          this.traverseAndExpand(node, isExpanded);
        }
      }
    }
  }

  public add(data) {
    const post = data.childNodes.length + 1;
    const newName = data.name + '-' + post;
    data.childNodes.push({name: newName, expanded: true, childNodes: []});
  }

  public delete(data) {
    data.childNodes = [];
  }

  public collapse(data) {
    data.expanded = false;
  }

  public expand(data) {
    data.expanded = true;
  }

  public expandAll() {
    this.traverseAndExpand(this.treeData[0], true);
  }

  public collapseAll() {
    this.traverseAndExpand(this.treeData[0], false);
  }

  public isSelection(){
    let isFound = false;
    if (this.isMultiSelect || this.isSingleSelect){
      isFound = true;
    }
    return isFound;
  }

  public itemChecked(data){
    if (this.isSingleSelect){
      this.updatePrevCheckedNode(data);
    }
    this.onItemSelection( { itemData : data } );
  }

  public itemClicked(data){
    if (this.isSingleSelect){
      data.checked = !data.checked;
      this.updatePrevCheckedNode(data);
    }else{
      data.checked = !data.checked;
    }
    this.onItemSelection( { itemData : data } );
  }

  public refresh(){
    this.treeData = [];
    this.simpleTreeService.doRefresh(true);
  }

}
