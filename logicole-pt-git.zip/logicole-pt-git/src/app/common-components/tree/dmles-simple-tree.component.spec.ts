import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {CUSTOM_ELEMENTS_SCHEMA} from "@angular/core";

import { DmlesSimpleTreeComponent } from './dmles-simple-tree.component';
import {FormsModule} from '@angular/forms';
import {LoggerService} from '../../services/logger/logger.service';
import {DmlesSimpleTreeService} from './dmles-simple-tree.service';

describe('DmlesSimpleTreeComponent', () => {
  let component: DmlesSimpleTreeComponent;
  let fixture: ComponentFixture<DmlesSimpleTreeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ FormsModule ],
      declarations: [ DmlesSimpleTreeComponent ],
      providers: [LoggerService, DmlesSimpleTreeService],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DmlesSimpleTreeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
