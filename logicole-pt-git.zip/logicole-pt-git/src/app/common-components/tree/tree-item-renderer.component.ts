import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { NodeTree } from '../../models/node-tree.model';
import { DmlesSimpleTreeService } from './dmles-simple-tree.service';

@Component({
  selector: 'tree-item-renderer',
  templateUrl: './tree-item-renderer.component.html'
})
export class TreeItemRendererComponent implements OnInit {

  @Input() treeNode: NodeTree;
  simpleTreeService: DmlesSimpleTreeService;

  constructor(private simpleTreeSvc: DmlesSimpleTreeService) { }

  ngOnInit() {
    this.simpleTreeService = this.simpleTreeSvc;
  }

  public isSelection(){
    let isFound = false;
    if (this.simpleTreeService.isMultiSelect || this.simpleTreeService.isSingleSelect){
      isFound = true;
    }
    return isFound;
  }

  public collapse(treeNode) {
    this.treeNode.expanded = false;
  }

  public expand(treeNode) {
    this.treeNode.expanded = true;
  }

  public itemChecked(data){
    if (this.simpleTreeService.isSingleSelect){
      this.updatePrevCheckedNode(data);
    }
    this.simpleTreeService.setClicked(data);
  }

  public itemClicked(data){
    if (this.simpleTreeService.isSingleSelect){
      data.checked = !data.checked;
      this.updatePrevCheckedNode(data);
    }else{
      data.checked = !data.checked;
    }
    this.simpleTreeService.setClicked(data);
  }

  private updatePrevCheckedNode(data){
    if (this.simpleTreeService.nodeChecked){
      if (this.simpleTreeService.nodeChecked.id !== data.id){
        this.simpleTreeService.nodeChecked.checked = false;
      }
    }
    this.simpleTreeService.nodeChecked = data;
  }

}
