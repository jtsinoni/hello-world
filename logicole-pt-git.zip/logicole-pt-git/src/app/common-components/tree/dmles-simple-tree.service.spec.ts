import { TestBed, inject } from '@angular/core/testing';

import { DmlesSimpleTreeService } from './dmles-simple-tree.service';

describe('DmlesSimpleTreeService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [DmlesSimpleTreeService]
    });
  });

  it('should be created', inject([DmlesSimpleTreeService], (service: DmlesSimpleTreeService) => {
    expect(service).toBeTruthy();
  }));
});
