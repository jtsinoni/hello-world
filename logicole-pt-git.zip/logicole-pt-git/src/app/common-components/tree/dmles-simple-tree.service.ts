import { Injectable, EventEmitter } from '@angular/core';
import { HttpClientModule } from '@angular/common/http'; import { HttpModule } from '@angular/http';
import { NodeTree } from '../../models/node-tree.model';

@Injectable()
export class DmlesSimpleTreeService {

  nodeClicked: EventEmitter<NodeTree> = new EventEmitter();
  refreshClicked: EventEmitter<boolean> = new EventEmitter();
  nodeChecked: any;
  isMultiSelect: Boolean;
  isSingleSelect: Boolean;
  treeFilter: String;

  constructor() {
    this.nodeClicked = new EventEmitter();
    this.refreshClicked = new EventEmitter();
  }

  setClicked(row: NodeTree) {
    console.log('node clicked');
    this.nodeClicked.emit(row);
  }
  doRefresh(flag: boolean) {
    console.log('refresh clicked');
    this.refreshClicked.emit(flag);
  }
}
