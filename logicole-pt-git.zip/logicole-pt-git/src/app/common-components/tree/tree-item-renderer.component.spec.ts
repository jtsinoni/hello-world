import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TreeItemRendererComponent } from './tree-item-renderer.component';
import {FormsModule} from '@angular/forms';
import {DmlesSimpleTreeService} from './dmles-simple-tree.service';
import {LoggerService} from '../../services/logger/logger.service';
import {NodeTree} from '../../models/node-tree.model';

describe('TreeItemRendererComponent', () => {
  let component: TreeItemRendererComponent;
  let fixture: ComponentFixture<TreeItemRendererComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ FormsModule ],
      declarations: [ TreeItemRendererComponent ],
      providers: [LoggerService, DmlesSimpleTreeService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TreeItemRendererComponent);
    component = fixture.componentInstance;
    component.treeNode = new NodeTree();
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
