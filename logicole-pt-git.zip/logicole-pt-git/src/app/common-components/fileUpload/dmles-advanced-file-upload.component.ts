import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dmles-advanced-file-upload',
  templateUrl: './dmles-advanced-file-upload.component.html',
  styleUrls: ['./dmles-advanced-file-upload.component.scss']
})
export class DmlesAdvancedFileUploadComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
