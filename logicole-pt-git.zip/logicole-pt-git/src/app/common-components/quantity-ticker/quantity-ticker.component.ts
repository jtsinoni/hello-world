import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {LoggerService} from '../../services/logger/logger.service';

@Component({
  selector: 'lc-quantity-ticker',
  templateUrl: 'quantity-ticker.component.html',
  styleUrls: ['quantity-ticker.component.scss']
})

export class QuantityTickerComponent implements OnInit {

  @Input() public index: number;
  @Input() public quantity: number;
  @Input() public customMax: number;
  @Input() public customMin: number;

  @Output() public quantityChange = new EventEmitter<number>();

  public data: number;
  public i: number;
  public min: number = 1;
  public max: number = 99999;

  constructor(private logger: LoggerService) { }
  ngOnInit() {

    this.data = this.quantity;
    this.i = this.index;

    if (this.customMax != null){
      this.max = this.customMax;
    }

    if (this.customMin != null){
      this.min = this.customMin;
    }
  }

  public emitChange() {
    this.quantityChange.emit(this.quantity);
  }

  public addQuantity() {
    if (this.quantity < this.max) {
      this.quantity = this.quantity + 1;
      this.emitChange();
    }
  }

  public subtractQuantity(){
    if (this.quantity > this.min) {
      this.quantity = this.quantity - 1;
      this.emitChange();
    }
  }
}
