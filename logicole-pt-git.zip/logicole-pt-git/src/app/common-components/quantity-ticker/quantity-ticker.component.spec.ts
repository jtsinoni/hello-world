import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {CUSTOM_ELEMENTS_SCHEMA, EventEmitter} from '@angular/core';

import { QuantityTickerComponent } from './quantity-ticker.component';
import {LoggerService} from '../../services/logger/logger.service';
import {FormsModule} from '@angular/forms';
import {CommonModule} from '@angular/common';

describe('QuantityTickerComponent', () => {
  let component: QuantityTickerComponent;
  let fixture: ComponentFixture<QuantityTickerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ FormsModule, CommonModule ],
      declarations: [ QuantityTickerComponent ],
      providers: [LoggerService],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QuantityTickerComponent);
    component = fixture.componentInstance;
    component.index = 0;
    component.quantity = 0;
    component.quantityChange = new EventEmitter<number>();
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
