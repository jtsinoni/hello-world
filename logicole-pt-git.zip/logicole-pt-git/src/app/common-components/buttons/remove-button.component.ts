import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'remove-button',
  templateUrl: './remove-button.component.html',
})
export class RemoveButtonComponent implements OnInit {

  @Input() buttonId: string;
  @Input() canShow: boolean;
  @Input() isDisabled: boolean;
  @Input() title: string;
  @Output() public buttonClick = new EventEmitter();

  constructor() { }

  ngOnInit() {
  }

  private emitClick(event) {
    this.buttonClick.emit();
    event.preventDefault();
    event.stopPropagation();
  }
}
