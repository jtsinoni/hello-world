import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';

@Component({
    selector: 'lc-back-button',
    templateUrl: './back-button.component.html',
    styleUrls: ['./back-button.component.scss']
})
export class BackButtonComponent implements OnInit {
    @Input() public id: string;
    @Output() public clicked: EventEmitter<string> = new EventEmitter();

    constructor() { }

    ngOnInit() {
    }

    public onGoBackClicked(): void {
        this.clicked.emit(null);
    }
}
