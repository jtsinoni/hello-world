import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LcTextAreaInputComponent } from './lc-text-area-input.component';
import {FormsModule} from '@angular/forms';

@NgModule({
  imports: [
    CommonModule,
    FormsModule
  ],
  declarations: [LcTextAreaInputComponent],
  exports : [LcTextAreaInputComponent]
})
export class LcTextAreaInputModule { }
