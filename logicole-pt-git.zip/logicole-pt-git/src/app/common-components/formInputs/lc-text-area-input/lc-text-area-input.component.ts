import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'lc-text-area-input',
  templateUrl: './lc-text-area-input.component.html'
})
export class LcTextAreaInputComponent implements OnInit {

  private defaultMaxChar: number = 120;
  @Input() inputId: string;
  @Input() charLimit: number;
  @Input() label: string;
  @Input() isRequired: boolean;
  @Input() isReadOnly: boolean;
  @Input() title: string;
  @Input() placeholder: string;
  public input: string;
  @Input() dmlesValue: string;
  @Input() onChange: Function;
  @Output() public callback = new EventEmitter<string>();
  @Output() public quantityChange = new EventEmitter();

  constructor() { }

  ngOnInit() {
    if (this.charLimit == null){
      this.charLimit = this.defaultMaxChar;
    }
  }

  public emitUpdate() {
    this.callback.emit(this.dmlesValue);
  }

  public emitChange() {
    this.quantityChange.emit();
  }

}
