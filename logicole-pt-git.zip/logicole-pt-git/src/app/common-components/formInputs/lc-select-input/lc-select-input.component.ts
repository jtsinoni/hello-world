import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'lc-select-input',
  templateUrl: './lc-select-input.component.html'
})
export class LcSelectInputComponent implements OnInit {

  @Input() inputId: string;
  @Input() label: string;
  @Input() isRequired: boolean;
  @Input() isDisabled: boolean;
  @Input() dmlesValue: string;
  @Input() options: Array<any>;
  @Input() optionsAsValueAndText: boolean = false;
  @Output() public valueChange = new EventEmitter<string>();

  constructor() { }

  ngOnInit() {
  }

  public emitChange() {
    this.valueChange.emit(this.dmlesValue);
  }

}
