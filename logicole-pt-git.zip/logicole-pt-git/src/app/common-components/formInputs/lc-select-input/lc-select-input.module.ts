import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LcSelectInputComponent } from './lc-select-input.component';
import {FormsModule} from '@angular/forms';

@NgModule({
  imports: [
    CommonModule,
    FormsModule
  ],
  declarations: [LcSelectInputComponent],
  exports : [LcSelectInputComponent]
})
export class LcSelectInputModule { }
