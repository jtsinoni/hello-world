import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {isNumber} from 'util';

@Component({
  selector: 'lc-currency-input',
  templateUrl: './lc-currency-input.component.html'
})
export class LcCurrencyInputComponent implements OnInit {

  private defaultMax: number = 999999999.99;
  private defaultMin: number = 0;

  @Input() public dmlesValue: number = 0;
  @Input() public showErrorMessage: boolean;
  @Input() public inputId: string;
  @Input() public label: string;
  public max: number;
  public min: number;
  @Input() public isRequired: boolean;
  @Input() public isReadOnly: boolean;
  @Input() public title: string;
  @Input() stringValue: string = '';
  @Output() public callback = new EventEmitter<number>();
  @Output() public quantityChange = new EventEmitter();
  @Output() public isValueValid = new EventEmitter<boolean>();

  constructor() { }

  ngOnInit() {
    this.setStringValue();
    if (this.max == null){
      this.max = this.defaultMax;
    }

    if (this.min == null){
      this.min = this.defaultMin;
    }
  }

  private setStringValue(){
    // This is for the formatting
    if (this.dmlesValue != null) {
      this.stringValue = this.dmlesValue.toString();
      // this.stringValue = Object.assign({}, this.dmlesValue.toString());
      // this.stringValue = angular.copy(this.dmlesValue.toString());
      this.formatDollar();
    }else{
      this.stringValue = '';
    }
  }

  public formatDollar(){
    if (this.isValid() && !(this.stringValue === null  || this.stringValue === '' || this.stringValue === undefined)) {
      if (this.stringValue.length > 1) {
        if (this.stringValue.indexOf('.') === -1) {
          this.stringValue = (this.stringValue + '.00');
        }
        if (this.stringValue.indexOf('.') === 0) {
          this.stringValue = ('0' + this.stringValue);
        }
        if (this.stringValue.indexOf('.') === this.stringValue.length - 1) {
          this.stringValue = (this.stringValue + '00');
        }
        if (this.stringValue.indexOf('.') === this.stringValue.length - 2) {
          this.stringValue = (this.stringValue + '0');
        }
        // Truncate is there's too many decimal places
        if (this.stringValue.indexOf('.') < this.stringValue.length - 3) {
          // This truncates the string if there's more than 2 decimals
          this.stringValue = this.stringValue.substr(0, this.stringValue.indexOf('.') + 3);
        }
      }
      if (this.stringValue.length === 1) {
        if (this.stringValue.indexOf('.') === 0) {
          this.stringValue = '0.00';
        }
      }
      if ( this.dmlesValue !== +this.stringValue) {
        this.dmlesValue = +this.stringValue;
      }
    } else {
      this.dmlesValue = null;
    }
  }

  public isValid(){
    let isValid = true;
    // The + converts a string to a number
    const value = +this.stringValue;
    // If the value contains chars it can't be parsed
    if (!(this.stringValue === null  || this.stringValue === '' || this.stringValue === undefined)) {
      if (isNaN(value) && isNumber(value)) {
        isValid = false;
      }
      if (this.max < value || value < this.min) {
        isValid = false;
      }
    }
    return isValid;
  }

  checkIfValid() {
    const valid: boolean = this.isValid();
    if (valid) {
      if ( this.dmlesValue !== +this.stringValue) {
        this.dmlesValue = +this.stringValue;
      }
      this.callback.emit(this.dmlesValue);
    }
    this.isValueValid.emit(valid);
  }

  checkIfChangeIsValid() {
    const valid: boolean = this.isValid();
    if (valid) {
      if ( this.dmlesValue !== +this.stringValue) {
        this.dmlesValue = +this.stringValue;
      }
      this.quantityChange.emit();
      this.formatDollar();
    }
    this.isValueValid.emit(valid);
  }

}
