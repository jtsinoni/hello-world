import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LcCurrencyInputComponent } from './lc-currency-input.component';
import {FormsModule} from '@angular/forms';

@NgModule({
  imports: [
    CommonModule,
    FormsModule
  ],
  declarations: [LcCurrencyInputComponent],
  exports : [LcCurrencyInputComponent]
})
export class LcCurrencyInputModule { }
