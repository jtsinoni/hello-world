import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LcCurrencyInputComponent } from './lc-currency-input.component';
import {FormsModule} from '@angular/forms';

describe('LcCurrencyInputComponent', () => {
  let component: LcCurrencyInputComponent;
  let fixture: ComponentFixture<LcCurrencyInputComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ FormsModule ],
      declarations: [ LcCurrencyInputComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LcCurrencyInputComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
