import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'lc-email-input',
  templateUrl: './lc-email-input.component.html'
})
export class LcEmailInputComponent implements OnInit {

  private defaultMaxChar: number = 120;
  @Input() inputId: string;
  @Input() charLimit: number;
  @Input() label: string;
  @Input() isRequired: boolean;
  @Input() isReadOnly: boolean;
  @Input() title: string;
  @Input() placeholder: string;
  @Input() dmlesValue: string;
  @Input() onChange: Function;
  @Output() public valueChange = new EventEmitter<string>();
  @Output() public quantityChange = new EventEmitter();
  @Output() public isValueValid = new EventEmitter<boolean>();

  constructor() { }

  ngOnInit() {
    if (this.charLimit == null){
      this.charLimit = this.defaultMaxChar;
    }
  }

  checkIfValid(valid: boolean) {
    if (valid) {
      this.valueChange.emit(this.dmlesValue);
      this.quantityChange.emit();
    }
    this.isValueValid.emit(valid);
  }

  checkIfChangeIsValid(valid: boolean) {
    if (valid) {
      this.quantityChange.emit();
    }
    this.isValueValid.emit(valid);
  }
}
