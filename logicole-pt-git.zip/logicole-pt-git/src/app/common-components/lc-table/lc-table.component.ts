import {Component, EventEmitter, Input, OnChanges, OnInit, Output} from '@angular/core';
import {LoggerService} from '../../services/logger/logger.service';
import {LocalDataSource} from 'ng2-smart-table';
import {NotificationService} from '../../services/notification.service';
import {LcTableSettings} from './models/lc-table-settings';
import {Angular2Csv} from 'angular2-csv';
import {LcTableColumn} from './models/lc-table-column';
import {UtilService} from '../../services/util.service';

@Component({
  selector: 'lc-table',
  templateUrl: './lc-table.component.html'
})
export class LcTableComponent implements OnInit, OnChanges {

  @Input() public lcTableColumns: any;
  @Input() public lcTableSettings: LcTableSettings;
  @Input() public lcTableData: Array<any> = [];

  @Output() public lcOnRefresh = new EventEmitter<string>();
  @Output() public lcRowSelected = new EventEmitter<any>();
  @Output() public lcRowUnselected = new EventEmitter<any>();
  @Output() public lcAllRowsSelected = new EventEmitter<any>();
  @Output() public lcAllRowsUnselected = new EventEmitter<any>();

  public data: LocalDataSource;
  public settings: Object;

  public test: string;

  constructor(private logger: LoggerService,
              // private notify: NotificationService,
              private utilService: UtilService) { }

  ngOnInit() {
    if (this.lcTableData.length >= 50000){
      // this.notify.warningMsg('Warning table contains more than 50,000 items, filtering my take awhile.');
    }
    this.setTableSettings();
    this.data = new LocalDataSource(this.lcTableData);
  }

  private setTableSettings(){
    this.settings = {
      mode: this.lcTableSettings.tableMode,
      hideHeader: this.lcTableSettings.tableHideHeader,  // shows or hides the column headings
      hideSubHeader: this.lcTableSettings.tableHideSubHeader, // shows or hides the column sort inputs
      selectMode: this.lcTableSettings.tableSelectMode, // single|multi
      actions: this.lcTableSettings.tableActions, // shows or hides the row actions
      attr: this.lcTableSettings.tableAttr,
      pager: this.lcTableSettings.tablePager,
      columns: this.lcTableColumns,
    };
  }

  ngOnChanges(changes: any) {
      // this.logger.debug('lcTable.ngOnChanges: ' + JSON.stringify(changes, null, 3));
    if (changes['lcTableData']) {
      this.data = new LocalDataSource(this.lcTableData);
    }
  }

  onSearch(query: string = '') {
    if (query.length > 0 && this.lcTableData) {
      const filterItems: Array<any> = [];
      for (const field of Object.keys(this.lcTableData[0])) {
        const item: any = {
          field: field,
          search: query
        };
        filterItems.push(item);
      }
      this.data.setFilter(filterItems, false);
    } else {
      this.data.setFilter([]);
    }
  }

  public cellClick() {
    this.logger.debug(`linkClick`);
  }

  public buttonClick() {
    this.logger.debug(`buttonClick`);
  }

  public refreshClick() {
    this.logger.debug(`refreshClick`);
    this.lcOnRefresh.emit('refreshTable');
  }

  public exportClick() {

    // TODO: Needs to format dates better
    // TODO: Needs to reduce export according to filter, if one is applied

    const columns: Array<LcTableColumn> = this.utilService.objectPropsToArray(this.lcTableColumns);
    const titles: Array<string> = [];

    columns.forEach((colItem: LcTableColumn) => {
      titles.push(colItem.title);
    });

    const options = {
      fieldSeparator: ',',
      decimalseparator: '.',
      showLabels: true,
      showTitle: true,
      useBom: true,
      headers: titles
    };

    const obj = new Angular2Csv(this.lcTableData, this.lcTableSettings.cardTitle, options);
  }

  public rowClicked(data){
    // this.logger.info(`rowClicked: ${data}`);

    if (data.isSelected !== null){
      if (data.isSelected === true){
        this.lcRowSelected.emit(data);
      }else{
        this.lcRowUnselected.emit(data);
      }
    }else {
      if (data.selected) {
        if (data.selected.length > 0) {
          this.lcAllRowsSelected.emit(data);
        } else {
          this.lcAllRowsUnselected.emit(data);
        }
      }
    }
  }

}
