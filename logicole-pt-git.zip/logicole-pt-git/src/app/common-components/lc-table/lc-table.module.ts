import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {LcTableComponent} from './lc-table.component';
import {Ng2SmartTableModule} from 'ng2-smart-table';
import {LcYesNoCellModule} from './lc-yes-no-cell/lc-yes-no-cell.module';
import {LcLinkCellModule} from './lc-link-cell/lc-link-cell.module';
import {LcDateCellModule} from './lc-date-cell/lc-date-cell.module';
import {LcCheckboxCellModule} from './lc-checkbox-cell/lc-checkbox-cell.module';
import {LcCheckboxDisplayOnlyCellModule} from 'app/common-components/lc-table/lc-checkbox-display-only-cell/lc-checkbox-display-only-cell.module';
import {LcButtonCellModule} from './lc-button-cell/lc-button-cell.module';
import {LcBadgeLinkCellModule} from 'app/common-components/lc-table/lc-badge-link-cell/lc-badge-link-cell.module';
import {LcCurrencyCellModule} from './lc-currency-cell/lc-currency-cell.module';

@NgModule({
  imports: [
    CommonModule,
    Ng2SmartTableModule,
    LcYesNoCellModule,
    LcLinkCellModule,
    LcDateCellModule,
    LcCheckboxCellModule,
    LcCheckboxDisplayOnlyCellModule,
    LcButtonCellModule,
    LcBadgeLinkCellModule,
    LcCurrencyCellModule
  ],
  declarations: [LcTableComponent],
  exports: [LcTableComponent]
})
export class LcTableModule {
}
