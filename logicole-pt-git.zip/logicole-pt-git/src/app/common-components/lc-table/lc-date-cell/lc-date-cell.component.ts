import {Component, OnInit} from '@angular/core';
import {ViewCell} from 'ng2-smart-table';
import {ContentConstants} from '../../../constants/content.constants';

@Component({
  selector: 'lc-date-cell',
  template: `<span>{{ value | date:dateFormat }}</span>`
})
export class LcDateCellComponent implements ViewCell, OnInit {
  value: string | number;
  rowData: any;
  dateFormat: string = ContentConstants.FORMAT_DATE;

  constructor() { }

  ngOnInit() {
  }

}
