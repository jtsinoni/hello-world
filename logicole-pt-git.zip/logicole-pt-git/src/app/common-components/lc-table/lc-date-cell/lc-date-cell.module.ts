import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LcDateCellComponent } from './lc-date-cell.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [LcDateCellComponent],
  entryComponents: [LcDateCellComponent]
})
export class LcDateCellModule { }
