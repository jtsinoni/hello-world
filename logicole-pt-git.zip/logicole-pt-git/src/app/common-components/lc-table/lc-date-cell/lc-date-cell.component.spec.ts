import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LcDateCellComponent } from './lc-date-cell.component';
import {LoggerService} from '../../../services/logger/logger.service';

describe('LcDateCellComponent', () => {
  let component: LcDateCellComponent;
  let fixture: ComponentFixture<LcDateCellComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LcDateCellComponent ],
      providers: [LoggerService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LcDateCellComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
