import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {LcCheckboxDisplayOnlyCellComponent} from './lc-checkbox-display-only-cell.component';
import {LoggerService} from '@lc-services/*';

describe('LcCheckboxDisplayOnlyCellComponent', () => {
  let component: LcCheckboxDisplayOnlyCellComponent;
  let fixture: ComponentFixture<LcCheckboxDisplayOnlyCellComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [LcCheckboxDisplayOnlyCellComponent],
      providers: [LoggerService]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LcCheckboxDisplayOnlyCellComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
