import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {LcCheckboxDisplayOnlyCellComponent} from './lc-checkbox-display-only-cell.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [LcCheckboxDisplayOnlyCellComponent],
  entryComponents: [LcCheckboxDisplayOnlyCellComponent],
  exports: [LcCheckboxDisplayOnlyCellComponent]
})
export class LcCheckboxDisplayOnlyCellModule {
}
