import {Component, Input, OnInit} from '@angular/core';
import {ViewCell} from 'ng2-smart-table';
import {LoggerService} from '@lc-services/*';

@Component({
  selector: 'lc-checkbox-display-only-cell',
  template: `<input type="checkbox" [checked]="isChecked" [disabled]="true"/>`
})
export class LcCheckboxDisplayOnlyCellComponent implements ViewCell, OnInit {

  // this component can be used when you want to display a boolean value in a disabled checkbox
  // where the checkbox will be checked when true and unchecked when false

  public isChecked: boolean;

  @Input() public value: string | number;
  @Input() public rowData: any;

  constructor(private logger: LoggerService) {
  }

  public ngOnInit() {
    this.isChecked = (this.value) ? true : false;

    // this.logger.debug(`LcACheckboxDisplayOnlyCellComponent - this.value = ${JSON.stringify(this.value)}`);
    // this.logger.debug(`LcACheckboxDisplayOnlyCellComponent - this.rowData = ${JSON.stringify(this.rowData)}`);
  }

}
