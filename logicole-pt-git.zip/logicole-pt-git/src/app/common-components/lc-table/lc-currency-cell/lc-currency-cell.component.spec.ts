import {async, ComponentFixture, TestBed} from '@angular/core/testing';

import {LcCurrencyCellComponent} from './lc-currency-cell.component';
import {LoggerService} from '@lc-services/*';

describe('LcCurrencyCellComponent', () => {
  let component: LcCurrencyCellComponent;
  let fixture: ComponentFixture<LcCurrencyCellComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [LcCurrencyCellComponent],
      providers: [LoggerService]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LcCurrencyCellComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
