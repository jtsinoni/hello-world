import {Component, OnInit} from '@angular/core';
import {ViewCell} from 'ng2-smart-table';

@Component({
  selector: 'lc-currency-cell',
  template: `<span>{{value | currency}}</span>`
})
export class LcCurrencyCellComponent implements ViewCell, OnInit {
  value: string | number;
  rowData: any;

  constructor() {
  }

  ngOnInit() {
  }

}
