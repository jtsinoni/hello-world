import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {LcCurrencyCellComponent} from './lc-currency-cell.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [LcCurrencyCellComponent],
  entryComponents: [LcCurrencyCellComponent]
})
export class LcCurrencyCellModule {
}
