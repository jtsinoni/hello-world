export class LcTableSettingsAttr {
  public id: string = 'tableAttrNeedsId';
  public class: string = 'table table-striped table-hover text-left';
}
