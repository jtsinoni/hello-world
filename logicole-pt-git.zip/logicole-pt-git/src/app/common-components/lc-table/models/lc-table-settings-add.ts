export class LcTableSettingsAdd {
  public inputClass: string = '';
  public addButtonContent: string = 'Add New';
  public createButtonContent: string = 'Create';
  public cancelButtonContent: string = 'Cancel';
  public confirmCreate: boolean = false;
}
