import {LcTableSettingsAttr} from './lc-table-settings-attr';
import {LcTableSettingsPager} from './lc-table-settings-pager';
import {LcTableSettingsEdit} from './lc-table-settings-edit';
import {LcTableSettingsAdd} from './lc-table-settings-add';
import {LcTableSettingsDelete} from './lc-table-settings-delete';

export class LcTableSettings {
  public cardId: string;
  public cardShowDownload: boolean = true;
  public cardShowGlobalSearch: boolean = true;
  public cardShowHeader: boolean = true;
  public cardShowRefresh: boolean = true;
  public cardTitle: string;
  public cardTitleIcon: string;
  public tableMode: string = 'external'; // inline|external|click-to-edit
  public tableSelectMode: string = 'single'; // single|multi
  public tableHideHeader: boolean = false;
  public tableHideSubHeader: boolean = true;
  public tableActions: { add: false, delete: false, edit: false };
  public tableAttr: LcTableSettingsAttr = new LcTableSettingsAttr();
  public tablePager: LcTableSettingsPager = new LcTableSettingsPager();
  public tableNoDataMessage: string = 'No data found';
  public tableEdit: LcTableSettingsEdit = new LcTableSettingsEdit();
  public tableAdd: LcTableSettingsAdd = new LcTableSettingsAdd();
  public tableDelete: LcTableSettingsDelete = new LcTableSettingsDelete();
}
