import { LcButtonCellComponent } from '../lc-button-cell/lc-button-cell.component';

export interface LcButtonCallbackEvent {
    buttonId: string;
    buttonColumnComponent: LcButtonCellComponent;
    rowData: any;
}
