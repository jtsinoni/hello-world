import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LcCheckboxCellComponent } from './lc-checkbox-cell.component';
import {LoggerService} from '../../../services/logger/logger.service';

describe('LcCheckboxCellComponent', () => {
  let component: LcCheckboxCellComponent;
  let fixture: ComponentFixture<LcCheckboxCellComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LcCheckboxCellComponent ],
      providers: [LoggerService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LcCheckboxCellComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
