import {Component, ElementRef, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {ViewCell} from 'ng2-smart-table';
import {LoggerService} from '../../../services/logger/logger.service';

@Component({
  selector: 'lc-checkbox-cell',
  template: `<input type="checkbox" [checked]= selected (change)="selected = !selected" (click)="onClick()" />`
  })
export class LcCheckboxCellComponent implements ViewCell, OnInit {

  @Input() public value: string | number;
  @Input() public selected: boolean;
  @Input() public rowData: any;
  @Output() public cellSelected = new EventEmitter<string>();

  constructor(private logger: LoggerService, private el: ElementRef) { }

  ngOnInit() {}

  onClick() {
    this.cellSelected.emit(this.rowData);
  }
}
