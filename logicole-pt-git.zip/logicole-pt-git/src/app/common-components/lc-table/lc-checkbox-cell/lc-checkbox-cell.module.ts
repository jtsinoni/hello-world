import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LcCheckboxCellComponent } from './lc-checkbox-cell.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [LcCheckboxCellComponent],
  entryComponents: [LcCheckboxCellComponent],
  exports: [LcCheckboxCellComponent]
})
export class LcCheckboxCellModule { }
