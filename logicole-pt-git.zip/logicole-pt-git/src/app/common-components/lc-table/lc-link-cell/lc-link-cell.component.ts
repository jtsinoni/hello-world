import {Component, ElementRef, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {ViewCell} from 'ng2-smart-table';
import {LoggerService} from '../../../services/logger/logger.service';

@Component({
  selector: 'lc-link-cell',
  template: `<a href="javascript:void(0);" class="text-primary cursor-pointer" (click)="onClick()">{{ value }}</a>`
})
export class LcLinkCellComponent implements ViewCell, OnInit {
  @Input() public value: string | number;
  @Input() public rowData: any;
  @Output() public cellSelected = new EventEmitter<string>();

  constructor(private logger: LoggerService, private el: ElementRef) { }

  ngOnInit() {}

  onClick() {
    this.cellSelected.emit(this.rowData);
  }
}
