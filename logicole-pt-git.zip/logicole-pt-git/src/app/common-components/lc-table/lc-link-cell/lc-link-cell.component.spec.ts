import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LcLinkCellComponent } from './lc-link-cell.component';
import { LoggerService } from '../../../services/logger/logger.service';

describe('LcLinkCellComponent', () => {
  let component: LcLinkCellComponent;
  let fixture: ComponentFixture<LcLinkCellComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LcLinkCellComponent ],
      providers: [LoggerService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LcLinkCellComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
