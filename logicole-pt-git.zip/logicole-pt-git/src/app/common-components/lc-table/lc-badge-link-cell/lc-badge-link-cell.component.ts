import { Component, OnInit, Input, Output, EventEmitter, ElementRef } from '@angular/core';
import { ViewCell } from 'ng2-smart-table';
import { LoggerService } from 'app/services/logger/logger.service';

// WARNING: This component does not pass 508 color contrast tests.  Please do not use this until it can be fixed.

@Component({
    selector: 'lc-badge-link-cell',
    template: `<span class="badge badge-pill badge-dark" style="font-size: larger"><a href="javascript:void(0);" class="text-primary cursor-pointer" (click)="onClick()">{{ value }}</a></span>`
})
export class LcBadgeLinkCellComponent implements OnInit {
    @Input() public value: string | number;
    @Input() public rowData: any;
    @Output() public cellSelected = new EventEmitter<string>();

    constructor(private logger: LoggerService, private el: ElementRef) { }

    ngOnInit() {}

    onClick() {
      this.cellSelected.emit(this.rowData);
    }
  }
