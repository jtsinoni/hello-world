import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LcBadgeLinkCellComponent } from './lc-badge-link-cell.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [LcBadgeLinkCellComponent],
  entryComponents: [LcBadgeLinkCellComponent]
})
export class LcBadgeLinkCellModule { }
