import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LcBadgeLinkCellComponent } from './lc-badge-link-cell.component';
import { LoggerService } from '../../../services/logger/logger.service';

describe('LcBadgeLinkCellComponent', () => {
  let component: LcBadgeLinkCellComponent;
  let fixture: ComponentFixture<LcBadgeLinkCellComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LcBadgeLinkCellComponent ],
      providers: [LoggerService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LcBadgeLinkCellComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
