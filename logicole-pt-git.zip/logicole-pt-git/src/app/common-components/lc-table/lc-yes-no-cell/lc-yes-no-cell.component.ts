import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lc-yes-no-cell',
  template: `
    <p>
      lc-yes-no-cell works!
    </p>
  `,
  styles: []
})
export class LcYesNoCellComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
