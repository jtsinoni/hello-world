import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LcButtonCellComponent } from './lc-button-cell.component';

describe('LcButtonCellComponent', () => {
  let component: LcButtonCellComponent;
  let fixture: ComponentFixture<LcButtonCellComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LcButtonCellComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LcButtonCellComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
