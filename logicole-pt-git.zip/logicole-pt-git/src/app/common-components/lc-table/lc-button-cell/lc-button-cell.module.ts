import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LcButtonCellComponent } from './lc-button-cell.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [LcButtonCellComponent],
  entryComponents: [LcButtonCellComponent],
  exports: [LcButtonCellComponent]
})
export class LcButtonCellModule { }
