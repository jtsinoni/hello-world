import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ViewCell } from 'ng2-smart-table';
import { LcButtonCallbackEvent } from '../models/lc-button-callback-event';

@Component({
  selector: 'lc-lc-button-cell',
  templateUrl: './lc-button-cell.component.html',
})
export class LcButtonCellComponent implements ViewCell, OnInit {
  @Input() public value: string | number;
  @Input() public rowData: any;

  @Output() public callbackFunction: EventEmitter<any> = new EventEmitter();
  public buttonId: string;
  public buttonToolTip: string;
  public iconName: string;

  constructor() {
  }

  ngOnInit() {
  }

  public onButtonClicked() {
    const buttonCallbackEvent: LcButtonCallbackEvent = {
      buttonId: this.buttonId,
      buttonColumnComponent: this,
      rowData: this.rowData,
    };
    this.callbackFunction.emit(buttonCallbackEvent);
  }
}
