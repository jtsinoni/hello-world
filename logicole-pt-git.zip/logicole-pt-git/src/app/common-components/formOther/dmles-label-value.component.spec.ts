import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';

import { DmlesLabelValueComponent } from './dmles-label-value.component';
import {FormsModule} from '@angular/forms';
import {LoggerService} from '../../services/logger/logger.service';

describe('DmlesLabelValueComponent', () => {
  let component: DmlesLabelValueComponent;
  let fixture: ComponentFixture<DmlesLabelValueComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ FormsModule ],
      declarations: [ DmlesLabelValueComponent ],
      providers: [LoggerService],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DmlesLabelValueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
