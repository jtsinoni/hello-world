import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {FormsModule} from '@angular/forms';
import {ReadonlyLabelValueComponent} from './readonly-label-value.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule
  ],
  declarations: [ReadonlyLabelValueComponent],
  exports : [ReadonlyLabelValueComponent]
})
export class ReadonlyLabelValueModule { }
