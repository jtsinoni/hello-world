import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReadonlyLabelValueComponent } from './readonly-label-value.component';

describe('ReadonlyLabelValueComponent', () => {
  let component: ReadonlyLabelValueComponent;
  let fixture: ComponentFixture<ReadonlyLabelValueComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReadonlyLabelValueComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReadonlyLabelValueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
