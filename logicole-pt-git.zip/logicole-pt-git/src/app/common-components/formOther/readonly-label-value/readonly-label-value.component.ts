import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'lc-readonly-label-value',
  templateUrl: './readonly-label-value.component.html'
})
export class ReadonlyLabelValueComponent implements OnInit {

  @Input() label:string;
  @Input() value:string;

  constructor() { }

  ngOnInit() {
  }

}
