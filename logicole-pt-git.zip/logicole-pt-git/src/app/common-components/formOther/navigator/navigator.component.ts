import { Component, OnInit, Input, EventEmitter, Output, OnChanges, SimpleChanges } from '@angular/core';
import { LoggerService } from '../../../services/logger/logger.service';

@Component({
    selector: 'lc-navigator',
    templateUrl: './navigator.component.html',
    styleUrls: ['./navigator.component.scss']
})
export class NavigatorComponent implements OnInit, OnChanges {
    @Input() currentPageIndex: number;
    @Input() numberOfRecords: number;
    @Output() pageIndexChanged: EventEmitter<number> = new EventEmitter();

    constructor(private logger: LoggerService) { }

    public ngOnInit() {
    }

    public ngOnChanges(changes: SimpleChanges): void {
    }

    public onFirstPageClicked(): void {
        this.setPageIndexAndRaiseEvent(0);
    }

    public onPreviousPageClicked(): void {
        this.setPageIndexAndRaiseEvent(this.currentPageIndex - 1);
    }

    public onNextPageClicked(): void {
        this.setPageIndexAndRaiseEvent(this.currentPageIndex + 1);
    }

    public onLastPageClicked(): void {
        this.setPageIndexAndRaiseEvent(this.numberOfRecords - 1);
    }

    private setPageIndexAndRaiseEvent(index: number) {
        let newPageIndex = index;

        if (newPageIndex < 0) {
            newPageIndex = 0;
        }
        if (newPageIndex >= this.numberOfRecords) {
            newPageIndex = this.numberOfRecords - 1;
        }
        if (newPageIndex !== this.currentPageIndex) {
            this.currentPageIndex = newPageIndex;
            this.pageIndexChanged.emit(this.currentPageIndex);
        }
    }
}
