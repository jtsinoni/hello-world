import { Component, Input, OnInit } from '@angular/core';
import { LoggerService } from '../../services/logger/logger.service';

@Component({
  selector: 'dmles-label-value',
  templateUrl: './dmles-label-value.component.html'
})
export class DmlesLabelValueComponent implements OnInit {

  @Input() label: string;
  @Input() value: string;
  labelColsClass: string;
  valueColsClass: string;
  labelCustomClass: string;
  valueCustomClass: string;
  popover: string;

  constructor(private logger: LoggerService) { }

  ngOnInit() {
    if (!this.labelColsClass){
      this.labelColsClass = 'col-sm-3';
    }

    if (!this.valueColsClass){
      this.valueColsClass = 'col-sm-9';
    }
  }

}
