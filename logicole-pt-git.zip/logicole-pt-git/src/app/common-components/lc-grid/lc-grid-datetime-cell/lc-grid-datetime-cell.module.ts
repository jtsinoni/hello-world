import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {LcGridDatetimeCellComponent} from './lc-grid-datetime-cell.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [
    LcGridDatetimeCellComponent
  ],
  entryComponents: [
    LcGridDatetimeCellComponent
  ]
})
export class LcGridDatetimeCellModule {
}
