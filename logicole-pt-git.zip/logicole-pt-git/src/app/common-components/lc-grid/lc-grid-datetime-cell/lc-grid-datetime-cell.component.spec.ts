import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LcGridDatetimeCellComponent } from './lc-grid-datetime-cell.component';

describe('LcGridDatetimeCellComponent', () => {
  let component: LcGridDatetimeCellComponent;
  let fixture: ComponentFixture<LcGridDatetimeCellComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LcGridDatetimeCellComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LcGridDatetimeCellComponent);
    component = fixture.componentInstance;
    component.params = {value: '2018-04-10'};
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
