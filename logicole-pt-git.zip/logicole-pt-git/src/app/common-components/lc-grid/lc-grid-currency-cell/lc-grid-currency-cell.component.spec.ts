import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {LoggerService} from '@lc-services/*';
import {LcGridCurrencyCellComponent} from './lc-grid-currency-cell.component';

describe('LcGridCurrencyCellComponent', () => {
  let component: LcGridCurrencyCellComponent;
  let fixture: ComponentFixture<LcGridCurrencyCellComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [LcGridCurrencyCellComponent],
      providers: [
        LoggerService,
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LcGridCurrencyCellComponent);
    component = fixture.componentInstance;
    component.params = {value: 12};
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
