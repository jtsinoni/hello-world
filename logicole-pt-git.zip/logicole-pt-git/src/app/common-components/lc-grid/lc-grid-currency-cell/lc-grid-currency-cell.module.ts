import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {LcGridCurrencyCellComponent} from './lc-grid-currency-cell.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [
    LcGridCurrencyCellComponent
  ],
  entryComponents: [
    LcGridCurrencyCellComponent
  ]
})
export class LcGridCurrencyCellModule {
}
