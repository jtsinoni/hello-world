import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA, EventEmitter } from '@angular/core';
import { HttpTestModule } from '../../common-components/test/http-test.module';

import { LcGridComponent } from './lc-grid.component';
import { LcGridCardSettings } from './models/lc-grid-card-settings';
import { AgGridModule } from 'ag-grid-angular';
import { LoggerService } from '../../services/logger/logger.service';
import { GridOptions, ColDef, Column } from 'ag-grid/main';
import { GridOptionsWrapper } from 'ag-grid/dist/lib/gridOptionsWrapper';
import { ToastrModule } from 'ngx-toastr';
import { LcButtonLinkCellComponent } from '../lc-grid/lc-button-link-cell/lc-button-link-cell.component';
import { LcGridButtonCellComponent } from '../lc-grid/lc-button-cell/lc-button-cell.component';
import { LcGridCheckboxCellComponent } from '../lc-grid/lc-grid-checkbox-cell/lc-grid-checkbox-cell.component';
import { LcButtonLinkCellModule } from '../lc-grid/lc-button-link-cell/lc-button-link-cell.module';
import { LcButtonCellModule } from '../lc-grid/lc-button-cell/lc-button-cell.module';
import { LcGridCheckboxCellModule } from '../lc-grid/lc-grid-checkbox-cell/lc-grid-checkbox-cell.module';

describe('LcGridComponent', () => {
  let component: LcGridComponent;
  let fixture: ComponentFixture<LcGridComponent>;
  const gridOptions: GridOptions = {};

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        AgGridModule.withComponents([
          LcButtonLinkCellComponent,
          LcGridButtonCellComponent,
          LcGridCheckboxCellComponent,
        ]),
        LcButtonLinkCellModule,
        LcButtonCellModule,
        LcGridCheckboxCellModule,
        HttpTestModule.forRoot(),
        ToastrModule.forRoot()],
        declarations: [LcGridComponent],
        schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [LoggerService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LcGridComponent);
    component = fixture.componentInstance;
    component.lcGridOptions = this.gridOptions;
    component.lcGridCardSettings = new LcGridCardSettings();
    component.lcGridRowData = [];
    component.lcOnRefresh = new EventEmitter<string>();
    component.lcSelectionChanged = new EventEmitter<any>();
    component.lcOnGridReady = new EventEmitter<any>();
    component.lcGridSizeChanged = new EventEmitter<any>();
    component.lcCellValueChanged = new EventEmitter<any>();
    component.lcCellClicked = new EventEmitter<any>();
    component.lcCellDoubleClicked = new EventEmitter<any>();
    component.lcRowClicked = new EventEmitter<any>();
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

