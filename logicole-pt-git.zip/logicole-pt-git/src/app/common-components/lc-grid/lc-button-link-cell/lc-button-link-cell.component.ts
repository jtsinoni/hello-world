import { Component, OnInit } from '@angular/core';
import {ICellRendererAngularComp} from 'ag-grid-angular';
import { LoggerService } from '../../../services/logger/logger.service';

@Component({
  selector: 'lc-button-link-cell',
  template: `<span><button style="height: 20px" (click)="invokeParentGoToRowDetailsMethod()"
            class="btn btn-link btn-link-text">{{paramsValue}}</button></span>`,
  styles: [`.btn {
            line-height: 0.5
            }`]
})
export class LcButtonLinkCellComponent implements ICellRendererAngularComp {
  public params: any;
  public paramsValue: string;

  constructor(private logger: LoggerService) { }

  agInit(params: any): void {
    this.params = params;
    this.paramsValue = params.value;
  }

  public invokeParentGoToRowDetailsMethod() {
    this.params.context.componentParent.lcGridGoToRowDetails(this.params.data);
  }

  refresh(params: any): boolean {
    this.params = params;
    return true;
  }
}
