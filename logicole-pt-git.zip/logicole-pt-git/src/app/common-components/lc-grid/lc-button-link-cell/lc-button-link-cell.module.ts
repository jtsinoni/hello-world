import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LcButtonLinkCellComponent } from './lc-button-link-cell.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [LcButtonLinkCellComponent],
  entryComponents: [LcButtonLinkCellComponent]
})
export class LcButtonLinkCellModule { }
