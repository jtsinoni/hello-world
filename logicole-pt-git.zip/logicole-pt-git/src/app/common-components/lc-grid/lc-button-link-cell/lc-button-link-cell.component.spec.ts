import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA} from '@angular/core';
import { LcButtonLinkCellComponent } from './lc-button-link-cell.component';
import { LoggerService } from '../../../services/logger/logger.service';

describe('LcButtonLinkCellComponent', () => {

  let component: LcButtonLinkCellComponent;
  let fixture: ComponentFixture<LcButtonLinkCellComponent>;
  let paramsValue: string;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LcButtonLinkCellComponent ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
      providers: [
        LoggerService,
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LcButtonLinkCellComponent);
    paramsValue = 'whatever';
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
