import { Component, OnInit } from '@angular/core';
import {ICellRendererAngularComp} from 'ag-grid-angular';
import { LoggerService } from '../../../services/logger/logger.service';

@Component({
  selector: 'lc-grid-checkbox-cell',
  template: `<input type="checkbox" [checked]="checkedValue" (click)=onClicked()/>`
})
export class LcGridCheckboxCellComponent implements ICellRendererAngularComp {
  public params: any;
  public checkedValue: boolean;

  constructor(private logger: LoggerService) { }

  agInit(params: any): void {
    this.params = params;
    this.checkedValue = (params.value === undefined || params.value === null) ? false : params.value;
  }

  onClicked(): void {
    this.checkedValue = !this.checkedValue;
    this.params.context.componentParent.lcGridCheckboxClicked(this.params.data, this.checkedValue);
  }

  refresh(): boolean {
    return false;
  }

}

