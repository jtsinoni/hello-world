import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LcGridCheckboxCellComponent } from './lc-grid-checkbox-cell.component';
import { LoggerService } from '../../../services/logger/logger.service';

describe('LcGridCheckboxCellComponent', () => {
  let component: LcGridCheckboxCellComponent;
  let fixture: ComponentFixture<LcGridCheckboxCellComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LcGridCheckboxCellComponent ],
      providers: [
        LoggerService,
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LcGridCheckboxCellComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
