import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LcGridCheckboxCellComponent } from './lc-grid-checkbox-cell.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [LcGridCheckboxCellComponent],
  entryComponents: [LcGridCheckboxCellComponent]
})
export class LcGridCheckboxCellModule { }
