import { Component, EventEmitter, Input, OnChanges, OnInit, Output } from '@angular/core';
import { GridOptions, ColDef, Column } from 'ag-grid/main';
import { LcGridCardSettings } from './models/lc-grid-card-settings';
import { LoggerService } from '../../services/logger/logger.service';

@Component({
  selector: 'lc-grid',
  templateUrl: './lc-grid.component.html'
})
export class LcGridComponent implements OnInit {

  @Input() public lcGridOptions: GridOptions;
  @Input() public lcGridCardSettings: LcGridCardSettings;
  @Input() public lcGridRowData: Array<any> = [];

  @Output() public lcOnRefresh = new EventEmitter<string>();
  @Output() public lcSelectionChanged = new EventEmitter<any>();
  @Output() public lcOnGridReady = new EventEmitter<any>();
  @Output() public lcGridSizeChanged = new EventEmitter<any>();
  @Output() public lcCellValueChanged = new EventEmitter<any>();
  @Output() public lcCellClicked = new EventEmitter<any>();
  @Output() public lcCellDoubleClicked = new EventEmitter<any>();
  @Output() public lcRowClicked = new EventEmitter<any>();

  private gridApi;
  public overlayLoadingTemplate: string;
  public overlayNoRowsTemplate: string;

  constructor(private logger: LoggerService) {
    this.overlayLoadingTemplate =
      '<div class="animated fadeInDown" style="margin: 0 auto; width: 300px">' +
      '<span class="ag-overlay-loading-center" style=\"padding: 10px; border: 2px solid #444; background: lightgoldenrodyellow;\">Please wait while your data loads</span>' +
      '</div>';
    this.overlayNoRowsTemplate =
      '<div class="animated fadeInDown" style="margin: 0 auto; width: 150px">' +
      '<span class="ag-overlay-loading-center" style=\"padding: 10px; border: 2px solid #444; background: lightgoldenrodyellow;\">No rows to display</span>' +
      '</div>';

   }

  ngOnInit() {
    // The below line makes this the parent object
    // this.lcGridOptions.context.componentParent = this;
  }

  public onSelectionChanged(rowData: any) {
    this.logger.debug(`lc-grid onSelectionChanged`);
    this.lcSelectionChanged.emit(rowData);
  }

  public refreshClick() {
    this.logger.debug(`refreshClick`);
    this.lcOnRefresh.emit('refreshTable');
  }

  public exportClick() {
    // Do not export columns that do not have a field value (such as button columns, etc.)
    const columns: Array<ColDef> = this.lcGridOptions.columnDefs;
    const titles: Array<string> = [];

    columns.forEach((colItem: ColDef) => {
      if (colItem.field !== undefined && colItem.field !== null && colItem.field.length > 0) {
        titles.push(colItem.field);
      }
    });

    let filename: string = (this.lcGridCardSettings.cardDownloadCsvFilename === undefined ||
      this.lcGridCardSettings.cardDownloadCsvFilename.trim().length === 0 ?
        this.lcGridCardSettings.cardId :
        this.lcGridCardSettings.cardDownloadCsvFilename.trim());

    if (!filename.endsWith('.csv')) {
      filename = filename + '.csv';
    }

    const params = {
      skipHeader: false,
      columnGroups: false,
      skipFooters: false,
      skipGroups: false,
      skipPinnedTop: false,
      skipPinnedBottom: false,
      allColumns: true,
      onlySelected: false,
      suppressQuotes: false,
      fileName: filename,
      columnSeparator: ',',
      columnKeys: titles,
    };

    this.gridApi.exportDataAsCsv(params);
  }

  onSearch(query: string = '') {
    this.logger.debug(`in onSearch with data: ${query}`);
    this.lcGridOptions.api.setQuickFilter(query);
  }

  onGridReady(param: any) {
    this.gridApi = param.api;

    if (this.lcGridRowData !== undefined && this.lcGridRowData.length > 0) {
      this.gridApi.setRowData(this.lcGridRowData);
      this.gridApi.sizeColumnsToFit();
    }

    this.lcOnGridReady.emit(param);
  }

  onGridSizeChanged(params: any) {
    this.lcGridSizeChanged.emit(params);
  }

  onCellValueChanged(value: any) {
    this.lcCellValueChanged.emit(value);
  }

  onCellClicked(data: any) {
    this.lcCellClicked.emit(data);
  }

  onCellDoubleClicked(data: any) {
    this.lcCellDoubleClicked.emit(data);
  }

  onRowClicked(row: any) {
    this.lcRowClicked.emit(row);
  }

}
