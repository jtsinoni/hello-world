import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {AgGridModule} from 'ag-grid-angular';
import {LcGridComponent} from './lc-grid.component';
import {LcButtonCellModule} from './lc-button-cell/lc-button-cell.module';
import {LcButtonLinkCellModule} from './lc-button-link-cell/lc-button-link-cell.module';
import {LcGridCheckboxCellModule} from './lc-grid-checkbox-cell/lc-grid-checkbox-cell.module';
import {LcGridCheckboxDisplayOnlyCellModule} from './lc-grid-checkbox-display-only-cell/lc-grid-checkbox-display-only-cell.module';
import {LcGridCurrencyCellModule} from './lc-grid-currency-cell/lc-grid-currency-cell.module';
import {LcGridDateCellModule} from './lc-grid-date-cell/lc-grid-date-cell.module';
import { LcGridDatetimeCellModule } from './lc-grid-datetime-cell/lc-grid-datetime-cell.module';

@NgModule({
  imports: [
    CommonModule,
    AgGridModule,
    LcButtonCellModule,
    LcButtonLinkCellModule,
    LcGridCheckboxCellModule,
    LcGridCheckboxDisplayOnlyCellModule,
    LcGridCurrencyCellModule,
    LcGridDateCellModule,
    LcGridDatetimeCellModule,
  ],
  declarations: [LcGridComponent],
  exports: [LcGridComponent]
})
export class LcGridModule {
}
