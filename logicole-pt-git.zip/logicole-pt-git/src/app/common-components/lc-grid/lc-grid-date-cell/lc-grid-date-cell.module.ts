import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import { LcGridDateCellComponent } from './lc-grid-date-cell.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [
    LcGridDateCellComponent
  ],
  entryComponents: [
    LcGridDateCellComponent
  ]
})
export class LcGridDateCellModule {
}
