import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LcGridDateCellComponent } from './lc-grid-date-cell.component';

describe('LcGridDateCellComponent', () => {
  let component: LcGridDateCellComponent;
  let fixture: ComponentFixture<LcGridDateCellComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LcGridDateCellComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LcGridDateCellComponent);
    component = fixture.componentInstance;
    component.params = {value: '2018-04-10'};
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
