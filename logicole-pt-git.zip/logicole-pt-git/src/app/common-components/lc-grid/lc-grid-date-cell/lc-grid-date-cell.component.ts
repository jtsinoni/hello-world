import {Component, OnInit} from '@angular/core';
import {ViewCell} from 'ng2-smart-table';
import {ContentConstants} from '../../../constants/content.constants';

@Component({
  selector: 'lc-lc-grid-date-cell',
  template: `<span>{{ params.value | date:dateFormat }}</span>`
})
export class LcGridDateCellComponent implements OnInit {
  public params: any;
  dateFormat: string = ContentConstants.FORMAT_DATE;
  constructor() { }

  ngOnInit() {
  }

  agInit(params: any): void {
    this.params = params;
  }

  refresh(): boolean {
    return false;
  }

}
