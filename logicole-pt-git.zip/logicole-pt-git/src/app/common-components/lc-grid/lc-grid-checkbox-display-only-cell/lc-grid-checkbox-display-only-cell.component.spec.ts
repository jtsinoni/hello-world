import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {LoggerService} from '@lc-services/*';
import {LcGridCheckboxDisplayOnlyCellComponent} from './lc-grid-checkbox-display-only-cell.component';

describe('LcGridCheckboxDisplayOnlyCellComponent', () => {
  let component: LcGridCheckboxDisplayOnlyCellComponent;
  let fixture: ComponentFixture<LcGridCheckboxDisplayOnlyCellComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [LcGridCheckboxDisplayOnlyCellComponent],
      providers: [
        LoggerService,
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LcGridCheckboxDisplayOnlyCellComponent);
    component = fixture.componentInstance;
    component.params = {value: true};
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
