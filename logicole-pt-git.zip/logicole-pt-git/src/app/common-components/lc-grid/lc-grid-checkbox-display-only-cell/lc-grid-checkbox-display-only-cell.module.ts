import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {LcGridCheckboxDisplayOnlyCellComponent} from './lc-grid-checkbox-display-only-cell.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [
    LcGridCheckboxDisplayOnlyCellComponent
  ],
  entryComponents: [
    LcGridCheckboxDisplayOnlyCellComponent
  ]
})
export class LcGridCheckboxDisplayOnlyCellModule {
}
