import {Component} from '@angular/core';
import {ICellRendererAngularComp} from 'ag-grid-angular';

@Component({
  selector: 'ag-grid-checkbox-cell',
  template: `<input type="checkbox" [checked]="this.isChecked" [disabled]="true"/>`
})
export class LcGridCheckboxDisplayOnlyCellComponent implements ICellRendererAngularComp {

  // this component can be used when you want to display a boolean value in a disabled checkbox
  // where the checkbox will be checked when this.params.value === true and unchecked when false

  public isChecked: boolean;
  public params: any;

  agInit(params: any): void {
    this.params = params;
    this.isChecked = (this.params.value) ? true : false;
  }

  refresh(): boolean {
    return false;
  }
}
