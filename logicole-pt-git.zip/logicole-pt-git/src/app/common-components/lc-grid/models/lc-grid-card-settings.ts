export class LcGridCardSettings {
    public cardId: string;
    public cardShowDownload: boolean = true;
    public cardShowGlobalSearch: boolean = true;
    public cardShowHeader: boolean = true;
    public cardShowRefresh: boolean = true;
    public cardTitle: string;
    public cardTitleIcon: string;
    public cardDownloadCsvFilename?: string;
  }
