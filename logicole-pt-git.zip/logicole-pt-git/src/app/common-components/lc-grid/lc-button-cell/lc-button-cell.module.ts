import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LcGridButtonCellComponent } from './lc-button-cell.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [LcGridButtonCellComponent],
  entryComponents: [LcGridButtonCellComponent]
})
export class LcButtonCellModule { }
