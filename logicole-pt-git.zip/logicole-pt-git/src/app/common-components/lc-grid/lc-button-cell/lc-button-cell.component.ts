import { Component, OnInit } from '@angular/core';
import {ICellRendererAngularComp} from 'ag-grid-angular';
import { LoggerService } from '../../../services/logger/logger.service';

@Component({
  selector: 'lc-button-cell',
  templateUrl: './lc-button-cell.component.html',
  styleUrls: ['./lc-button-cell.component.scss']
})
export class LcGridButtonCellComponent implements ICellRendererAngularComp {
  public params: any;
  public buttonIconName: string;
  public buttonToolTip: string;
  public buttonId: string;

  constructor(private logger: LoggerService) { }

  agInit(params: any): void {
    this.params = params;
    this.buttonIconName = this.params.context.buttonIconName;
    this.buttonToolTip = this.params.context.buttonToolTip;
    this.buttonId = this.params.context.buttonId;
  }

  public onButtonClicked(event: any) {
    this.params.context.componentParent.lcGridRowButtonClicked(this.params.data);
  }

  refresh(params: any): boolean {
    this.params = params;
    return true;
  }
}
