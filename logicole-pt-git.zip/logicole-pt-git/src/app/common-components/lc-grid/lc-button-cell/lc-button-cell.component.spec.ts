import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LcGridButtonCellComponent } from './lc-button-cell.component';
import { LoggerService } from '../../../services/logger/logger.service';

describe('LcButtonCellComponent', () => {
  let component: LcGridButtonCellComponent;
  let fixture: ComponentFixture<LcGridButtonCellComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LcGridButtonCellComponent ],
      providers: [
        LoggerService,
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LcGridButtonCellComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
