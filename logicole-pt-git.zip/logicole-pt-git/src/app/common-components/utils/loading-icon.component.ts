import {Component, Input, OnInit} from '@angular/core';

@Component({
  selector: 'lc-loading-icon',
  templateUrl: './loading-icon.component.html'
})
export class LoadingIconComponent implements OnInit {

  @Input() public loadingMsg: string;

  constructor() { }

  ngOnInit() {
    if (!this.loadingMsg){
      this.loadingMsg = 'Loading...';
    }
  }

}
