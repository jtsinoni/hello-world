import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FacetComponent} from './facet/facet.component';
import {FormsModule} from '@angular/forms';
import {SearchFacetsComponent} from './search-facets/search-facets.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule
  ],
  declarations: [
    FacetComponent,
    SearchFacetsComponent
  ],
  exports: [SearchFacetsComponent]
})
export class SearchModule {
}
