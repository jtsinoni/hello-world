import {async, ComponentFixture, TestBed} from '@angular/core/testing';

import {FacetComponent} from './facet.component';
import {FormsModule} from '@angular/forms';
import {FacetConfiguration} from '../../../models/facet-configuration.model';
import {a11yTests, prettyPrintA11Y} from '@lc-a11y/*';
import {LoggerService} from '@lc-services/*';

describe('FacetComponent', () => {
  let component: FacetComponent;
  let fixture: ComponentFixture<FacetComponent>;
  let logger: LoggerService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [FormsModule],
      providers: [LoggerService],
      declarations: [FacetComponent]
    })
      .compileComponents();

    logger = TestBed.get(LoggerService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FacetComponent);
    component = fixture.componentInstance;
    component.facetConfiguration = new FacetConfiguration();
    component.facetOptions = [];
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have no a11y violations', async(() => {
    a11yTests(fixture.nativeElement)
      .then((results) => {
        expect(results.violations.length).toBe(0, `${prettyPrintA11Y(results.violations)}`);
      })
      .catch((error) => {
        logger.error(`${error}`);
      });
  }));
});
