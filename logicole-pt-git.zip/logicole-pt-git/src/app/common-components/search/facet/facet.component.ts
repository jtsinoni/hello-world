import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {FacetConfiguration} from '../../../models/facet-configuration.model';
import {FacetOption} from '../../../models/facet-option.model';
import {SearchConstants} from '../../../constants/search.constants';

@Component({
  selector: 'lc-facet',
  templateUrl: './facet.component.html',
  styleUrls: ['./facet.component.scss']
})
export class FacetComponent implements OnInit {
  facetId: string;
  facetHeadingId: string;
  facetBodyId: string;
  facetDataTarget: string;
  facetDataParent: string;
  facetCollapsed: boolean;

  @Input() facetConfiguration: FacetConfiguration;
  @Input() facetOptions: Array<FacetOption> = [];
  @Output() facetOptionClicked: EventEmitter<FacetOption> = new EventEmitter<FacetOption>();
  @Output() facetOptionsCleared: EventEmitter<Array<FacetOption>> = new EventEmitter<Array<FacetOption>>();

  facetOptionsWithNonZeroCounts: Array<FacetOption> = [];

  // used to filter the displayed facet options to only those that match (contain) the text string
  matchText: string = '';

  // used to calculate the current height of the facet
  heightPerFacetOptionDisplayed: number = 28;
  maxFacetOptionsDisplayed: number = 10;
  facetOptionsDisplayed: number = this.maxFacetOptionsDisplayed;
  facetOptionMaxStringLength: number = 50;
  height: number;

  lastFacetOptionUpdated: FacetOption = null;
  haveFacetOptionCountsBeenUpdated: boolean;

  constructor() {
  }

  ngOnInit(): void {
    this.facetId = 'facet' + this.facetConfiguration.aggregationIdentifier;
    this.facetHeadingId = 'facetHeading' + this.facetId;
    this.facetBodyId = 'facetBody' + this.facetId;
    this.facetDataTarget = '#' + this.facetBodyId;
    this.facetDataParent = '#' + this.facetId;
  }

  toggleFacet(): void {
    this.facetCollapsed = !this.facetCollapsed;
  }

  buildFilters(): any {
    const fieldValues: any[] = [];
    this.facetOptions.filter(option => option.selected).forEach(selectedOption => {
      const value = (selectedOption.value === SearchConstants.NO_VALUE) ? '' : selectedOption.value;
      const fieldValue: any = {
        field: this.facetConfiguration.elasticSearchFieldName,
        value: value
      };
      fieldValues.push(fieldValue);
    });

    return {
      operator: 'or',
      fieldValues: fieldValues
    };
  }

  private calculateHeight(): void {
    this.determineFacetOptionsWithNonZeroCounts();
    if (this.facetOptionsWithNonZeroCounts.length >= this.maxFacetOptionsDisplayed) {
      this.facetOptionsDisplayed = this.maxFacetOptionsDisplayed;
    } else {
      this.facetOptionsDisplayed = this.facetOptionsWithNonZeroCounts.length;
      for (let i: number = 0; i < this.facetOptionsWithNonZeroCounts.length; i++) {
        if (this.facetOptionsWithNonZeroCounts[i].value.length > this.facetOptionMaxStringLength) {
          this.facetOptionsDisplayed += 1;
        }
      }
    }
    this.height = this.facetOptionsDisplayed * this.heightPerFacetOptionDisplayed;
  }

  resetFacet(): Array<FacetOption> {
    this.matchText = '';
    this.haveFacetOptionCountsBeenUpdated = false;
    return this.resetOptions();
  }

  resetFacetAndNotify(): void {
    const facetOptionsCleared = this.resetFacet();
    this.facetOptionsCleared.emit(facetOptionsCleared);
  }

  private resetOptions(): Array<FacetOption> {
    const facetOptionsCleared: Array<FacetOption> = [];
    this.facetOptions.filter(facetOption => facetOption.selected).forEach(facetOption => {
      facetOption.selected = false;
      this.lastFacetOptionUpdated = facetOption;
      facetOptionsCleared.push(facetOption);
      // TODO
    });
    return facetOptionsCleared;
  }

  clearSelectedFacetOption(selectedOption): void {
    this.facetOptions.filter(option => option.value === selectedOption.value).forEach(option => {
      option.selected = false;
    });
  }

  private determineFacetOptionsWithNonZeroCounts(): void {
    this.facetOptionsWithNonZeroCounts = this.facetOptions.filter(option => option.count);
  }

  getNumberOfFacetOptionsWithNonZeroCounts(): number {
    this.determineFacetOptionsWithNonZeroCounts();
    return this.facetOptionsWithNonZeroCounts.length;
  }

  isAnOptionSelected(): boolean {
    return this.facetOptions.filter(option => option.selected).length > 0;
  }

  populate(abiAggregations: any): void {
    this.facetOptions = [];
    if (abiAggregations && abiAggregations[this.facetConfiguration.aggregationIdentifier] && abiAggregations[this.facetConfiguration.aggregationIdentifier].buckets) {
      const values = abiAggregations[this.facetConfiguration.aggregationIdentifier].buckets;
      for (let i = 0; i < values.length; i++) {
        const option: FacetOption = new FacetOption();
        option.type = this.facetConfiguration.displayLabel;
        option.value = (values[i].key === '') ? SearchConstants.NO_VALUE : values[i].key;
        option.count = values[i].doc_count;
        option.selected = false;
        this.facetOptions.push(option);
      }
    }
    this.haveFacetOptionCountsBeenUpdated = false;
    this.calculateHeight();
  }

  updateExistingFacetOptionCounts(abiAggregations: any): void {
    if (abiAggregations && abiAggregations[this.facetConfiguration.aggregationIdentifier] && abiAggregations[this.facetConfiguration.aggregationIdentifier].buckets) {
      const values = abiAggregations[this.facetConfiguration.aggregationIdentifier].buckets;
      this.facetOptions.forEach(option => option.count = 0);

      // now update the counts for the existing facet options and add any newly found facet options
      values.forEach(value => {
        this.facetOptions.filter(option => option.value === values.key).forEach(option => {
          option.count = value.doc_count;
        });
      });
      this.haveFacetOptionCountsBeenUpdated = true;
    }
  }

  optionClicked(facetOption: FacetOption): void {
    this.facetOptionClicked.emit(facetOption);
  }

  getOptions() {
    if (this.matchText) {
      return this.getFilteredOptions();
    } else {
      return this.facetOptions;
    }
  }

  private getFilteredOptions() {
    return this.facetOptions.filter(option => option.value.startsWith(this.matchText.toUpperCase()));
  }

}
