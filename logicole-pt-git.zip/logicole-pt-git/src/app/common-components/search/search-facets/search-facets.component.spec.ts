import {async, ComponentFixture, TestBed} from '@angular/core/testing';

import {SearchFacetsComponent} from './search-facets.component';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {a11yTests, prettyPrintA11Y} from '@lc-a11y/*';
import {LoggerService} from '@lc-services/*';
import {FormsModule} from '@angular/forms';

describe('SearchFacetsComponent', () => {
  let component: SearchFacetsComponent;
  let fixture: ComponentFixture<SearchFacetsComponent>;
  let logger: LoggerService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [SearchFacetsComponent],
      imports: [FormsModule],
      providers: [LoggerService],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();

    logger = TestBed.get(LoggerService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchFacetsComponent);
    component = fixture.componentInstance;
    component.facets = [];
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have no a11y violations', async(() => {
    a11yTests(fixture.nativeElement)
      .then((results) => {
        expect(results.violations.length).toBe(0, `${prettyPrintA11Y(results.violations)}`);
      })
      .catch((error) => {
        logger.error(`${error}`);
      });
  }));
});
