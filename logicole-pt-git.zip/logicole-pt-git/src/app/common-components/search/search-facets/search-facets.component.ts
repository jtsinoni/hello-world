import {Component, EventEmitter, Input, OnInit, Output, QueryList, ViewChildren} from '@angular/core';
import {FacetComponent} from '../facet/facet.component';
import {FacetOption} from '../../../models/facet-option.model';

@Component({
  selector: 'lc-search-facets',
  templateUrl: './search-facets.component.html',
  styleUrls: ['./search-facets.component.scss']
})
export class SearchFacetsComponent implements OnInit {

  selectedFacetOptions: Array<FacetOption> = [];

  secondarySearchBreadcrumb: string = '';

  @Input() facets: Array<any>;
  @Output() facetSearchUpdated: EventEmitter<FacetOption> = new EventEmitter<FacetOption>();

  @ViewChildren(FacetComponent)
  private childrenFacets: QueryList<FacetComponent>;

  private lastFacetOptionUpdated: FacetOption;

  searchWithinResultsInput: string;
  searchWithinResultsKeywords: Array<string> = [];
  hasResults: boolean;

  constructor() {
  }

  ngOnInit(): void {
  }

  populateFacets(equipmentRecordAggregations: any): void {
    this.childrenFacets.forEach(facet => {

      // if THIS facet has any facet options selected
      if (facet.isAnOptionSelected()) {
        // if the last user facet-effecting action was one that updated a specific facet option
        if (this.lastFacetOptionUpdated) {
          // if the last facet option that was updated belongs to THIS facet
          if (this.lastFacetOptionUpdated.type === facet.facetConfiguration.displayLabel) {

            // if THIS facet has ever had the counts associated with its facet options updated
            if (facet.haveFacetOptionCountsBeenUpdated) {
              // since we've already updated this facet's option counts once (probably due the fact
              // that another facet was interacted with), go ahead and update them again
              facet.updateExistingFacetOptionCounts(equipmentRecordAggregations);
            } else {

              // leave the facet options and counts as is - usually you are here when only one facet has
              // been interacted with so far, leave as is so the user sees the original facet options and
              // counts that were generated just using the user input search string
            }
            // the last facet option that was updated belongs to a different facet
          } else {
            // update THIS facet's existing facet options with new counts
            facet.updateExistingFacetOptionCounts(equipmentRecordAggregations);
          }
          // the last user facet-effecting action was a Clear All or something that didn't effect a specific facet
        } else {
          // update THIS facet's existing facet options with new counts
          facet.updateExistingFacetOptionCounts(equipmentRecordAggregations);
        }
        // THIS facet has no facet options currently selected
      } else {
        // reinitialize THIS facet's options and counts with the latest aggregation results
        facet.populate(equipmentRecordAggregations);
      }
    });
    this.hasResults = this.childrenFacets.filter(facet => facet.facetOptions.length > 0).length > 0;
  }

  buildFilters(): Array<any> {
    const requestFilters = [];
    this.childrenFacets.forEach(facet => {
      const facetRequestFilter = facet.buildFilters();
      if (facetRequestFilter['fieldValues'].length > 0) {
        if (facet.facetConfiguration.aggregationIdentifier === 'ownership') {
          for (let i = 0, fieldValueLength = facetRequestFilter['fieldValues'].length; i < fieldValueLength; i++) {
            facetRequestFilter['fieldValues'][i].value = this.convertOwnershipStringToCodeString(facetRequestFilter['fieldValues'][i].value);
          }
        }
        requestFilters.push(facetRequestFilter);
      }
    });
    return requestFilters;
  }

  convertOwnershipStringToCodeString(ownershipCode: string): string {
    let returnString: string = '0';
    if (ownershipCode === 'ORGANIZATIONAL') {
      returnString = '1';
    } else if (ownershipCode === 'OPERATING LEASED') {
      returnString = '2';
    } else if (ownershipCode === 'OTHER GOV. OWNED') {
      returnString = '3';
    } else if (ownershipCode === 'NON-GOV. OWNED') {
      returnString = '4';
    } else if (ownershipCode === 'CAPITAL LEASED') {
      returnString = '5';
    } else {
      returnString = '1';
    }
    return returnString;
  }

  clearAllClicked(): void {
    if (this.secondarySearchBreadcrumb.length > 0) {
      // TODO do something here if needed, was init the search service
    } else {
      // if we are NOT in the midst of a secondary search, clear facets and categories and trigger search
      this.clearAllSelectedFacetOptions();
      this.searchWithinResultsKeywords = [];
      // TODO clear category breadcrumbs
    }
    this.lastFacetOptionUpdated = null;
    this.facetSearchUpdated.emit(this.lastFacetOptionUpdated);
  }

  private clearAllSelectedFacetOptions(): void {
    this.selectedFacetOptions = [];
    this.childrenFacets.forEach(facet => facet.resetFacet());
  }

  optionClicked(option: FacetOption): void {
    if (option.selected) {
      this.selectedFacetOptions.push(option);
    } else {
      this.removeFacetOption(option);
    }
    this.lastFacetOptionUpdated = option;
    this.facetSearchUpdated.emit(this.lastFacetOptionUpdated);
  }

  clearSelectedFacetOption(selectedOption): void {
    this.removeFacetOption(selectedOption);
    this.removeSelectedFacetOptionFromChildFacet(selectedOption);
    this.lastFacetOptionUpdated = selectedOption;
    this.facetSearchUpdated.emit(this.lastFacetOptionUpdated);
  }

  private removeFacetOption(value: FacetOption): void {
    const findIndex = this.selectedFacetOptions.findIndex(facetOption => facetOption.type === value.type && facetOption.value === value.value);
    this.selectedFacetOptions.splice(findIndex, 1);
  }

  private removeSelectedFacetOptionFromChildFacet(facetOption: FacetOption): void {
    this.childrenFacets.filter(facet => facet.facetConfiguration.displayLabel === facetOption.type).forEach(facet => facet.clearSelectedFacetOption(facetOption));
  }

  childOptionsCleared(options: Array<FacetOption>): void {
    const newArray = [];
    this.selectedFacetOptions.forEach(sOption => {
      const i = options.findIndex(op => op.type === sOption.type && op.value === sOption.value);
      if (i < 0) {
        newArray.push(sOption);
      }
    });
    this.selectedFacetOptions = newArray;
    this.lastFacetOptionUpdated = options[0];
    this.facetSearchUpdated.emit(this.lastFacetOptionUpdated);
  }

  addKeywordToSearchWithinResults() {
    if (this.searchWithinResultsInput) {
      this.searchWithinResultsKeywords.push(this.searchWithinResultsInput);
      this.facetSearchUpdated.emit(null);
    }

    this.searchWithinResultsInput = '';
  }

  clearKeyword(keyword: string): void {
    const keywordIndex = this.searchWithinResultsKeywords.findIndex(k => k === keyword);
    this.searchWithinResultsKeywords.splice(keywordIndex, 1);
    this.facetSearchUpdated.emit(null);
  }

  reset(): void {
    this.hasResults = false;
    this.childrenFacets.forEach(facet => facet.facetOptions = []);
    this.secondarySearchBreadcrumb = '';
    this.selectedFacetOptions = [];
    this.searchWithinResultsKeywords = [];
  }

}
