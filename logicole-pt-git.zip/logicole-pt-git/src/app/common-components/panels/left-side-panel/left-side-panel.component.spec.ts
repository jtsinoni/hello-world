import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {LeftSidePanelComponent} from './left-side-panel.component';
import {SidePanelService} from '../../../services/side-panel.service';
import {LoggerService} from '../../../services/logger/logger.service';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';


describe('LeftSidePanelComponent', () => {
  let component: LeftSidePanelComponent;
  let fixture: ComponentFixture<LeftSidePanelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LeftSidePanelComponent ],
      providers: [SidePanelService, LoggerService],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LeftSidePanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
