import { Component, OnInit, Input } from '@angular/core';
import { SidePanelService } from '../../../services/side-panel.service';
import { LoggerService } from '../../../services/logger/logger.service';

@Component({
  selector: 'right-side-panel',
  templateUrl: './right-side-panel.component.html'
})
export class RightSidePanelComponent implements OnInit {

  @Input() public isOpen: boolean;
  @Input() public panelWidth: string;

  private isPanelOpen: boolean = false;

  constructor(public sidePanelService: SidePanelService, private logger: LoggerService) { }

  public ngOnInit() {
    if (this.isOpen) {
      this.isPanelOpen = true;
    }
    this.onParametersChanged();
  }

  // public ngOnChanges(changes: SimpleChanges): void {
  //   this.onParametersChanged();
  // }

  private onParametersChanged(): void {
    if (this.panelWidth) {
      this.sidePanelService.rightPanelWidthOpened = this.panelWidth;
    }

    // Because all the side panels share the same service we have to check this so the
    // so the panel is correctly open/close when the page opens.
    if (this.isPanelOpen !== this.sidePanelService.isRightPanelShown) {
      this.sidePanelService.toggleRightPanel();
    }
  }
}
