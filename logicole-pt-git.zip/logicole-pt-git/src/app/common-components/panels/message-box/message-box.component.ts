import { Component, OnInit, EventEmitter, Input, Output, OnChanges, SimpleChanges, ElementRef, TemplateRef, ViewChild } from '@angular/core';
import { MessageBoxConfiguration } from '../../../models/message-box-configuration';
import { LoggerService } from '../../../services/logger/logger.service';
import { BsModalService, BsModalRef } from 'ngx-bootstrap';
import { ModalOptions } from 'ngx-bootstrap';
import { MessageBoxIcon } from '../../../models/message-box-icon';

@Component({
    selector: 'lc-message-box',
    templateUrl: './message-box.component.html',
})
export class MessageBoxComponent implements OnInit, OnChanges {
    @Input() title: string;
    @Input() message: string;
    @Input() configuration: MessageBoxConfiguration;
    @Output() buttonClicked: EventEmitter<string> = new EventEmitter();

    @ViewChild('msgBoxDiv') msgBoxModalRef: any;

    private isVisible: boolean = false;
    private bsModalRef: BsModalRef;

    constructor(private logger: LoggerService, private modalService: BsModalService) { }

    ngOnInit() {
        // this.logger.debug('MessageBox.ngOnInit() was called.');
        // this.logger.debug('isVisible: ' + this.isVisible);
    }

    ngOnChanges(changes: SimpleChanges): void {
        // this.logger.debug('MessageBox.ngOnChanges() was called.');
        if (changes.hasOwnProperty('isVisible')) {
            // this.logger.debug('isVisible (current): ' + changes['isVisible'].currentValue);
            // this.logger.debug('isVisible (previous): ' + changes['isVisible'].previousValue);
            // this.logger.debug('isVisible: ' + this.isVisible);
            if (changes['isVisible'].currentValue !== changes['isVisible'].previousValue) {
                this.changeMessageBoxVisibility();
            }
        }
    }

    public showDialog(): void {
        // this.logger.debug('showDialog was called');
        this.isVisible = true;
        this.changeMessageBoxVisibility();
    }

    public hideDialog(): void {
        // this.logger.debug('hideDialog was called.');
        this.isVisible = false;
        this.changeMessageBoxVisibility();
    }

    private onButtonClicked(buttonType: string): void {
        // this.logger.debug('a button was clicked: ' + buttonType);
        setTimeout(() => {
            this.buttonClicked.emit(buttonType);
        });
        this.msgBoxModalRef.hide();
    }

    showYesNoButtons(): boolean {
        let showYesNoButtons: boolean = false;
        if (!this.isNullOrUndefined(this.configuration)) {
            showYesNoButtons = this.configuration.showYesNoButtons;
        }
        return showYesNoButtons;
    }

    showOkCancelButtons(): boolean {
        let showOkCancelButtons: boolean = false;
        if (!this.isNullOrUndefined(this.configuration)) {
            showOkCancelButtons = this.configuration.showOkCancelButtons;
        }
        return showOkCancelButtons;
    }

    showCloseButton(): boolean {
        let showCloseButton: boolean = true;
        if (!this.isNullOrUndefined(this.configuration)) {
            showCloseButton = this.configuration.showCloseButton;
        }
        return showCloseButton;
    }

    private changeMessageBoxVisibility(): void {
        if (this.isVisible) {
            const modalOptions: ModalOptions = new ModalOptions();
            if (!this.isNullOrUndefined(this.configuration)) {
                if (!this.isNullOrUndefined(this.configuration.useAnimation)) {
                    modalOptions.animated = this.configuration.useAnimation;
                }
                if (!this.isNullOrUndefined(this.configuration.showBackdrop)) {
                    modalOptions.backdrop = this.configuration.showBackdrop;
                }
                if (!this.isNullOrUndefined(this.configuration.allowBackdropClickToClose)) {
                    modalOptions.ignoreBackdropClick = !this.configuration.allowBackdropClickToClose;
                }
                if (!this.isNullOrUndefined(this.configuration.allowEscapeToClose)) {
                    modalOptions.keyboard = this.configuration.allowEscapeToClose;
                }
            }
            this.msgBoxModalRef.config = modalOptions;
            this.bsModalRef = this.msgBoxModalRef.show();
        } else {
            this.msgBoxModalRef.hide();
        }
    }

    private isNullOrUndefined(object: any): boolean {
        let isNullOrUndefined = false;
        if ((object === null) || (object === undefined)) {
            isNullOrUndefined = true;
        }
        return isNullOrUndefined;
    }

    isLargeModal(): boolean {
        let isLargeModal: boolean = true;
        if (!this.isNullOrUndefined(this.configuration)) {
            if (!this.isNullOrUndefined(this.configuration.showLargeModal)) {
                isLargeModal = this.configuration.showLargeModal;
            }
        }
        // this.logger.debug('MessageBoxComponent.isLargeModal() returns ' + isLargeModal);
        return isLargeModal;
    }

    isSmallModal(): boolean {
        let isSmallModal: boolean = false;
        if (!this.isNullOrUndefined(this.configuration)) {
            if (!this.isNullOrUndefined(this.configuration.showLargeModal)) {
                isSmallModal = !this.configuration.showLargeModal;
            }
        }
        // this.logger.debug('MessageBoxComponent.isSmallModal() returns ' + isSmallModal);
        return isSmallModal;
    }

    showInformationIcon(): boolean {
        let showInformationIcon: boolean = false;
        if (!this.isNullOrUndefined(this.configuration)) {
            if (!this.isNullOrUndefined(this.configuration.icon)) {
                showInformationIcon = (this.configuration.icon === MessageBoxIcon.informationIcon);
            }
        }
        // this.logger.debug('MessageBoxComponent.showInformationIcon() returns ' + showInformationIcon);
        return showInformationIcon;
    }

    showWarningIcon(): boolean {
        let showWarningIcon: boolean = false;
        if (!this.isNullOrUndefined(this.configuration)) {
            if (!this.isNullOrUndefined(this.configuration.icon)) {
                showWarningIcon = (this.configuration.icon === MessageBoxIcon.warningIcon);
            }
        }
        // this.logger.debug('MessageBoxComponent.showWarningIcon() returns ' + showWarningIcon);
        return showWarningIcon;
    }

    showErrorIcon(): boolean {
        let showErrorIcon: boolean = false;
        if (!this.isNullOrUndefined(this.configuration)) {
            if (!this.isNullOrUndefined(this.configuration.icon)) {
                showErrorIcon = (this.configuration.icon === MessageBoxIcon.errorIcon);
            }
        }
        // this.logger.debug('MessageBoxComponent.showErrorIcon() returns ' + showErrorIcon);
        return showErrorIcon;
    }

    showNoIcon(): boolean {
        let showNoIcon: boolean = false;
        if (!this.isNullOrUndefined(this.configuration)) {
            if (!this.isNullOrUndefined(this.configuration.icon)) {
                showNoIcon = (this.configuration.icon === MessageBoxIcon.noIcon);
            }
        }
        // this.logger.debug('MessageBoxComponent.showNoIcon() returns ' + showNoIcon);
        return showNoIcon;
    }
}
