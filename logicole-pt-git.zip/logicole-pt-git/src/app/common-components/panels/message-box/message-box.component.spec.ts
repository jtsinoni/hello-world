import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { LoggerService } from 'app/services/logger/logger.service';

import { MessageBoxComponent } from './message-box.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Ng2SmartTableModule } from 'ng2-smart-table';
import { CommonComponentsModule } from 'app/common-components/common-components.module';
import { CommsCommonComponentsModule } from 'app/home/communications/comms-common-components/comms-common-components.module';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpTestModule } from '../../test/http-test.module';
import { ToastrModule } from 'ngx-toastr';
import { NavigationTestModule } from 'app/common-components/test/navigation-test/navigation-test.module';
import { BsModalService, BsModalRef, ModalModule } from 'ngx-bootstrap/modal';

describe('MessageBoxComponent', () => {
  let component: MessageBoxComponent;
  let fixture: ComponentFixture<MessageBoxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MessageBoxComponent ],
      imports: [
        FormsModule,
        ReactiveFormsModule,
        Ng2SmartTableModule,
        RouterTestingModule,
        HttpTestModule.forRoot(),
        ToastrModule.forRoot(),
        NavigationTestModule.forRoot(),
        ModalModule.forRoot(),
      ],
      providers: [ LoggerService ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MessageBoxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
