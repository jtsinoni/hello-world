///<reference path="../../../node_modules/ngx-bootstrap/accordion/accordion.module.d.ts"/>
import {NgModule, ModuleWithProviders} from '@angular/core';
import {DmlesAdvancedFileUploadComponent} from './fileUpload/dmles-advanced-file-upload.component';
import {UtilsModule} from './utils/utils.module';
import {MainNavService} from '../home/main-nav/main-nav.service';
import {LoggerService} from '../services/logger/logger.service';
import {LoginService} from '../services/login.service';
import {MockComponent} from './test/mock.component';
import {RouterModule} from '@angular/router';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {
  AccordionModule, AlertModule, BsDatepickerModule, BsDropdownModule, ButtonsModule,
  TypeaheadModule, CollapseModule, DatepickerModule, ModalModule, PaginationModule, PopoverModule, ProgressbarModule,
  RatingModule,
  SortableModule, TabsModule, TimepickerModule, TooltipModule, PaginationConfig
} from 'ngx-bootstrap';

import { LeftSidePanelComponent } from './panels/left-side-panel/left-side-panel.component';
import { RightSidePanelComponent } from './panels/right-side-panel/right-side-panel.component';
import {LcTableModule} from './lc-table/lc-table.module';
import {LcCurrencyInputModule} from './formInputs/lc-currency-input/lc-currency-input.module';
import {LcTextInputModule} from './formInputs/lc-text-input/lc-text-input.module';
import {LcTextAreaInputModule} from './formInputs/lc-text-area-input/lc-text-area-input.module';
import {LcSelectInputModule} from './formInputs/lc-select-input/lc-select-input.module';
import {LcEmailInputModule} from './formInputs/lc-email-input/lc-email-input.module';
import {QuantityTickerModule} from './quantity-ticker/quantity-ticker.module';
import {CommonModule} from '@angular/common';
import {LcGridModule} from './lc-grid/lc-grid.module';

import {DmlesLabelValueComponent} from './formOther/dmles-label-value.component';
import {DmlesSimpleTreeService} from './tree/dmles-simple-tree.service';
import {RemoveButtonComponent} from './buttons/remove-button.component';
import { LcTextInputComponent } from './formInputs/lc-text-input/lc-text-input.component';
import { LcTextAreaInputComponent } from './formInputs/lc-text-area-input/lc-text-area-input.component';
import { LcSelectInputComponent } from './formInputs/lc-select-input/lc-select-input.component';
import { LcEmailInputComponent } from './formInputs/lc-email-input/lc-email-input.component';
import {DmlesSimpleTreeComponent} from './tree/dmles-simple-tree.component';
import {TreeItemRendererComponent} from './tree/tree-item-renderer.component';
import { LcCurrencyInputComponent } from './formInputs/lc-currency-input/lc-currency-input.component';
import { ChangeProfileAccessComponent } from './dropdown/change-profile-access.component';
import { SpinnerComponent } from './spinner/spinner.component';
import {SpinnerModule} from './spinner/spinner.module';
import { ReadonlyLabelValueComponent } from './formOther/readonly-label-value/readonly-label-value.component';
import {ReadonlyLabelValueModule} from './formOther/readonly-label-value/readonly-label-value.module';
import { NavigatorComponent } from './formOther/navigator/navigator.component';
import { BackButtonComponent } from './buttons/back-button/back-button.component';
import { MessageBoxComponent } from './panels/message-box/message-box.component';
import {SearchModule} from './search/search.module';
import {ServicesModule} from '../services/services.module';

@NgModule({
  imports: [
    CommonModule,
    UtilsModule,
    LcTableModule,
    LcGridModule,
    SpinnerModule,
    FormsModule,
    AccordionModule.forRoot(),
    AlertModule.forRoot(),
    ButtonsModule.forRoot(),
    BsDatepickerModule.forRoot(),
    BsDropdownModule.forRoot(),
    CollapseModule.forRoot(),
    DatepickerModule.forRoot(),
    ModalModule.forRoot(),
    PaginationModule.forRoot(),
    PopoverModule.forRoot(),
    ProgressbarModule.forRoot(),
    RatingModule.forRoot(),
    SortableModule.forRoot(),
    TabsModule.forRoot(),
    TimepickerModule.forRoot(),
    TooltipModule.forRoot(),
    TypeaheadModule.forRoot(),
    QuantityTickerModule,
    PaginationModule,
    TabsModule,
    LcCurrencyInputModule,
    LcTextInputModule,
    LcTextAreaInputModule,
    LcSelectInputModule,
    LcEmailInputModule,
    ReactiveFormsModule,
    ReadonlyLabelValueModule,
    SearchModule
  ],
  declarations: [
    DmlesLabelValueComponent,
    DmlesAdvancedFileUploadComponent,
    MockComponent,
    LeftSidePanelComponent,
    RightSidePanelComponent,
    RemoveButtonComponent,
    DmlesSimpleTreeComponent,
    TreeItemRendererComponent,
    ChangeProfileAccessComponent,
    NavigatorComponent,
    BackButtonComponent,
    MessageBoxComponent,
  ],
  // Since this is shared module we need to export modules or components (without forRoot())
  exports: [
    UtilsModule,
    BsDatepickerModule,
    LcTableModule,
    LcGridModule,
    SpinnerModule,
    DmlesLabelValueComponent,
    LeftSidePanelComponent,
    RightSidePanelComponent,
    LcCurrencyInputComponent,
    RemoveButtonComponent,
    LcTextInputComponent,
    LcTextAreaInputComponent,
    LcSelectInputComponent,
    LcEmailInputComponent,
    DmlesSimpleTreeComponent,
    ChangeProfileAccessComponent,
    QuantityTickerModule,
    TreeItemRendererComponent,
    ReadonlyLabelValueComponent,
    SearchModule,
    NavigatorComponent,
    BackButtonComponent,
    MessageBoxComponent,
  ]
})
export class CommonComponentsModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: CommonComponentsModule,
      providers: [
        PaginationConfig,
        DmlesSimpleTreeService,
      ]
    };
  }
}
